# Native DynamoDB Backend Preparation Implementation Plan

> **For agentic workers:** Use `subagent-driven-development` or `executing-plans`
> when implementation is authorized. Each numbered leaf is one PR. Checkbox
> steps are work within that PR, not separate feature or test-only PRs.

**Goal:** Prepare native Floci so a later DynamoDB Local adapter can serve public
operations and internal consumers without another cross-service routing rewrite.

**Architecture:** Keep the stateful `DynamoDbService` as the native engine.
Introduce a small operation contract, bounded typed capabilities and a new
`DynamoDbFacade` for existing Java consumers. A shared API-based stream reader
uses the selected operation executor; native protocol handlers never call back
into the facade or selector.

**Tech Stack:** Java 25, Quarkus CDI, Jackson, existing StorageFactory/lifecycle,
JUnit/Mockito and existing SDK compatibility suites.

---

## Scope and estimates

Selected as **C** on 2026-09-18. Status:
[Task 36](../../TEOS_GROUNDZERO_TASKS.md#task-36-native-dynamodb-backend-preparation).
These PRs enable only native mode. D supplies the second engine later.

| PR | Work | Estimate | Merge prerequisites |
| --- | --- | --- | --- |
| 36.1 | Native control mutation ownership | 2-3 days | None |
| 36.2 | Operation contract, native adapter and typed facade | 2-4 days | 36.1 |
| 36.3 | Shared stream reader and consumer traversal | 2-4 days | 36.2 and 35.4 |
| 36.4 | Runtime side-effect ownership and lifecycle | 2-3 days | 36.3 |
| **C total** | Native remains default and only enabled engine | **8-14 developer-days** | |

The concrete shared-reader design has real dependencies: it uses 36.2's
operation contract and adapts 35.4's final consumer lifecycle. Do not label
36.3 independent by copying those types or inventing a temporary adapter.
37.1's Local client can progress after 36.2 while reader/runtime work lands.
No stacking: wait for prerequisites on `main`.

The estimate is optimistic if interpreted as mechanical interface extraction.
It includes DI/fixture changes, typed behavior preservation, account-aware
stream reconstruction and safe Pipes progress. It excludes a second retry
engine, managed containers, a generic plugin framework and native-correctness
estimate A. Focused PR checks are included, not a separate qualification project.

## Acyclic arrangement

```text
JSON / CBOR controllers, API Gateway, Step Functions SDK path
  -> thin DynamoDbJsonHandler / DynamoDbStreamsJsonHandler
  -> selected DynamoDbOperations
       native -> NativeDynamoDbJsonHandler / NativeDynamoDbStreamsJsonHandler
              -> NativeDynamoDbTableService / DynamoDbService / DynamoDbStreamService
       local  -> D's identity/metadata adapter -> Local request client

CFN, IoT, optimized Step Functions, IAM metadata, Resource Explorer
  -> DynamoDbFacade
  -> selected item/table capabilities
       native -> DynamoDbService directly
       local  -> D's ordinary Local operations

Lambda and Pipes
  -> DynamoDbStreamReader
  -> DynamoDbApiStreamReader
  -> selected DynamoDbOperations for Streams requests
```

The existing roughly 4,000-line native engine is not moved just to retain its
name as a facade. It keeps state, existing nested result types and direct unit-test
constructors. The new facade is the injection boundary for other services.
Native handlers must not inject the facade, selected operations or API reader:
that would create `backend -> handler -> facade -> backend` recursion.

## File ownership

Paths below are relative to Floci. New backend contract classes live under
`src/main/java/io/github/hectorvent/floci/services/dynamodb/backend/`.
This path choice also applies to the skeleton package declarations below.

| Unit | Existing or proposed file |
| --- | --- |
| Native engine, unchanged ownership | `src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbService.java` |
| Native stream engine | `src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbStreamService.java` |
| New native control service | `src/main/java/io/github/hectorvent/floci/services/dynamodb/NativeDynamoDbTableService.java` |
| Mechanical native handler moves | Existing `DynamoDbJsonHandler.java` and `DynamoDbStreamsJsonHandler.java` become `NativeDynamoDbJsonHandler.java` and `NativeDynamoDbStreamsJsonHandler.java` in the same package |
| New thin handlers, original public names | `src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbJsonHandler.java`, `DynamoDbStreamsJsonHandler.java` |
| New operation/capability contracts | `backend/DynamoDbOperations.java`, `backend/DynamoDbItemAccess.java`, `backend/DynamoDbTableAccess.java` under the prefix above |
| New native adapter and immutable selection | `backend/NativeDynamoDbBackend.java`, `backend/DynamoDbBackendSelector.java` |
| New caller facade and ResourceProvider | `src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbFacade.java` |
| New reader contract and parser | `backend/DynamoDbStreamReader.java`, `backend/DynamoDbApiStreamReader.java` |
| New runtime coordinator | `src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbRuntime.java` |

One-time consumers changed in C:

- `src/main/java/io/github/hectorvent/floci/services/cloudformation/CloudFormationResourceProvisioner.java`
- `src/main/java/io/github/hectorvent/floci/services/iot/IotService.java`
- `src/main/java/io/github/hectorvent/floci/services/stepfunctions/AslExecutor.java`
- `src/main/java/io/github/hectorvent/floci/core/common/IamConditionContextResolver.java`
- `src/main/java/io/github/hectorvent/floci/services/lambda/DynamoDbStreamsEventSourcePoller.java`
- `src/main/java/io/github/hectorvent/floci/services/pipes/PipesPoller.java`
- Existing constructor/test fixtures, especially
  `src/test/java/io/github/hectorvent/floci/services/cloudformation/CfnProvisionerFixture.java`.

Do not change the legacy CFN monolith's resource-type switch or add a
new type here; only its existing DynamoDB dependency/calls are rerouted.

## 36.1: Native control-operation consolidation

- [ ] Move native table-setting mutation from the existing JSON handler into
      `NativeDynamoDbTableService`, injected by constructor. Cover the shared
      creation path, UpdateTable settings and Kinesis-destination metadata
      mutations. Keep the current ImportTable call into the shared creation
      path and its initial CREATING state.
- [ ] Keep wire parsing and response formatting at the handler. Preserve
      validation ordering: rejected settings cannot leave a partially created
      native table. Do not add missing CFN properties or change native TTL/
      conditional-write semantics during this move.
- [ ] Replace handler-owned setter/persist sequences with service-owned
      operations. The returned table is a description, not an instruction for
      the handler to mutate backend state. Existing native API errors,
      descriptions, stream changes and import/Kinesis behavior stay intact.
- [ ] Add proposed `NativeDynamoDbTableServiceTest.java` in the DynamoDB test
      package. Cases: invalid create leaves no table; create/update settings
      persist; ImportTable retains its creation state; stream-view settings
      survive reload; Kinesis destination state still follows the native path.
- [ ] Run from Floci root:

```sh
./mvnw test -Dtest=NativeDynamoDbTableServiceTest,DynamoDbJsonHandlerTest,DynamoDbStreamViewTypeDurabilityTest,DynamoDbImportIntegrationTest,DynamoDbKinesisStreamingIntegrationTest
```

Expected: the move preserves the current native wire/persistence contract.
Update `docs/services/dynamodb.md` only where ownership/limitations need clarity.

## 36.2: Operation boundary and native adapter

### Raw operation contract

Create this interface. Nested value types avoid a file for every envelope:

```java
package io.github.hectorvent.floci.services.dynamodb.backend;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import java.util.Map;

public interface DynamoDbOperations {
    enum Api { DYNAMODB, DYNAMODB_STREAMS }
    record Scope(String accountId, String region) {}
    record Call(Scope scope, Api api, String action, JsonNode body) {}
    record Reply(int status, JsonNode body, Map<String, List<String>> headers) {}
    Reply execute(Call call);
}
```

Scope is explicit; validate required values at entry. Do not mutate the input
tree or expose mutable response trees to background consumers without copying.
`action` is intentionally not an enum/allowlist: D must forward all operations
the selected Local version accepts. AWS errors retain their full body, status
and relevant headers; transport failures are not successful empty replies.
Controllers continue returning reflection-safe JSON, not an SDK/HTTP client object.

### Typed capability boundary

Do not force current internal calls through the public handler. For example,
native public DeleteTable checks deletion protection while a direct native
service delete does not. A refactor must not silently change one into the other.

`DynamoDbItemAccess` contains only the externally used native methods:
`putItem` (including conditional form), `getItem`, conditional `deleteItem`,
`updateItem`, and `scan`. Replace the implicit account/separate region input
with the `Scope` above. Reuse the existing key/AttributeValue argument types.

`DynamoDbTableAccess` contains `createTable`, `describeTable`, `findTable`,
`deleteTable`, `enableStream`, `disableStream`, `listTagsOfResource`,
`tagResource`, `untagResource`, the CFN add/remove-region form of
`applyReplicaUpdates`, and scoped resource inventory.

Move only caller-required result views into the capability contract:
requested old/new update attributes; scan items, scanned count and continuation
key. Reuse `TableDefinition` as a detached description where existing consumers
need it. Never perform extra Local reads to fabricate both historical update
images when one operation returns only the requested view.

- [ ] Mechanically rename the existing handlers to the native names in the file
      map. Their dependencies remain native services, including the existing
      `DynamoDbPartiQLHandler`; they cannot re-enter the selected facade.
- [ ] Add thin handlers with the original names. Build `Call` from the current
      resolved account/region, dispatch through selected operations and rebuild
      the existing Response shape. Retain controller CRC32 handling, JSON 1.0,
      CBOR conversion, AWS error members and request metadata.
- [ ] Implement `NativeDynamoDbBackend`: raw calls delegate to the native
      handlers under explicit scope; typed capabilities call `DynamoDbService`
      directly. Reuse existing account-context helpers with bounded enter/exit,
      never leave background work on the default request-less account.
- [ ] Preserve original thin-handler constants/entry signatures used by
      `AwsJsonController`, `AwsJsonCborController` and service registration.
      Repoint the DynamoDB action sources in `tools/docs/services.yaml` to the
      native handlers so generated native action tables do not become empty.
      Keep external pass-through capability documentation distinct from claims
      of native action implementation.
- [ ] Introduce `DynamoDbFacade` for the listed Java consumers. Its methods
      delegate to selected capabilities, not to native storage or an HTTP
      request to Floci itself. Carry the IoT rule's owning account explicitly
      for MQTT/background work, alongside region.
- [ ] Treat backend calls as potentially blocking I/O now. Use the repository's
      existing worker/virtual-thread dispatch at any affected event-loop entry
      point, particularly MQTT rule execution. A synchronous facade cannot fix
      this by submitting work and then joining on the same event-loop thread.
      Preserve rule action isolation, error-action behavior and acknowledgement
      semantics. A blocking fake backend must not stall the MQTT event loop.
- [ ] Move `ResourceProvider` registration from the native engine to the facade.
      External inventory must not enumerate the abandoned native table store.
      Ensure CDI discovers one provider, not both.
- [ ] Select all capabilities as one immutable backend selection. Use concrete
      CDI bean types (for example `@Typed(NativeDynamoDbBackend.class)`) plus
      central selected-interface producers so native and later Local beans
      cannot become ambiguous unqualified implementations.
- [ ] Add proposed `DynamoDbNativeBackendTest`, `DynamoDbFacadeTest` and
      `DynamoDbBackendSelectionTest` in the backend test package. Use a recording
      fake for selected operations/capabilities to prove every named caller
      passes the same explicit account/region and never reaches native state
      when the fake is selected. Prove raw/typed native DeleteTable behavior
      remains distinct and that UpdateItem does not invent extra images.
- [ ] Run:

```sh
./mvnw test -Dtest=DynamoDbNativeBackendTest,DynamoDbFacadeTest,DynamoDbBackendSelectionTest,DynamoDbIntegrationTest,DynamoDbCborIntegrationTest,DynamoDbFgacEnforcementIntegrationTest,StepFunctionsDynamoDbIntegrationTest,DynamoDbStreamSpecificationCfnProvisionerTest
```

Expected: all entry paths cross the new boundary, native behavior stays
characterized, no delegation cycle, no new publicly selectable backend.
Run `make docs-sync` and `make docs-check` for the moved handler action sources.

## 36.3: Stream reader and consumer boundary

Create the following reader contract in the backend package:

```java
package io.github.hectorvent.floci.services.dynamodb.backend;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;

public interface DynamoDbStreamReader {
    enum Position {
        TRIM_HORIZON, LATEST, AT_SEQUENCE_NUMBER, AFTER_SEQUENCE_NUMBER
    }
    enum CheckpointLifetime { PROCESS, STREAM }
    record Stream(DynamoDbOperations.Scope scope, String arn) {}
    record Shard(String shardId, String parentShardId,
                 String startingSequenceNumber, String endingSequenceNumber) {}
    record ShardsPage(Stream stream, List<Shard> shards,
                      String lastEvaluatedShardId) {}
    record Cursor(Stream stream, String shardId, String token) {}
    record Record(String sequenceNumber, JsonNode awsRecord) {}
    record RecordsPage(List<Record> records, Cursor nextCursor) {}

    ShardsPage describeStream(Stream stream, String exclusiveStartShardId, Integer limit);
    Cursor getShardIterator(Stream stream, String shardId, Position position, String sequenceNumber);
    RecordsPage getRecords(Cursor cursor, int limit);
    CheckpointLifetime checkpointLifetime();
}
```

`DynamoDbApiStreamReader` parses standard Streams replies from selected
`DynamoDbOperations`; use the same parser for native and later Local.
`awsRecord` is the AWS Records[] shape with nested `dynamodb`, not the native
Java bean's serialization. Consumers add the public `eventSourceARN` to a copy.
Preserve supplied binary values, size and identity metadata without invention.

There is **no ack method** on this reader. Fetch cursor, pending batch and
consumer-committed sequence are distinct. A closed shard is complete only after
pending work is disposed; an empty page with another cursor is not closure.

- [ ] Implement the parser and response-error handling, including paged shard
      descriptions and opaque cursors. Use the account/region in `Stream`.
      Remove direct consumer dependence on native `SHARD_ID`.
- [ ] Make native stream lookup/bootstrap carry the explicit owner account.
      The existing region/table-only stream key is insufficient for the new
      scoped contract. Prove two accounts' same-named tables cannot share
      stream descriptions, records or cursors. This directly required source
      isolation repair is included here, not separately counted as the optional
      native-A hardening project.
- [ ] Adapt Lambda after 35.4. Preserve B's already-merged partial/retry behavior
      rather than implementing it again. Discover shards, process children only
      after parent completion, and renew iterators from committed progress.
      Trimming must produce an explicit loss/recovery outcome, not a silent
      restart at TRIM_HORIZON.
- [ ] Keep source reads on the existing bounded poll workers, not Vert.x timer
      callbacks. Confirm the same constraint for Pipes with a blocked reader
      fixture so adding Local later requires no consumer-threading rewrite.
- [ ] Preserve native PROCESS checkpoint lifetime: native history is volatile.
      External STREAM lifetime preserves progress across Floci restart only
      while the same source generation survives. No invented reliable database
      epoch or unconditional checkpoint clearing for every backend.
- [ ] Adapt the ordinary Pipes DynamoDB source to the same reader. Retain pending
      records after delivery failure; commit only successful target delivery or
      successful configured dead-letter disposition. Do not save the fetched
      next iterator before delivery, or let later records skip an undisposed
      earlier failure. Keep source owner scope and AWS record shape.
- [ ] Reject unsupported Pipes stream options explicitly. This task does not
      add enrichment or a complete new retry policy. The supported ordinary
      source path must be safe on both engines, not silently native in Local mode.
- [ ] Add proposed `DynamoDbApiStreamReaderTest` with multi-page descriptions,
      parent/child shards, empty/open pages, closed/pending shards, expiry,
      trimming, nondefault accounts and repeat reads. Extend existing consumer
      tests for target/DLQ failure without premature progress and default-native
      restart behavior. Run:

```sh
./mvnw test -Dtest=DynamoDbApiStreamReaderTest,DynamoDbStreamServiceTest,DynamoDbStreamsEventSourcePollerTest,PipesPollerTest,PipesPollerIntegrationTest
```

Expected: fetch and disposition never collapse into one cursor; both consumers
use the selected reader and owner scope. No Local implementation yet.

## 36.4: Runtime side effects and lifecycle

- [ ] Add `DynamoDbRuntime` as the existing emulator lifecycle's coordinator for
      selected-backend readiness, maintenance and client ownership. It is not
      a server/container manager and is not a StorageFactory storage mode.
- [ ] Make native initialization/recovery, stream reconstruction, TTL scheduling,
      Kinesis forwarding and native import/export recovery native-owned. Remove
      public eager native-engine injection that would initialize its stores
      despite another backend being selected. Other services use the facade.
- [ ] After Floci storage initialization and before persisted Lambda/Pipes
      pollers start, initialize only the selected backend and verify readiness.
      A future external selection must not create/load native table/item/import/
      export stores or reconstruct native stream buffers.
- [ ] Preflight `EmulatorInfoController` reset/nuke before its first destructive
      operation, then quiesce affected consumers, invoke existing clear hooks
      and clear stores only after preflight succeeds. Supply a denying fake
      backend in the regression; no unrelated store may be cleared on refusal.
      Native reset keeps its intended behavior and clears native process state.
- [ ] Stop consumers before final checkpoint persistence and close selected
      clients afterward. Old workers cannot write state after reset/shutdown.
      Individual AWS DeleteTable remains an ordinary authorized operation,
      distinct from emulator-wide nuke or deleting an external volume.
- [ ] Touch existing `EmulatorLifecycle.java`, `EmulatorInfoController.java`,
      `DynamoDbTtlService.java` and native cleanup hooks only as needed for the
      ownership boundary. Add proposed `DynamoDbRuntimeTest` and
      `DynamoDbBackendResetIntegrationTest`, then run:

```sh
./mvnw test -Dtest=DynamoDbRuntimeTest,DynamoDbBackendResetIntegrationTest,EmulatorLifecycleTest,EmulatorInfoControllerIntegrationTest,DynamoDbTtlForwardingTest
```

Expected: the fake non-native selection initializes no native database state;
reset refusal happens before global changes; native startup/reset still work.
Update lifecycle/configuration documentation without exposing Local selection yet.

## D handoff

C is complete when a recording non-native backend can replace operations,
typed access, inventory and stream reads through the selector without edits
to service consumers. D then adds transport, identity, ancillary tags and
configuration activation. It does not move native code again, add per-service
HTTP clients or copy the Lambda/Pipes consumers.

The selected source/configuration still carries normal implementation checks.
No tests or runtime changes are executed merely by writing this plan.
