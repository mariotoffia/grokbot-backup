# TEOS root-issue follow-ups

**Source:** TEOS root [ISSUES.md](../../../../../thiink/teos/ISSUES.md) and
[API_ENDPOINT.md](../../../../../thiink/teos/API_ENDPOINT.md), read at clean
`floci-enhanced` commit `4514f7d53` on 2026-09-18. Root issue numbers below are
section numbers, not the design register's P-/F-/W- identities.

**2026-09-21:** the root `ISSUES.md` was removed on TEOS branch
`feature/floci-test-env`. Its test-environment entries are checkboxes in TEOS
`design-in-progess/floci/TEST_PLAN.md` Tasks 10, 12, 13 and 14 and its section 9. Everything else is
owned by this ledger: the disposition table below names the task for each
entry, and "Details kept from the removed root ISSUES.md" at the end holds the
facts no task plan records.

**Goal:** Retain relevant local-integration work without importing unrelated
maintenance or reimplementing completed changes. Status is in
[Task 33](../../TEOS_GROUNDZERO_TASKS.md#task-33-teos-root-issue-follow-ups).
Every executable leaf is one TEOS PR from `main`, including its check and docs.
Conditional leaves stay unscheduled until a real consumer needs them.

## 33.1: Shared network profile, completed baseline

W-21 is now `go-core/cbnet`, installed through `ctx.OptAWSConfigLoadDefault` and
applied by `httputil.NewClient`. Commits `6d5e5e1c6` and `2fbe18710` implement and
harden it. The original token-script helper is deleted. Preserve this completed
work; the remaining callers below are new tasks, not a reopened profile design.

The profile redirects only the local base domain and its label-delimited
subdomains to `AWS_ENDPOINT_URL`. It preserves the URL, Host header, SNI and
certificate verification, adds the configured CA to system trust unless the
caller supplied an explicit pool, and bypasses proxies only for the local names.
Vendor destinations keep their original routing/proxies. Invalid local AWS
configuration fails at loading; do not replace this with success-shaped defaults.
The existing warning/fallback behavior of `httputil.NewClient` is documented by
API_ENDPOINT.md and is not a new contract silently introduced by these tasks.

## 33.2: Lambda DynamoDB Streams endpoint

**Root 1.2.** In `deployment/lib/adapters/cdk/lambda/environment.go`,
`applyDeploymentTarget` currently injects the DynamoDB endpoint but not the
separate Streams endpoint. Add `AWS_ENDPOINT_URL_DYNAMODB_STREAMS` through the
same local-target configuration, retaining explicit caller overrides and the
unchanged AWS target. No function currently consumes that client; this closes
the known endpoint-wiring omission without changing the backend.

Extend `environment_test.go` for both variables, explicit overrides and absence
on AWS. From `deployment/lib`, run
`go test -short -race -count=1 ./adapters/cdk/lambda/`.
Do not wait for the proposed Floci backend integration to fix this independent
configuration gap, or remove the existing split before its replacement is approved.

## 33.3: Building OpenAPI reference validity

**Root 3.1, W-15.** In
`go-services/buildingsvc/spec/models/buildingsvcevents/upsert-building-event.yaml`,
remove the redundant description beside `building.$ref`; its target schema
already has a description. Keep the deployment library's global validation strict.
The new `generate-api` target exists already, so do not recreate it.

Run `make generate-api` from `go-services/buildingsvc`, then the existing
deployment synthesis/validation path with `lcs-api` enabled against local
configuration. Assert the previously rejected bundled schema passes; fix a
directly related generated artifact, not a hand-edited bundle. Report any newly
exposed blocker rather than weakening the validator. Actual API execution and
IAM restoration remain separate 27.6 after the required image gates.

## 33.4: Forward the explicit groundzero force flag

**Root 3.3.** Trace `cbdeploy cfn deploy --force` through stack properties into
`deployment/stacks/groundzero/registrar.go` and its registration options.
`registerSelf` currently sets `Force: false`. Preserve rejection of a same-version
rewrite without the flag; pass only the explicit operator intent through the
existing option, never make all local registrations forced.

Add a synthesis/options regression for true/false and a disposable local
same-version registration case that fails without force and succeeds with it.
Keep AWS groundzero qualification read-only. This does not depend on 31.6's
broader update test; use the existing registrar test helpers.

## 33.5: Repository-relative service registration roots

**Root 3.4.** Fix the common producer of `RegisterMetadataOptions.ServiceRoot`
used by ordinary service stacks; groundzero already supplies
`deployment/stacks/groundzero`. Follow all callers and stored-row consumers before
changing the value. Use the existing repository root/path helpers rather than
reconstructing an absolute developer path in each stack.
Start at `deployment/lib/adapters/cdk/stack/stack.go`, its registry custom-resource
adapter and tests, and `go-services/appstore/cmd/cbdeploy/internal/cloud/sync_builder.go`
where the manifest's `ServicePath` enters `ServiceRoot`.

Assert registration rows are checkout-independent, resolve the same declared
artifacts, and do not escape the repository. Preserve or explicitly migrate
existing absolute-path records according to actual consumers. Cover two different
checkout roots, the existing groundzero value and an invalid outside-root path.
One root-cause producer/consumer PR, not a per-service stack of path patches.

## 33.6: Building Go-model generation hook

**Root 3.5.** Add the conventional `generate-code` hook to
`go-services/buildingsvc/Makefile`, reusing its existing `generate`/`gen` recipes
instead of copying generator commands. `generate-api` is already implemented
and handles the OpenAPI bundle, not these models.

Prove root `make generate` selects the model generation, and a second run is
idempotent. Preserve the completed exclusion of other worktrees under `work/`.
Keep generated changes limited to the affected model inputs. This PR is
independent of 33.3's schema correction.

## Independent HTTPS caller repairs

| Task | Root issue and files | Minimal change and required proof |
| --- | --- | --- |
| 33.7 | 2.2, Siemens sign-in: `go-services/providers/northbound/siemens/auth/auth.go` | Dropped 2026-09-21: the file no longer exists on TEOS `feature/floci-test-env` (commit `03929c083`), so there is nothing to move |
| 33.8 | 2.2, token-backed IAM client: `go-services/core/management/iam/api/client/client.go`, `FromToken` | Reuse the existing network profile beneath `bearerTransport`, preserving the constructor API where possible. Surface profile construction errors through the existing error return. Preserve bearer/API-key injection, rotation/concurrency and caller timeouts; do not remove the auth transport |
| 33.9 | 2.2, `go-services/appstore/cmd/cbdeploy/internal/auth/oauth.go` | Conditional on local browser sign-in being selected. Reuse the network profile in `newOAuthClient`, retaining its 15-second timeout and injected test client. Exercise exchange, refresh and revoke against verified local TLS; preserve production destination and OAuth errors |
| 33.10 | 2.3, direct generated IAM/AppStore callers | Audit actual constructor call sites of `go-services/core/management/iam/api/client/iam_api_gen.go` and `go-services/appstore/api/client/appstore_api_gen.go`. Pass a profile-aware client from handwritten callers. Do not hand-edit generated defaults or redirect all 33 plain HTTP clients, most of which call vendors. Record unchanged vendor call sites and test selected TEOS callers |

For each PR, add the smallest local TLS/transport regression in the owning
package, run that module's focused `go test -count=1` (and `-race` for shared
transport state), and update its local-run notes. No new routing helper or
network-profile implementation. 33.7 and 33.8 are independent; 33.9 is not a
prerequisite for today's service tests.

## 33.11: DynamoDB Local TTL capability proof

**Root 1.7.** Extend the existing DynamoDB Local integration tests under
`go-core/utils/testutils` against the pinned 3.3.1 image. Enabling/read-back of
TTL does not prove an expired item is deleted. First check the official Local
capability contract, then use an expired item with bounded observation if that
behavior is supported. Record unsupported or unobserved deletion honestly;
do not emulate deletion in the test and label it native TTL.

The source states no current local test depends on physical expiry. Retain that
boundary. Include any supported TTL stream behavior in the capability report,
without making this small test a new TTL service. The backend investigation
must consume this evidence before claiming TTL parity.

## Conditional stream-pump extensions

Root 1.4 says unsupported options currently fail loudly and no locally running
stack needs them. Preserve those guards until each corresponding PR lands.
Do not start all five simply because they are indexed. The user has now selected
the unified Floci path in Tasks 35-37, so these host-pump additions are deferred
unless an explicit interim consumer needs one before 37.6. Do not implement two
competing delivery engines.

| Task | One-PR scope | Acceptance before removing that option's rejection |
| --- | --- | --- |
| 33.12 | `FilterCriteria` | SDK-shaped record filtering, matching/nonmatching records, malformed criteria and checkpoint advancement without invoking a fully filtered batch |
| 33.13 | Nonzero `MaximumBatchingWindowInSeconds` | Bounded window, early full-batch flush, no lost records on cancellation, existing ordering and failure semantics |
| 33.14 | `ParallelizationFactor` above one | Approved per-shard/key ordering model, bounded concurrency, retries and checkpoint advancement under partial failures |
| 33.15 | Nonzero `TumblingWindowInSeconds` | Evidence-backed window state/final invocation contract, failures and cancellation; do not mistake a batching window for a tumbling window |
| 33.16 | `MaximumRecordAgeInSeconds` other than -1 | Controlled-clock expiry, retry/age interaction, failure destination and explicit discard statistics; no silent loss |

Files: existing `go-core/utils/testutils/flocilocal/ddbstreampump` parser,
mapping/delivery/pump implementation and focused tests. Each leaf includes
its own parser acceptance, runtime behavior and docs. After selecting a leaf,
run `go test -short -race -count=1 ./utils/testutils/flocilocal/ddbstreampump/`
from `go-core` and one affected deployed-service case. Until then, an unsupported
setting is a startup failure, not an outstanding bug in a supported path.
`AT_TIMESTAMP` and non-SQS failure sinks also remain explicitly unsupported;
the source names no selected consumer for them.

## 33.17: Local hostname and certificate proof

**Root 5.** Add a groundzero local check that the public names resolve as the
current deployment expects and that the profile-routed HTTPS connection verifies
the exact hostname. Reuse `cbnet`, not manual dial/CA code. Keep host resolution,
container reachability and TLS routing as separate assertions.

This can land before 31.1 because it tests the public/local routing contract,
not records inside Floci's Route 53. Do not use it to close P-24 or delete the
real record assertion. Use the existing local groundzero service-test package;
AWS stays read-only.

The login host is already covered: groundzero's local test
`TestTheTokenEndpointAnswersOnTheLoginDomain` posts to the token endpoint of
`api.auth.<account domain>` over HTTPS verified for that exact name, with the
connection routed to the emulator. The API and IoT hosts have no such check.

## 33.18: Retire the local CFN DNS-record skip

**Root 4/5, P-24.** After 31.1 is in the selected image, remove the local
skip in `deployment/stacks/groundzero/service-test/endpoints_test.go` and
assert the four CFN records through the Route 53 SDK, including actual values
and cleanup. Keep CDK's validation record distinct. A resolved hostname or
CREATE_COMPLETE is insufficient. One TEOS PR, independent of 33.17.

## 33.19: One owner for the shared audit log group

**Root 3.10, found 2026-09-21.** `NewAuditLogGroup` in
`deployment/lib/adapters/cdk/observability/auditlog.go` creates an
`AWS::Logs::LogGroup` with the fixed name `/teos/common/audit/audit-log` and a
retain policy in every service stack that has audit logging on. Audit logging
is on unless a provisioning file turns it off. The ingestion, actuation,
collector, core router, event and BuildingX stacks all reach it through
`observability.CreateAuditInfrastructure`. The second such stack in one account
fails with "The specified log group already exists", on AWS as on the emulator.
Because the group is retained after an undeploy, a redeploy fails the same way.

What a person sees: the local actuation service test deploys the ingestion
service first and then fails on its own stack. The core router test fails the
same way, because it deploys the actuation service. Both fail before tag
discovery (17.x) matters.

Create the group once, for example in groundzero, which every service already
depends on, and reference it by name from the other stacks; or give each service
its own group. Prove it by deploying two auditing services into one local
environment, and by an undeploy followed by a redeploy. Keep the per-RSID
pattern, which creates no group, unchanged.

## Complete root-issue disposition

| Root section | Disposition |
| --- | --- |
| 1.1, current split and empty Floci tables | Baseline architecture and evidence; [Task 34](../dynamodb-local/README.md) records the selected B/C/D direction, implemented through 35-37, not a claim native Floci conditional writes were newly disproved |
| 1.2, missing Lambda Streams endpoint | 33.2 |
| 1.3, service-originated writes hit the wrong database | 36.2 routes internal service callers as well as public operations; 37 supplies Local. Until 37.6 passes, keep the documented Lambda-mediated local path |
| 1.4, five unsupported pump settings | Separate conditional 33.12-33.16; keep fail-fast validation |
| 1.5, table copy is check-only and omits settings | Keep mismatch failure and metadata limits until 37.6 retires the copy; no silent schema alteration |
| 1.6, polling is not a barrier | Explicit unresolved timing boundary until unified backend adoption. 31.6 tests evidence/cleanup, not a timing guarantee. The measured timing is under "Details kept from the removed root ISSUES.md" |
| 1.7, physical TTL expiry unproven | 33.11 |
| 2.1, correct handwritten hostnames | Opportunistic cleanup only when those files change. No standalone replacement of correct strings. The file list is under "Details kept from the removed root ISSUES.md" |
| 2.2, three plain HTTP clients | Independent 33.8 and conditional 33.9. 33.7 dropped 2026-09-21: the Siemens helper no longer exists |
| 2.3, incomplete client-call inventory | Focused 33.10; leave vendor clients alone |
| 3.1, invalid building OpenAPI schema | 33.3, then existing 27.6 |
| 3.2, root benchmark target | General tooling decision outside this Floci integration scope. Since 2026-09-21 a TEOS `design-in-progess/floci/TEST_PLAN.md` Task 14 checkbox |
| 3.3, force flag lost | 33.4 |
| 3.4, absolute serviceRoot | 33.5 |
| 3.5, model generator hook | 33.6; do not recreate completed generate-api |
| 3.6, floating helper images | 32.16-32.18 done locally on TEOS `feature/floci-test-env`. 32.22 pins the retained Jena/Fuseki; the MQTT helper's `eclipse-mosquitto:2` is also unpinned |
| 3.7, false dependency-check docs | Existing 31.9 |
| 3.8, ctxoptions.go near size limit | Opportunistic unrelated maintenance only. Dropped from the registers 2026-09-21: no visible effect, and the repository's file-size rule applies on the next change |
| 3.9, lifecycle-script tests outside `go.work` | Added after this table was written. TEOS `design-in-progess/floci/TEST_PLAN.md` Task 14 |
| 3.10, shared audit log group in every auditing stack | Added 2026-09-21. 33.19, a TEOS stack defect that no Floci task can fix |
| 3.11 to 3.13, SUR and MQTT service-test configs, `cbtest local exec` empty values | Added 2026-09-21. TEOS `design-in-progess/floci/TEST_PLAN.md` Tasks 13 and 10 |
| 3.14, `make lint` skips nested modules | Added 2026-09-21. TEOS `design-in-progess/floci/TEST_PLAN.md` Task 14 |
| 3.15, two broken end-to-end tests | Added 2026-09-21. TEOS `design-in-progess/floci/TEST_PLAN.md` Task 12 |
| 4, iam-service | Existing 20.1/20.2 and 31.2-31.4, then 27.6 |
| 4, tklocal/actuation/reserved topics/metric filters | Existing 20.3-20.5, 17.x, 19.x, 6.1 and their corresponding 27.x qualification PRs |
| 4, building API | 33.3 and 27.6; retained schema/IAM blockers |
| 4, bucket cleanup | Existing 29.7 then 27.7 |
| 4, CFN DNS | 31.1 then 33.18 |
| 4, mapping properties | Existing 23.1/23.2. CFN forwarding cannot provide external-stream execution by itself |
| 5, device test | Existing 31.5 |
| 5, registration update | Existing 31.6; create/delete and dependency deployment are already proven |
| 5, local DNS substitute | 33.17 is independent transport evidence, never a substitute for 33.18's actual records |
| 5, local CI | Explicit owner decision on 2026-09-17: do not add local CI now. Revisit only if the owner changes the PR/release-gating policy. Recorded in TEOS `design-in-progess/floci/TEST_PLAN.md` section 9 |

The root register remains the owner of excluded general maintenance. This
reconciliation authorizes no source deletion. Before later removing the TEOS
design directory, preserve its unique run evidence and executable
`floci-scan.sh`, repoint external links, and put the gitignored `.vscode`
backlog in durable version control.


## Details kept from the removed root ISSUES.md

These facts from the root register are not recorded in any task plan above.

- **Root 1.3, writes made by another AWS service.** A DynamoDB action on an IoT
  rule, a Step Functions task that calls DynamoDB directly, or an API Gateway
  method integrated with DynamoDB writes into Floci's own DynamoDB, which TEOS
  code never reads. No TEOS stack uses one. Until 37.6 passes, the rule for new
  stacks is to keep a Lambda function between the service and the table, or the
  feature cannot be tested locally.
- **Root 1.5, what the table copy leaves out.** Encryption, point-in-time
  recovery, deletion protection, tags, table class and throughput are not
  copied, and the copy always bills on demand. None of them changes what a read
  or a write returns. A same-named table with other keys or indexes already on
  DynamoDB Local stops the run with an error naming the table.
- **Root 1.6, the timing the copy relies on.** The harness copies new tables
  every 250 milliseconds while a deploy runs, because groundzero's registrar
  function writes to a table the same deploy creates. Measured on 2026-09-18 on
  an arm64 Mac: the table appeared 0.14 seconds into the deploy, the registrar
  call started at 1.28 seconds and its row was written at 7.40 seconds. If the
  order ever failed, the custom resource would fail with
  `ResourceNotFoundException`, the stack would roll back, and a second run would
  pass. A slower copy, for example one that also copies rows in the same pass,
  is what would break it.
- **Looking at DynamoDB by hand.** Floci's own DynamoDB holds an empty copy of
  every table, so a DynamoDB tool pointed at Floci's port shows tables with no
  items. The data is on DynamoDB Local's port.
- **Root 2.1, TEOS hostnames written by hand.** These places format a TEOS
  address themselves. The text equals what the `go-core/cbnet` helpers return,
  and the client decides where a connection goes, so they work on both targets.
  Move them only when a file changes for another reason. Code that sends
  requests: `go-core/utils/httputil/httpauth/teos_api.go`,
  `go-services/clients/ssm/api.go`, `go-services/clients/healthsummary/api.go`,
  `go-services/core/management/iam/api/client/client.go`,
  `go-services/providers/eastbound/sur/api/client/client.go`,
  `go-services/buildingsvc/export/client/apiclient/client.go` and
  `go-services/tklocal/geo/query.go`. Code that only names an address: the
  `stack_part2.go` of the SMA and Siemens providers, `stack_restapi_part2.go`
  of the SUR provider, `stack_admin_api.go` of the tklocal provider, and
  `cmd/cbclean/main.go`.
- **Root section 4, who else needs tag discovery.** Besides the actuation
  service, `cbapi`, `cbiam`, the licence key lookup and the function that
  removes old API keys look API keys up by tag. They get empty answers locally
  until 17.1 and 17.5 land.
