# Task plans: setup and the shared checklist

Index of the tasks, their state and their PRs: [TEOS_GROUNDZERO_TASKS.md](../TEOS_GROUNDZERO_TASKS.md).
Each `task<N>/README.md` here is the full text of one task with its checkboxes; `task7/` also
carries one implementation plan per PR. Design: [TEOS_GROUNDZERO_DESIGN.md](../TEOS_GROUNDZERO_DESIGN.md).
Reasons and evidence: [TEOS_GROUNDZERO_ANALYSIS.md](../TEOS_GROUNDZERO_ANALYSIS.md).

Task 6 uses a single status source: its checkboxes live only in `TEOS_GROUNDZERO_TASKS.md`.
The files under `task6/` contain design, evidence boundaries and navigation, not another task ledger.

## Reconciled plans

| Plan | Scope |
| --- | --- |
| [Source reconciliation](reconciliation/README.md) | Both TEOS sources, divergence evidence, exclusions and requirement ownership |
| [Runtime fidelity](runtime-fidelity/README.md) | Task 8.2 and Tasks 15-24, including split discovery/authorizer/mapping PRs |
| [TEOS adoption](teos-adoption/README.md) | Task 27, one TEOS-owned qualification or workaround-removal PR per leaf |
| [Pump reliability](pump-reliability/README.md) | Task 28, new reliability deltas on the delivered DynamoDB Local pump |
| [Additional compatibility](additional-compatibility/README.md) | Task 29, omitted issue-register gaps and newly numbered corrections |
| [Deferred compatibility](deferred-compatibility/README.md) | Task 30, explicit conditional scope with the working local path retained |
| [Groundzero checkpoint follow-ups](groundzero-follow-ups/README.md) | Task 31, fresh IDs for remaining work after the locally completed checkpoint |
| [Legacy driver migration](test-driver-migration/README.md) | Task 32, outstanding caller migrations, safe deletions and actual shared Docker helpers |
| [TEOS root issues](teos-root-issues/README.md) | Task 33, root-register integration deltas, completed network-profile baseline and explicit exclusions |
| [DynamoDB selected direction](dynamodb-local/README.md) | Task 34, B/C/D selected with multi-account/region isolation and no Local lifecycle automation |
| [Native DynamoDB Streams](dynamodb-streams/README.md) | Task 35, native delivery PRs independent of the external backend; 6-11 days including the relevant 23.1 share |
| [DynamoDB backend preparation](dynamodb-backend/README.md) | Task 36, native-only operation/source/lifecycle boundaries; 8-14 days |
| [DynamoDB Local adapter](dynamodb-local/IMPLEMENTATION.md) | Task 37, externally owned Local adapter, paired TEOS helper and adoption; 10-19 days |
| [TEOS paired lifecycle](dynamodb-local/TEOS_LIFECYCLE.md) | Task 37.7, opt-in companion tied to the Floci helper; lands before adoption 37.6 |
| [Lambda debug attach](lambda-debug-attach/README.md) | Task 38, IDE process as the Lambda runtime on any trigger, VS Code extension and `cbtest` runtime tagging; 6.5-10.5 days |
| [Cancelled SQS long polls](sqs-cancelled-long-poll/README.md) | Task 39.13, measure Amazon SQS first, then end a long poll whose client has gone; TEOS marker removal |
| [Greedy path parameter below a path parameter](apigateway-nested-greedy-path/README.md) | Task 44.7, route `/{a}/{b+}` REST API resources and fill both path parameters; measure AWS first; TEOS removal 27.33 |

## PR boundaries for outstanding work

Each numbered executable leaf in the task index is one PR in its owning repository.
A parent task groups leaves; it is not another PR. Acceptance bullets and implementation
steps belong to that leaf's PR, not separate test-only stacks.

Start each PR from its repository's current `main`. Where a prerequisite is genuinely
required, wait for it to merge, then start from the new `main`. Do not stack PRs merely
to share fixtures or start earlier. An image qualification dependency is not a source
dependency: a TEOS test can land independently with an explicit capability gate, but
must not claim a skipped scenario passed. Already-open historical stacks remain recorded.

Completed tasks stay completed. Any newly required behavior or correction to delivered
work gets a new task ID, linked to the original. Old source plans are evidence, not
instructions to redo shipped work. Recheck the implementation and selected image before
starting, since this backlog is not a live upstream status feed.
`🟢L` means implementation/run evidence exists locally, not that its PR merged.
Deliver each such leaf's existing implementation in its own PR; its consumers
still wait for that PR to merge into `main`. Do not rebuild a checkpoint to make
it fit a task, or treat its combined local history as a mandate for a PR stack.
The 2026-09-18 sync reads clean TEOS `floci-enhanced` at `4514f7d53`, including
project-root `ISSUES.md`. Source completion is not blanket completion of the
backlog. Groundzero AWS checks are read-only; mutating lifecycle proof belongs
to disposable local stacks. Preserve the `env` column when adding PR units.

## Before any task

- [ ] With permission to update refs, fetch the owning repository's current `main`
      (`upstream = https://github.com/floci-io/floci.git` for Floci) and create the
      task branch from it. Never rebase, reset or stash a user's dirty checkout to
      prepare a task. Confirm required predecessors are merged, not just open.
- [ ] Get the CloudFormation registry schemas the tests read from
      `local/aws/cfn-resource-schemas/us-east-1/` (gitignored). `CfnSchemaCoverageTest` skips
      without them, so run it once with them present. The attribute names in each task below
      come from the schema's `readOnlyProperties`; check them there before trusting this file.
- [ ] Baseline: `./mvnw test -Dtest=CfnResourceInventoryTest` green.
- [ ] Build an image once to know the build works: `docker build -f docker/Dockerfile -t floci-teos:dev .`

## The checklist every provisioner task ends with

- [ ] Class `services/cloudformation/provisioners/<Service>CfnProvisioner.java`, `@ApplicationScoped`, injects only its service.
- [ ] `resourceTypes()`; `provision()` sets the physical id **and** every `Fn::GetAtt` attribute; handles `ctx.isUpdate()`.
- [ ] `delete()` tolerates "already gone" through `CfnDeletes.safeDelete`.
- [ ] Row in `src/test/resources/cloudformation/supported-resource-types.tsv`.
- [ ] `CfnProvisionerFixture`: field, builder setter, `inferredProvisioners()` arm.
- [ ] Unit test asserting the attribute keys (copy `SqsCfnProvisioner`'s test); integration test.
- [ ] `make docs-sync`, commit the generated table.
- [ ] Unset attributes recorded in `getatt-attribute-gaps.tsv` with a reason.
- [ ] `./mvnw test -Dtest=CfnResourceInventoryTest,CfnProvisionerFixtureTest,<YourTest>`.
- [ ] Rebuild `floci-teos:dev`, run the TEOS service test against it (section 5 of the design), confirm the stub check no longer names the type.
- [ ] PR targets `main`, identifies its task ID and source requirements, and contains
      its implementation, focused compatibility coverage and documentation together.
      No new stack without an explicit maintainer decision.
