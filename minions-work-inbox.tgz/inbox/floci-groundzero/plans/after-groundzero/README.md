# After groundzero deploys (TEOS side, not Floci)

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

**Synced 2026-09-18.** This is historical context, not another executable
checklist. The remaining work is split into one PR per leaf in the
[TEOS adoption plan](../teos-adoption/README.md) and
[checkpoint follow-ups](../groundzero-follow-ups/README.md). Existing image,
host TLS, groundzero create/delete, mirror and pump implementation is retained.

**Original 2026-09-08 context.** The local DNS configuration already selects
`localhost.floci.io` without a delegation role. Do not build it again.
The token probe now uses the shared `cbnet` profile while verifying its
exact custom hostname with the run-scoped CA. Keep that real HTTPS request.
The older host-443 recommendation was rejected because parallel runs collide;
do not reintroduce it or an OS-wide trust installation.

The full current checklist is the
[TEOS section of the task index](../../TEOS_GROUNDZERO_TASKS.md#after-groundzero-deploys-teos-side-not-floci).
The main/image distinction and actual commands are in
[TEOS's current run plan](../../../../../thiink/teos/design-in-progess/floci/PLAN.md#current-run-plan-2026-09-17).

| Old requirement | Executable owner |
| --- | --- |
| Image selection/pin | Recorded done; additional release-contract cases 27.1 |
| Host TLS and Cognito trust | Recorded done, 27.2; remaining devices 31.5 |
| Groundzero service test and create/delete | Recorded done, 27.3; real CFN DNS 31.1 |
| Deployment-time metadata copy | Recorded done, 27.4; registrar update/cleanup 31.6 |
| Registrar omission, `ignoreDeps`, `--disable-auto-resolve` | Recorded done, 27.5, PLAN 6.9 |
| Building IAM registration and LCS API | 27.6 after schema repair 33.3 and missing IAM resources |
| CDK bucket auto-delete | 27.7 |
| Observability stubs | Dashboard/event-invoke removal done; MetricFilter remains 27.8 |
| Retained data, SSM trigger, tag discovery and ECR cleanup | 27.9-27.12 |
| Nil-safe device metadata and indexing readiness | 27.13-27.14 |
| Obsolete private native-build patch | 27.15 |
| Selected-service qualification and honest skips | Separate PRs 27.16.1-27.16.6 |
| Conditional SQS fixture cleanup | 27.17 |
| Marker removals: IoT merge, Logs messages, fleet search, shadow metadata | 27.18-27.21 |
| DDB image pin and record-age/failure-queue guards | Recorded done, 28.1-28.3; residual checks 31.7 |
| Copied/inherited account-domain safety config | Recorded done, 31.8 |
| Shared network routing/trust | Recorded done, 33.1; remaining plain-client call sites 33.7-33.10 |

P-9 remains open for authorizers, F-12 for reserved-topic delivery and F-5 for
asynchronous Lambda behavior. Keep DynamoDB Local and the pump until their
separate parity gates pass; retained containers do not keep a host pump alive.
