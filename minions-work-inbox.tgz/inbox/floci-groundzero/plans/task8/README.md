# Task 8: API Gateway custom domain provisioners (blocks groundzero)

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

Branch `feat/apigateway-cfn-domain`. Title `feat(apigateway): provision AWS::ApiGateway::DomainName and BasePathMapping`. Done: merged as #3040 on 2026-09-05 (Greptile 5/5, CI green). Found by reading TEOS after this file was written (ISSUES.md P-5); independent of Tasks 1 to 3 in code, groundzero needs all four.

- [x] groundzero's `api.<acct>` is an `AWS::ApiGateway::DomainName` (`domain.go` line 163) and every service REST API with a domain adds an `AWS::ApiGateway::BasePathMapping` (`gateway_builder.go` lines 134-150). Both are stubs today and the harness stub check does not tolerate them.
- [x] `ApiGatewayDomainCfnProvisioner`: `DomainName` (physical id = the domain; attributes `RegionalDomainName`, `RegionalHostedZoneId`, `DistributionDomainName`, `DistributionHostedZoneId` from the stored `CustomDomain`; replacement on domain change) and `BasePathMapping` (physical id `<domain>|<basePath>`: CloudFormation joins a compound primary identifier with `|`, not `/` as first written here; `(none)` for an empty path). `UsagePlan`, `ApiKey`, `UsagePlanKey` in a follow-up PR. The API exists: `ApiGatewayService`, `CustomDomain`, `BasePathMapping`, and `ApiGatewayCustomDomainFilter` already routes by `Host`.
- [x] Legacy `AWS::ApiGateway::*` arms stay untouched.
- [x] Checklist in [../README.md](../README.md). Analysis section 11.1.
