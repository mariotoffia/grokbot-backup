# Task 40 implementation plan

**Goal:** Close seven gaps TEOS found on 2026-10-02: five in CloudFormation and
DynamoDB, two in the Cognito OAuth endpoints. Each makes Floci answer the way AWS
does, so a TEOS test can drop its local skip.

**Architecture:** One Floci PR per leaf, based on upstream `main`, each with an
issue and a draft PR. Every fix goes into the one place all callers already go
through: the provisioner that owns the resource type, the stack engine's own
loop, the DynamoDB backend that answers the wire call, or the shared Cognito
service method. No new framework, no new storage engine.

**Tech stack:** Floci Java/Quarkus, the existing REST Assured and AWS SDK tests,
DynamoDB Local 3.3.1 for 40.5, and TEOS Go for the marker removals (27.22,
27.23, 27.24).

Status: [Task 40](../../TEOS_GROUNDZERO_TASKS.md#task-40-cloudformation-and-dynamodb-local-gaps-found-by-teos-on-2026-10-02).
`SRC` means `src/main/java/io/github/hectorvent/floci`; `TEST` means
`src/test/java/io/github/hectorvent/floci`. Other paths start at the owning
repository root. Recorded 2026-10-02.

## Source revisions and what was measured

Line numbers are on upstream `main` `c800cc375` (2026-10-02), the base every PR
starts from. The first survey read local `main` `ea0689698`, which is 48 commits
older. In between, floci-io/floci#4442 (`60985b9a8`, "skip unchanged resources
during updates") rewrote the update loop in `CloudFormationService.java`, and
floci-io/floci#4771 changed how Cognito OAuth tokens get their scopes. Where a
number differs between the two revisions, both are given.

Probes run on 2026-10-02 against a throwaway `mariotoffia/floci:latest`
container (version `20261002`) with the AWS CLI, removed afterwards:

- A stack table with `TimeToLiveSpecification` `{AttributeName: exp, Enabled: true}`
  reaches `CREATE_COMPLETE`, and `DescribeTimeToLive` answers `DISABLED` (40.1).
- An `UpdateStack` that adds a queue reports `UPDATE_IN_PROGRESS` and
  `UPDATE_COMPLETE` for it, and `DescribeStackResource` stores `UPDATE_COMPLETE` (40.3).
- A stack left in `UPDATE_ROLLBACK_FAILED` accepts `UpdateStack` and ends
  `UPDATE_COMPLETE`. `ContinueUpdateRollback` answers `UnknownAction`
  "Action ContinueUpdateRollback is not supported." (40.4).
- An update that changes nothing in a queue and a table, and adds a bucket that
  fails, ends `UPDATE_ROLLBACK_COMPLETE`: since #4442 an unchanged resource is
  not provisioned again, so it owes no rollback. Only resources the update
  really changed reach the rollback walker. This matters for 40.2: the TEOS
  groundzero rollback only needs the changed custom resource to roll back.

A throwaway `amazon/dynamodb-local:3.3.1` container, with a streamed table and
time-to-live (TTL) on attribute `exp`, answered as follows (40.1 and 40.5):

- A second `UpdateTimeToLive` with the same attribute: `ValidationException`
  "TimeToLive is already enabled".
- `UpdateTimeToLive` with another attribute while enabled: `ValidationException`
  "TimeToLive is active on a different AttributeName".
- An expired item was deleted within 15 seconds. Its stream record, read raw with
  `get-records`, has `"eventName": "UNKNOWN_TO_SDK_VERSION"` as a literal string,
  an `OldImage`, no `NewImage` and no `userIdentity`. DynamoDB Local writes that
  string itself; it is not something an SDK maps.

Not measured on AWS (no AWS run in this planning step): the exact error texts
listed under each leaf's open questions. Capture them in the PR, in the TEOS
devlocal account in eu-west-1 as earlier tasks did, before pinning a message.

## 40.1: Table time-to-live in CloudFormation

**What a person sees.** A template declares `TimeToLiveSpecification` on an
`AWS::DynamoDB::Table`. The stack reaches `CREATE_COMPLETE`, but
`DescribeTimeToLive` answers `DISABLED` and expired items are never removed.
TEOS groundzero's service test skips its registry-table TTL check locally for
this reason (marker `DynamoDB TimeToLiveSpecification in CloudFormation` in
`deployment/stacks/groundzero/service-test/deployment_test.go:266`).

**Evidence.**

- `SRC/services/cloudformation/provisioners/DynamoDbCfnProvisioner.java`
  `provisionTable` (104-243) serves create and update alike. It reconciles `Tags`
  (196-203) and `StreamSpecification` (214-222), and never reads
  `TimeToLiveSpecification`. The class has no `rollbackUpdate`, so a changed
  table in a failed update ends the stack in `UPDATE_ROLLBACK_FAILED` with
  "Rollback is not implemented for AWS::DynamoDB::Table" (walker in
  `CloudFormationService.java` 2017-2086, message at 2066).
- `SRC/services/dynamodb/backend/DynamoDbTableAccess.java` (the typed table
  operations the provisioner uses) has `enableStream`/`disableStream` but no TTL
  method. The raw path `DynamoDbOperations.execute(new Call(scope, Api.DYNAMODB,
  "UpdateTimeToLive", body))` reaches both engines: `NativeDynamoDbBackend.execute`
  (93-98) and `DynamoDbLocalBackend.execute` (116-174), which forwards any action
  it does not serve itself.
- The native engine accepts what AWS and DynamoDB Local refuse:
  `DynamoDbService.updateTimeToLive` (2672-2681) overwrites the attribute and
  flag with no "already enabled" or "different AttributeName" check.
- AWS rules, from the API and CloudFormation references: a TTL change can take up
  to one hour, and another `UpdateTimeToLive` on the table within that hour is a
  `ValidationException`. The CloudFormation property says "To update this
  property, you must first disable TTL and then enable TTL with the new attribute
  name", and `AttributeName` is required when enabling.
- Related plans: `plans/dynamodb-local/IMPLEMENTATION.md:211` (forward TTL to
  Local and report its real state) and `plans/dynamodb-local/RESEARCH.md:204`
  and `:403` (the provisioner omits TTL; TTL configuration ownership).

**Fix.**

1. Add two methods to `DynamoDbTableAccess`, next to `enableStream`:
   `timeToLive(Scope, tableName)` returning the enabled flag and attribute name,
   and `updateTimeToLive(Scope, tableName, attributeName, enabled)`.
   - `NativeDynamoDbBackend`: read `TableDefinition.isTtlEnabled()` and
     `getTtlAttributeName()` from `describeTable`, and call
     `DynamoDbService.updateTimeToLive`, both under `RequestScopes` like
     `enableStream` (186-190).
   - `DynamoDbLocalBackend`: `call(scope, "DescribeTimeToLive", ...)` and
     `call(scope, "UpdateTimeToLive", ...)`, like `updateStream` (450-457).
   - `TEST/services/dynamodb/backend/RecordingDynamoDbBackend.java`: record both.
   Why not the raw `DynamoDbOperations` path: the provisioner tests build
   `NativeDynamoDbBackend` with no JSON handler (`DynamoDbCfnProvisionerTest`
   line 49, `CfnProvisionerFixture` line 277), so `execute` would fail there,
   and the typed methods are how stream settings already work.
2. In `provisionTable`, after the stream block, reconcile TTL against what the
   table reports now, so a call is made only when something differs:
   - Declared enabled, table disabled: enable with the declared attribute.
   - Declared enabled, table enabled on the same attribute: nothing.
   - Declared enabled, table enabled on another attribute: fail the resource
     with `ValidationException` "TimeToLive is active on a different
     AttributeName" (DynamoDB Local's text; replace it with the AWS
     CloudFormation status reason once captured). This follows the
     CloudFormation rule that a rename is disable first, enable in a later
     update.
   - Declared enabled with no `AttributeName`: fail with `ValidationError`.
   - Declared `Enabled: false`, or the block removed on an update, while the
     table is enabled: disable, sending the current attribute name. Removing the
     block means "off", as the provisioner already treats a removed
     `StreamSpecification`.
   - Resolve `Enabled` through the template engine; it may arrive as the string
     `"true"`.
3. Rollback. Because an update now changes TTL as well as tags and the stream,
   give the table the snapshot every other in-place provisioner uses:
   - Add `DYNAMODB_TABLE_UPDATE_SNAPSHOT_ATTR` to `CfnRollback`.
   - On an update (`ctx.isUpdate()`), before the first mutating call, record the
     table's tags, stream state and view type, and TTL state and attribute.
   - Implement `rollbackUpdate` to put all three back and then drop the
     snapshot. Leave the snapshot in place when the restore throws, as
     `CloudWatchDashboardCfnProvisioner.rollbackUpdate` does.
   - Drop a stale snapshot at the start of `provision`.
   - Restoring only TTL would report a rollback while tags or the stream stayed
     changed, so all three go in, or none.

**Do not.**

- Do not add a TTL sweeper for the Local engine, and do not claim expiry from an
  accepted setting (`IMPLEMENTATION.md:211`).
- Do not emulate the one-hour limit. Neither engine's API has it today, and a
  rollback within the hour would then always fail.
- Do not fix the native API's missing "already enabled" check here. That is a
  separate DynamoDB API fix; the provisioner compares before it calls, so it
  behaves the same on both engines either way.

**Acceptance.**

- `TEST/services/cloudformation/provisioners/DynamoDbCfnProvisionerTest`:
  - create with TTL calls `updateTimeToLive` once;
  - an update with the same TTL makes no TTL call;
  - `Enabled: false` and a removed block disable it;
  - a renamed attribute while enabled fails the resource;
  - `rollbackUpdate` restores tags, stream and TTL.
- New `TEST/services/cloudformation/CloudFormationDynamoDbTimeToLiveIntegrationTest`
  (REST Assured, like `CloudFormationDynamoDbGlobalTableIntegrationTest`):
  - `DescribeTimeToLive` after create, after a disabling update and after the
    block is removed;
  - an update that changes TTL and then fails on a later resource ends
    `UPDATE_ROLLBACK_COMPLETE` with the old TTL back.
- `TEST/services/dynamodb/backend/DynamoDbLocalBackendTest` and
  `DynamoDbNativeBackendTest`: the two new methods send and read the right
  calls.
- With `FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT` set,
  `DynamoDbLocalBackendIntegrationTest` gains one case: the TTL a stack enables
  is what Local's `DescribeTimeToLive` reports.
- TEOS 27.22: groundzero's registry-table TTL check runs locally and passes.

**Commands.**
`./mvnw test -Dtest='DynamoDbCfnProvisionerTest,CloudFormationDynamoDbTimeToLiveIntegrationTest,DynamoDbLocalBackendTest,DynamoDbNativeBackendTest,CfnProvisionerFixtureTest'`.
Update the `AWS::DynamoDB::Table` notes in `docs/services/cloudformation.md`,
then `make docs-sync` and `make docs-check`.

## 40.2: Roll back a changed custom resource

**What a person sees.** An update changes a custom resource's properties, the
handler applies the change, and a later resource fails. AWS sends the handler a
second `Update` with the old properties so it can undo the change. Floci sends
nothing. The stack event says "Rollback is not implemented for
AWS::CloudFormation::CustomResource" (or the `Custom::*` type), and the stack
ends `UPDATE_ROLLBACK_FAILED` while the handler's side effect stays applied.
TEOS skips its groundzero "forced change is put back" step for this reason
(marker `custom resource rollback in CloudFormation` in
`deployment/stacks/groundzero/service-test/update_registration_test.go:145`).

**Evidence.**

- `SRC/services/cloudformation/CloudFormationService.java` `rollbackUpdatedResources`
  (2017-2086; 1741-1822 at `ea0689698`) calls `dispatcher.rollbackUpdate` for
  each changed resource. When that returns false and the status starts with
  `UPDATE_`, it records "Rollback is not implemented for <type>" (2066; 1790 at
  `ea0689698`).
- `SRC/services/cloudformation/provisioners/CustomResourceCfnProvisioner.java`:
  - `provision` (76-150) reads the stashed old properties (108);
  - it skips the call when nothing changed (116-118);
  - after a successful `Update` it overwrites the stash
    `__FlociServiceToken`/`__FlociResourceProperties` with the new values
    (147-149);
  - it does not override `rollbackUpdate(StackResource)`, so the default answers
    false.
- The hook receives only the current resource. The dispatcher hands each
  provision a fresh copy with copied attributes (`CfnResourceDispatcher.provision`
  74-118), and the walker calls the hook on that copy. The previous resource is
  not passed to it, so the old properties must be kept on the copy before they
  are overwritten.
- The snapshot-attribute pattern: `CfnRollback` constants such as
  `DASHBOARD_UPDATE_SNAPSHOT_ATTR`, written before the first mutation and spent
  by `rollbackUpdate` (`CloudWatchDashboardCfnProvisioner` 65, 167-179, 224-249).
- The handler call `invokeCustomResourceHandler` (192-236) blocks on a
  synchronous Lambda invoke, then waits `CR_RESPONSE_TIMEOUT` (10 seconds, line
  53) for the response `PUT`. `CustomResourceResponseStore` extends that wait for
  the CDK provider framework.
- AWS behaviour (CDK custom-resources guide): "If an Update event fails,
  CloudFormation will issue an additional Update with the previous properties."
  A response with a different `PhysicalResourceId` is a replacement, and
  CloudFormation then sends a `Delete` for the other id. When an update that
  replaced the resource rolls back, CloudFormation sends the `Delete` for the new
  id.
- floci-io/floci#4861 (row 39.16, open) changes `invokeCustomResourceHandler` to
  take the real stack id and stashes it as `__FlociStackId`.

**Fix.** All in `CustomResourceCfnProvisioner`, plus one constant in `CfnRollback`.

1. Add `CUSTOM_RESOURCE_UPDATE_SNAPSHOT_ATTR` to `CfnRollback`. In `provision`,
   drop a stale snapshot first. Then, on an `Update` that will call the handler
   (after the unchanged check at 116), write the snapshot before the invoke. It
   holds:
   - the prior physical id;
   - the old properties (the stash read at 108);
   - the region;
   - the non-`__Floci` attributes the resource had, which are the old `Data`
     values.
2. Override `rollbackUpdate(StackResource, Consumer<StackEvent>)`:
   - No snapshot: return true. Nothing was sent to the handler.
   - The physical id changed in the forward update (the handler replaced the
     resource): send `Delete` for the current id with the current properties,
     best effort like `delete()` (152-173). Then point the resource back at the
     prior id, with the old properties stash and old attributes. Send no
     `Update`.
   - Otherwise, report `UPDATE_IN_PROGRESS` through the progress consumer. Then
     send `Update` with `PhysicalResourceId` set to the current id,
     `ResourceProperties` set to the old properties and `OldResourceProperties`
     set to the current stash. Use the stashed service token and stack id.
   - A response other than `SUCCESS` throws with the handler's `Reason`. The
     walker then records `UPDATE_FAILED` with that reason, and the stack ends
     `UPDATE_ROLLBACK_FAILED`, as on AWS. Keep the snapshot so a later attempt
     can retry.
   - On `SUCCESS`, put the old properties back in the stash, replace the
     non-`__Floci` attributes with the response's `Data`, and drop the snapshot.
   - If the response names a different physical id, take it and send a best
     effort `Delete` for the id that was sent, with the properties it held.
     Floci has no rollback cleanup phase, so this `Delete` runs at once rather
     than in `UPDATE_ROLLBACK_COMPLETE_CLEANUP_IN_PROGRESS`.
3. Reuse `invokeCustomResourceHandler` unchanged. The 10-second response wait
   and the provider-framework wait apply as they do to a forward `Update`.
4. Base the PR on `main` after floci-io/floci#4861 merges, so the rollback
   request sends the stashed `__FlociStackId`. If it has not merged, send the
   id the same way the forward call does and rebase later.

**Do not.**

- Do not move rollback into `CloudFormationService`, and do not hand the hook the
  previous resource. The snapshot keeps the change inside the provisioner, like
  every other type.
- Do not retry a `FAILED` rollback response, and do not treat it as success.
- Do not add the missing success-path cleanup here. Today a forward `Update`
  that returns a new physical id never gets a `Delete` for the old id after the
  update commits. That is a separate gap; record it as a follow-up.

**Acceptance.**

- `TEST/services/cloudformation/CustomResourceProvisionerTest` (stubbed
  `LambdaService` and `CustomResourceResponseStore`, as in `stubHandler`):
  - the snapshot is written before the invoke;
  - `rollbackUpdate` sends `Update` with the two property sets swapped and the
    same physical id, and restores stash and attributes;
  - a `FAILED` answer throws and keeps the snapshot;
  - a replaced resource gets a `Delete` for the new id and no `Update`;
  - unchanged properties need no rollback call.
- New `TEST/services/cloudformation/CloudFormationCustomResourceRollbackIntegrationTest`
  (`@QuarkusTest` with `LambdaService` mocked to `PUT` responses):
  - change the custom resource and add an `AWS::S3::Bucket` named
    `bad/name` with `DependsOn` on it;
  - the stack ends `UPDATE_ROLLBACK_COMPLETE`;
  - the handler saw `Update(new)`, then `Update(old)`;
  - `DescribeStackResource` keeps the physical id;
  - no event says "Rollback is not implemented";
  - a handler that answers `FAILED` on the rollback leaves
    `UPDATE_ROLLBACK_FAILED` with its reason.
- TEOS 27.23: the groundzero step "a forced change is put back when a later
  resource fails" runs locally and passes. It is the first local proof of the
  registrar's rollback restore.

**Commands.**
`./mvnw test -Dtest='CustomResourceProvisionerTest,CloudFormationCustomResourceRollbackIntegrationTest,CustomResourceProviderFrameworkTest,CloudFormationServiceRollbackTest'`.
Update the custom-resource section of `docs/services/cloudformation.md`, then
`make docs-sync` and `make docs-check`.

## 40.3: Create events for a resource an update adds

**What a person sees.** An `UpdateStack` adds a new resource. AWS reports
`CREATE_IN_PROGRESS` and `CREATE_COMPLETE` (or `CREATE_FAILED`) for it, and
`DescribeStackResource` shows `CREATE_COMPLETE`. Floci reports `UPDATE_*`. A tool
that waits for the create events of a new resource, or counts creates in a
deploy, sees the wrong thing. No TEOS test depends on it.

**Evidence.** `SRC/services/cloudformation/CloudFormationService.java`
`executeTemplate` (1406 on, 1239 at `ea0689698`):

- The in-progress event uses the stack-wide `isCreate` (1505-1514; 1323-1332 at
  `ea0689698`).
- Every resource's `CREATE_COMPLETE`/`CREATE_FAILED` becomes
  `UPDATE_COMPLETE`/`UPDATE_FAILED` when the stack operation is an update
  (1529-1535; 1347-1353 at `ea0689698`).
- The loop already knows whether the stack held the resource:
  `previousResource` is null for a new logical id (1487-1488).
- Nested stacks: `executeNestedStack` (2769) already decides per resource for
  the child stack's own events (`childCreate`, 2788-2789). The parent's event for
  the `AWS::CloudFormation::Stack` resource goes through the same two places as
  any other resource.

**Fix.** In the loop, compute `boolean creating = isCreate || previousResource == null`.
Use it for the in-progress status, and apply the `CREATE_*`-to-`UPDATE_*`
mapping only when `!creating`. A resource whose condition turned true, so it
was never deployed before, counts as created too, which is what AWS does. The
rollback of an added resource is unchanged: the walker's `previous == null`
branch deletes it and reports `DELETE_*`.

**Do not.** Do not change the stack-level statuses (`UPDATE_IN_PROGRESS` and the
rest). Do not touch `executeNestedStack`.

**Acceptance.** Add a case to
`TEST/services/cloudformation/CfnUnchangedResourceUpdateIntegrationTest`. An
update that adds a queue gives that queue only `CREATE_IN_PROGRESS` and
`CREATE_COMPLETE` events, and `DescribeStackResource` shows `CREATE_COMPLETE`.
An added resource that fails reports `CREATE_FAILED`, and the stack still rolls
back to `UPDATE_ROLLBACK_COMPLETE`. A nested stack added by an update reports
`CREATE_*` for the parent's resource. Search the existing tests for assertions
that expect `UPDATE_*` on an added resource and correct them.

**Commands.**
`./mvnw test -Dtest='CfnUnchangedResourceUpdateIntegrationTest,CloudFormationIntegrationTest,CloudFormationRollbackCompleteUpdateIntegrationTest'`.
No docs change unless `docs/services/cloudformation.md` describes update events.

## 40.4: Refuse updates after a failed rollback, and ContinueUpdateRollback

**What a person sees.** A stack whose update rollback failed is in
`UPDATE_ROLLBACK_FAILED`. AWS refuses `UpdateStack` there. The way out is
`ContinueUpdateRollback`, optionally skipping the resources that cannot roll
back, or `DeleteStack`. Floci accepts the update and builds on resources in an
unknown state, and it has no `ContinueUpdateRollback` (the probe got
`UnknownAction`). A CDK or CLI deploy that works on Floci fails on AWS, and the
recovery path cannot be tested locally.

**Evidence.**

- `SRC/services/cloudformation/CloudFormationService.java` `refusesUpdate`
  (240-243; 239-242 at `ea0689698`) refuses only `*_IN_PROGRESS` and
  `ROLLBACK_COMPLETE`. `createChangeSet` (378) raises the refusal as
  `ValidationError` "Stack:<arn> is in <status> state and can not be updated.",
  so `UpdateStack` and `CreateChangeSet` both use it.
- `SRC/services/cloudformation/StackSetService.java` (238) uses `refusesUpdate`
  to mark an instance `INOPERABLE` instead of updating it.
- `SRC/services/cloudformation/CloudFormationQueryHandler.java` dispatches
  actions at 50-85. There is no `ContinueUpdateRollback`; the default arm
  answers `UnknownAction` (85).
- `rollbackFailedUpdate` (1962 on) and the walker `rollbackUpdatedResources`
  (2017-2086) take the pre-update `StackUpdateSnapshot` (record at 2164) and the
  attempted logical ids. Both live only for the one `executeTemplate` call. On
  failure the stack keeps the failed template, restores only its parameters,
  and marks the resources that could not roll back `UPDATE_FAILED`.
- A provisioner keeps its own snapshot when its restore throws (for example
  `CloudWatchDashboardCfnProvisioner.rollbackUpdate`), so calling the walker
  again is a real retry.
- AWS (`ContinueUpdateRollback` API reference):
  - it only works from `UPDATE_ROLLBACK_FAILED`;
  - `ResourcesToSkip` may name only resources in `UPDATE_FAILED` because their
    rollback failed;
  - skipped resources are set to `UPDATE_COMPLETE`;
  - a nested resource is named `NestedStackName.ResourceLogicalID`;
  - the response is an empty `ContinueUpdateRollbackResponse`.

**Fix.**

1. Add `UPDATE_ROLLBACK_FAILED` to `refusesUpdate`, matched exactly like
   `ROLLBACK_COMPLETE`. The existing message format should be AWS's. Capture
   the AWS text for both `UpdateStack` and `CreateChangeSet` in the PR and pin
   it. `DeleteStack` stays allowed. The StackSet path follows automatically: the
   instance becomes `INOPERABLE`.
2. Keep what the walker needs after the call returns. When `rollbackFailedUpdate`
   ends in `UPDATE_ROLLBACK_FAILED`, store on the `Stack` the pre-update
   snapshot. That is the template bodies, outputs, exports, export names, and the
   previous resources keyed by logical id, all types the stack already persists.
   Also store the logical ids still owed a rollback. Clear both when a rollback
   completes and when the stack is deleted.
3. Split the tail of `rollbackFailedUpdate` (restore template and outputs, then
   set `UPDATE_ROLLBACK_COMPLETE` or `UPDATE_ROLLBACK_FAILED`) into one method
   that both callers use.
4. Add `ContinueUpdateRollback`:
   - The handler case reads `StackName` (a name or id) and
     `ResourcesToSkip.member.N`, and answers an empty
     `ContinueUpdateRollbackResponse`.
   - The service method refuses unless the stack is `UPDATE_ROLLBACK_FAILED`.
   - It refuses a skip that is not an `UPDATE_FAILED` resource of this stack,
     and a dotted (nested) id. Floci's nested stacks are out of scope here; say
     so in the error and the docs.
   - It then runs on the same executor as other stack operations: set
     `UPDATE_ROLLBACK_IN_PROGRESS`, mark each skipped resource `UPDATE_COMPLETE`
     with an event, run the walker over the remaining owed ids with the stored
     snapshot, and finish through the shared tail.

**Do not.**

- Do not invent a second rollback walker.
- Do not let `ContinueUpdateRollback` change the template.
- Do not accept `RoleARN` or `ClientRequestToken` semantics beyond parsing them.
- A stack stored before this change has no stored snapshot. Treat it as owing
  every `UPDATE_FAILED` resource and keep its current template, rather than
  failing the call.

**Acceptance.** Extend `TEST/services/cloudformation/CloudFormationRollbackCompleteUpdateIntegrationTest`.
Reach `UPDATE_ROLLBACK_FAILED` the way
`CloudFormationDeleteAfterFailedRollbackIntegrationTest` does: change a log
group, then add a second log group whose name collides with one made outside the
stack. Then check:

- `UpdateStack` and `CreateChangeSet` are refused with the captured message;
- `DeleteStack` still works;
- `ContinueUpdateRollback` without skips ends `UPDATE_ROLLBACK_FAILED` again,
  because log groups cannot roll back;
- with `ResourcesToSkip` naming the log group, it ends `UPDATE_ROLLBACK_COMPLETE`
  and the resource is `UPDATE_COMPLETE`;
- `UpdateStack` is then accepted;
- the call is refused on a stack in another state and for a skip that is not
  `UPDATE_FAILED`;
- the SDK's `ContinueUpdateRollback` waiter path works through the AWS CLI or
  Java SDK.

Add the `INOPERABLE` case to `CloudFormationStackSetsIntegrationTest` only if it
needs no new fixtures.

**Commands.**
`./mvnw test -Dtest='CloudFormationRollbackCompleteUpdateIntegrationTest,CloudFormationDeleteAfterFailedRollbackIntegrationTest,CloudFormationServiceRollbackTest,CloudFormationStackSetsIntegrationTest'`.
The new action changes the generated action table in
`docs/services/cloudformation.md`: run `make docs-sync`, then `make docs-check`.

## 40.5: Time-to-live deletions on the stream

**What a person sees.** When TTL deletes an item, AWS writes a stream record with
`eventName` `REMOVE` and `userIdentity` `{"type": "Service", "principalId":
"dynamodb.amazonaws.com"}`. AWS documents that pair as the Lambda filter for
"only TTL deletions". With the DynamoDB Local engine, Floci passes on Local's
record unchanged: `eventName` is the literal string `UNKNOWN_TO_SDK_VERSION`,
and there is no `userIdentity`. A consumer looking for `REMOVE` misses the
deletion, and a filter on `userIdentity` never matches. The native engine
writes `REMOVE` but no `userIdentity`, so a TTL deletion cannot be told apart
from a `DeleteItem`.

**Priority.** TEOS does not need this today. Its only stream consumer, the
building service's config dispatcher, reads a table without TTL. It matters for
any consumer that archives or reacts on expiry.

**Evidence.**

- The record Local writes is in "Source revisions and what was measured" above.
  That was step 1 of the original plan, now done.
- `SRC/services/dynamodb/backend/DynamoDbLocalBackend.java` `execute` (116-174)
  sends every Streams call to Local and passes the reply through `toPublic`
  (262-282). `toPublic` rewrites only ARNs and `awsRegion`.
- Every reader goes through that `execute`:
  - the public `GetRecords` (`DynamoDbStreamsJsonHandler` line 34);
  - `DynamoDbApiStreamReader.getRecords` (59-71), which feeds the Lambda poller,
    Pipes (`PipesPoller`) and the Redshift zero-ETL consumer.
- `SRC/services/lambda/DynamoDbStreamsEventSourcePoller.java`
  `buildDynamoDbRecordNode` (745-753) copies the record as it is. The same node
  is what filter patterns match (345-352).
- The native engine:
  - the TTL sweep calls `streamService.captureEvent("REMOVE", ...)` with nothing
    marking it as TTL (`DynamoDbService.java` 2778);
  - `DynamoDbStreamService.captureEvent` (156-197) and `DynamoDbStreamRecord`
    have no identity field;
  - `NativeDynamoDbStreamsJsonHandler.recordToNode` (173-199) writes no
    `userIdentity`;
  - the Kinesis copy of the same deletion writes `userIdentity: null`
    (`KinesisStreamingForwarder.java` 449, called at `DynamoDbService.java`
    2783).

**Fix.**

1. Local engine: in `DynamoDbLocalBackend.execute`, for a successful
   `Api.DYNAMODB_STREAMS` `GetRecords` reply, rewrite each record whose
   `eventName` is `UNKNOWN_TO_SDK_VERSION` to `REMOVE` and add the service
   `userIdentity`. Leave every other record untouched. This is the one place
   every reader and the filter matcher pass through.
2. Native engine:
   - give `DynamoDbStreamRecord` a TTL flag;
   - add an overload of `captureEvent` that sets it, and call it from the sweep
     at 2778;
   - make `recordToNode` write the service `userIdentity` when the flag is set;
   - pass the same flag to `KinesisStreamingForwarder.forward` at 2783, so the
     Kinesis record says the same thing.

**Do not.** Do not translate in the poller or in Pipes; the filter must see the
translated record. Do not add `userIdentity` to `DeleteItem` removals. Do not
build a TTL sweeper for Local.

**Acceptance.**

- `TEST/services/dynamodb/backend/DynamoDbLocalBackendTest`: a canned Local
  `GetRecords` reply with `UNKNOWN_TO_SDK_VERSION` comes back as `REMOVE` with
  the identity, and `INSERT`/`MODIFY`/`REMOVE` records are unchanged.
- `DynamoDbStreamServiceTest` and `DynamoDbTtlForwardingTest`: a sweep removal
  has the identity, and a `DeleteItem` removal has none.
- `DynamoDbKinesisStreamingIntegrationTest`: the Kinesis copy has the identity.
- `DynamoDbStreamsEventSourcePoller` filter test: an event source mapping
  filtered on `userIdentity.principalId` `dynamodb.amazonaws.com` gets only the
  TTL deletion.
- With `FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT` set,
  `DynamoDbLocalBackendIntegrationTest` gains one case: an expired item's
  deletion reads back as `REMOVE` with the identity, within a bounded wait. The
  probe saw about 15 seconds.

**Commands.**
`./mvnw test -Dtest='DynamoDbLocalBackendTest,DynamoDbStreamServiceTest,DynamoDbTtlForwardingTest,DynamoDbKinesisStreamingIntegrationTest,DynamoDbApiStreamReaderTest'`.
Note the record shape under Streams/TTL in `docs/services/dynamodb.md`, then
`make docs-check`.

## 40.6: The refresh_token grant on the token endpoint

**What a person sees.** An app that signed in through the hosted pages refreshes
its session with `POST /oauth2/token` and `grant_type=refresh_token`. Floci
answers 400 `unsupported_grant_type`, so the app has to send the user through
sign-in again every time the access token expires. TEOS's `cbdeploy` browser
sign-in does this refresh: `go-services/appstore/cmd/cbdeploy/internal/auth/oauth.go`
`refresh` (91-104) is a public client sending `client_id` and `refresh_token`.
TEOS 33.9 will test sign-in against Floci and mark that step
`floci: Missing Implementation for Cognito OAuth refresh_token grant.` until
this lands. TEOS 27.24 removes the mark.

**Evidence.**

- `SRC/services/cognito/CognitoOAuthController.java` `issueToken` (400 on)
  serves `authorization_code` and `client_credentials`. Everything else gets
  `unsupported_grant_type` (435-437; 347-349 at `ea0689698`).
- Client authentication is already resolved from the form body or a Basic header
  (406-431). `redeemAuthorizationCode` checks a confidential client's secret
  (479-480).
- Refresh exists only through the API:
  - `InitiateAuth` `REFRESH_TOKEN_AUTH` (`CognitoAuthFlowHandler.handleRefreshToken`
    643 on, which fires the `TokenGeneration_RefreshTokens` trigger);
  - `GetTokensFromRefreshToken` (`CognitoService.getTokensFromRefreshToken`,
    3464-3506).
- Gaps in that shared method:
  - it never checks the client secret;
  - it never checks that the token was issued to the calling client. The token
    holds the client id in field 2 (`buildRefreshToken` 4462-4472), and
    `revokeToken` checks it;
  - it mints the access token with the API sign-in scope
    `aws.cognito.signin.user.admin` (`API_SIGN_IN_SCOPES`, 106).
- Since floci-io/floci#4771, a hosted sign-in's access token holds the scopes
  granted at authorize (`generateAuthResultForHostedAuth`, 3583-3589). The
  refresh token does not record them, so a refresh would lose them.
- AWS (token endpoint reference):
  - `client_secret_basic` or `client_secret_post` for a client with a secret,
    and `client_id` alone for a public client;
  - the response is `access_token`, `id_token`, `token_type`, `expires_in`, with
    a new `refresh_token` only when refresh token rotation is active;
  - a revoked token gives `invalid_grant`;
  - a refreshed access token keeps the scopes of the original grant.
- `RefreshTokenRotation` is stored on the client (`CognitoService` 934, 1176)
  but applied nowhere, not even in `InitiateAuth`.

**Fix.**

1. In `issueToken`, add a `refresh_token` branch next to `authorization_code`:
   - require `refresh_token` (`invalid_request`);
   - look up the client and, on a custom domain, require it to belong to the
     domain's pool (`domainPoolId`), else `invalid_client`;
   - check a confidential client's secret as `redeemAuthorizationCode` does
     (`invalid_client`);
   - call the shared method;
   - map `NotAuthorizedException` (invalid, expired or revoked token) to
     `invalid_grant`, and a disabled refresh flow to `unauthorized_client`;
   - answer `access_token`, `token_type`, `expires_in`, and `id_token` when the
     grant includes `openid`, with no `refresh_token`.
2. In `getTokensFromRefreshToken`, refuse a token issued to another client with
   `NotAuthorizedException` "Invalid Refresh Token". This also fixes the
   `GetTokensFromRefreshToken` API. Capture AWS's API message in the PR.
3. Keep the granted scopes:
   - `buildRefreshToken` gains one field after the family id, the granted scopes
     base64url-encoded, because a scope may contain `|`;
   - `parseRefreshToken` reads it, and fields 0-4 keep their meaning, so no
     caller changes;
   - the hosted path passes its granted scopes, and the API path passes none;
   - the refresh mints the access token with those scopes (API sign-in scope
     when none), fires the refresh trigger as today, and mints an ID token as
     the original sign-in did;
   - a token minted before this change has no scope field and refreshes with
     today's API sign-in scope.

**Do not.**

- Do not implement refresh token rotation here; it is missing in every path and
  needs its own task.
- Do not let a refresh widen scopes, or accept a `scope` parameter on this grant.
- Do not change the custom-domain filter; see 40.7.

**Acceptance.**

- `TEST/services/cognito/CognitoOAuthControllerTest`: each error mapping, Basic
  and body authentication, and the public client.
- `TEST/services/cognito/CognitoOAuthTokenIntegrationTest` and
  `CognitoManagedLoginIntegrationTest`:
  - redeem a code, then refresh;
  - the new access token has the granted scopes and a new `jti`;
  - there is no `refresh_token` in the answer;
  - an `id_token` is present only with `openid`;
  - after `RevokeToken`, refresh gives `invalid_grant`;
  - another client's token gives `invalid_grant`.
- `TEST/services/cognito/CognitoCustomDomainOAuthContractIntegrationTest`: the
  same refresh through the custom domain's `/oauth2/token`, and a client of
  another pool is refused.
- `CognitoServiceTest`: the refresh token field round trip and a token without
  the scope field.

**Commands.**
`./mvnw test -Dtest='CognitoOAuthControllerTest,CognitoOAuthTokenIntegrationTest,CognitoManagedLoginIntegrationTest,CognitoCustomDomainOAuthContractIntegrationTest,CognitoServiceTest'`.
Update the token-endpoint list in `docs/services/cognito.md` (about lines
363-367 and 505-518), then `make docs-check`.

## 40.7: The token revocation endpoint

**What a person sees.** An app signs a user out with `POST /oauth2/revoke`, and
the refresh token stays valid until it expires. Floci has no Cognito route for
it, so S3 answers instead.

- Measured by TEOS's cbdeploy sign-in test on 2026-10-02 against
  `mariotoffia/floci:latest`, on a Cognito custom domain
  (`api.auth.<name>.localhost.floci.io`): `POST /oauth2/revoke` answers 400
  `application/xml` `InvalidArgument` "POST requires either ?uploads,
  ?uploadId, ?restore or ?select parameter.". With `Accept: application/json`
  it answers 406 with an empty body.
- Reproduced the same day on a throwaway container on Floci's own host:
  - `POST /cognito-idp/oauth2/revoke` gives the same S3 `InvalidArgument`;
  - `GET /cognito-idp/oauth2/revoke` and `GET /cognito-idp/oauth2/token` give
    404 `NoSuchBucket` for a bucket named `cognito-idp`.

TEOS's `cbdeploy` logout calls this endpoint: `oauth.go` `revoke` (110-139)
sends `token` and `client_id` as a public client. TEOS 33.9 will mark that step
`floci: Missing Implementation for Cognito OAuth revoke endpoint.` until this
lands. TEOS 27.24 removes the mark.

**Evidence.**

- No `@Path("/cognito-idp/oauth2/revoke")` exists in `CognitoOAuthController`;
  its OAuth routes are at 86, 351 and 391.
- `CognitoCustomDomainFilter` (40, 52-74) does map the path: it rewrites every
  `/oauth2/*` path on a custom domain to `/cognito-idp/oauth2/*` and sets the
  pool property. No Cognito route matches the rewritten path, so JAX-RS picks
  S3's path-style catch-all instead:
  - `S3Controller.handleMultipartPost`, `@POST @Path("/{bucket}/{key:.+}")`
    (1468-1471), with bucket `cognito-idp` and key `oauth2/revoke`;
  - its `InvalidArgument` is raised at 1578;
  - a `GET` reaches S3's `GetObject` and answers `NoSuchBucket`.
  The S3 virtual-host filter is not involved; it already skips a request that
  holds the Cognito pool property (`S3VirtualHostFilter` 163-169).
- `TEST/services/cognito/CognitoCustomDomainOAuthContractIntegrationTest`
  `revokeEndpointIsNotServed` (203-214) asserts 404 for `GET /oauth2/revoke`.
  That 404 is S3's `NoSuchBucket`, not a missing route.
- The same thing happens to any path under `/oauth2/` that Cognito does not
  serve, and to a served path called with the wrong method (the `GET
  /cognito-idp/oauth2/token` probe). `EksController` (168-170) shows the same
  family of problem, fixed there with explicit routes.
- `CognitoService.revokeToken` (3508-3560), behind the `RevokeToken` API, does
  the work:
  - it checks the client and its secret, that revocation is enabled, the token
    type and the issuing client;
  - it stores the token family in the revoked-token store.
- Access and ID tokens minted from that family have `origin_jti` and are then
  refused (`validateTokenNotRevoked` 4745, called for `origin_jti` at 4539 and
  4585). A refresh of the family is refused too.
- AWS (revocation endpoint reference):
  - `POST` only, with a form body;
  - `token` is required, and `client_id` is required for a public client;
  - a client with a secret authenticates with a Basic header;
  - success is 200 with an empty body;
  - a missing token, or revocation disabled on the client, is 400
    `invalid_request`;
  - a token that is not a refresh token is 400 `unsupported_token_type`;
  - bad client credentials are 401 `invalid_client`;
  - an already revoked or invalid token is 200.

**Fix.**

1. Add `@POST @Path("/cognito-idp/oauth2/revoke")` to `CognitoOAuthController`,
   reusing `parseBasicCredentials` and the client resolution from `issueToken`.
   - On a custom domain, require the client to belong to the domain's pool.
   - Call `revokeToken` and map its exceptions:
     - `InvalidParameterException` and `UnsupportedOperationException` → 400
       `invalid_request`;
     - `ResourceNotFoundException` and the secret's `UnauthorizedException` →
       401 `invalid_client`;
     - `UnsupportedTokenTypeException` → 400 `unsupported_token_type` when the
       token is a Cognito JWT (three dot-separated parts), and otherwise 200,
       because AWS answers 200 for a token that is not valid.
   - Answer 200 with an empty body.
2. Keep S3 away from Cognito's OAuth paths on a custom domain. In
   `CognitoCustomDomainFilter`, inside the existing `/oauth2/` and managed-login
   path check (so no extra domain lookups), hold one map of the paths Cognito
   serves and their methods:
   - `/oauth2/token` and `/oauth2/revoke`: `POST`;
   - `/oauth2/authorize` and `/oauth2/idpresponse`: `GET`;
   - `/oauth2/userInfo`: `GET` and `POST`;
   - `/login`: `GET` and `POST`;
   - `/logout`: `GET`.
   When the host is a Cognito custom domain and the path is not in the map,
   abort with a Cognito-shaped 404. When the method does not match, abort with
   405. Update the filter's doc comment to list `/oauth2/revoke`.

**Not in this leaf.** A path on a Cognito custom domain outside `/oauth2/`,
`/login` and `/logout` (say `GET /favicon.ico`) is not touched by the Cognito
filter. The S3 virtual-host filter then treats the domain's first labels as a
bucket name (`S3VirtualHostFilter` 171-179). Read from source, not measured; no
TEOS caller sends such a path. Claiming the whole host would put
`CognitoService.findCustomDomain`, which scans the domain store
(`findDomains`), in front of every request, so it needs a host-keyed lookup
first. Park it like the unmapped-path gap in row 8.2, with no upstream action
until a caller needs it.

**Do not.**

- Do not duplicate the revocation logic in the controller.
- Do not add a `GET` route.
- Do not add a `/cognito-idp/oauth2/{rest}` catch-all route on Floci's own host.
  A bucket literally named `cognito-idp` would lose those keys.

**Acceptance.**

- `CognitoOAuthControllerTest`: each mapping.
- `CognitoOAuthTokenIntegrationTest`:
  - sign in, revoke with a public client, then refresh gives `invalid_grant`
    (with 40.6, otherwise through `InitiateAuth`);
  - `GetUser` with the old access token is refused;
  - a second revoke is 200;
  - a confidential client without Basic gets 401;
  - revocation disabled gives `invalid_request`.
- `CognitoCustomDomainOAuthContractIntegrationTest`: replace
  `revokeEndpointIsNotServed` with:
  - a positive revoke through the custom domain;
  - a client of another pool refused;
  - `POST /oauth2/revoke`, `GET /oauth2/token` and `GET /oauth2/no-such-path`
    on the custom domain are answered with JSON by Cognito, never with an S3
    `application/xml` body, whatever the `Accept` header.

**Commands.**
`./mvnw test -Dtest='CognitoOAuthControllerTest,CognitoOAuthTokenIntegrationTest,CognitoCustomDomainOAuthContractIntegrationTest,S3VirtualHostFilterTest'`.
Add the route to the endpoint table in `docs/services/cognito.md`, then
`make docs-check`.

## Order and size

Sizes are production plus test lines: S under 200, M 200 to 600, L over 600.
Each is its own PR from `main`. Two PRs touching the same file are opened one
after the other merges, not stacked.

| Order | Leaf | Size | Why here |
| --- | --- | :-: | --- |
| 1 | 40.1 | M | Unblocks TEOS 27.22. TTL reconcile is S; the table rollback snapshot makes it M |
| 2 | 40.2 | M | Unblocks TEOS 27.23. Start once floci-io/floci#4861 merges (same method) |
| 3 | 40.7 | S | Unblocks half of TEOS 27.24 and gives 40.6 its revoked-token test |
| 4 | 40.6 | M | The other half of TEOS 27.24. The scope field is most of the work |
| 5 | 40.3 | S | Fidelity only. Touches the `executeTemplate` loop, so it goes before 40.4 |
| 6 | 40.4 | L | Fidelity only. The refusal alone is one line, but shipping it without `ContinueUpdateRollback` leaves `DeleteStack` as the only way out, so they ship together |
| 7 | 40.5 | S | Fidelity only. No TEOS consumer reads a TTL table's stream today |

## Open questions for the implementer

Capture each AWS answer in the PR before pinning it in a test.

1. **40.1.** CloudFormation's status reason for a TTL attribute change while
   enabled. Whether removing the block disables TTL on AWS; the plan assumes it
   does.
2. **40.2.** When a custom resource's own `Update` fails, AWS sends it a second
   `Update` with the old properties (CDK guide). Floci restores the previous
   resource without calling the handler (`executeTemplate`, the failed-resource
   branch at 1592-1625). Measure on AWS, then decide whether this PR also does
   that. The route is `retainsFailedUpdateState` answering true while the
   snapshot exists. It changes a path TEOS's "refused registration" step passes
   today, so measure first.
3. **40.2.** Whether AWS sends the rollback `Delete` for a replaced id during the
   rollback or in its cleanup phase. Floci sends it at once.
4. **40.4.** The exact `ValidationError` texts:
   - for `UpdateStack` and `CreateChangeSet` on `UPDATE_ROLLBACK_FAILED`;
   - for `ContinueUpdateRollback` on another status;
   - for a skip that is not allowed;
   - the event reason on a skipped resource.
5. **40.6.** AWS's answer for a refresh token issued to another client, through
   both the endpoint and `GetTokensFromRefreshToken`.
6. **40.7.** AWS's answer for a token issued to another client, and whether a
   `client_secret` in the body is accepted in place of Basic.
7. **Follow-up, not in any leaf.** A custom resource whose forward `Update`
   returns a new physical id never gets a `Delete` for the old id after the
   update commits. `ReplacementCleanup` cannot do it as is, because its deleter
   gets no properties or service token. File it as its own task if a workload
   needs it.
