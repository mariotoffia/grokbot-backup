# Native DynamoDB Streams Delivery Implementation Plan

> **For agentic workers:** Use `subagent-driven-development` or `executing-plans`
> when implementation is authorized. Each numbered leaf is one PR; checkbox
> steps belong inside that PR. Do not implement this entire plan in one PR.

**Goal:** Make Floci's existing DynamoDB-to-Lambda poller execute the stream
delivery settings needed by TEOS without depending on DynamoDB Local.

**Architecture:** Keep the existing poller, mapping store, invocation service and
filter matcher. Separate fetched cursor position from acknowledged progress,
apply failure policy to the retained batch, and stop mapping-owned work safely.
No second pump, generic event framework or external database is introduced.

**Tech Stack:** Java 25, Quarkus, Vert.x, Jackson, JUnit/Mockito, AWS SDK compatibility tests.

---

## Scope, estimates and landing order

Selected as **B** on 2026-09-18. Status:
[Task 35](../../TEOS_GROUNDZERO_TASKS.md#task-35-native-dynamodb-streams-delivery).
Native correctness repairs from estimate A are not implicitly scheduled here.
Task 21 is asynchronous Lambda invocation policy, not this event-source policy.

| PR | Work | Effort | Merge prerequisites |
| --- | --- | --- | --- |
| 35.1 | DynamoDB mapping retry/age model and API contract | 0.5-1 day | None |
| Existing 23.1 | CFN forwarding of the supported model, including 35.1's fields | 0.5-1 day attributable to this delivery plan | 35.1 for the complete DynamoDB field set |
| 35.2 | Partial-batch responses and safe checkpoints | 1-2 days | None |
| 35.3 | Retry limits, record age, bisection and SQS failure destination | 3-5 days | 35.1, 35.2 and 35.4 |
| 35.4 | Initial position and mapping-owned lifecycle | 1-2 days | None; reconcile with any already-merged 35.2/35.3 work |
| **B total** | Includes the relevant 23.1 share once | **6-11 developer-days** | No Local dependency |

Estimates include normal PR completion/docs, not review queues or a separate
TEOS qualification campaign. The rest of 23.1's existing SQS/general mapping
scope is not estimated again here. Branch from current `main`; wait for named
prerequisites to merge rather than stack. Independent tasks can still touch the
same poller, so coordinate landing rather than manufacturing branch dependencies.

## File map

Paths are relative to Floci.

- `src/main/java/io/github/hectorvent/floci/services/lambda/model/EventSourceMapping.java`:
  saved settings and per-shard progress.
- `src/main/java/io/github/hectorvent/floci/services/lambda/LambdaService.java`:
  create/update validation and mapping persistence.
- `src/main/java/io/github/hectorvent/floci/services/lambda/LambdaController.java`:
  AWS REST JSON mapping response.
- `src/main/java/io/github/hectorvent/floci/services/lambda/DynamoDbStreamsEventSourcePoller.java`:
  existing read/filter/invoke/checkpoint loop and worker lifecycle.
- `src/main/java/io/github/hectorvent/floci/services/lambda/EsmStore.java`:
  existing account-aware mapping storage, not a new queue.
- `src/main/java/io/github/hectorvent/floci/services/lambda/EsmFilterCriteriaUtils.java`:
  existing filter selection; retain it.
- `src/main/java/io/github/hectorvent/floci/services/sqs/SqsService.java`:
  existing destination send API; no transport-specific HTTP loopback.
- `src/main/java/io/github/hectorvent/floci/services/cloudformation/provisioners/LambdaEventSourceMappingCfnProvisioner.java`:
  **owned by 23.1**, not edited again as another CFN implementation in 35.x.
- `src/test/java/io/github/hectorvent/floci/services/lambda/`:
  `EventSourceMappingSerializationTest.java`, `LambdaServiceTest.java`,
  `LambdaServicePersistenceTest.java`, `DynamoDbStreamsEventSourcePollerTest.java`.
- `docs/services/lambda.md`: distinguish settings storage, executed semantics,
  native volatile stream history and remaining unsupported capabilities.

35.3 may add one package-private `DynamoDbBatchDelivery` helper in the existing
Lambda package if policy would otherwise obscure the poll loop. It owns this
batch policy only, not a pluggable destination/pump framework.

## 35.1: Mapping retry and age contract

Satisfied upstream by floci-io/floci#3428.

- [x] Add nullable `Integer maximumRetryAttempts` and
      `Integer maximumRecordAgeInSeconds` with ordinary accessors to
      `EventSourceMapping`. Preserve old stored mappings with absent fields.
      For DynamoDB processing, absent/-1 means unlimited, subject to available
      stream history; zero retries means one initial execution only.
- [x] Validate DynamoDB mappings in `LambdaService`: retry attempts are -1 or
      0 through 10000; record age is -1 or 60 through 604800 seconds. Reject
      malformed/fractional/out-of-range input with the existing AWS
      `InvalidParameterValueException` convention. Keep create, update and
      unchanged/omitted update fields distinct. Do not change other source
      families' behavior as a side effect.
- [x] Extend `LambdaController.buildEsmResponse` consistently with the existing
      optional batching-window response. Preserve null-versus-explicit-default
      serialization and native reflection safety. Add create/get/list/update,
      restart and legacy-record cases in the existing suites.
- [x] Put the following focused round-trip case beside the existing batching
      window tests; its accessor names are defined by the first step:

```java
@Test
void streamRetrySettingsRoundTrip() throws Exception {
    EventSourceMapping mapping = new EventSourceMapping();
    mapping.setMaximumRetryAttempts(0);
    mapping.setMaximumRecordAgeInSeconds(60);
    EventSourceMapping restored = objectMapper.readValue(
            objectMapper.writeValueAsString(mapping), EventSourceMapping.class);
    assertEquals(0, restored.getMaximumRetryAttempts());
    assertEquals(60, restored.getMaximumRecordAgeInSeconds());
    assertNull(new EventSourceMapping().getMaximumRetryAttempts());
    assertNull(new EventSourceMapping().getMaximumRecordAgeInSeconds());
}
```

- [x] Run from Floci root:

```sh
./mvnw test -Dtest=EventSourceMappingSerializationTest,LambdaServiceTest,LambdaServicePersistenceTest
```

Expected: exact API/serialization assertions pass, invalid inputs cannot mutate
the stored mapping, and unrelated SQS/Kafka settings retain their behavior.
Document this PR as storing/validating settings; 35.3 supplies execution.
23.1 then forwards these fields with its existing intrinsic/removal handling.

## 35.2: Partial-batch responses and checkpoint safety

Satisfied upstream by floci-io/floci#3466.

- [x] Extend the existing deterministic poller fixture. Feed three ordered
      sequence numbers and a successful invocation containing this response:

```json
{"batchItemFailures":[{"itemIdentifier":"000000000000000000002"}]}
```

With `ReportBatchItemFailures` enabled, only sequence 1 is acknowledged; the
retry starts at sequence 2. With the feature disabled, a successful invocation
retains the existing whole-batch success contract.
- [x] Parse the response only after a successful synchronous Lambda invocation.
      Multiple failures select the earliest failed sequence in fetched order.
      Empty/no failures mean success. A malformed/null/empty identifier or an
      identifier outside the submitted batch fails the whole submitted batch,
      rather than being ignored as a success.
- [x] Keep the fetched batch and its matched-record positions together. Advance
      only a contiguous disposed prefix: filtered records can be consumed but
      cannot carry the checkpoint past an earlier failed matched record.
      Never infer ordering by lexical comparison of arbitrary unpadded tokens.
- [x] Cover these exact outcomes in `DynamoDbStreamsEventSourcePollerTest`:

| Fetched order | Matched records | Invocation outcome | Safe progress |
| --- | --- | --- | --- |
| 1,2,3 | all | fail 2 | acknowledge 1, retry from 2 |
| 1,2,3,4 | 1,3 | fail 1 | do not skip 1 because 2/4 were filtered |
| 1,2,3,4 | 1,3 | fail 3 | acknowledge 1 and filtered 2, retry from 3 |
| 1,2,3 | none | no invoke | acknowledge 3 |
| 1,2,3 | all | invalid identifier | no batch progress |
| 1,2,3 | all | successful empty failure list | acknowledge 3 |

- [x] Reuse the existing invocation/filter/store helpers and run:

```sh
./mvnw test -Dtest=DynamoDbStreamsEventSourcePollerTest,EventSourceMappingSerializationTest
```

Expected: no failed record is skipped; the original native restart/checkpoint
regressions still pass. Document at-least-once delivery, not exactly once.

## 35.3: Retry, age, bisection and failure destination

Gap (bisection, refused destination) in PR floci-io/floci#4337 (closes floci-io/floci#4312); retry, age and destinations already upstream (#3428, #3613, #3622).

- [x] Reuse mapping settings and retain the same immutable batch while retrying.
      Key transient state by owner account, mapping, stream generation and shard.
      Use a controlled clock and bounded scheduling; do not sleep on a Vert.x
      event-loop thread or add an unbounded worker/queue.
- [x] Classify failure before choosing policy. Function errors and opted-in
      partial responses are delivery failures. Before-invocation service
      failures/throttling do not consume function retry quota the same way.
      Age/history still bounds usable records. Do not copy the TEOS pump's
      simpler treatment of all invocation errors as the AWS contract.
- [x] Apply bisection only to a failing nonempty batch, preserving order. A split
      does not consume retry quota. Work through the failing subset without
      redelivering already disposed prefixes. Respect partial-response policy
      when both settings are enabled.
- [x] With a retry budget of 0, execute once, then dispose through the configured
      failure path. With -1, keep retrying while age/history permits. Evaluate
      age from each record's creation timestamp; a configured age limit must
      actually expire records. Use the account/region of the mapping, not a
      request-thread default.
- [x] Deliver exhausted/expired work to the existing SQS service with the AWS
      DynamoDB destination record shape: request/response context plus
      `DDBStreamBatchInfo`, public source ARN, sequence range, timestamps and
      batch size. Read the documented stream destination contract, not the
      unrelated async Lambda destination shape. Unsupported destination types
      fail validation explicitly until implemented.
- [x] A configured destination send failure must remain visible and must not
      become a successful checkpoint. Retain bounded pending work for retry,
      record a diagnostic and expose the existing mapping-result status where
      available. With no destination, deliberate policy exhaustion may discard
      and advance, but its discard count/reason must be explicit.
- [x] Add controlled cases for retry 0/1/-1, expiration, before-invoke throttling,
      bisection of one poison record, combined partial/bisect, successful failure
      delivery and failed destination send. Use an existing/native stream source
      and mocked invocation for timing; include one ordinary SDK mapping to a
      real SQS failure target in a proposed
      `DynamoDbStreamDeliveryIntegrationTest.java`.
- [x] Run:

```sh
./mvnw test -Dtest=DynamoDbStreamsEventSourcePollerTest,DynamoDbStreamDeliveryIntegrationTest
```

Expected: successful prefixes survive retries, exact destination records arrive,
and a refused destination cannot silently lose the batch. Update Lambda docs.
Do not add native stream durability, a new DLQ protocol or global retry config.

## 35.4: Starting position and mapping lifecycle

Implemented in floci-io/floci#4318 (closes #4311).

- [x] Honor the saved `TRIM_HORIZON`/`LATEST` contract. Capture the initial LATEST
      position once for a new mapping, not on every empty poll. Resume an existing
      mapping from its committed position. Unsupported starting modes fail
      honestly rather than silently behaving as TRIM_HORIZON.
- [x] Keep the current native-only restart rule: native stream buffers/sequence
      counters are volatile, so stale persisted native progress is discarded.
      Do not remove that regression to prepare for Local. Task 36.3 moves this
      decision into source-generation policy, and 37.4 supplies external behavior.
- [x] Use a mapping generation/cancellation guard around scheduling, invocation
      and checkpoint writes. Disable/delete/reset cancels queued work and waits
      for bounded in-flight work as appropriate; an old worker cannot save into
      a deleted/recreated mapping or invoke its replacement.
- [x] Extend the poller tests with: old rows plus new rows under LATEST, an empty
      page before a later write, disable/re-enable, delete during a blocked read,
      delete during invoke, and reset followed by mapping recreation.
      Drive completion with controlled futures/latches, not longer sleeps.
- [x] Run:

```sh
./mvnw test -Dtest=DynamoDbStreamsEventSourcePollerTest,LambdaServicePersistenceTest
```

Expected: only the intended initial records run, and no stale invocation or
checkpoint outlives its mapping generation. Existing native restart cases pass.

## Relationship to C and D

All four native PRs can land without Local or its future client. When 36.3
introduces the source reader, preserve these exact delivery decisions behind
that reader. C owns source abstraction, not another retry engine; D owns Local
protocol adaptation, not a copy of this poller.

Do not delete TEOS's host pump here. That happens only in 37.6 after the selected
image has B, C, D and CFN forwarding, and the run starts without the old pump.
