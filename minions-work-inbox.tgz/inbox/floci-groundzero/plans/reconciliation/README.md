# Floci planning source reconciliation

**Goal:** Keep one actionable Floci/TEOS-integration backlog without losing
requirements or reopening completed work.

**Architecture:** The [task index](../../TEOS_GROUNDZERO_TASKS.md) owns status.
Plans own implementation boundaries, acceptance and source provenance. Each
executable leaf is one PR in its owning repository; a dependent leaf waits for
its predecessor to merge into `main`.

**Tech stack:** Floci Java/Quarkus and the existing TEOS Go/CDK test harness.

## Sources and scope, synced 2026-09-18

| Source | Snapshot | Treatment |
| --- | --- | --- |
| Floci checkout | `570f975829ab30f2cf2447985fa425e7a9df3b7b` | Local implementation evidence, not the latest upstream or a running image |
| Existing `.vscode` index and plans | Read on 2026-09-17, including the newer Task 6 split notes | Preserve completed work and historical PRs |
| TEOS working checkout | Initial HEAD `a2ff9dc13bae9dec68657c8f959650c51602d2a4`, with uncommitted changes | Working plans and local changes are evidence, not completion |
| Prior working-plan cut | HEAD `f9a7a89fe979f1a2b3377b383c6919ec9f459dee` plus files copied 2026-09-17 14:36 +02:00 | Historical import, now superseded by the completed source sync below |
| Current completed TEOS source | `4514f7d53a119fcda38bbc360a954f7c6d4c7f75`, clean `floci-enhanced`, copied 2026-09-18 06:30 +02:00 | All eight design Markdown files, scan script and project-root ISSUES/API_ENDPOINT read without mutation |
| TEOS planning branch | `feature/psdk-v2-planning` at `9a66295a724c5a652cfc3fdb17b0fcc0300b97aa` | Read through Git objects, without checkout or merge |
| TEOS committed `main` used in branch comparison | `20e10c182f474eff03bb81c1d3b364c1acc21f68` | Distinct from the working-checkout HEAD above |
| Branch merge base | `819a257ba003dd9d50cd2eef5d6d3f54e67257d9` | Branch has 2 commits, `main` has 9, beyond their common base |

At the original branch comparison, local `origin/feature/psdk-v2-planning`
matched the branch tip and `origin/main` matched the compared `main`. This is
historical evidence, not a refreshed remote-state claim.

**At that comparison the Floci files did not diverge between the branch and
committed `main` `20e10c182`.** All nine tracked files had identical blobs.
The two branch commits instead rewrite Provider SDK documentation and add its
conformance, schema and use-case designs. The user explicitly excluded the full
Provider SDK v2 implementation backlog. There are no additional Floci-only branch
tasks to invent, and no reason to merge the SDK document deletions into Floci.

**The earlier working checkout differed from that branch:** `ISSUES.md`, `PLAN.md`,
`README.md` and `WATCH.md` differ, measured as 435 additions/267 deletions during
the 2026-09-17 check. The completed `floci-enhanced` sources now supersede that
draft. W-12 and the account-safety fix are complete; W-15 is still open for
identified schema/IAM defects. No unfinished draft marker is imported.

The read-only source directory is
[`TEOS/design-in-progess/floci/`](../../../../../thiink/teos/design-in-progess/floci/).
It contains:

- `README.md`: service/provisioning analysis, AWS call sweep and current capability gaps.
- `PLAN.md`: deployment/test orchestration and the current run plan.
- `ISSUES.md`: F-/P-/W- requirement identities and workaround deletion conditions.
- `WATCH.md` and `floci-scan.sh`: upstream/image evidence; no source merge implies image adoption.
- `PLAN_FLOCI_ENHANCED_IMPL.md`: completed TEOS integration implementation record,
  not an unimplemented native-Floci replacement plan.
- `PLAN_LOCAL_SERVICES.md`: local service-test harness and removal conditions.
- `PLAN_MONITOR_DATAPATH.md`: the monitor data path and its real fixtures.
- `PLAN_DDB_PUMP.md`: DynamoDB Local stream-pump contract and limitations.

Additional sources in TEOS's root:

- [`ISSUES.md`](../../../../../thiink/teos/ISSUES.md): DynamoDB integration limits,
  remaining HTTPS callers, local-enabling TEOS defects and unimplemented tests.
- [`API_ENDPOINT.md`](../../../../../thiink/teos/API_ENDPOINT.md): the completed
  common network profile's routing/trust and endpoint-safety contract.

The initial working checkout contained edits to the harness, table mirroring, Cognito probe,
image pin, discovery/build files and `WATCH.md`, plus untracked groundzero tests and
a mirror watcher. The later local checkpoint records the baseline as implemented.
This reconciliation does not edit, stage, commit or certify those source changes.

## Completed-source delta, 2026-09-18

| Source change since the prior cut | Applied disposition |
| --- | --- |
| PLAN 6.9 finishes real service registration/dependency run | Mark 27.5 completed locally, W-12 removed. Preserve read-back of groundzero and event-service rows |
| Config loader fix completed in `4bfc7ab0c` | Mark 31.8 completed locally; do not reimplement it |
| W-21 moved from script-local code to common `cbnet` and was hardened | New completed baseline 33.1, commits `6d5e5e1c6` and `2fbe18710`. Caller gaps are separate 33.7-33.10 |
| W-15 identifies the actual OpenAPI `$ref` sibling defect | New 33.3; 27.6 waits for schema validation plus missing IAM resources, not nonexistent groundzero |
| `generate-api` and root worktree-exclusion fixes are complete | Retain as evidence. Remaining building Go-model generation hook is new 33.6 |
| Groundzero AWS test became explicitly read-only | Carry that invariant into every new lifecycle/force/update task |
| W-22 and root 1.6 describe the polling race and authoritative post-deploy check | Do not claim a hard barrier. Keep 31.6; selected Tasks 35-37 implement the replacement before 37.6 removes the copy |
| Pump design now documents W-19 as closed | Preserve completed 28.2/28.3 and residual 31.7; no repeat guard implementation |
| Root issue register inventories Streams env, direct service writes, client gaps, registry defects and TTL uncertainty | Task 33 and the separate DynamoDB investigation; full per-section disposition in the root-issue plan |
| WATCH and old implementation plans mainly repoint current-status anchors | Update navigation, retain implementation history and the working scan script |
| Root 5 records the owner's decision not to add local CI | No CI task is scheduled unless the owner changes that decision |

`PLAN.md` 6.9 records building 4 pass/1 LCS skip (182 s), collector 1 pass
(127 s), and event 5 pass (114 s), including the actual service-registration
row. Groundzero precedes each service through normal manifest dependencies.
These are attributed run records, not tests rerun by this documentation sync.
No new GitHub merge/PR-state scan was performed.

## Conflicting status and requirement claims

| Source claim | Reconciled disposition |
| --- | --- |
| Old Floci index pins TEOS to 2.0.1 | Superseded by the recorded 2.1.0 adoption below; do not create a second image-pin task |
| Old PLAN says domains are missing and groundzero cannot start | Superseded by recorded groundzero and dependent-service runs. Task 31 carries remaining DNS/update/device gaps |
| An unchecked old implementation step overlaps a merged PR | Keep the merged task completed; qualify the containing image or open a newly numbered correction task only for an actual remaining delta |
| Local harness/groundzero checkpoint passed | Record the demonstrated subset as 🟢L in 27.2-27.4, not merged. The four CFN DNS records were absent despite complete stack status |
| SQL rules exist | Reserved shadow/presence event dispatch remains Task 19 |
| EventInvokeConfig exists | Asynchronous execution remains Task 21; completed Task 6.3 is not reopened |
| MQTT WebSocket transport exists | Custom-authorizer management, provisioning and enforcement are Tasks 20.3, 20.4 and 20.5 |
| WATCH contains a `present RetainResources` probe | A probe describes the condition to look for, not a passing result. P-3 remains with Task 16 until real revision/API evidence exists |
| Stub tolerances were reduced for 2.1.0 | Dashboard/event-invoke removals are done. Only MetricFilter remains for 27.8. `ListStackResources` does not expose a stub-reason field |
| TEOS says floci-io/floci#3233 was closed unmerged | True for its earlier source snapshot and the 2.1.0 image. The newer existing Floci Task 6 notes record reopening plus draft floci-io/floci#3809; preserve those notes, not the older closure as current PR state |
| WATCH P-23 checks for bucket `Tags` | New CFN bucket-tag task 29.7; auto-delete qualification 27.7 needs both tags and TLS, not only a reachable callback |
| Native image packaging is fixed privately | Tasks 25 and 26 remain completed. Any obsolete workflow-patch cleanup is a new task, not another packaging fix |
| Old source says leave `DescribeEndpoint` as `host:port` | Superseded by completed 7.12. Use a bare hostname and qualify device ports in new 31.5 |
| Old plan requires publishing host 443 | Rejected by the final source: W-21 dials the endpoint override while verifying the custom hostname, allowing concurrent runs. Preserve this implemented behavior |
| W-21 previously described a script helper | Completed common network profile 33.1 replaces it. New callers reuse `cbnet`/`httputil`, never another custom TLS transport |
| Groundzero record says all 23 resources are real | The same run's Route 53 API check found four CFN records absent. Keep P-24/31.1 open; stack status and non-stub-shaped IDs are not proof |
| Root 1.6 says a real backend barrier was not planned | The user requested research and then selected B/C/D on 2026-09-18. Tasks 35-37 are planned, not implemented; the existing copy stays until adoption gates pass |
| Task 10B observed an overlong Lambda/custom-resource wait | Current local code has invocation deadlines and CFN idle/liveness waits. Qualify the negative case in new 31.6 before creating any runtime repair |

## Existing task ownership

| Source requirements | Existing execution owner | Boundary |
| --- | --- | --- |
| P-4/P-5/F-2/F-9: certificate and custom-domain provisioners, API keys/usage plans | Completed Tasks 1-4, 7-8, 10 | Only new qualification/correction work |
| F-1: IoT SQL | Completed Task 5 | Do not rewrite the evaluator |
| F-13: TLS, custom-domain host routing and MQTT transport | Completed Task 7 and local host-TLS 27.2; 7.14 and 8.2 remain outstanding | Device qualification is new 31.5 |
| P-13 / W-14: SSM ARN and parameter-change events | 15.1, 15.2 | Service mutation emits the event, not the test |
| P-6: SSM tags and filtering | Completed 15.3 via floci-io/floci#3550 and floci-io/floci#3646 | Keep GetParametersByPath. Remaining CFN tag forwarding is new 29.9 |
| P-3 / W-2: retained stack resources | 16 plus TEOS cleanup after qualification | Retained data survives, not just a successful API response |
| P-1 / P-2: tag discovery | 17.1-17.5 | One parser PR and one PR per service |
| P-14 / W-17: ECR bind conflicts | 18 | Bound retries; don't mask unrelated Docker errors |
| F-12: reserved IoT events | 19.1, 19.2 | Real shadow operations and connection lifecycle drive rules |
| P-15 / P-16: Cognito groups and EventBridge archives | 20.1, 20.2 | Actual resource read-back and lifecycle |
| P-9 authorizer remainder | 20.3-20.5 | API, CFN, transport enforcement are separate PRs |
| F-5 / W-6: async Lambda | 21 | Runtime retry/destination proof, not configuration read-back |
| F-7 / W-16: queue URLs | 22 | Conditional; keep endpoint safety and validators |
| P-22: mapping properties | 23.1, 23.2 | CFN forwarding and runtime proof, no premature pump deletion |
| Account-bearing Lambda references | 24.1, 24.2 | Separate service and CFN repair after predecessor merge |
| Task 6 deferred capabilities | 6.4-6.11 | Existing detailed designs retained; conditional work is not silently scheduled |

Detailed files, PR boundaries and acceptance for overlapping runtime work are in
the [runtime fidelity plan](../runtime-fidelity/README.md).

## Remaining issue-register coverage

| Source IDs | Disposition and execution owner |
| --- | --- |
| P-7 | `/apiKeyRequired` delivered in floci-io/floci#3537; new TEOS contract cases 27.1. `/policy` storage is 29.1; denial enforcement is conditional 30.3 |
| P-8 | TraceHeader propagation, 29.2 |
| P-10 | Silent-success rejection delivered in floci-io/floci#3139; OR support is new 29.3 |
| P-11 | FIFO dedup after consume/delete, 29.4 |
| P-12 | Old open-issue evidence conflicts with existing raw-PSS implementation. New TEOS interoperability qualification 29.5, no repeat signer |
| P-17 | Dashboard/event-invoke provisioners and TEOS tolerance removal recorded done; only metric-filter remainder goes to 27.8 |
| P-18 | Floci field name 9.1; separate TEOS nil-safety 27.13 |
| P-19 | IoT merge/type/version/billing-group behavior remains 9.2 |
| P-20 | Exact Logs error messages remain 9.3 |
| P-21 | Indexing configuration remains 9.4; readiness qualification 27.14 is not fleet search |
| P-23 | Working WATCH adds CFN bucket tags, new 29.7; actual auto-delete 27.7 depends on it |
| P-24 | Real CFN Route53 RecordSet creation, new 31.1; a name-only fake is not detected by the old stub-ID check |
| P-25 | Missing iam-service WAF association/user/group-attachment provisioners, separate 31.2/31.3/31.4 |
| F-3 | Bounded fleet-search follow-up 30.1 when selected |
| F-4 | Deferred alarm-service backend decision 30.2; DSQL remains off |
| F-5 | Lambda execution 21 and independent EventBridge delivery 29.6; settings read-back closes neither |
| F-6 | Retain the pump and completed 28.1-28.3; residual checks 31.7. B/C/D and multi-account isolation are now selected in 34; execution is 35-37, removal gated by 37.6 |
| F-7 | Retain endpoint configuration; Task 22/27.17 cover only conditional returned-URL cleanup |
| F-8 | Denial scope is conditional 30.3; do not infer policy enforcement from successful calls |
| F-9 | ACM is delivered; AppSync remainder is conditional inventory 30.4 |
| F-10 | Retain the documented Firehose newline deviation; source explicitly says no work is needed |
| F-11 | Existing Task 6; only MetricFilter is still a tolerated TEOS stub |

### Every workaround has a removal or retention decision

| Source | Decision |
| --- | --- |
| W-1 | Keep host/container endpoint configuration; separate from 22 |
| W-2 | Warning remains until 16 passes, then removal PR 27.9 |
| W-3 | Preserve fail-fast stub checks; remove only the last tolerance in 27.8 |
| W-4 | Keep external pump/stream endpoint override and completed 28.1-28.3; remaining evidence is new 31.7 |
| W-5 | Keep arm64 local runs, no speculative architecture-emulation work |
| W-6 | Keep second-tick substitution until 21 and the exercised 29.6 path work; extend real slow-turn evidence in 27.16 |
| W-7 | Withdrawn size override; no PR |
| W-8 | Keep explicit limits on local security/throttling/encryption claims; conditional 30.3 |
| W-9 | Keep deployment-target validation and endpoint injection; completed source work |
| W-10 | Plain CDK asset upload works; no `cdklocal` task |
| W-11 | Keep GetParametersByPath; P-6 is delivered, CFN tag delta is 29.9 |
| W-12 | Removed and 27.5 completed locally in PLAN 6.9. Registration update remains 31.6, not reopening the cleanup |
| W-13 | Bucket tags 29.7 plus real Node/TLS auto-delete qualification 27.7 |
| W-14 | SSM emitter 15.2, then separate TEOS cleanup 27.10 |
| W-15 | 27.6 still pending: first schema fix 33.3, then actual API test and the missing IAM resource types. Groundzero and generate-api exist |
| W-16 | Conditional URL strategy 22 and TEOS cleanup 27.17; validators unchanged |
| W-17 | ECR conflict retry 18, then independent image-qualified cleanup 27.12 |
| W-18 | Keep completed monitor activation/watermark fixtures; the absent production publisher is not a Floci defect |
| W-19 | Record-age guard and harness failure on destination errors are completed locally as 28.2/28.3. New residual loss/cancellation proof is 31.7 |
| W-20 | Host TLS and run-scoped SDK/Node CA trust are implemented, 27.2. Keep this configuration |
| W-21 | Common network profile 33.1 is complete and replaces the original 27.2 script helper. No host 443 binding; preserve vendor isolation and caller trust |
| W-22 | Copying is complete, 27.4, but polling is not a hard barrier. Keep authoritative post-deploy validation and existing failure diagnostics until an approved backend replaces the split |

### Closed items and recorded probes

| Source IDs | Disposition |
| --- | --- |
| C-1, C-2, C-3 | Existing service constants, evidence-preserving containers and `FLOCI_DOCKER_RESOURCE_NAMESPACE`; no new task |
| C-4 | IoT endpoint scheme support is delivered; actual HTTP/TLS paths qualified by 27.2/27.16 |
| C-5 | Existing alarm evaluator; automatic evaluation proof in 27.16, not another implementation |
| C-6, C-7 | Existing usage-plan and Cognito-domain APIs; no repeat implementation. Remaining unknown-domain response is new 29.8 |
| C-8, C-9 | Keep existing SDK endpoint routing and Lambda environment injection |
| C-10 | No local throttling claim, no speculative retry simulator |
| C-11 | Optional existing docs-only 9.5; no new Cognito operation |
| X-1 | Asset upload and groundzero certificate/registrar create/delete are proven locally. Registrar update is new 31.6; remaining `Custom::AWS` and bucket proof are 27.6/27.7 |
| X-2 | Container/log/scheduler baseline is recorded; extend newly unblocked path evidence in 27.16 |
| X-3 | Keep fresh runs; optional reuse qualification 30.5, without reopening the closed leak fix |
| X-4 | Intrinsic/tag fix is delivered; exact emitted-template/property proof in 27.3/27.16 |
| X-5 | Real shadow HTTP/publish/rule proof in 27.16; reserved-event behavior stays 19.x |

## Recorded 2.1.0 adoption, not new work

`PLAN.md` section 6.6 and `ISSUES.md`'s 2026-09-17 status section record:

- Release source `560b3e4aa`, image
  `floci/floci:2.1.0@sha256:f5aa8c18302cedb4f2385f5c4e455b3efc77fee6bf7b6e5d1712b2817ba102db`.
- 165 narrow subtests with no skips. The three-service run passed: building
  4 passes/1 LCS skip, collector 1 pass, event 4 passes. Containers/networks cleaned up.
- Actual dashboard and event-invoke read-back, followed by removal of those two
  stub tolerances. MetricFilter remains the only tolerated type.
- The event writer's deployed SQS mapping retained batch size and
  `ReportBatchItemFailures`, but lost its declared 30-second batching window.
  This is execution evidence for P-22, not proof of that setting working.

These are attributed source run records, not tests rerun by this reconciliation.
27.1 is a new release-contract follow-up, not redoing the pin. 27.16 adds evidence
for newly unblocked paths instead of relabeling the old run as new coverage.
The source run used TEOS `20e10c182` plus the pin change; no merged TEOS PR is
inferred from its dirty working-tree state.

The later sections 6.7/6.8 add a measured failed nonempty-bucket deletion (missing
auto-delete tag) and a successful groundzero deploy/undeploy. Groundzero's own
registration row is in DynamoDB Local and is removed on delete. Four CFN DNS
records are absent; only the CDK-created validation record exists. Registration
update and device transport were not exercised. The final source also records
the DynamoDB Local 3.3.1 image-list pin and completed W-19 safeguards.

The source introduced two non-emulator follow-ups: resolving copied/
inherited config before cbdeploy's safety check (31.8, now completed), and correcting
the false dependency-check claim in deployment docs (31.9). Code signing and DSQL
were disabled for the recorded groundzero run; no local signing-enforcement or
DSQL claim follows from that run.

## Completed implementation plans retained as history

`PLAN_FLOCI_ENHANCED_IMPL.md` explicitly says it was executed on 2026-09-03.
Its task numbers are source-local, not the Floci task IDs. All five-step
test/implement/commit sequences below are historical, including the final push/PR
instructions. They authorize no new commits or PRs during this reconciliation.

| Source-local task | Delivered scope | Remaining delta owner |
| --- | --- | --- |
| Enhanced 1 | `cbenv` deployment-target constants/parser and tests | Retain; no new target abstraction |
| Enhanced 2 | CDK Go Lambda target and DynamoDB endpoint injection | Retain; 27.2 qualifies additional TLS/trust |
| Enhanced 3 | cbdeploy emulator retain warning | 27.9 removes it only after Task 16 behavior is qualified |
| Enhanced 4 | Withdrawn 256 KiB SQS cap | Dropped; keep AWS's 1 MiB limit, no new task |
| Enhanced 5 | Pump mapping model and CFN template parser | Completed 28.2 guard retained; remaining proof 31.7, not another parser |
| Enhanced 6 | Stack/resource discovery across emulator and DynamoDB Local | Retain; 23.x must not prematurely replace template discovery |
| Enhanced 7 | Lambda DynamoDB event-shape conversion | Retain binary, nested attributes and omitted-image behavior |
| Enhanced 8 | Batch invocation, partial failures, bisection, retry and SQS failure sink | Completed 28.2/28.3 retained; new residual checks 31.7 |
| Enhanced 9 | DynamoDB Local pump, shard ordering, lifecycle and statistics | New 31.7 lifecycle qualification; not Floci-native stream polling |
| Enhanced 10 | Real DynamoDB Local/Floci integration and benchmarks | Extend existing checks when behavior changes; do not recreate them |
| Enhanced 11 | Lint, docs, verification and delivery | Historical completion, not an outstanding umbrella PR |
| Local-services 1-8 | Local service-test integration, fixtures and workaround wiring | New Task 27 qualification/removal leaves |
| Monitor-datapath 1-4 | Monitor test helpers, watermark and deployed data-path test | Retain; 27.16 runs it without relabeling fixtures as workarounds |
| DDB-pump design | Architecture and limitations of the delivered external pump | Completed 28.1-28.3 and new residual 31.7; not a second implementation backlog |

## Outstanding legacy-driver migration

PLAN.md work-order step 3 is distinct from the completed service harness and
was still explicitly not started. Task 32 carries its caller migrations,
zero-caller driver deletions, shared Docker functions with real consumers and
retained image pinning. The current sweep finds sixteen calling test files in
fifteen packages rather than the historical fourteen-file count.

The source's floating awsmock/MinIO/ElasticMQ images disappear with their drivers;
do not add speculative interim pinning PRs. The retained Jena/Fuseki image gets
32.22. Mosquitto/Neptune and DynamoDB Local remain. The existing driver methods
are `New`, `Start`, `Stop` and `AwsConfig`, not the older plan's pseudo-API.

The enhanced plan specifies no standalone virtual-clock, fault-injection, reset,
SNS, generic service-enablement or native-DynamoDB rewrite project. Do not invent
those tasks from its title. The separate user-requested DynamoDB integration
research is [Task 34](../dynamodb-local/README.md), not a reinterpretation of
this completed enhanced plan. The completed report recommends a user-owned
external Local endpoint serving all callers, with real Streams consumption,
not bundling the AWS server or merely proxying HTTP. It documents licensing
restrictions and the delivery work still required before removing TEOS's pump.

## Root ISSUES coverage and source-retirement boundary

[The root-issue plan](../teos-root-issues/README.md#complete-root-issue-disposition)
maps every numbered section and each unnumbered section-4/5 item to an existing
task, a new 33.x leaf, the DynamoDB investigation, or an explicit keep/defer/
out-of-scope decision. Correct hostname formatting, near-limit file size, general
benchmark policy and the rejected CI proposal are not silently scheduled.

All actionable Floci/local-integration requirements in the completed source cut
are represented. This is not an archival copy of all analysis or run logs.

**2026-09-21, retired.** The owner removed every file in TEOS
`design-in-progess/floci/` except `TEST_PLAN.md`, on branch
`feature/floci-test-env`; the old files remain in TEOS git history. The scan
script and its watch list were dropped, because the owner tracks releases by
hand in this ledger. `.vscode` stays out of version control by design. TEOS
references to the old files became `floci: Missing Implementation for` markers,
listed under Task 27 of the task index.

## Research evidence, not new observed failures

The [DynamoDB report](../dynamodb-local/RESEARCH.md#3-the-originating-teos-issues)
traces the implementation beyond the root summary: existing-index validation is
not full schema equality, the deployment-time copy can copy items, and table
enumeration is unpaginated. Keep those boundaries visible in 31.6/31.7 and the
backend decision. Do not claim a general replica or a proven ordering barrier,
or silently replace the completed mirror task with a larger replication project.

The same research found native Floci conditional-write locking/tests, but ran
no comparative failure reproduction. TEOS's choice of Local is not proof of a
new Floci data-correctness defect. AWS's license is not the SDK's Apache license;
the external-endpoint recommendation avoids redistributing the Local server but
does not give blanket legal approval for embedding, bundling or hosted use.

## Selected execution plan, 2026-09-18

The user selected B native Streams delivery, C native-only backend preparation
and D the externally supplied Local adapter, and explicitly chose preservation
of multi-account/multi-region isolation. The decision is recorded as 34;
one-PR execution leaves are 35.1-35.4, 36.1-36.4 and 37.1-37.7. The existing
23.1 PR remains the sole CFN mapping-property owner.

The selected plan excludes Floci-managed Local downloads/containers/lifecycle,
server bundling, the native-correctness estimate A and a separate qualification
campaign. Focused implementation checks and safe removal gates remain mandatory.
Native is the default; incomplete Local slices remain dormant until 37.5.
TEOS's old pump enhancements 33.12-33.16 are deferred unless an explicit interim
consumer justifies one. This avoids implementing two replacement delivery engines.

The dated research remains evidence, not the current task index. In particular
its possible managed-sidecar R8 is not selected. Nothing here claims code is
implemented, a PR is opened or legal redistribution permission was obtained.

The user's follow-up explicitly adds a **TEOS-owned** pair in 37.7, not a
Floci-managed sidecar. `WithDynamoDBLocal()` starts the pinned Local companion
first, and its Stop/Close/rollback/keep ownership follows the Floci helper.
37.6 consumes that option and deletes the independent harness owner plus the
old mirror, host pump and per-service endpoint wiring after the gates pass.
With the option absent the generic driver remains Floci-only. The added helper
scope is 1-2 days: D is now 10-19 and the selected total is 24-44 days.
