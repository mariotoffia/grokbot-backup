# Task 3: IoT domain configurations (API + provisioner)

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

Branch `feat/iot-domain-configuration`. Title `feat(iot): domain configurations`. Independent of Tasks 1 and 2 in code; groundzero needs all three. API and provisioner in one PR because neither is useful alone; say so in the description.

API half:
- [x] Model `services/iot/model/IotDomainConfiguration.java`: `domainConfigurationName`, `domainConfigurationArn`, `domainName`, `serviceType`, `domainConfigurationStatus`, `serverCertificates` (list of `{serverCertificateArn, serverCertificateStatus}`), `authorizerConfig`, `domainType`, `lastStatusChangeDate`, `tlsConfig`, `serverCertificateConfig`, `authenticationType`, `applicationProtocol`, `clientCertificateConfig`, tags. No `createdDate`: `DescribeDomainConfiguration` has none on AWS.
- [x] Store through `StorageFactory` in `IotService` (see how `topicRuleStore` is created, line ~99), key `domain-configuration:<region>:<name>`.
- [x] `IotService`: `createDomainConfiguration` (name pattern `^[\w.-]+$`, 1..128; the `iot:` prefix is reserved; at most one `serverCertificateArns` entry; `serviceType` default `DATA`; `domainType` `CUSTOMER_MANAGED`; ARN `arn:aws:iot:<region>:<acct>:domainconfiguration/<name>/<short random id>` stored at create), `describeDomainConfiguration`, `updateDomainConfiguration` (`domainConfigurationStatus`, `authorizerConfig`, `removeAuthorizerConfig`, `tlsConfig`, `serverCertificateConfig`, `authenticationType`, `applicationProtocol`, `clientCertificateConfig`; touch `lastStatusChangeDate` on a status change), `deleteDomainConfiguration` (refuse with `InvalidRequestException` while `ENABLED`, as AWS does), `listDomainConfigurations(region, serviceType, marker, pageSize)` returning `domainConfigurations[]` + `nextMarker`. Unknown name: `ResourceNotFoundException`, 404. Duplicate create: `ResourceAlreadyExistsException`, 409. `CreateDomainConfiguration` has no status parameter: every new configuration is `ENABLED`.
- [x] `IotController`: routes `POST /domainConfigurations/{name}`, `GET /domainConfigurations/{name}`, `PUT /domainConfigurations/{name}`, `DELETE /domainConfigurations/{name}`, `GET /domainConfigurations?marker=&pageSize=&serviceType=`. Always serialise `domainConfigurationStatus`, `domainType`, `serviceType` and `serverCertificates[]` in the describe response: the Go SDK reads an omitted enum as `""`, and TEOS's `enable-iot-domain` then loops to its 60-second timeout.
- [x] Extend `taggableForArn` with `domainconfiguration/` so `TagResource`/`UntagResource`/`ListTagsForResource` work on the ARN.
- [x] Unit tests for the service; an integration test driven with the AWS SDK client, not hand-made HTTP (AGENTS.md rule); add the TEOS-shaped `DescribeDomainConfiguration` and `UpdateDomainConfiguration{DomainConfigurationStatus: ENABLED}` calls to `compatibility-tests/sdk-test-go/tests/iot_test.go`.

Provisioner half:
- [x] `IotDomainConfigurationCfnProvisioner` (as merged in #3008: its own class next to an `IotDomainConfigurationService` and `IotDomainConfigurationController`; Task 4's `IotCfnProvisioner` is a separate class for Thing, Policy and TopicRule) for `AWS::IoT::DomainConfiguration`: map `DomainConfigurationName` (stable through `ctx.stablePhysicalName`), `DomainName`, `ServiceType`, `ServerCertificateArns`, `AuthorizerConfig`, `TlsConfig`, `Tags`. Create, then if the template says `DomainConfigurationStatus: DISABLED` apply it with an update (AWS's CFN handler does the same; TEOS's `domain.go` sets no status, so the configuration is `ENABLED` and `enable-iot-domain`'s `DISABLED` branch is defensive). `DomainConfigurationName`, `DomainName`, `ServiceType`, `ServerCertificateArns`, `ValidationCertificateArn` are createOnly: a change is create-new then disable-and-delete-prior. Physical id: the name. Attributes: `Arn`, `DomainType`, `ServerCertificates` (a list on AWS; Floci's attribute map is `String`, so a JSON string; note it in `tools/docs/cfn_resource_types.yaml`).
- [x] Delete: set `DISABLED` first, then delete, each tolerating `ResourceNotFoundException`.
- [x] Docs: state in `docs/services/iot.md` that a custom domain changes nothing about the broker's listen address; DNS is outside Floci.
- [x] Checklist in [../README.md](../README.md).

TEOS check: deploy groundzero locally (design section 5, item 4). The `enable-iot-domain` script must exit 0 within its 60-second budget.

Size: about 300 lines plus tests.
