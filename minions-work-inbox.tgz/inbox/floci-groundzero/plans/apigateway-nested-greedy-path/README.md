# Greedy path parameter below a path parameter: implementation plan

**Goal:** A REST API resource whose rest-of-the-path parameter (greedy path
parameter, `{name+}`) comes after an ordinary path parameter, such as
`/v1/admin/catalog/{kind}/{name+}`, must route requests and fill both path
parameters the way AWS API Gateway does.

**Architecture:** One change in the REST API (API Gateway v1) request router,
`ApiGatewayExecuteController`. The greedy matcher compares the part of the
resource path before the greedy segment segment by segment, with the same rule
the single-segment template matcher already uses, instead of as a literal text
prefix. Path parameter extraction fills the ordinary parameters before the
greedy segment as well. Nothing else changes.

**Tech stack:** Floci Java/Quarkus, the existing API Gateway unit and
integration tests, and TEOS Go for the marker removal.

Status: [Task 44.7](../../TEOS_GROUNDZERO_TASKS.md#task-44-api-gateway-cognito-iot-and-lambda-gaps-behind-teos-workarounds);
TEOS removal [27.33](../../TEOS_GROUNDZERO_TASKS.md#task-27-teos-adoption-and-workaround-retirement).
`SRC` means `src/main/java/io/github/hectorvent/floci`; `TEST` means
`src/test/java/io/github/hectorvent/floci`. Other paths start at the owning
repository root. Recorded 2026-10-12.

## What a person sees

TEOS's IAM admin API (Thiink-LLC/teos#1048) manages its catalog of scopes,
claims and packs through these routes:

- `GET /v1/admin/catalog/{kind}`, which lists the rows of one kind;
- `GET`, `PUT`, `DELETE` and `PATCH` on `/v1/admin/catalog/{kind}/{name+}`,
  which work on one row. `{kind}` is `scopes`, `claims` or `packs`. `{name+}`
  is the row's name. A scope name always contains a `/`, for example
  `teos/sur-df`, so it must be the rest of the path. API Gateway turns `%2F`
  back into `/` before it matches a route, so a scope name never fits one path
  segment.

On Floci, a request such as `GET /v1/admin/catalog/scopes/teos/sur-df` reaches
no resource. The emulator answers 403 `{"message":"Missing Authentication Token"}`
and never calls the admin Lambda. `GET /v1/scopes/{name+}` works, because
everything before its greedy segment is plain text.

So TEOS cannot test the catalog row routes through API Gateway locally. Its IAM
service test sends those four requests straight to the `iam-admin-api` function
on the local target. It sends them as the event API Gateway would send, with the
access token's claims where the Cognito authorizer puts them. A local run
therefore never checks API Gateway's routing, or its token check, on those
routes. Only a run against AWS does.

## What AWS does

AWS allows a greedy path parameter only as the last segment of a resource path.
The parent resource above it may contain ordinary path parameters. A request
matches the resource when two things hold:

- its first segments match the parent's segments, where a literal segment
  matches only itself and a `{param}` segment matches any one segment;
- it has at least one more segment after them.

The proxy integration event then carries:

- `resource`: the resource path;
- `pathParameters`: every ordinary parameter, plus the greedy one holding the
  rest of the path. For `/v1/admin/catalog/scopes/teos/sur-df` that is
  `{"kind": "scopes", "name": "teos/sur-df"}`.

**Measure this on AWS before changing Floci.** The TEOS service test has not run
against AWS yet. Do this:

1. Import a two-resource API (`/a/{x}` and `/a/{x}/{y+}`, `MOCK` or Lambda proxy
   integrations).
2. Call `/a/one/two/three`.
3. Record the matched resource and the event's `pathParameters`.
4. Call `/a/one` and confirm it goes to `/a/{x}`.
5. If AWS answers differently from this section, change this plan before
   writing code.

## Evidence in the Floci source

Read on `upstream/main` `03a0dfefd`, in `SRC/services/apigateway/ApiGatewayExecuteController.java`.

1. **`matchResources` (line 3982), step 3, the greedy matcher.**
   - It takes the resource's parent prefix from `greedyParentPrefix` (line 4072), the text before the greedy segment. For `/v1/admin/catalog/{kind}/{name+}` that is `/v1/admin/catalog/{kind}/`.
   - It accepts a request only when `requestPath.startsWith(parentPrefix)`.
   - A real request path never contains the text `{kind}`, so such a resource never matches.
2. **`matchResources`, step 2, the single-segment template matcher.** It deliberately skips greedy resources (`greedyParentPrefix(r.getPath()) == null`), so nothing else picks the resource up. No resource matches, and the controller answers 403 "Missing Authentication Token".
3. **`extractPathParams` (line 4112).**
   - It returns no parameters at all when the template and the request have different numbers of segments (`tParts.length != rParts.length`).
   - For a greedy resource the request usually has more segments, so even after the match is fixed, `kind` would be missing from `pathParameters`.
   - `greedyPathParam` (line 4093) already finds the greedy value by segment index, so it is correct as it is.
4. **Callers that combine the two extractors:** lines 604-605, 713, 880, 1228, 1363-1364, 1699-1700, 2284-2285 and 3920-3921. They cover the Lambda proxy event, the non-proxy mapping templates, the authorizer input and the other integration types. All of them get the fix through the two functions; none parses paths itself.
5. **The proxy-match sort (lines 4016-4020)** orders greedy candidates by the length of the parent prefix text. With parameters in the prefix, text length no longer says which candidate is more specific.

The HTTP API (API Gateway v2) router is not affected. It compiles route
templates to regular expressions, with `(.+)` for a greedy segment. That code is
`PathTemplateResolver` and the route matching near line 2565 on local `main`.

## The change (one Floci PR)

Branch from `upstream/main`. PR title:
`fix(apigateway): route greedy resources below a path parameter`.

1. **Match greedy resources segment by segment.** Add a helper,
   `greedyParentMatches(String resourcePath, String requestPath)`:
   - Split both paths on `/`.
   - The resource's parent segments are every segment before the terminal greedy one.
   - Each parent segment must match the request segment at the same index: a literal by equality, a `{param}` by any non-empty segment.
   - The request must have at least one non-empty segment after the parent, except for the root `/{proxy+}`, which matches everything, as today.

   Use it in step 3 of `matchResources` in place of `startsWith`. A resource whose parent is all literals must behave exactly as today.
2. **Order greedy candidates by specificity.** Compare them segment by segment from the left: a literal segment is more specific than a parameter at the same position. Then prefer more parent segments. This keeps today's order wherever all parents are literal: the longest prefix wins. It adds one rule: `/a/b/{proxy+}` beats `/a/{x}/{proxy+}` for `/a/b/c`. Confirm that rule in the AWS measurement above, or leave the two candidates in declaration order and say so in the code.
3. **Extract the ordinary parameters before the greedy segment.** In `extractPathParams`, when the template ends in a greedy segment, read every `{param}` at index `i < greedyIndex` from the request segment at index `i`, even when the segment counts differ. Keep skipping the greedy segment itself, because `greedyPathParam` adds it. Non-greedy templates keep the equal-count rule.
4. **No other code changes.** The callers listed in the evidence section get both fixes through the two functions.
5. **Docs.** Where the API Gateway docs list path matching rules (search `docs/` for `proxy+`), add one sentence: a greedy parameter may follow ordinary path parameters.

## Tests

Put them in the same PR.

- **`TEST/services/apigateway/ApiGatewayProxyMatchTest.java`**, next to `longestParentPrefixWins`:
  - `greedyResourceBelowAPathParameterMatches`: `/v1/admin/catalog/{kind}/{name+}` matches `/v1/admin/catalog/scopes/teos/sur-df`.
  - `listResourceStillWinsForItsOwnPath`: `/v1/admin/catalog/{kind}` wins for `/v1/admin/catalog/scopes`, and the greedy resource does not match it, because there is no segment after the parent.
  - `literalParentBeatsParameterParent`: the step 2 rule, or the documented declaration order.
  - `greedyBelowParameterNeedsASegmentAfterTheParent`: `/v1/admin/catalog/scopes/` does not match the greedy resource.
  - The existing tests still pass unchanged, which shows literal-parent behaviour is unchanged.
- **`TEST/services/apigateway/ApiGatewayGreedyPathParameterIntegrationTest.java`**, a new case:
  - Import an API with `/v1/admin/catalog/{kind}` and `/v1/admin/catalog/{kind}/{name+}`, both Lambda proxy.
  - Call `GET /v1/admin/catalog/scopes/teos/sur-df`.
  - Assert that the event has `resource` `/v1/admin/catalog/{kind}/{name+}` and `pathParameters` `{"kind": "scopes", "name": "teos/sur-df"}`.
  - Call `GET /v1/admin/catalog/scopes` and assert that it reaches the list resource with `{"kind": "scopes"}`.
  - Add one request whose name was sent as `teos%2Fsur-df` and assert the same event, because the router works on the decoded path.
- **A mapping-template case:** a non-proxy integration reading `$input.params('kind')` on the greedy resource gets `scopes`. This covers the line 713 path.
- **An authorizer case:** if a test class for authorizer input on greedy resources already exists, add `kind` to its expected `pathParameters`. Do not add a new class just for this.

**Acceptance:**
- The integration test above passes.
- All existing API Gateway tests pass.
- The TEOS IAM service test passes on an image with the fix after 27.33 deletes its workaround.

## TEOS removal (27.33, one TEOS PR after the fix is in the pinned image)

- **File:** `go-services/core/management/iam/deployment/service-test/admin_function_test.go`, added by Thiink-LLC/teos#1048. Search for the marker `floci: Missing Implementation for greedy path parameters below a path parameter in API Gateway.`
- **Delete the local branch in `catalogRow`.** Every request then goes through API Gateway with `a.call`.
- **Delete the code only that branch needs:** `invokeAdminFunction`, the proxy event and answer types and `catalogRowResource`.
- **Run the test locally:** `CB_SERVICE_TEST=iam-service make test-service` from the TEOS repository root must pass on the local target with the requests going through API Gateway.
- **Remove the marker row** from the Task 27 marker table.
- **PR title:** `test(iam): route catalog row requests through API Gateway on Floci`.

## Estimate

- Floci fix with tests: about half a day.
- AWS measurement: about one hour, needing an AWS account to deploy a throwaway REST API.
- TEOS removal: about one hour, plus one local service-test run.
