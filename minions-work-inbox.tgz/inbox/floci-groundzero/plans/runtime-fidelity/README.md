# Runtime fidelity implementation plan

**Goal:** Remove the Floci gaps behind TEOS's local workarounds without rebuilding
features already delivered.

**Architecture:** Keep AWS wire handlers thin and fix behavior in the shared service
path. Reuse existing storage, routing, scheduling and test helpers. Each numbered
leaf below is one Floci PR, including its regression test and service documentation.

**Tech stack:** Java, Quarkus, JUnit, AWS SDK compatibility clients.

Status lives in [the task index](../../TEOS_GROUNDZERO_TASKS.md).
[PR rules](../README.md#pr-boundaries-for-outstanding-work) apply.
These are reconciled implementation boundaries, not claims that old source observations
still reproduce on today's upstream `main`.

## File map and common acceptance

Paths below are relative to Floci. `SRC` means
`src/main/java/io/github/hectorvent/floci`; `TEST` means
`src/test/java/io/github/hectorvent/floci`.
Service SDK scenarios belong in `compatibility-tests/sdk-test-java`.
Update the affected `docs/services/<service>.md` and run `make docs-sync` when
operations or the generated CloudFormation inventory change.

For each leaf, reproduce its specific gap on the intended base before changing
production code. If it already works, retain that implementation and land only
missing regression coverage or TEOS qualification, with the containing revision
recorded. Do not manufacture a second fix from an old unchecked source box.

## 8.2: API Gateway custom-host routing

**Files:** `SRC/services/apigateway/ApiGatewayCustomDomainFilter.java`,
`SRC/services/s3/S3VirtualHostFilter.java`, and the matching routing tests.

Mark the custom-domain rewrite and have S3's virtual-host filter respect it,
reusing the existing Cognito routed-request pattern. Prove GET and POST through
the same custom domain/base path reach the deployed integration, while an ordinary
S3 virtual-host GET still reaches S3. No dependency on certificate registration or
the new SigV4 core; the TLS/domain provisioners are already delivered.

## 15.1 to 15.3: SSM

**Files:** `SRC/services/ssm/SsmService.java`, its JSON handler and parameter model,
the SSM CloudFormation provisioner, and `TEST/services/ssm/`.

| PR | Scope | Required proof | Predecessor |
| --- | --- | --- | --- |
| 15.1 | Normalize resource ARNs for parameter names with and without a leading slash | SDK read-back and CFN `Arn` agree; no double slash or missing `parameter/` | None |
| 15.2 | Emit `aws.ssm` / `Parameter Store Change` from successful create, update, delete, batch-delete and label mutations | SDK mutation alone reaches an EventBridge rule and SQS; failed mutations emit nothing; downstream failure does not roll back an accepted SSM write | 15.1 only if correct ARN generation is still absent on `main` |
| 15.3, completed | Service-side creation tags and `Path`/`tag:` DescribeParameters filtering | Source records floci-io/floci#3550 and floci-io/floci#3646 in 2.1.0 | Do not reopen; CFN tag forwarding is new 29.9 |

The earlier CFN `Arn` attribute work is not ARN-normalization proof. Preserve TEOS's
correct `GetParametersByPath` and its IAM permissions. Removing
`injectSSMParameterChangeEvent` is a separate TEOS PR after image qualification,
not a second commit hidden in 15.2's Floci PR.

Run: `./mvnw test -Dtest=SsmServiceTest,SsmIntegrationTest`.
Add the event-flow case to the owning existing integration suite in the same PR.

## 16: RetainResources

**Files:** `SRC/services/cloudformation/CloudFormationQueryHandler.java`,
`CloudFormationService.java`, and the CloudFormation deletion integration tests.

Carry Query `RetainResources.member.N` into deletion with AWS's stack-state and
logical-ID validation. Test the eligible failed-delete case with real retained
data and an unretained sibling. No backing delete may run for the retained item;
genuine sibling failures and template deletion policies still apply.

The TEOS watch source contains a desired scan predicate, not proof of an upstream
fix. Check the containing revision before implementing this older task. Removing the warning in TEOS
`go-services/appstore/cmd/cbdeploy/internal/cfn/cloud_undeploy.go` is a new
qualification/cleanup PR, not reopening the merged upstream work.

## 17.1 to 17.5: Tag-based discovery

**Files:** `SRC/services/resourcegroupstagging/ResourceGroupsTaggingService.java`
and each owning service's create/tag/untag/delete paths; tests in
`TEST/services/resourcegroupstagging/` and the affected service package.

| PR | Single ownership boundary | Dependencies |
| --- | --- | --- |
| 17.1 | Resource-type parsing, including API Gateway `/apikeys/<id>` ARNs and service-only filters | None |
| 17.2 | SQS queue tags discoverable through GetResources | None |
| 17.3 | Lambda function tags discoverable through GetResources | None |
| 17.4 | CloudWatch Logs log-group tags discoverable through GetResources | None for registration; 17.1 must merge before TEOS's `logs:log-group` filter matches |
| 17.5 | API Gateway tags discoverable through GetResources | 17.1 must merge for exact resource-type-filter assertions |

Use the existing service registration mechanism. Do not create a second tag store,
TEOS-only resource query or an extensibility framework for these four integrations.
If shared plumbing is genuinely missing, put only the minimal reusable change in
the first owning PR and record it as a merge prerequisite for its consumers.

Every service PR covers creation tags, explicit tag/untag, deletion, CFN creation,
persistence reload, pagination and account/region isolation with SDK GetResources.
Use TEOS's `sqs:queue` plus `fd`/`pn`/`pt` filters in the queue case.
Run the existing `ResourceGroupsTaggingIntegrationTest` and
`ResourceGroupsTaggingServicePersistenceTest` with the owning service regression.
A discovered resource must then be used, not only counted.

### 17.4 evidence: log groups are not found by their tags

Read on Floci `main` `570f975829ab30f2cf2447985fa425e7a9df3b7b` on 2026-09-23.

**Problem.** TEOS lists log groups by tag through the Resource Groups Tagging
API (`GetResources`). Floci returns nothing for a log group that was created
with that tag, so TEOS cannot find its own log groups by tag on the local target.

**Evidence.**

- The tagging service answers `GetResources` only from its own store
  (`SRC/services/resourcegroupstagging/ResourceGroupsTaggingService.java:24`,
  read at `:104`). That store is written only by `tagResources`,
  `untagResources` and `deleteResources` (`:56`, `:71`, `:82`).
- The only services that write to it are the tagging API itself
  (`ResourceGroupsTaggingJsonHandler.java:30-31`), EventBridge
  (`SRC/services/eventbridge/EventBridgeService.java:167`, `:328`, `:502-562`)
  and Glue (`SRC/services/glue/GlueService.java:134`, `:1088`, `:1199`, `:1270`).
  RDS only reads it (`SRC/services/rds/RdsService.java:5887`).
- CloudWatch Logs never references the tagging service. Its constructor takes no
  such dependency (`SRC/services/cloudwatch/logs/CloudWatchLogsService.java:92-95`).
  Tags live only on the stored log group:
  - `CreateLogGroup` tags: handler `CloudWatchLogsHandler.java:88-90`, stored at
    `CloudWatchLogsService.java:209-212`;
  - `TagLogGroup` and `TagResource`: handler `:502-505` and `:540-544`, both into
    `tagLogGroup` (`CloudWatchLogsService.java:291-298`);
  - `UntagLogGroup` and `UntagResource`: `untagLogGroup` (`:300-306`);
  - `ListTagsLogGroup` and `ListTagsForResource`: `listTagsLogGroup` (`:339-344`);
  - `deleteLogGroup` (`:216`) leaves nothing to remove from the tagging store.
- CloudFormation-created groups take the same path: `LogsCfnProvisioner.java:79-104`
  passes the template's `Tags` to `createLogGroup`.
- SQS, API Gateway and Lambda also have no reference to the tagging service, which
  is the same cause as 17.2, 17.3 and 17.5.
- Second, separate cause: the resource-type filter. Floci builds the log-group ARN
  as `arn:aws:logs:<region>:<account>:log-group:<name>`
  (`CloudWatchLogsService.java:1029`). `matchesResourceTypeFilters` takes the text
  before the first `/` of the resource part as the type
  (`ResourceGroupsTaggingService.java:150-153`), giving `log-group:<name>` or
  `log-group:` for a name that starts with `/`. Neither equals `log-group`, so the
  filter `logs:log-group` never matches, even for a group tagged through the
  tagging API. That is 17.1's colon-delimited resource-type work.

**TEOS test affected.** `TestListLogGroupsByPrefixAndTag`, subtest "by tag", in
`go-core/managers/mgrlog/clwlog/loggroup_integration_test.go` (TEOS branch
`test/retag-aws-tests-integration`, commit `ceaac3704`, PR #856). It is skipped on
the local target under the marker
`floci: Missing Implementation for CloudWatch Logs log groups found by tag.`
The code under test is `getLogGroupsFromTags` in
`go-core/managers/mgrlog/clwlog/loggroup.go`, which calls `GetResources` with
`ResourceTypeFilters: ["logs:log-group"]` and the caller's tag filters, then
`DescribeLogGroups` for each group found.

**Floci change.** Inject `ResourceGroupsTaggingService` into
`CloudWatchLogsService`, as EventBridge and Glue do, and keep both stores in step
on every path: `tagResources` with the log-group ARN on create (when tags are
given), `tagLogGroup`; `untagResources` on `untagLogGroup`; `deleteResources` on
`deleteLogGroup`. The owning service remains the source of truth for
`ListTagsLogGroup`/`ListTagsForResource`. Register the ARN in the same form AWS
returns from `GetResources` (no trailing `:*`), because TEOS takes the text after
the last `:` as the group name.

**Verify.**

1. Floci: a service regression plus an SDK `GetResources` scenario covering
   create-with-tags, `TagResource`, `UntagResource`, delete, CloudFormation
   creation and persistence reload, with the filter `logs:log-group` once 17.1 is in.
2. CLI probe against a running Floci:

   ```bash
   aws --endpoint-url http://localhost:4566 logs create-log-group \
     --log-group-name /probe/tagged --tags purpose=probe
   aws --endpoint-url http://localhost:4566 resourcegroupstaggingapi get-resources \
     --resource-type-filters logs:log-group --tag-filters Key=purpose,Values=probe
   ```

   Today the second command returns an empty `ResourceTagMappingList`. Fixed, it
   lists `arn:aws:logs:<region>:<account>:log-group:/probe/tagged` with the tag.
   Delete the group afterwards.
3. TEOS: remove the skip, then run the `clwlog` integration tests on the local
   target; the "by tag" subtest must pass.

**TEOS removal step.** When 17.4 and 17.1 are in a pinned Floci image, search TEOS
for `floci: Missing Implementation for CloudWatch Logs log groups found by tag`
and delete the marker comment and the
`if testenv.Target() == cbenv.DeploymentTargetLocal { t.Skip(...) }` block it
labels in `loggroup_integration_test.go`.

## 18: ECR port allocation

**Files:** `SRC/services/ecr/registry/EcrRegistryManager.java`,
`TEST/services/ecr/registry/EcrRegistryManagerTest.java`.

Retry only Docker bind-conflict errors within the configured port range. Exclude
failed candidates, bound exhaustion by the range, and clean failed containers and
reservations. Other Docker errors fail immediately. A two-registry test must reach
both registries on different ports and assert useful exhaustion errors.

TEOS removes its single-port override only in its own later PR after this behavior
works in a containing image. A host free-port probe is not an atomic reservation.

## 19.1 and 19.2: Reserved IoT events

**Files:** `SRC/services/iot/IotDataController.java`, `IotService.java`,
`IotMqttBrokerService.java`, the existing rule engine and IoT integration tests.

19.1 sends successful HTTP and MQTT named/unnamed shadow changes through the shared
rule path, preserving MQTT fan-out, account/region, `clientToken`, version, timestamp
and exact reserved topic/payload. Define loop prevention at the event dispatch
boundary; do not recursively reevaluate every low-level broker publish.

19.2 emits AWS-shaped connected/disconnected presence events with real session
identity and disconnect reason, including abrupt loss and client-ID replacement.
It can land independently of 19.1 by using the existing rules entry point.

A deployed rule on `$aws/things/+/shadow/name/building/update/accepted` must deliver
the actual update's SQL projection to its target; a nonmatching `clientToken` must
not. Real MQTT connect/disconnect must drive the two tklocal presence rules.
No test-published reserved events. Keep Tasks 4, 5 and 7 completed.

## 20.1 to 20.5: Remaining resource types and authorizers

**Files:** Existing Cognito group and EventBridge archive services; their provisioners
under `SRC/services/cloudformation/provisioners/`; IoT controller/service and broker.
Use the provisioner inventory, fixture and schema-attribute checklist in `../README.md`.

| PR | Scope and acceptance | Predecessor |
| --- | --- | --- |
| 20.1 | `AWS::Cognito::UserPoolGroup`: create/update/delete and actual group read-back, preserving pool identity | None |
| 20.2 | `AWS::Events::Archive`: identity, source, pattern and retention read-back through lifecycle changes | None |
| 20.3 | IoT authorizer management API: persist and validate AWS settings, lifecycle/tag/SDK read-back | None |
| 20.4 | `AWS::IoT::Authorizer`: real resource lifecycle and exact `Ref`/`Fn::GetAtt` attributes | 20.3 merged |
| 20.5 | Invoke the configured authorizer Lambda on TEOS's transport and enforce allow/deny | 20.3 merged; uses SDK setup, so does not require 20.4 |

An archive provisioner does not prove replay execution. An authorizer definition
does not prove transport authentication. Never close P-9 solely on the WebSocket
transport or its existing provisioners.

## 20.6: CloudWatch Logs log stream provisioner

**Source:** TEOS ingestion service, found 2026-09-21 against release 2.1.0.
Its stack declares an `AWS::Logs::LogStream` (`FirehoseLogStream`) inside the
log group its Firehose delivery stream writes to. CloudFormation marks the
resource `CREATE_COMPLETE` without calling the Logs service, so no stream
exists; the TEOS service-test harness checks every deployed stack for such
pretended resources and stops the ingestion service test on this one.
**Files:** a new `services/cloudformation/provisioners/LogsLogStreamCfnProvisioner.java`
following the provisioner checklist in `plans/README.md`, using the existing
`CreateLogStream` and `DeleteLogStream` of the Logs service.

Provision creates the stream in the named group and sets the physical id to
the stream name; update with a changed name or group replaces it; delete
tolerates an already-deleted stream. Read the stream back with
`DescribeLogStreams` in the integration test rather than trusting stack
status. Record any unset attribute in `getatt-attribute-gaps.tsv`.

What a person sees today: `make test-service` for the ingestion service fails
before its tests run, with the harness message naming the resource. No
predecessor.

## 21: Asynchronous Lambda execution

**Files:** `SRC/services/lambda/LambdaExecutorService.java`, `LambdaService.java`,
the event-invoke model/configuration path and existing invocation tests.

Trace all asynchronous callers into the shared dispatcher. Honor the selected
function/version/alias settings for retry count, event age, success/failure
destinations and dead-letter delivery. Leave synchronous calls and SQS ESM retries
alone. Keep this as one bounded runtime PR using existing dispatch primitives,
not a general messaging framework or a test-only stack.

Prove handler failure, zero retries, successful execution, qualifier selection,
expiry and destination failure with controlled time and AWS destination records.
Read-back of Task 6.3's delivered settings is not execution proof. EventBridge
target-delivery retries remain a different task and must not duplicate accepted
Lambda invocations.

## 22: Conditional SQS URL strategy

**Files:** Existing SQS response URL construction and `SqsService.normalizeQueueKey`;
TEOS validators remain unchanged.

First use existing endpoint/base-address configuration to prove create, get and list
responses work from both host and launched Lambda clients without real-AWS traffic.
No new input parser is needed. Only if configuration cannot solve the response
shape, obtain approval for an opt-in AWS-shaped URL strategy preserving the current
default. The proposal and implementation are one conditional leaf, not an automatic
commitment to a new option. Keep the small TEOS fixture rewrites if no strategy is accepted.

## 23.1 and 23.2: CloudFormation event-source mappings

**Files:** `SRC/services/cloudformation/provisioners/LambdaEventSourceMappingCfnProvisioner.java`,
`TEST/services/cloudformation/provisioners/LambdaEventSourceMappingCfnProvisionerTest.java`,
Lambda integration tests and the SDK compatibility suite.

23.1 forwards only already-supported model options through CFN create/update/removal:
`FilterCriteria`, `MaximumBatchingWindowInSeconds`, `BisectBatchOnFunctionError`,
`DestinationConfig`, `MaximumRetryAttempts`, `MaximumRecordAgeInSeconds`,
`ParallelizationFactor` and `ScalingConfig`. Resolve whole/nested intrinsics using
existing helpers. SDK read-back must match create, update and removed properties.
35.1 now owns the missing `MaximumRetryAttempts` and
`MaximumRecordAgeInSeconds` service/API model fields. The complete 23.1 PR
waits for 35.1 to merge, then forwards those fields with its existing property
set. Do not add another CFN mapping implementation in Task 35.
For other fields absent from the model, preserve the explicit unsupported
boundary rather than silently accepting them. Preserve the already-forwarded
`FunctionResponseTypes`.

The estimate attributed to B for 35.1 plus the relevant 23.1 CFN share is
1-2 days total, split as 0.5-1 day each. The rest of 23.1's existing mapping
scope is not newly estimated or counted twice. SDK setup lets native delivery
PRs 35.2-35.4 proceed without waiting for this CFN PR.

23.2 is a separate runtime compatibility PR after 23.1 merges: a CFN-created SQS
mapping must apply filters and its batching window, discard nonmatches correctly
and honor partial failures. A bounded wait must reflect the configured window.
Do not bundle unsupported DynamoDB stream runtime work into either PR.
That runtime work is now explicitly planned in
[35.1-35.4](../dynamodb-streams/README.md), independently of the external Local
backend. Task 37.5 joins both runtime and CFN work before public release/adoption.

At local Floci `570f97582`, the CFN mapper lacks those property forwards and the
native DynamoDB poller uses Floci's own stream store. Keep the external pump and
template-based mapping discovery until both the data source and execution contract
are qualified, not merely because the mapping describes the right properties.

## 24.1 and 24.2: Lambda account references

The detailed root-cause and acceptance cases remain in
[Task 24](../../TEOS_GROUNDZERO_TASKS.md#task-24-the-account-in-a-lambda-function-reference).
24.1 repairs shared full/partial-ARN read/write ownership. 24.2 is a separate CFN
replacement PR only after 24.1 merges. Do not reopen completed Task 6.3 or revive
the unsafe replacement from the closed floci-io/floci#3249.
