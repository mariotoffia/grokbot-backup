# Deferred compatibility decisions

**Goal:** Retain outstanding source limits without silently approving large or
unneeded emulator projects.

**Architecture:** Keep the working local path unchanged. Each Task 30 leaf is a
separate conditional PR only after its trigger is met. A design-only leaf produces
a bounded decision/specification, not a hidden implementation stack.

**Tech stack:** Existing Floci service patterns and TEOS harness; no new dependency
or backend is selected by this reconciliation.

Status: [Task 30](../../TEOS_GROUNDZERO_TASKS.md#task-30-deferred-compatibility-decisions).
None of these blocks the first DSQL-disabled groundzero run.

## 30.1: Bounded IoT fleet search, F-3

**Trigger:** Device-search coverage is selected for local execution.
**Owner:** Floci. One bounded feature PR after 9.4 merges, not a full AWS indexer.

Use `services/iot/IotController.java`, `IotService.java`, the existing thing store,
broker session state and IoT SDK tests under the standard Floci source/test roots.
Implement the TEOS query subset: `thingName:`, `attributes.<key>:<value>`,
`thingTypeName:`, `connectivity.connected:true`, `AND` and `OR`. Validate unsupported
syntax honestly. Preserve AWS request/result shape, pagination, account/region
isolation and index-configuration semantics.

SDK tests create distinct things, update their attributes/types, connect/disconnect
a real device, and assert matching/nonmatching search results and pagination.
Index readiness alone is not acceptance. Do not infer general fleet-indexing
parity from this finite query subset; document the supported scope.
TEOS 27.20 then removes the `IoT fleet search` marker.

## 30.2: Alarm-service local database decision, F-4

**Trigger:** Local alarm-service execution is required.
**Owner:** TEOS. One design PR, not an assumed Postgres implementation.

Inventory alarm-service's actual Aurora DSQL calls and transaction/SQL assumptions.
Compare a real-account lane, waiting for Floci DSQL support, and a specifically
qualified local database substitute. State what each would and would not prove,
connection/credential isolation, lifecycle and the smallest reusable conformance
test. Keep DSQL off until the backend decision is explicitly approved.

Do not create an AWS-shaped convenience endpoint or silently claim Postgres is
DSQL. A selected implementation gets new independently scoped task IDs.

## 30.3: Resource-policy denial scope, F-8/W-8

**Trigger:** A selected test must prove an access denial, not merely successful
execution against permissive local APIs.
**Owner:** Floci. One scoped design/contract PR before additional implementation.

Inventory the selected SQS/Lambda/API Gateway resource-policy actions, principal
and condition combinations against existing `IamEnforcementFilter` and service
authorization. Separate authentication, SigV4 verification, identity policies,
resource policies and IoT device action authorization. Tasks 12-14 and completed
7.11 cover only their named paths; MQTT Connect does not imply Publish/Subscribe
authorization. Patch/read-back in 29.1 is not enforcement.

Define positive and negative SDK/transport cases and compatible defaults before
splitting actual service repairs into new PR units. No broad policy framework,
throttling emulator or encryption-at-rest redesign is authorized. Retain real-AWS
evidence for behavior the emulator still does not enforce.

## 30.4: AppSync CloudFormation inventory, F-9 remainder

**Trigger:** A selected local TEOS stack actually emits an AppSync resource.
**Owner:** Floci. One inventory/design PR; source says this remainder was unplanned.

List exact emitted types, required properties and `Ref`/`Fn::GetAtt` attributes,
then compare the current CDI provisioner inventory and existing AppSync APIs.
Reuse any already-landed support. Select only proven gaps and propose one PR per
independent missing resource family, with SDK read-back and update/delete cases.
No guessed full AppSync provisioner implementation from the old umbrella row.
Completed ACM Tasks 1/10 remain untouched.

## 30.5: Warm emulator reuse qualification, X-3

**Trigger:** Reuse is explicitly desired and the remaining upstream update/
collection issues have been resolved or no longer reproduce.
**Owner:** TEOS. One optional test/lifecycle PR.

Keep fresh per-run emulators until this gate passes. floci-io/floci#2211 is
recorded closed; floci-io/floci#2134 and floci-io/floci#2419 remain source watch
items, not approval to refactor CloudFormation here.

With the existing harness, repeat create/update/delete across runs containing
named resources and replacements. Assert no leaked resources or containers,
correct retained data and isolation between tests, with concurrency limited to
the scenario being qualified. Do not disable ForceStart merely because a stack
reaches DELETE_COMPLETE. If it fails, retain fresh runs and create a separate
reproduced Floci bug task rather than stacking a framework rewrite.

## Explicitly retained, not new tasks

| Source | Decision |
| --- | --- |
| F-6/W-4 | Keep DynamoDB Local and the external pump. Native internal-stream changes do not supply an external stream source |
| F-7/W-1 | Keep configured host/container endpoints. Task 22 covers only conditional AWS-shaped returned SQS URLs |
| F-10 | Firehose's documented newline addition is retained; no TEOS byte-level assertion requires changing it |
| W-5 | Keep arm64 local runs. No speculative x86/QEMU runner project |
| W-7/W-10 | No 256 KiB SQS override and no `cdklocal`; both proposals were withdrawn or unnecessary |
| W-18 | Keep real monitor activation/source-watermark fixtures. A production watermark publisher belongs to TEOS's own product backlog, outside Floci integration scope |
| Groundzero code signing | The successful local checkpoint disabled it. Existing empty configuration reads are not signing enforcement. Keep the real-account lane until a separate scoped feature is approved |
| C-1-C-4, C-6-C-10 | Retain existing constants, resource namespace, endpoint injection, IoT resolver and SDK behavior. No repeat implementation |
| C-5 | Automatic alarm evaluation exists; qualify it in 27.16, not a new alarm evaluator |
| C-11 | Cognito operations exist; optional documentation-only 9.5 remains the owner |
| X-1/X-2/X-4/X-5 | Keep completed 27.3; extend remaining custom-resource/template/runtime proof in 31.6, 27.6 and 27.16's separate leaves |
