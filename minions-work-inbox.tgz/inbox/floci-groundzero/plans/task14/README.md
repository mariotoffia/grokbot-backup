# Task 14: one SigV4 signer and verifier in core

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps: [../README.md](../README.md). Needed by Task 13.2 (the credentials the IoT credential provider mints must be verifiable) and by the SigV4 paths of Task 13.3 and PR 13 (#3150).

## Why

Floci carries six SigV4 implementations, each with its own canonical request builder, key
derivation, expiry rule and secret lookup, and the rest of the emulator only parses the access key
id, region and service out of the `Authorization` header (`SigV4CredentialScope`, `AccountResolver`,
`RegionResolver`) without checking the signature. Inventory on `upstream/main` 7a5ae965e:

| Class | Lines | Role today |
| --- | --- | --- |
| `services/apigateway/ExecuteApiSigV4Authorizer` | 624 | Full verifier for execute-api `AWS_IAM`: header and presigned query forms, canonical request rebuilt, constant-time compare, 5 minute skew, 7 day presign cap, session token check; 17 tests in `ExecuteApiSigV4AuthorizerTest` |
| `services/elasticache/proxy/SigV4Validator` | 213 | Presigned-URL verifier for the proxy, `iamService.findSecretKey` plus a legacy `test` secret; `SigV4ValidatorTest` |
| `services/rds/proxy/RdsSigV4Validator` | 215 | A near-identical copy of the ElastiCache one; `RdsSigV4ValidatorTest` |
| `services/eks/EksTokenValidator` | 241 | Verifies the presigned STS `GetCallerIdentity` inside an EKS bearer token; `EksTokenValidatorTest` |
| `services/lambda/launcher/kubernetes/EksTokenMinter` | 507 | The signing side of the same token |
| `services/s3/PreSignedUrlFilter`, `PreSignedUrlGenerator` | 455 | S3 presigned URLs verified and generated, `floci.auth.presign-secret` for Floci-made URLs, `floci.auth.validate-signatures` (default `false`) for SDK-made ones; presigned POST policy signing in `S3Controller`; `PreSignedUrlFilterTest`, three integration tests |

`IamService.findSecretKey(accessKeyId)` and `findSecretKey(accessKeyId, sessionToken)` already
resolve a secret for an IAM access key or an STS session, which is the one piece a shared verifier
needs from the outside.

The algorithm is the same in all six, run forwards (sign) or backwards (verify). One core package,
adapters per service, and the six shrink to the protocol-specific parts: which request fields to
read, which error to answer, which expiry rule applies.

## SigV4 facts the core must carry (from the AWS "Create a signed AWS API request" and "Authenticating requests (AWS Signature Version 4)" pages; re-read before coding)

- Canonical request: method, canonical URI, canonical query string, canonical headers, signed
  headers, payload hash, joined by newlines. String to sign: `AWS4-HMAC-SHA256`, `X-Amz-Date`,
  credential scope `<date>/<region>/<service>/aws4_request`, SHA-256 hex of the canonical request.
  Signing key: HMAC chain `AWS4` + secret over date, region, service, `aws4_request`.
- Canonical URI: every path segment URI-encoded twice for every service except S3, which encodes
  once and does not normalize `.` and `..` segments. Canonical query: names and values encoded
  (unreserved characters untouched, space as `%20`, not `+`), sorted by name then value, the
  `X-Amz-Signature` parameter left out in the query form. Canonical headers: lowercased names,
  values trimmed with sequential spaces collapsed, multi-valued headers joined with commas, sorted;
  `host` and `x-amz-date` (or `date`) must be signed.
- Payload hash: SHA-256 hex of the body; `UNSIGNED-PAYLOAD` is allowed on S3; the S3 streaming
  markers (`STREAMING-AWS4-HMAC-SHA256-PAYLOAD`, the `-TRAILER` and `STREAMING-UNSIGNED-PAYLOAD-TRAILER`
  variants) describe an `aws-chunked` body whose chunk signatures chain from the seed signature.
  `S3Controller.decodeAwsChunked` strips the chunks today without checking them; chunk-signature
  verification is an S3 adapter concern, not the core's, and can stay a documented gap.
- Header form: `Authorization: AWS4-HMAC-SHA256 Credential=<akid>/<scope>, SignedHeaders=...,
  Signature=...`, `X-Amz-Date` or `Date`, `X-Amz-Content-Sha256` (required on S3),
  `X-Amz-Security-Token` for temporary credentials, and the token must be among the signed
  headers. Query form: `X-Amz-Algorithm`, `X-Amz-Credential`, `X-Amz-Date`, `X-Amz-Expires`,
  `X-Amz-SignedHeaders`, `X-Amz-Signature`, optional `X-Amz-Security-Token`; `X-Amz-Expires`
  between 1 and 604800 seconds (7 days) per the SigV4 query-string page, and a request after
  `X-Amz-Date` plus `X-Amz-Expires` is expired.
- Skew: AWS answers `RequestTimeTooSkewed` (S3) or a signature failure when the request time is
  more than 15 minutes from the server's clock; execute-api's existing 5 minute window stays an
  adapter parameter, the core takes the window as an argument.
- Compare signatures in constant time. A wrong secret and a wrong canonical request are the same
  failure to the caller: AWS only ever says the signature does not match (S3
  `SignatureDoesNotMatch` 403 with the canonical request echoed in the XML, JSON services
  `InvalidSignatureException` 403 or `IncompleteSignatureException` 400, Query services
  `SignatureDoesNotMatch` 403, execute-api `{"message":"The request signature we calculated does not
  match the signature you provided. ..."}` 403). The core returns a typed failure; each adapter maps
  it to its protocol's error, so the core never formats a response.
- Not in scope: SigV4a (the asymmetric variant for multi-region access points); nothing in Floci
  needs it.

## Subtasks

Each one PR. 14.1 first; 14.2 to 14.4 and 14.7 are independent after it merges; 14.5 and 14.6 add
new verification and come last.

### 14.1 `refactor(core): one SigV4 signer and verifier`

- [ ] Package `core.common.sigv4`: `SigV4Request` (method, raw path, raw query pairs, headers,
      payload hash or body bytes), `SigV4Canonicalizer` (canonical request, string to sign; the S3
      path switch), `SigV4Signer` (signing key, signature, header-form `Authorization` and
      query-form parameters, for the generators), `SigV4Verifier` (parses both forms, resolves the
      secret through a `SecretResolver` interface (access key id, session token) to an optional
      secret and account, checks skew and expiry with per-call limits, compares in constant time,
      returns a `Result` with the caller identity or a typed `Failure`: missing, malformed, unknown
      key, expired, skewed, token mismatch, signature mismatch). Plain classes, no CDI in the
      canonicalizer and signer; the verifier gets its `SecretResolver` by constructor. The default
      resolver over `IamService.findSecretKey(akid, token)` plus the legacy `test` key lives in
      `services/iam`, not in core.
- [ ] Move `ExecuteApiSigV4Authorizer` onto the core: it keeps its class, its `Result` and
      `CallerIdentity`, its 5 minute window and its error text, and loses the canonical request
      and key derivation code. `ExecuteApiSigV4AuthorizerTest` runs unchanged: that is the proof the
      core reproduces the one verifier the project already trusts.
- [ ] Core tests against the AWS published test vectors (the `aws-sig-v4-test-suite` cases: `get-vanilla`,
      `get-vanilla-query-order-key-case`, `get-utf8`, `post-x-www-form-urlencoded`, `get-space`,
      `get-slash-dot-slash`, `get-slashes`, `post-vanilla-query`, the header-value trimming cases)
      plus S3-specific path cases and a query-form presign case checked against a URL the AWS SDK
      for Java v2 presigner produced with a fixed clock.
- [ ] `docs/configuration/multi-account.md` "Signature Validation" paragraph updated to say what
      is verified where; `make docs-check`.

### 14.2 `refactor(rds): verify proxy presigned URLs with the core`

- [ ] `RdsSigV4Validator` becomes an adapter over the merged core (service name,
      the `GET /` canonical request with `Action=connect` query, legacy secret through
      the shared resolver). Keep `RdsSigV4ValidatorTest` unchanged. One RDS-only PR.

### 14.7 `refactor(elasticache): verify proxy presigned URLs with the core`

- [ ] `services/elasticache/proxy/SigV4Validator` becomes the equivalent ElastiCache
      adapter. Keep `SigV4ValidatorTest` unchanged. One ElastiCache-only PR, independent
      of 14.2 after 14.1 merges. No RDS branch dependency.

### 14.3 `refactor(eks): sign and verify the STS token with the core`

- [ ] `EksTokenMinter` builds its presigned `GetCallerIdentity` through `SigV4Signer`;
      `EksTokenValidator` verifies through `SigV4Verifier` with its own 15 minute rule and the
      `x-k8s-aws-id` signed header; `EksTokenValidatorTest` and the webhook test unchanged, plus a
      round trip test (mint, then verify) that did not exist before.

### 14.4 `refactor(s3): presigned URLs and POST policies over the core`

- [ ] `PreSignedUrlGenerator` and `PreSignedUrlFilter` use the signer and verifier with the S3
      path rule, `UNSIGNED-PAYLOAD`, the 1 to 604800 second expiry, and the two secret sources
      (`floci.auth.presign-secret` for Floci-made URLs, the IAM resolver when
      `floci.auth.validate-signatures` is on). Presigned POST policy signing in `S3Controller`
      uses `SigV4Signer.signingKey`. Behaviour and error XML unchanged; the four S3 tests
      unchanged.

### 14.5 `feat(iam): verify request signatures on the management plane`

- [ ] Behind `floci.auth.validate-signatures` (stays `false` by default: SDKs and tools point at
      Floci with placeholder credentials, and the default `test` key must keep working), the
      request filter that already reads the credential scope verifies the signature with the
      core for every signed request, header and query form, and answers each protocol's error
      shape on failure (JSON 1.1 `InvalidSignatureException` and `IncompleteSignatureException`,
      Query `SignatureDoesNotMatch`, REST-JSON `{"message": ...}` with the AWS text, S3 unchanged).
      Unsigned requests keep today's anonymous handling. Body hashing must not consume the body:
      reuse the buffering `ResourceArnBuilder.readJsonBody` already does for the enforcement
      filter, or hash from the same buffer.
- [ ] Tests through the SDKs with real credentials created by IAM `CreateAccessKey` and STS
      `AssumeRole` (a tampered secret fails, a replayed old date fails, a missing session token on
      temporary credentials fails), and the compatibility suites still green with the flag off.

### 14.6 `feat(iot): verify SigV4 on the device gateway`

- [ ] Service `iotdevicegateway`: the `/mqtt` WebSocket upgrade (query form, `X-Amz-SignedHeaders=host`,
      empty payload hash, which #3150 accepts unverified) and the `/topics/{topic}` HTTPS publish with a
      signed `Authorization` header (Task 13.3's SigV4 arm), through the core verifier, behind the
      same `floci.auth.validate-signatures` switch, then `iot:Connect` and `iot:Publish` evaluated for
      the IAM principal the way the certificate path evaluates them for a device. Refusal is 403.

## Order and size

14.1 about 400 lines of core plus the test vectors, and a net deletion in the authorizer. 14.2 to
14.4 and 14.7 are deletions with a few adapter lines each. 14.5 and 14.6 about 150 lines each plus tests.
None is on the groundzero path; 14.1 is the prerequisite for Task 13.2's credentials being worth
more than the strings they are.
