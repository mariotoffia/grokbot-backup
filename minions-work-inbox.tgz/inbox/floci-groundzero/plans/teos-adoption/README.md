# TEOS adoption and workaround retirement implementation plan

**Goal:** Run groundzero and dependent services against a source-qualified Floci
image, then remove only workarounds whose original failure no longer occurs.

**Architecture:** Extend the existing local harness, driver, metadata mirror and
stream pump. Keep real AWS clients, TLS verification and endpoint safety guards.
Each Task 27 leaf is its own TEOS PR, except 27.15 in the private image repository.
No Floci PR includes a hidden second-repository change.

**Tech stack:** Existing TEOS Go/CDK service tests, Docker and Floci.

Status: [Task 27](../../TEOS_GROUNDZERO_TASKS.md#task-27-teos-adoption-and-workaround-retirement).
Source: TEOS `PLAN.md`, `PLAN_LOCAL_SERVICES.md`, `ISSUES.md`, `WATCH.md` and the
previous `TEOS.1` to `TEOS.10`, `7.T`, the old TEOS-side `9.6` (not Floci 9.6) and `25.3` follow-up notes.
Completed monitor, mirror, pump and local-DNS work is not being implemented again.
The 2.1.0 pin, initial three-service run and dashboard/event-invoke tolerance
removals are also recorded as done. Only their additional deltas are tasks here.

**Synced 2026-09-18:** TEOS `4514f7d53` on `floci-enhanced`, with a clean checkout.
Host TLS, groundzero create/delete, deployment-time copying and now service
registration/dependency restoration are recorded complete as 27.2-27.5. The
network profile supersedes the original script-local TLS helper (completed 33.1).
Building's API remains blocked by a TEOS schema error and missing iam-service
resources, not by the absence of groundzero. Remaining device, registrar-update
and DNS work is in [Task 31](../groundzero-follow-ups/README.md). These are local
completion records, not claims of merged PRs.

## File ownership

All paths here are relative to TEOS unless stated otherwise. Reuse the now-committed
implementation in these files rather than rebuilding the earlier dirty checkpoint:

- `go-core/utils/testutils/flocilocal/consts.go` and the existing driver package:
  image pin, container environment, published ports and endpoints.
- `deployment/lib/svctest/harness.go`, `local.go`, `local_mirror.go`,
  `local_mirror_internal_test.go`, `harness_cbdeploy.go`: orchestration and cleanup.
- `deployment/lib/svctest/local_check.go`: the remaining MetricFilter tolerance.
- `deployment/lib/svctest/local_mirror_watch.go` and its internal test:
  deployment-time copying, with an authoritative post-deploy schema check.
- `deployment/stacks/groundzero/service-test/`, root `Makefile` and `go.work`:
  existing test package and discovery.
- `deployment/stacks/groundzero/scripts/created/03-check-cognito-token-endpoint/main.go`
  and `main_test.go`: real HTTPS token endpoint probe.
- `deployment/lib/adapters/cdk/registry/custom_resource.go` and
  `deployment/lib/adapters/cdk/storage/s3bucket.go`: registration is restored;
  the bucket auto-delete omission remains for missing CFN bucket tags.
- `go-core/cbnet/`, `go-core/utils/httputil/` and the context AWS-config option:
  shared connection routing and trust. The old token-script transport helper is gone.
- Affected `go-services/<service>/deployment/service-test/` packages and their
  `provision-config.local.yaml` files: fixtures and service-specific assertions.

## One PR per leaf

| Task | Scope and required evidence | Source dependency |
| --- | --- | --- |
| 27.1 | Align additional API compatibility cases with 2.1.0: linked API keys, unknown-route 403 and bounded log-retention diagnostics | None; the image pin and initial run already exist |
| 27.2, recorded done | Existing WithTLS, run-scoped CA and SDK/Node trust, verified Cognito hostname via endpoint override | Keep; device ports/trust are new 31.5 |
| 27.3, recorded done | Groundzero test/discovery and create/delete smoke, DSQL and code signing off | Keep; real DNS needs 31.1 and exact follow-up qualification |
| 27.4, recorded done | Deployment-time table copy lets the registrar create/delete its row | Keep W-22; update/cleanup proof is new 31.6 |
| 27.5, recorded done | Registrar omission and dependency suppression removed; event-service registration row read back | Source PLAN 6.9; do not redo the cleanup |
| 27.6 | Restore building IAM registration and `features.lcs-api` with deployed IAM dependencies | 33.3 schema repair; image for 20.1/20.2, 31.2-31.4 and 8.2 |
| 27.7 | Restore CDK bucket auto-delete and prove the Node custom resource empties/deletes the bucket | TLS plus 29.7's bucket tags in the image |
| 27.8 | Remove the last MetricFilter stub tolerance and assert actual filter execution | Containing image for 6.1; dashboard/event-invoke cleanup is already done |
| 27.9 | Remove the RetainResources warning after an eligible delete retains real data | Containing image with Task 16 behavior |
| 27.10 | Remove synthetic SSM change-event injection; a parameter write alone creates the collector schedule | Containing image with 15.1/15.2 |
| 27.11 | Qualify tag-discovered queues/log groups/API keys and remove corresponding local exclusions | Containing image with relevant 17.x leaves |
| 27.12 | Remove the ECR single-port-range workaround after concurrent registries start without collisions | Containing image with 18; ready: 18 merged as floci-io/floci#4857 |
| 27.13 | Make IoT thing-type metadata reads nil-safe, including absent `DeprecationDate` for nondeprecated types | None, also needed for real AWS |
| 27.14 | Qualify devicesvc fleet-indexing setup and remove only its readiness guard | Containing image with 9.4; not SearchIndex proof; ready: 9.4 merged as floci-io/floci#4896 |
| 27.15 | Remove obsolete private native-build flag injection without reopening Tasks 25/26 | Private image repository only |
| 27.16.1 | Extend event-service mapping/alarm/runtime evidence beyond the recorded baseline | 23.x in the image for CFN mapping execution; other cases use existing APIs; ready: 23.1 (floci-io/floci#4316) and 23.2 (floci-io/floci#4739) merged |
| 27.16.2 | Qualify actuation queue discovery and inbound shadow delivery | Relevant 17.x and 19.1 in the image; ready: 17.x (floci-io/floci#4563) and 19.1 (floci-io/floci#5260) merged |
| 27.16.3 | Qualify core-router reserved-shadow delivery | 19.1 in the image; ready: 19.1 merged as floci-io/floci#5260 |
| 27.16.4 | Qualify ingestion reserved-shadow delivery and real sink output | 19.1 in the image; existing Firehose/Logs actions; ready: 19.1 merged as floci-io/floci#5260 |
| 27.16.5 | Qualify tklocal presence and custom-authorizer behavior | 19.2 and 20.3-20.5 in the image |
| 27.16.6 | Qualify the monitor slow-turn case without a synthetic second invocation | 21 in the image; 29.6 additionally for target-delivery retry assertions; ready: 21 (floci-io/floci#4733) and 29.6 (floci-io/floci#4736) merged |
| 27.17 | Remove AWS-shaped queue-URL fixture rewriting, conditionally | Approved and qualified Task 22 strategy |
| 27.18 | Un-skip `TestCreateAndUpdateThing`; partial `UpdateDevice` keeps the other attributes | Containing image with 9.2 |
| 27.19 | Un-skip the three `clwlog` missing group/stream tests; delete gobridge's audit-stream pre-creation | Containing image with 9.3 |
| 27.20 | Un-skip `TestITSearchThingsFindsCreatedThing` | Containing image with 30.1; 27.14 first; ready: 30.1 merged as floci-io/floci#4913 and floci-io/floci#6025 |
| 27.21 | Un-skip both shadow-metadata payload tests | Containing image with 9.6; ready: 9.6 merged with floci-io/floci#5260 |

An image dependency is not a reason to stack source PRs across repositories.
Preparatory tests may merge with explicit capability gating; deletion of a
workaround may not merge on the strength of a skip.

## 27.1: Release-contract follow-ups

The 2.1.0 pin and baseline run are completed source work. Add the remaining
compatibility cases, not another image-selection mechanism:

- A method requiring an API key rejects a missing/invalid key and accepts a key
  whose usage plan is linked to the stage. The Floci implementation is already
  delivered in floci-io/floci#3537.
- An unknown REST API path expects AWS's 403, not the old local 404/405. Attribute
  the source's floci-io/floci#3547 claim to release notes until the new case runs.
- Document the new 20,000-event account-wide Logs cap and eviction diagnostic
  boundary. Use existing `WithEnv` and
  `FLOCI_SERVICES_CLOUDWATCHLOGS_MAX_STORED_EVENTS` only if a run needs more; do not
  add a second retention control or claim missing early logs never occurred.

Preserve `TK_LOCAL_EMULATOR` and explicit per-test overrides. Record each added
case's actual selected digest; root `common.local.emulator` is not inherited
automatically by all tests.

From `design-in-progess/floci`, run `./floci-scan.sh --no-pull` with `FLOCI_SRC`
pointing at the exact locally available source revision. A symbol scan is only
source evidence; SDK behavior and the running image must also agree. Never download
or publish images as an implicit part of this documentation task.

## 27.2 and 27.3: Real TLS and groundzero

These baseline tasks are completed in the source record. Preserve
`WithTLS`, internal container port 443 and run-scoped CA distribution. The
token probe now uses the common `cbnet` profile and `httputil.NewClient`.
The profile dials `AWS_ENDPOINT_URL` only for the local base domain while
retaining the custom hostname for SNI and certificate verification.
**Do not publish host port 443:** the source explicitly rejected that alternative
because simultaneous local runs would collide. SDKs and health checks stay HTTP.

Reuse `cbnet.FromContext(ctx)` or `cbnet.FromEnv()` and the existing client
construction. The profile loads `AWS_CA_BUNDLE` for raw Go HTTPS, preserves an
explicit caller-owned certificate pool, and leaves vendor hosts and their proxy
settings alone. Do not add another TLS pool/transport to each caller, install an
OS trust root or disable verification. Device trust still needs its own proof.

The existing groundzero test waits for its real services and checks the
certificate, Cognito endpoint, IoT domain status and cleanup. Retain it rather
than generating a second harness. DSQL and code signing remain disabled.
The four CFN DNS records were not created despite CREATE_COMPLETE: new 31.1
owns that defect. The CDK-created validation record is real.
On the AWS target the groundzero test is read-only: it inspects the existing
shared stack and fails if absent. It must never deploy, update or delete the
account's groundzero. Mutating lifecycle cases use isolated local stacks.
Correct the stale `enable-iot-domain` comment that says CDK creates a disabled
domain; do not introduce a disable/enable round trip to match the comment.
Put the remaining registrar-update and missing-callback/failing-handler cases
in new 31.6, not in the completed baseline. The old Task 10B hang observation is not grounds to rewrite
Lambda timeouts: current Floci has dispatch-time result deadlines and CFN
idle/liveness handling. Preserve legitimate provider progress while proving
an actually stalled resource does not hang this test indefinitely.

## 27.4 to 27.7: Deployment ordering and real custom resources

Deployment-time copying now exists as W-22: groundzero registered itself and its
delete removed that row in the recorded run. Keep the watcher and the database
split. Root `ISSUES.md` 1.6 clarifies this is polling, not a hard barrier: the
250 ms copy usually beats a cold Lambda start. The authoritative post-deploy
copy checks every table/index. New 31.6 proves remaining registration-update
and lifecycle cases; it must not claim this proves race-free ordering.

27.5 is complete: normal manifest dependency resolution deploys groundzero first,
and all three services run with real registration. Keep it. For 27.6 repair the
building API schema in separate 33.3 first. Its `generate-api` target already
exists; the separate missing Go-model hook is 33.6. Restore the IAM half only
when iam-service's five missing resource types are in the image.
Exercise iam-service's actual `Custom::AWS` update of `PreTokenGenerationConfig`.
Resolve groundzero `stack.go`'s stale `stack_pool_attrs.go`/`AddCustomAttributes`
comment against that path rather than adding an invented missing component.

For auto-delete, use the actual CDK Node handler against a nonempty test bucket.
Assert the bucket and objects disappear and stack destruction completes. A manual
`DeleteObject` loop in the test is not acceptance for removing W-13.

## 27.8 to 27.12: Workaround deletion gates

For 27.8, keep the already-removed dashboard/event-invoke tolerances removed.
Delete only `AWS::Logs::MetricFilter` from `toleratedStubTypes`, then turn off
unsupported-resource stubbing for the covered stacks. Keep the harness's useful
unsupported-resource checks. Do not assert a
stub-reason field on `ListStackResources`, which does not expose one. Read the
actual filter through its service API, ingest matching and nonmatching logs and
read the expected metric. Async failure handling remains Task 21.

For 27.9, exercise a permitted failed-delete/retain flow with persisted data before
changing `go-services/appstore/cmd/cbdeploy/internal/cfn/cloud_undeploy.go`.

For 27.10, remove `injectSSMParameterChangeEvent` from
`go-services/collectorsvc/deployment/service-test/helpers_test.go` and its call in
`e2e_collection_test.go` only when the real parameter mutation drives the deployed
EventBridge rule, queue and rule-manager Lambda.

For 27.11, call GetResources with the real `fd`/`pn`/`pt` and resource-type filters,
then send through the discovered queue or read the discovered log group. Do not seed
a second tagging store. For 27.12, start two scoped emulator/registry instances and
prove reachability and cleanup without the single-port override.

## 27.13 to 27.17: Focused follow-ups

27.13 changes `go-core/managers/mgriot/awsmgriot/devicemanager_aws.go`, not Floci's completed
thing-type API. Cover nil metadata, nil deprecation date, a normal nondeprecated
type and a deprecated type. Floci's field-name correction remains 9.1.

27.14 proves `UpdateIndexingConfiguration`, `GetIndexingConfiguration` and index
readiness through the existing devicesvc lifecycle script. Search, connectivity
and reserved-event delivery need their own proof; do not remove those exclusions.

27.15 belongs in the private Floci image repository's `.github/workflows/teos.yml`.
The assemble step resets from upstream and replants selected files, so edit the
workflow-owned patch, not a Dockerfile that assembly discards. Remove only the
now-redundant `application.yml` flag injection once the Dockerfile supplies the
flag. Preserve the libz packaging and native/compat image boot checks from Task 26.

27.16 is a grouping, not a PR. Its six leaves are separate service/path PRs;
do not wait for all IoT work to land before qualifying an unrelated event case.
Building API restoration remains 27.6. The previous three-service run
is a baseline, not new coverage. In the appropriate leaf include exact template/intrinsic property
read-back (X-4), real Lambda logs and scheduled delivery (X-2), IoT HTTP
get/update/publish and rule projections (X-5), and automatic metric-alarm
evaluation rather than test-driven `SetAlarmState` (C-5). Keep admission, denial,
throttling and encryption-at-rest claims out of permissive local tests.

Use each selected service's existing `deployment/service-test` package and
root test selector. Keep all six cases' required capability gates explicit,
and keep W-6 until the slow-turn leaf executes without replacement invocations.

Run the baseline regression from the TEOS root with the selected image:

```sh
CB_SERVICE_TEST=event-service,building-service,collector-service make test-service
```

Use `-count=1` for direct Go runs in the selected service-test module, retain the
service selector and e2e build tag, and record executed tests separately from skips.
The removed `make test-service-local` target is not a valid command. Existing
monitor activation/watermark fixtures are real setup, not emulation workarounds.

27.17 remains conditional. Preserve production URL validation and the existing
SDK endpoint override until returned URLs pass validation and requests from host
and launched Lambda both stay inside Floci. If no upstream URL strategy is
approved, keep the small `awsShapedQueueURL`/`subscriptionQueueURL` fixtures.

## 27.18 to 27.21: Marker removals

Each leaf deletes one `floci: Missing Implementation for` marker and the skip
under it, nothing else. Delete only after the containing image carries the Floci
fix and the un-skipped test passes there and on AWS. A local skip is not evidence.
All paths are TEOS `main` at `44009fbe5`.

27.18, `IoT UpdateThing attribute merging`:
`go-core/managers/mgriot/awsmgriot/devicemanager_aws_integration_test.go:38`,
`TestCreateAndUpdateThing`. Needs 9.2's `attributePayload.merge`.

27.19, `CloudWatch Logs missing group and stream error messages`:
`go-core/managers/mgrlog/clwlog/cloudwatch_integration_test.go:164`
`TestLogToStreamThatDoNotExistsShallGiveError`, `:203`
`TestLogToGroupThatDoNotExistsShallGiveError` and `:233`
`TestLogToStreamThatDoNotExistsWithAutoCreateShallSucceed`. Also delete the
today/tomorrow `CreateLogStream` loop in
`go-services/core/brokers/gobridge/internal/testkit/logs.go:34`; go-core's audit
writer then creates its stream itself. Needs 9.3's exact AWS message text.

27.20, `IoT fleet search`:
`go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go:26`,
`TestITSearchThingsFindsCreatedThing`. Keep its account-indexing-off skip, which
is real AWS behaviour. Needs 30.1, which needs 9.4; land after 27.14.

27.21, `device shadow metadata`:
`go-core/cbtarget/awsdstarget/target_integration_test.go:214`
`TestProcessedPayloadFormatTypeSensorsFiltered` and
`go-core/cbtarget/awsdstarget_integration_test.go:45`
`TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered`. Both compare
per-sensor timestamps from `GetThingShadow`'s `metadata`. Needs 9.6.
