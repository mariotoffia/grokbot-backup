# DynamoDB Local pump reliability implementation plan

**Goal:** Make the delivered external stream pump's limits explicit and prevent
local tests from passing after unexpected loss.

**Architecture:** Keep DynamoDB Local for data access and the existing host pump
for Lambda delivery. Extend the delivered parser, delivery engine, lifecycle and
statistics rather than implementing a second pump or replacing Floci storage.

**Tech stack:** Existing TEOS Go packages, AWS SDK clients and Docker integration tests.

Status: [Task 28](../../TEOS_GROUNDZERO_TASKS.md#task-28-dynamodb-local-pump-reliability).
The 2026-09-18 sync at `4514f7d53` confirms the three narrow repairs first recorded
at the 2026-09-17 checkpoint as complete. Keep them completed, alongside enhanced Tasks 1-11.
Remaining discard/cancellation evidence is a new Task 31.7, not reopening these.
Root-issue conditional capability extensions are 33.12-33.16; do not implement
them without a selected consumer or duplicate an approved backend replacement.

## Files

Paths are relative to TEOS:

- `go-core/utils/testutils/flocilocal/ddbstreampump/template.go` and
  `template_test.go`: supported CFN mapping options.
- `mapping.go`, `discover.go`, `discover_test.go` in the same package:
  declared versus actual stream identity.
- `invoke.go`, `deliver.go`, `deliver_test.go`: synchronous invocation, partial
  failure, retry, bisection and on-failure delivery.
- `pump.go`, `pump_test.go`, `integration_test.go`: shard/lifecycle/statistics
  and real DynamoDB Local/Floci integration.
- The existing `testutils.NewLocalDynamoDb` image selection and
  `deployment/lib/svctest/` pump startup/cleanup.
- `design-in-progess/floci/PLAN_DDB_PUMP.md`, `PLAN.md`, `ISSUES.md`:
  the supported contract and workaround status.

## 28.1: Reproducible DynamoDB Local image

Recorded done: `go-core/utils/testutils/dynamodb_local.go` pins release 3.3.1
by the multi-architecture image-list digest. Keep that pin and existing user
overrides; do not create another container launcher or repin from an older note.

Acceptance: a normal test run records the resolved image identity, and the
existing real pump integration cases pass against that identity. Update the
run documentation with the same pin and the controlled process for updating it.
This does not change the Floci image or its database implementation.

## 28.2: Honest mapping-option support

Recorded done: the parser rejects `MaximumRecordAgeInSeconds` other than -1,
because the pump does not model record age. Keep its explicit unsupported-option
behavior and documented defaults; the broader reliability checks belong to 31.7.

Include record-age handling in this inventory. Keep retry limit, bisection,
partial-batch reporting, starting position and SQS failure destinations that the
delivered pump already supports. Tests must distinguish invalid shapes, unsupported
options and the supported configurations actually emitted by TEOS templates.
Do not broaden this PR into full Lambda event-source-mapping parity.

The parser currently reads templates because Floci's CFN mapping drops options.
Neither Task 23 read-back nor Floci's native poller proves that the external
DynamoDB Local stream is being consumed. Preserve the declared stream ARN in the
Lambda event while reading the actual local stream.

## 28.3: Loss, failure-destination and lifecycle assertions

Recorded done: a failed send to the mapping's failure queue now fails the
harness even if the service test passed. Keep that failure behavior.
New 31.7 checks unexpected discard counts and the remaining cancellation/lifecycle
boundaries. Intentional poison-record tests assert their expected discard count
and destination record rather than disabling checks.

Cover a destination send failure, exhausted retry budget, malformed partial
response, cancellation while backing off, and cleanup after an earlier harness
failure. Do not swallow a failure-destination exception or call a discarded
record successfully processed.

`TEOS_LOCAL_KEEP` keeps containers, not the host Go process or pump workers.
Document this limit and stop workers before their clients are released. Test
prompt cancellation without arbitrary sleeps. No durable daemon or checkpoint
service is requested by these sources.

## Runnable checks

From the TEOS root, the focused package suite is:

```sh
cd go-core
go test -short -race -count=1 ./utils/testutils/flocilocal/ddbstreampump/
```

For image/discovery/delivery changes, run the delivered real integration tests:

```sh
cd go-core
go test -race -count=1 \
  -run 'TestPumpDeliversWhatDynamoDBLocalWrites|TestDiscoverReadsADeployedStack' \
  -v ./utils/testutils/flocilocal/ddbstreampump/
```

The first test uses DynamoDB Local with an in-process invoker. The second
discovers a deployed mapping but does not execute its placeholder Lambda.
Neither alone proves deployed Lambda delivery; retain the service-test proof
when extending execution in 31.7.

For harness cleanup changes, from TEOS `deployment/lib`:

```sh
go test -short -race -count=1 ./svctest/
```

Expected result: supported mappings deliver the exact intended records, unexpected
loss or destination failure fails visibly, and every worker stops with its owner.
Keep existing benchmarks; no new benchmarking project is needed.
