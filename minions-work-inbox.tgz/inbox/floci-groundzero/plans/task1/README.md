# Task 1: ACM certificate provisioner

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

**Done.** Merged as #3003 (`feat(acm): provision AWS::CertificateManager::Certificate`, squash `38176b9e`, 2026-09-04 05:46). Not to be touched; follow-ups are Task 10.

groundzero holds three certificates (`domain.go`, `stack.go`). `api.<acct>` and `iot-<region>.<acct>` come from CDK's `NewCertificate` with DNS validation and are `AWS::CertificateManager::Certificate`: this task. `api.auth.<acct>` is created with `ForceRegion: "us-east-1"`, which makes CDK emit a `DnsValidatedCertificate` custom resource whose Node.js Lambda calls ACM and Route 53 itself; the provisioner does not touch it (analysis 1.8).

- [x] Read `services/acm/AcmService.java` (`requestCertificate`, `describeCertificate`, `deleteCertificate`) and `SsmCfnProvisioner.java` as the pattern.
- [x] `AcmCfnProvisioner` for `AWS::CertificateManager::Certificate`: maps `DomainName`, `SubjectAlternativeNames`, `ValidationMethod` (default `DNS`), `KeyAlgorithm`, `Tags`. `DomainValidationOptions` accepted and ignored. `CertificateExport`, `CertificateTransparencyLoggingPreference` and `CertificateAuthorityArn` ignored (the PR body's table says so); the first two move to Task 10.
- [x] Physical id: the certificate ARN. Attribute: `CertificateArn` (the schema's only `readOnlyProperty`). Status `ISSUED` immediately, said in the class comment.
- [x] Update: `DomainName`, `SubjectAlternativeNames` and `KeyAlgorithm` compared (`sameCreateOnlyProperties`); a change requests a new certificate and `deletePriorOrUnwind` removes the prior one, or removes the replacement and marks the rollback restored when the prior cannot be deleted. Tags reconciled in place (`staleTagKeys`). `CertificateExport` as a createOnly comparison moves to Task 10; `CertificateAuthorityArn` is out of scope (private CA not emulated).
- [x] Delete: `deleteCertificate` through `CfnDeletes.safeDelete`, tolerating `ResourceNotFoundException` only.
- [x] Integration test: a template with one certificate and one `Fn::GetAtt CertificateArn` output; the output is an ARN that `DescribeCertificate` finds with status `ISSUED`.
- [x] Checklist in [../README.md](../README.md).

TEOS check after #3003: `ListStackResources` shows a real ARN for the `api` and `iot` certificates. The `DnsValidatedCertificate` smoke test is a verification, not code, and lives in Task 10.
