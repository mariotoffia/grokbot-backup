# Task 2: Cognito user-pool domain provisioner

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

Branch `feat/cognito-cfn-userpool-domain`. Title `feat(cognito): provision AWS::Cognito::UserPoolDomain`. Needs Task 1 merged or rebased on. Done: merged as #3005 (`f3c251ef`, 2026-09-04); the certificate lookup and ACM `InUseBy` follow-up is #3035 (open, CI green, rebased onto `main`).

- [x] Read `CognitoService.createUserPoolDomain / describeUserPoolDomain / deleteUserPoolDomain` (around line 1080) and the `UserPoolDomain` model.
- [x] Where do `AWS::Cognito::UserPool` and `UserPoolClient` live today? In the legacy switch of `CloudFormationResourceProvisioner`. Add the domain to a new `CognitoCfnProvisioner` and leave the two legacy arms alone; `noTypeIsServedByBothTheRegistryAndTheSwitch` only fails when the same type is in both.
- [x] Map `Domain`, `UserPoolId`, `CustomDomainConfig.CertificateArn` (+ `SecurityPolicy`), `ManagedLoginVersion`. Physical id: the domain name.
- [x] Attribute: `CloudFrontDistribution` only (the schema's sole `readOnlyProperty`; `CloudFrontEndpoint` is a CDK accessor name, not a CloudFormation attribute). TEOS's alias record is an L1 `CfnRecordSet` reading `Fn::GetAtt CloudFrontDistribution` (`domain.go` lines 232-245), no custom resource. For a prefix domain set `""` rather than leaving it unset, so nothing resolves to the literal `LogicalId.Attr`.
- [x] Add `CognitoService.updateUserPoolDomain(domain, userPoolId, customDomainConfig, managedLoginVersion)` and the `UpdateUserPoolDomain` route in `CognitoJsonHandler` (response `{CloudFrontDomain, ManagedLoginVersion}`): Floci lacks the operation and the provisioner's in-place update path (`ctx.reusesPriorEntity(domain)`, same pool) needs it. `Domain` and `UserPoolId` are createOnly: a change to either is create-new then delete-prior.
- [x] Delete needs the user-pool id: keep it as a create-time attribute and override `delete(StackResource, String)` (pattern: `AutoScalingLifecycleHookCfnProvisioner`).
- [x] Integration test: user pool + certificate + domain + a Route 53 alias record using `Fn::GetAtt CloudFrontDistribution`; assert `DescribeUserPoolDomain` finds it and the record's target ends in `.cloudfront.net`, not a literal `LogicalId.Attr`. `CognitoUserPoolDomainIntegrationTest` gains an `UpdateUserPoolDomain` case.
- [x] Checklist in [../README.md](../README.md) (`make docs-sync`: `cognito.md` gains the new action row, fill its description).

Size: about 100 lines plus tests, plus the update operation.
