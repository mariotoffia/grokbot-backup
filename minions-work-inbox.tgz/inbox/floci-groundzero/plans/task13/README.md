# Task 13: client certificates beyond the MQTT listener

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps: [../README.md](../README.md). Builds on Task 7 PR 11 (#3180) and, for 13.2 and 13.3, on Task 12 for certificates Floci did not issue.

## Why

#3180 taught the MQTT TLS listener to read the peer certificate, find it in the IoT registry and
evaluate a policy for it. AWS uses client certificates in three more places, and Floci has none of
them:

1. **The IoT credential provider.** A device presents its registered certificate to
   `https://<credentials endpoint>/role-aliases/<alias>/credentials` and gets temporary AWS
   credentials for the role behind the alias. This is how a device certificate reaches every other
   AWS service: the device then signs requests with SigV4. Reuses the IoT registry and policy
   evaluation, action `iot:AssumeRoleWithCertificate`.
2. **HTTPS publish with a certificate.** `POST https://<data endpoint>:8443/topics/<topic>?qos=1`
   (or 443 with ALPN `x-amzn-http-ca`) authenticates with the registered certificate and evaluates
   `iot:Publish`. Reuses the IoT registry. Floci serves `/topics/{topic}` on 4566 with no
   authentication.
3. **API Gateway mutual TLS on a custom domain.** Trust is by issuer, not by registration: the
   domain carries a truststore (a PEM bundle of CA certificates in S3), API Gateway validates the
   client's chain against it and hands the certificate to authorizers and integrations as
   `$context.identity.clientCert`. Nothing of the IoT registry applies; the TLS-side mechanics do.
   Floci stores `mutualTlsAuthentication` on REST domain names and ignores it, and
   `ApiGatewayExecuteController` puts `clientCert: null` with a comment that mTLS is unsupported.

All three need the same groundwork first: Floci's HTTPS listeners do not ask for a client
certificate today. That groundwork is subtask 13.1 and its own PR, so the three features stay
one-concern PRs.

Verified 2026-09-07 against the AWS IoT developer guide (`authorizing-direct-aws`, `http`,
`protocols`) and the API Gateway developer guide (`rest-api-mutual-tls`); role alias shapes from
`API_CreateRoleAlias` and siblings. Re-read the pages before coding; error message texts come from a
call against AWS.

## Floci facts that shape the work

- With `floci.tls.enabled=true`, `TlsConfigSource` puts Quarkus HTTP on 4510 and HTTPS on 4511, and
  `TlsProxyServer` (a TCP proxy that only sniffs the first byte) listens on 4566 and on
  `floci.tls.aws-https-port` (443), forwarding TLS bytes to 4511. TLS is terminated by the Quarkus
  server, so a client certificate is only visible there. Requesting one means
  `quarkus.http.ssl.client-auth=request` in `TlsConfigSource` plus a trust manager that accepts any
  issuer (`quarkus.tls.<default>.trust-all`, check that the HTTP server honours it for client auth;
  otherwise a custom `TrustOptions`), so the handshake completes and the application decides, the
  same split as #3180. `request`, never `required`: every other HTTPS client on 4566 must keep
  working, and a browser only prompts for a certificate when it has one installed.
- `IotMqttBrokerService` has the reusable pieces: the accept-any `X509ExtendedTrustManager`,
  `ReloadingKeyManager` following `CertificateUpdatedEvent`, `presentedDevice` (peer chain from the
  SSL session) and `requestedServerName` (SNI). `IotService.findRegisteredCertificate` and
  `isConnectAllowed` carry the registry lookup and the policy evaluation with connection variables;
  the evaluation is fixed to `iot:Connect` on `client/<id>` and needs an action and resource
  parameter for `iot:AssumeRoleWithCertificate` on `rolealias/<alias>` and `iot:Publish` on
  `topic/<topic>`.
- On a JAX-RS request the peer certificate is
  `CurrentVertxRequest.getCurrent().request().sslSession().getPeerCertificates()`
  (`SSLPeerUnverifiedException` when none was presented), the pattern `IamEnforcementFilter`
  already uses to read the Vert.x request.
- STS lives in `StsQueryHandler.handleAssumeRole` with `IamService.registerSession`; the credential
  provider needs the same session minting as a Java call, not an HTTP round trip.
- `ApiGatewayCustomDomainFilter` routes a custom domain by `Host` and rewrites onto execute-api;
  `ApiGatewayController` line 2097 stores `mutualTlsAuthentication` on a REST domain name;
  `ApiGatewayExecuteController` lines 654 and 805 write `clientCert: null`; `disableExecuteApiEndpoint`
  is already enforced (line 1474). API Gateway v2 domain names have no `MutualTlsAuthentication`
  fields at all.

## Subtasks

### 13.1 `feat(tls): request a client certificate on the HTTPS listeners`

The groundwork. No feature visible to a client yet, but a device can present a certificate on
4566 and 443 and the application can read it.

- [ ] `TlsConfigSource`: `quarkus.http.ssl.client-auth=request` and the accept-any trust for the
      default TLS configuration, behind `floci.tls.client-auth` (`none`, `request`; default `request`
      when TLS is on; `FLOCI_TLS_CLIENT_AUTH`). `EmulatorConfig`, both `application.yml`,
      `docs/configuration/tls.md`.
- [ ] A small `ClientCertificates` helper in `config` (or `core.common`): the peer leaf and chain of
      the current Vert.x request as `Optional<X509Certificate[]>`, plus the SNI name, shared by 13.2
      to 13.4 and by the MQTT broker (move `presentedDevice`'s chain reading there, keep the broker's
      registry lookup where it is).
- [ ] `IotService`: generalise the evaluation into `isAllowed(RegisteredDevice, action, resource,
      clientId or null, sourceIp, domainName)` and make `isConnectAllowed` call it, so 13.2 and 13.3
      add no second evaluator. `${iot:ClientId}` stays unresolved when there is no client id (HTTPS has
      none: "HTTPS doesn't support a clientId value like MQTT does"), which by #3180's rule drops
      the statement.
- [ ] Tests: `TlsProxyServer`/`TlsUserCertIntegrationTest` style integration test that a JSSE client
      with a client key completes the handshake on 4566 and a filter test resource can read the
      leaf; a client without a key still works; `client-auth=none` restores today's behaviour.
      Watch the shared `/tmp` fixture note in the memory file for `TlsUserCertIntegrationTest`.
- [ ] Docs: `docs/configuration/tls.md` gets a "Client certificates" section; `make docs-check`.

### 13.2 `feat(iot): role aliases and the credential provider`

- [ ] Role alias API: `CreateRoleAlias` (`POST /role-aliases/{roleAlias}`, body `roleArn`,
      `credentialDurationSeconds` 900 to 43200 default 3600, `tags`; name `[\w=,@-]{1,128}`, case
      sensitive; `ResourceAlreadyExistsException` 409), `DescribeRoleAlias` (`roleAliasDescription`
      with `roleAlias`, `roleAliasArn`, `roleArn`, `owner`, `credentialDurationSeconds`,
      `creationDate`, `lastModifiedDate`), `ListRoleAliases` (`pageSize`, `marker`,
      `isAscendingOrder`, `nextMarker`), `UpdateRoleAlias`, `DeleteRoleAlias`, tags on
      `arn:aws:iot:<region>:<account>:rolealias/<name>`. Own store `iot-role-aliases.json`.
      `credentialDurationSeconds` above the role's `MaxSessionDuration` is `InvalidRequestException`
      as on AWS (verify the message).
- [ ] `GET /role-aliases/{roleAlias}/credentials`: the credential provider. Requires a presented
      certificate (13.1) that `findRegisteredCertificate` knows, `ACTIVE` and valid; policy check
      `iot:AssumeRoleWithCertificate` on the alias ARN with the connection variables; optional
      `x-amzn-iot-thingname` header, which must name a thing attached to the certificate (AWS answers
      403 when it does not) and then resolves the thing variables; then mint credentials the way
      `StsQueryHandler.handleAssumeRole` does for the alias's role, duration
      `credentialDurationSeconds`, the role's trust policy allowing `credentials.iot.amazonaws.com`.
      Response `{"credentials":{"accessKeyId","secretAccessKey","sessionToken","expiration"}}`,
      `expiration` ISO-8601 UTC. Refusals are 403 with the AWS body (capture it from a real call;
      it is `{"message":"..."}`).
- [ ] `DescribeEndpoint` for `iot:CredentialProvider` keeps returning Floci's host (Task 7 PR 12
      decides the shape); the endpoint is the same 4566 or 443, since the path is distinct.
- [ ] IAM policy variables `credentials-iot:ThingName`, `credentials-iot:ThingTypeName`,
      `credentials-iot:AwsCertificateId` on the minted session: only if `IamEnforcementFilter`'s
      condition context can carry session tags cheaply; otherwise record it as a gap in the docs.
- [ ] Tests: unit for the alias API and the duration rule, integration over HTTPS with a device
      from `IotDeviceIdentity` (admitted, wrong alias, `INACTIVE` certificate, no certificate,
      thing name not attached, duration echoed in `expiration`), then the minted credentials used
      for a signed call against Floci (an S3 `ListBuckets` through the Java SDK is enough) to prove
      the session is real. Java SDK v2 `createRoleAlias` through the compatibility suite.
- [ ] Docs: `docs/services/iot.md` "Credential provider" section; `make docs-sync`, `make docs-check`.

### 13.3 `feat(iot): HTTPS publish with a device certificate`

- [ ] `POST /topics/{topic}?qos=` in `IotDataController`: when the request carries a client
      certificate (13.1), it must be registered, `ACTIVE` and valid, and `iot:Publish` on
      `arn:aws:iot:<region>:<account>:topic/<topic>` must be allowed through the certificate's
      policies, evaluated with `aws:SourceIp` and `iot:DomainName` and no client id; otherwise 403.
      A request without a certificate keeps today's behaviour (SigV4 is parsed for the region only,
      as everywhere in Floci). Response stays `{"message":"OK","traceId":"..."}` if that is what
      Floci returns today; check against AWS which answers `{"message":"OK","traceId":"<uuid>"}`.
- [ ] Port 8443: AWS's certificate-only HTTPS port. Either a second `floci.tls.aws-https-port`-style
      binding of `TlsProxyServer` (`floci.services.iot.https-port`, default 8443, 0 disables) or the
      documented `443:4566` mapping; decide in the PR, the filter logic is the same.
- [ ] `retain` on HTTPS: AWS accepts `?retain=true` on the publish URL; keep it.
- [ ] Tests: integration with `IotDeviceIdentity` over HTTPS: allowed topic publishes and reaches an
      MQTT subscriber, denied topic is 403, `INACTIVE` certificate is 403, no certificate keeps
      working, `${iot:ClientId}` in the policy never matches over HTTPS. Compatibility suite: the
      Python SDK example from the AWS page (`requests` with `cert=`) against Floci on 8443.
- [ ] Docs: the HTTPS publish paragraph in `docs/services/iot.md`; `make docs-sync`, `make docs-check`.

### 13.4 `feat(apigateway): mutual TLS on custom domains`

- [ ] REST `DomainName.mutualTlsAuthentication`: `truststoreUri` (`s3://bucket/key` in Floci's
      S3), `truststoreVersion`, `truststoreWarnings` (one entry per certificate in the bundle that is
      not a usable CA); `ownershipVerificationCertificateArn` stored and echoed; `create-domain-name`
      and `update-domain-name` patch paths `/mutualTlsAuthentication/truststoreUri` (empty value
      disables) and `/truststoreVersion`. Mutual TLS is REGIONAL only and `TLS_1_2` on AWS: reject
      EDGE with the AWS `BadRequestException` message. API Gateway v2 `DomainName`
      `MutualTlsAuthentication` with the same three fields, if the v2 domain name API exists by then.
- [ ] Enforcement in `ApiGatewayCustomDomainFilter`: when the domain has a truststore, the request
      must carry a client certificate (13.1) whose chain validates against the CAs in the bundle
      (`CertPathValidator` with the bundle as trust anchors, revocation off: "API Gateway doesn't
      verify if a certificate has been revoked", chain length at most four, SHA-256 or stronger,
      RSA-2048 or stronger, ECDSA P-256 or P-384, validity current); otherwise 403 with
      `{"message":"Forbidden"}`. The truststore is read from `S3Service` per request or cached by
      bucket, key and version. Deviation to document: AWS fails the handshake, Floci answers 403.
- [ ] `$context.identity.clientCert` in `ApiGatewayExecuteController`: `clientCertPem`, `subjectDN`,
      `issuerDN`, `serialNumber`, `validity.notBefore`, `validity.notAfter`, into the Lambda proxy
      event (`requestContext.identity.clientCert`), Lambda authorizer input and access log
      variables; stays null without mTLS, exactly as the two existing lines say today.
- [ ] Tests: unit for the chain validation (trusted, untrusted issuer, expired, chain of five,
      weak key), integration: a domain with a truststore holding a test CA, a client with a leaf
      from that CA invokes the API and the Lambda event shows the certificate, a leaf from another CA
      gets 403, no certificate gets 403, disabling mTLS by patching `truststoreUri` to empty lets
      it through again, warnings for a bundle with a broken certificate. SDK-based domain name
      calls, as AGENTS.md asks.
- [ ] Docs: `docs/services/apigateway.md`; `make docs-sync`, `make docs-check`.

## Decisions to take before coding

- `client-auth=request` on the whole HTTPS listener (recommended: one switch, AWS's own API Gateway
  requests a certificate only on mTLS domains, but Floci cannot vary client auth by SNI without a
  second TLS terminator) versus a dedicated IoT listener on 8443 with its own Vert.x `HttpServer`
  sharing the Quarkus `Router` (what #3150's WebSocket bridge does for a route; cleaner for browsers
  that have client certificates installed, more code).
- Where the truststore cache lives when the domain is updated (invalidate on the patch).

## Order and size

13.1 first (about 80 lines plus tests). 13.2 and 13.3 are independent of each other after 13.1 and
after Task 12.1 when the test devices should not come from `CreateKeysAndCertificate` (they can,
`IotDeviceIdentity` is enough). 13.4 needs only 13.1. About 250, 120 and 300 lines plus tests.
None is on the groundzero path.
