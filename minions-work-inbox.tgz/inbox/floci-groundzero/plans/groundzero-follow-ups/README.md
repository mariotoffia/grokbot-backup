# Groundzero checkpoint follow-up implementation plan

**Goal:** Close the newly observed gaps without reopening the working host-TLS,
groundzero, table-copy or pump baselines.

**Architecture:** Each Task 31 leaf is its own PR, based on the owning repository's
`main`. Keep local checkpoint implementation separate from merged delivery.
Wait for a required baseline to merge rather than stacking a new repair on it.

**Tech stack:** Existing Floci provisioners and SDK tests; TEOS Go/CDK harness.

**Source cut:** synced 2026-09-18 at TEOS `4514f7d53`, clean `floci-enhanced`.
`PLAN.md` 6.9 now completes W-12 and the account-safety fix (31.8). W-15
remains open for the actual schema/IAM blockers. Root `ISSUES.md` adds the
polling race and further gaps; its complete disposition is in
[the root-issue plan](../teos-root-issues/README.md).

Status: [Task 31](../../TEOS_GROUNDZERO_TASKS.md#task-31-new-groundzero-checkpoint-follow-ups).

## Floci provisioner PRs

All paths in this section are under
`src/main/java/io/github/hectorvent/floci/services/cloudformation/provisioners/`.
Each leaf also updates its matching test, the supported-resource inventory,
`CfnProvisionerFixture`, schema-gap ledger if necessary, and generated docs.
The local schema corpus is absent in this checkout: obtain the named registry
schemas before implementing, and derive exact `Ref`/`Fn::GetAtt` contracts from
them rather than guessing attributes. Follow the existing per-service recipe.

| Task | Source | Existing owner | Scope and acceptance |
| --- | --- | --- | --- |
| 31.1 | P-24 | `Route53CfnProvisioner.java` | Add real `AWS::Route53::RecordSet` create/update/delete through Route53Service. The legacy arm only assigns a name, which evades the stub-ID check. Cover the actual groundzero alias/CNAME/A records, TTL/resource values, hosted-zone resolution, update rollback and delete. Assert Route 53 SDK record contents, not stack status or public DNS resolution |
| 31.2 | P-25 | `WafV2CfnProvisioner.java` | Provision `AWS::WAFv2::WebACLAssociation` using existing association APIs. Assert the actual ACL associated with the target, reassociation/update and disassociation/delete, preserving account/region and AWS target validation |
| 31.3 | P-25 | `CognitoCfnProvisioner.java` | Provision `AWS::Cognito::UserPoolUser` through existing admin APIs. Preserve pool/username identity and supported attributes, update and delete. Read the actual user through the SDK; do not replace the user merely to change a mutable attribute |
| 31.4 | P-25 | `CognitoCfnProvisioner.java` | Provision `AWS::Cognito::UserPoolUserToGroupAttachment`. Assert actual membership on create, moves on update and removal on delete without deleting the user or group |

31.1 must not add another legacy `CloudFormationResourceProvisioner` switch case.
Move ownership of this type to its existing service provisioner and preserve
HostedZone behavior. A zone with the CDK-created certificate validation record
but none of its four CFN records is a failing regression fixture.

31.2-31.4 can start independently: seed prerequisite ACLs/users/groups through
the SDK, not unmerged CFN provisioners. 31.4 does not need 31.3 or 20.1 to merge
for its own tests. The complete iam-service deployment requires all three plus
20.1/20.2 in its selected image; that is a later TEOS gate in 27.6.

Run the owning provisioner tests, `CfnResourceInventoryTest` and
`CfnProvisionerFixtureTest`, plus each new SDK lifecycle case. Run `make docs-sync`
and `make docs-check` in each PR. No new service/storage registration is needed
when the existing owning API provides the required operation.

## 31.5: Device transport and trust qualification

**Owner:** TEOS. New follow-up to completed host-TLS 27.2, not another WithTLS option.
**Files:** `go-core/utils/testutils/flocilocal/flocilocal.go`, its existing access/
options tests, and the selected IoT/device integration tests.

Host SDK/Node trust and the Cognito endpoint override are implemented; MQTT/TLS,
device trust anchors and the advertised IoT endpoint were not exercised. Use the
existing driver to expose the needed device ports without requiring a machine-wide
host 443 reservation. Set a reachable bare IoT hostname, retain SNI/hostname
verification and use Floci's CA for the device. Exercise MQTT TLS and WSS with
active/inactive/denied certificates where that transport actually enforces them.

Do not claim WSS authentication, HTTPS client-certificate authentication or
Publish/Subscribe authorization from transport success. Those remain Tasks 12-14
and 20.5. After 7.14 is in the image, qualify its exact 128 KiB boundary on each
transport in the affected test PR. No OS-wide trust installation.

## 31.6: Registrar update and mirror lifecycle proof

**Owner:** TEOS. New follow-up to completed groundzero/mirror 27.3/27.4.
**Files:** `deployment/stacks/groundzero/service-test/`,
`deployment/lib/svctest/local_mirror.go`, `local_mirror_watch.go` and their tests.

The source proves groundzero and dependent-service registration, plus
groundzero's registrar delete, not update.
Update the registration custom resource and assert the exact row change in
DynamoDB Local, including the stored stack identity. Retain the real
dependent-stack case now in the harness rather than rebuilding it. Verify
the post-deploy schema check preserves GSIs and TTL.
Assert watcher stop/cleanup after success, cancellation and failed deployment.
The 250 ms watcher is not a barrier. A slow copy can still lose the race to a
warm provider. Record this limitation explicitly; do not lengthen sleeps or
add production registrar retries to claim it solved. Task 34 investigates the
shared backend boundary needed to remove that race.

Include a missing callback or failing provider case with a bounded failure
outcome. Reuse existing Lambda deadline and CFN idle/liveness behavior instead of
introducing a new timeout framework. Preserve legitimate provider progress.
Keep W-22: successful registration does not eliminate the split database.
All deploy/update/delete and failing-provider cases run against disposable local
stacks. Groundzero's AWS test is read-only and must stay so.

Run `go test -short -race -count=1 ./svctest/` from `deployment/lib`, then
`CB_SERVICE_TEST=groundzero make test-service` from TEOS root, adding the
update/negative cases rather than repeating only the recorded create/delete smoke.

## 31.7: Remaining pump loss and cancellation evidence

**Owner:** TEOS. New follow-up to completed W-19 / 28.2/28.3.
**Files:** `go-core/utils/testutils/flocilocal/ddbstreampump/` existing delivery/
pump tests and `deployment/lib/svctest/` pump-result assertions.

Keep rejection of nondefault record age and the already-added harness failure on
failure-queue send errors. Add explicit unexpected-discard assertions and
intentional poison-record expectations, malformed partial responses, cancellation
during backoff and cleanup after an earlier harness failure. Do not suppress the
existing failure signal or build another queue/daemon.

Run the focused short/race pump suite from `go-core`, and the harness suite from
`deployment/lib`. Reuse the existing integration tests when changing actual
delivery, and retain the documented fact that kept containers do not keep the
host pump running.

## 31.8: cbdeploy account-domain safety configuration

**Owner:** TEOS. Recorded complete, 2026-09-17, in `4bfc7ab0c` and PLAN 6.9;
synced at `4514f7d53`. No merged PR is inferred. Do not reopen this fix.
**Files:** `go-services/appstore/cmd/cbdeploy/internal/core/types.go`,
`load_config_test.go` and the existing configuration loader they use.

Resolve `$copy:` and `inherit:` before the account-domain safety comparison.
Preserve the comparison itself and endpoint/deployment-target guards. Test a
copied correct alias, inherited settings, a genuinely wrong account domain and
malformed directives. Do not bypass the check just because the target is local.

From `go-services/appstore/cmd/cbdeploy`, run
`go test -short -race -count=1 ./internal/core/`, then the retained groundzero
undeploy case with a correctly resolved alias if future code touches this path.
The source records the successful rerun; these are retained regression criteria,
not another outstanding implementation task.

## 31.9: Correct dependency-bypass documentation

**Owner:** TEOS. Independent docs-only PR.
**Files:** `deployment/README.md`,
`deployment/_design/deployment-flow.adoc`.

Correct the claim that `--disable-auto-resolve` verifies dependencies are deployed.
The source says it does not perform that check. State the actual behavior and the
normal dependency-resolving path, without removing CLI functionality or claiming
the completed local 27.5 cleanup merged upstream. Keep the Markdown and AsciiDoc
descriptions consistent.
