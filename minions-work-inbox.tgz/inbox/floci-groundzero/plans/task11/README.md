# Task 11: document the IoT policy delete difference in the CloudFormation table

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

Branch `docs/cfn-iot-policy-delete-note`. Title `docs(cloudformation): note that a stack detaches an IoT policy before deleting it`. Needs #3014 merged first: the generator renders a note only for a type that has a row in `supported-resource-types.tsv`, so on its own the line would be a no-op.

Asked by hectorvent on #3014 as a follow-up in its own PR. `IotCfnProvisioner` detaches a policy from its principals before deleting it (Floci refuses to delete an attached policy, and a local teardown must not get stuck on a device that connected while the stack existed), while on AWS the stack delete fails with `DeleteConflictException`. The generated table in `docs/services/cloudformation.md` is where users look for such differences.

- [x] One line under `notes:` in `tools/docs/cfn_resource_types.yaml`, next to the `AWS::IoT::DomainConfiguration` note: `AWS::IoT::Policy: 'deleted after detaching it from its principals; on AWS the delete fails with DeleteConflictException while the policy is attached'`.
- [x] `make docs-sync`, commit the regenerated row of `docs/services/cloudformation.md`; `make docs-check` green. The PR is based on `main`, where the type has no inventory row yet, so the row is not in the diff: whichever of #3014 and #3042 lands second regenerates it (if #3014 merges first, rebase #3042, `make docs-sync`, push the row).
- [x] No tests: docs only. Say so in the PR description, as `CONTRIBUTING.md` asks.

Size: one line plus the generated table row. Not folded into #3014 only because the maintainer asked for a separate PR.

Done 2026-09-04 as #3042 (head ed789b08, one commit, one line): Greptile 5/5 "safe to merge", every check green. It was first stacked on #3014, which made its diff show all the stacked code; re-based onto `main` the same day. Greptile's review of the stacked diff found that stack updates piled up policy versions without limit, fixed on #3014 in four commits (`CreatePolicyVersion` refuses a sixth version with `VersionsLimitExceededException` 409 and AWS's message, one lock over every policy version write and the policy delete, `IotService.makeRoomForPolicyVersion` as one locked step, bounded retry in `IotCfnProvisioner`), with service, provisioner, stack and HTTP tests; #3014 is 5/5 as well.
