# Legacy test-driver migration implementation plan

**Goal:** Finish PLAN.md work-order step 3: replace the remaining ElasticMQ,
MinIO and awsmock callers with the existing Floci driver, then delete the unused
drivers and reuse their common Docker execution code where it is actually shared.

**Architecture:** One PR per numbered leaf below. Caller migrations can land
independently on TEOS `main`; retire each helper only after its callers merge.
No per-service compatibility wrapper, second harness or new container framework.

**Tech stack:** Existing TEOS Go tests and `flocilocal`, AWS SDK Go v2, Docker.

Status: [Task 32](../../TEOS_GROUNDZERO_TASKS.md#task-32-legacy-test-driver-migration).
Source: `PLAN.md` sections 3.1, 5.2 and work-order step 3, explicitly not started.
The old count is fourteen files. The current call sweep finds sixteen calling
test files in fifteen package-sized PR units, plus a stale MinIO comment.
Do not use the old count as a deletion criterion.

## Common migration recipe

Use the actual public API: `flocilocal.New`, `Local.Start`, `Local.Stop`,
`Local.AwsConfig` and, where necessary, `Local.AwsConfigWithDynamoDB`.
The old plan's `Configure`/`Shutdown`/`AWSConfig(t)` names do not exist in this
driver and must not be added merely to copy that example.

Preserve each package's existing test ownership, short-mode skipping, unique
resource names, endpoint safety, cleanup and assertions. Use `t.Cleanup` or its
existing TestMain teardown and existing `ifcore.CbContext` patterns. Create queues
and buckets with a few SDK calls in the test package rather than replacing
`SqsLocal`/`S3Local` with another wrapper. Keep DynamoDB Local for reference
conditional-write behavior.

Run each affected package both with `go test -short -count=1` and with
`go test -count=1` and Docker available. These current calling files have no
`go:build` constraint; preserve any surrounding package convention discovered
when implementing. Run from the owning Go module with the table's package
selected. A green short run that skips the emulator test is not integration proof.
Preserve intentional real-AWS-only denial, encryption and throttling checks.
Do not weaken FIFO assertions to hide P-11, or reintroduce the withdrawn 256 KiB cap.

## Independent caller PRs

All file paths are relative to TEOS. Each row is one PR including its tests and
directly related documentation.

| Task | Calling file(s) | Migration scope |
| --- | --- | --- |
| 32.1 | `go-core/managers/mgrstore/awamgrstore/integration_setup_test.go`; update the stale fixture comment in `s3manager_integration_test.go` | Both S3 setup paths; preserve manager integration behavior |
| 32.2 | `go-core/managers/mgrstore/storeloader/integration_s3_test.go` | S3-backed store loading |
| 32.3 | `go-services/buildingsvc/handlers/configdispatcher/main/main_test.go`, `provider_event_test.go` | All SQS fixture sites in the dispatcher package |
| 32.4 | `go-services/eventsvc/evidencecollector/handlers/clwsubscriber/main_test.go` | Subscriber SQS fixture |
| 32.5 | `go-services/eventsvc/evidencecollector/internal/claimcheck/store_integration_test.go` | Claim-check S3 fixture and payload assertions |
| 32.6 | `go-services/collectorsvc/handlers/collectorscheduler/main_test.go` | Both awsmock and SQS fixtures in this package, preserving trigger/delivery evidence limits |
| 32.7 | `go-services/collectorsvc/handlers/collectorquery/main_test.go` | Query-handler awsmock fixture |
| 32.8 | `go-services/collectorsvc/handlers/collconfigchange/main_test.go` | Configuration-change awsmock fixture |
| 32.9 | `go-services/providers/eastbound/sur/handlers/async-sv/service/integration_test.go` | Async service S3 fixture |
| 32.10 | `go-services/providers/eastbound/sur/handlers/configchange/service/integration_test.go` | SUR configuration-change S3 fixture |
| 32.11 | `go-services/providers/northbound/sma/handlers/health-summary/api/main_test.go` | SMA API S3 fixture |
| 32.12 | `go-services/providers/northbound/sma/handlers/health-summary/lambda/main_test.go` | SMA Lambda S3 fixture |
| 32.13 | `go-services/actuationsvc/handlers/actconfigchange/main/main_test.go` | Actuation configuration S3 fixture; not full actuation deployment proof |
| 32.14 | `go-services/corerouter/handlers/corerouter/main_test.go` | Router SQS fixture; not reserved-topic dispatch proof |
| 32.15 | `go-services/core/management/iam/internal/core/application/admin_service_integration_test.go` | Admin-service awsmock fixture; not proof its missing CFN resource types work |

The provider test migrations above are existing Floci fixture work from PLAN.md,
not the excluded Provider SDK v2 design rewrite. No SDK v2 contracts or branch
document deletions are imported.

## Separate deletion and reuse PRs

| Task | Scope | Required merged callers or predecessor |
| --- | --- | --- |
| 32.16 | Delete `go-core/utils/testutils/sqs_local.go`, its exclusive tests and ElasticMQ image reference after a fresh zero-caller search | 32.3, 32.4, 32.6, 32.14 |
| 32.17 | Delete `go-core/utils/testutils/s3_local.go`, its exclusive tests and MinIO image reference after a fresh zero-caller search | 32.1, 32.2, 32.5, 32.9-32.13 |
| 32.18 | Delete `go-core/utils/testutils/awsmock_local.go`, its exclusive tests and awsmock image reference after a fresh zero-caller search | 32.6-32.8, 32.15 |
| 32.19 | Extract the existing bounded Docker command helpers from `go-core/utils/testutils/flocilocal/docker.go` to `go-core/utils/testutils/dockerexec/`, with Floci and DynamoDB Local as real consumers in the same PR | None; reuse actual shared functions, no single-implementation interface |
| 32.20 | Move `go-core/utils/testutils/neptune_local.go` onto those helpers, preserving its Jena/Fuseki behavior and lifecycle | 32.19 merged |
| 32.21 | Move `go-core/utils/testutils/mqtt_local.go` onto those helpers, preserving Mosquitto behavior and lifecycle | 32.19 merged; independent of 32.20 |
| 32.22 | Pin the retained Jena/Fuseki image in `go-core/utils/testutils/neptune_local.go` using a qualified tag/image-list digest | None; independent of command-helper extraction |

For 32.19, preserve separate pull/start/inspect/log/removal budgets, combined
diagnostics, cancellation, isolated resource cleanup and cleanup after a request
context has already been cancelled. Transfer the existing focused tests with the
functions. Do not rewrite Docker execution wholesale.

For each deletion PR, search the whole workspace for constructors, types and
imports, not only the sixteen files above. Compile affected modules and run the
remaining driver tests. Do not delete shared tests or assets another driver uses.
For 32.22, qualify the retained graph tests on the chosen image and preserve user
overrides; don't pin an architecture-specific manifest as if it were an image list.

After the three retired drivers are gone and the retained image is pinned, audit
remaining defaults under `go-core/utils/testutils` for floating `latest` tags.
DynamoDB Local's 3.3.1 pin is already done (28.1), and the source proposes deleting
the other three floating-image drivers, so temporary repinning of those retired
drivers is not another task. Finish with the existing root `make test-integration`
gate; do not add the removed `make test-service-local` target.
