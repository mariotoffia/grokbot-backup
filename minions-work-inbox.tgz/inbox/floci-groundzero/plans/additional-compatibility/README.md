# Additional compatibility implementation plan

**Goal:** Preserve the concrete source-register gaps omitted from the older
groundzero task index, without reopening delivered implementations.

**Architecture:** One independently useful PR per Task 29 leaf. Reuse the owning
AWS service's existing model, storage and wire path. Each PR includes its own
regression and documentation; no test-only stack is required.

**Tech stack:** Floci Java/Quarkus, existing AWS SDK tests, and TEOS Go for 29.5.

Status: [Task 29](../../TEOS_GROUNDZERO_TASKS.md#task-29-additional-source-register-compatibility).
`SRC` means `src/main/java/io/github/hectorvent/floci`; `TEST` means
`src/test/java/io/github/hectorvent/floci`. Paths otherwise start at the owning
repository root. Reproduce on the selected current base before changing production
code: a WATCH string predicate or open issue is not proof the code is still broken.

## 29.1: API Gateway policy patches, P-7 remainder

**Files:** `SRC/services/apigateway/ApiGatewayService.java`,
`ApiGatewayController.java`, the REST API model and
`TEST/services/apigateway/ApiGatewayIntegrationTest.java`.

Apply supported `UpdateRestApi` `/policy` patch operations through the existing
patch machinery. Preserve valid JSON policy content through read-back, deployment,
update and removal, and reject malformed requests with the AWS error contract.
Cover SDK create/patch/get and a stage deployment.

The `/apiKeyRequired` patch and runtime enforcement already shipped in
floci-io/floci#3537; do not implement them again. Policy storage is not denial
enforcement. The broader resource-policy gap remains deferred in 30.3.

Run `./mvnw test -Dtest=ApiGatewayIntegrationTest` with the added policy cases.
Update `docs/services/apigateway.md`. No predecessor.

## 29.2: EventBridge trace headers, P-8

**Files:** `SRC/services/eventbridge/EventBridgeHandler.java`,
`EventBridgeService.java`, the existing event/target-delivery representation and
`TEST/services/eventbridge/`.

Preserve each PutEvents entry's optional `TraceHeader` through the common
ingestion and supported target-delivery path. Follow AWS's tracing metadata
contract, not a new property inserted into the user's `detail` or a custom
response shape. Missing tracing metadata must preserve existing behavior.

Use a distinct trace header on each of two entries and assert it reaches the
appropriate invocation/target context without cross-entry leakage. Cover both
traced and untraced SDK requests and the existing batch/error semantics.

Run `./mvnw test -Dtest=EventBridgeIntegrationTest,EventBridgeBatchIntegrationTest`.
Update `docs/services/eventbridge.md`. No predecessor; coordinate the touched
delivery file with 29.6, but do not stack for a shared hunk.

## 29.3: Logs Insights boolean OR, P-10 remainder

**Files:** `SRC/services/cloudwatch/logs/LogsInsightsQuery.java`, the existing
query execution path and `TEST/services/cloudwatch/logs/`.

Extend the existing parser for the exact SMA multi-report-type predicate using
`||`, preserving quoted pipe characters and single-pipe pipeline stages. Specify
and test supported boolean grouping/precedence rather than splitting every pipe
or selecting only the first report type. Do not introduce another general SQL engine.

An SDK StartQuery/GetQueryResults case stores distinct report types, returns all
requested types and excludes an unrelated type. Include quoted pipes, parenthesized
predicates and malformed input. Preserve honest rejection of unsupported syntax
from floci-io/floci#3139; this is a new feature, not reopening that completed fix.

Run `./mvnw test -Dtest=CloudWatchLogsInsightsQueryTest` and the SDK query
regression added in this PR.
Update `docs/services/cloudwatch.md`. Independent of metric filters and 6.4.

## 29.4: FIFO deduplication after consumption, P-11

**Files:** `SRC/services/sqs/SqsService.java`, existing persisted deduplication
metadata and `TEST/services/sqs/SqsServiceTest.java`, `SqsIntegrationTest.java`.

Keep deduplication identity and original response identifiers for the full
five-minute window, independently of whether the first message still exists in
the queue. Reuse the existing cache/store and preserve atomic concurrent
admission, queue/message-group scope, account/region isolation and expiry.
Do not retain whole consumed message bodies solely for deduplication.

Regression: send, receive, delete, then send the same dedup ID before expiry.
The duplicate is acknowledged but never delivered again. After expiry, it is
deliverable. Preserve the current request's response MD5 behavior, content-based
deduplication, persistence/reload semantics and reset/purge/deletion boundaries.
Exercise both SQS JSON and Query entry points through their shared service.

Run `./mvnw test -Dtest=SqsServiceTest,SqsIntegrationTest`.
Update `docs/services/sqs.md`. No predecessor.

## 29.5: KMS PSS digest interoperability, P-12 qualification

**Owner:** TEOS, one new qualification PR, not another Floci signing algorithm.

The register watches floci-io/floci#2570 without reading the 2.1.0 KMS source.
Local Floci `570f97582` already has `signRsaPssDigest`, `verifyRsaPssDigest` and
`PSSSigner.createRawSigner` in `SRC/services/kms/KmsService.java`. Do not infer
PKCS#1 substitution from the old issue state or replace that implementation.

Exercise the signing path in `go-core/cbpolicy/utils/runner.go` from a new
`go-core/cbpolicy/utils/runner_kms_integration_test.go` test named
`TestKmsPssDigestInterop`. It requests `RSASSA_PSS_SHA_256` with
`MessageType=DIGEST`; do not create another signer. Fetch the public
key via the SDK and verify the digest signature using the standard Go RSA-PSS
verifier. Also cover RAW/DIGEST interoperability and rejection by the wrong
algorithm, with no secret material in fixtures.

From TEOS `go-core`, run
`go test -count=1 -run TestKmsPssDigestInterop ./cbpolicy/utils/` against the
pinned image using the existing local client setup and endpoint guards. Record
the digest and remove only the obsolete local limitation note.
If this reproduces a Floci defect, file a separate newly numbered minimal
Floci repair task with the failing vector. No guessed crypto rewrite in this PR.

## 29.6: EventBridge target delivery retry and DLQ

**Source:** F-5/W-6's EventBridge half and the 2.1.0 source inspection.
**Files:** `SRC/services/eventbridge/model/Target.java`, `EventBridgeHandler.java`,
`EventBridgeService.java`, the existing target invoker and EventBridge tests.

Add AWS `RetryPolicy` and `DeadLetterConfig` validation, storage/read-back and
actual target-delivery behavior in the same PR. Reuse scheduling/clock and
invocation primitives. Bound retries by configured attempts and event age;
send exhausted/permanent failures to the configured supported SQS DLQ with
AWS's body and failure attributes. Make destination-send failures visible.

Cover SDK PutTargets/read-back, transient refusal then acceptance, exhaustion,
age expiry, a nonretryable refusal, DLQ failure, target update/removal and
account/region isolation. Accepted Lambda invocation followed by a function
error must not trigger another EventBridge delivery: Lambda owns that failure
under Task 21. Target delivery can be tested with a failing SQS target or
controlled invoker, so this PR is independent of Task 21.

Use the existing EventBridge service/integration suites, controlled time for
retry tests and one SDK-to-DLQ test. Update `docs/services/eventbridge.md`.

## 29.7: CloudFormation S3 bucket tags, P-23

**Files:** `SRC/services/cloudformation/provisioners/S3CfnProvisioner.java`,
the existing S3 bucket-tag API, and
`TEST/services/cloudformation/provisioners/S3CfnProvisionerTest.java`.

Apply resolved template `Tags` through the owning service on create and reconcile
them on update/removal. Preserve existing CORS/versioning behavior, stack/system
tags, AWS tag validation, update failure handling and delete behavior.
Do not replace the bucket to update tags.

SDK CFN create/update/remove followed by S3 GetBucketTagging must agree with the
template, including conditional tags. In particular retain CDK's
`aws-cdk:auto-delete-objects` marker. That marker is required by the real Node
auto-delete handler, so 27.7 waits for a containing image as well as TLS.
Successful stack status alone is not proof.

Run `./mvnw test -Dtest=S3CfnProvisionerTest,CfnResourceInventoryTest` plus the
SDK tag-lifecycle regression added in this PR. Update S3/CFN documentation;
no new resource type, storage backend or manual generated-table edit.

## 29.8: Unknown Cognito domain response

**Source:** P-4's remaining DescribeUserPoolDomain contract, separate from
completed Task 2.
**Files:** `SRC/services/cognito/CognitoService.java`, `CognitoJsonHandler.java`
and existing Cognito service/integration tests.

Return AWS's successful empty `DomainDescription` for a missing domain on
DescribeUserPoolDomain. Preserve invalid-input errors and required-existence
semantics for update/delete and internal callers. The current shared service
lookup throws 404 and is also used by mutating paths: do not globally replace
its exception with null to fix this single operation.

Prove exact JSON shape and SDK empty-domain handling, a real known domain,
invalid input and unchanged missing-domain mutation errors. Keep returned types
native-image safe. Update `docs/services/cognito.md`. No predecessor.

## 29.9: CloudFormation SSM parameter tags

**Source:** Remaining CFN requirement from original 15.3, after service-side
P-6 fixes shipped in floci-io/floci#3550 and floci-io/floci#3646.
**Files:** `SRC/services/cloudformation/provisioners/SsmCfnProvisioner.java`,
existing SSM tag APIs and the provisioner's tests.

Forward resolved creation tags and reconcile changed/removed user tags on update
through `SsmService`. Preserve system/stack tags and existing value/type/update
behavior. Use the merged service API, not another tag store or DescribeParameters
implementation.

SDK CFN create/update/removal must match ListTagsForResource and the now-working
tag-filtered DescribeParameters results, including conditional tags and a failed
update that does not silently corrupt the prior resource. Keep
GetParametersByPath in TEOS. This is a new provisioner PR, not reopening 15.3.

Add the CFN-to-SDK tag regression to
`TEST/services/cloudformation/CloudFormationSsmParameterIntegrationTest.java`.
Run `./mvnw test -Dtest=CloudFormationSsmParameterIntegrationTest,SsmServiceTest,SsmIntegrationTest`.
Update `docs/services/ssm.md`. The required service
changes are already in 2.1.0; no pending branch dependency.

## 29.10: DescribeUserPool custom domain

**Source:** TEOS deployed-test discovery in
`go-core/managers/mgriam/mgriamcognito` (`DiscoverAccountDomain` and
`DiscoverDeployment`), confirmed against release 2.1.0 on 2026-09-21. After
CloudFormation created the `AWS::Cognito::UserPoolDomain`
`api.auth.devlocal02.localhost.floci.io`, `DescribeUserPoolDomain` reports the
domain `ACTIVE` with its `CustomDomainConfig`, but `DescribeUserPool` returns
`CustomDomain: null` and `Domain: null`. AWS fills `UserPool.CustomDomain` for
a custom domain and `UserPool.Domain` for a prefix domain.
**Files:** `SRC/services/cognito/CognitoService.java` (the user pool
description), the domain create and delete paths, and the existing Cognito
service and integration tests.

Set `CustomDomain` on the pool's description when a custom domain is created
for it and clear it when that domain is deleted; do the same for `Domain` with
a prefix domain. Read the value from the domain record rather than a second
store, so a domain created through CloudFormation and one created through the
API behave the same.

Prove with the SDK: create a pool, create a custom domain, `DescribeUserPool`
returns it; delete the domain, the field is null again; a prefix domain fills
`Domain` and leaves `CustomDomain` null. Update `docs/services/cognito.md`.

What a person sees today: every TEOS test that attaches to a deployed local
TEOS through `testenv.EnvTEOSDeployed` fails at setup with "Cognito user pool
'...' has no custom domain, so the account domain of the deployment cannot be
read". No predecessor; independent of 29.8.

## 29.11: Launched containers keep their anonymous volumes

**Source:** a TEOS investigation of dangling Docker volumes on 2026-09-21,
read against the Floci source at the `2.1.0` tag (revision `560b3e4a`, the
revision the TEOS image names). Floci removes every container it launches with
`removeContainerCmd(id).withForce(true)` and never adds
`.withRemoveVolumes(true)`. Docker then keeps the anonymous volume it created
for each `VOLUME` the image declares.
**Files:** `SRC/core/common/docker/ContainerLifecycleManager.java` (the removals
near lines 144, 309, 366, 504 for the helper container, 715 in `removeIfExists`
and 734 in `removeIfExistsStrict`),
`SRC/services/ecs/container/EcsContainerManager.java` (near line 318) and
`SRC/services/ec2/Ec2ContainerManager.java` (near line 1085).

Remove each launched container together with its anonymous volumes, in one
place that every removal goes through. Named volumes Floci manages itself,
such as the ECR registry's, keep their own lifecycle.

Prove with Docker: launch an ElastiCache cluster on `redis:7.4-alpine` (which
declares `/data`), delete it, and check that no new dangling volume exists; do
the same for an ECS task whose image declares a volume.

What a person sees today: nothing in TEOS runs, because the Lambda runtime
images and the `busybox` helper declare no volumes and the ECR registry uses a
named volume that TEOS removes. A user of ElastiCache, ECS or EC2 on Floci
collects one dangling volume per launch until they prune by hand. No
predecessor.
