# Lambda Debug Attach Implementation Plan

> **For agentic workers:** Use `subagent-driven-development` or `executing-plans`
> when implementation is authorized. Each numbered leaf is one PR; checkbox
> steps belong inside that PR. Do not implement this entire plan in one PR.

**Goal:** Stop at a VS Code or Zed breakpoint in a Lambda handler when a real
trigger in Floci invokes it (SQS, Kinesis, DynamoDB Streams, S3, SNS,
EventBridge, API Gateway, Function URL, Step Functions or `Invoke`), without
repackaging, an in-container debugger or source-path mapping.

**Architecture:** Lambda is the one compute type whose events Floci delivers
through a pull protocol, the Runtime API. A function tagged
`floci:debug=<label>` gets no container. Floci serves that function's Runtime
API on a fixed, host-reachable port and writes the environment the container
would have received to `<label>.env`. The developer runs the handler's `main`
under the IDE debugger with that env file; its Lambda runtime client polls the port and
receives the real event. Every trigger already funnels through
`LambdaExecutorService.invoke`, `WarmPool.acquire` and
`LambdaRuntimeLauncher.launch`, so one routing branch covers all of them on
both the Docker and the Kubernetes executors.

**Tech Stack:** Java 25, Quarkus, Vert.x, JUnit/Mockito, AWS SDK integration
tests; TEOS Go `flocilocal` for the paired helper.

---

## Scope, estimates and landing order

Recorded 2026-09-23. Status:
[Task 38](../../TEOS_GROUNDZERO_TASKS.md#task-38-lambda-debug-attach).

| PR | Work | Effort | Merge prerequisites |
| --- | --- | --- | --- |
| 38.1 | Forward `AWS::Lambda::Function` `Tags` from CloudFormation | 0.5-1 day | None. Superseded if 17.3 lands CloudFormation-created function tags first. Only needed for CDK-declared debug tags: 38.6 and 38.7 tag at runtime |
| 38.2 | Attach mode: external launcher, fixed port, debug deadline, tag reconcile | 2-3 days | None; `aws lambda tag-resource` works without 38.1 |
| 38.3 | Env file with the function's environment and execution-role credentials | 1-1.5 days | 38.2 |
| 38.4 | TEOS `flocilocal.WithLambdaDebug` and IDE entries | 0.5-1 day | 38.2 and 38.3 in the selected image |
| 38.5 | In-container Delve, inbound HTTP forwarding | Not estimated | Deferred, not scheduled |
| 38.6 | TEOS `cbtest local debug ls/attach/detach`, runtime tagging for Zed and the terminal | 0.5-1 day | 38.4 |
| 38.7 | VS Code extension: "Debug Lambda on Floci" from the open handler, runtime tagging | 2-3 days | 38.3 in the selected image; TEOS use also needs 38.4 |
| **Total** | 38.1-38.4, 38.6, 38.7 | **6.5-10.5 developer-days** | |

Branch each Floci PR from current `main`; wait for named prerequisites to merge
rather than stack.

### Why ECS, EKS and EC2 are out of scope

Those workloads read SQS, Kinesis or HTTP themselves; Floci owns no delivery
channel it could hand to the IDE. They can be debugged on the host today with no
Floci change: run the binary under the debugger with `AWS_ENDPOINT_URL` pointed
at Floci, and scale the emulated copy to zero so it does not compete
(`aws ecs update-service --desired-count 0`, `aws ec2 stop-instances`).
Inbound HTTP to a service behind an emulated ALB is the one gap, recorded
under 38.5.

## Decisions

| Topic | Decision | Reason |
| --- | --- | --- |
| Request | Tag `floci:debug=<label>`, optional `floci:debug-port=<n>` | AWS-native `TagResource` or CDK `Tags.of`, no custom endpoint. The label is stable where CDK generates function names |
| Label | `[A-Za-z0-9._-]{1,64}`, unique across accounts and regions | It becomes a file name, so it is validated at the trust boundary |
| Gate | `floci.services.lambda.debug.enabled`, default `false` | Attached functions deviate from AWS. Disabled means the tags are ordinary tags |
| Port | Tag value, else first free in `debug.base-port`..`debug.max-port` (12500-12509) | Next to the Runtime API range 12000-12499 and small enough to publish from Docker |
| Timeout | `debug.timeout-seconds` (3600) replaces `Timeout` for the dispatch wait and the `PendingInvocation` deadline | That deadline is also `Lambda-Runtime-Deadline-Ms`, which becomes Go's `ctx` deadline. A normal one cancels SDK calls after a pause |
| Concurrency | One shared handle per attached function; invocations queue in its `RuntimeApiServer` | The port binds once, and the server already holds invocations until a poller arrives |
| Handle lifetime | Invocation errors never destroy an attached handle; only detach does | Closing the port would drop the IDE's runtime client mid-session |
| Bind failure, label clash | Warn with function, label and port; the function runs normally | A broken debug setup must not break the stack |
| Env file | `debug.env-dir` (`./data/lambda-debug`), `<label>.env`, 0600, written on attach, deleted on detach | Written before the developer presses F5. VS Code substitutes variables and vscode-go reads `envFile` before `preLaunchTask` runs, so a task-generated file would be one run late |
| Endpoint in env file | `EmulatorConfig.baseUrl()`, not `effectiveBaseUrl()` | TEOS sets `FLOCI_HOSTNAME` to a Docker alias the host cannot resolve; `FLOCI_BASE_URL` is host-facing |
| Credentials | The container's own `LambdaExecutionRoleCredentials.forFunction` session | Non-expiring and role-scoped, so IAM enforcement evaluates the role exactly as for the container. Written once per attach |
| IDE workflow | The extension (38.7) or `cbtest local debug` (38.6) tags at runtime; label = function name. No CDK change | Debugging is a runtime choice, not a deploy-time one. Function names already fit the label pattern, so the env file path is predictable |
| Discovery | `docker ps` and `docker inspect`: every running container whose env has `FLOCI_SERVICES_LAMBDA_DEBUG_ENABLED=true`. Endpoint from the host port published for `4566/tcp`; env dir from the host source of the mount covering `FLOCI_SERVICES_LAMBDA_DEBUG_ENV_DIR`; account from `FLOCI_DEFAULT_ACCOUNT_ID`, else `000000000000`; region from setting `flociLambdaDebug.region`, prompted and saved when unset. A Floci run outside Docker is added by setting | Live state, so no stale marker after a crash, and no Floci or TEOS change. Independent of image name and of TEOS labels |
| Handler detection | None. Any `func main()` gets the CodeLens; any Go file or folder gets the menu item | Handlers wrapped in other types never call `lambda.Start` directly. A wrong pick just runs a program that never polls |
| Function choice | Always show every function. Walk up from `main.go`'s folder (at most four folders); each folder whose name some function contains adds those candidates, nearest folder first; the rest follow alphabetically. The last choice for that folder goes first | The guess saves a keystroke; the list keeps any function reachable. Folders like `handler` match nothing and are passed over without a stop list |
| Extension home | Separate repository, `mariotoffia/vscode-floci-lambda-debug` | TypeScript toolchain and extension release cycle stay out of Floci's Maven build. Move to `tools/` if upstream asks for it |

## File map

Floci paths are relative to `src/main/java/io/github/hectorvent/floci/` unless
they start at the repository root.

- `services/cloudformation/CloudFormationResourceProvisioner.java`:
  `provisionLambda` desired state, create `Tags`, update tag diff (38.1). A
  property fix on an existing type in the legacy monolith, not a new type.
- `services/lambda/launcher/ExternalRuntimeLauncher.java` (new, 38.2):
  implements `LambdaRuntimeLauncher`. `launch` returns a handle with no
  container around a fixed-port `RuntimeApiServer`; `isAlive` is the server's
  state; `stop` closes it.
- `services/lambda/runtime/RuntimeApiServerFactory.java`: `create(int port)`
  beside the allocating `create()` (38.2).
- `core/common/port/PortAllocator.java`: its `(int, int)` constructor is
  package-private; the debug range needs a second instance (38.2).
- `services/lambda/WarmPool.java`: route attached functions, share their handle,
  keep them out of the idle pool and eviction (38.2).
- `services/lambda/LambdaExecutorService.java`: effective timeout for attached
  handles in `executeSync` (38.2).
- `services/lambda/LambdaService.java`: reconcile after create, tag, untag,
  update configuration and delete; `rehydrateDebugAttach()` beside
  `rehydrateConcurrency()` in `init()` (38.2).
- `services/lambda/launcher/ContainerLauncher.java`: extract the environment
  block into one method both launchers call (38.3).
- `core/common/docker/LaunchedContainerAwsEnv.java`: reuse the five-argument
  `sdkBaselineEnv` with an explicit endpoint; no change expected (38.3).
- `config/EmulatorConfig.java`, `src/main/resources/application.yml`,
  `src/test/resources/application.yml`: `floci.services.lambda.debug.*`.
- `docs/services/lambda.md`: "Debugging from an IDE" section and config rows.
- Tests under `src/test/java/io/github/hectorvent/floci/services/`:
  `lambda/launcher/ExternalRuntimeLauncherTest.java` (new),
  `lambda/WarmPoolTest.java`, `lambda/LambdaExecutorServiceTest.java`,
  `lambda/LambdaDebugAttachIntegrationTest.java` (new),
  `lambda/launcher/ContainerLauncherTest.java`,
  `cloudformation/CloudFormationIntegrationTest.java`.

TEOS: `go-core/utils/testutils/flocilocal/options.go`, `flocilocal.go`,
`cmd/cbtest/op_local.go`, `go-core/docs/testing/local-environments.md` (38.4);
`cmd/cbtest/op_local_debug.go` (new, 38.6).

Extension repository (38.7): `package.json` (commands, menus, settings),
`src/extension.ts` (activation, CodeLens, commands), `src/docker.ts`
(discovery), `src/floci.ts` (`ListFunctions`, `TagResource`, env-file wait),
`src/pick.ts` (best-match preselection), `src/detach.ts` (session end and
restart grace), `test/*.test.ts`.

## 38.1: CloudFormation Lambda tags

CDK `Tags.of(fn)` reaches Floci as the `Tags` property of
`AWS::Lambda::Function`. `provisionLambda` does not forward it today, so a
CDK-declared debug tag never reaches the function.

- [ ] Check whether 17.3 merged with CloudFormation-created function tags. If
      it did, record 38.1 as 🟢S and stop.
- [ ] Resolve `Tags` (a list of `Key`/`Value`) in the desired state and pass it
      as `Tags` in the create request. `LambdaService.createFunction` already
      stores a `Tags` map.
- [ ] On update, diff prior and desired tags: `tagResource` for added or changed
      keys, `untagResource` for removed ones. Dropping the property removes the
      stack-applied tags. Tags added outside the stack are left alone.
- [ ] Cover create, change one, drop one and drop the property in the existing
      CloudFormation integration test, asserting through `ListTags`.
- [ ] Run:

```sh
./mvnw test -Dtest=CloudFormationIntegrationTest,CfnResourceInventoryTest
```

Expected: `ListTags` agrees with the template after create and each update.

## 38.2: Attach mode

- [ ] Config under `floci.services.lambda.debug`: `enabled` (`false`),
      `base-port` (`12500`), `max-port` (`12509`), `timeout-seconds` (`3600`).
      Add to `EmulatorConfig` and both YAML files; environment variables follow
      `FLOCI_SERVICES_LAMBDA_DEBUG_*`.
- [ ] Add `RuntimeApiServerFactory.create(int port)`. Debug ports come from a
      second `PortAllocator` over the debug range, used only when the function
      has no `floci:debug-port` tag. Reject tag ports outside 1024-65535.
- [ ] `ExternalRuntimeLauncher`: handle id `external:<label>`, no Docker or
      Kubernetes calls. It keeps one handle per label.
- [ ] `WarmPool.acquire` returns the attached function's single handle and marks
      it busy. `release` does not pool it; idle eviction and `drainAll` skip it.
      `destroyHandle` on an attached handle is a no-op except on detach.
- [ ] One `reconcileDebugAttach(fn)` in `LambdaService` after create, tag,
      untag, update configuration and delete, and for every stored function in
      `init()`. Attach opens the port and logs
      `Lambda <fn> attached as <label>: AWS_LAMBDA_RUNTIME_API=127.0.0.1:<port>`.
      Detach closes it and drains the function's pool, so the next invocation
      cold-starts a container.
- [ ] `LambdaExecutorService.executeSync`: for an attached handle, use
      `debug.timeout-seconds` for the dispatch wait and the `PendingInvocation`
      deadline. Reserved concurrency and throttling are unchanged.
- [ ] Unit tests: the fixed port binds and closes; a second launch for the same
      label reuses the handle; an attached function never reaches the container
      launcher (mocked); eviction and `drainAll` keep the handle; detach stops it
      and the next acquire goes to the container launcher; the attached
      deadline is about now plus the debug timeout, not `Timeout`.
- [ ] `LambdaDebugAttachIntegrationTest` with a `@TestProfile` enabling debug,
      following `LambdaExecutionRoleDockerIntegrationTest`. No container ever
      starts, so it needs no Docker. The test plays the runtime:
  - create a function and tag it `floci:debug=it-attach`, `floci:debug-port=12505`
  - start an SDK `Invoke` on another thread
  - GET `http://127.0.0.1:12505/2018-06-01/runtime/invocation/next`; assert the
    payload and a `Lambda-Runtime-Deadline-Ms` more than 30 minutes ahead
  - POST `{"ok":true}` to `/response`; assert `Invoke` returned it
  - repeat through an SQS event source mapping: the event has
    `Records[0].eventSource == "aws:sqs"` and the message is deleted after the
    response
  - `UntagResource`; the port refuses connections
- [ ] Docs: "Debugging from an IDE" in `docs/services/lambda.md`, listing the
      deviations: no container, no timeout, one invocation at a time, and that
      synchronous callers such as API Gateway still apply their own timeouts.
- [ ] Run:

```sh
./mvnw test -Dtest=ExternalRuntimeLauncherTest,WarmPoolTest,LambdaExecutorServiceTest,LambdaDebugAttachIntegrationTest,LambdaRuntimeLauncherProducerTest
```

Expected: with `debug.enabled=false`, the existing Lambda suites pass unchanged.

## 38.3: Env file with the function's identity

- [ ] Extract `ContainerLauncher`'s environment block (Runtime API,
      `AWS_LAMBDA_*`, `_HANDLER`, `sdkBaselineEnv` with the `forFunction`
      session and owner account, the function's `Environment` with the
      credential-triad rule) into one method taking the Runtime API endpoint and
      the Floci endpoint. The container env must not change; existing
      `ContainerLauncherTest` assertions pass.
- [ ] On attach, write `<debug.env-dir>/<label>.env` from that method with
      `AWS_LAMBDA_RUNTIME_API=127.0.0.1:<port>` and the endpoint
      `config.baseUrl()`. Write a temporary file and move it into place, 0600
      where POSIX permissions exist. Mint the role session once per attach and
      reuse it; mint a new one, unregistering the old, only when `Role`
      changes. On reconcile, rewrite only when the content differs, so a stack
      update that re-applies unchanged configuration never invalidates a
      running debug session. Delete the file and unregister the session on
      detach and at shutdown. IAM policy edits need no rewrite: enforcement
      reads the role's policies per request (`collectRolePolicies`).
- [ ] With `aws-config-path` set, omit credentials, `AWS_CONFIG_FILE` and
      `AWS_SHARED_CREDENTIALS_FILE`, so the host SDK reads the developer's own
      `~/.aws`. `AWS_CA_BUNDLE` for TLS stays the developer's; TEOS prints its
      host path.
- [ ] Format: one `KEY=VALUE` per line, double-quoted when the value holds
      whitespace, `#` or quotes. A value containing a newline is skipped with a
      warning naming the key. Check the result parses identically in vscode-go
      and in Zed's Delve `envFile`.
- [ ] Add `debug.env-dir` to `EmulatorConfig` and both YAML files.
- [ ] Tests: the file equals the container env except the two substitutions;
      it is 0600 and removed on untag; an unchanged update configuration
      leaves it byte-identical and the session valid; a `Role` change replaces
      the session and the old keys are rejected; it carries the role session when the
      role exists and the owner-account key otherwise. Under an IAM-enforcement
      profile, the file's credentials authorize an SDK call the role allows and
      are denied one it does not; after `PutRolePolicy` allows it, the same
      keys succeed without a rewrite.
- [ ] Docs: the env file, the IDE entries below, and why no `preLaunchTask`.
      Confirm the variable and `envFile` ordering against the current VS Code
      and vscode-go releases before stating it.
- [ ] Run:

```sh
./mvnw test -Dtest=ContainerLauncherTest,LambdaDebugAttachIntegrationTest
```

## 38.4: TEOS paired helper (separate repository PR)

- [ ] `flocilocal.WithLambdaDebug(hostEnvDir string)`: sets
      `FLOCI_SERVICES_LAMBDA_DEBUG_ENABLED=true` and
      `FLOCI_SERVICES_LAMBDA_DEBUG_ENV_DIR=/floci-debug`, and mounts
      `hostEnvDir` at `/floci-debug`. `options.go` has no publish or mount
      option today, so add the plumbing. Default runs are unchanged.
- [ ] Several environments at once: pick a free 10-port block on the host,
      publish it with the same host and container numbers, and pass it as
      `FLOCI_SERVICES_LAMBDA_DEBUG_BASE_PORT`/`_MAX_PORT`. The port Floci
      writes is then the host port, and a second environment neither fails to
      start nor steals the first one's ports. `hostEnvDir` is per environment,
      so equal labels in two environments never overwrite each other.
- [ ] `cbtest local serve --lambda-debug`, defaulting to a gitignored
      `<repo>/.floci-debug/<environment>`, and prints the env-file folder.
- [ ] Document in `go-core/docs/testing/local-environments.md`: tag through
      `aws lambda tag-resource`, or in local deploys only through
      `awscdk.Tags_Of(fn).Add(jsii.String("floci:debug"), jsii.String("<label>"), nil)`,
      which needs 38.1; the IDE entries below.
- [ ] Qualify with the image containing 38.2 and 38.3: keep a service-test
      environment, tag one handler, start the debugger, send an SQS message; the
      breakpoint hits, the response completes and the message is deleted.

## 38.6: TEOS `cbtest local debug` (separate repository PR)

Runtime tagging from the terminal or a Zed task. No CDK change.

- [ ] `cbtest local debug ls [--name <env>]`: the environment's functions and
      whether each is attached. Endpoint and region come from `localenv`
      discovery, like `cbtest local exec`; the env dir from the Floci
      container's mount. Without debug enabled, fail with "Lambda debug is off,
      start with `--lambda-debug`".
- [ ] `cbtest local debug attach <function> [--name <env>]`: `TagResource`
      `floci:debug=<function>`, wait up to 10 s for `<function>.env`, print its
      path. On timeout, point at Floci's log (bind failure or label clash).
- [ ] `cbtest local debug detach <function>|--all`: `UntagResource`; the next
      invocation cold-starts a container.
- [ ] Unit tests with a fake Lambda client: attach tags and returns the path
      once the file appears; timeout returns an error; `--all` detaches only
      attached functions.
- [ ] Docs: the Zed flow (a task running `attach`, then a static
      `debug.json` entry with `envFile` `<function>.env`) in
      `go-core/docs/testing/local-environments.md`.

## 38.7: VS Code extension (separate repository)

"Debug Lambda on Floci" from the open handler. The extension does all tagging
at runtime and owns the ordering, so no `preLaunchTask`, `${input:}` or
third-party extension is involved. It assumes the function, its role,
environment and triggers are deployed; the debugger only replaces the code, so
code edits need a restart, not a redeploy.

- [ ] Entry points, all running one command with the file's folder: CodeLens
      "Debug on Floci" above every `func main()` in a Go file, editor and
      explorer context menu on Go files and folders, command palette. No
      handler detection: wrapped handlers never call `lambda.Start` directly,
      and a wrong pick just runs a program that never polls.
- [ ] Discovery through the `docker` CLI: `docker ps -q`, then
      `docker inspect`; keep containers whose env has
      `FLOCI_SERVICES_LAMBDA_DEBUG_ENABLED=true`.
  - endpoint: `http://127.0.0.1:<host port>` published for `4566/tcp`
  - env dir: host `Source` of the mount covering
    `FLOCI_SERVICES_LAMBDA_DEBUG_ENV_DIR` (default `data/lambda-debug` under
    the container's working directory). Not mounted: skip the container and
    say why.
  - account: `FLOCI_DEFAULT_ACCOUNT_ID` from the container env, else
    `000000000000`. The account id is the access key (`AccountResolver`).
  - region: setting `flociLambdaDebug.region`. Unset: a quick pick of AWS
    regions, the container's `FLOCI_DEFAULT_REGION` (else `us-east-1`)
    first, saved to workspace settings. Nothing TEOS-specific.
  - name: the container name.
  - setting `flociLambdaDebug.environments` adds `{name, endpoint, envDir,
    region, accountId}` entries for Floci run outside Docker.
  - more than one environment: quick pick, last choice first. None: say debug
    is off and how to enable it. Docker missing or unreachable: fall back to
    the setting and say so.
- [ ] Function: `ListFunctions` (paged) against the environment. The quick
      pick always lists every function, marks attached ones, and preselects
      the last choice for this folder and environment, else the first
      candidate. Candidates come from walking up from `main.go`'s folder, at
      most four folders (the folder and three parents), stopping at the
      workspace root. At each folder, a function is a candidate when its name
      contains the folder name, both lowercased with `-` and `_` removed;
      folder names under three characters are skipped. A folder with no
      candidate is passed over, so `handler` in
      `collectorsvc/ingest/handler/main.go` yields nothing and `ingest` does.
      The list is ordered: candidates of the nearest folder first, then each
      folder further up, then every other function alphabetically. Within one
      folder, candidates sharing the longest common substring with the folders
      above come first, so `collectorsvc` puts `collector-ingest` before
      `billing-ingest`; then alphabetical. A function appears once, at its
      nearest folder. Enter accepts the first; typing filters to any other.
- [ ] Attach: `TagResource` `floci:debug=<function>` unless already attached;
      wait up to 10 s for `<envDir>/<function>.env`; then
      `vscode.debug.startDebugging` with `type: go`, `request: launch`,
      `mode: debug`, `program: <folder>`, `envFile: <path>`,
      `name: λ <function> (<environment>)`.
- [ ] Detach: when the session ends, untag after a 3 s grace, cancelled if a
      session for the same function starts (restart). Command "Floci: Detach
      all Lambdas" untags every function the extension attached (kept in
      workspace state), also run best-effort on deactivate.
- [ ] Dependencies: `@aws-sdk/client-lambda`, bundled with esbuild. The Go
      extension is an `extensionDependencies` entry.
- [ ] Unit tests (mocha, no VS Code host): `docker inspect` JSON fixtures to
      environments (published port, mount mapping, defaults, unmounted env
      dir skipped); region prompt only when the setting is unset, then saved;
      best-match order: both `collectorsvc/handlers/ingest/main.go` and
      `collectorsvc/ingest/handler/main.go` list the `ingest` functions first
      with `collector-ingest` ahead of `billing-ingest`; candidates of several
      folders keep folder order without duplicates; no candidate at any folder
      leaves the plain alphabetical list; the last choice goes first; env-file
      wait succeeds and times out; grace detach runs once and is cancelled by a
      restart. `vsce package` produces an installable `.vsix`; Marketplace
      publishing is out of scope.
- [ ] Qualify against a kept TEOS environment (38.4): open a handler's
      `main.go`, click the CodeLens, pick the function, send an SQS message;
      the breakpoint hits, the message is deleted, and stopping the session
      returns the function to containers.

## 38.5: Deferred, not scheduled

Only with a failing case and maintainer approval:

- `floci:debug-delve`: mount a Linux `dlv`, wrap the entrypoint in
  `dlv exec --headless --listen=:2345 --accept-multiclient --continue`, publish
  the port and relax timeouts and health checks. For Lambda it exercises layers,
  extensions and native dependencies; for ECS it debugs the production image
  unchanged; for EC2 it saves an SSH session. It needs an architecture-matched
  `dlv`, the image's own entrypoint for ECS and possibly `SYS_PTRACE`.
- Forwarding inbound HTTP from an emulated ALB target to a host process.

## IDE entries

The port is not written here: `AWS_LAMBDA_RUNTIME_API` is in the env file. The
folder name (`alpha`) picks the environment; copy the entry per environment.
Program paths are illustrative.

VS Code `launch.json`:

```jsonc
{
  "name": "λ collector-ingest (Floci attach)",
  "type": "go",
  "request": "launch",
  "mode": "debug",
  "program": "${workspaceFolder}/go-services/collectorsvc/handlers/ingest/main",
  "envFile": "${workspaceFolder}/.floci-debug/alpha/collector-ingest.env"
}
```

Zed `.zed/debug.json` (`envFile` for Delve needs a Zed release from July 2025 on):

```json
[
  {
    "label": "λ collector-ingest (Floci attach)",
    "adapter": "Delve",
    "request": "launch",
    "mode": "debug",
    "program": "./go-services/collectorsvc/handlers/ingest/main",
    "envFile": "./.floci-debug/alpha/collector-ingest.env"
  }
]
```
