# Cancelled SQS long poll implementation plan

**Goal:** A `ReceiveMessage` long poll whose client has gone away must not take
a message that nobody will read, if Amazon SQS behaves that way too.

**Architecture:** Measure Amazon SQS first. Change Floci only when AWS drops an
abandoned poll. The change stays inside the SQS receive loop and the three
controllers that serve outside clients. Callers inside Floci keep today's
behaviour.

**Tech stack:** Floci Java/Quarkus (Vert.x HTTP server), existing SQS tests, the
Go SDK compatibility tests, and TEOS Go for the marker removal.

Status: [Task 39.13](../../TEOS_GROUNDZERO_TASKS.md#task-39-gobridge-on-floci).
`SRC` means `src/main/java/io/github/hectorvent/floci`; `TEST` means
`src/test/java/io/github/hectorvent/floci`. Other paths start at the owning
repository root. Recorded 2026-10-01.

## What a person sees

The GoBridge runtime (TEOS's message bridge) reads each outbound SQS queue with
a 20-second long poll. When it stops a route, it cancels that poll. A route
stops when a link is removed or changed, or when the runtime itself stops.

On Floci the cancelled poll keeps waiting on the server. If a message arrives
during the rest of those 20 seconds, the poll takes it. The answer goes to a
closed connection, so nobody reads the message. The message then stays hidden
for the queue's 60-second visibility timeout. It also uses one of the five
receives the GoBridge queues allow before they move a message to the
dead-letter queue.

In TEOS this shows up in two GoBridge integration tests. Each sends a message
right after the runtime stopped a route, then reads it back. A 5-second read
failed whenever the message arrived inside the abandoned poll's wait, so both
tests now wait up to 90 seconds.

## Evidence in the Floci source

Read on local `main` `e6ee34676` (committed 2026-09-30 00:03 -0400).
`SqsService.java`, `GuardedMessageQueue.java`, `SqsJsonHandler.java` and
`SqsQueryHandler.java` are identical on fork `origin/teos` `2cdcf003b` and
upstream `main` `8ff1eae12`.

- `SRC/services/sqs/SqsService.java` `receiveMessage` (1092-1148) holds a long
  poll in a loop (1116-1147). The loop ends in only four ways:
  - a claim returns messages (1125-1134);
  - the wait time passes (1135-1138);
  - the queue was deleted (1117-1124);
  - the thread is interrupted (1143-1146).
- Nothing in the loop asks whether the client is still connected.
- Between turns the poll waits on the queue's lock for at most one second
  (1139-1142). Each `SendMessage` wakes it at once through `notifyReceivers`
  (1044-1051, called from `sendMessage` at 889 and 912).
- The woken poll claims the new message. `SRC/services/sqs/GuardedMessageQueue.java`
  `tryClaim` raises its receive count (109), gives it a new receipt handle and
  hides it until now plus the visibility timeout (121).
- The entry points pass no connection information. `SqsJsonHandler`
  `handleReceiveMessage` (252-263) and `SqsQueryHandler` `handleReceiveMessage`
  (267-277) are called from `SRC/core/common/AwsJsonController.java` (96, 144),
  `AwsJsonCborController.java` (414) and `AwsQueryController.java` (268, 305).
- The deleted-queue check at 1117-1124 already refuses to let a stale poll
  take a message or use up its receive count. The new check follows the same
  rule for a poll whose client has gone.

## Evidence in TEOS

On TEOS branch `gobridge-svc`, not yet committed on 2026-10-01:

- `go-services/core/brokers/gobridge/tests/integration/lifecycle_test.go:239`,
  in `TestIntegration_LinkRemovalStopsTheSessionAndConsumesNothingAfterwards`.
- `go-services/core/brokers/gobridge/tests/integration/gobridgectl_test.go:152`,
  in `TestIntegration_GobridgectlRedrivesARuntimeProducedRecordAndAuditsIt`.

Both carry `// floci: Missing Implementation for cancelled SQS long polls.` and
wait `(SQSLongPollSeconds + SQSVisibilityTimeoutSeconds + 10) * time.Second`.
The two constants are 20 and 60
(`deployment/models/services/gobridge/gobridge_identifiers.go:18-19`), so the
wait is 90 seconds. These tests start `floci/floci:latest` through the GoBridge
library's fixture (`github.com/mariotoffia/gobridge/testutil/flocilocal` v0.5.0,
`defaultImage` in `flocilocal.go:73`). The `FLOCI_IMAGE` environment variable
overrides that image. The fix therefore reaches these tests only through an
upstream image, or through `FLOCI_IMAGE`.

## Step 1: measure what Amazon SQS does

AWS does not document what happens to a long poll whose client disconnects.
Nobody has checked it for TEOS. Do this before any Floci change.

1. Write a small Go program with `aws-sdk-go-v2`, the client the GoBridge
   runtime uses. It then disconnects exactly as the runtime does, whether the
   SDK talks HTTP/1.1 or HTTP/2 to SQS.
2. In an AWS test account, create a standard queue with a random name,
   `VisibilityTimeout` 60 and `ReceiveMessageWaitTimeSeconds` 0.
3. Run 20 rounds. In each round:
   - start `ReceiveMessage` with `WaitTimeSeconds` 20 under a context that is
     cancelled after 2 seconds;
   - 1 second after the cancel, send a message with a unique body;
   - receive with `WaitTimeSeconds` 5, asking for `ApproximateReceiveCount`;
   - record whether the unique message came back, how long it took, and its
     receive count;
   - if it did not come back, keep receiving for up to 90 seconds and record
     when it appears and its receive count, then delete it.
4. Delete the queue, also when the program fails.
5. Record the rounds in this plan and in row 39.13.

Reading the result:

- Every round returns the message within 5 seconds with receive count 1: AWS
  drops an abandoned poll. Do step 2.
- Any round hides the message for about 60 seconds, or returns receive count 2:
  AWS can hand a message to an abandoned poll. AWS spreads a queue over many
  hosts, so a mix of results still means this. Floci then matches AWS. Do not
  change Floci. Mark row 39.13 dropped with the recorded rounds, and do the
  TEOS changes under "If AWS also delivers to an abandoned poll" below.

If the Floci pull request needs a replayable capture, commit the program under
`tools/aws-capture/sqs/`, next to the existing `cloudwatchlogs` capture.

## Step 2: the Floci change, only if AWS drops an abandoned poll

Open an upstream issue with the recorded rounds first, then one pull request
that closes it.

**Files:**

- `SRC/services/sqs/SqsService.java`: `receiveMessage` takes a
  `BooleanSupplier` that reports whether the client has gone. At the top of
  every loop turn, before `doReceiveMessage` claims anything, return an empty
  list when it reports true. Keep the current signature as an overload that
  never reports a gone client. The Lambda poller
  (`SRC/services/lambda/SqsEventSourcePoller.java:190`), the Pipes poller
  (`SRC/services/pipes/PipesPoller.java:165`), API Gateway service integrations
  (`SRC/services/apigateway/AwsServiceRouter.java:197`) and Step Functions
  (`SRC/services/stepfunctions/AslExecutor.java`) have no outside client and
  keep that overload.
- `SRC/services/sqs/SqsJsonHandler.java` and `SqsQueryHandler.java`: pass the
  check through to `receiveMessage` for `ReceiveMessage` only.
- `SRC/core/common/AwsJsonController.java`, `AwsJsonCborController.java` and
  `AwsQueryController.java`: build the check from the current request. Read
  the Vert.x `RoutingContext` through `CurrentVertxRequest`, as
  `SRC/core/common/MissingHostHeaderFilter.java` (57-73) does, and use
  `routingContext.response().closed()`. For HTTP/1.1 this turns true when the
  connection closes. For HTTP/2 it turns true when the client resets the
  stream.
- `docs/services/sqs.md`, section "Long Polling" (line 83): say that a long
  poll whose client disconnects ends without taking a message.

No wake-up hook is needed. A send already wakes the poll, and the check runs
before the claim. Without a send, the poll notices the gone client within its
one-second wait.

One race stays. The client can disconnect after the claim and before the answer
is written. Then the message stays hidden, as a lost answer does on AWS. Close
that window only if step 1 shows AWS returning such messages at once.

**Tests:**

- `TEST/services/sqs/SqsServiceTest.java`: a poll parked with a gone-client
  check that turns true, then a send. The poll returns empty within about one
  second. A receive with `WaitTimeSeconds` 0 then gets the message with receive
  count 1. Copy the thread and latch pattern of `deleteQueueReleasesParkedLongPoll`
  (1896).
- `TEST/services/sqs/SqsJsonProtocolTest.java`: open a raw socket, write a JSON
  `ReceiveMessage` with `WaitTimeSeconds` 10, close the socket after 300 ms,
  send a message, and receive it at once with `ApproximateReceiveCount` 1.
  Repeat once through the query protocol, the form-encoded path of
  `AwsQueryController`.
- `compatibility-tests/sdk-test-go/tests/sqs_test.go`: the step 1 round
  against Floci, with a Go SDK receive under a context cancelled after 1 second.
  This is the GoBridge runtime's own client.
- A poll whose client stays connected still returns a message that arrives
  during its wait. `queueDefaultLongPollReturnsAsSoonAsAMessageArrives`
  (`SqsServiceTest.java:2027`) already covers this and must keep passing.

Run `./mvnw test -Dtest=SqsServiceTest,SqsJsonProtocolTest,SqsIntegrationTest`
and the Go SDK SQS tests.

## TEOS removes the marker

Only after the fix is in `floci/floci:latest`, the image the GoBridge fixture
pulls. One TEOS pull request:

1. Search the GoBridge module for `cancelled SQS long polls`.
2. In `tests/integration/lifecycle_test.go` and
   `tests/integration/gobridgectl_test.go`, delete the marker and the comment
   paragraph above it that explains the abandoned poll.
3. Replace the 90-second `hidden` wait with a 10-second receive, as
   `tests/integration/preflight_test.go:34` uses.
4. Run `make -C go-services/core/brokers/gobridge test-integration` three
   times. Both tests must pass every time.
5. Remove the marker's row from the Task 27 marker table.

## If AWS also delivers to an abandoned poll

Floci is right, so the marker names something that is not missing.

1. In both TEOS tests, delete the marker comment. Keep the 90-second wait.
   Rewrite its comment to say Amazon SQS behaves the same way, and cite the
   recorded rounds.
2. Correct GoBridge `DESIGN.md` (lines 213-216). It says a changed link "is
   disconnected for its drain (at most the 30-second drain timeout) plus the
   time to reconnect". For messages read from SQS that is not the whole delay.
   A message that arrives while the old route's last poll is still open is
   hidden for another 60 seconds. It also uses one of the queue's five receives
   (`maxReceiveCount`, `deployment/lib/adapters/cdk/gobridge/names.go:18`).
3. Decide with the owner whether to ask the GoBridge library to let a stopping
   route's last poll finish and make anything it got visible again, instead of
   cancelling it.
4. Mark row 39.13 dropped and remove the marker's row from the Task 27 marker
   table.
