# Task 9: runtime fidelity fixes found by the call sweep

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

The TEOS T12/T13 requirements below are historical source descriptions. Their
remaining execution is now one PR each: [27.14 and 27.13](../teos-adoption/README.md).
T11 remains completed and must not be implemented again.

Three one-file `fix` PRs plus two small `feat` PRs (9.4, 9.6), independent of everything above; analysis section 14. Found by following every AWS SDK call in `go-core` and the service Lambdas into Floci's source. Of about 120 operations TEOS calls at runtime, only fleet indexing is missing; these are the places where an implemented operation answers differently enough to break TEOS.

- [ ] `fix(iot): name the thing type deprecation date as AWS does`. `IotController.buildThingTypeDescription` (line 1000) writes `thingTypeMetadata.deprecatedDate`; AWS writes `deprecationDate`. The Go SDK leaves the field nil and `devicemanager_aws.go` line 325 dereferences it, so `GetDeviceType()` panics against Floci. One key rename; SDK test in `IotIntegrationTest`.
- [ ] `fix(iot): honour attributePayload.merge, thingTypeName and expectedVersion on things`. `updateThing` (lines 104-116) reads only the attributes and `expectedVersion`; the service replaces the attribute map. TEOS `UpdateDevice` sends `Merge: true`, so a partial update wipes every other attribute locally. TEOS 27.18 removes the marker once this ships. Merge when `merge=true` (AWS default is replace), set or clear the thing type (`thingTypeName`, `removeThingType`), `VersionConflictException` on a stale `expectedVersion` in `DeleteThing`, store and echo `billingGroupName`.
- [ ] `fix(logs): use AWS's ResourceNotFoundException messages`. `CloudWatchLogsService` appends `: <name>` to `The specified log group does not exist` and `The specified log stream does not exist` (lines 219-220, 357-358, 378-379); AWS ends with a period and no name. TEOS `clwlog/cloudwatch.go` 527-554 switches on the exact text to decide whether to create the group or the stream, so `PutLogEvents` never auto-creates on Floci. Update the Floci tests that assert the old text. TEOS 27.19 then removes its four marker sites.
- [ ] `feat(iot): indexing configuration`. Store and echo `UpdateIndexingConfiguration`/`GetIndexingConfiguration`, answer `DescribeIndex` for `AWS_Things` as `ACTIVE`, so devicesvc's `enable-fleet-indexing` lifecycle script passes locally. `SearchIndex` itself stays ISSUES F-3 (larger: a query subset over the thing store plus `connectivity.connected` from the broker's sessions).
- [ ] Optional `docs(cognito)`: `AdminEnableUser`, `AdminDisableUser`, `AdminResetUserPassword` and `AddCustomAttributes` exist in `CognitoJsonHandler` but `docs/services/cognito.md` does not list them; register the handler in `tools/docs/services.yaml` so the table is generated.
- [ ] 9.6 `feat(iot): return device shadow metadata as AWS does`. `IotService.updateThingShadow` and `getThingShadow` keep only `state`, `version` and `timestamp`; AWS also returns `metadata`, mirroring `state.desired` and `state.reported` with `{"timestamp": <epoch seconds>}` per leaf, refreshed when that leaf is written and removed when it is set to `null`. Add it to `GetThingShadow` over HTTP and MQTT `get/accepted`, and to `update/accepted` (written leaves only), `update/documents` (`previous` and `current`) and `delta` (delta leaves only). Store metadata beside the document so restarts keep it. Capture the shapes from AWS (`iot-data update-thing-shadow`/`get-thing-shadow`) before coding; arrays are leaves. SDK test in `IotIntegrationTest`. Unblocks TEOS 27.21.
- [x] TEOS T11: `eventsvc/deployment/service-test/provision-config.local.yaml` already supplies the monitor's AWS-shaped queue URL. Its production validator remains unchanged.
TEOS T12: Task 27.14 qualifies devicesvc's `enable-fleet-indexing` path when the
indexing configuration API ships. A local guard is not fleet-search coverage.

TEOS T13: Task 27.13 nil-checks thing-type metadata, including `DeprecationDate`
for a non-deprecated type. This is needed for AWS, not only Floci's field-name fix.
- [ ] Checklist in [../README.md](../README.md) minus the CloudFormation rows; `make docs-check`.
