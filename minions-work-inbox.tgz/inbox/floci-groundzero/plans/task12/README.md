# Task 12: register device certificates issued elsewhere

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md). Broker side already in place: Task 7 PR 11 (#3180).

## Why

After #3180 the MQTT TLS listener on 8883 admits a device only when its certificate is registered in IoT
Core. That is AWS's rule ("Client certificates must be registered with AWS IoT before a client can
communicate with AWS IoT"; the handshake "validates the certificate's status and AWS account against a
registry of certificates"), and the broker was built as a membership check by fingerprint on purpose so
that certificates from any issuer work once they can be registered. Floci only has the two paths where
IoT Core issues the certificate (`CreateKeysAndCertificate`, `CreateCertificateFromCsr`). The two paths
where the caller brings a certificate are missing, so a device with a certificate from its own CA
cannot connect to Floci today. On AWS:

- `RegisterCertificateWithoutCA` registers a certificate with no CA involved. The certificate ends up in
  `SNI_ONLY` mode ("a certificate in SNI_ONLY mode is registered without an issuer CA"; devices with such
  certificates must send the SNI extension when connecting).
- `RegisterCertificate` registers a certificate signed by a CA that is itself registered with
  `RegisterCACertificate` ("The client certificate must be signed by a certificate authority (CA) that
  you have registered with AWS IoT"). The device certificate inherits the CA's mode (`DEFAULT` or
  `SNI_ONLY`) and records `caCertificateId`. So this operation needs the CA certificate API first.

Nothing in the broker changes for either: `IotService.findRegisteredCertificate` looks the presented
leaf up by the SHA-256 of its DER, which is the `certificateId` AWS assigns to registered certificates
as well, and `isConnectAllowed` only asks for `ACTIVE`, validity and an `iot:Connect` policy. Each
subtask ends by proving that with a device whose certificate Floci never issued.

Verified against the AWS API reference and developer guide on 2026-09-07 (`API_RegisterCertificate`,
`API_RegisterCertificateWithoutCA`, `API_RegisterCACertificate`, `API_CertificateDescription`,
`manual-cert-registration`, `x509-client-certs`), and the CloudFormation registry schemas
`aws-iot-certificate.json` and `aws-iot-cacertificate.json` from the `local/aws/cfn-resource-schemas`
corpus. Check the current pages again before coding; the exact error messages are not in the docs and
have to come from a call against AWS.

## AWS facts that shape the work

| Fact | Where it bites |
| --- | --- |
| `POST /certificate/register-no-ca`, body `certificatePem` (required), `status` (`ACTIVE`, `INACTIVE`, `REVOKED`, `PENDING_TRANSFER`, `REGISTER_INACTIVE`, `PENDING_ACTIVATION`); response `certificateArn`, `certificateId` | 12.1 route and shape |
| `POST /certificate/register?setAsActive=` (deprecated flag), body `certificatePem` (required), `caCertificatePem` (optional), `status`; the CA is found by the device certificate's issuer when `caCertificatePem` is omitted; several registered CAs with the same subject and key give `CertificateConflictException` 409 | 12.3 route and CA resolution |
| Registration without `status` or `setAsActive` leaves the certificate registered but not active ("registered with AWS IoT, but it is not active yet") | default status `INACTIVE`; confirm against AWS |
| Errors on both register calls: `ResourceAlreadyExistsException` 409 with `resourceArn` and `resourceId` (same fingerprint already registered in this account and region), `CertificateValidationException` 400 (bad PEM, unsupported key or signature algorithm, signature does not verify against the CA), `CertificateStateException` 406, `InvalidRequestException` 400 | error mapping; the message texts must be taken from AWS |
| `certificateId` is the SHA-256 of the DER, 64 lowercase hex, for registered certificates too | `IotService.certificateIdOf` already does this, so the broker finds them |
| Accepted keys: RSA of at least 2048 bits, EC on P-256, P-384, P-521; accepted signatures: SHA256/384/512 with RSA, RSA-PSS, ECDSA, DSA_WITH_SHA256 | `FlociCertificateAuthority.requireAcceptedKey` covers the key part today and is private; make it reusable and add the signature algorithm check |
| `RegisterCertificateWithoutCA` gives `certificateMode = SNI_ONLY`; a certificate registered through a CA takes the CA's mode; `DescribeCertificate` also reports `caCertificateId` | `IotCertificate` gains `certificateMode` and `caCertificateId`; `IotController.buildCertificateDescription` stops hard-coding `DEFAULT` |
| A device with an `SNI_ONLY` certificate must send the SNI extension when it connects | optional broker check in 12.1: the TLS listener refuses an `SNI_ONLY` certificate when no server name was sent at all; note that Paho sends the dialled host as SNI even when it is an IP, so an IP literal still counts as "sent" for this check (unlike `iot:DomainName`) |
| `POST /cacertificate?allowAutoRegistration=&setAsActive=`, body `caCertificate` (required), `verificationCertificate` (required in `DEFAULT` mode, must be empty in `SNI_ONLY`), `certificateMode`, `registrationConfig`, `tags`; `GET /registrationcode` gives the per-account code the verification certificate's CN must carry; `DELETE /registrationcode`; `GET /cacertificate/{id}`, `GET /cacertificates`, `PUT /cacertificate/{id}?newStatus=&newAutoRegistrationStatus=`, `DELETE /cacertificate/{id}`, `GET /certificates-by-ca/{id}`; up to 10 CAs with the same subject, `LimitExceededException` 410 beyond | 12.2 |
| A CA certificate must be a CA (`basicConstraints cA=true`, `keyCertSign`); a `DEFAULT`-mode registration verifies the verification certificate is signed by the CA and its CN equals the registration code | 12.2 validation |
| Deactivating or deleting a CA does not deactivate the device certificates it signed; `DeleteCACertificate` needs the CA `INACTIVE` (`CertificateStateException` 406) | 12.2 lifecycle, documented |
| `UpdateCertificate`: `REVOKED` is terminal, a revoked certificate cannot be activated again | 12.1 status transitions |
| CloudFormation `AWS::IoT::Certificate`: properties `CertificateSigningRequest`, `CertificatePem`, `CACertificatePem`, `CertificateMode`, `Status` (required); createOnly everything but `Status`; readOnly `Arn`, `Id`; a CSR means `CreateCertificateFromCsr`, `CertificatePem` with `CACertificatePem` means `RegisterCertificate`, `CertificatePem` alone means `RegisterCertificateWithoutCA`; `AWS::IoT::CACertificate`: `CACertificatePem` and `Status` required, `VerificationCertificatePem`, `CertificateMode`, `AutoRegistrationStatus`, `RemoveAutoRegistration`, `RegistrationConfig`, `Tags`; readOnly `Arn`, `Id` | 12.4, the ten-step provisioner recipe in AGENTS.md |

## Subtasks

Four separate PRs. 12.1 and 12.2 can start independently from `main`.
12.3 waits for both to merge, then starts from the updated `main`; 12.4 is optional
and waits for the registration APIs it exercises. Do not stack 12.3 on 12.2.

### 12.1 `feat(iot): register device certificates without a CA`

- [ ] `IotService.registerCertificateWithoutCa(certificatePem, status, region)`: parse the PEM (`CertificateGenerator.parseCertificate`), reject an unsupported key or signature algorithm with `CertificateValidationException` 400, `certificateId` = SHA-256 of the DER, `ResourceAlreadyExistsException` 409 with `resourceArn` and `resourceId` when the id already exists in this account and region, store `certificatePem`, `publicKey`, `notBefore`, `notAfter`, `status` (default `INACTIVE`), `certificateMode = SNI_ONLY`, no private key. Reuse `fill(...)`; move `requireAcceptedKey` out of `FlociCertificateAuthority` so both callers share it.
- [ ] `IotController`: `POST /certificate/register-no-ca`, response `certificateArn` and `certificateId` only. `DescribeCertificate` and `ListCertificates` report the stored `certificateMode` (today hard-coded `DEFAULT`) and `caCertificateId` when set; the two create paths store `DEFAULT`.
- [ ] Statuses: `validateCertificateStatus` accepts `PENDING_ACTIVATION` and `REGISTER_INACTIVE` too; `UpdateCertificate` from `REVOKED` answers `CertificateStateException` 406 as AWS does. Optional in the same file, from analysis 4.16: `DeleteCertificate` of an `ACTIVE` certificate answers `CertificateStateException` 406 and of an attached one `DeleteConflictException` 409 instead of `InvalidRequestException` 400.
- [ ] Multi-account: the same certificate registered under two accounts lives in two partitions, and `findRegisteredCertificate` keeps picking the lowest account id when both hold it; document that AWS routes by the SNI host name instead.
- [ ] Broker proof, in `IotMqttMutualTlsIntegrationTest` or a sibling: a certificate issued by a CA the test builds itself (BouncyCastle, never the Floci CA), registered with `status ACTIVE` and a connect policy, connects on 8883; the same certificate registered `INACTIVE` or `PENDING_ACTIVATION` is refused; a certificate that was only issued and never registered stays refused. This is the test that shows the fingerprint lookup works for foreign issuers.
- [ ] Optional, only if cheap: the TLS listener refuses an `SNI_ONLY` certificate when the client sent no server name at all (AWS: "must send the SNI extension"). A raw JSSE client with `SSLParameters.setServerNames(List.of())` is the test; Paho cannot be made to omit SNI.
- [ ] Tests: `IotServiceTest` or a new `IotCertificateRegistrationTest` (unit: statuses, duplicate, bad key, bad PEM, mode), `IotDeviceCertificateIntegrationTest` (REST shapes through RestAssured, and the Java SDK v2 `registerCertificateWithoutCA` call), the broker proof above.
- [ ] `docs/services/iot.md`: certificate basics paragraph, the "Device verification on 8883" section (registered by any of the four operations), `make docs-sync` for the action table, `make docs-check`.
- [ ] `compatibility-tests/sdk-test-java` `IotTest`: register a certificate without a CA, describe it, activate it, delete it.

### 12.2 `feat(iot): CA certificates`

- [ ] `IotCaCertificate` model (id, ARN `arn:aws:iot:<region>:<account>:cacert/<id>`, PEM, status `ACTIVE`/`INACTIVE`, `certificateMode`, `autoRegistrationStatus`, `registrationConfig`, dates, tags, `customerVersion`, `generationId`) in its own store `iot-ca-certificates.json`.
- [ ] `GetRegistrationCode` and `DeleteRegistrationCode`: one 64-hex code per account, stable across restarts (persist it; derive it from the account id and a stored secret, or store it in the CA store under a fixed key).
- [ ] `RegisterCACertificate`: parse the CA PEM, require `basicConstraints cA=true` and `keyCertSign`; `DEFAULT` mode requires `verificationCertificate`, verifies it against the CA's public key and that its subject CN equals the registration code (`RegistrationCodeValidationException` 400 otherwise); `SNI_ONLY` requires no verification certificate and refuses one; `certificateId` = SHA-256 of the DER; `ResourceAlreadyExistsException` 409 on the same id; `LimitExceededException` 410 past ten CAs with the same subject; `setAsActive`, `allowAutoRegistration`, `registrationConfig` and `tags` stored.
- [ ] `DescribeCACertificate`, `ListCACertificates` (paginated, `ascendingOrder`, `templateName` filter can be ignored), `UpdateCACertificate` (`newStatus`, `newAutoRegistrationStatus`, `registrationConfig`, `removeAutoRegistration`), `DeleteCACertificate` (`CertificateStateException` 406 while `ACTIVE`), `ListCertificatesByCA`, tags through the existing `tagResource` for the `cacert/` ARN.
- [ ] Not in scope, say so in the docs: just-in-time registration and provisioning (`allowAutoRegistration` is stored, not acted on: the broker still refuses an unregistered certificate), `TransferCertificate`.
- [ ] Tests: unit for the validations, `IotCaCertificateIntegrationTest` through the Java SDK v2 for the whole lifecycle in both modes, `make docs-sync`, `make docs-check`.

### 12.3 `feat(iot): register device certificates signed by a registered CA`

- [ ] `IotService.registerCertificate(certificatePem, caCertificatePem, status, setAsActive, region)`: resolve the CA (by the fingerprint of `caCertificatePem` when given, otherwise by the device certificate's issuer DN among the account's registered CAs; more than one match with the same subject and key is `CertificateConflictException` 409; none, or a signature that does not verify against the CA, is `CertificateValidationException` 400; an `INACTIVE` CA is `CertificateStateException` 406), then the same registration as 12.1 with `certificateMode` taken from the CA and `caCertificateId` set.
- [ ] `IotController`: `POST /certificate/register` with the deprecated `setAsActive` query parameter honoured next to `status`.
- [ ] Broker proof: a CA registered in `SNI_ONLY` mode (no verification certificate) and a device certificate it signed, registered through `RegisterCertificate` with a connect policy, connects on 8883; deactivating the CA afterwards does not disconnect or refuse the device (AWS behaviour); a certificate signed by an unregistered CA is refused by `RegisterCertificate` and so stays refused on 8883.
- [ ] Tests, docs, compat suite as in 12.1.

### 12.4 Optional `feat(cloudformation): provision AWS::IoT::Certificate and AWS::IoT::CACertificate`

- [ ] `IotCfnProvisioner` gains both types following the ten-step recipe in AGENTS.md: `Status` is the only updatable property, everything else replaces; delete deactivates first when the handler on AWS does (check the AWS CloudFormation handler source before deciding); `Ref` is the certificate id, `Fn::GetAtt Arn` and `Id`.
- [ ] Rows in `supported-resource-types.tsv`, `CfnProvisionerFixture` arms, `make docs-sync`, the fixture and inventory tests, and the checklist in [../README.md](../README.md).

## Order and size

12.1 is about 120 lines plus tests. 12.2 owns the CA lifecycle and can prove its
SDK lifecycle without device registration. 12.3 owns CA-backed device registration
and its broker proof after 12.1 and 12.2 merge. 12.4 follows when a stack needs it.
Nothing here is on the groundzero path: the local deploy uses `CreateKeysAndCertificate`.
