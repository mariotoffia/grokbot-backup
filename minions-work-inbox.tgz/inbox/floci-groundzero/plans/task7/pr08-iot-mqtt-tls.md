# PR 8: `feat(iot): MQTT over TLS listener` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

> **Status 2026-09-06:** implemented and opened as #3142 (branch `feat/iot-mqtt-tls` from `upstream/main` c0b5461f1, worktree `.claude/worktrees/feat-iot-mqtt-tls`, head c490ffd66 after two review commits: retired key-material generations kept 60 s (Greptile P1), joined close on the listen failure path (Copilot); Greptile 5/5, 23/23 checks green). Deviations from the text below: `ReloadingKeyManager` takes an `X509KeyManager` and exposes `keyManagerOf(Vertx, KeyCertOptions)` plus `reload(X509KeyManager)`; the broker builds the delegate from `event.tlsConfiguration().getKeyStoreOptions()`, not from the registry again. The claim that `MqttServer` has no `updateSSLOptions` is wrong (vertx-mqtt 4.5.30 has it), but it was still not used: `TCPServerBase` serves a null SSL provider to connections accepted while the new context is built, so an 8-thread reload-plus-handshake test dropped connections; the key manager never rebuilds anything. Aliases are generation-qualified and retired generations stay readable for 60 s (longer than the 10 s handshake timeout), so any number of reloads between `chooseEngineServerAlias` and `getPrivateKey` still yields a matching pair (Greptile round 1 asked for this instead of keeping one previous generation). Start is all-or-nothing (a TLS bind failure closes the plaintext listener too). Tests beyond the plan: `IotMqttBrokerServiceTest` (14, real Vert.x) with TLS 1.2 and 1.3 against AWS's default security-policy suites, and the integration test verifies the learned name through SNI plus endpoint identification, MQTT 5, client id takeover across ports, a shadow update over TLS, a broker restart and `GetConnection` on a TLS session.

**Goal:** IoT devices connect with `ssl://<host>:8883` trusting only `floci-root-ca.crt`, exactly as they do against AWS IoT's 8883, and the listener presents whatever the HTTPS server presents, including SANs learned after it started.

**Architecture:** A second `MqttServer` in `IotMqttBrokerService` with `setSsl(true)` on `floci.services.iot.mqtt.tls-port` (default 8883), sharing every handler with the plaintext one. Its key material is `KeyCertOptions.wrap(ReloadingKeyManager)`: an `X509ExtendedKeyManager` whose delegate is rebuilt from the TLS registry's default configuration (`TlsConfiguration.getKeyStoreOptions().getKeyManagerFactory(vertx)`) whenever `CertificateUpdatedEvent` fires, because `io.vertx.mqtt.MqttServer` has no `updateSSLOptions`. JSSE consults the key manager on every handshake, so a new connection sees the new leaf without a listener restart. Client certificates are requested (`ClientAuth.REQUEST`) and accepted by a trust-all client trust manager so the handshake carries them; PR 11 turns them into identity.

**Tech Stack:** vertx-mqtt 4.5.30 (`MqttServerOptions.setSsl/setKeyCertOptions/setTrustOptions/setClientAuth`), vertx-core `KeyCertOptions.wrap(X509KeyManager)`, `TrustOptions.wrap(TrustManager)`, Quarkus TLS registry, Paho mqttv3 1.2.5 over `ssl://`.

**Release coupling:** this PR opens 8883 with `ClientAuth.REQUEST` and admits every client, exactly as permissive as 1883 is today. PR 11 (`feat/iot-mtls`) is what makes 8883 verify devices. Merge both before a release is cut; a release with PR 8 alone would advertise a TLS listener that does not authenticate.

**Branch:** `feat/iot-mqtt-tls` from `upstream/main` after PRs 3 and 6 merge. Depends on PR 3 (CA, server leaf under `quarkus.tls.key-store.pem.0.*`) and PR 6 (`TlsCertificateManager.ensureHost` + `CertificateUpdatedEvent` for the reload test). Upstream's IoT rules-engine work also edits `IotMqttBrokerService`; rebase, the edits are in different methods.

Verified: `MqttServerOptions` has `setSsl`, `setKeyCertOptions`, `setTrustOptions`, `setClientAuth`, `setSni`, `setUseWebSocket`; `MqttEndpoint` has `isSsl()`, `sslSession()`; `KeyCertOptions.wrap(X509KeyManager)` and `TrustOptions.wrap(TrustManager)` exist in vertx-core 4.5.30; `TlsConfiguration` exposes `getKeyStoreOptions()` and `reload()`; `CertificateGenerator` writes `127.0.0.1` as an `iPAddress` SAN so Paho's default hostname verification passes against `ssl://127.0.0.1`.

---

## File structure

- Modify: `SRC/config/EmulatorConfig.java` (`MqttConfig.tlsPort()`)
- Modify: `src/main/resources/application.yml`, `src/test/resources/application.yml` (`tls-port`)
- Create: `SRC/services/iot/ReloadingKeyManager.java`
- Modify: `SRC/services/iot/IotMqttBrokerService.java` (ctor, `startIfEnabled`, `stop`, observer)
- Create: `TEST/services/iot/ReloadingKeyManagerTest.java`
- Create: `TEST/services/iot/IotMqttTlsIntegrationTest.java`
- Modify: `docs/services/iot.md`

---

### Task 1: Config

**Files:**
- Modify: `SRC/config/EmulatorConfig.java:752-764`
- Modify: `src/main/resources/application.yml:586-592`, `src/test/resources/application.yml:346-350`

- [x] **Step 1: Add `tlsPort`**

In `MqttConfig`, after `int port();`:

```java
        /** MQTT over TLS listener. Active only when {@code floci.tls.enabled} is true; 0 disables it. */
        @WithDefault("8883")
        int tlsPort();
```

Main yml, after `port: 1883` inside `iot.mqtt`:

```yaml
        tls-port: 8883
```

Test yml, same place:

```yaml
        tls-port: 8883
```

- [x] **Step 2: Compile**

Run: `./mvnw -q compile`
Expected: BUILD SUCCESS.

- [x] **Step 3: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/EmulatorConfig.java src/main/resources/application.yml src/test/resources/application.yml
git commit -m "feat(iot): floci.services.iot.mqtt.tls-port (default 8883)"
```

### Task 2: `ReloadingKeyManager`

**Files:**
- Create: `TEST/services/iot/ReloadingKeyManagerTest.java`
- Create: `SRC/services/iot/ReloadingKeyManager.java`

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.services.iot;

import io.quarkus.tls.TlsConfiguration;
import io.quarkus.tls.TlsConfigurationRegistry;
import io.vertx.core.Vertx;
import io.vertx.core.net.KeyCertOptions;
import org.junit.jupiter.api.Test;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.X509KeyManager;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ReloadingKeyManagerTest {

    private final Vertx vertx = mock(Vertx.class);
    private final TlsConfigurationRegistry registry = mock(TlsConfigurationRegistry.class);
    private final TlsConfiguration tls = mock(TlsConfiguration.class);

    @Test
    void delegatesToTheKeyManagerOfTheDefaultTlsConfiguration() throws Exception {
        X509KeyManager inner = mock(X509KeyManager.class);
        X509Certificate cert = mock(X509Certificate.class);
        PrivateKey key = mock(PrivateKey.class);
        when(inner.getServerAliases("RSA", null)).thenReturn(new String[] {"srv"});
        when(inner.chooseServerAlias("RSA", null, null)).thenReturn("srv");
        when(inner.getCertificateChain("srv")).thenReturn(new X509Certificate[] {cert});
        when(inner.getPrivateKey("srv")).thenReturn(key);
        stubRegistry(inner);

        ReloadingKeyManager manager = ReloadingKeyManager.fromRegistry(vertx, registry);

        assertEquals("srv", manager.chooseServerAlias("RSA", null, null));
        assertEquals("srv", manager.chooseEngineServerAlias("RSA", null, null));
        assertSame(cert, manager.getCertificateChain("srv")[0]);
        assertSame(key, manager.getPrivateKey("srv"));
    }

    @Test
    void reloadSwapsTheDelegate() throws Exception {
        X509KeyManager first = mock(X509KeyManager.class);
        X509KeyManager second = mock(X509KeyManager.class);
        when(first.chooseServerAlias("RSA", null, null)).thenReturn("first");
        when(second.chooseServerAlias("RSA", null, null)).thenReturn("second");
        stubRegistry(first);
        ReloadingKeyManager manager = ReloadingKeyManager.fromRegistry(vertx, registry);
        assertEquals("first", manager.chooseServerAlias("RSA", null, null));

        stubRegistry(second);
        manager.reload();

        assertEquals("second", manager.chooseServerAlias("RSA", null, null));
    }

    @Test
    void failedReloadKeepsTheOldDelegate() throws Exception {
        X509KeyManager first = mock(X509KeyManager.class);
        when(first.chooseServerAlias("RSA", null, null)).thenReturn("first");
        stubRegistry(first);
        ReloadingKeyManager manager = ReloadingKeyManager.fromRegistry(vertx, registry);

        when(registry.getDefault()).thenReturn(Optional.empty());
        manager.reload();

        assertEquals("first", manager.chooseServerAlias("RSA", null, null));
    }

    @Test
    void noDefaultTlsConfigurationIsAnError() {
        when(registry.getDefault()).thenReturn(Optional.empty());

        assertThrows(IllegalStateException.class, () -> ReloadingKeyManager.fromRegistry(vertx, registry));
    }

    private void stubRegistry(X509KeyManager inner) throws Exception {
        KeyManagerFactory factory = mock(KeyManagerFactory.class);
        when(factory.getKeyManagers()).thenReturn(new javax.net.ssl.KeyManager[] {inner});
        KeyCertOptions options = mock(KeyCertOptions.class);
        when(options.getKeyManagerFactory(any())).thenReturn(factory);
        when(tls.getKeyStoreOptions()).thenReturn(options);
        when(registry.getDefault()).thenReturn(Optional.of(tls));
    }
}
```

`KeyManagerFactory` is a non-final class with a protected constructor; Mockito's inline mock maker (Mockito 5, the default) mocks it. If it refuses, replace the factory mock with a real one: `KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())` initialised over a `KeyStore` holding a generated key, and stub `inner` behaviour through the real key store instead. Try the mock first; it is shorter.

- [x] **Step 2: Run and watch it fail to compile**

Run: `./mvnw test -Dtest=ReloadingKeyManagerTest`
Expected: COMPILATION ERROR, `cannot find symbol: class ReloadingKeyManager`.

- [x] **Step 3: Write the key manager**

```java
package io.github.hectorvent.floci.services.iot;

import io.quarkus.tls.TlsConfiguration;
import io.quarkus.tls.TlsConfigurationRegistry;
import io.vertx.core.Vertx;
import org.jboss.logging.Logger;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.X509ExtendedKeyManager;
import javax.net.ssl.X509KeyManager;
import java.net.Socket;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

/**
 * Key manager for the MQTT TLS listeners that always answers with the TLS registry's <em>current</em>
 * default key material.
 *
 * <p>{@code io.vertx.mqtt.MqttServer} cannot be handed new SSL options after {@code listen()}, unlike
 * the Quarkus HTTP server. JSSE, however, asks the key manager for the alias, chain and key on every
 * handshake, so swapping the delegate is enough for the next connection to see a reissued leaf
 * (a SAN learned through {@code TlsCertificateManager.ensureHost}). {@link #reload()} is called from
 * the {@code CertificateUpdatedEvent} observer in {@code IotMqttBrokerService}.
 */
final class ReloadingKeyManager extends X509ExtendedKeyManager {

    private static final Logger LOG = Logger.getLogger(ReloadingKeyManager.class);

    private final Vertx vertx;
    private final TlsConfigurationRegistry registry;
    private volatile X509KeyManager delegate;

    private ReloadingKeyManager(Vertx vertx, TlsConfigurationRegistry registry, X509KeyManager delegate) {
        this.vertx = vertx;
        this.registry = registry;
        this.delegate = delegate;
    }

    /** Fails fast when there is no default TLS configuration: the caller should not open a TLS port. */
    static ReloadingKeyManager fromRegistry(Vertx vertx, TlsConfigurationRegistry registry) throws Exception {
        return new ReloadingKeyManager(vertx, registry, load(vertx, registry));
    }

    /** Rebuilds the delegate from the registry; on failure the previous one stays in place. */
    void reload() {
        try {
            delegate = load(vertx, registry);
            LOG.debug("IoT MQTT TLS: key material reloaded");
        } catch (Exception e) {
            LOG.warnv(e, "IoT MQTT TLS: could not reload key material, keeping the previous certificate: {0}",
                    e.getMessage());
        }
    }

    private static X509KeyManager load(Vertx vertx, TlsConfigurationRegistry registry) throws Exception {
        TlsConfiguration tls = registry.getDefault()
                .orElseThrow(() -> new IllegalStateException("no default TLS configuration registered"));
        KeyManagerFactory factory = tls.getKeyStoreOptions().getKeyManagerFactory(vertx);
        for (KeyManager manager : factory.getKeyManagers()) {
            if (manager instanceof X509KeyManager x509) {
                return x509;
            }
        }
        throw new IllegalStateException("default TLS configuration has no X509KeyManager");
    }

    @Override
    public String[] getClientAliases(String keyType, Principal[] issuers) {
        return delegate.getClientAliases(keyType, issuers);
    }

    @Override
    public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket) {
        return delegate.chooseClientAlias(keyType, issuers, socket);
    }

    @Override
    public String[] getServerAliases(String keyType, Principal[] issuers) {
        return delegate.getServerAliases(keyType, issuers);
    }

    @Override
    public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
        return delegate.chooseServerAlias(keyType, issuers, socket);
    }

    @Override
    public String chooseEngineServerAlias(String keyType, Principal[] issuers, SSLEngine engine) {
        return delegate.chooseServerAlias(keyType, issuers, null);
    }

    @Override
    public String chooseEngineClientAlias(String[] keyType, Principal[] issuers, SSLEngine engine) {
        return delegate.chooseClientAlias(keyType, issuers, null);
    }

    @Override
    public X509Certificate[] getCertificateChain(String alias) {
        return delegate.getCertificateChain(alias);
    }

    @Override
    public PrivateKey getPrivateKey(String alias) {
        return delegate.getPrivateKey(alias);
    }
}
```

- [x] **Step 4: Run the tests**

Run: `./mvnw test -Dtest=ReloadingKeyManagerTest`
Expected: PASS, 4 tests.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/iot/ReloadingKeyManager.java src/test/java/io/github/hectorvent/floci/services/iot/ReloadingKeyManagerTest.java
git commit -m "feat(iot): key manager that follows the TLS registry's current default certificate"
```

### Task 3: The TLS listener

**Files:**
- Create: `TEST/services/iot/IotMqttTlsIntegrationTest.java`
- Modify: `SRC/services/iot/IotMqttBrokerService.java`

- [x] **Step 1: Write the failing integration test**

```java
package io.github.hectorvent.floci.services.iot;

import io.github.hectorvent.floci.config.CertificateMetadata;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.config.TlsCertificateManager;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import jakarta.inject.Inject;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.junit.jupiter.api.Test;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@QuarkusTest
@TestProfile(IotMqttTlsIntegrationTest.Profile.class)
class IotMqttTlsIntegrationTest {

    static final Path DATA_DIR = Path.of("/tmp/floci-iot-mqtt-tls-test");
    static final Path TLS_DIR = DATA_DIR.resolve("tls");
    static final int PLAIN_PORT = 18832;
    static final int TLS_PORT = 18883;
    static final String LEARNED_HOST = "iot.teos.localhost.floci.io";

    @Inject
    TlsCertificateManager certificateManager;

    @Test
    void connectSubscribePublishOverTlsTrustingOnlyTheFlociCa() throws Exception {
        String topic = "tls/roundtrip/" + System.nanoTime();
        byte[] payload = "hello over 8883".getBytes(StandardCharsets.UTF_8);

        try (TlsClient subscriber = TlsClient.connect("tls-sub-" + System.nanoTime())) {
            subscriber.subscribe(topic);
            try (TlsClient publisher = TlsClient.connect("tls-pub-" + System.nanoTime())) {
                publisher.publish(topic, payload);
            }
            assertArrayEquals(payload, subscriber.takePayload());
        }
    }

    @Test
    void plaintextOnTheTlsPortIsRefused() {
        MqttException refused = assertThrows(MqttException.class, () -> {
            MqttClient client = new MqttClient("tcp://127.0.0.1:" + TLS_PORT, "plain-on-tls", new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setConnectionTimeout(5);
            client.connect(options);
        });
        assertNotNull(refused);
    }

    @Test
    void plaintextListenerStillWorks() throws Exception {
        MqttClient client = new MqttClient("tcp://127.0.0.1:" + PLAIN_PORT, "plain-" + System.nanoTime(), new MemoryPersistence());
        client.connect();
        assertTrue(client.isConnected());
        client.disconnect();
    }

    @Test
    void learnedHostnameIsPresentedOnTheNextTlsHandshake() throws Exception {
        assertFalse(peerSans(LEARNED_HOST).contains(LEARNED_HOST), "precondition: not covered at boot");

        certificateManager.ensureHost(LEARNED_HOST);

        Set<String> sans = peerSans(LEARNED_HOST);
        assertTrue(sans.contains(LEARNED_HOST), sans.toString());
    }

    private static SSLContext trustOnlyFlociCa() throws Exception {
        KeyStore trust = KeyStore.getInstance(KeyStore.getDefaultType());
        trust.load(null, null);
        trust.setCertificateEntry("floci", FlociCertificateAuthority.loadOrCreate(TLS_DIR).certificate());
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trust);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, tmf.getTrustManagers(), null);
        return ctx;
    }

    private static Set<String> peerSans(String sniName) throws Exception {
        try (SSLSocket socket = (SSLSocket) trustOnlyFlociCa().getSocketFactory().createSocket("127.0.0.1", TLS_PORT)) {
            SSLParameters params = socket.getSSLParameters();
            params.setServerNames(List.of(new SNIHostName(sniName)));
            socket.setSSLParameters(params);
            socket.startHandshake();
            X509Certificate leaf = (X509Certificate) socket.getSession().getPeerCertificates()[0];
            Set<String> sans = new TreeSet<>();
            for (List<?> entry : leaf.getSubjectAlternativeNames()) {
                sans.add(String.valueOf(entry.get(1)));
            }
            return sans;
        }
    }

    private static final class TlsClient implements AutoCloseable {
        private final MqttClient client;
        private final BlockingQueue<byte[]> payloads = new LinkedBlockingQueue<>();

        private TlsClient(MqttClient client) {
            this.client = client;
        }

        static TlsClient connect(String clientId) throws Exception {
            MqttClient client = new MqttClient("ssl://127.0.0.1:" + TLS_PORT, clientId, new MemoryPersistence());
            TlsClient tlsClient = new TlsClient(client);
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) {
                    tlsClient.payloads.add(message.getPayload());
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                }
            });
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setConnectionTimeout(10);
            options.setSocketFactory(trustOnlyFlociCa().getSocketFactory());
            client.connect(options);
            return tlsClient;
        }

        void subscribe(String topic) throws MqttException {
            client.subscribe(topic, 1);
        }

        void publish(String topic, byte[] payload) throws MqttException {
            client.publish(topic, payload, 1, false);
        }

        byte[] takePayload() throws InterruptedException {
            byte[] payload = payloads.poll(10, TimeUnit.SECONDS);
            assertNotNull(payload, "no publish received over TLS within 10s");
            return payload;
        }

        @Override
        public void close() throws MqttException {
            if (client.isConnected()) {
                client.disconnect();
            }
            client.close();
        }
    }

    /**
     * TLS on with a CA-issued leaf on disk, exactly what TlsConfigSource produces in production.
     * TlsConfigSource reads system properties, not profile overrides, so the profile lays the files
     * down and points the TLS registry at them.
     */
    public static final class Profile implements QuarkusTestProfile {

        static {
            try {
                Files.createDirectories(TLS_DIR);
                for (String name : List.of("floci-server.crt", "floci-server.key", "floci-server.metadata.json")) {
                    Files.deleteIfExists(TLS_DIR.resolve(name));
                }
                FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(TLS_DIR);
                List<String> sans = List.of("localhost", "127.0.0.1", "*.localhost.floci.io");
                var leaf = ca.issueServerCertificate("localhost", sans, KeyAlgorithm.RSA_2048, null);
                Files.writeString(TLS_DIR.resolve("floci-server.crt"), leaf.certificatePem());
                Files.writeString(TLS_DIR.resolve("floci-server.key"), leaf.privateKeyPem());
                Files.writeString(TLS_DIR.resolve("floci-server.metadata.json"),
                        new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(CertificateMetadata.create(sans, "dev")));
            } catch (IOException e) {
                throw new IllegalStateException("could not prepare TLS fixtures", e);
            }
        }

        @Override
        public Map<String, String> getConfigOverrides() {
            return Map.ofEntries(
                    Map.entry("floci.tls.enabled", "true"),
                    Map.entry("floci.tls.self-signed", "true"),
                    Map.entry("floci.storage.persistent-path", DATA_DIR.toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.cert", TLS_DIR.resolve("floci-server.crt").toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.key", TLS_DIR.resolve("floci-server.key").toString()),
                    Map.entry("quarkus.http.insecure-requests", "enabled"),
                    Map.entry("floci.services.iot.mqtt.enabled", "true"),
                    Map.entry("floci.services.iot.mqtt.auto-start", "true"),
                    Map.entry("floci.services.iot.mqtt.host", "127.0.0.1"),
                    Map.entry("floci.services.iot.mqtt.port", Integer.toString(PLAIN_PORT)),
                    Map.entry("floci.services.iot.mqtt.tls-port", Integer.toString(TLS_PORT)));
        }
    }
}
```

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=IotMqttTlsIntegrationTest`
Expected: FAIL. `connectSubscribePublishOverTlsTrustingOnlyTheFlociCa`, `learnedHostnameIsPresentedOnTheNextTlsHandshake` with connection refused on 18883; `plaintextOnTheTlsPortIsRefused` passes for the wrong reason (nothing listens); `plaintextListenerStillWorks` passes.

- [x] **Step 3: Add the TLS listener**

`IotMqttBrokerService` fields and constructor:

```java
    private final TlsConfigurationRegistry tlsRegistry;
    private MqttServer server;
    private MqttServer tlsServer;
    private ReloadingKeyManager keyManager;

    @Inject
    public IotMqttBrokerService(EmulatorConfig config, Vertx vertx, Instance<IotService> iotService,
                                TlsConfigurationRegistry tlsRegistry) {
        this.config = config;
        this.vertx = vertx;
        this.iotService = iotService;
        this.tlsRegistry = tlsRegistry;
    }
```

In `startIfEnabled`, after `server = mqttServer;` and its log line, still inside the `synchronized` method (outside the plaintext try/catch):

```java
        startTlsListener();
```

New methods:

```java
    private void startTlsListener() {
        int tlsPort = config.services().iot().mqtt().tlsPort();
        if (tlsPort <= 0) {
            return;
        }
        if (!config.tls().enabled()) {
            LOG.infov("IoT MQTT TLS listener not started: floci.tls.enabled is false (port {0})", tlsPort);
            return;
        }
        ReloadingKeyManager manager;
        try {
            manager = ReloadingKeyManager.fromRegistry(vertx, tlsRegistry);
        } catch (Exception e) {
            LOG.warnv("IoT MQTT TLS listener not started on port {0}: {1}", tlsPort, e.getMessage());
            return;
        }

        // Client certificates are requested so the handshake carries them, and accepted at the TLS
        // layer no matter who signed them: AWS IoT trusts a certificate because it is registered, not
        // because of its issuer, and that lookup is the broker's job (fingerprint against the store).
        MqttServer mqttServer = MqttServer.create(vertx, new MqttServerOptions()
                .setHost(config.services().iot().mqtt().host())
                .setPort(tlsPort)
                .setSsl(true)
                .setKeyCertOptions(KeyCertOptions.wrap(manager))
                .setTrustOptions(TrustOptions.wrap(ACCEPT_ANY_CLIENT_CERTIFICATE))
                .setClientAuth(ClientAuth.REQUEST));
        mqttServer.endpointHandler(this::handleEndpoint);
        mqttServer.exceptionHandler(error -> LOG.warnv("IoT MQTT TLS broker error: {0}", error.getMessage()));

        try {
            mqttServer.listen().toCompletionStage().toCompletableFuture().join();
            tlsServer = mqttServer;
            keyManager = manager;
            LOG.infov("IoT MQTT TLS broker started on {0}:{1}", config.services().iot().mqtt().host(), tlsPort);
        } catch (Exception e) {
            mqttServer.close();
            throw new IllegalStateException("Failed to start IoT MQTT TLS broker on port " + tlsPort, e);
        }
    }

    void onCertificateUpdated(@Observes CertificateUpdatedEvent event) {
        ReloadingKeyManager manager = keyManager;
        if (manager != null && TlsConfig.DEFAULT_NAME.equalsIgnoreCase(event.name())) {
            manager.reload();
        }
    }

    private static final X509ExtendedTrustManager ACCEPT_ANY_CLIENT_CERTIFICATE = new X509ExtendedTrustManager() {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType, Socket socket) {
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine) {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            throw new CertificateException("server-side trust manager");
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType, Socket socket) throws CertificateException {
            throw new CertificateException("server-side trust manager");
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType, SSLEngine engine) throws CertificateException {
            throw new CertificateException("server-side trust manager");
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    };
```

`stop()` becomes:

```java
    synchronized void stop() {
        MqttServer mqttServer = server;
        MqttServer mqttTlsServer = tlsServer;
        if (mqttServer == null && mqttTlsServer == null) {
            return;
        }
        server = null;
        tlsServer = null;
        keyManager = null;
        sessionsByClient.values().forEach(session -> session.endpoint().close());
        sessionsByClient.clear();
        subscriptionsByClient.clear();
        if (mqttServer != null) {
            mqttServer.close().toCompletionStage().toCompletableFuture().join();
        }
        if (mqttTlsServer != null) {
            mqttTlsServer.close().toCompletionStage().toCompletableFuture().join();
        }
        LOG.info("IoT MQTT broker stopped");
    }
```

Imports to add: `io.quarkus.tls.CertificateUpdatedEvent`, `io.quarkus.tls.TlsConfigurationRegistry`, `io.quarkus.tls.runtime.config.TlsConfig`, `io.vertx.core.http.ClientAuth`, `io.vertx.core.net.KeyCertOptions`, `io.vertx.core.net.TrustOptions`, `javax.net.ssl.SSLEngine`, `javax.net.ssl.X509ExtendedTrustManager`, `java.net.Socket`, `java.security.cert.CertificateException`, `java.security.cert.X509Certificate`.

Nothing else constructs `IotMqttBrokerService` (`grep -rn "new IotMqttBrokerService(" src/test` is empty), so the constructor change ripples nowhere.

- [x] **Step 4: Run the integration tests**

Run: `./mvnw test -Dtest='IotMqttTlsIntegrationTest,IotMqttEnabledIntegrationTest,IotMqttLazyStartupIntegrationTest'`
Expected: PASS. If `learnedHostnameIsPresentedOnTheNextTlsHandshake` fails with the old SAN list, the observer did not fire: confirm PR 6's `TlsCertificateManager` fired `CertificateUpdatedEvent("<default>", ...)` in the log, and that `keyManager` is non-null (TLS listener started; look for "IoT MQTT TLS broker started").

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/iot/IotMqttBrokerService.java src/test/java/io/github/hectorvent/floci/services/iot/IotMqttTlsIntegrationTest.java
git commit -m "feat(iot): MQTT over TLS listener on 8883

Second MqttServer sharing the plaintext handlers, key material from the TLS
registry's default configuration through a reloading key manager, so a SAN
learned at runtime is presented on the next handshake. Client certificates
are requested and carried, not yet verified."
```

### Task 4: Docs and PR

- [x] **Step 1: `docs/services/iot.md`**

In the MQTT broker section (where `FLOCI_SERVICES_IOT_MQTT_PORT` / 1883 is described), add:

```markdown
### MQTT over TLS

When TLS is enabled (`FLOCI_TLS_ENABLED=true`) the broker also listens on
`FLOCI_SERVICES_IOT_MQTT_TLS_PORT` (default 8883) with the same certificate the HTTPS endpoint
uses, issued by the Floci CA. Devices connect with `ssl://localhost:8883` trusting
`GET /_floci/ca.pem`, as they would trust Amazon Root CA 1 against AWS IoT. Set the port to `0` to
disable the listener. Client certificates are requested on 8883 and carried through the handshake;
identity and policy enforcement land with mutual TLS.
```

Add `8883` to the port table if the page has one. Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/iot.md
git commit -m "docs(iot): MQTT over TLS on 8883"
```

```
The IoT MQTT broker only listened on plaintext 1883, so a device configured like production
(ssl://…:8883 with the CA bundle) could not connect.

- floci.services.iot.mqtt.tls-port (default 8883, 0 disables), active when floci.tls.enabled.
- Second MqttServer with setSsl(true), sharing every handler with 1883. Key material comes from
  the TLS registry's default configuration through ReloadingKeyManager, rebuilt on
  CertificateUpdatedEvent: vertx-mqtt has no updateSSLOptions, but JSSE asks the key manager on
  every handshake, so a hostname learned via ensureHost is served on the next connection.
- ClientAuth.REQUEST with an accept-any client trust manager: AWS IoT trusts a certificate
  because it is registered, not because of its issuer; the fingerprint lookup is the next PR.
- Plaintext 1883 unchanged.

Tests: ReloadingKeyManagerTest (delegate, reload, failed reload keeps old); IotMqttTlsIntegrationTest
(Paho ssl:// round trip trusting only the Floci CA, plaintext refused on 8883, 1883 still fine,
learned SAN visible after ensureHost without restart).
Depends on the local CA and ensure-host PRs.
```

---

## Self-review

- Spec coverage. Second `MqttServer` `setSsl(true)` on `tls-port` default 8883 (Task 3); `ClientAuth.REQUEST`, carried not verified (Task 3); 1883 unchanged (test); `KeyCertOptions.wrap(X509KeyManager)` with a delegating key manager so new handshakes see new SANs (Task 2, 3): the spec said "delegates to `TlsCertificateManager`'s current leaf"; here it delegates to the TLS registry's default key material and is refreshed by the `CertificateUpdatedEvent` PR 6 fires, which also covers the user-provided certificate mode with no extra code. Config in `EmulatorConfig`, both yml, `FLOCI_SERVICES_IOT_MQTT_TLS_PORT` (Task 1, docs Task 4). Tests as listed in the spec (Task 3).
- Placeholders: none.
- Type consistency: `ReloadingKeyManager.fromRegistry(Vertx, TlsConfigurationRegistry)` and `reload()` used in Task 3 as defined in Task 2; PR 13 reuses `ReloadingKeyManager` and `ACCEPT_ANY_CLIENT_CERTIFICATE` (make the constant package-private `static final` rather than `private` if PR 13 needs it from another class; PR 13 stays inside `IotMqttBrokerService`, so `private` is fine). PR 11 reads `endpoint.sslSession().getPeerCertificates()` on endpoints accepted by `tlsServer`.
