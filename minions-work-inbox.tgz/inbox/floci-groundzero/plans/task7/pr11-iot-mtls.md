# PR 11: `feat(iot): verify device certificates on the TLS listener` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A device connecting to the MQTT TLS listener (8883) is admitted only when it presents a certificate that is registered in IoT Core as `ACTIVE` and has an attached policy allowing `iot:Connect` for its client id; the plaintext listener (1883) stays permissive.

**Architecture:** `IotService` gains two queries: `findRegisteredCertificate(X509Certificate)` (SHA-256 of the DER is the `certificateId` PR 4 assigns; membership in the store is the check, not chain validation) and `isConnectAllowed(IotCertificate, clientId)` which feeds the attached policies' default documents to the existing `IamPolicyEvaluator` with action `iot:Connect` and resource `arn:aws:iot:<region>:<account>:client/<clientId>`, after substituting `${iot:ClientId}` and, when the client id names a thing attached to the certificate, `${iot:Connection.Thing.ThingName}`. `IotMqttBrokerService.handleEndpoint` gains a `verifyDevice` flag set only by the TLS listener; on failure it answers `CONNACK` not-authorized (code 5, or 0x87 for MQTT 5) and never registers the session. The certificate ARN becomes the session principal.

**Tech Stack:** vertx-mqtt `MqttEndpoint.sslSession()/reject(MqttConnectReturnCode)/protocolVersion()`, `IamPolicyEvaluator.evaluate(List<String>, String, String)`, Paho over `ssl://` with a client `KeyManager`.

**Branch:** `feat/iot-mtls` from `upstream/main`. Depends on PR 4 (real device certificates, `certificateId = sha256(DER)`) and PR 8 (TLS listener requesting client certificates). Rebase onto both.


> **Status 2026-09-07:** opened as #3180 `feat(iot): verify device certificates on the MQTT TLS listener` from branch `feat/iot-mtls` from `upstream/main` 7a5ae965e, worktree
> `/Users/mariotoffia/progs/github/floci/.claude/worktrees/feat-iot-mtls`. Deviations from this plan, each from the
> code or the AWS developer guide: (1) `findRegisteredCertificate` returns `RegisteredDevice(accountId, region,
> certificate)` and scans every account partition (`AccountAwareStorageBackend.scanAllAccountEntries`): the broker
> has no request context, so the plan's `certificateStore.scan` would only see the default account; policies and
> things are read with `getForAccount`/`keysForAccount` from the certificate's own partition. (2)
> `isConnectAllowed(device, clientId, sourceIp, domainName)` evaluates with a condition context (basic policy
> variables `iot:ClientId`, `aws:SourceIp`, `iot:DomainName` from SNI, and the thing variables `IsAttached`,
> `ThingName`, `ThingTypeName`, `Attributes[name]`), so `Condition` blocks such as the AWS `IsAttached` example work.
> (3) Variables are substituted on the parsed JSON tree, and a statement that still carries an unresolved `${...}`
> is dropped: text replacement lets a client id with a quote rewrite a Deny, and literal comparison lets the client
> id `${iot:Connection.Thing.ThingName}` match an unattached policy. (4) Validity is checked from the registered
> record's dates (AWS: "not yet reached the certificate expiration date"), in the service, not the broker. (5) No
> `ClientSession.principal` yet: nothing reads it in this PR; PR 11b adds it with its first reader. (6) Paho 1.2.5
> sends the dialled host as SNI even when it is an IP, so IPv4 literals are ignored for `iot:DomainName`, and the
> tests pin MQTT 3.1.1 because Paho retries a refused connect as MQTT 3.1. Fixture dir `target/floci-iot-mqtt-mtls-test`,
> ports 18838/18839 (PR 8 has 18834/18835, PR 13 18836/18837). AWS closes an MQTT 3.1.1 connection it does not
> authorize without a CONNACK and refuses bad certificates in the handshake; Floci answers CONNACK 5 / 0x87 after a
> completed handshake, documented as intentional.

**Release coupling:** PR 8 opens 8883 with `ClientAuth.REQUEST` and admits everyone; this PR is what makes 8883 mean something. Ship both in the same release. Between the two merges 8883 is exactly as permissive as 1883 is today, no worse, but a release cut in the gap would advertise a TLS listener that does not check devices.

**Scope:** `iot:Connect` only, as the spec says (SPEC.md §11). Publish, subscribe and receive stay unauthorised for a connected device. The natural follow-up PR (call it 11b, about 50 lines) reuses `isConnectAllowed`'s evaluator wiring with actions `iot:Publish` / `iot:Subscribe` / `iot:Receive` and resources `arn:aws:iot:<region>:<account>:topic/<topic>` / `topicfilter/<filter>`, gated in the broker's `publishHandler` and `subscribeHandler` on `session.principal() != null`. Not here: keep this PR reviewable.

**Slack first.** `docs/services/iot.md` lines 23, 63 and 89 promise a permissive broker. This PR changes that for 8883 only; say so in the PR body and keep 1883 exactly as it is.

---

## File structure

- Modify: `SRC/services/iot/IotService.java` (inject `IamPolicyEvaluator`; add `findRegisteredCertificate`, `isConnectAllowed`)
- Modify: `SRC/services/iot/IotMqttBrokerService.java` (`handleEndpoint(MqttEndpoint, boolean)`, `ClientSession.principal`)
- Create: `TEST/services/iot/IotServiceDeviceAuthTest.java` (unit, no Quarkus)
- Create: `TEST/services/iot/IotMqttMutualTlsIntegrationTest.java`
- Create: `TEST/services/iot/IotDeviceIdentity.java` (test helper: provision a device over REST, build its `SSLContext`)
- Modify: `TEST/services/iot/IotMqttTlsIntegrationTest.java` (PR 8's round trip now presents a device certificate)
- Modify: `docs/services/iot.md`

---

### Task 1: `IotService` answers "is this device allowed to connect?"

**Files:**
- Modify: `SRC/services/iot/IotService.java`
- Create: `TEST/services/iot/IotServiceDeviceAuthTest.java`

- [x] **Step 1: Write the failing unit test**

`IotService` has a package-private constructor taking every store plus the collaborators; no test uses it today, so this test builds the service with in-memory stores and mocks for the collaborators it does not exercise. Read the package-private constructor on your rebased branch (`grep -n "    IotService(" -A25 src/main/java/io/github/hectorvent/floci/services/iot/IotService.java`) and pass `new InMemoryStorage<>()` for each `StorageBackend`, `mock(...)` for each service, `new ObjectMapper()`, `new RegionResolver("us-east-1", "000000000000")`, an `EmulatorConfig` mock with `RETURNS_DEEP_STUBS`, a real `FlociCertificateAuthority.loadOrCreate(tempDir)` (PR 4 added it), and `new IamPolicyEvaluator(new ObjectMapper())`.

```java
package io.github.hectorvent.floci.services.iot;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.hectorvent.floci.config.EmulatorConfig;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.core.common.RegionResolver;
import io.github.hectorvent.floci.core.storage.InMemoryStorage;
import io.github.hectorvent.floci.services.acm.CertificateGenerator;
import io.github.hectorvent.floci.services.iam.IamPolicyEvaluator;
import io.github.hectorvent.floci.services.iot.model.IotCertificate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.security.cert.X509Certificate;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class IotServiceDeviceAuthTest {

    private static final String REGION = "us-east-1";
    private static final String CONNECT_ANY_CLIENT = """
            {"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"iot:Connect","Resource":"arn:aws:iot:*:*:client/*"}]}
            """;
    private static final String CONNECT_AS_THING = """
            {"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"iot:Connect","Resource":"arn:aws:iot:*:*:client/${iot:Connection.Thing.ThingName}"}]}
            """;

    @TempDir
    Path tempDir;

    private IotService service;
    private FlociCertificateAuthority ca;
    private final CertificateGenerator generator = new CertificateGenerator();

    @BeforeEach
    void setUp() {
        ca = FlociCertificateAuthority.loadOrCreate(tempDir);
        EmulatorConfig config = mock(EmulatorConfig.class, RETURNS_DEEP_STUBS);
        when(config.services().iot().mqtt().enabled()).thenReturn(false);
        service = IotServiceTestSupport.inMemory(config, new RegionResolver(REGION, "000000000000"), ca,
                new IamPolicyEvaluator(new ObjectMapper()));
    }

    @Test
    void registeredActiveCertificateIsFoundByItsDer() {
        IotCertificate created = service.createKeysAndCertificate(true, REGION);
        X509Certificate presented = generator.parseCertificate(created.getCertificatePem());

        assertEquals(created.getCertificateArn(),
                service.findRegisteredCertificate(presented).orElseThrow().getCertificateArn());
    }

    @Test
    void unknownCertificateIsNotFoundEvenWhenTheFlociCaSignedIt() {
        X509Certificate stranger = generator.parseCertificate(ca.issueClientCertificate("stranger").certificatePem());

        assertTrue(service.findRegisteredCertificate(stranger).isEmpty());
    }

    @Test
    void inactiveCertificateIsNotAllowedToConnect() {
        IotCertificate created = service.createKeysAndCertificate(false, REGION);
        service.createPolicy("p", CONNECT_ANY_CLIENT, REGION);
        service.attachPolicy("p", created.getCertificateArn(), REGION);

        assertFalse(service.isConnectAllowed(created, "any"));
    }

    @Test
    void activeCertificateWithoutPolicyIsDenied() {
        IotCertificate created = service.createKeysAndCertificate(true, REGION);

        assertFalse(service.isConnectAllowed(created, "any"));
    }

    @Test
    void activeCertificateWithConnectPolicyIsAllowed() {
        IotCertificate created = service.createKeysAndCertificate(true, REGION);
        service.createPolicy("p", CONNECT_ANY_CLIENT, REGION);
        service.attachPolicy("p", created.getCertificateArn(), REGION);

        assertTrue(service.isConnectAllowed(created, "sensor-1"));
    }

    @Test
    void detachedPolicyNoLongerAllows() {
        IotCertificate created = service.createKeysAndCertificate(true, REGION);
        service.createPolicy("p", CONNECT_ANY_CLIENT, REGION);
        service.attachPolicy("p", created.getCertificateArn(), REGION);
        service.detachPolicy("p", created.getCertificateArn(), REGION);

        assertFalse(service.isConnectAllowed(created, "sensor-1"));
    }

    @Test
    void thingNameVariableResolvesOnlyForAThingAttachedToTheCertificate() {
        IotCertificate created = service.createKeysAndCertificate(true, REGION);
        service.createThing("sensor-1", Map.of(), REGION);
        service.attachThingPrincipal("sensor-1", created.getCertificateArn(), REGION);
        service.createPolicy("p", CONNECT_AS_THING, REGION);
        service.attachPolicy("p", created.getCertificateArn(), REGION);

        assertTrue(service.isConnectAllowed(created, "sensor-1"));
        assertFalse(service.isConnectAllowed(created, "sensor-2"));
    }

    @Test
    void explicitDenyWins() {
        IotCertificate created = service.createKeysAndCertificate(true, REGION);
        service.createPolicy("allow", CONNECT_ANY_CLIENT, REGION);
        service.createPolicy("deny", """
                {"Version":"2012-10-17","Statement":[{"Effect":"Deny","Action":"iot:Connect","Resource":"arn:aws:iot:*:*:client/blocked"}]}
                """, REGION);
        service.attachPolicy("allow", created.getCertificateArn(), REGION);
        service.attachPolicy("deny", created.getCertificateArn(), REGION);

        assertTrue(service.isConnectAllowed(created, "sensor-1"));
        assertFalse(service.isConnectAllowed(created, "blocked"));
    }
}
```

`IotServiceTestSupport.inMemory(...)` is a tiny package-private factory you write in the same test package so the twenty-argument constructor is spelled out once:

```java
package io.github.hectorvent.floci.services.iot;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.hectorvent.floci.config.EmulatorConfig;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.core.common.RegionResolver;
import io.github.hectorvent.floci.core.storage.InMemoryStorage;
import io.github.hectorvent.floci.services.iam.IamPolicyEvaluator;

import static org.mockito.Mockito.mock;

final class IotServiceTestSupport {

    private IotServiceTestSupport() {
    }

    static IotService inMemory(EmulatorConfig config, RegionResolver regionResolver,
                               FlociCertificateAuthority ca, IamPolicyEvaluator policyEvaluator) {
        return new IotService(
                new InMemoryStorage<>(),   // things
                new InMemoryStorage<>(),   // certificates
                new InMemoryStorage<>(),   // policies
                new InMemoryStorage<>(),   // policy attachments
                new InMemoryStorage<>(),   // thing principals
                new InMemoryStorage<>(),   // shadows
                new InMemoryStorage<>(),   // topic rules
                new InMemoryStorage<>(),   // retained messages
                new InMemoryStorage<>(),   // jobs
                new InMemoryStorage<>(),   // job executions
                new InMemoryStorage<>(),   // thing types
                new InMemoryStorage<>(),   // thing groups
                new InMemoryStorage<>(),   // thing group memberships
                config,
                regionResolver,
                new ObjectMapper(),
                mock(IotPublishEventRecorder.class),
                mock(IotMqttBrokerService.class),
                mock(io.github.hectorvent.floci.services.sqs.SqsService.class),
                mock(io.github.hectorvent.floci.services.sns.SnsService.class),
                mock(io.github.hectorvent.floci.services.s3.S3Service.class),
                mock(io.github.hectorvent.floci.services.kinesis.KinesisService.class),
                mock(io.github.hectorvent.floci.services.dynamodb.DynamoDbService.class),
                mock(io.github.hectorvent.floci.services.lambda.LambdaService.class),
                ca,
                policyEvaluator);
    }
}
```

Match the argument order to the package-private constructor on your branch exactly; the comment per store is there so a mismatch is visible. If a collaborator is `final` and Mockito refuses, the inline mock maker (`quarkus-junit-mockito` brings `mockito-inline` semantics on Mockito 5) handles it.

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=IotServiceDeviceAuthTest`
Expected: compile error, no constructor takes `IamPolicyEvaluator`, no `findRegisteredCertificate`/`isConnectAllowed`.

- [x] **Step 3: Implement**

In `IotService`: add `IamPolicyEvaluator policyEvaluator` as the last parameter of both constructors (the `@Inject` one forwards it, the package-private one stores it in `private final IamPolicyEvaluator policyEvaluator;`). `IamPolicyEvaluator` is `@ApplicationScoped` in `services/iam`, so CDI provides it. Then add, next to `describeCertificate`:

```java
    /**
     * AWS IoT trusts a device certificate because it is registered, not because of who signed it.
     * The lookup key is the certificateId, which is the lowercase hex SHA-256 of the DER encoding.
     */
    public Optional<IotCertificate> findRegisteredCertificate(X509Certificate presented) {
        String id;
        try {
            id = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(presented.getEncoded()));
        } catch (Exception e) {
            LOG.debugv("Could not fingerprint presented certificate: {0}", e.getMessage());
            return Optional.empty();
        }
        String suffix = ":" + id;
        return certificateStore.scan(key -> key.startsWith("cert:") && key.endsWith(suffix)).stream().findFirst();
    }

    /**
     * Evaluates iot:Connect for {@code clientId} against the policies attached to the certificate.
     * Only ACTIVE certificates can connect. Policy variables: {@code ${iot:ClientId}} always;
     * {@code ${iot:Connection.Thing.ThingName}} only when the client id names a thing attached to
     * this certificate, as on AWS.
     */
    public boolean isConnectAllowed(IotCertificate certificate, String clientId) {
        if (!"ACTIVE".equals(certificate.getStatus()) || clientId == null) {
            return false;
        }
        String[] arn = certificate.getCertificateArn().split(":");
        String region = arn[3];
        String account = arn[4];
        String clientArn = "arn:aws:iot:" + region + ":" + account + ":client/" + clientId;
        boolean clientIsAttachedThing = listPrincipalThings(certificate.getCertificateArn(), region).contains(clientId);

        List<String> documents = listAttachedPolicies(certificate.getCertificateArn(), region).stream()
                .map(IotPolicy::getPolicyDocument)
                .filter(Objects::nonNull)
                .map(document -> document.replace("${iot:ClientId}", clientId))
                .map(document -> clientIsAttachedThing
                        ? document.replace("${iot:Connection.Thing.ThingName}", clientId)
                        : document)
                .toList();
        if (documents.isEmpty()) {
            return false;
        }
        return policyEvaluator.evaluate(documents, "iot:Connect", clientArn) == IamPolicyEvaluator.Decision.ALLOW;
    }
```

Imports: `io.github.hectorvent.floci.services.iam.IamPolicyEvaluator`, `java.security.MessageDigest`, `java.security.cert.X509Certificate`, `java.util.HexFormat`, `java.util.Objects`, `java.util.Optional` (some already present from PR 4). `IamPolicyEvaluator.evaluate(List<String>, String, String)` is default-deny: no matching `Allow` yields `DENY`, any matching `Deny` wins, and an unparseable document denies.

- [x] **Step 4: Run**

Run: `./mvnw test -Dtest='IotServiceDeviceAuthTest,IotIntegrationTest'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/iot/IotService.java src/test/java/io/github/hectorvent/floci/services/iot/IotServiceDeviceAuthTest.java src/test/java/io/github/hectorvent/floci/services/iot/IotServiceTestSupport.java
git commit -m "feat(iot): registered-certificate lookup and iot:Connect evaluation"
```

### Task 2: The TLS listener enforces it

**Files:**
- Create: `TEST/services/iot/IotDeviceIdentity.java`
- Create: `TEST/services/iot/IotMqttMutualTlsIntegrationTest.java`
- Modify: `SRC/services/iot/IotMqttBrokerService.java`

- [x] **Step 1: The device-identity test helper**

Provisioning over REST is what a real device onboarding does; the helper turns the response into an `SSLContext` that presents the device certificate and trusts only the Floci CA.

```java
package io.github.hectorvent.floci.services.iot;

import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.services.acm.CertificateGenerator;
import io.restassured.path.json.JsonPath;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

import static io.restassured.RestAssured.given;

/** A device provisioned through CreateKeysAndCertificate, ready to present itself on 8883. */
final class IotDeviceIdentity {

    private static final char[] PASSWORD = "device".toCharArray();

    final String certificateId;
    final String certificateArn;
    final X509Certificate certificate;
    final PrivateKey privateKey;

    private IotDeviceIdentity(String certificateId, String certificateArn, X509Certificate certificate, PrivateKey privateKey) {
        this.certificateId = certificateId;
        this.certificateArn = certificateArn;
        this.certificate = certificate;
        this.privateKey = privateKey;
    }

    static IotDeviceIdentity provision(boolean active) {
        JsonPath created = given()
                .queryParam("setAsActive", active)
                .when().post("/keys-and-certificate")
                .then().statusCode(200)
                .extract().jsonPath();
        CertificateGenerator generator = new CertificateGenerator();
        return new IotDeviceIdentity(
                created.getString("certificateId"),
                created.getString("certificateArn"),
                generator.parseCertificate(created.getString("certificatePem")),
                generator.parsePrivateKey(created.getString("keyPair.PrivateKey")));
    }

    /** A certificate the Floci CA signed but IoT Core never registered. */
    static IotDeviceIdentity stranger(Path tlsDir) {
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tlsDir);
        CertificateGenerator generator = new CertificateGenerator();
        var issued = ca.issueClientCertificate("stranger");
        return new IotDeviceIdentity("unregistered", "arn:none",
                generator.parseCertificate(issued.certificatePem()), generator.parsePrivateKey(issued.privateKeyPem()));
    }

    /** Presents the device certificate and trusts only the Floci CA. */
    SSLContext sslContext(Path tlsDir) throws Exception {
        KeyStore identity = KeyStore.getInstance("PKCS12");
        identity.load(null, null);
        identity.setKeyEntry("device", privateKey, PASSWORD, new java.security.cert.Certificate[]{certificate});
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(identity, PASSWORD);

        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(kmf.getKeyManagers(), trustManagers(tlsDir), null);
        return ctx;
    }

    /** Trusts only the Floci CA and presents nothing: an anonymous client. */
    static SSLContext trustOnlySslContext(Path tlsDir) throws Exception {
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, trustManagers(tlsDir), null);
        return ctx;
    }

    private static TrustManager[] trustManagers(Path tlsDir) throws Exception {
        KeyStore trust = KeyStore.getInstance(KeyStore.getDefaultType());
        trust.load(null, null);
        trust.setCertificateEntry("floci", FlociCertificateAuthority.loadOrCreate(tlsDir).certificate());
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trust);
        return tmf.getTrustManagers();
    }
}
```

Add `import javax.net.ssl.TrustManager;` to the imports above. Policies are attached from the test with plain RestAssured so the request shape stays visible there. `keyPair.PrivateKey` is the JSON path in the `CreateKeysAndCertificate` response (`IotController:142-170` builds `keyPair` with `PublicKey`/`PrivateKey`); confirm with `grep -n '"PrivateKey"' src/main/java/io/github/hectorvent/floci/services/iot/IotController.java`.

- [x] **Step 2: Write the failing integration test**

The profile is PR 8's, on different ports and data dir so both classes can run in one JVM without fighting over `/tmp`.

```java
package io.github.hectorvent.floci.services.iot;

import io.github.hectorvent.floci.config.CertificateMetadata;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.services.acm.KeyAlgorithm;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttSecurityException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.*;

/**
 * 8883 admits a device only when its certificate is registered, ACTIVE, and an attached policy
 * allows iot:Connect for the client id. 1883 stays permissive.
 */
@QuarkusTest
@TestProfile(IotMqttMutualTlsIntegrationTest.Profile.class)
class IotMqttMutualTlsIntegrationTest {

    static final Path DATA_DIR = Path.of("/tmp/floci-iot-mqtt-mtls-test");
    static final Path TLS_DIR = DATA_DIR.resolve("tls");
    static final int PLAIN_PORT = 18834;
    static final int TLS_PORT = 18885;

    private static final String CONNECT_ANY_CLIENT =
            "{\\\"Version\\\":\\\"2012-10-17\\\",\\\"Statement\\\":[{\\\"Effect\\\":\\\"Allow\\\",\\\"Action\\\":\\\"iot:Connect\\\",\\\"Resource\\\":\\\"arn:aws:iot:*:*:client/*\\\"}]}";

    @Test
    void activeCertificateWithConnectPolicyIsAdmitted() throws Exception {
        IotDeviceIdentity device = IotDeviceIdentity.provision(true);
        String policy = "connect-" + System.nanoTime();
        createPolicy(policy, CONNECT_ANY_CLIENT);
        attachPolicy(policy, device.certificateArn);

        MqttClient client = connectTls(device, "sensor-" + System.nanoTime());
        assertTrue(client.isConnected());
        client.disconnect();
        client.close();
    }

    @Test
    void activeCertificateWithoutPolicyIsRefused() throws Exception {
        IotDeviceIdentity device = IotDeviceIdentity.provision(true);

        assertNotAuthorized(() -> connectTls(device, "no-policy-" + System.nanoTime()));
    }

    @Test
    void inactiveCertificateIsRefused() throws Exception {
        IotDeviceIdentity device = IotDeviceIdentity.provision(false);
        String policy = "inactive-" + System.nanoTime();
        createPolicy(policy, CONNECT_ANY_CLIENT);
        attachPolicy(policy, device.certificateArn);

        assertNotAuthorized(() -> connectTls(device, "inactive-" + System.nanoTime()));
    }

    @Test
    void deactivatedCertificateIsRefusedOnTheNextConnect() throws Exception {
        IotDeviceIdentity device = IotDeviceIdentity.provision(true);
        String policy = "deactivate-" + System.nanoTime();
        createPolicy(policy, CONNECT_ANY_CLIENT);
        attachPolicy(policy, device.certificateArn);
        MqttClient first = connectTls(device, "deact-1-" + System.nanoTime());
        first.disconnect();
        first.close();

        given().queryParam("newStatus", "INACTIVE").when().put("/certificates/" + device.certificateId).then().statusCode(200);

        assertNotAuthorized(() -> connectTls(device, "deact-2-" + System.nanoTime()));
    }

    @Test
    void detachedPolicyIsRefusedOnTheNextConnect() throws Exception {
        IotDeviceIdentity device = IotDeviceIdentity.provision(true);
        String policy = "detach-" + System.nanoTime();
        createPolicy(policy, CONNECT_ANY_CLIENT);
        attachPolicy(policy, device.certificateArn);
        MqttClient first = connectTls(device, "detach-1-" + System.nanoTime());
        first.disconnect();
        first.close();

        given().queryParam("target", device.certificateArn).when().post("/target-policies/" + policy).then().statusCode(200);

        assertNotAuthorized(() -> connectTls(device, "detach-2-" + System.nanoTime()));
    }

    @Test
    void unregisteredCertificateIsRefusedEvenThoughTheFlociCaSignedIt() {
        IotDeviceIdentity stranger = IotDeviceIdentity.stranger(TLS_DIR);

        assertNotAuthorized(() -> connectTls(stranger, "stranger-" + System.nanoTime()));
    }

    @Test
    void noClientCertificateIsRefused() {
        assertNotAuthorized(() -> {
            MqttClient client = new MqttClient("ssl://127.0.0.1:" + TLS_PORT, "anon-" + System.nanoTime(), new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setConnectionTimeout(10);
            options.setSocketFactory(IotDeviceIdentity.trustOnlySslContext(TLS_DIR).getSocketFactory());
            client.connect(options);
            return client;
        });
    }

    @Test
    void plaintextListenerStaysPermissive() throws Exception {
        MqttClient client = new MqttClient("tcp://127.0.0.1:" + PLAIN_PORT, "plain-" + System.nanoTime(), new MemoryPersistence());
        client.connect();
        assertTrue(client.isConnected());
        client.disconnect();
        client.close();
    }

    private static MqttClient connectTls(IotDeviceIdentity device, String clientId) throws Exception {
        MqttClient client = new MqttClient("ssl://127.0.0.1:" + TLS_PORT, clientId, new MemoryPersistence());
        MqttConnectOptions options = new MqttConnectOptions();
        options.setCleanSession(true);
        options.setConnectionTimeout(10);
        options.setSocketFactory(device.sslContext(TLS_DIR).getSocketFactory());
        client.connect(options);
        return client;
    }

    private interface Connect {
        MqttClient run() throws Exception;
    }

    private static void assertNotAuthorized(Connect connect) {
        MqttException e = assertThrows(MqttException.class, () -> {
            MqttClient client = connect.run();
            client.disconnect();
            client.close();
        });
        assertInstanceOf(MqttSecurityException.class, e, "expected CONNACK not-authorized, got: " + e);
        assertEquals(MqttException.REASON_CODE_NOT_AUTHORIZED, e.getReasonCode());
    }

    private static void createPolicy(String name, String escapedDocument) {
        given()
                .contentType("application/json")
                .body("{\"policyDocument\":\"" + escapedDocument + "\"}")
                .when().post("/policies/" + name)
                .then().statusCode(200);
    }

    private static void attachPolicy(String name, String certificateArn) {
        given().queryParam("target", certificateArn).when().put("/target-policies/" + name).then().statusCode(200);
    }

    public static final class Profile implements QuarkusTestProfile {

        static {
            try {
                Files.createDirectories(TLS_DIR);
                for (String name : List.of("floci-server.crt", "floci-server.key", "floci-server.metadata.json")) {
                    Files.deleteIfExists(TLS_DIR.resolve(name));
                }
                FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(TLS_DIR);
                List<String> sans = List.of("localhost", "127.0.0.1", "*.localhost.floci.io");
                var leaf = ca.issueServerCertificate("localhost", sans, KeyAlgorithm.RSA_2048, null);
                Files.writeString(TLS_DIR.resolve("floci-server.crt"), leaf.certificatePem());
                Files.writeString(TLS_DIR.resolve("floci-server.key"), leaf.privateKeyPem());
                Files.writeString(TLS_DIR.resolve("floci-server.metadata.json"),
                        new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(CertificateMetadata.create(sans, "dev")));
            } catch (IOException e) {
                throw new IllegalStateException("could not prepare TLS fixtures", e);
            }
        }

        @Override
        public Map<String, String> getConfigOverrides() {
            return Map.ofEntries(
                    Map.entry("floci.tls.enabled", "true"),
                    Map.entry("floci.tls.self-signed", "true"),
                    Map.entry("floci.storage.persistent-path", DATA_DIR.toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.cert", TLS_DIR.resolve("floci-server.crt").toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.key", TLS_DIR.resolve("floci-server.key").toString()),
                    Map.entry("quarkus.http.insecure-requests", "enabled"),
                    Map.entry("floci.services.iot.mqtt.enabled", "true"),
                    Map.entry("floci.services.iot.mqtt.auto-start", "true"),
                    Map.entry("floci.services.iot.mqtt.host", "127.0.0.1"),
                    Map.entry("floci.services.iot.mqtt.port", Integer.toString(PLAIN_PORT)),
                    Map.entry("floci.services.iot.mqtt.tls-port", Integer.toString(TLS_PORT)));
        }
    }
}
```

- [x] **Step 3: Run and watch it fail**

Run: `./mvnw test -Dtest=IotMqttMutualTlsIntegrationTest`
Expected: every `assertNotAuthorized` test FAILS because the broker still `accept()`s everyone; `activeCertificateWithConnectPolicyIsAdmitted` and `plaintextListenerStaysPermissive` pass.

- [x] **Step 4: Enforce in the broker**

In `IotMqttBrokerService`:

`ClientSession` gains a principal (the certificate ARN, or `null` on the permissive listener):

```java
    private record ClientSession(
            String clientId,
            MqttEndpoint endpoint,
            String sourceIp,
            int sourcePort,
            boolean cleanSession,
            String principal) {
    }
```

The plaintext listener (PR 8 left it at `mqttServer.endpointHandler(this::handleEndpoint);`) becomes:

```java
        mqttServer.endpointHandler(endpoint -> handleEndpoint(endpoint, false));
```

and the TLS listener in `startTlsListener()`:

```java
        mqttServer.endpointHandler(endpoint -> handleEndpoint(endpoint, true));
```

The WebSocket path (PR 13) does not go through this listener at all: it bridges `/mqtt` on the HTTP(S) port onto the plaintext 1883 listener, so it lands in the `handleEndpoint(endpoint, false)` branch by construction. AWS authenticates that path by SigV4 or custom authorizer, never by client certificate, so this is the right branch for it.

`handleEndpoint` becomes:

```java
    private void handleEndpoint(MqttEndpoint endpoint, boolean verifyDevice) {
        String clientId = endpoint.clientIdentifier();
        String principal = null;
        if (verifyDevice) {
            Optional<IotCertificate> device = authenticateDevice(endpoint);
            if (device.isEmpty() || !iotService.get().isConnectAllowed(device.get(), clientId)) {
                LOG.infov("IoT MQTT TLS client {0} refused: {1}", clientId,
                        device.isEmpty() ? "no registered certificate presented" : "iot:Connect not allowed for " + device.get().getCertificateArn());
                endpoint.reject(endpoint.protocolVersion() == 5
                        ? MqttConnectReturnCode.CONNECTION_REFUSED_NOT_AUTHORIZED_5
                        : MqttConnectReturnCode.CONNECTION_REFUSED_NOT_AUTHORIZED);
                return;
            }
            principal = device.get().getCertificateArn();
        }
        SocketAddress remoteAddress = endpoint.remoteAddress();
        ClientSession session = new ClientSession(
                clientId,
                endpoint,
                remoteAddress == null ? null : remoteAddress.host(),
                remoteAddress == null ? -1 : remoteAddress.port(),
                endpoint.isCleanSession(),
                principal);

        ... the existing handler wiring, sessionsByClient.put(...) and endpoint.accept() unchanged ...
    }

    /** The peer certificate, if one was presented and IoT Core has it registered. */
    private Optional<IotCertificate> authenticateDevice(MqttEndpoint endpoint) {
        if (!endpoint.isSsl() || endpoint.sslSession() == null) {
            return Optional.empty();
        }
        try {
            Certificate[] chain = endpoint.sslSession().getPeerCertificates();
            if (chain.length == 0 || !(chain[0] instanceof X509Certificate presented)) {
                return Optional.empty();
            }
            presented.checkValidity();
            return iotService.get().findRegisteredCertificate(presented);
        } catch (SSLPeerUnverifiedException e) {
            LOG.debugv("IoT MQTT TLS client {0} presented no certificate", endpoint.clientIdentifier());
            return Optional.empty();
        } catch (CertificateExpiredException | CertificateNotYetValidException e) {
            LOG.infov("IoT MQTT TLS client {0} presented a certificate outside its validity: {1}",
                    endpoint.clientIdentifier(), e.getMessage());
            return Optional.empty();
        }
    }
```

`checkValidity()` matters because PR 8's trust manager only verifies the chain, and a device certificate
registered a year ago is still in the store after it expires; AWS refuses it, so does this.

Imports: `io.netty.handler.codec.mqtt.MqttConnectReturnCode`, `io.github.hectorvent.floci.services.iot.model.IotCertificate`, `javax.net.ssl.SSLPeerUnverifiedException`, `java.security.cert.Certificate`, `java.security.cert.CertificateExpiredException`, `java.security.cert.CertificateNotYetValidException`, `java.security.cert.X509Certificate`, `java.util.Optional`. `iotService` is already the `Instance<IotService>` field the broker uses for publishes, so no constructor change. `ClientAuth.REQUEST` (PR 8) means a client that sends no certificate still completes the handshake, which is why `getPeerCertificates()` throwing `SSLPeerUnverifiedException` is the "no certificate" path here, not a connection error.

- [x] **Step 5: Run**

Run: `./mvnw test -Dtest='IotMqttMutualTlsIntegrationTest,IotMqttEnabledIntegrationTest,IotMqttLazyStartupIntegrationTest'`
Expected: PASS. `IotMqttTlsIntegrationTest` from PR 8 now fails (its round trip connects to 8883 without a device certificate): fixed in the next task.

- [x] **Step 6: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/iot/IotMqttBrokerService.java src/test/java/io/github/hectorvent/floci/services/iot/IotDeviceIdentity.java src/test/java/io/github/hectorvent/floci/services/iot/IotMqttMutualTlsIntegrationTest.java
git commit -m "feat(iot): verify device certificates and iot:Connect on the MQTT TLS listener"
```

### Task 3: PR 8's round trip presents a device

**Files:**
- Modify: `TEST/services/iot/IotMqttTlsIntegrationTest.java`

- [x] **Step 1: Give the round-trip client an identity**

In `IotMqttTlsIntegrationTest.TlsClient.connect(String clientId)` replace

```java
            options.setSocketFactory(trustOnlyFlociCa().getSocketFactory());
```

with

```java
            options.setSocketFactory(DEVICE.sslContext(TLS_DIR).getSocketFactory());
```

and add to the test class:

```java
    private static IotDeviceIdentity DEVICE;

    @BeforeAll
    static void provisionDevice() {
        DEVICE = IotDeviceIdentity.provision(true);
        String policy = "tls-roundtrip-" + System.nanoTime();
        given()
                .contentType("application/json")
                .body("{\"policyDocument\":\"{\\\"Version\\\":\\\"2012-10-17\\\",\\\"Statement\\\":[{\\\"Effect\\\":\\\"Allow\\\",\\\"Action\\\":\\\"iot:Connect\\\",\\\"Resource\\\":\\\"arn:aws:iot:*:*:client/*\\\"}]}\"}")
                .when().post("/policies/" + policy)
                .then().statusCode(200);
        given().queryParam("target", DEVICE.certificateArn).when().put("/target-policies/" + policy).then().statusCode(200);
    }
```

Imports: `org.junit.jupiter.api.BeforeAll`, `static io.restassured.RestAssured.given`. `@BeforeAll` runs inside the Quarkus test lifecycle, so RestAssured already points at the test HTTP port. `plaintextOnTheTlsPortIsRefused`, `plaintextListenerStillWorks` and `learnedHostnameIsPresentedOnTheNextTlsHandshake` are unchanged: the last one handshakes without sending MQTT CONNECT, so device verification never runs.

- [x] **Step 2: Run everything MQTT**

Run: `./mvnw test -Dtest='IotMqtt*IntegrationTest,IotIntegrationTest,IotServiceDeviceAuthTest'`
Expected: PASS.

- [x] **Step 3: Commit**

```bash
git add src/test/java/io/github/hectorvent/floci/services/iot/IotMqttTlsIntegrationTest.java
git commit -m "test(iot): TLS round trip presents a registered device certificate"
```

### Task 4: Docs and PR

- [x] **Step 1: Docs**

`docs/services/iot.md`: line 23 becomes

```markdown
- MQTT on 1883 remains permissive; the TLS listener on 8883 admits a device only when its certificate is registered and `ACTIVE` and an attached policy allows `iot:Connect` for the client id.
```

line 63 becomes

```markdown
- Keep the plaintext listener permissive; 8883 verifies devices (see MQTT over TLS below). `Publish`, `Subscribe` and `Receive` are not evaluated yet.
```

line 89 becomes

```markdown
- Certificate and `iot:Connect` policy checks are enforced on 8883 only; topic-level authorization is not enforced yet.
```

and in the "MQTT over TLS" section PR 8 added, append:

```markdown
#### Device verification on 8883

The listener requests a client certificate. The connection is admitted when all of these hold,
otherwise the broker answers `CONNACK` not-authorized (code 5, `0x87` on MQTT 5):

1. A certificate was presented and its SHA-256 fingerprint is a registered `certificateId`
   (`CreateKeysAndCertificate`). Who signed it does not matter; membership does, as on AWS.
2. The certificate is `ACTIVE`.
3. The policies attached to it (`AttachPolicy` with the certificate ARN as target) allow
   `iot:Connect` on `arn:aws:iot:<region>:<account>:client/<clientId>`. `${iot:ClientId}` is
   substituted; `${iot:Connection.Thing.ThingName}` only when the client id is a thing attached to
   the certificate (`AttachThingPrincipal`). Explicit `Deny` wins, no policy means deny.

Deactivating the certificate or detaching the policy takes effect on the next connect; existing
sessions are not dropped. Policies attached to thing groups are not consulted yet.
```

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/iot.md
git commit -m "docs(iot): device verification on the MQTT TLS listener"
```

```
The MQTT TLS listener requested client certificates but accepted everyone. This makes 8883 behave
like AWS IoT Core's mutual-TLS endpoint; 1883 is unchanged and stays permissive.

- IotService.findRegisteredCertificate(X509Certificate): SHA-256 of the DER is the certificateId,
  looked up in the certificate store. Registration is the trust decision, not the issuer.
- IotService.isConnectAllowed(cert, clientId): ACTIVE only; attached policies' default documents
  evaluated by IamPolicyEvaluator for iot:Connect on arn:aws:iot:<region>:<account>:client/<id>,
  with ${iot:ClientId} and (when the client id is an attached thing) ${iot:Connection.Thing.ThingName}
  substituted. Default deny, explicit deny wins.
- IotMqttBrokerService rejects with CONNACK not-authorized (5, or 0x87 for MQTT 5) when either check
  fails and records the certificate ARN as the session principal for later Publish/Subscribe
  evaluation.
- Tests: unit (8 cases incl. policy variables and explicit deny), integration over Paho with a
  client KeyManager: admitted, no policy, INACTIVE, deactivated after connect, detached after
  connect, Floci-CA-signed but unregistered, no certificate at all, 1883 still permissive.

Not in this PR: Publish/Subscribe/Receive evaluation, thing-group policies, dropping live sessions
on deactivation. The WebSocket listener (separate PR) authenticates by custom authorizer on AWS,
not by client certificate, and is not covered by this check.
```

---

## Self-review

- Spec coverage. Fingerprint lookup, ACTIVE only, unknown/INACTIVE refused, principal bound to the session (Task 2); `iot:Connect` evaluation (Task 1); 8883 only via the `verifyDevice` flag, WebSocket excluded (Task 2, PR body); tests for unknown, ACTIVE accepted, INACTIVE, detached (Task 2); docs sentence change (Task 4).
- Placeholders: the `handleEndpoint` snippet elides the unchanged handler wiring (`subscriptionAutoAck` through `endpoint.accept()`), which is lines 155-169 of the upstream file.
- Type consistency: `findRegisteredCertificate(X509Certificate): Optional<IotCertificate>` and `isConnectAllowed(IotCertificate, String): boolean` used identically in Tasks 1 and 2; `IamPolicyEvaluator.Decision.ALLOW` matches the enum in `services/iam`; `MqttConnectReturnCode.CONNECTION_REFUSED_NOT_AUTHORIZED` and `_5` exist in netty-codec-mqtt (verified via javap); `MqttEndpoint.protocolVersion()` returns `int` (verified); Paho maps CONNACK 5 to `MqttSecurityException` with `REASON_CODE_NOT_AUTHORIZED`.
- Ports: PR 8 uses 18832/18883, this PR 18834/18885, PR 13 uses 18836/18887; data dirs differ so profiles never share a CA.
- Known pre-existing quirk, not fixed here: `IamPolicyEvaluator.globMatches` (lines 439-443) lower-cases both sides, so an `iot:Connect` policy on `client/Sensor-1` also admits `sensor-1`. AWS is case-sensitive. That is an IAM-evaluator bug shared by every service using it and belongs in its own fix.
- Expired or not-yet-valid peer certificates are refused in `authenticateDevice` (`checkValidity()`), independent of the chain check.
