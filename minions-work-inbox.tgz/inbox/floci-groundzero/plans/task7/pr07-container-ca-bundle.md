# PR 7: `feat(docker): every container Floci launches trusts the Floci CA` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** When TLS is on, any container Floci launches (Lambda, ECS, MWAA, Flink, RDS, ElastiCache, RabbitMQ, Kubernetes Lambda pods) can call `https://<anything Floci serves>` including custom domains, from any runtime (Node, Python, Go, curl, AWS SDK/CLI), without disabling verification and without losing access to public HTTPS.

**Architecture:** `TlsConfigSource` writes one file at boot, `{persistent-path}/tls/floci-ca-bundle.pem` = the JVM's default trust anchors (about 150 public roots) + the Floci CA (or the user-provided certificate). Because the bundle contains the public roots, the "replacing" variables (`SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`, `CURL_CA_BUNDLE`) are now safe to set alongside the "appending" ones (`NODE_EXTRA_CA_CERTS`) and the SDK-scoped `AWS_CA_BUNDLE`. `ContainerLifecycleManager.create` is the single choke point every Docker container passes through: it copies the bundle to `/etc/floci-ca-bundle.pem` and appends the five variables (spec-provided values win). Lambda's bespoke CA copy and its append-only env policy are deleted; Kubernetes pods keep their ConfigMap mount, now holding the bundle.

**Tech Stack:** `javax.net.ssl.TrustManagerFactory` (JVM roots), docker-java `copyArchiveToContainerCmd`, commons-compress tar, Mockito.

**Branch:** `feat/container-ca-bundle` from `upstream/main` after PR 3 merges. Depends on PR 3. If PR 5 merged first, rebase and take the deletion of `ContainerLauncherCaTrustTest` (PR 5 edits a line in it).

**Status (2026-09-05):** opened as #3091, stacked on #3078's head f02148abd (a sibling of #3079, #3080 and #3084), worktree `.claude/worktrees/feat-container-ca-bundle`, five commits. Deviations from this plan, all deliberate: `ContainerCaBundle` lives in `config` (the shared-types table in README.md), not `core/common/docker`, so the dependency stays docker to config; the anchor file is parsed and re-serialised (a combined cert-and-key file never leaks a key); the boot-write tests are a new `TlsConfigSourceContainerCaBundleTest` (`TlsCertificateHostnameTest` was already 520 lines); the Docker-gated test lays down CA, leaf and bundle itself because a `QuarkusTestProfile` override is not a system property and `TlsConfigSource` never sees it; the bootstrap now sets `resolvedTlsDir` in user-certificate mode too (review finding), so `hostPath` and the CA producer read where the boot wrote. Review round 1 (Greptile 2/5, Copilot one pass) found two real things, both fixed as extra commits: `ca.pem` served a user certificate file verbatim (key leak with a combined file; now certificate blocks only, #3078's code fixed here) and a failed bundle copy left `SSL_CERT_FILE` naming a missing file (now the container is recreated without the variables). Re-stack after #3078 merges: `git rebase --onto upstream/main f02148abd feat/container-ca-bundle`.

---

## Reconciliation with the spec (read first)

The spec listed the env variables and a Java `ca.p12` + `JAVA_TOOL_OPTIONS`, and an https `ContainerReachableEndpoint.baseUrl()`. Three adjustments, each deliberate:

1. **Combined bundle instead of Floci CA alone.** The current `ContainerLauncher.flociCaEnv` sets only `NODE_EXTRA_CA_CERTS` + `AWS_CA_BUNDLE` because `SSL_CERT_FILE` and `REQUESTS_CA_BUNDLE` replace the trust store and would break a Lambda's public HTTPS calls (`ContainerLauncherCaTrustTest.caEnv_onlySetsAppendingAndAwsScopedVars` enforces this). A bundle that already contains the public roots removes that constraint; the test is deleted with the policy it guarded. Go's `net/http` (which TEOS uses) only honours `SSL_CERT_FILE`, so this is the difference between working and not working for a Go Lambda calling a custom domain.
2. **No Java truststore.** `javax.net.ssl.trustStore` replaces the JRE's `cacerts` too, so it would need the same combined set in PKCS12, and `JAVA_TOOL_OPTIONS` is noisy and collides with user values. Nothing in TEOS is a Java workload. Left for a follow-up, stated in the PR body.
3. **`ContainerReachableEndpoint.baseUrl()` stays http.** Container to Floci over plain HTTP already works (`insecure-requests=enabled`); HTTPS only matters for custom domains, which resolve through the embedded DNS to Floci's AWS HTTPS port, not through `baseUrl()`. YAGNI.

## File structure

- Create: `SRC/core/common/docker/ContainerCaBundle.java` (static: write, locate, env)
- Modify: `SRC/config/TlsConfigSource.java` (write the bundle at boot)
- Modify: `SRC/core/common/docker/ContainerLifecycleManager.java` (`create`: env + copy)
- Modify: `SRC/services/lambda/launcher/ContainerLauncher.java` (delete CA code)
- Modify: `SRC/services/lambda/launcher/kubernetes/KubernetesPodLauncher.java`, `LambdaPodSpecFactory.java`
- Delete: `TEST/services/lambda/launcher/ContainerLauncherCaTrustTest.java`
- Create: `TEST/core/common/docker/ContainerCaBundleTest.java`, `ContainerLifecycleManagerCaBundleTest.java`
- Modify: `TEST/config/TlsCertificateHostnameTest.java`, `TEST/services/lambda/launcher/kubernetes/LambdaPodSpecFactoryTest.java:248`
- Modify: `docs/configuration/tls.md`

---

### Task 1: `ContainerCaBundle`

**Files:**
- Create: `TEST/core/common/docker/ContainerCaBundleTest.java`
- Create: `SRC/core/common/docker/ContainerCaBundle.java`

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.core.common.docker;

import io.github.hectorvent.floci.config.EmulatorConfig;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ContainerCaBundleTest {

    @TempDir
    Path tempDir;

    @BeforeAll
    static void bouncyCastle() {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    @Test
    void bundleHoldsTheSystemRootsAndTheAnchorLast() throws Exception {
        Path tlsDir = Files.createDirectories(tempDir.resolve("tls"));
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tlsDir);

        Path bundle = ContainerCaBundle.write(tlsDir, ca.certificatePath());

        assertEquals(tlsDir.resolve("floci-ca-bundle.pem"), bundle);
        Collection<? extends java.security.cert.Certificate> certs = CertificateFactory.getInstance("X.509")
                .generateCertificates(new ByteArrayInputStream(Files.readAllBytes(bundle)));
        assertTrue(certs.size() > 50, "expected the JVM's public roots, got " + certs.size());
        X509Certificate last = (X509Certificate) certs.stream().reduce((a, b) -> b).orElseThrow();
        assertEquals(ca.certificate(), last, "the Floci CA closes the bundle");
    }

    @Test
    void writeIsIdempotent() throws Exception {
        Path tlsDir = Files.createDirectories(tempDir.resolve("tls"));
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tlsDir);

        byte[] first = Files.readAllBytes(ContainerCaBundle.write(tlsDir, ca.certificatePath()));
        byte[] second = Files.readAllBytes(ContainerCaBundle.write(tlsDir, ca.certificatePath()));

        assertTrue(java.util.Arrays.equals(first, second));
    }

    @Test
    void hostPathIsEmptyWhenTlsIsOffOrTheBundleIsMissing() {
        EmulatorConfig config = mock(EmulatorConfig.class, RETURNS_DEEP_STUBS);
        when(config.storage().persistentPath()).thenReturn(tempDir.toString());

        when(config.tls().enabled()).thenReturn(false);
        assertEquals(Optional.empty(), ContainerCaBundle.hostPath(config));

        when(config.tls().enabled()).thenReturn(true);
        assertEquals(Optional.empty(), ContainerCaBundle.hostPath(config), "no file yet");
    }

    @Test
    void hostPathFindsTheWrittenBundle() throws Exception {
        Path tlsDir = Files.createDirectories(tempDir.resolve("tls"));
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tlsDir);
        Path bundle = ContainerCaBundle.write(tlsDir, ca.certificatePath());
        EmulatorConfig config = mock(EmulatorConfig.class, RETURNS_DEEP_STUBS);
        when(config.tls().enabled()).thenReturn(true);
        when(config.storage().persistentPath()).thenReturn(tempDir.toString());

        assertEquals(Optional.of(bundle), ContainerCaBundle.hostPath(config));
    }

    @Test
    void envPointsEveryRuntimeAtTheContainerPath() {
        assertEquals(List.of(
                "SSL_CERT_FILE=/etc/floci-ca-bundle.pem",
                "CURL_CA_BUNDLE=/etc/floci-ca-bundle.pem",
                "REQUESTS_CA_BUNDLE=/etc/floci-ca-bundle.pem",
                "NODE_EXTRA_CA_CERTS=/etc/floci-ca-bundle.pem",
                "AWS_CA_BUNDLE=/etc/floci-ca-bundle.pem"), ContainerCaBundle.env());
    }

    @Test
    void envDoesNotOverrideAVariableTheSpecAlreadySets() {
        List<String> merged = ContainerCaBundle.appendEnv(List.of("FOO=bar", "SSL_CERT_FILE=/my/own.pem"));

        assertEquals("FOO=bar", merged.get(0));
        assertEquals("SSL_CERT_FILE=/my/own.pem", merged.get(1));
        assertEquals(1, merged.stream().filter(e -> e.startsWith("SSL_CERT_FILE=")).count());
        assertTrue(merged.contains("AWS_CA_BUNDLE=/etc/floci-ca-bundle.pem"));
        assertEquals(6, merged.size());
    }
}
```

- [x] **Step 2: Run and watch it fail to compile**

Run: `./mvnw test -Dtest=ContainerCaBundleTest`
Expected: COMPILATION ERROR, `cannot find symbol: class ContainerCaBundle`.

- [x] **Step 3: Write the class**

```java
package io.github.hectorvent.floci.core.common.docker;

import io.github.hectorvent.floci.config.EmulatorConfig;
import org.jboss.logging.Logger;

import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * The CA bundle Floci hands to every container it launches so the workload can call Floci over
 * HTTPS (including custom domains) from any runtime.
 *
 * <p>The bundle is the JVM's default trust anchors followed by Floci's trust anchor. Carrying the
 * public roots is what makes it safe to point the <em>replacing</em> variables
 * ({@code SSL_CERT_FILE}, {@code CURL_CA_BUNDLE}, {@code REQUESTS_CA_BUNDLE}) at it: a workload
 * still reaches public HTTPS endpoints. {@code NODE_EXTRA_CA_CERTS} appends, and
 * {@code AWS_CA_BUNDLE} is scoped to SDK/CLI traffic, so both are harmless with the same file.
 *
 * <p>Written by {@code TlsConfigSource} at boot; copied into containers by
 * {@link ContainerLifecycleManager#create}; mounted from a ConfigMap by the Kubernetes launcher.
 */
public final class ContainerCaBundle {

    private static final Logger LOG = Logger.getLogger(ContainerCaBundle.class);

    public static final String HOST_FILE_NAME = "floci-ca-bundle.pem";
    public static final String CONTAINER_DIR = "/etc";
    public static final String CONTAINER_FILE_NAME = HOST_FILE_NAME;
    public static final String CONTAINER_PATH = CONTAINER_DIR + "/" + CONTAINER_FILE_NAME;

    private static final List<String> ENV_KEYS = List.of(
            "SSL_CERT_FILE", "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "NODE_EXTRA_CA_CERTS", "AWS_CA_BUNDLE");

    private ContainerCaBundle() {
    }

    /** Writes {@code tlsDir/floci-ca-bundle.pem} = JVM roots + the PEM at {@code anchorPath}. */
    public static Path write(Path tlsDir, Path anchorPath) throws IOException, GeneralSecurityException {
        Files.createDirectories(tlsDir);
        StringBuilder pem = new StringBuilder(systemRootsPem());
        String anchor = Files.readString(anchorPath).strip();
        pem.append(anchor).append('\n');
        Path target = tlsDir.resolve(HOST_FILE_NAME);
        Path tmp = tlsDir.resolve(HOST_FILE_NAME + ".tmp");
        Files.writeString(tmp, pem.toString());
        Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        return target;
    }

    /** The bundle on the Floci host, or empty when TLS is off or the boot write did not happen. */
    public static Optional<Path> hostPath(EmulatorConfig config) {
        if (!config.tls().enabled()) {
            return Optional.empty();
        }
        Path bundle = Path.of(config.storage().persistentPath(), "tls", HOST_FILE_NAME);
        if (!Files.isReadable(bundle)) {
            LOG.warnv("TLS enabled but {0} is missing; launched containers will not trust Floci HTTPS", bundle);
            return Optional.empty();
        }
        return Optional.of(bundle);
    }

    /** The {@code KEY=value} entries that make each runtime read {@link #CONTAINER_PATH}. */
    public static List<String> env() {
        List<String> env = new ArrayList<>(ENV_KEYS.size());
        for (String key : ENV_KEYS) {
            env.add(key + "=" + CONTAINER_PATH);
        }
        return env;
    }

    /** {@link #env()} appended to {@code env}, skipping any key the caller already set. */
    public static List<String> appendEnv(List<String> env) {
        List<String> merged = new ArrayList<>(env == null ? List.of() : env);
        for (String key : ENV_KEYS) {
            boolean present = merged.stream().anyMatch(e -> e.startsWith(key + "="));
            if (!present) {
                merged.add(key + "=" + CONTAINER_PATH);
            }
        }
        return merged;
    }

    /** Every trust anchor the running JVM accepts by default, as concatenated PEM. */
    static String systemRootsPem() throws GeneralSecurityException {
        TrustManagerFactory factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        factory.init((KeyStore) null);
        StringBuilder pem = new StringBuilder();
        for (var manager : factory.getTrustManagers()) {
            if (manager instanceof X509TrustManager x509) {
                for (X509Certificate root : x509.getAcceptedIssuers()) {
                    pem.append(toPem(root));
                }
            }
        }
        return pem.toString();
    }

    private static String toPem(X509Certificate cert) throws CertificateEncodingException {
        return "-----BEGIN CERTIFICATE-----\n"
                + Base64.getMimeEncoder(64, new byte[] {'\n'}).encodeToString(cert.getEncoded())
                + "\n-----END CERTIFICATE-----\n";
    }
}
```

Add `import java.util.Optional;`.

- [x] **Step 4: Run the tests**

Run: `./mvnw test -Dtest=ContainerCaBundleTest`
Expected: PASS, 6 tests.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/core/common/docker/ContainerCaBundle.java src/test/java/io/github/hectorvent/floci/core/common/docker/ContainerCaBundleTest.java
git commit -m "feat(docker): CA bundle for launched containers, JVM roots plus the Floci anchor"
```

### Task 2: `TlsConfigSource` writes the bundle at boot

**Files:**
- Modify: `TEST/config/TlsCertificateHostnameTest.java`
- Modify: `SRC/config/TlsConfigSource.java` (ctor, both branches)

- [x] **Step 1: Write the failing tests**

Append to `TlsCertificateHostnameTest`:

```java
    @Test
    void bootWritesTheContainerCaBundleEndingWithTheLocalCa() throws Exception {
        System.setProperty("floci.tls.enabled", "true");
        System.setProperty("floci.tls.self-signed", "true");
        System.setProperty("floci.storage.persistent-path", tempDir.toString());

        new TlsConfigSource();

        Path bundle = tempDir.resolve("tls/floci-ca-bundle.pem");
        assertTrue(Files.exists(bundle), "bundle written at boot");
        String pem = Files.readString(bundle);
        String caPem = Files.readString(tempDir.resolve("tls/floci-root-ca.crt")).strip();
        assertTrue(pem.strip().endsWith(caPem), "the Floci CA is the last entry");
        assertTrue(pem.indexOf("-----BEGIN CERTIFICATE-----") < pem.lastIndexOf("-----BEGIN CERTIFICATE-----"),
                "public roots precede the CA");
    }

    @Test
    void bootWritesTheContainerCaBundleEndingWithTheUserCertificate() throws Exception {
        Path userDir = Files.createDirectories(tempDir.resolve("user"));
        var generated = new io.github.hectorvent.floci.services.acm.CertificateGenerator()
                .generateSelfSignedCertificate("localhost", List.of("localhost"),
                        io.github.hectorvent.floci.services.acm.model.KeyAlgorithm.RSA_2048);
        Path userCert = userDir.resolve("user.crt");
        Path userKey = userDir.resolve("user.key");
        Files.writeString(userCert, generated.certificatePem());
        Files.writeString(userKey, generated.privateKeyPem());
        System.setProperty("floci.tls.enabled", "true");
        System.setProperty("floci.tls.cert-path", userCert.toString());
        System.setProperty("floci.tls.key-path", userKey.toString());
        System.setProperty("floci.storage.persistent-path", tempDir.toString());

        new TlsConfigSource();

        String pem = Files.readString(tempDir.resolve("tls/floci-ca-bundle.pem"));
        assertTrue(pem.strip().endsWith(generated.certificatePem().strip()));
    }
```

- [x] **Step 2: Run and watch them fail**

Run: `./mvnw test -Dtest='TlsCertificateHostnameTest#bootWrites*'`
Expected: FAIL, "bundle written at boot".

- [x] **Step 3: Write the bundle from the constructor**

In `TlsConfigSource()` declare `Path trustAnchor;` before the `if (!certPath.isBlank() && !keyPath.isBlank())` branch. In the user branch, after the `LOG.infov("TLS: using user-provided certificate ...")` line add `trustAnchor = Path.of(certPath);`. In the self-signed branch (PR 3's version, where `FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tlsDir);` runs) add `trustAnchor = ca.certificatePath();` right after the CA is loaded. Then, immediately before `properties.put("quarkus.tls.key-store.pem.0.cert", certPath);`:

```java
        writeContainerCaBundle(Path.of(persistentPath, TLS_DIR), trustAnchor);
```

And the method:

```java
    /**
     * Containers Floci launches get this bundle copied in (ContainerLifecycleManager) or mounted
     * (Kubernetes). A failure here must not stop Floci: log it, containers just will not trust
     * Floci HTTPS until the next boot.
     */
    private static void writeContainerCaBundle(Path tlsDir, Path trustAnchor) {
        try {
            Path bundle = ContainerCaBundle.write(tlsDir, trustAnchor);
            LOG.debugv("TLS: container CA bundle written to {0}", bundle);
        } catch (Exception e) {
            LOG.warnv(e, "TLS: could not write the container CA bundle under {0}: {1}", tlsDir, e.getMessage());
        }
    }
```

Add `import io.github.hectorvent.floci.core.common.docker.ContainerCaBundle;`.

- [x] **Step 4: Run the config TLS tests**

Run: `./mvnw test -Dtest='TlsConfigSource*Test,TlsCertificateHostnameTest'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/TlsConfigSource.java src/test/java/io/github/hectorvent/floci/config/TlsCertificateHostnameTest.java
git commit -m "feat(tls): write the container CA bundle at boot"
```

### Task 3: `ContainerLifecycleManager.create` copies the bundle and sets the env

**Files:**
- Create: `TEST/core/common/docker/ContainerLifecycleManagerCaBundleTest.java`
- Modify: `SRC/core/common/docker/ContainerLifecycleManager.java` (`create`, lines 104-149)

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.core.common.docker;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.command.CopyArchiveToContainerCmd;
import com.github.dockerjava.api.command.CreateContainerCmd;
import com.github.dockerjava.api.command.CreateContainerResponse;
import io.github.hectorvent.floci.config.EmulatorConfig;
import io.github.hectorvent.floci.services.lambda.launcher.ImageCacheService;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.RETURNS_SELF;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Every emulator-created container passes through {@link ContainerLifecycleManager#create}, so
 * asserting CA trust here covers Lambda, ECS, MWAA, Flink, RDS and the rest by construction.
 */
@ExtendWith(MockitoExtension.class)
class ContainerLifecycleManagerCaBundleTest {

    @Mock DockerClient dockerClient;
    @Mock ImageCacheService imageCacheService;
    @Mock ContainerDetector containerDetector;
    @Mock PortAllocator portAllocator;
    @Mock EmulatorConfig config;
    @Mock EmulatorConfig.DockerConfig dockerConfig;
    @Mock EmulatorConfig.TlsConfig tlsConfig;
    @Mock EmulatorConfig.StorageConfig storageConfig;

    @TempDir Path tempDir;

    @BeforeEach
    void setUp() {
        lenient().when(config.docker()).thenReturn(dockerConfig);
        lenient().when(dockerConfig.resourceNamespace()).thenReturn(Optional.empty());
        lenient().when(config.tls()).thenReturn(tlsConfig);
        lenient().when(config.storage()).thenReturn(storageConfig);
        lenient().when(storageConfig.persistentPath()).thenReturn(tempDir.toString());
    }

    @Test
    void tlsOnCopiesTheBundleAndSetsTheTrustEnv() throws Exception {
        when(tlsConfig.enabled()).thenReturn(true);
        Path bundle = Files.createDirectories(tempDir.resolve("tls")).resolve("floci-ca-bundle.pem");
        Files.writeString(bundle, "-----BEGIN CERTIFICATE-----\nAAAA\n-----END CERTIFICATE-----\n");
        CreateContainerCmd createCmd = stubCreateContainer();
        CopyArchiveToContainerCmd copyCmd = mock(CopyArchiveToContainerCmd.class, RETURNS_SELF);
        when(dockerClient.copyArchiveToContainerCmd("container-id")).thenReturn(copyCmd);

        manager().create(specWithEnv(List.of("FOO=bar")));

        List<String> env = capturedEnv(createCmd);
        assertEquals("FOO=bar", env.get(0));
        assertTrue(env.contains("SSL_CERT_FILE=/etc/floci-ca-bundle.pem"), env.toString());
        assertTrue(env.contains("AWS_CA_BUNDLE=/etc/floci-ca-bundle.pem"));

        verify(copyCmd).withRemotePath("/etc");
        ArgumentCaptor<InputStream> tar = ArgumentCaptor.forClass(InputStream.class);
        verify(copyCmd).withTarInputStream(tar.capture());
        verify(copyCmd).exec();
        try (TarArchiveInputStream in = new TarArchiveInputStream(tar.getValue())) {
            TarArchiveEntry entry = in.getNextEntry();
            assertEquals("floci-ca-bundle.pem", entry.getName());
            assertEquals(Files.readString(bundle), new String(in.readAllBytes(), StandardCharsets.UTF_8));
        }
    }

    @Test
    void specValuesWinOverTheInjectedEnv() throws Exception {
        when(tlsConfig.enabled()).thenReturn(true);
        Files.writeString(Files.createDirectories(tempDir.resolve("tls")).resolve("floci-ca-bundle.pem"), "x");
        CreateContainerCmd createCmd = stubCreateContainer();
        when(dockerClient.copyArchiveToContainerCmd("container-id"))
                .thenReturn(mock(CopyArchiveToContainerCmd.class, RETURNS_SELF));

        manager().create(specWithEnv(List.of("SSL_CERT_FILE=/my/own.pem")));

        List<String> env = capturedEnv(createCmd);
        assertEquals(1, env.stream().filter(e -> e.startsWith("SSL_CERT_FILE=")).count());
        assertTrue(env.contains("SSL_CERT_FILE=/my/own.pem"));
    }

    @Test
    void tlsOffLeavesTheContainerAlone() {
        when(tlsConfig.enabled()).thenReturn(false);
        CreateContainerCmd createCmd = stubCreateContainer();

        manager().create(specWithEnv(List.of("FOO=bar")));

        assertEquals(List.of("FOO=bar"), capturedEnv(createCmd));
        verify(dockerClient, never()).copyArchiveToContainerCmd(org.mockito.ArgumentMatchers.anyString());
    }

    @Test
    void missingBundleMeansNoEnvAndNoCopy() {
        when(tlsConfig.enabled()).thenReturn(true);
        CreateContainerCmd createCmd = stubCreateContainer();

        manager().create(specWithEnv(List.of("FOO=bar")));

        assertFalse(capturedEnv(createCmd).contains("SSL_CERT_FILE=/etc/floci-ca-bundle.pem"));
        verify(dockerClient, never()).copyArchiveToContainerCmd(org.mockito.ArgumentMatchers.anyString());
    }

    private ContainerLifecycleManager manager() {
        return new ContainerLifecycleManager(dockerClient, imageCacheService, containerDetector, portAllocator, config);
    }

    private static ContainerSpec specWithEnv(List<String> env) {
        return new ContainerSpec("busybox:stable", null, env, null, null, null, Map.of(), List.of(), null,
                List.of(), List.of(), List.of(), Map.of(), null, false, null, List.of(), null, null, List.of());
    }

    private CreateContainerCmd stubCreateContainer() {
        CreateContainerCmd createCmd = mock(CreateContainerCmd.class, RETURNS_SELF);
        when(dockerClient.createContainerCmd("busybox:stable")).thenReturn(createCmd);
        CreateContainerResponse response = mock(CreateContainerResponse.class);
        when(response.getId()).thenReturn("container-id");
        when(createCmd.exec()).thenReturn(response);
        return createCmd;
    }

    @SuppressWarnings("unchecked")
    private static List<String> capturedEnv(CreateContainerCmd createCmd) {
        ArgumentCaptor<List<String>> env = ArgumentCaptor.forClass((Class<List<String>>) (Class<?>) List.class);
        verify(createCmd).withEnv(env.capture());
        return env.getValue();
    }
}
```

If `EmulatorConfig.TlsConfig` or `StorageConfig` are not visible from this package, they are `interface`s nested in a `public interface`, so they are implicitly public; if the compiler disagrees, use `mock(EmulatorConfig.class, RETURNS_DEEP_STUBS)` as in `ContainerCaBundleTest`.

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=ContainerLifecycleManagerCaBundleTest`
Expected: FAIL, `tlsOnCopiesTheBundleAndSetsTheTrustEnv` (env lacks `SSL_CERT_FILE`, `copyArchiveToContainerCmd` never called). `tlsOffLeavesTheContainerAlone` may already pass.

- [x] **Step 3: Implement in `create`**

Replace

```java
        if (spec.env() != null && !spec.env().isEmpty()) {
            createCmd.withEnv(spec.env());
        }
```

with

```java
        Optional<Path> caBundle = ContainerCaBundle.hostPath(config);
        List<String> env = caBundle.isPresent() ? ContainerCaBundle.appendEnv(spec.env()) : spec.env();
        if (env != null && !env.isEmpty()) {
            createCmd.withEnv(env);
        }
```

and after `String containerId = response.getId();` add:

```java
        caBundle.ifPresent(bundle -> copyCaBundle(containerId, bundle));
```

Add the method:

```java
    /**
     * Copies the CA bundle into the created (not yet started) container, so runtimes that read
     * SSL_CERT_FILE and friends at init find it. A copy rather than a bind mount because when Floci
     * itself runs in Docker its persistent path is not a host path the daemon can mount.
     */
    private void copyCaBundle(String containerId, Path bundle) {
        try {
            byte[] content = Files.readAllBytes(bundle);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(content.length + 1024);
            try (TarArchiveOutputStream tar = new TarArchiveOutputStream(buffer)) {
                TarArchiveEntry entry = new TarArchiveEntry(ContainerCaBundle.CONTAINER_FILE_NAME);
                entry.setSize(content.length);
                entry.setMode(0644);
                tar.putArchiveEntry(entry);
                tar.write(content);
                tar.closeArchiveEntry();
            }
            dockerClient.copyArchiveToContainerCmd(containerId)
                    .withRemotePath(ContainerCaBundle.CONTAINER_DIR)
                    .withTarInputStream(new ByteArrayInputStream(buffer.toByteArray()))
                    .exec();
            LOG.debugv("Copied CA bundle into container {0} at {1}", containerId, ContainerCaBundle.CONTAINER_PATH);
        } catch (Exception e) {
            LOG.warnv(e, "Could not copy the CA bundle into container {0}; it will not trust Floci HTTPS: {1}",
                    containerId, e.getMessage());
        }
    }
```

Imports: `java.io.ByteArrayInputStream`, `java.io.ByteArrayOutputStream`, `java.nio.file.Files`, `java.nio.file.Path`, `java.util.List`, `java.util.Optional`, `org.apache.commons.compress.archivers.tar.TarArchiveEntry`, `org.apache.commons.compress.archivers.tar.TarArchiveOutputStream`. commons-compress is already a dependency (Lambda uses it).

- [x] **Step 4: Run the lifecycle tests**

Run: `./mvnw test -Dtest='ContainerLifecycleManager*Test'`
Expected: PASS. The existing three tests mock `EmulatorConfig` without `tls()`: `config.tls()` returns `null` there and `hostPath` would NPE. If they fail with `NullPointerException` at `config.tls().enabled()`, add to each of their `@BeforeEach` methods `lenient().when(config.tls()).thenReturn(mock(EmulatorConfig.TlsConfig.class));` (a mock `TlsConfig` returns `false` for `enabled()`).

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/core/common/docker/ContainerLifecycleManager.java src/test/java/io/github/hectorvent/floci/core/common/docker/
git commit -m "feat(docker): every launched container gets the CA bundle and trust env"
```

### Task 4: Delete Lambda's bespoke CA handling, move Kubernetes to the bundle

**Files:**
- Modify: `SRC/services/lambda/launcher/ContainerLauncher.java`
- Modify: `SRC/services/lambda/launcher/kubernetes/KubernetesPodLauncher.java:172-176,191`
- Modify: `SRC/services/lambda/launcher/kubernetes/LambdaPodSpecFactory.java:63,103`
- Modify: `TEST/services/lambda/launcher/kubernetes/LambdaPodSpecFactoryTest.java:248`
- Delete: `TEST/services/lambda/launcher/ContainerLauncherCaTrustTest.java`

- [x] **Step 1: `ContainerLauncher`**

Delete:
- constants `FLOCI_CA_DIR`, `FLOCI_CA_FILE_NAME`, `FLOCI_CA_CONTAINER_PATH` (105-108) and `LOCAL_CA_CERT_NAME` (PR 3's rename of `SELF_SIGNED_CERT_NAME`, 109-110);
- the `flociCaCert` resolution block (230-235, comment included);
- `env.addAll(flociCaEnv(flociCaCert));` (259);
- the "4. Copy Floci's CA cert" block (427-434);
- `resolveFlociCaCertPath`, `isSelfSignedCaCertificate`, `flociCaEnv` (1345-1420).

Remove now-unused imports (`CertificateFactory`, `X509Certificate`, `InputStream` if nothing else uses them; the compiler tells you).

- [x] **Step 2: Kubernetes**

`KubernetesPodLauncher` 172-176 becomes:

```java
            var caConfigMap = ContainerCaBundle.hostPath(config).map(bundle -> ensureCaConfigMap(namespace, bundle));
```

and line 191 becomes:

```java
            if (caConfigMap.isPresent()) {
                env.addAll(ContainerCaBundle.env());
            }
```

Import `io.github.hectorvent.floci.core.common.docker.ContainerCaBundle`. `LambdaPodSpecFactory:103`: `.put("mountPath", ContainerCaBundle.CONTAINER_PATH)`; javadoc at 63: `mounted at /etc/floci-ca-bundle.pem when present`. `LambdaPodSpecFactoryTest:248`: expected `"/etc/floci-ca-bundle.pem"`.

- [x] **Step 3: Delete the old test**

```bash
git rm src/test/java/io/github/hectorvent/floci/services/lambda/launcher/ContainerLauncherCaTrustTest.java
```

- [x] **Step 4: Compile and run the affected tests**

Run: `./mvnw test -Dtest='ContainerLauncherTest,LambdaImageConfigTest,KubernetesPodLauncherTest,LambdaPodSpecFactoryTest,ContainerLifecycleManager*Test,ContainerCaBundleTest'`
Expected: PASS. If `ContainerLauncherTest` asserts on `NODE_EXTRA_CA_CERTS` or `/etc/floci-ca.crt` (grep it), update the assertion to `ContainerCaBundle.env()` entries; the container env is now set by the lifecycle manager, so a launcher-level assertion should simply not expect CA vars.

- [x] **Step 5: Commit**

```bash
git add -A src/main/java/io/github/hectorvent/floci/services/lambda src/test/java/io/github/hectorvent/floci/services/lambda
git commit -m "refactor(lambda): CA trust comes from the lifecycle manager bundle, not the launcher"
```

### Task 5: One real container proves the trust end to end

The four tests so far mock Docker. They pin the env and the copy, not that a runtime reading those
variables actually trusts Floci *and* still reaches public HTTPS. One Docker-gated test does, the
way `BatchDockerRunnerDockerIntegrationTest` does it (skips without a daemon).

**Files:**
- Create: `TEST/core/common/docker/ContainerCaBundleDockerIntegrationTest.java`
- Modify: `.github/ci/prefetch-images.sh` (one line)

- [x] **Step 1: Write the test**

```java
package io.github.hectorvent.floci.core.common.docker;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.async.ResultCallback;
import com.github.dockerjava.api.model.Frame;
import com.github.dockerjava.core.command.WaitContainerResultCallback;
import io.github.hectorvent.floci.config.CertificateMetadata;
import io.github.hectorvent.floci.config.EmulatorConfig;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.core.common.dns.EmbeddedDnsServer;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * A container Floci launches, with no setup of its own, calls https://floci/_floci/ca.pem and a
 * public HTTPS site. Python is the runtime because it honours SSL_CERT_FILE, the "replacing"
 * variable: if the bundle lacked the public roots, the second call would fail. Skipped without
 * a Docker daemon, like the other *DockerIntegrationTest classes.
 */
@QuarkusTest
@TestProfile(ContainerCaBundleDockerIntegrationTest.Profile.class)
class ContainerCaBundleDockerIntegrationTest {

    private static final Path DATA_DIR = Path.of("/tmp/floci-ca-bundle-docker-test");
    private static final Path TLS_DIR = DATA_DIR.resolve("tls");
    private static final String IMAGE = "public.ecr.aws/docker/library/python:3.12-alpine";

    @Inject DockerClient dockerClient;
    @Inject ContainerBuilder containerBuilder;
    @Inject ContainerLifecycleManager lifecycle;
    @Inject ContainerDetector containerDetector;
    @Inject EmulatorConfig config;

    @ConfigProperty(name = "quarkus.http.test-ssl-port", defaultValue = "0")
    int testSslPort;

    @BeforeEach
    void requireDocker() {
        Assumptions.assumeTrue(isDockerAvailable(), "Docker daemon must be available");
    }

    @Test
    void launchedContainerTrustsFlociAndPublicRootsWithoutAnySetup() throws Exception {
        String flociHost = containerDetector.isRunningInContainer()
                ? config.hostname().orElse(EmbeddedDnsServer.DEFAULT_SUFFIX)
                : "host.docker.internal";
        String script = """
                import os, urllib.request, urllib.error
                bundle = "/etc/floci-ca-bundle.pem"
                for var in ("SSL_CERT_FILE", "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "NODE_EXTRA_CA_CERTS", "AWS_CA_BUNDLE"):
                    assert os.environ.get(var) == bundle, (var, os.environ.get(var))
                assert open(bundle).read().count("BEGIN CERTIFICATE") > 1, "bundle must hold public roots and the Floci CA"
                ca = urllib.request.urlopen("https://%s:%d/_floci/ca.pem", timeout=20).read()
                assert b"BEGIN CERTIFICATE" in ca, ca[:80]
                try:
                    urllib.request.urlopen("https://public.ecr.aws/", timeout=20).read()
                except urllib.error.HTTPError:
                    pass  # any HTTP status means the handshake against a public root succeeded
                print("ok")
                """.formatted(flociHost, testSslPort);

        ContainerSpec spec = containerBuilder.newContainer(IMAGE)
                .withName("floci-ca-bundle-test-" + Long.toString(System.nanoTime(), 36))
                .withHostDockerInternalOnLinux()
                .withEntrypoint(List.of("python3", "-c", script))
                .build();

        ContainerLifecycleManager.ContainerInfo info = lifecycle.createAndStart(spec);
        try {
            Integer status = dockerClient.waitContainerCmd(info.containerId())
                    .exec(new WaitContainerResultCallback())
                    .awaitStatusCode(120, TimeUnit.SECONDS);
            assertEquals(0, status, () -> logs(info.containerId()));
        } finally {
            lifecycle.stopAndRemove(info.containerId(), null);
        }
    }

    private String logs(String containerId) {
        StringBuilder out = new StringBuilder();
        try {
            dockerClient.logContainerCmd(containerId).withStdOut(true).withStdErr(true)
                    .exec(new ResultCallback.Adapter<Frame>() {
                        @Override
                        public void onNext(Frame frame) {
                            out.append(new String(frame.getPayload(), StandardCharsets.UTF_8));
                        }
                    }).awaitCompletion(10, TimeUnit.SECONDS);
        } catch (Exception e) {
            out.append("(could not read logs: ").append(e.getMessage()).append(')');
        }
        return out.toString();
    }

    private boolean isDockerAvailable() {
        try {
            dockerClient.pingCmd().exec();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Same fixture shape as the IoT TLS tests: a CA and a server leaf prepared before boot. */
    public static final class Profile implements QuarkusTestProfile {

        static {
            try {
                Files.createDirectories(TLS_DIR);
                for (String name : List.of("floci-server.crt", "floci-server.key", "floci-server.metadata.json")) {
                    Files.deleteIfExists(TLS_DIR.resolve(name));
                }
                FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(TLS_DIR);
                List<String> sans = List.of("localhost", "127.0.0.1", "host.docker.internal",
                        EmbeddedDnsServer.DEFAULT_SUFFIX, "*." + EmbeddedDnsServer.DEFAULT_SUFFIX);
                var leaf = ca.issueServerCertificate("localhost", sans, KeyAlgorithm.RSA_2048, null);
                Files.writeString(TLS_DIR.resolve("floci-server.crt"), leaf.certificatePem());
                Files.writeString(TLS_DIR.resolve("floci-server.key"), leaf.privateKeyPem());
                Files.writeString(TLS_DIR.resolve("floci-server.metadata.json"),
                        new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(CertificateMetadata.create(sans, "dev")));
            } catch (IOException e) {
                throw new IllegalStateException("could not prepare TLS fixtures", e);
            }
        }

        @Override
        public Map<String, String> getConfigOverrides() {
            return Map.ofEntries(
                    Map.entry("floci.tls.enabled", "true"),
                    Map.entry("floci.tls.self-signed", "true"),
                    Map.entry("floci.storage.persistent-path", DATA_DIR.toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.cert", TLS_DIR.resolve("floci-server.crt").toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.key", TLS_DIR.resolve("floci-server.key").toString()),
                    Map.entry("quarkus.http.insecure-requests", "enabled"));
        }
    }
}
```

`host.docker.internal` is in the leaf's SAN list because that is the name the container dials on
Docker Desktop and (via `withHostDockerInternalOnLinux`, `host-gateway`) on Linux; Python verifies
the hostname. Floci binds `0.0.0.0` in tests (`quarkus.http.host` in the main yml), so the random
`test-ssl-port` is reachable from the container. `QuarkusTestProfile.getConfigOverrides()` values
are applied as system properties, which is how `TlsConfigSource.resolveProperty` (sysprop, env,
default) sees `floci.tls.enabled` before CDI exists; PR 8's `IotMqttTlsIntegrationTest` relies on
the same fact.

- [x] **Step 2: Run**

Run: `./mvnw test -Dtest=ContainerCaBundleDockerIntegrationTest`
Expected: PASS (`Tests run: 1, Failures: 0`) with Docker running; `Tests run: 1, Skipped: 1` without.
If it fails, the assertion message is the container's stdout and stderr, so the failing Python
`assert` line names the variable or URL that broke.

To see it fail for the right reason once: remove `"SSL_CERT_FILE"` from `ContainerCaBundle.ENV_KEYS`
(Task 1, line with the five names) and re-run. Expected: FAIL with
`AssertionError: ('SSL_CERT_FILE', None)` in the message (`ContainerCaBundleTest` fails too).
Restore it.

- [x] **Step 3: Prefetch the image in CI**

`.github/ci/prefetch-images.sh` pulls images per shard by package token. Add after the `/ec2/` line:

```bash
grep -q '/common/docker/' "$SHARD_FILE" && pull public.ecr.aws/docker/library/python:3.12-alpine
```

- [x] **Step 4: Commit**

```bash
git add src/test/java/io/github/hectorvent/floci/core/common/docker/ContainerCaBundleDockerIntegrationTest.java .github/ci/prefetch-images.sh
git commit -m "test(docker): a launched container trusts Floci and public roots via the CA bundle"
```

### Task 6: Docs, full run, PR

- [x] **Step 1: `docs/configuration/tls.md`**

Add after "Custom Domains Learned at Runtime" (or after "Custom Hostname Support" if PR 6 is not merged):

```markdown
### Containers Floci Launches

Every container Floci starts (Lambda, ECS, MWAA, Flink, RDS, ElastiCache, Kubernetes Lambda pods)
receives `/etc/floci-ca-bundle.pem`: the public root CAs plus the Floci CA. `SSL_CERT_FILE`,
`CURL_CA_BUNDLE`, `REQUESTS_CA_BUNDLE`, `NODE_EXTRA_CA_CERTS` and `AWS_CA_BUNDLE` point at it, so
Go, Python, Node, curl and every AWS SDK reach both Floci (including custom domains) and public
HTTPS without configuration. A variable you set on the function or task definition wins.
Java workloads are the exception: the JVM does not read those variables, so a Java container
needs its own trust store until Floci ships one.
```

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Full module test run**

Run: `./mvnw test -Dtest='Tls*Test,Container*Test,Lambda*Test,Ecs*Test,Mwaa*Test,Flink*Test,Kubernetes*Test'`
Expected: PASS (`ContainerCaBundleDockerIntegrationTest` skips without Docker).

- [x] **Step 3: Commit and PR body**

```bash
git add docs/configuration/tls.md
git commit -m "docs(tls): containers Floci launches trust the Floci CA"
```

```
With TLS on, only Lambda containers trusted Floci, only through NODE_EXTRA_CA_CERTS and
AWS_CA_BUNDLE, so a Go or curl call from a Lambda to https://api.teos.localhost.floci.io failed,
and ECS, MWAA and Flink workloads could not reach Floci over HTTPS at all.

- TlsConfigSource writes {persistent-path}/tls/floci-ca-bundle.pem at boot: the JVM's public
  roots followed by the Floci CA (or the user-provided certificate).
- ContainerLifecycleManager.create copies it to /etc/floci-ca-bundle.pem in every container and
  sets SSL_CERT_FILE, CURL_CA_BUNDLE, REQUESTS_CA_BUNDLE, NODE_EXTRA_CA_CERTS, AWS_CA_BUNDLE
  (spec values win). Because the bundle carries the public roots, the replacing variables no
  longer cut a workload off from public HTTPS, which is why the previous append-only policy in
  ContainerLauncher (and its test) is gone.
- Kubernetes Lambda pods mount the bundle from their ConfigMap.
- Not included: a Java trust store (the JVM ignores these variables; JAVA_TOOL_OPTIONS is noisy
  and collides with user values) and https in ContainerReachableEndpoint.baseUrl() (plain HTTP
  from container to Floci keeps working; only custom domains need HTTPS and they resolve through
  DNS). Both can follow if a workload needs them.

Tests: ContainerCaBundleTest, ContainerLifecycleManagerCaBundleTest (choke-point coverage for
all launchers), TlsCertificateHostnameTest boot write in both modes, Kubernetes spec test, and
ContainerCaBundleDockerIntegrationTest: a real python:3.12-alpine container, no setup, reaches
https://floci/_floci/ca.pem and https://public.ecr.aws/ through SSL_CERT_FILE alone (skips
without a Docker daemon, like the other *DockerIntegrationTest classes).
Depends on the local CA PR.
```

---

## Self-review

- Spec coverage. Spec PR 7: bind-mount CA + env vars for all launchers: delivered as copy (host path is not mountable when Floci runs in Docker) at the lifecycle choke point, covering every launcher including ones the spec did not list; `SSL_CERT_FILE`, `AWS_CA_BUNDLE`, `NODE_EXTRA_CA_CERTS`, `REQUESTS_CA_BUNDLE`, `CURL_CA_BUNDLE`: Task 1; Java `ca.p12`: deliberately out, see Reconciliation 2; `baseUrl()` https: out, Reconciliation 3.
- Placeholders: none.
- Type consistency: `FlociCertificateAuthority.certificatePath()` and `certificate()` from PR 3; `ContainerCaBundle.write(Path, Path)`, `hostPath(EmulatorConfig)`, `env()`, `appendEnv(List<String>)`, `CONTAINER_PATH`, `CONTAINER_DIR`, `CONTAINER_FILE_NAME` used consistently in Tasks 2 to 4.
- Note for PR 3 ordering: PR 3 Task 5 renamed `SELF_SIGNED_CERT_NAME` to `LOCAL_CA_CERT_NAME` in `ContainerLauncher`; this PR deletes it.
- Adversarial-review fix: the first draft proved the env and the copy only through Mockito; Task 5 runs a real container so a wrong variable name, a bundle without public roots, or a copy to the wrong path fails a test instead of a Lambda at runtime.
