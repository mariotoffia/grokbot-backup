# PR 3: `feat(tls): a local root CA that signs Floci's server certificate` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Floci owns one persistent root CA (`{persistent-path}/tls/floci-root-ca.{crt,key}`) and its HTTPS server certificate is a leaf issued by that CA, so a client that trusts the CA once keeps trusting Floci through every later leaf reissue.

**Architecture:** `FlociCertificateAuthority` is a plain class (no CDI: `TlsConfigSource` runs before CDI) that loads or creates the CA and signs leaves via `CertificateGenerator.generateIssuedCertificate`. A tiny `@ApplicationScoped` producer exposes the same instance to beans (`EmulatorInfoController` for `GET /_floci/ca.pem`, PRs 4 to 8 later). `TlsConfigSource` swaps "self-signed leaf" for "CA-issued leaf", publishes it through `quarkus.tls.key-store.pem.0.*` (the TLS registry, so PR 6 can reload it) and the "regenerate legacy cert" check becomes "not issued by our CA". Lambda's existing container trust injection is pointed at the CA file instead of the leaf.

**Tech Stack:** Quarkus 3.37.4 TLS registry (`quarkus-tls-registry`, transitive via `quarkus-vertx-http`), BouncyCastle, JUnit 5, RestAssured.

**Branch:** `feat/tls-local-ca` from `upstream/main`. Depends on PR 2 (`generateIssuedCertificate`, `generateCaCertificate`, `Issuer`, `LeafUsage`, public `toPem`).

---

## File structure

- Create: `SRC/config/FlociCertificateAuthority.java` (plain class: load or create, sign, `isIssuedByUs`, `caPem`)
- Create: `SRC/config/FlociCertificateAuthorityProducer.java` (`@ApplicationScoped`, one `@Produces`)
- Modify: `SRC/config/TlsConfigSource.java` (constants 46-48, ctor 84-127, `generateSelfSignedCert` 180-207, `isSelfSigned` 221-229)
- Modify: `SRC/config/EmulatorConfig.java:2293-2299` (javadoc of `selfSigned`)
- Modify: `SRC/lifecycle/EmulatorInfoController.java` (ctor, new `GET /ca.pem`)
- Modify: `SRC/services/lambda/launcher/ContainerLauncher.java:109-110, 1345-1377` (CA file name)
- Modify: `src/main/resources/application.yml:223-228`, `src/test/resources/application.yml:98-100` (comments only)
- Modify: `docs/configuration/tls.md`
- Create: `TEST/config/FlociCertificateAuthorityTest.java`
- Modify: `TEST/config/TlsCertificateHostnameTest.java`, `TlsConfigSourceCertificateReuseTest.java`, `TlsConfigSourceCertificateGenerationTest.java`, `TlsConfigSourceMetadataPersistenceTest.java`, `TlsConfigSourceMetadataComparisonTest.java` (file name rename, one new test)
- Modify: `TEST/services/lambda/launcher/ContainerLauncherCaTrustTest.java:46,69` (file name)
- Modify: `TEST/lifecycle/EmulatorInfoControllerIntegrationTest.java` (one new test)

File names after this PR under `{persistent-path}/tls/`:

| File | Content | Perms |
| --- | --- | --- |
| `floci-root-ca.crt` | CA certificate, the thing clients trust | default |
| `floci-root-ca.key` | CA private key | `rw-------` |
| `floci-server.crt` | HTTPS leaf issued by the CA | default |
| `floci-server.key` | leaf private key | `rw-------` |
| `floci-server.metadata.json` | SAN list for change detection (unchanged format) | default |
| `rds-ca.*` | untouched, RDS proxy keeps its own CA | |

The directory itself becomes `rwx------` (same as `RdsProxyTlsCertificates` does at line 122).

---

### Task 1: `FlociCertificateAuthority` with a failing unit test

**Files:**
- Create: `TEST/config/FlociCertificateAuthorityTest.java`
- Create: `SRC/config/FlociCertificateAuthority.java`

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.config;

import io.github.hectorvent.floci.services.acm.CertificateGenerator;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FlociCertificateAuthorityTest {

    @TempDir
    Path tempDir;

    @BeforeAll
    static void bouncyCastle() {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    @Test
    void createsCaFilesWithOwnerOnlyKey() throws Exception {
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tempDir);

        assertTrue(Files.exists(tempDir.resolve("floci-root-ca.crt")));
        assertTrue(Files.exists(tempDir.resolve("floci-root-ca.key")));
        assertTrue(ca.certificate().getBasicConstraints() >= 0, "CA must be cA=true");
        assertEquals(ca.certificate().getSubjectX500Principal(), ca.certificate().getIssuerX500Principal());
        assertTrue(ca.caPem().startsWith("-----BEGIN CERTIFICATE-----"));

        Set<PosixFilePermission> keyPerms = Files.getPosixFilePermissions(tempDir.resolve("floci-root-ca.key"));
        assertEquals(PosixFilePermissions.fromString("rw-------"), keyPerms);
    }

    @Test
    void reloadsTheSameCaAcrossRestarts() {
        FlociCertificateAuthority first = FlociCertificateAuthority.loadOrCreate(tempDir);
        FlociCertificateAuthority second = FlociCertificateAuthority.loadOrCreate(tempDir);

        assertEquals(first.certificate(), second.certificate());
        assertEquals(first.key(), second.key());
    }

    @Test
    void corruptCaIsRegeneratedNotSilentlyKept() throws Exception {
        FlociCertificateAuthority first = FlociCertificateAuthority.loadOrCreate(tempDir);
        Files.writeString(tempDir.resolve("floci-root-ca.crt"), "-----BEGIN CERTIFICATE-----\nnope\n-----END CERTIFICATE-----\n");

        FlociCertificateAuthority second = FlociCertificateAuthority.loadOrCreate(tempDir);

        assertNotEquals(first.certificate(), second.certificate());
        assertTrue(second.certificate().getBasicConstraints() >= 0);
    }

    @Test
    void signsAServerLeafThatVerifiesAgainstTheCa() throws Exception {
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tempDir);

        CertificateGenerator.GeneratedCertificate leaf = ca.issueServerCertificate(
                "localhost", List.of("localhost", "*.localhost.floci.io"), KeyAlgorithm.RSA_2048, null);
        X509Certificate cert = new CertificateGenerator().parseCertificate(leaf.certificatePem());

        cert.verify(ca.certificate().getPublicKey());
        assertEquals(ca.certificate().getSubjectX500Principal(), cert.getIssuerX500Principal());
        assertEquals(List.of("1.3.6.1.5.5.7.3.1"), cert.getExtendedKeyUsage());
        assertTrue(ca.isIssuedByUs(cert));
    }

    @Test
    void aSelfSignedLeafIsNotOurs() throws Exception {
        FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tempDir);
        var stranger = new CertificateGenerator().generateSelfSignedCertificate(
                "localhost", List.of("localhost"), KeyAlgorithm.RSA_2048);

        assertFalse(ca.isIssuedByUs(new CertificateGenerator().parseCertificate(stranger.certificatePem())));
    }
}
```

- [x] **Step 2: Run it and watch it fail to compile**

Run: `./mvnw test -Dtest=FlociCertificateAuthorityTest`
Expected: COMPILATION ERROR, `cannot find symbol: class FlociCertificateAuthority`.

- [x] **Step 3: Write the class**

```java
package io.github.hectorvent.floci.config;

import io.github.hectorvent.floci.services.acm.CertificateGenerator;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.jboss.logging.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.List;

/**
 * Floci's one local root CA. Every certificate the emulator hands out that a client is expected
 * to validate (the HTTPS server leaf, ACM certificates, IoT device certificates) chains to it, so
 * a developer trusts one file once: {@code {persistent-path}/tls/floci-root-ca.crt}, also served
 * at {@code GET /_floci/ca.pem}.
 *
 * <p>Plain class on purpose: {@link TlsConfigSource} needs it before CDI exists. Beans get the
 * same instance through {@link FlociCertificateAuthorityProducer}.
 */
public final class FlociCertificateAuthority {

    private static final Logger LOG = Logger.getLogger(FlociCertificateAuthority.class);

    public static final String CA_CERT_NAME = "floci-root-ca.crt";
    public static final String CA_KEY_NAME = "floci-root-ca.key";
    static final String COMMON_NAME = "Floci Local CA";

    private final Path certificatePath;
    private final X509Certificate certificate;
    private final PrivateKey key;
    private final String caPem;
    private final CertificateGenerator generator;

    private FlociCertificateAuthority(Path certificatePath, X509Certificate certificate, PrivateKey key,
                                      String caPem, CertificateGenerator generator) {
        this.certificatePath = certificatePath;
        this.certificate = certificate;
        this.key = key;
        this.caPem = caPem;
        this.generator = generator;
    }

    /**
     * Loads the CA from {@code tlsDir}, or creates one when missing or unreadable. A corrupt or
     * mismatched pair is regenerated with a WARN: every leaf issued before that moment stops
     * validating, which is the correct outcome for a trust anchor nobody can read.
     */
    public static FlociCertificateAuthority loadOrCreate(Path tlsDir) {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
        CertificateGenerator generator = new CertificateGenerator();
        Path certFile = tlsDir.resolve(CA_CERT_NAME);
        Path keyFile = tlsDir.resolve(CA_KEY_NAME);
        try {
            if (Files.exists(certFile) && Files.exists(keyFile)) {
                try {
                    String pem = Files.readString(certFile);
                    X509Certificate cert = generator.parseCertificate(pem);
                    PrivateKey key = generator.parsePrivateKey(Files.readString(keyFile));
                    if (cert.getBasicConstraints() < 0) {
                        throw new IllegalStateException("not a CA certificate (BasicConstraints cA=false)");
                    }
                    cert.verify(cert.getPublicKey());
                    cert.checkValidity();
                    restrictToOwnerOnly(tlsDir, "rwx------");
                    restrictToOwnerOnly(keyFile, "rw-------");
                    LOG.infov("TLS: using local CA {0} ({1})", certFile, cert.getSubjectX500Principal().getName());
                    return new FlociCertificateAuthority(certFile, cert, key, pem, generator);
                } catch (Exception e) {
                    LOG.warnv("TLS: local CA at {0} is unreadable ({1}); generating a new one. Clients that "
                            + "trusted the old CA must re-import {2}", tlsDir, e.getMessage(), CA_CERT_NAME);
                }
            }
            Files.createDirectories(tlsDir);
            restrictToOwnerOnly(tlsDir, "rwx------");
            CertificateGenerator.GeneratedCertificate generated = generator.generateCaCertificate(COMMON_NAME);
            Files.writeString(certFile, generated.certificatePem());
            Files.writeString(keyFile, generated.privateKeyPem());
            restrictToOwnerOnly(keyFile, "rw-------");
            LOG.infov("TLS: generated local CA {0}. Trust it once: curl http://localhost:4566/_floci/ca.pem", certFile);
            return new FlociCertificateAuthority(certFile,
                    generator.parseCertificate(generated.certificatePem()),
                    generator.parsePrivateKey(generated.privateKeyPem()),
                    generated.certificatePem(), generator);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to create local CA under " + tlsDir, e);
        }
    }

    public X509Certificate certificate() {
        return certificate;
    }

    public PrivateKey key() {
        return key;
    }

    /** PEM of the CA certificate, exactly the bytes on disk. */
    public String caPem() {
        return caPem;
    }

    public Path certificatePath() {
        return certificatePath;
    }

    public CertificateGenerator.Issuer issuer() {
        return new CertificateGenerator.Issuer(certificate, key);
    }

    /**
     * A {@code serverAuth} leaf for {@code commonName} plus {@code sans}. {@code keyPair} null
     * mints a new key of {@code keyAlgorithm}; passing the current pair keeps the public key
     * across a SAN change (the algorithm is then ignored).
     */
    public CertificateGenerator.GeneratedCertificate issueServerCertificate(String commonName, List<String> sans,
                                                                            KeyAlgorithm keyAlgorithm, KeyPair keyPair) {
        return generator.generateIssuedCertificate(commonName, sans, keyAlgorithm, keyPair, issuer(),
                CertificateGenerator.LeafUsage.SERVER);
    }

    /** A {@code clientAuth} leaf, for IoT device certificates. Always a fresh key pair. */
    public CertificateGenerator.GeneratedCertificate issueClientCertificate(String commonName) {
        return generator.generateIssuedCertificate(commonName, List.of(), KeyAlgorithm.RSA_2048, null, issuer(),
                CertificateGenerator.LeafUsage.CLIENT);
    }

    /** True when {@code cert} names this CA as issuer and its signature checks against our key. */
    public boolean isIssuedByUs(X509Certificate cert) {
        if (!certificate.getSubjectX500Principal().equals(cert.getIssuerX500Principal())) {
            return false;
        }
        try {
            cert.verify(certificate.getPublicKey());
            return true;
        } catch (Exception e) {
            LOG.debugv("TLS: certificate names our CA but does not verify: {0}", e.getMessage());
            return false;
        }
    }

    static void restrictToOwnerOnly(Path path, String posixPerms) {
        PosixFileAttributeView view = Files.getFileAttributeView(path, PosixFileAttributeView.class);
        if (view == null) {
            return;
        }
        try {
            view.setPermissions(PosixFilePermissions.fromString(posixPerms));
        } catch (IOException e) {
            LOG.warnv("TLS: could not restrict permissions on {0}: {1}", path, e.getMessage());
        }
    }
}
```

- [x] **Step 4: Run the test and watch it pass**

Run: `./mvnw test -Dtest=FlociCertificateAuthorityTest`
Expected: PASS, 5 tests.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/FlociCertificateAuthority.java src/test/java/io/github/hectorvent/floci/config/FlociCertificateAuthorityTest.java
git commit -m "feat(tls): FlociCertificateAuthority, a persistent local root CA

Loads or creates {persistent-path}/tls/floci-root-ca.{crt,key} with an
owner-only key, signs serverAuth and clientAuth leaves through
CertificateGenerator, and regenerates with a WARN when the pair is unreadable."
```

### Task 2: The CDI producer

**Files:**
- Create: `SRC/config/FlociCertificateAuthorityProducer.java`

- [x] **Step 1: Write the producer**

```java
package io.github.hectorvent.floci.config;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.inject.Inject;

import java.nio.file.Path;

/**
 * Exposes {@link FlociCertificateAuthority} to CDI. {@link TlsConfigSource} may already have
 * created the files during config bootstrap; this loads the same pair. Lazy, so a boot with TLS
 * off and no ACM or IoT traffic never touches the disk.
 */
@ApplicationScoped
public class FlociCertificateAuthorityProducer {

    static final String TLS_DIR = "tls";

    private final EmulatorConfig config;

    @Inject
    public FlociCertificateAuthorityProducer(EmulatorConfig config) {
        this.config = config;
    }

    @Produces
    @ApplicationScoped
    FlociCertificateAuthority certificateAuthority() {
        return FlociCertificateAuthority.loadOrCreate(tlsDir(config));
    }

    /**
     * The one TLS directory. {@link TlsConfigSource} runs before CDI and resolves
     * {@code floci.storage.persistent-path} from system properties and environment only; when it
     * laid down the CA, every CDI consumer must use exactly that directory, or a persistent-path set
     * in application.yml alone would produce a second CA (served leaf signed by one, ca.pem from
     * the other). With TLS off the bootstrap never ran and the configured path is the only truth.
     */
    static Path tlsDir(EmulatorConfig config) {
        Path fromBootstrap = TlsConfigSource.resolvedTlsDir();
        return fromBootstrap != null ? fromBootstrap : Path.of(config.storage().persistentPath(), TLS_DIR);
    }
}
```

`TlsConfigSource.resolvedTlsDir()` is added in Task 3 (Step 4); until then this does not compile,
so Task 2 Step 2 runs after Task 3 Step 4 if you execute strictly in order. Simplest: add the two
lines to `TlsConfigSource` now, together with this class:

```java
    private static volatile Path resolvedTlsDir;

    /** The directory the bootstrap used for CA and leaf, or null when it did not run the self-signed branch. */
    static Path resolvedTlsDir() {
        return resolvedTlsDir;
    }
```

- [x] **Step 2: Compile**

Run: `./mvnw -q compile`
Expected: BUILD SUCCESS. (No behaviour to test until Task 4 injects it.)

- [x] **Step 3: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/FlociCertificateAuthorityProducer.java
git commit -m "feat(tls): produce FlociCertificateAuthority for CDI consumers"
```

### Task 3: `TlsConfigSource` issues the server leaf from the CA

**Files:**
- Modify: `SRC/config/TlsConfigSource.java`
- Modify: five `TEST/config/TlsConfigSource*Test.java` + `TlsCertificateHostnameTest.java` (rename)

- [x] **Step 1: Rename the on-disk file names in the tests first (mechanical)**

Run:
```bash
grep -rl 'floci-selfsigned' src/test/java/io/github/hectorvent/floci/config | xargs sed -i '' 's/floci-selfsigned/floci-server/g'
grep -rn 'floci-selfsigned' src/test/java/io/github/hectorvent/floci/config | wc -l
```
Expected: second command prints `0`.

- [x] **Step 2: Add a failing test to `TlsCertificateHostnameTest`**

Append inside the class:

```java
    @Test
    void serverCertificateIsIssuedByTheLocalCa() throws Exception {
        System.setProperty("floci.tls.enabled", "true");
        System.setProperty("floci.tls.self-signed", "true");
        System.setProperty("floci.storage.persistent-path", tempDir.toString());

        TlsConfigSource source = new TlsConfigSource();

        Path tlsDir = tempDir.resolve("tls");
        X509Certificate ca = parseCertificate(tlsDir.resolve("floci-root-ca.crt"));
        X509Certificate leaf = parseCertificate(tlsDir.resolve("floci-server.crt"));
        leaf.verify(ca.getPublicKey());
        assertEquals(ca.getSubjectX500Principal(), leaf.getIssuerX500Principal());
        assertEquals(-1, leaf.getBasicConstraints(), "server leaf must not be a CA");

        assertEquals(tlsDir.resolve("floci-server.crt").toAbsolutePath().toString(),
                source.getValue("quarkus.tls.key-store.pem.0.cert"));
        assertEquals(tlsDir.resolve("floci-server.key").toAbsolutePath().toString(),
                source.getValue("quarkus.tls.key-store.pem.0.key"));
        assertNull(source.getValue("quarkus.http.ssl.certificate.files"), "legacy key no longer published");
        assertEquals(PosixFilePermissions.fromString("rw-------"),
                Files.getPosixFilePermissions(tlsDir.resolve("floci-server.key")));
    }

    @Test
    void legacySelfSignedLeafIsReplacedByCaIssuedOne() throws Exception {
        System.setProperty("floci.tls.enabled", "true");
        System.setProperty("floci.tls.self-signed", "true");
        System.setProperty("floci.storage.persistent-path", tempDir.toString());
        Path tlsDir = Files.createDirectories(tempDir.resolve("tls"));
        CertificateGenerator gen = new CertificateGenerator();
        // The exact SAN list TlsConfigSource would compute for this configuration, so only the
        // issuer check can trigger regeneration here.
        List<String> sans = List.of("localhost", "127.0.0.1", "0.0.0.0", "*.localhost",
                "localhost.floci.io", "*.localhost.floci.io", "*.execute-api.localhost.floci.io",
                "*.execute-api.localhost.localstack.cloud", "host.docker.internal");
        var legacy = gen.generateSelfSignedCertificate("localhost", sans, KeyAlgorithm.RSA_2048);
        Files.writeString(tlsDir.resolve("floci-server.crt"), legacy.certificatePem());
        Files.writeString(tlsDir.resolve("floci-server.key"), legacy.privateKeyPem());
        Files.writeString(tlsDir.resolve("floci-server.metadata.json"),
                new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(
                        CertificateMetadata.create(sans, "dev")));

        new TlsConfigSource();

        X509Certificate ca = parseCertificate(tlsDir.resolve("floci-root-ca.crt"));
        X509Certificate leaf = parseCertificate(tlsDir.resolve("floci-server.crt"));
        assertEquals(ca.getSubjectX500Principal(), leaf.getIssuerX500Principal());
    }
```

Add imports `java.nio.file.attribute.PosixFilePermissions`, and `static org.junit.jupiter.api.Assertions.assertNull` if missing.

- [x] **Step 3: Run and watch the two new tests fail**

Run: `./mvnw test -Dtest=TlsCertificateHostnameTest`
Expected: the two new tests FAIL (`NoSuchFileException: .../floci-root-ca.crt` and `quarkus.tls.key-store.pem.0.cert` is null); the renamed older tests FAIL too with `NoSuchFileException: floci-server.crt` because the source still writes `floci-selfsigned.crt`.

- [x] **Step 4: Change `TlsConfigSource`**

Constants (lines 46 to 48):

```java
    private static final String SERVER_CERT_NAME = "floci-server.crt";
    private static final String SERVER_KEY_NAME = "floci-server.key";
    private static final String SERVER_METADATA_NAME = "floci-server.metadata.json";
```

Replace every use of `SELF_SIGNED_CERT_NAME`, `SELF_SIGNED_KEY_NAME`, `SELF_SIGNED_METADATA_NAME` with the new names (lines 86, 87, 288, 325).

Constructor, the `else if ("true".equalsIgnoreCase(selfSigned))` branch (lines 84 to 112) becomes:

```java
        } else if ("true".equalsIgnoreCase(selfSigned)) {
            Path tlsDir = Path.of(persistentPath, TLS_DIR);
            resolvedTlsDir = tlsDir;
            Path certFile = tlsDir.resolve(SERVER_CERT_NAME);
            Path keyFile = tlsDir.resolve(SERVER_KEY_NAME);
            FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(tlsDir);

            if (Files.exists(certFile) && Files.exists(keyFile)) {
                List<String> currentHostnames = new ArrayList<>(DEFAULT_SAN_HOSTNAMES);
                currentHostnames.addAll(extractCustomHostnames());

                // Regenerate when the hostname config changed, when the existing leaf was not
                // issued by the current CA (pre-CA self-signed cert, or the CA was regenerated), or
                // when it is outside its validity window (the leaf lives 365 days, dev data dirs longer).
                if (hostnameConfigChanged(tlsDir, currentHostnames) || !isValidLocalLeaf(ca, certFile)) {
                    generateServerCert(tlsDir, certFile, keyFile, ca);
                } else {
                    LOG.infov("TLS: reusing existing server certificate: {0}", certFile);
                }
            } else {
                generateServerCert(tlsDir, certFile, keyFile, ca);
            }

            certPath = certFile.toAbsolutePath().toString();
            keyPath = keyFile.toAbsolutePath().toString();
        } else {
```

Properties (lines 119 and 120):

```java
        // The default entry of the Quarkus TLS registry. The HTTP server reads it, and
        // TlsConfigurationRegistry.getDefault().reload() can swap the leaf at runtime.
        properties.put("quarkus.tls.key-store.pem.0.cert", certPath);
        properties.put("quarkus.tls.key-store.pem.0.key", keyPath);
```

Replace `generateSelfSignedCert` (lines 180 to 207) with:

```java
    private void generateServerCert(Path tlsDir, Path certFile, Path keyFile, FlociCertificateAuthority ca) {
        try {
            Files.createDirectories(tlsDir);
            List<String> allSans = new ArrayList<>(DEFAULT_SAN_HOSTNAMES);
            allSans.addAll(extractCustomHostnames());

            CertificateGenerator.GeneratedCertificate generated = ca.issueServerCertificate("localhost", allSans,
                    KeyAlgorithm.RSA_2048, null);

            Files.writeString(certFile, generated.certificatePem());
            Files.writeString(keyFile, generated.privateKeyPem());
            FlociCertificateAuthority.restrictToOwnerOnly(keyFile, "rw-------");

            LOG.infov("TLS: generated server certificate {0} issued by {1}", certFile,
                    ca.certificate().getSubjectX500Principal().getName());
            persistMetadata(tlsDir, allSans);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to write TLS server certificate", e);
        }
    }
```

Replace `isSelfSigned` (lines 216 to 229) with:

```java
    private boolean isValidLocalLeaf(FlociCertificateAuthority ca, Path certFile) {
        try {
            X509Certificate cert = new CertificateGenerator().parseCertificate(Files.readString(certFile));
            if (!ca.isIssuedByUs(cert)) {
                LOG.infov("TLS: existing server certificate was not issued by the local CA; regenerating");
                return false;
            }
            cert.checkValidity();
            return true;
        } catch (Exception e) {
            LOG.warnv("TLS: existing server certificate unusable ({0}); regenerating", e.getMessage());
            return false;
        }
    }
```

`checkValidity()` throws `CertificateExpiredException` or `CertificateNotYetValidException`, both
land in the catch and regenerate.

Update the class javadoc paragraph (lines 34 to 38) to:

```java
 * <p>
 * When TLS is enabled without a user certificate, the server certificate is a leaf issued by
 * {@link FlociCertificateAuthority} and persisted under {@code {persistent-path}/tls/}. Clients
 * trust the CA ({@code floci-root-ca.crt}, or {@code GET /_floci/ca.pem}), never the leaf.
```

Also fix the comment at lines 68 to 72 to say `isValidLocalLeaf` instead of `isSelfSigned`.

- [x] **Step 5: Run all the config TLS unit tests**

Run: `./mvnw test -Dtest='TlsConfigSource*Test,TlsCertificateHostnameTest'`
Expected: PASS. Watch `TlsConfigSourceCertificateReuseTest.testCertificateReusedWhenBouncyCastleNotPreRegistered`: `loadOrCreate` registers BouncyCastle itself, so the reuse path still holds.

- [x] **Step 6: Run the TLS integration tests (they bypass `TlsConfigSource` and must be untouched)**

Run: `./mvnw test -Dtest='TlsIntegrationTest,TlsUserCertIntegrationTest,TlsProxyServerTest'`
Expected: PASS.

- [x] **Step 7: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/TlsConfigSource.java src/test/java/io/github/hectorvent/floci/config
git commit -m "feat(tls): issue the HTTPS server certificate from the local CA

The leaf is floci-server.{crt,key}, signed by floci-root-ca; a pre-CA
self-signed leaf is replaced on first boot. Published through
quarkus.tls.key-store.pem.0.* so the TLS registry owns it and can reload it.
The server key is written owner-only."
```

### Task 4: `GET /_floci/ca.pem`

**Files:**
- Modify: `TEST/lifecycle/EmulatorInfoControllerIntegrationTest.java`
- Modify: `SRC/lifecycle/EmulatorInfoController.java`

- [x] **Step 1: Write the failing test**

Append inside the test class:

```java
    @ParameterizedTest
    @ValueSource(strings = {"/_floci/ca.pem", "/_localstack/ca.pem"})
    void caPem_returnsTheLocalCaAsPlainText(String path) throws Exception {
        String pem = given()
            .when().get(path)
            .then()
                .statusCode(200)
                .contentType(startsWith("text/plain"))
                .extract().body().asString();

        var cert = (java.security.cert.X509Certificate) java.security.cert.CertificateFactory.getInstance("X.509")
                .generateCertificate(new java.io.ByteArrayInputStream(pem.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));
        assertTrue(cert.getBasicConstraints() >= 0, "must be a CA certificate");
        assertEquals(cert.getSubjectX500Principal(), cert.getIssuerX500Principal());
    }
```

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=EmulatorInfoControllerIntegrationTest#caPem_returnsTheLocalCaAsPlainText`
Expected: FAIL, status 404.

- [x] **Step 3: Add the endpoint**

In `EmulatorInfoController`: add a constructor parameter `FlociCertificateAuthority certificateAuthority` (and field), import `io.github.hectorvent.floci.config.FlociCertificateAuthority` and `jakarta.ws.rs.core.MediaType`, then add:

```java
    /**
     * The local root CA in PEM. Trust this once (system keychain, {@code AWS_CA_BUNDLE},
     * {@code NODE_EXTRA_CA_CERTS}) and every certificate Floci issues validates.
     */
    @GET
    @Path("/ca.pem")
    @Produces(MediaType.TEXT_PLAIN)
    public String caPem() {
        return certificateAuthority.caPem();
    }
```

If there is a test that constructs `EmulatorInfoController` directly (`grep -rn "new EmulatorInfoController(" src/test`), pass `FlociCertificateAuthority.loadOrCreate(tempDir)`.

- [x] **Step 4: Run and watch it pass**

Run: `./mvnw test -Dtest=EmulatorInfoControllerIntegrationTest`
Expected: PASS. The CA is created lazily under `./target/test-data/tls/` (test yml `persistent-path`).

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/lifecycle/EmulatorInfoController.java src/test/java/io/github/hectorvent/floci/lifecycle/EmulatorInfoControllerIntegrationTest.java
git commit -m "feat: serve the local CA at GET /_floci/ca.pem"
```

### Task 5: Lambda containers trust the CA, not the leaf

**Files:**
- Modify: `SRC/services/lambda/launcher/ContainerLauncher.java:109-110, 1345-1377`
- Modify: `TEST/services/lambda/launcher/ContainerLauncherCaTrustTest.java:46, 69`

- [x] **Step 1: Update the test to the CA file name**

Lines 46 and 69: `"floci-selfsigned.crt"` becomes `"floci-root-ca.crt"`. Rename the two tests to `resolveCaCertPath_localCaUnderPersistentPath` and `resolveCaCertPath_blankUserCertFallsBackToLocalCa`.

- [x] **Step 2: Run and watch them fail**

Run: `./mvnw test -Dtest=ContainerLauncherCaTrustTest`
Expected: two FAIL (`Optional.orElseThrow` on empty: the launcher still looks for `floci-selfsigned.crt`).

- [x] **Step 3: Point the launcher at the CA**

Lines 109 and 110 become:

```java
    /** Root CA produced by {@code FlociCertificateAuthority} under {persistent-path}/tls/. */
    private static final String LOCAL_CA_CERT_NAME = io.github.hectorvent.floci.config.FlociCertificateAuthority.CA_CERT_NAME;
```

Line 1364: `Path.of(persistentPath, "tls", SELF_SIGNED_CERT_NAME)` becomes `Path.of(persistentPath, "tls", LOCAL_CA_CERT_NAME)`.

Javadoc lines 1345 to 1355: replace "the self-signed cert under" with "Floci's local root CA under" and "The auto-generated Floci cert is one" with "Floci's local CA is one".

- [x] **Step 4: Run and watch them pass**

Run: `./mvnw test -Dtest=ContainerLauncherCaTrustTest`
Expected: PASS. `KubernetesPodLauncher` and `LambdaPodSpecFactory` call the same static helpers, nothing else to change.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/lambda/launcher/ContainerLauncher.java src/test/java/io/github/hectorvent/floci/services/lambda/launcher/ContainerLauncherCaTrustTest.java
git commit -m "fix(lambda): inject the local root CA into containers instead of the server leaf

The leaf will be reissued as SANs grow; pinning it would break after the first
reissue. The CA is stable."
```

### Task 6: Config text and docs

**Files:**
- Modify: `SRC/config/EmulatorConfig.java:2293-2299`
- Modify: `src/main/resources/application.yml:227`, `src/test/resources/application.yml:98-100`
- Modify: `docs/configuration/tls.md`

- [x] **Step 1: `EmulatorConfig.TlsConfig.selfSigned` javadoc**

```java
        /**
         * Auto-generate a server certificate when no cert-path/key-path is provided. The leaf is
         * issued by Floci's local root CA; both live under {@code {storage.persistent-path}/tls/}
         * and survive restarts. Clients trust the CA ({@code GET /_floci/ca.pem}), not the leaf.
         * Env: FLOCI_TLS_SELF_SIGNED
         */
        @WithDefault("true")
        boolean selfSigned();
```

- [x] **Step 2: `application.yml` line 227 comment**

```yaml
    self-signed: true                  # FLOCI_TLS_SELF_SIGNED: auto-generate a server cert signed by Floci's local CA if no cert-path provided
```

Test yml lines 98 to 100 need no value change; if there is a comment mentioning "self-signed certificate", reword it to "certificate issued by the local CA".

- [x] **Step 3: `docs/configuration/tls.md`**

Replace the Quick Start paragraph and block (lines 11 to 23) with:

````markdown
Then trust Floci's local CA in the processes that talk to it. Every certificate Floci issues (its
HTTPS endpoint, ACM certificates, IoT device certificates) chains to it:

```bash
curl -s http://localhost:4566/_floci/ca.pem -o floci-root-ca.pem

# AWS CLI and every AWS SDK
export AWS_CA_BUNDLE=$PWD/floci-root-ca.pem
aws --endpoint-url https://localhost:4566 sts get-caller-identity

# Node.js (appends to the built-in roots)
export NODE_EXTRA_CA_CERTS=$PWD/floci-root-ca.pem

# curl, Python, Go on Linux (replaces the default roots for that process only)
export SSL_CERT_FILE=$PWD/floci-root-ca.pem
```

Prefer these per-process variables, and scope them to the shell or the tool (a `.envrc`, a
compose `environment:` block) that needs them. They cannot affect anything else on the machine.

Installing the CA into the operating system trust store (macOS `security add-trusted-cert`,
Linux `update-ca-certificates`) also works and is what Safari, Chrome and Go on macOS need, but
understand what it does: every process on the machine then trusts anything signed by the key in
`{persistent-path}/tls/floci-root-ca.key`. Keep that file private, treat the CA as a dev-machine
secret, and remove it from the store when you stop using Floci:

```bash
# macOS login keychain; remove later with: security delete-certificate -c "Floci Local CA"
security add-trusted-cert -r trustRoot -k ~/Library/Keychains/login.keychain-db floci-root-ca.pem
```

Disabling verification (`--no-verify-ssl`, `verify=False`, `NODE_TLS_REJECT_UNAUTHORIZED=0`) still
works but is no longer needed.
````

Replace the section `## Self-Signed Certificate` heading and intro (lines 34 to 36) with:

```markdown
## Local CA and Server Certificate

When `FLOCI_TLS_ENABLED=true` and no custom certificate is provided, Floci keeps a local root CA
at `{persistent-path}/tls/floci-root-ca.crt` (key `floci-root-ca.key`, owner-only) and issues its
server certificate `floci-server.crt` from it at startup. The server certificate:
```

Keep the four bullets. In the table row at line 32 change the description to
`Auto-generate a server certificate signed by Floci's local CA when no cert/key paths provided`.

In "When Do I Need to Disable TLS Verification?" replace the first row with:

```markdown
| Floci local CA (default) | **No**, once you trust `floci-root-ca.crt` (`GET /_floci/ca.pem`) | One CA covers the HTTPS endpoint and every ACM and IoT certificate Floci issues |
```

Troubleshooting: add before the last entry:

```markdown
**`Go: x509: certificate signed by unknown authority` on macOS.**
Go on macOS ignores `SSL_CERT_FILE` and reads the keychain. Pin the CA in code with
`x509.NewCertPool().AppendCertsFromPEM` (what a client that fetches `/_floci/ca.pem` or the ACM
`CertificateChain` does anyway), or add it to the login keychain as shown in Quick Start.

**I regenerated `{persistent-path}/tls/`.**
That created a new CA. Re-download `/_floci/ca.pem` wherever you installed the old one.
```

Anywhere else the page says "self-signed", reword to "issued by Floci's local CA" (lines 47, 81, 148, 159, 171 to 175). Remove the em-dashes on lines 91 and 159 while there (use a comma or colon).

- [x] **Step 4: Docs check**

Run: `make docs-check`
Expected: exit 0.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/EmulatorConfig.java src/main/resources/application.yml src/test/resources/application.yml docs/configuration/tls.md
git commit -m "docs(tls): trust the local CA once instead of disabling verification"
```

### Task 7: Whole-module check and PR

- [x] **Step 1: Run every test touched by this PR in one go**

Run: `./mvnw test -Dtest='FlociCertificateAuthorityTest,TlsConfigSource*Test,TlsCertificateHostnameTest,TlsIntegrationTest,TlsUserCertIntegrationTest,TlsProxyServerTest,EmulatorInfoControllerIntegrationTest,ContainerLauncherCaTrustTest,CertificateGenerator*Test'`
Expected: PASS.

- [x] **Step 2: Manual smoke (optional but cheap)**

```bash
FLOCI_TLS_ENABLED=true FLOCI_STORAGE_PERSISTENT_PATH=/tmp/floci-pr3 ./mvnw quarkus:dev -Dquarkus.args="" &
sleep 40
curl -s http://localhost:4566/_floci/ca.pem -o /tmp/floci-pr3-ca.pem
curl --cacert /tmp/floci-pr3-ca.pem https://localhost:4566/_floci/health | head -c 80
ls -l /tmp/floci-pr3/tls/
```
Expected: the second curl returns JSON without `-k`; `ls` shows `floci-root-ca.key` and `floci-server.key` as `-rw-------`.

- [x] **Step 3: PR body**

```
Floci's HTTPS certificate was a self-signed leaf. Trusting it pinned that exact certificate,
which breaks the moment the leaf is reissued (hostname change, and the growing SAN list in a
follow-up PR). This PR gives Floci one local root CA and makes the server certificate a leaf
issued by it.

- FlociCertificateAuthority: {persistent-path}/tls/floci-root-ca.{crt,key}, key owner-only,
  regenerated with a WARN if unreadable. Plain class so TlsConfigSource can use it pre-CDI;
  a producer exposes it to beans.
- TlsConfigSource: the leaf is floci-server.{crt,key}, issued by the CA, serverAuth EKU;
  published through quarkus.tls.key-store.pem.0.* (TLS registry default) instead of the
  legacy quarkus.http.ssl.certificate.*; a pre-CA self-signed leaf is replaced on first boot.
- GET /_floci/ca.pem (and /_localstack/ca.pem) serves the CA as text/plain.
- Lambda container trust injection now mounts the CA, not the leaf.
- docs/configuration/tls.md: trust the CA once instead of disabling verification.

Tests: FlociCertificateAuthorityTest (create, reload, corrupt-regenerate, sign, isIssuedByUs),
two new TlsCertificateHostnameTest cases (issued by CA, legacy leaf replaced, registry keys),
EmulatorInfoControllerIntegrationTest#caPem, ContainerLauncherCaTrustTest updated.

Behaviour change for existing installs: the first boot after upgrade regenerates the server
certificate and logs where the CA is. Anyone who had trusted floci-selfsigned.crt must trust
floci-root-ca.crt instead.
```

---

## Self-review

- Spec coverage. Spec PR 3 bullets: plain class + producer (Tasks 1, 2); `TlsConfigSource` signs with CA, `isSelfSigned` replaced by issued-by-CA, switch to `quarkus.tls.key-store.pem.0.*` (Task 3); CA key perms and server key perms (Tasks 1, 3); `GET /_floci/ca.pem` text/plain (Task 4); corrupt CA WARN + regenerate, never silent self-signed fallback (Task 1 `loadOrCreate`; `TlsConfigSource` has no self-signed branch left); config text + both yml + docs (Task 6). Extra beyond spec, found while reading: Lambda already injects the leaf as a trust anchor, so Task 5 repoints it. Without it, PR 6 would break Lambda HTTPS callbacks on the first reissue.
- Placeholders: none. Every code step has full code.
- Type consistency: `FlociCertificateAuthority.loadOrCreate(Path)`, `certificate()`, `key()`, `caPem()`, `certificatePath()`, `issuer()`, `issueServerCertificate(String, List<String>, KeyAlgorithm, KeyPair)`, `issueClientCertificate(String)`, `isIssuedByUs(X509Certificate)`, static `restrictToOwnerOnly(Path, String)`, constants `CA_CERT_NAME`, `CA_KEY_NAME`. PRs 4 to 8 use exactly these. `CertificateGenerator.generateIssuedCertificate` signature matches PR 2.
- Open question carried to PR 6: `TlsUserCertIntegrationTest`/`TlsIntegrationTest` profiles still set legacy `quarkus.http.ssl.certificate.*`; that is fine for them, and PR 6's reload test sets `quarkus.tls.key-store.pem.0.*` in its own profile.
