# PR 10: `feat(cognito): route custom domains by Host` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A request to `https://auth.teos.localhost.floci.io/oauth2/token` (the URL a Cognito custom domain has on AWS) reaches Floci's token handler, is refused with `invalid_client` when the `client_id` belongs to another pool, and the pool's `openid-configuration` advertises those custom-domain URLs.

**Architecture:** A `@PreMatching` `ContainerRequestFilter` copied from `ApiGatewayCustomDomainFilter`: it looks the request `Host` up in `CognitoService`'s domain store (custom domains are keyed by their FQDN and carry a `certificateArn`) and rewrites `/oauth2/token` and `/oauth2/userInfo` onto the existing `/cognito-idp/oauth2/...` resources. `CognitoOAuthController` re-reads `Host` through the same lookup and passes the domain's pool id to `issueClientCredentialsToken`, which rejects a client from another pool. `getTokenEndpoint`/`getUserInfoEndpoint` become pool-aware.

**Tech Stack:** JAX-RS filters (RESTEasy Reactive), RestAssured with a `Host` header.

**Branch:** `feat/cognito-host-routing` from `upstream/main`. No dependency on the other PRs of this task: it works over plain HTTP and gains TLS when PRs 6 and 9 land.

**Not in scope, stated so nobody adds it:** `/oauth2/authorize`, `/login`, `/logout`, and the prefix form `<prefix>.auth.<region>.amazoncognito.com`. Floci has no hosted UI and `EmbeddedDnsServer` only answers the Floci suffixes, so none of those can be reached.

---

## File structure

- Create: `SRC/services/cognito/CognitoCustomDomainFilter.java` (Host lookup + path rewrite, one static helper for the hostname)
- Modify: `SRC/services/cognito/CognitoService.java` (`findCustomDomain(String hostname)`, `findCustomDomainForPool(String poolId)`, 4-arg `issueClientCredentialsToken`, pool-aware `getTokenEndpoint(poolId)`/`getUserInfoEndpoint(poolId)`)
- Modify: `SRC/services/cognito/CognitoOAuthController.java:38-45,84` (inject `HttpHeaders`, pass the domain pool)
- Modify: `SRC/services/cognito/CognitoWellKnownController.java:62-63`
- Create: `TEST/services/cognito/CognitoCustomDomainRoutingIntegrationTest.java`
- Modify: `docs/services/cognito.md`

---

### Task 1: The service knows its custom domains

**Files:**
- Modify: `SRC/services/cognito/CognitoService.java`
- Modify: `TEST/services/cognito/CognitoServiceTest.java`

- [x] **Step 1: Write the failing tests**

Append to `CognitoServiceTest` (the class already has a `service` built with the 9-arg constructor at line 51 and helpers to create pools; use `service.createUserPool(Map.of("PoolName", "..."), "us-east-1")` which returns a `UserPool` with `getId()`):

```java
    @Test
    void findCustomDomainMatchesOnlyCustomDomains() {
        String poolId = service.createUserPool(Map.of("PoolName", "domain-pool"), "us-east-1").getId();
        service.createUserPoolDomain("auth.teos.localhost.floci.io", poolId,
                Map.of("CertificateArn", "arn:aws:acm:us-east-1:000000000000:certificate/abc"), null);
        service.createUserPoolDomain("teos-prefix", poolId, null, null);

        assertTrue(service.findCustomDomain("auth.teos.localhost.floci.io").isPresent());
        assertEquals(poolId, service.findCustomDomain("auth.teos.localhost.floci.io").get().getUserPoolId());
        assertTrue(service.findCustomDomain("teos-prefix").isEmpty());
        assertTrue(service.findCustomDomain("nobody.localhost.floci.io").isEmpty());
        assertEquals("auth.teos.localhost.floci.io", service.findCustomDomainForPool(poolId).get().getDomain());
    }

    @Test
    void clientCredentialsTokenIsRefusedWhenTheClientBelongsToAnotherPool() {
        String poolA = service.createUserPool(Map.of("PoolName", "pool-a"), "us-east-1").getId();
        String poolB = service.createUserPool(Map.of("PoolName", "pool-b"), "us-east-1").getId();
        UserPoolClient clientB = service.createUserPoolClient(poolB, "b", true, true,
                List.of("client_credentials"), List.of());

        AwsException e = assertThrows(AwsException.class, () -> service.issueClientCredentialsToken(
                clientB.getClientId(), clientB.getClientSecret(), null, poolA));
        assertEquals("ResourceNotFoundException", e.getErrorCode());

        assertNotNull(service.issueClientCredentialsToken(clientB.getClientId(), clientB.getClientSecret(), null, poolB)
                .get("access_token"));
        assertNotNull(service.issueClientCredentialsToken(clientB.getClientId(), clientB.getClientSecret(), null, null)
                .get("access_token"));
    }

    @Test
    void endpointsUseTheCustomDomainWhenThePoolHasOne() {
        String withDomain = service.createUserPool(Map.of("PoolName", "with-domain"), "us-east-1").getId();
        String without = service.createUserPool(Map.of("PoolName", "without-domain"), "us-east-1").getId();
        service.createUserPoolDomain("auth2.teos.localhost.floci.io", withDomain,
                Map.of("CertificateArn", "arn:aws:acm:us-east-1:000000000000:certificate/abc"), null);

        assertEquals("https://auth2.teos.localhost.floci.io/oauth2/token", service.getTokenEndpoint(withDomain));
        assertEquals("https://auth2.teos.localhost.floci.io/oauth2/userInfo", service.getUserInfoEndpoint(withDomain));
        assertEquals("http://localhost:4566/cognito-idp/oauth2/token", service.getTokenEndpoint(without));
        assertEquals("http://localhost:4566/cognito-idp/oauth2/userInfo", service.getUserInfoEndpoint(without));
    }
```

The test class builds `service` with the 9-arg constructor at line 51 and base URL `http://localhost:4566`, which the endpoint assertions above rely on. `createUserPoolClient(poolId, name, generateSecret, allowedOAuthFlowsUserPoolClient, allowedOAuthFlows, allowedOAuthScopes)` is the 6-arg overload at `CognitoService:538`. Add imports for `List`, `Map`, `UserPoolClient`, `AwsException` if missing.

- [x] **Step 2: Run and watch them fail**

Run: `./mvnw test -Dtest=CognitoServiceTest`
Expected: compile errors, `findCustomDomain`, `findCustomDomainForPool`, 4-arg `issueClientCredentialsToken` and 1-arg `getTokenEndpoint` do not exist.

- [x] **Step 3: Implement**

In `CognitoService`, next to `describeUserPoolDomain` (line 1118):

```java
    /**
     * Host-based lookups run before any SigV4 account is known (a browser or SDK OAuth call
     * carries none), so they search every account, the way
     * {@code SecretsManagerService} and {@code KinesisService} do with the same instanceof.
     * {@code domainStore.get(name)} would only see the default account.
     */
    public Optional<UserPoolDomain> findCustomDomain(String hostname) {
        if (hostname == null || hostname.isBlank()) {
            return Optional.empty();
        }
        String wanted = hostname.toLowerCase(Locale.ROOT);
        return allDomains().stream()
                .filter(d -> wanted.equalsIgnoreCase(d.getDomain()) && d.getCertificateArn() != null)
                .findFirst();
    }

    public Optional<UserPoolDomain> findCustomDomainForPool(String poolId) {
        return allDomains().stream()
                .filter(d -> poolId.equals(d.getUserPoolId()) && d.getCertificateArn() != null)
                .findFirst();
    }

    private List<UserPoolDomain> allDomains() {
        return domainStore instanceof AccountAwareStorageBackend<UserPoolDomain> aware
                ? aware.scanAllAccounts()
                : domainStore.scan(key -> true);
    }
```

Import `io.github.hectorvent.floci.core.storage.AccountAwareStorageBackend`. The `instanceof` fallback
is what lets `CognitoServiceTest` keep its `InMemoryStorage` stores (line 52).

Replace `issueClientCredentialsToken` (2419) with the pair:

```java
    public Map<String, Object> issueClientCredentialsToken(String clientId, String clientSecret, String scope) {
        return issueClientCredentialsToken(clientId, clientSecret, scope, null);
    }

    /**
     * @param requiredPoolId when the request came in on a custom domain, the pool that owns that
     *                       domain; a client from another pool is "not found" there, as on AWS.
     */
    public Map<String, Object> issueClientCredentialsToken(String clientId, String clientSecret, String scope,
                                                           String requiredPoolId) {
        UserPoolClient client = clientStore.get(clientId)
                .filter(c -> requiredPoolId == null || requiredPoolId.equals(c.getUserPoolId()))
                .orElseThrow(() -> new AwsException("ResourceNotFoundException", "Client not found", 400));
        UserPool pool = describeUserPool(client.getUserPoolId());
        ... rest of the existing body unchanged ...
    }
```

Replace `getTokenEndpoint`/`getUserInfoEndpoint` (2450-2456):

```java
    public String getTokenEndpoint(String poolId) {
        return findCustomDomainForPool(poolId)
                .map(d -> "https://" + d.getDomain() + "/oauth2/token")
                .orElse(baseUrl + "/cognito-idp/oauth2/token");
    }

    public String getUserInfoEndpoint(String poolId) {
        return findCustomDomainForPool(poolId)
                .map(d -> "https://" + d.getDomain() + "/oauth2/userInfo")
                .orElse(baseUrl + "/cognito-idp/oauth2/userInfo");
    }
```

`https` is unconditional because a Cognito custom domain exists only with an ACM certificate and is HTTPS-only on AWS; a Floci without TLS enabled cannot serve it either way, and PRs 6 and 9 make it work. Import `java.util.Locale` and `java.util.Optional` if missing. Update `CognitoWellKnownController:62-63`:

```java
        String tokenEndpoint = cognitoService.getTokenEndpoint(pool.getId());
        String userInfoEndpoint = cognitoService.getUserInfoEndpoint(pool.getId());
```

- [x] **Step 4: Run**

Run: `./mvnw test -Dtest='CognitoServiceTest,CognitoOAuthTokenIntegrationTest'`
Expected: PASS (the well-known assertion at `CognitoOAuthTokenIntegrationTest:479` still sees the `baseUrl` form because that pool has no custom domain).

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/cognito/CognitoService.java src/main/java/io/github/hectorvent/floci/services/cognito/CognitoWellKnownController.java src/test/java/io/github/hectorvent/floci/services/cognito/CognitoServiceTest.java
git commit -m "feat(cognito): custom domain lookups and pool-scoped client credentials"
```

### Task 2: The filter and the controller check

**Files:**
- Create: `SRC/services/cognito/CognitoCustomDomainFilter.java`
- Modify: `SRC/services/cognito/CognitoOAuthController.java`
- Create: `TEST/services/cognito/CognitoCustomDomainRoutingIntegrationTest.java`

- [x] **Step 1: Write the failing integration test**

```java
package io.github.hectorvent.floci.services.cognito;

import com.fasterxml.jackson.databind.JsonNode;
import io.github.hectorvent.floci.testing.RestAssuredJsonUtils;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static io.github.hectorvent.floci.services.cognito.CognitoRestAssuredUtils.cognitoJson;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.startsWith;

/**
 * A Cognito custom domain on AWS serves https://&lt;domain&gt;/oauth2/token. Floci resolves the
 * request Host against the domain store and routes to the same handler as /cognito-idp/oauth2/token.
 */
@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CognitoCustomDomainRoutingIntegrationTest {

    private static final String DOMAIN = "auth-" + System.nanoTime() + ".teos.localhost.floci.io";

    private static String poolA;
    private static String poolB;
    private static String clientA;
    private static String secretA;
    private static String clientB;
    private static String secretB;

    @BeforeAll
    static void configureRestAssured() {
        RestAssuredJsonUtils.configureAwsContentTypes();
    }

    @Test
    @Order(1)
    void setUpTwoPoolsAndOneCustomDomain() throws Exception {
        poolA = cognitoJson("CreateUserPool", "{\"PoolName\": \"RoutingPoolA\"}").path("UserPool").path("Id").asText();
        poolB = cognitoJson("CreateUserPool", "{\"PoolName\": \"RoutingPoolB\"}").path("UserPool").path("Id").asText();

        JsonNode a = cognitoJson("CreateUserPoolClient", confidentialClient(poolA)).path("UserPoolClient");
        clientA = a.path("ClientId").asText();
        secretA = a.path("ClientSecret").asText();
        JsonNode b = cognitoJson("CreateUserPoolClient", confidentialClient(poolB)).path("UserPoolClient");
        clientB = b.path("ClientId").asText();
        secretB = b.path("ClientSecret").asText();

        cognitoJson("CreateUserPoolDomain", """
                {
                  "Domain": "%s",
                  "UserPoolId": "%s",
                  "CustomDomainConfig": {"CertificateArn": "arn:aws:acm:us-east-1:000000000000:certificate/routing"}
                }
                """.formatted(DOMAIN, poolA));
    }

    @Test
    @Order(2)
    void tokenRequestOnTheCustomDomainReachesTheTokenHandler() {
        given()
                .header("Host", DOMAIN)
                .header("Authorization", basic(clientA, secretA))
                .formParam("grant_type", "client_credentials")
        .when()
                .post("/oauth2/token")
        .then()
                .statusCode(200)
                .body("token_type", equalTo("Bearer"));
    }

    @Test
    @Order(3)
    void clientOfAnotherPoolIsRefusedOnThisDomain() {
        given()
                .header("Host", DOMAIN)
                .header("Authorization", basic(clientB, secretB))
                .formParam("grant_type", "client_credentials")
        .when()
                .post("/oauth2/token")
        .then()
                .statusCode(400)
                .body("error", equalTo("invalid_client"));
    }

    @Test
    @Order(4)
    void sameClientStillWorksOnTheGenericPath() {
        given()
                .header("Authorization", basic(clientB, secretB))
                .formParam("grant_type", "client_credentials")
        .when()
                .post("/cognito-idp/oauth2/token")
        .then()
                .statusCode(200);
    }

    @Test
    @Order(5)
    void emptyPostOnTheCustomDomainAnswersInvalidRequest() {
        given()
                .header("Host", DOMAIN)
                .contentType("application/x-www-form-urlencoded")
        .when()
                .post("/oauth2/token")
        .then()
                .statusCode(400)
                .body("error", equalTo("invalid_request"));
    }

    @Test
    @Order(6)
    void unknownHostIsLeftUntouched() {
        given()
                .header("Host", "nobody-" + System.nanoTime() + ".localhost.floci.io")
                .formParam("grant_type", "client_credentials")
        .when()
                .post("/oauth2/token")
        .then()
                .statusCode(404);
    }

    @Test
    @Order(7)
    void userInfoPathIsRewrittenToo() {
        given()
                .header("Host", DOMAIN)
        .when()
                .get("/oauth2/userInfo")
        .then()
                .statusCode(401)
                .header("WWW-Authenticate", startsWith("Bearer"));
    }

    @Test
    @Order(8)
    void openIdConfigurationAdvertisesTheCustomDomain() {
        given()
        .when()
                .get("/" + poolA + "/.well-known/openid-configuration")
        .then()
                .statusCode(200)
                .body("token_endpoint", equalTo("https://" + DOMAIN + "/oauth2/token"))
                .body("userinfo_endpoint", equalTo("https://" + DOMAIN + "/oauth2/userInfo"));

        given()
        .when()
                .get("/" + poolB + "/.well-known/openid-configuration")
        .then()
                .statusCode(200)
                .body("token_endpoint", equalTo("http://localhost:4566/cognito-idp/oauth2/token"));
    }

    @Test
    @Order(9)
    void callerSuppliedPoolHeaderIsIgnored() {
        given()
                .header(CognitoCustomDomainFilter.POOL_HEADER, poolA)
                .header("Authorization", basic(clientB, secretB))
                .formParam("grant_type", "client_credentials")
        .when()
                .post("/cognito-idp/oauth2/token")
        .then()
                .statusCode(200);
    }

    private static String confidentialClient(String poolId) {
        return """
                {
                  "UserPoolId": "%s",
                  "ClientName": "routing-client",
                  "GenerateSecret": true,
                  "AllowedOAuthFlowsUserPoolClient": true,
                  "AllowedOAuthFlows": ["client_credentials"]
                }
                """.formatted(poolId);
    }

    private static String basic(String clientId, String secret) {
        return "Basic " + Base64.getEncoder().encodeToString((clientId + ":" + secret).getBytes(StandardCharsets.UTF_8));
    }
}
```

`Order(7)` asserts the header `CognitoUserInfoController.bearerError` sets; if its exact name differs, read lines 61-70 of that controller and match. `Order(8)`'s `http://localhost:4566` is the test-profile `floci.base-url`; if `CognitoOAuthTokenIntegrationTest:238` asserts a different issuer prefix, use that.

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=CognitoCustomDomainRoutingIntegrationTest`
Expected: `Order(2)` fails with 404 (no resource at `/oauth2/token`), `Order(3)` fails likewise.

- [x] **Step 3: The filter**

```java
package io.github.hectorvent.floci.services.cognito;

import io.github.hectorvent.floci.services.cognito.model.UserPoolDomain;
import jakarta.annotation.Priority;
import jakarta.inject.Inject;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.PreMatching;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.UriBuilder;
import jakarta.ws.rs.ext.Provider;
import org.jboss.logging.Logger;

import java.net.URI;
import java.util.Optional;

/**
 * Routes Cognito custom-domain requests by Host. On AWS a custom domain serves
 * {@code https://<domain>/oauth2/token}; Floci maps that onto {@code /cognito-idp/oauth2/token}
 * and lets the controller pin the pool the domain belongs to.
 */
@Provider
@PreMatching
@Priority(12) // after ApiGatewayCustomDomainFilter (10), before CloudFront (15)
public class CognitoCustomDomainFilter implements ContainerRequestFilter {

    private static final Logger LOG = Logger.getLogger(CognitoCustomDomainFilter.class);
    private static final String OAUTH_PREFIX = "/oauth2/";
    private static final String TARGET_PREFIX = "/cognito-idp/oauth2/";

    /**
     * The pool the Host resolved to, handed to the controller on the same request. Resolving
     * twice (filter, then controller) would fail open if the domain vanished in between: the
     * controller would see no pool and accept any client. Stripped from every incoming request
     * first so a caller cannot set it.
     */
    static final String POOL_HEADER = "X-Floci-Cognito-Pool";

    private final CognitoService cognitoService;

    @Inject
    public CognitoCustomDomainFilter(CognitoService cognitoService) {
        this.cognitoService = cognitoService;
    }

    @Override
    public void filter(ContainerRequestContext requestContext) {
        requestContext.getHeaders().remove(POOL_HEADER);
        URI originalUri = requestContext.getUriInfo().getRequestUri();
        String path = originalUri.getRawPath();
        if (path == null || !path.startsWith(OAUTH_PREFIX)) {
            return;
        }
        Optional<UserPoolDomain> domain = resolve(requestContext.getHeaderString(HttpHeaders.HOST));
        if (domain.isEmpty()) {
            return;
        }
        URI newUri = UriBuilder.fromUri(originalUri)
                .replacePath(TARGET_PREFIX + path.substring(OAUTH_PREFIX.length()))
                .build();
        LOG.debugv("Cognito custom domain routing: {0}{1} -> {2}", domain.get().getDomain(), path, newUri.getPath());
        requestContext.getHeaders().putSingle(POOL_HEADER, domain.get().getUserPoolId());
        requestContext.setRequestUri(newUri);
    }

    private Optional<UserPoolDomain> resolve(String hostHeader) {
        if (hostHeader == null) {
            return Optional.empty();
        }
        return cognitoService.findCustomDomain(stripPort(hostHeader));
    }

    private static String stripPort(String host) {
        int colon = host.lastIndexOf(':');
        if (colon > 0 && host.substring(colon + 1).chars().allMatch(Character::isDigit)) {
            return host.substring(0, colon);
        }
        return host;
    }
}
```

- [x] **Step 4: The controller pins the pool**

`CognitoOAuthController.token` (38-45) becomes:

```java
    @POST
    @Path("/cognito-idp/oauth2/token")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response token(@HeaderParam("Authorization") String authorization,
                          @HeaderParam(CognitoCustomDomainFilter.POOL_HEADER) String requiredPoolId,
                          MultivaluedMap<String, String> formParams) {
```

(`requiredPoolId` is `null` on the generic path: the filter strips the header from every request and
only sets it after a successful Host match, so the value is the filter's, never the caller's.) And
line 84:

```java
            Map<String, Object> result = cognitoService.issueClientCredentialsToken(clientId, clientSecret, scope, requiredPoolId);
```

No new imports: `@HeaderParam` is already there. The `ResourceNotFoundException` branch at line 91 already maps to `invalid_client`, which is the AWS answer for a client that does not belong to the domain's pool.

`userInfo` needs no pool pin: the access token's `iss` claim carries the pool and `CognitoUserInfoController` already resolves it from there.

- [x] **Step 5: Run**

Run: `./mvnw test -Dtest='CognitoCustomDomainRoutingIntegrationTest,CognitoOAuthTokenIntegrationTest,CognitoUserInfoIntegrationTest,ApiGatewayCustomDomainIntegrationTest'`
Expected: PASS. The API Gateway test is included because both filters read `Host`; they must not interfere (the API Gateway filter only acts on domains in its own store, this one only on `/oauth2/*`).

- [x] **Step 6: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/cognito/CognitoCustomDomainFilter.java src/main/java/io/github/hectorvent/floci/services/cognito/CognitoOAuthController.java src/test/java/io/github/hectorvent/floci/services/cognito/CognitoCustomDomainRoutingIntegrationTest.java
git commit -m "feat(cognito): route /oauth2 requests on a custom domain by Host"
```

### Task 3: Docs and PR

- [x] **Step 1: Docs**

In `docs/services/cognito.md`, in the domains or OAuth section, add:

````markdown
### Custom domains

A user pool domain created with `CustomDomainConfig` answers the hosted-UI paths on that host, as
on AWS:

```
POST https://auth.example.localhost.floci.io/oauth2/token
GET  https://auth.example.localhost.floci.io/oauth2/userInfo
```

Requests are matched on the `Host` header, so the name must resolve to Floci (any
`*.localhost.floci.io` does) and, for `https`, TLS must be enabled. A `client_id` from a different
user pool is refused with `invalid_client`. The pool's `openid-configuration` advertises the
custom-domain URLs when one exists. Prefix domains (`<prefix>.auth.<region>.amazoncognito.com`)
are stored but not routed: that hostname never reaches Floci.
````

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/cognito.md
git commit -m "docs(cognito): custom domain routing"
```

```
CDK deploys Cognito with a custom domain and clients call https://<domain>/oauth2/token, the URL
AWS serves. Floci stored the domain but only answered /cognito-idp/oauth2/token on its own host.

- CognitoCustomDomainFilter (@PreMatching, priority 12, modeled on ApiGatewayCustomDomainFilter)
  resolves Host against the domain store (custom domains only: keyed by FQDN, certificateArn set)
  and rewrites /oauth2/* onto /cognito-idp/oauth2/*.
- The filter hands the resolved pool to CognitoOAuthController in a request header it strips
  from every incoming request first (X-Floci-Cognito-Pool), so the controller pins exactly the
  pool the filter matched: no second lookup, no fail-open window if the domain is deleted
  mid-request, no caller influence. A client from another pool is "not found" and answered
  with invalid_client, as on AWS. Without a custom-domain Host nothing changes.
- Lookups scan all accounts (AccountAwareStorageBackend.scanAllAccounts), since an OAuth call
  carries no SigV4 account.
- openid-configuration advertises https://<domain>/oauth2/... for pools with a custom domain.
- No /oauth2/authorize, /login or prefix-domain support: Floci has no hosted UI and
  <prefix>.auth.<region>.amazoncognito.com cannot reach it.

Works over plain HTTP today; with the TLS PRs the same names are served over https.
```

---

## Self-review

- Spec coverage. Filter on Host + rewrite of both paths (Task 2); other-pool `client_id` refused with `invalid_client` (Task 1 service, Task 2 controller, `Order(3)`); `openid-configuration` advertises `https://<domain>/oauth2/...` (Task 1, `Order(8)`); tests for reach, refusal, unknown host untouched (`Order(6)` gets 404, not a rewrite), empty POST still 400 `invalid_request` (`Order(5)`).
- Placeholders: the `issueClientCredentialsToken` snippet elides "rest of the existing body unchanged", which is lines 2423-2432 of the current file and is deliberately not restated.
- Type consistency: `findCustomDomain(String)`/`findCustomDomainForPool(String)` return `Optional<UserPoolDomain>`; `issueClientCredentialsToken(String, String, String, String)`; `getTokenEndpoint(String)`; `CognitoCustomDomainFilter.POOL_HEADER` is package-private and read by the controller and the integration test in the same package.
- Adversarial-review fixes folded in: the controller no longer re-resolves Host (fail-open race); `findCustomDomain` uses `scanAllAccounts()` rather than `domainStore.get` (per-account key prefix would miss domains created under a non-default account); `Order(9)` pins that the pool header cannot be supplied by the caller.
- Not in this PR: TLS itself, ensureHost (PR 9), certificate issuance (PR 5).

## Outcome (2026-09-05)

Shipped as #3095. Deviations: pool and account travel in request properties (`CognitoCustomDomainFilter.POOL_PROPERTY`, `AccountContextFilter.PINNED_ACCOUNT_PROPERTY`), no `POOL_HEADER`; userInfo also pins the pool; `S3VirtualHostFilter` skips Cognito-routed requests; domain names are unique across accounts under `domainLock` and an ambiguous legacy name is not routed; HTTP/2 authority fallback. Tests split into `CognitoCustomDomainRoutingIntegrationTest`, `CognitoCustomDomainOAuthContractIntegrationTest` and `CognitoCustomDomainFixtures`. Integration tests must request a real ACM certificate since #3035.
