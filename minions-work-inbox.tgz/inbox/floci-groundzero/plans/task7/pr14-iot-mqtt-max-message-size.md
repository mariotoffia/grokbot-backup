# PR 14: `fix(iot): accept MQTT packets up to the AWS 128 KB payload limit` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A device publishing a payload AWS IoT accepts (up to 128 KB) gets it delivered by Floci on every transport (1883, 8883 and `/mqtt`), and a payload above that limit gets the AWS reaction (the client is disconnected) instead of an accidental cut-off at 8 KB.

**Why:** found while writing PR 13. `IotMqttBrokerService.startIfEnabled` builds `MqttServerOptions` with host and port only, so vertx-mqtt's `DEFAULT_MAX_MESSAGE_SIZE` (8092 bytes, `MqttServerOptions.java:44`) applies to every MQTT packet the broker decodes. Any PUBLISH with more than about 8 KB of payload is rejected by the decoder and the connection is closed, on TCP, TLS and WebSocket alike. AWS IoT Core's limit is 128 KB of payload per message ("Maximum message size", AWS IoT Core message broker limits); a larger publish is dropped and the client disconnected. The PR 13 burst test uses 4 KB payloads for exactly this reason.

**Architecture:** set `setMaxMessageSize(MAX_PACKET_SIZE)` on both listeners in
`IotMqttBrokerService`, and check the PUBLISH payload length in their shared
handler before PUBACK, rules or subscriber delivery. These are different
limits. The decoder allowance includes headers (`128 * 1024 + 4096`); the
payload limit is exactly `128 * 1024`. Raising only the decoder allowance
would also admit a 128 KiB plus one byte payload and fail the AWS boundary
test. Check header constraints separately rather than treating 4096 bytes as
an AWS header limit. The WebSocket bridge's 256 KB frame/message allowance is
already above this packet allowance, so it needs no separate payload check.

**Branch:** `fix/iot-mqtt-max-message-size` from `upstream/main` at c4027bbf5 or later (#3150 merged 2026-09-09; its tests are the transport coverage this PR extends). Independent of PR 11 and PR 12.

Not in scope: the IoT Data HTTP `Publish` payload limit (also 128 KB on AWS) is a separate check in `IotDataController`; verify it in analysis before touching it.

---

## File structure

`SRC` = `src/main/java/io/github/hectorvent/floci`, `TEST` = `src/test/java/io/github/hectorvent/floci`.

- Modify: `SRC/services/iot/IotMqttBrokerService.java` (packet allowance on both listeners and the shared payload-length guard)
- Modify: `TEST/services/iot/IotMqttEnabledIntegrationTest.java` (128 KB over TCP delivered, 128 KB + 1 disconnects)
- Modify: `TEST/services/iot/IotMqttWebSocketIntegrationTest.java` (128 KB over `wss://` delivered)
- Modify: `TEST/services/iot/IotMqttTlsIntegrationTest.java` (128 KB over `ssl://` delivered)
- Modify: `docs/services/iot.md` (one sentence in the broker section: payloads up to 128 KB as on AWS, larger publishes disconnect the client)

No config, no `application.yml`, no `pom.xml` change.

---

### Task 1: The failing tests

- [ ] **Step 1:** In `IotMqttEnabledIntegrationTest`, `publishOf128KbIsDelivered` (subscriber gets the exact bytes, QoS 1) and `publishAbove128KbDisconnectsTheClientAsOnAws` (Paho `connectionLost` fires within 10 s; wrap the publish in a `try` that logs the `MqttException` Paho may throw while waiting for PUBACK, as the PR 13 QoS 2 test does).
- [ ] **Step 2:** In `IotMqttWebSocketIntegrationTest` and `IotMqttTlsIntegrationTest`, test both exact-limit delivery and limit-plus-one rejection over `wss://` and `ssl://`. Assert oversized payloads reach neither subscribers nor a rule target.
- [ ] **Step 3:** Run: `./mvnw test -Dtest='IotMqttEnabledIntegrationTest,IotMqttWebSocketIntegrationTest,IotMqttTlsIntegrationTest'`. Expected: the three "delivered" tests FAIL (the client is disconnected at 8 KB, no publish arrives); the "above" test passes for the wrong reason (8 KB already disconnects). That is the point: after Task 2 the "above" test only passes if the cap is exactly where AWS puts it.
- [ ] **Step 4:** Commit `test(iot): 128 KB MQTT payloads on every transport, failing`.

### Task 2: The packet allowance and payload limit

- [ ] **Step 1:** Define separate payload and packet limits in `IotMqttBrokerService`. Add `.setMaxMessageSize(MAX_PACKET_SIZE)` to both builders. In the shared PUBLISH handler, close an over-limit client's connection before acknowledgement, rule evaluation or fan-out. Keep the exact-limit payload valid.
- [ ] **Step 2:** Run the three classes again. Expected: PASS. Then `IotMqttWebSocketContractIntegrationTest`, `IotMqttWebSocketFramingIntegrationTest` (its `frameAboveTheTransportLimitClosesTheSession` sends 300 KB, still above both caps) and `IotIntegrationTest`: PASS, no count change.
- [ ] **Step 3:** Commit `fix(iot): accept MQTT packets up to the AWS 128 KB payload limit`.

### Task 3: Docs and PR

- [ ] **Step 1:** One sentence in the "MQTT Broker" scope list of `docs/services/iot.md`. `make docs-check`.
- [ ] **Step 2:** PR body in the #3003 shape: what was wrong (8 KB cut-off on every transport), what AWS does (128 KB, disconnect above), a table with the three transports and the over-limit case, the files, the tests. No TEOS mention.

---

## Self-review

- Spec coverage: 128 KB delivered on 1883, 8883 and `/mqtt`; above 128 KB disconnects; docs say so.
- Wire behaviour: no protocol change, no new endpoint, no config.
- Placeholders: none. `setMaxMessageSize(int)` is on `MqttServerOptions` 4.5.30; the receive-buffer constraint is quoted with its line.
