# PR 4: `feat(iot): real device certificates` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** `CreateKeysAndCertificate` returns a real X.509 client certificate issued by Floci's local CA, a matching key pair, and the AWS-shaped `certificateId` (lowercase SHA-256 hex of the DER), so a device can present it on the mTLS listener that PR 11 adds.

**Architecture:** `IotService.createCertificate` (lines 276 to 289) stops fabricating PEM strings and asks `FlociCertificateAuthority.issueClientCertificate`. Everything else (store key, ARN, status, `DescribeCertificate`) is untouched. `CreateCertificateFromCsr` keeps its fake output; TEOS never calls it and signing an arbitrary CSR is YAGNI.

**Tech Stack:** `FlociCertificateAuthority` (PR 3), BouncyCastle, RestAssured.

**Branch:** `feat/iot-real-device-certs` from `upstream/main` after PR 3 merges. Depends on PR 3.

---

## File structure

- Modify: `SRC/services/iot/IotService.java` (both constructors 80-158, `createCertificate` 276-289)
- Modify: `SRC/config/FlociCertificateAuthority.java` (from PR 3: one new method `signClientCsr`)
- Modify: `TEST/services/iot/IotIntegrationTest.java:376-394` (strengthen assertions in the existing round-trip test)
- Create: `TEST/services/iot/IotDeviceCertificateIntegrationTest.java`

---

### Task 1: Failing integration test

**Files:**
- Create: `TEST/services/iot/IotDeviceCertificateIntegrationTest.java`

- [x] **Step 1: Write the test**

```java
package io.github.hectorvent.floci.services.iot;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@QuarkusTest
class IotDeviceCertificateIntegrationTest {

    @Test
    void createKeysAndCertificateIssuesARealClientCertificate() throws Exception {
        JsonPath body = given()
            .contentType("application/json")
            .queryParam("setAsActive", true)
            .body("{}")
        .when()
            .post("/keys-and-certificate")
        .then()
            .statusCode(200)
            .extract().jsonPath();

        X509Certificate cert = parse(body.getString("certificatePem"));
        X509Certificate ca = parse(given().when().get("/_floci/ca.pem").then().statusCode(200).extract().asString());

        cert.verify(ca.getPublicKey());
        assertEquals(ca.getSubjectX500Principal(), cert.getIssuerX500Principal());
        assertEquals(List.of("1.3.6.1.5.5.7.3.2"), cert.getExtendedKeyUsage(), "clientAuth");
        assertEquals(-1, cert.getBasicConstraints());

        String expectedId = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(cert.getEncoded()));
        assertEquals(expectedId, body.getString("certificateId"), "AWS certificateId is sha256(DER), lowercase hex");
        assertTrue(body.getString("certificateArn").endsWith(":cert/" + expectedId));

        PrivateKey privateKey = parsePkcs8(body.getString("keyPair.PrivateKey"));
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(privateKey);
        signer.update("floci".getBytes(StandardCharsets.UTF_8));
        byte[] sig = signer.sign();
        Signature verifier = Signature.getInstance("SHA256withRSA");
        verifier.initVerify(cert.getPublicKey());
        verifier.update("floci".getBytes(StandardCharsets.UTF_8));
        assertTrue(verifier.verify(sig), "private key must match the certificate's public key");

        String publicKeyPem = body.getString("keyPair.PublicKey");
        assertEquals(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()),
                publicKeyPem.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "")
                        .replaceAll("\\s", ""));
    }

    @Test
    void createCertificateFromCsrSignsTheCsrKeyAndReturnsNoPrivateKey() throws Exception {
        java.security.KeyPairGenerator kpg = java.security.KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        java.security.KeyPair deviceKey = kpg.generateKeyPair();
        org.bouncycastle.pkcs.PKCS10CertificationRequest csr =
                new org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder(
                        new org.bouncycastle.asn1.x500.X500Name("CN=thing-0001,O=TEOS"), deviceKey.getPublic())
                .build(new org.bouncycastle.operator.jcajce.JcaContentSignerBuilder("SHA256withRSA").build(deviceKey.getPrivate()));
        java.io.StringWriter pem = new java.io.StringWriter();
        try (org.bouncycastle.openssl.jcajce.JcaPEMWriter w = new org.bouncycastle.openssl.jcajce.JcaPEMWriter(pem)) {
            w.writeObject(csr);
        }

        JsonPath body = given()
            .contentType("application/json")
            .queryParam("setAsActive", true)
            .body(java.util.Map.of("certificateSigningRequest", pem.toString()))
        .when()
            .post("/certificates")
        .then()
            .statusCode(200)
            .extract().jsonPath();

        X509Certificate cert = parse(body.getString("certificatePem"));
        X509Certificate ca = parse(given().when().get("/_floci/ca.pem").then().statusCode(200).extract().asString());

        cert.verify(ca.getPublicKey());
        assertEquals(deviceKey.getPublic(), cert.getPublicKey(), "the CSR's key is the certificate's key");
        assertEquals("CN=thing-0001,O=TEOS", cert.getSubjectX500Principal().getName());
        assertEquals(List.of("1.3.6.1.5.5.7.3.2"), cert.getExtendedKeyUsage(), "clientAuth");
        String expectedId = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(cert.getEncoded()));
        assertEquals(expectedId, body.getString("certificateId"));
        assertNull(body.get("keyPair"), "AWS never returns a private key for a CSR: the device holds it");
    }

    @Test
    void createCertificateFromCsrRejectsGarbage() {
        given()
            .contentType("application/json")
            .body(java.util.Map.of("certificateSigningRequest", "-----BEGIN CERTIFICATE REQUEST-----\nbm90IGEgY3Ny\n-----END CERTIFICATE REQUEST-----"))
        .when()
            .post("/certificates")
        .then()
            .statusCode(400)
            .body("__type", org.hamcrest.Matchers.containsString("InvalidRequestException"));
    }

    @Test
    void describeCertificateReturnsTheSamePem() {
        JsonPath created = given()
            .contentType("application/json")
            .queryParam("setAsActive", false)
            .body("{}")
        .when()
            .post("/keys-and-certificate")
        .then()
            .statusCode(200)
            .extract().jsonPath();

        given()
        .when()
            .get("/certificates/" + created.getString("certificateId"))
        .then()
            .statusCode(200)
            .body("certificateDescription.certificatePem", org.hamcrest.Matchers.equalTo(created.getString("certificatePem")))
            .body("certificateDescription.status", org.hamcrest.Matchers.equalTo("INACTIVE"));
    }

    private static X509Certificate parse(String pem) throws Exception {
        return (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(pem.getBytes(StandardCharsets.US_ASCII)));
    }

    private static PrivateKey parsePkcs8(String pem) throws Exception {
        String base64 = pem.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64)));
    }
}
```

Check the `DescribeCertificate` JSON shape before relying on `certificateDescription.certificatePem`: `grep -n "certificateDescription" src/main/java/io/github/hectorvent/floci/services/iot/IotController.java`. If the controller nests differently, adjust the two `body(...)` paths to the real shape; the assertion is "same PEM back", not the path.

Also check how the IoT REST controller renders an `AwsException` (`grep -n "__type\|\"message\"" src/main/java/io/github/hectorvent/floci/core/common/AwsExceptionMapper.java`). AWS IoT's REST JSON errors carry `message` and no `__type`; if Floci's mapper emits only `message`, change the garbage test's body assertion to `.body("message", containsString("certificateSigningRequest"))`. The assertion that matters is the 400.

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=IotDeviceCertificateIntegrationTest`
Expected: the two `create*` tests and `describeCertificateReturnsTheSamePem` FAIL in `parse` with `CertificateException` (the fake PEM body is a UUID string); `createCertificateFromCsrRejectsGarbage` FAILS with `expected 400 but was 200`.

### Task 2: Issue from the CA

**Files:**
- Modify: `SRC/config/FlociCertificateAuthority.java`
- Modify: `SRC/services/iot/IotService.java`

- [x] **Step 0: Teach the CA to sign a CSR**

Add to `FlociCertificateAuthority` (PR 3), after `issueClientCertificate`:

```java
    /**
     * Signs an external PKCS#10 request as a {@code clientAuth} leaf. The subject DN comes from
     * the CSR; requested extensions are ignored (AWS IoT ignores them too). Throws
     * {@link IllegalArgumentException} when the PEM is not a CSR or its self-signature fails.
     */
    public X509Certificate signClientCsr(String csrPem) {
        try (PEMParser parser = new PEMParser(new StringReader(csrPem))) {
            Object parsed = parser.readObject();
            if (!(parsed instanceof PKCS10CertificationRequest csr)) {
                throw new IllegalArgumentException("certificateSigningRequest is not a PEM CERTIFICATE REQUEST");
            }
            PublicKey subjectKey = new JcaPKCS10CertificationRequest(csr).getPublicKey();
            if (!csr.isSignatureValid(new JcaContentVerifierProviderBuilder().build(subjectKey))) {
                throw new IllegalArgumentException("certificateSigningRequest signature does not verify");
            }
            X500Name issuerDn = X500Name.getInstance(certificate.getSubjectX500Principal().getEncoded());
            return generator.signCertificate(csr.getSubject(), subjectKey, issuerDn, key, List.of(), false,
                    CertificateGenerator.LeafUsage.CLIENT, 365);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException("certificateSigningRequest could not be parsed: " + e.getMessage(), e);
        }
    }
```

Imports: `java.io.StringReader`, `java.security.PublicKey`, `org.bouncycastle.asn1.x500.X500Name`,
`org.bouncycastle.openssl.PEMParser`, `org.bouncycastle.operator.jcajce.JcaContentVerifierProviderBuilder`,
`org.bouncycastle.pkcs.PKCS10CertificationRequest`, `org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequest`.
All in `bcpkix-jdk18on`, already a dependency (`pom.xml` line 198). `generator.signCertificate(...)` is
the public primitive from PR 2 (`CertificateGenerator:216`); `certificate` and `key` are the CA's own
fields from PR 3.

- [x] **Step 1: Inject `FlociCertificateAuthority`**

Add `FlociCertificateAuthority certificateAuthority` as the last parameter of both constructors (the `@Inject` one at line 81 forwards it; the package-private one at line 110 stores it in `private final FlociCertificateAuthority certificateAuthority;`). Import `io.github.hectorvent.floci.config.FlociCertificateAuthority`. No test constructs `IotService` directly (verified: `grep -rn "new IotService(" src/test` is empty).

- [x] **Step 2: Replace `createCertificate`**

```java
    private IotCertificate createCertificate(boolean setAsActive, String certificateSigningRequest, String region) {
        startMqttIfEnabled();
        IotCertificate certificate = new IotCertificate();
        if (certificateSigningRequest == null) {
            issueFromLocalCa(certificate);
        } else {
            issueFromCsr(certificate, certificateSigningRequest);
        }
        certificate.setCertificateArn(regionResolver.buildArn("iot", region, "cert/" + certificate.getCertificateId()));
        certificate.setStatus(setAsActive ? "ACTIVE" : "INACTIVE");
        certificate.setCreationDate(Instant.now());
        certificateStore.put(certificateKey(region, certificate.getCertificateId()), certificate);
        return certificate;
    }

    private void issueFromLocalCa(IotCertificate certificate) {
        CertificateGenerator.GeneratedCertificate issued = certificateAuthority.issueClientCertificate("AWS IoT Certificate");
        try {
            X509Certificate x509 = new CertificateGenerator().parseCertificate(issued.certificatePem());
            fill(certificate, x509);
            certificate.setPrivateKey(issued.privateKeyPem());
        } catch (Exception e) {
            throw new AwsException("InternalFailureException", "Could not issue device certificate: " + e.getMessage(), 500);
        }
    }

    /** The device keeps its key: only the certificate and its public key are stored. */
    private void issueFromCsr(IotCertificate certificate, String csrPem) {
        X509Certificate x509;
        try {
            x509 = certificateAuthority.signClientCsr(csrPem);
        } catch (IllegalArgumentException e) {
            throw new AwsException("InvalidRequestException", e.getMessage(), 400);
        }
        try {
            fill(certificate, x509);
        } catch (Exception e) {
            throw new AwsException("InternalFailureException", "Could not encode device certificate: " + e.getMessage(), 500);
        }
    }

    /** AWS IoT's certificateId is the lowercase hex SHA-256 of the certificate's DER encoding. */
    private static void fill(IotCertificate certificate, X509Certificate x509) throws Exception {
        CertificateGenerator pem = new CertificateGenerator();
        certificate.setCertificateId(HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(x509.getEncoded())));
        certificate.setCertificatePem(pem.toPem(x509));
        certificate.setPublicKey(pem.toPem(x509.getPublicKey()));
    }
```

Imports to add: `io.github.hectorvent.floci.services.acm.CertificateGenerator`, `java.security.MessageDigest`, `java.security.cert.X509Certificate`, `java.util.HexFormat`. `java.util.UUID` may now be unused in this file; remove it if the compiler says so.

`CertificateGenerator.toPem(Object)` (public since PR 2) accepts a `PublicKey` through BouncyCastle's `JcaPEMWriter` and emits `-----BEGIN PUBLIC KEY-----`; confirm with the new test's last assertion rather than by reading.

- [x] **Step 3: Run the new test and the existing IoT suites**

Run: `./mvnw test -Dtest='IotDeviceCertificateIntegrationTest,IotIntegrationTest,IotMvpAcceptanceIntegrationTest'`
Expected: one failure. `IotIntegrationTest.certificatesPoliciesAndAttachmentsRoundTrip` (line 566) posts
`-----BEGIN CERTIFICATE REQUEST-----\nfloci\n-----END CERTIFICATE REQUEST-----` and expects 200; it now
gets 400 because that was never a CSR. Fix the test, not the code: replace the literal with a real CSR.
Add to `IotIntegrationTest`:

```java
    private static String csrPem() throws Exception {
        java.security.KeyPairGenerator kpg = java.security.KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        java.security.KeyPair kp = kpg.generateKeyPair();
        var csr = new org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder(
                new org.bouncycastle.asn1.x500.X500Name("CN=round-trip"), kp.getPublic())
                .build(new org.bouncycastle.operator.jcajce.JcaContentSignerBuilder("SHA256withRSA").build(kp.getPrivate()));
        java.io.StringWriter out = new java.io.StringWriter();
        try (var w = new org.bouncycastle.openssl.jcajce.JcaPEMWriter(out)) {
            w.writeObject(csr);
        }
        return out.toString();
    }
```

and change line 566 to `.body(java.util.Map.of("certificateSigningRequest", csrPem()))` (the test method
already declares `throws Exception`; if not, add it). Re-run the same command. Expected: PASS.

- [x] **Step 4: Tighten the existing round-trip assertion**

In `IotIntegrationTest` line 389 change
`.body("certificatePem", containsString("BEGIN CERTIFICATE"))` to
`.body("certificateId", matchesPattern("[0-9a-f]{64}"))` followed by the same `certificatePem` line, importing `static org.hamcrest.Matchers.matchesPattern`. Run `./mvnw test -Dtest=IotIntegrationTest#certificatesPoliciesAndAttachmentsRoundTrip`. Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/FlociCertificateAuthority.java src/main/java/io/github/hectorvent/floci/services/iot/IotService.java src/test/java/io/github/hectorvent/floci/services/iot/IotDeviceCertificateIntegrationTest.java src/test/java/io/github/hectorvent/floci/services/iot/IotIntegrationTest.java
git commit -m "feat(iot): CreateKeysAndCertificate issues a real client certificate from the local CA

certificateId is sha256(DER) in lowercase hex as on AWS; the returned key pair
matches the certificate. CreateCertificateFromCsr signs the CSR's key with the same
CA and returns no private key, as on AWS."
```

### Task 3: Docs and PR

- [x] **Step 1: `docs/services/iot.md`**

Find the certificates section (`grep -n -i "certificate" docs/services/iot.md`). Add one paragraph after the first mention of `CreateKeysAndCertificate`:

```markdown
`CreateKeysAndCertificate` returns a real X.509 client certificate issued by Floci's local CA
(`GET /_floci/ca.pem`), with `certificateId` equal to the SHA-256 of its DER encoding as on AWS.
`CreateCertificateFromCsr` signs the request's public key with the same CA and, as on AWS, returns
no private key. The MQTT listener does not verify device certificates yet.
```

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/iot.md
git commit -m "docs(iot): describe the CA-issued device certificate"
```

```
CreateKeysAndCertificate returned "-----BEGIN CERTIFICATE-----\n<uuid>\n-----END CERTIFICATE-----",
which no TLS library parses, so a device could never authenticate with it.

- IotService.createCertificate asks FlociCertificateAuthority for a clientAuth leaf; the
  returned PEM parses, chains to /_floci/ca.pem, and the PrivateKey matches the certificate.
- certificateId = lowercase hex SHA-256 of the DER, as AWS documents it.
- CreateCertificateFromCsr parses the PKCS#10 (BouncyCastle), checks its self-signature,
  and issues a clientAuth leaf for the CSR's key and subject. No private key in the response.
  A non-CSR body is InvalidRequestException (400). This is what TEOS-style provisioning
  (device generates its key, cloud signs) needs and what the placeholder could never do.

Tests: IotDeviceCertificateIntegrationTest (chain, EKU, id derivation, key match, CSR key
match, no keyPair for CSR, garbage CSR 400, describe round trip); IotIntegrationTest asserts
the 64-hex id.
Depends on the local CA PR.
```

---

## Self-review

- Spec coverage: real leaf signed by CA with `clientAuth` (Task 2), `certificateId = sha256 hex of DER` (Task 2), tests parse PEM, pubkey matches privkey, verifies against `ca.pem`, id == sha256(DER) (Task 1). Docs (Task 3). Deviation from the spec's "CreateCertificateFromCsr stays fake": the adversarial review found the placeholder path is the one a real device enrollment uses, so it is signed for real (about 30 lines, Task 2 Step 0); the spec line is superseded.
- No placeholders. The one conditional instruction (check `certificateDescription` path) tells the engineer exactly what to grep and what the assertion means.
- Type consistency: `FlociCertificateAuthority.issueClientCertificate(String)` as defined in PR 3, `signClientCsr(String)` added here; `CertificateGenerator.signCertificate(X500Name, PublicKey, X500Name, PrivateKey, List<String>, boolean, LeafUsage, int)` and public `toPem(Object)` from PR 2.
