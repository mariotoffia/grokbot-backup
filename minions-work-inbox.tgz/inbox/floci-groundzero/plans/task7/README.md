# Task 7 implementation plans: certificates, trust and TLS for custom domains

Spec: [SPEC.md](SPEC.md) (the Task 7 text, moved out of `TEOS_GROUNDZERO_TASKS.md`) and
`.vscode/TEOS_GROUNDZERO_ANALYSIS.md` 10.2, 10.3, 10.5. One plan per pull request. Each plan
produces working, tested software on its own and is reviewable in one sitting.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development
> (recommended) or superpowers:executing-plans to implement each plan task-by-task. Steps use
> checkbox (`- [ ]`) syntax for tracking. Ponytail mode applies: the plan already picked the
> laziest correct rung; do not add abstractions it does not name.

## Order and dependencies

```mermaid
graph LR
  PR1[1 acm chain pem]
  PR2[2 issuer primitive] --> PR3[3 local CA]
  PR3 --> PR4[4 iot real device certs]
  PR3 --> PR5[5 acm CA-signed]
  PR3 --> PR6[6 ensureHost]
  PR3 --> PR7[7 container CA bundle]
  PR3 --> PR8[8 mqtt tls 8883]
  PR5 --> PR9[9 custom domain hooks]
  PR6 --> PR9
  PR10[10 cognito host routing]
  PR4 --> PR11[11 iot mtls]
  PR8 --> PR11
  PR3 --> PR13[13 mqtt websocket /mqtt]
  PR13 --> PR14[14 mqtt 128 KB packets]
  PR12[12 DescribeEndpoint]
```

Day one: PR 2, PR 10, PR 12 (each builds and tests alone). PR 1 is a disposable hotfix: ship it
only if PR 5 is more than a few days out, otherwise fold its assertion into PR 5. Critical path
for TEOS: 2, 3, then 5 and 6 side by side, then 9. PR 9 also needs upstream #3040
(`regionalCertificateArn` stored), merged 2026-09-05. PR 10 builds alone, but the `https://` URLs it
advertises only serve TLS once PR 9 has landed. Release coupling: PR 8 and PR 11 ship in the
same release (8 alone opens a TLS listener that accepts any client certificate); PR 11 edits
`IotMqttBrokerService` after PR 8. PR 13 needs only PR 3 (for the test's CA trust) and touches
neither `IotMqttBrokerService` nor config: it bridges `/mqtt` on 4566 onto the plaintext
listener, so wss:// rides the HTTPS certificate and the `443:4566` mapping PR 12 documents. PR 14 is
the one-option fix PR 13 found (vertx-mqtt's 8 KB packet cap on every transport); it branches after
c4027bbf5 (#3150, merged 2026-09-09) because it extends that PR's transport tests.

| Plan | Branch | Size |
| --- | --- | --- |
| [pr01-acm-chain-pem.md](pr01-acm-chain-pem.md) | `fix/acm-chain-pem` | 30 lines + test (ship or skip, see plan) |
| [pr02-certificate-generator-issuer.md](pr02-certificate-generator-issuer.md) | `refactor/certificate-generator-issuer` | 80 lines net |
| [pr03-tls-local-ca.md](pr03-tls-local-ca.md) | `feat/tls-local-ca` | 250 lines + tests |
| [pr04-iot-real-device-certs.md](pr04-iot-real-device-certs.md) | `feat/iot-real-device-certs` | 90 lines + tests (real CSR signing) |
| [pr05-acm-ca-signed.md](pr05-acm-ca-signed.md) | `feat/acm-ca-signed` | 80 lines + tests |
| [pr06-tls-ensure-host.md](pr06-tls-ensure-host.md) | `feat/tls-ensure-host` | 250 lines + tests |
| [pr07-container-ca-bundle.md](pr07-container-ca-bundle.md) | `feat/container-ca-bundle` | 150 lines + tests (one Docker-gated) |
| [pr08-iot-mqtt-tls.md](pr08-iot-mqtt-tls.md) | `feat/iot-mqtt-tls` | 150 lines + tests |
| [pr09-custom-domain-ensure-host.md](pr09-custom-domain-ensure-host.md) | `feat/custom-domain-ensure-host` | 70 lines + tests |
| [pr10-cognito-host-routing.md](pr10-cognito-host-routing.md) | `feat/cognito-host-routing` | 120 lines + tests |
| [pr11-iot-mtls.md](pr11-iot-mtls.md) | `feat/iot-mtls` | 200 lines + tests |
| [pr12-describe-endpoint.md](pr12-describe-endpoint.md) | `fix/iot-describe-endpoint-address` | 20 lines + test + docs |
| [pr13-iot-mqtt-websocket.md](pr13-iot-mqtt-websocket.md) | `feat/iot-mqtt-websocket` | 90 lines + tests, no config |
| [pr14-iot-mqtt-max-message-size.md](pr14-iot-mqtt-max-message-size.md) | `fix/iot-mqtt-max-message-size` | 5 lines + tests, no config |

## Conventions every plan assumes

- Branch from `upstream/main` (`floci-io/floci`), not from the local fork's `main`, which is
  behind: `git fetch upstream && git checkout -b <branch> upstream/main`.
- Conventional commits, no `Co-Authored-By` trailers for AI tools (AGENTS.md).
- No em-dashes in any file, docs or code comments.
- Tests: `./mvnw test -Dtest=<Class>` for one class, `-Dtest=<Class>#<method>` for one method.
  First run of the day: `./mvnw -q compile` to warm the build.
- Every PR that touches `docs/` ends with `make docs-check`.
- Constructor injection; package-private constructors for tests; never an empty `catch`.
- `TlsConfigSource` runs before CDI. Anything it needs must be a plain class.
- Repo-relative paths below are from the repo root. `src/main/java/io/github/hectorvent/floci`
  is abbreviated `SRC`, `src/test/java/io/github/hectorvent/floci` is `TEST`.

## Shared types introduced (so later plans match earlier ones)

| Type | Introduced in | Package |
| --- | --- | --- |
| `CertificateGenerator.LeafUsage { SERVER, CLIENT }` | PR 2 | `services.acm` |
| `CertificateGenerator.Issuer(X509Certificate certificate, PrivateKey key)` | PR 2 | `services.acm` |
| `CertificateGenerator.signCertificate(...)`, `generateCaCertificate(...)`, `generateIssuedCertificate(...)`, `toPem(...)` public | PR 2 | `services.acm` |
| `FlociCertificateAuthority` (plain class, `loadOrCreate(Path)`, `issueServerCertificate(...)`, `isValidLocalLeaf(...)`) + `FlociCertificateAuthorityProducer` (CDI, `tlsDir(EmulatorConfig)`) | PR 3 | `config` |
| `CertificateGenerator.toGenerated(X509Certificate, PrivateKey, String subjectDn, String issuerDn)` (private), `colonHex(BigInteger)` | PR 2 | `services.acm` |
| `FlociCertificateAuthority.signClientCsr(String csrPem): X509Certificate` | PR 4 | `config` |
| `TlsCertificateManager` (`@ApplicationScoped`, `Resettable`) | PR 6 | `config` |
| `CertificateMetadata.learnedHostnames` | PR 6 | `config` |
| `ContainerCaBundle` | PR 7 | `config` |
| `TlsCertificateManager.knownHostnames()` | PR 6 | `config` |
| `ReloadingKeyManager(X509KeyManager)`, `keyManagerOf(Vertx, KeyCertOptions)`, `reload(X509KeyManager)` (X509 key manager the broker rebuilds from the event's key store; aliases carry a generation so a reload mid-handshake keeps key and chain matched; #3142) | PR 8 | `services.iot` |
| `IotMqttBrokerService.handleEndpoint(MqttEndpoint, boolean verifyDevice)` | PR 11 | `services.iot` |
| `IotService.RegisteredDevice(accountId, region, certificate)`, `findRegisteredCertificate(X509Certificate): Optional<RegisteredDevice>` (every account partition), `isConnectAllowed(RegisteredDevice, clientId, sourceIp, domainName)` (condition context with the basic and thing policy variables; unresolved `${...}` drops the statement) | PR 11 | `services.iot` |
| `IotDeviceIdentity` (test helper: provision over REST, `sslContext(tlsDir)`, `stranger(tlsDir)`, `trustOnlySslContext(tlsDir)`), `IotServiceTestSupport` (in-memory account-aware `IotService`) | PR 11 | `TEST/services.iot` |
| `IotServiceConfig.endpointAddress(): Optional<String>` | PR 12 | `config.EmulatorConfig` |
| `MqttConfig.tlsPort()` (8883) | PR 8 | `config.EmulatorConfig` |
| `IotMqttWebSocketBridge` (`@Observes Router`, route `/mqtt`), `HttpOptionsCustomizer.MQTT_WEBSOCKET_SUBPROTOCOLS` | PR 13 | `services.iot`, `config` |
| `CognitoCustomDomainFilter` (`POOL_PROPERTY`, a request property the controllers and `S3VirtualHostFilter` read; the planned `POOL_HEADER` was dropped), `AccountContextFilter.PINNED_ACCOUNT_PROPERTY` (core), `CognitoService.findCustomDomain(String)` (all accounts, fails closed on duplicates), `findCustomDomainForPool(String)`, `issueClientCredentialsToken(clientId, secret, scope, requiredPoolId)`, `getTokenEndpoint(poolId)`, `getUserInfoEndpoint(poolId)` | PR 10 (#3095) | `services.cognito`, `core.common` |
| `CustomDomainTlsTest.tlsIsServed()` (compatibility suite, skips the class when `FLOCI_ENDPOINT` serves no TLS) | PR 9 | `compatibility-tests/sdk-test-java` |
