# PR 6: `feat(tls): serve exact hostnames as custom domains are created` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** `TlsCertificateManager.ensureHost("api.teos.localhost.floci.io")` makes Floci's HTTPS listener present a certificate covering that exact name within the same call, without a restart, without a new key, and without clients having to trust anything new.

**Architecture:** One `@ApplicationScoped` bean over the server leaf `TlsConfigSource` wrote (`{persistent-path}/tls/floci-server.*`). On a new, allow-listed hostname it reissues the leaf from `FlociCertificateAuthority` with the same key pair and the SAN appended, writes cert and metadata atomically (key file untouched), then `TlsConfigurationRegistry.getDefault().reload()` and fires `CertificateUpdatedEvent("<default>", cfg)`; Quarkus's `HttpCertificateUpdateEventListener` swaps the server's SSL options synchronously. Learned names are persisted in a new `learnedHostnames` metadata field so `TlsConfigSource` re-includes them after a restart. Nothing calls `ensureHost` yet; PR 9 wires the AWS APIs.

**Tech Stack:** Quarkus TLS registry (`io.quarkus.tls.TlsConfigurationRegistry`, `TlsConfiguration.reload()`, `CertificateUpdatedEvent`), CDI `Event`, BouncyCastle via `CertificateGenerator`, Mockito, `SSLSocket` with SNI for the integration test.

**Branch:** `feat/tls-ensure-host` from `upstream/main` after PR 3 merges. Depends on PR 3.

Verified against the jars in `~/.m2` (Quarkus 3.37.4): `TlsConfigurationRegistry.getDefault(): Optional<TlsConfiguration>`, `TlsConfiguration.reload(): boolean`, `CertificateUpdatedEvent(String name, TlsConfiguration)`, `io.quarkus.tls.runtime.config.TlsConfig.DEFAULT_NAME = "<default>"`, and `VertxHttpRecorder` registers the HTTPS server with `getHttpServerTlsConfigName(...).orElse("<default>")`, so the event name must be `"<default>"`. Both `quarkus-tls-registry` and `-spi` are on the classpath through `quarkus-vertx-http`; no pom change.

---

## File structure

- Create: `SRC/config/TlsCertificateManager.java`
- Modify: `SRC/config/CertificateMetadata.java` (add `learnedHostnames`)
- Modify: `SRC/config/TlsConfigSource.java` (`generateServerCert`: include learned names; `persistMetadata` signature)
- Create: `TEST/config/TlsCertificateManagerTest.java` (unit, Mockito)
- Create: `TEST/config/TlsEnsureHostIntegrationTest.java` (`@QuarkusTest`, real handshake)
- Modify: `TEST/config/TlsCertificateHostnameTest.java` (one test: learned names survive a boot regeneration)
- Modify: `docs/configuration/tls.md` (one section)

---

### Task 1: `CertificateMetadata.learnedHostnames`

**Files:**
- Modify: `SRC/config/CertificateMetadata.java`

- [x] **Step 1: Add the field, accessors, and equality**

After the `hostnames` field (line 31):

```java
    /**
     * Hostnames added at runtime by {@link TlsCertificateManager#ensureHost(String)} (API Gateway,
     * IoT and Cognito custom domains). Kept apart from {@link #hostnames} so a change in the
     * configured list is detected without losing what was learned.
     */
    private List<String> learnedHostnames = List.of();
```

After `setHostnames`:

```java
    public List<String> getLearnedHostnames() {
        return learnedHostnames == null ? List.of() : learnedHostnames;
    }

    public void setLearnedHostnames(List<String> learnedHostnames) {
        this.learnedHostnames = learnedHostnames == null ? List.of() : List.copyOf(learnedHostnames);
    }
```

Include `learnedHostnames` in `equals`, `hashCode` and `toString` (add `Objects.equals(learnedHostnames, that.learnedHostnames)`, add it to `Objects.hash(...)`, append `", learnedHostnames=" + learnedHostnames`). The class javadoc line 20 still names `floci-selfsigned.metadata.json`; change it to `floci-server.metadata.json`.

- [x] **Step 2: Existing metadata tests still pass**

Run: `./mvnw test -Dtest='TlsConfigSourceMetadata*Test'`
Expected: PASS (old JSON without the field deserializes to an empty list thanks to `@JsonIgnoreProperties(ignoreUnknown = true)` and the default).

- [x] **Step 3: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/CertificateMetadata.java
git commit -m "feat(tls): record runtime-learned hostnames in the certificate metadata"
```

### Task 2: `TlsCertificateManager` with unit tests

**Files:**
- Create: `TEST/config/TlsCertificateManagerTest.java`
- Create: `SRC/config/TlsCertificateManager.java`

- [x] **Step 1: Write the failing unit test**

```java
package io.github.hectorvent.floci.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.hectorvent.floci.services.acm.CertificateGenerator;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import io.quarkus.tls.CertificateUpdatedEvent;
import io.quarkus.tls.TlsConfiguration;
import io.quarkus.tls.TlsConfigurationRegistry;
import jakarta.enterprise.event.Event;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class TlsCertificateManagerTest {

    private static final List<String> CONFIGURED = List.of("localhost", "127.0.0.1", "*.localhost.floci.io", "localhost.floci.io");

    @TempDir
    Path tempDir;

    private Path tlsDir;
    private FlociCertificateAuthority ca;
    private EmulatorConfig config;
    private TlsConfigurationRegistry registry;
    private TlsConfiguration defaultTls;
    @SuppressWarnings("unchecked")
    private final Event<CertificateUpdatedEvent> events = mock(Event.class);

    @BeforeAll
    static void bouncyCastle() {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    @BeforeEach
    void serverLeafOnDisk() throws Exception {
        tlsDir = Files.createDirectories(tempDir.resolve("tls"));
        ca = FlociCertificateAuthority.loadOrCreate(tlsDir);
        var leaf = ca.issueServerCertificate("localhost", CONFIGURED, KeyAlgorithm.RSA_2048, null);
        Files.writeString(tlsDir.resolve("floci-server.crt"), leaf.certificatePem());
        Files.writeString(tlsDir.resolve("floci-server.key"), leaf.privateKeyPem());
        Files.writeString(tlsDir.resolve("floci-server.metadata.json"),
                new ObjectMapper().writeValueAsString(CertificateMetadata.create(CONFIGURED, "dev")));

        config = mock(EmulatorConfig.class, org.mockito.Mockito.RETURNS_DEEP_STUBS);
        when(config.tls().enabled()).thenReturn(true);
        when(config.tls().certPath()).thenReturn(Optional.empty());
        when(config.storage().persistentPath()).thenReturn(tempDir.toString());
        when(config.hostname()).thenReturn(Optional.of("floci"));
        when(config.baseUrl()).thenReturn("http://localhost:4566");
        when(config.dns().extraSuffixes()).thenReturn(Optional.of(List.of("teos.internal")));

        registry = mock(TlsConfigurationRegistry.class);
        defaultTls = mock(TlsConfiguration.class);
        when(registry.getDefault()).thenReturn(Optional.of(defaultTls));
        when(defaultTls.reload()).thenReturn(true);
    }

    private TlsCertificateManager manager() {
        return new TlsCertificateManager(config, ca, registry, events);
    }

    @Test
    void newHostIsAppendedWithTheSameKeyAndReloaded() throws Exception {
        byte[] keyBefore = Files.readAllBytes(tlsDir.resolve("floci-server.key"));
        X509Certificate before = read("floci-server.crt");

        manager().ensureHost("api.teos.localhost.floci.io");

        X509Certificate after = read("floci-server.crt");
        assertTrue(sans(after).contains("api.teos.localhost.floci.io"), sans(after).toString());
        assertTrue(sans(after).containsAll(CONFIGURED));
        assertEquals(before.getPublicKey(), after.getPublicKey(), "same key pair");
        assertArrayEquals(keyBefore, Files.readAllBytes(tlsDir.resolve("floci-server.key")), "key file never rewritten");
        after.verify(ca.certificate().getPublicKey());

        CertificateMetadata metadata = new ObjectMapper().readValue(
                tlsDir.resolve("floci-server.metadata.json").toFile(), CertificateMetadata.class);
        assertEquals(CONFIGURED, metadata.getHostnames(), "configured list untouched");
        assertEquals(List.of("api.teos.localhost.floci.io"), metadata.getLearnedHostnames());

        verify(defaultTls).reload();
        ArgumentCaptor<CertificateUpdatedEvent> event = ArgumentCaptor.forClass(CertificateUpdatedEvent.class);
        verify(events).fire(event.capture());
        assertEquals("<default>", event.getValue().name());
        assertEquals(defaultTls, event.getValue().tlsConfiguration());
    }

    @Test
    void knownOrWildcardCoveredHostIsANoOp() throws Exception {
        byte[] certBefore = Files.readAllBytes(tlsDir.resolve("floci-server.crt"));

        TlsCertificateManager m = manager();
        m.ensureHost("localhost");
        m.ensureHost("LOCALHOST.floci.io.");
        m.ensureHost("one-label.localhost.floci.io");

        assertArrayEquals(certBefore, Files.readAllBytes(tlsDir.resolve("floci-server.crt")));
        verify(defaultTls, never()).reload();
        verify(events, never()).fire(any());
    }

    @Test
    void secondCallForTheSameHostDoesNotReissue() throws Exception {
        TlsCertificateManager m = manager();
        m.ensureHost("api.teos.localhost.floci.io");
        byte[] certAfterFirst = Files.readAllBytes(tlsDir.resolve("floci-server.crt"));

        m.ensureHost("api.teos.localhost.floci.io");

        assertArrayEquals(certAfterFirst, Files.readAllBytes(tlsDir.resolve("floci-server.crt")));
        verify(defaultTls, times(1)).reload();
    }

    @Test
    void hostOutsideTheAllowListIsRefused() throws Exception {
        byte[] certBefore = Files.readAllBytes(tlsDir.resolve("floci-server.crt"));

        manager().ensureHost("accounts.google.com");

        assertArrayEquals(certBefore, Files.readAllBytes(tlsDir.resolve("floci-server.crt")));
        verify(defaultTls, never()).reload();
    }

    @Test
    void wildcardIsAcceptedOnlyAsAWholeLeftmostLabel() throws Exception {
        TlsCertificateManager m = manager();

        m.ensureHost("*.api.teos.localhost.floci.io");
        assertTrue(sans(read("floci-server.crt")).contains("*.api.teos.localhost.floci.io"),
                "one leading *. label is a valid SAN");
        verify(defaultTls, times(1)).reload();

        m.ensureHost("*");
        m.ensureHost("api*.teos.localhost.floci.io");
        m.ensureHost("*.*.teos.localhost.floci.io");
        m.ensureHost("teos.*.localhost.floci.io");
        verify(defaultTls, times(1)).reload();
        Set<String> starred = new TreeSet<>(sans(read("floci-server.crt")));
        starred.removeIf(n -> !n.contains("*"));
        assertEquals(Set.of("*.localhost.floci.io", "*.api.teos.localhost.floci.io"), starred,
                "malformed wildcards must not reach the certificate");
    }

    @Test
    void allowListIncludesConfiguredHostnameBaseUrlAndExtraSuffixes() throws Exception {
        TlsCertificateManager m = manager();
        m.ensureHost("api.floci");
        m.ensureHost("iot.teos.internal");
        m.ensureHost("data.localhost.localstack.cloud");

        Set<String> sans = sans(read("floci-server.crt"));
        assertTrue(sans.containsAll(List.of("api.floci", "iot.teos.internal", "data.localhost.localstack.cloud")), sans.toString());
    }

    @Test
    void learnedHostsSurviveANewManagerInstance() throws Exception {
        manager().ensureHost("api.teos.localhost.floci.io");

        TlsCertificateManager fresh = manager();
        fresh.ensureHost("api.teos.localhost.floci.io");

        verify(defaultTls, times(1)).reload();
        assertTrue(fresh.knownHostnames().contains("api.teos.localhost.floci.io"));
    }

    @Test
    void clearDropsLearnedHostsAndKeepsConfiguredOnes() throws Exception {
        TlsCertificateManager m = manager();
        m.ensureHost("api.teos.localhost.floci.io");

        m.clear();

        Set<String> sans = sans(read("floci-server.crt"));
        assertFalse(sans.contains("api.teos.localhost.floci.io"));
        assertTrue(sans.containsAll(CONFIGURED));
        CertificateMetadata metadata = new ObjectMapper().readValue(
                tlsDir.resolve("floci-server.metadata.json").toFile(), CertificateMetadata.class);
        assertEquals(List.of(), metadata.getLearnedHostnames());
        verify(defaultTls, times(2)).reload();
    }

    @Test
    void doesNothingWhenTlsIsOff() throws Exception {
        when(config.tls().enabled()).thenReturn(false);
        byte[] certBefore = Files.readAllBytes(tlsDir.resolve("floci-server.crt"));

        manager().ensureHost("api.teos.localhost.floci.io");

        assertArrayEquals(certBefore, Files.readAllBytes(tlsDir.resolve("floci-server.crt")));
    }

    @Test
    void doesNothingWithAUserProvidedCertificate() throws Exception {
        when(config.tls().certPath()).thenReturn(Optional.of("/etc/floci/user.crt"));
        byte[] certBefore = Files.readAllBytes(tlsDir.resolve("floci-server.crt"));

        manager().ensureHost("api.teos.localhost.floci.io");

        assertArrayEquals(certBefore, Files.readAllBytes(tlsDir.resolve("floci-server.crt")));
    }

    private X509Certificate read(String name) throws Exception {
        return new CertificateGenerator().parseCertificate(Files.readString(tlsDir.resolve(name)));
    }

    private static Set<String> sans(X509Certificate cert) throws Exception {
        Set<String> out = new TreeSet<>();
        for (List<?> entry : cert.getSubjectAlternativeNames()) {
            out.add(String.valueOf(entry.get(1)));
        }
        return out;
    }
}
```

- [x] **Step 2: Run and watch it fail to compile**

Run: `./mvnw test -Dtest=TlsCertificateManagerTest`
Expected: COMPILATION ERROR, `cannot find symbol: class TlsCertificateManager`.

- [x] **Step 3: Write the manager**

```java
package io.github.hectorvent.floci.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.hectorvent.floci.core.common.Resettable;
import io.github.hectorvent.floci.services.acm.CertificateGenerator;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import io.quarkus.tls.CertificateUpdatedEvent;
import io.quarkus.tls.TlsConfiguration;
import io.quarkus.tls.TlsConfigurationRegistry;
import io.quarkus.tls.runtime.config.TlsConfig;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Event;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.KeyPair;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * Grows the HTTPS server certificate's SAN list at runtime so a custom domain created through
 * API Gateway, IoT or Cognito is served under its exact name in the same call.
 *
 * <p>Reissue keeps the key pair: only the SAN extension and serial change, the CA that signs it
 * is the same, so anyone who trusts {@code floci-root-ca.crt} keeps validating. The key file is
 * never rewritten. Cert and metadata are replaced atomically, then the Quarkus TLS registry's
 * default configuration is reloaded and {@link CertificateUpdatedEvent} is fired, which is what
 * {@code HttpCertificateUpdateEventListener} listens to before calling
 * {@code HttpServer.updateSSLOptions}.
 *
 * <p>Only names under an allow-list of local suffixes are accepted: a Floci certificate that
 * covered an arbitrary public name would let anyone who trusts the Floci CA be impersonated.
 */
@ApplicationScoped
public class TlsCertificateManager implements Resettable {

    private static final Logger LOG = Logger.getLogger(TlsCertificateManager.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final List<String> BUILTIN_SUFFIXES = List.of("localhost", "localhost.floci.io", "localhost.localstack.cloud");

    static final String CERT_NAME = "floci-server.crt";
    static final String KEY_NAME = "floci-server.key";
    static final String METADATA_NAME = "floci-server.metadata.json";

    private final EmulatorConfig config;
    private final FlociCertificateAuthority ca;
    private final TlsConfigurationRegistry registry;
    private final Event<CertificateUpdatedEvent> certificateUpdated;
    private final Object lock = new Object();

    private volatile Set<String> knownHostnames = Set.of();
    private List<String> configuredHostnames = List.of();
    private Set<String> learnedHostnames = new LinkedHashSet<>();
    private KeyPair keyPair;
    private boolean loaded;

    @Inject
    public TlsCertificateManager(EmulatorConfig config, FlociCertificateAuthority ca,
                                 TlsConfigurationRegistry registry, Event<CertificateUpdatedEvent> certificateUpdated) {
        this.config = config;
        this.ca = ca;
        this.registry = registry;
        this.certificateUpdated = certificateUpdated;
    }

    /**
     * Makes sure {@code host} is covered by the server certificate. Idempotent, wildcard-aware,
     * and never throws: a failure is logged and the caller's AWS operation still succeeds.
     */
    public void ensureHost(String host) {
        String name = normalize(host);
        if (name == null || !config.tls().enabled()) {
            return;
        }
        if (config.tls().certPath().filter(p -> !p.isBlank()).isPresent()) {
            LOG.debugv("TLS: user-provided certificate in use; cannot add {0} to its SAN list", name);
            return;
        }
        if (!isAllowed(name)) {
            LOG.warnv("TLS: refusing to add {0} to the server certificate: not under a local suffix "
                    + "(localhost, localhost.floci.io, localhost.localstack.cloud, floci.hostname, "
                    + "floci.base-url host, floci.dns.extra-suffixes)", name);
            return;
        }
        synchronized (lock) {
            try {
                if (!loadOnce() || covers(name)) {
                    return;
                }
                learnedHostnames.add(name);
                reissue();
                LOG.infov("TLS: server certificate now covers {0}", name);
            } catch (Exception e) {
                LOG.warnv(e, "TLS: could not extend the server certificate with {0}: {1}", name, e.getMessage());
            }
        }
    }

    /** Every SAN currently on the served leaf (configured and learned), for diagnostics and tests. */
    public Set<String> knownHostnames() {
        synchronized (lock) {
            loadOnce();
            return knownHostnames;
        }
    }

    /** Reset: forget learned names, keep the configured ones. */
    @Override
    public void clear() {
        synchronized (lock) {
            try {
                if (!loadOnce() || learnedHostnames.isEmpty()) {
                    return;
                }
                learnedHostnames.clear();
                reissue();
            } catch (Exception e) {
                LOG.warnv(e, "TLS: could not reset the server certificate: {0}", e.getMessage());
            }
        }
    }

    private boolean loadOnce() {
        if (loaded) {
            return true;
        }
        Path dir = tlsDir();
        Path certFile = dir.resolve(CERT_NAME);
        Path keyFile = dir.resolve(KEY_NAME);
        if (!Files.exists(certFile) || !Files.exists(keyFile)) {
            LOG.debugv("TLS: no server certificate under {0}; ensureHost is a no-op", dir);
            return false;
        }
        try {
            CertificateGenerator generator = new CertificateGenerator();
            X509Certificate cert = generator.parseCertificate(Files.readString(certFile));
            keyPair = new KeyPair(cert.getPublicKey(), generator.parsePrivateKey(Files.readString(keyFile)));
            Set<String> sans = new LinkedHashSet<>();
            if (cert.getSubjectAlternativeNames() != null) {
                for (List<?> entry : cert.getSubjectAlternativeNames()) {
                    sans.add(String.valueOf(entry.get(1)).toLowerCase(Locale.ROOT));
                }
            }
            Path metadataFile = dir.resolve(METADATA_NAME);
            if (Files.exists(metadataFile)) {
                CertificateMetadata metadata = OBJECT_MAPPER.readValue(metadataFile.toFile(), CertificateMetadata.class);
                configuredHostnames = metadata.getHostnames() == null ? List.copyOf(sans) : metadata.getHostnames();
                learnedHostnames = new LinkedHashSet<>(metadata.getLearnedHostnames());
            } else {
                configuredHostnames = List.copyOf(sans);
                learnedHostnames = new LinkedHashSet<>();
            }
            knownHostnames = Set.copyOf(sans);
            loaded = true;
            return true;
        } catch (Exception e) {
            LOG.warnv(e, "TLS: could not read the server certificate under {0}: {1}", dir, e.getMessage());
            return false;
        }
    }

    private void reissue() throws IOException {
        List<String> sans = new ArrayList<>(new LinkedHashSet<>(configuredHostnames));
        for (String learned : learnedHostnames) {
            if (!sans.contains(learned)) {
                sans.add(learned);
            }
        }
        CertificateGenerator.GeneratedCertificate issued = ca.issueServerCertificate("localhost", sans, KeyAlgorithm.RSA_2048, keyPair);

        Path dir = tlsDir();
        CertificateMetadata metadata = CertificateMetadata.create(configuredHostnames, resolveFlociVersion());
        metadata.setLearnedHostnames(new ArrayList<>(learnedHostnames));
        writeAtomically(dir.resolve(CERT_NAME), issued.certificatePem());
        writeAtomically(dir.resolve(METADATA_NAME), OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(metadata));

        Set<String> lower = new LinkedHashSet<>();
        sans.forEach(s -> lower.add(s.toLowerCase(Locale.ROOT)));
        knownHostnames = Set.copyOf(lower);
        reloadServer();
    }

    private void reloadServer() {
        Optional<TlsConfiguration> defaultTls = registry.getDefault();
        if (defaultTls.isEmpty()) {
            LOG.warn("TLS: no default TLS configuration registered; the new certificate applies on next restart");
            return;
        }
        TlsConfiguration cfg = defaultTls.get();
        if (!cfg.reload()) {
            LOG.warn("TLS: TlsConfiguration.reload() returned false; the new certificate applies on next restart");
            return;
        }
        certificateUpdated.fire(new CertificateUpdatedEvent(TlsConfig.DEFAULT_NAME, cfg));
    }

    private boolean covers(String name) {
        if (knownHostnames.contains(name)) {
            return true;
        }
        int dot = name.indexOf('.');
        return dot > 0 && knownHostnames.contains("*" + name.substring(dot));
    }

    private boolean isAllowed(String name) {
        List<String> suffixes = new ArrayList<>(BUILTIN_SUFFIXES);
        config.hostname().filter(h -> !h.isBlank()).map(String::toLowerCase).ifPresent(suffixes::add);
        try {
            String baseHost = URI.create(config.baseUrl()).getHost();
            if (baseHost != null) {
                suffixes.add(baseHost.toLowerCase(Locale.ROOT));
            }
        } catch (RuntimeException e) {
            LOG.debugv("TLS: base-url {0} has no usable host: {1}", config.baseUrl(), e.getMessage());
        }
        config.dns().extraSuffixes().ifPresent(list -> list.forEach(s -> suffixes.add(s.toLowerCase(Locale.ROOT))));
        for (String suffix : suffixes) {
            if (name.equals(suffix) || name.endsWith("." + suffix)) {
                return true;
            }
        }
        return false;
    }

    private static String normalize(String host) {
        if (host == null) {
            return null;
        }
        String name = host.trim().toLowerCase(Locale.ROOT);
        if (name.endsWith(".")) {
            name = name.substring(0, name.length() - 1);
        }
        if (name.isEmpty() || name.contains(":") || name.contains("/")) {
            return null;
        }
        // API Gateway accepts wildcard custom domains (*.example.com); X.509 accepts them as a
        // leading wildcard label only, so "*.x" passes and "*", "a*.x" or "*.*.x" do not.
        if (name.startsWith("*") && (!name.startsWith("*.") || name.indexOf('*', 1) >= 0)) {
            return null;
        }
        return name;
    }

    private Path tlsDir() {
        return FlociCertificateAuthorityProducer.tlsDir(config);
    }

    private static void writeAtomically(Path target, String content) throws IOException {
        Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
        Files.writeString(tmp, content);
        Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }

    private static String resolveFlociVersion() {
        String env = System.getenv("FLOCI_VERSION");
        return env == null || env.isBlank() ? "dev" : env;
    }
}
```

- [x] **Step 4: Run the unit tests**

Run: `./mvnw test -Dtest=TlsCertificateManagerTest`
Expected: PASS, 9 tests. If `RETURNS_DEEP_STUBS` returns `null` for `config.dns()` in a test that never stubbed it, the `@BeforeEach` stub covers it; every test uses the same `config`.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/TlsCertificateManager.java src/test/java/io/github/hectorvent/floci/config/TlsCertificateManagerTest.java
git commit -m "feat(tls): TlsCertificateManager.ensureHost grows the server certificate at runtime

Reissues the leaf from the local CA with the same key pair and the new SAN,
replaces cert and metadata atomically, reloads the default TLS configuration
and fires CertificateUpdatedEvent so the HTTPS listener swaps immediately.
Names must sit under a local suffix; anything else is refused with a WARN."
```

### Task 3: Learned names survive a restart

**Files:**
- Modify: `TEST/config/TlsCertificateHostnameTest.java`
- Modify: `SRC/config/TlsConfigSource.java` (`generateServerCert`, `persistMetadata`)

- [x] **Step 1: Write the failing test**

Append to `TlsCertificateHostnameTest`:

```java
    @Test
    void learnedHostnamesAreKeptWhenBootRegeneratesTheCertificate() throws Exception {
        System.setProperty("floci.hostname", "host1");
        System.setProperty("floci.tls.enabled", "true");
        System.setProperty("floci.tls.self-signed", "true");
        System.setProperty("floci.storage.persistent-path", tempDir.toString());
        new TlsConfigSource();

        Path metadataFile = tempDir.resolve("tls/floci-server.metadata.json");
        var mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        CertificateMetadata metadata = mapper.readValue(metadataFile.toFile(), CertificateMetadata.class);
        metadata.setLearnedHostnames(List.of("api.teos.localhost.floci.io"));
        Files.writeString(metadataFile, mapper.writeValueAsString(metadata));

        System.setProperty("floci.hostname", "host2");
        new TlsConfigSource();

        List<String> sans = extractSansFromCertificate(parseCertificate(tempDir.resolve("tls/floci-server.crt")));
        assertTrue(sans.contains("host2"), sans.toString());
        assertTrue(sans.contains("api.teos.localhost.floci.io"), "learned name must survive: " + sans);
        CertificateMetadata after = mapper.readValue(metadataFile.toFile(), CertificateMetadata.class);
        assertEquals(List.of("api.teos.localhost.floci.io"), after.getLearnedHostnames());
        assertFalse(after.getHostnames().contains("api.teos.localhost.floci.io"), "learned names stay out of the configured list");
    }
```

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=TlsCertificateHostnameTest#learnedHostnamesAreKeptWhenBootRegeneratesTheCertificate`
Expected: FAIL, "learned name must survive".

- [x] **Step 3: Teach `TlsConfigSource.generateServerCert` about learned names**

Replace the method body (the PR 3 version):

```java
    private void generateServerCert(Path tlsDir, Path certFile, Path keyFile, FlociCertificateAuthority ca) {
        try {
            Files.createDirectories(tlsDir);
            List<String> configured = new ArrayList<>(DEFAULT_SAN_HOSTNAMES);
            configured.addAll(extractCustomHostnames());
            List<String> learned = readLearnedHostnames(tlsDir);
            List<String> allSans = new ArrayList<>(configured);
            for (String name : learned) {
                if (!allSans.contains(name)) {
                    allSans.add(name);
                }
            }

            CertificateGenerator.GeneratedCertificate generated = ca.issueServerCertificate("localhost", allSans,
                    KeyAlgorithm.RSA_2048, null);

            Files.writeString(certFile, generated.certificatePem());
            Files.writeString(keyFile, generated.privateKeyPem());
            FlociCertificateAuthority.restrictToOwnerOnly(keyFile, "rw-------");

            LOG.infov("TLS: generated server certificate {0} issued by {1}", certFile,
                    ca.certificate().getSubjectX500Principal().getName());
            persistMetadata(tlsDir, configured, learned);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to write TLS server certificate", e);
        }
    }

    /** Names added at runtime by TlsCertificateManager; a boot regeneration must not drop them. */
    private List<String> readLearnedHostnames(Path tlsDir) {
        Path metadataFile = tlsDir.resolve(SERVER_METADATA_NAME);
        if (!Files.exists(metadataFile)) {
            return List.of();
        }
        try {
            return OBJECT_MAPPER.readValue(Files.readString(metadataFile), CertificateMetadata.class).getLearnedHostnames();
        } catch (IOException e) {
            LOG.warnv("TLS: could not read learned hostnames from {0} ({1}); starting without them", metadataFile, e.getMessage());
            return List.of();
        }
    }
```

Change `persistMetadata(Path tlsDir, List<String> hostnames)` to `persistMetadata(Path tlsDir, List<String> hostnames, List<String> learnedHostnames)` and, after `CertificateMetadata metadata = CertificateMetadata.create(hostnames, version);`, add `metadata.setLearnedHostnames(learnedHostnames);`. Update its javadoc `@param` list.

- [x] **Step 4: Run the whole config TLS unit set**

Run: `./mvnw test -Dtest='TlsConfigSource*Test,TlsCertificateHostnameTest,TlsCertificateManagerTest'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/TlsConfigSource.java src/test/java/io/github/hectorvent/floci/config/TlsCertificateHostnameTest.java
git commit -m "feat(tls): keep runtime-learned hostnames across a boot regeneration"
```

### Task 4: The real handshake

**Files:**
- Create: `TEST/config/TlsEnsureHostIntegrationTest.java`

- [x] **Step 1: Write the test**

```java
package io.github.hectorvent.floci.config;

import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.junit.jupiter.api.Test;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * End to end: after ensureHost, a TLS client that trusts only floci-root-ca.crt and sends the
 * new name as SNI receives a leaf whose SAN list contains it. No restart in between.
 */
@QuarkusTest
@TestProfile(TlsEnsureHostIntegrationTest.Profile.class)
class TlsEnsureHostIntegrationTest {

    static final Path DATA_DIR = Path.of("/tmp/floci-tls-ensure-host-test");
    static final Path TLS_DIR = DATA_DIR.resolve("tls");
    static final String NEW_HOST = "api.teos.localhost.floci.io";

    @ConfigProperty(name = "quarkus.http.test-ssl-port", defaultValue = "8444")
    int sslPort;

    @Inject
    TlsCertificateManager manager;

    @Test
    void ensureHostIsVisibleToTheNextHandshake() throws Exception {
        assertFalse(peerSans().contains(NEW_HOST), "precondition: the boot leaf does not cover " + NEW_HOST);

        manager.ensureHost(NEW_HOST);

        Set<String> sans = peerSans();
        assertTrue(sans.contains(NEW_HOST), sans.toString());
        assertTrue(sans.contains("localhost"), "configured names are still served: " + sans);
    }

    private Set<String> peerSans() throws Exception {
        KeyStore trust = KeyStore.getInstance(KeyStore.getDefaultType());
        trust.load(null, null);
        trust.setCertificateEntry("floci", FlociCertificateAuthority.loadOrCreate(TLS_DIR).certificate());
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trust);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, tmf.getTrustManagers(), null);

        try (SSLSocket socket = (SSLSocket) ctx.getSocketFactory().createSocket("localhost", sslPort)) {
            SSLParameters params = socket.getSSLParameters();
            params.setServerNames(List.of(new SNIHostName(NEW_HOST)));
            socket.setSSLParameters(params);
            socket.startHandshake();
            X509Certificate leaf = (X509Certificate) socket.getSession().getPeerCertificates()[0];
            Set<String> sans = new TreeSet<>();
            for (List<?> entry : leaf.getSubjectAlternativeNames()) {
                sans.add(String.valueOf(entry.get(1)));
            }
            return sans;
        }
    }

    /**
     * Boots Quarkus with TLS on and a CA-issued leaf that TlsConfigSource would have produced.
     * TlsConfigSource itself reads system properties, not profile overrides, so the profile lays
     * the files down and points the TLS registry at them directly.
     */
    public static final class Profile implements QuarkusTestProfile {

        static {
            try {
                Files.createDirectories(TLS_DIR);
                for (String name : List.of("floci-server.crt", "floci-server.key", "floci-server.metadata.json")) {
                    Files.deleteIfExists(TLS_DIR.resolve(name));
                }
                FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(TLS_DIR);
                List<String> sans = List.of("localhost", "127.0.0.1", "*.localhost.floci.io");
                var leaf = ca.issueServerCertificate("localhost", sans, KeyAlgorithm.RSA_2048, null);
                Files.writeString(TLS_DIR.resolve("floci-server.crt"), leaf.certificatePem());
                Files.writeString(TLS_DIR.resolve("floci-server.key"), leaf.privateKeyPem());
                Files.writeString(TLS_DIR.resolve("floci-server.metadata.json"),
                        new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(CertificateMetadata.create(sans, "dev")));
            } catch (IOException e) {
                throw new IllegalStateException("could not prepare TLS fixtures", e);
            }
        }

        @Override
        public Map<String, String> getConfigOverrides() {
            return Map.of(
                    "floci.tls.enabled", "true",
                    "floci.tls.self-signed", "true",
                    "floci.storage.persistent-path", DATA_DIR.toString(),
                    "quarkus.tls.key-store.pem.0.cert", TLS_DIR.resolve("floci-server.crt").toString(),
                    "quarkus.tls.key-store.pem.0.key", TLS_DIR.resolve("floci-server.key").toString(),
                    "quarkus.http.insecure-requests", "enabled");
        }
    }
}
```

`*.localhost.floci.io` covers one label only (RFC 6125), so the three-label `api.teos.localhost.floci.io` is genuinely uncovered before `ensureHost`; the precondition assertion proves it.

- [x] **Step 2: Run it**

Run: `./mvnw test -Dtest=TlsEnsureHostIntegrationTest`
Expected: PASS. If the precondition holds but the post-assertion fails with the old SAN list, `HttpCertificateUpdateEventListener` did not apply: check the Quarkus log for `TLS: TlsConfiguration.reload() returned false` (path mismatch between the profile and the manager) or for the listener not being registered (the profile must not set `quarkus.http.tls-configuration-name`).

- [x] **Step 3: Commit**

```bash
git add src/test/java/io/github/hectorvent/floci/config/TlsEnsureHostIntegrationTest.java
git commit -m "test(tls): ensureHost is visible to the next TLS handshake without a restart"
```

### Task 5: Docs and PR

- [x] **Step 1: `docs/configuration/tls.md`**

After the "Custom Hostname Support" section add:

```markdown
### Custom Domains Learned at Runtime

Creating an API Gateway, IoT Core or Cognito custom domain adds its hostname to the server
certificate immediately, without a restart and without changing the key. Learned names persist in
`{persistent-path}/tls/floci-server.metadata.json` and survive restarts. Only names under a local
suffix are accepted: `localhost`, `localhost.floci.io`, `localhost.localstack.cloud`,
`FLOCI_HOSTNAME`, the `FLOCI_BASE_URL` host, and `FLOCI_DNS_EXTRA_SUFFIXES`. Anything else is
refused with a warning, so a Floci certificate can never cover a public name.
```

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/configuration/tls.md
git commit -m "docs(tls): custom domains learned at runtime"
```

```
Floci's server certificate is fixed at boot, so an API Gateway custom domain like
api.teos.localhost.floci.io (three labels under the wildcard, therefore not covered) fails TLS
validation until a restart with FLOCI_HOSTNAME set.

- TlsCertificateManager.ensureHost(name): appends the SAN, reissues the leaf from the local CA
  with the same key pair, replaces cert + metadata atomically (the key file is never
  rewritten), reloads the TLS registry's default configuration and fires
  CertificateUpdatedEvent("<default>") so Quarkus swaps the listener's SSL options in the
  same call. Idempotent, wildcard-aware, refuses names outside local suffixes, never throws.
- CertificateMetadata.learnedHostnames keeps learned names apart from configured ones;
  TlsConfigSource re-includes them when it regenerates at boot.
- Resettable: /_floci/reset drops learned names.
- Nothing calls ensureHost yet; the API Gateway, IoT and Cognito hooks are the next PR.

Tests: TlsCertificateManagerTest (9 unit cases incl. same key, key file untouched, allow-list,
wildcard no-op, restart, clear); TlsCertificateHostnameTest boot-regeneration keeps learned
names; TlsEnsureHostIntegrationTest does a real SNI handshake trusting only the CA before and
after ensureHost.
Depends on the local CA PR.
```

---

## Self-review

- Spec coverage. Spec PR 6: `@ApplicationScoped` `ensureHost(String)` appending SAN with same key (Task 2); atomic cert + metadata writes, key never rewritten (Task 2, test asserts key bytes); reload via registry + `CertificateUpdatedEvent(TlsConfig.DEFAULT_NAME)` (Task 2); `learnedHostnames` separate from `hostnames` (Tasks 1, 3); allow-list of suffixes with WARN + skip (Task 2); idempotent, wildcard-aware, synchronized (Task 2); `Resettable` (Task 2); failures WARN not propagate (Task 2); tests key unchanged, restart keeps learned names, client sees new SAN (Tasks 2, 3, 4).
- Placeholders: none.
- Type consistency: `FlociCertificateAuthority.issueServerCertificate(String, List<String>, KeyAlgorithm, KeyPair)` and `certificate()` from PR 3; `FlociCertificateAuthorityProducer.tlsDir(EmulatorConfig)` is the package-private resolver from PR 3 (same package `config`); never build the path from `persistentPath()` directly, PR 3 explains why. `TlsCertificateManager.ensureHost(String)`, `knownHostnames()`, `clear()` are what PRs 8, 9 and 11 use.
- Wildcards: `normalize` accepts exactly one leading `*.` label (RFC 6125 §6.4.3, what API Gateway's `*.example.com` custom domains send) and rejects `*`, `a*.x` and interior wildcards; `wildcardIsAcceptedOnlyAsAWholeLeftmostLabel` pins both directions. An earlier draft rejected every `*`, which would have made a wildcard custom domain silently unservable (adversarial review finding).
- Deviation to note: the spec said `FlociCertificateAuthority` is where PR 3 signs; the manager passes the persisted `KeyPair` into `issueServerCertificate`, which `generateIssuedCertificate` honours (PR 2 test `issuedLeafReusesSuppliedKeyPairAndClientUsage`).
