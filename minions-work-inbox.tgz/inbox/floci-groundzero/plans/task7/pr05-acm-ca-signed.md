# PR 5: `feat(acm): issue certificates from the local CA` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Every certificate ACM issues (`AMAZON_ISSUED` and `PRIVATE`) is a server leaf (serverAuth plus clientAuth EKU, as ACM issues and `DescribeCertificate` already advertises) signed by Floci's local CA, and `CertificateChain` is that CA's PEM, so `Certificate` + `CertificateChain` from `GetCertificate` form a chain that actually validates.

**Architecture:** `AcmService.requestCertificate` swaps `certificateGenerator.generateCertificate(...)` for `certificateAuthority.issueServerCertificate(domain, sans, alg, null)` (the requested key algorithm is honoured), and `getAwsRootCa()` becomes `certificateAuthority.caPem()`. The bundled `amazon-root-ca.pem` and its validator go away. The cosmetic-Amazon-issuer generator loses its last production caller and is deleted too.

**Tech Stack:** `FlociCertificateAuthority` (PR 3), `CertificateGenerator` (PR 2), RestAssured JSON 1.1.

**Branch:** `feat/acm-ca-signed` from `upstream/main` after PR 3 merges. Depends on PR 3.

---

## File structure

- Modify: `SRC/services/acm/AcmService.java` (ctors 69-88, `validateRootCaResource` 101-112, `requestCertificate` 152-155 and 185, `getAwsRootCa` 723-734)
- Modify: `SRC/services/acm/CertificateGenerator.java` (delete `generateCertificate` 76-88 and `ISSUER_DN` 53)
- Delete: `src/main/resources/certs/amazon-root-ca.pem`
- Modify: `TEST/services/acm/AcmIntegrationTest.java` (strengthen `getCertificate`, add PRIVATE chain test)
- Modify: `TEST/services/acm/AcmServicePersistenceTest.java:68-74` (ctor)
- Modify: `TEST/services/acm/CertificateGeneratorSelfSignedTest.java:55-67` (delete one test)
- Modify: `TEST/services/acm/CertificateGeneratorIssuerTest.java` (drop the acm-style half of one test)
- Modify: `TEST/config/TlsIntegrationTest.java:134`, `TEST/config/TlsCertificateHostnameTest.java:192`, `TEST/services/lambda/launcher/ContainerLauncherCaTrustTest.java:88` (replace `generateCertificate` calls)
- Modify: `docs/services/acm.md:29-35`

---

### Task 1: Failing integration tests

**Files:**
- Modify: `TEST/services/acm/AcmIntegrationTest.java`

- [x] **Step 1: Replace the `getCertificate` body (PR 1 version) with a chain-validating one, and add a PRIVATE case**

```java
    @Test
    @Order(12)
    void getCertificate() throws Exception {
        var response = given()
            .header("X-Amz-Target", "CertificateManager.GetCertificate")
            .contentType(ACM_CONTENT_TYPE)
            .body("""
                {
                    "CertificateArn": "%s"
                }
                """.formatted(createdCertificateArn))
        .when()
            .post("/")
        .then()
            .statusCode(200)
            .extract().jsonPath();

        assertLeafChainsToFlociCa(response.getString("Certificate"), response.getString("CertificateChain"));
    }

    @Test
    @Order(13)
    void privateCertificateChainsToTheSameCa() throws Exception {
        String arn = given()
            .header("X-Amz-Target", "CertificateManager.RequestCertificate")
            .contentType(ACM_CONTENT_TYPE)
            .body("""
                {
                    "DomainName": "internal.example.com",
                    "CertificateAuthorityArn": "arn:aws:acm-pca:us-east-1:000000000000:certificate-authority/11111111-2222-3333-4444-555555555555"
                }
                """)
        .when()
            .post("/")
        .then()
            .statusCode(200)
            .extract().jsonPath().getString("CertificateArn");

        var response = given()
            .header("X-Amz-Target", "CertificateManager.GetCertificate")
            .contentType(ACM_CONTENT_TYPE)
            .body("{\"CertificateArn\": \"%s\"}".formatted(arn))
        .when()
            .post("/")
        .then()
            .statusCode(200)
            .extract().jsonPath();

        assertLeafChainsToFlociCa(response.getString("Certificate"), response.getString("CertificateChain"));
    }

    /**
     * Certificate is a TLS server leaf, CertificateChain is exactly Floci's CA (the one served at
     * /_floci/ca.pem), and the pair builds a PKIX path with the CA as the only trust anchor.
     */
    private static void assertLeafChainsToFlociCa(String leafPem, String chainPem) throws Exception {
        var factory = java.security.cert.CertificateFactory.getInstance("X.509");
        var leaf = (java.security.cert.X509Certificate) factory.generateCertificate(
                new java.io.ByteArrayInputStream(leafPem.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));
        var chain = (java.security.cert.X509Certificate) factory.generateCertificate(
                new java.io.ByteArrayInputStream(chainPem.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));
        String servedCa = given().when().get("/_floci/ca.pem").then().statusCode(200).extract().asString();

        assertEquals(servedCa.strip(), chainPem.strip(), "CertificateChain must be the local CA PEM");
        assertEquals(chain.getSubjectX500Principal(), leaf.getIssuerX500Principal());

        // Real path validation, not just a signature check: what every TLS client will do.
        var params = new java.security.cert.PKIXParameters(java.util.Set.of(new java.security.cert.TrustAnchor(chain, null)));
        params.setRevocationEnabled(false);
        java.security.cert.CertPathValidator.getInstance("PKIX")
                .validate(factory.generateCertPath(java.util.List.of(leaf)), params);

        assertEquals(java.util.List.of("1.3.6.1.5.5.7.3.1", "1.3.6.1.5.5.7.3.2"), leaf.getExtendedKeyUsage(),
                "serverAuth and clientAuth, as DescribeCertificate advertises");
        assertEquals(-1, leaf.getBasicConstraints());
    }
```

Add `import static org.junit.jupiter.api.Assertions.assertEquals;` if missing. If an existing test already carries `@Order(13)`, renumber the new test to the next free order value and keep the class's ordering intact.

- [x] **Step 2: Run and watch both fail**

Run: `./mvnw test -Dtest='AcmIntegrationTest#getCertificate+privateCertificateChainsToTheSameCa'`
Expected: FAIL on `assertEquals(servedCa, chainPem)` (chain is still Amazon Root CA 1) or, on a branch where PR 1 was not merged, on the chain parse.

### Task 2: ACM issues from the CA

**Files:**
- Modify: `SRC/services/acm/AcmService.java`
- Modify: `TEST/services/acm/AcmServicePersistenceTest.java:68-74`

- [x] **Step 1: Rewire `AcmService`**

Add a `private final FlociCertificateAuthority certificateAuthority;` field and import
`io.github.hectorvent.floci.config.FlociCertificateAuthority`. **Keep** the existing
`private final CertificateGenerator certificateGenerator;` field: `ImportCertificate` (lines 333 to
341: `parseCertificate`, `validateCertificate`, `parsePrivateKey`), `detectKeyAlgorithm` (line 364)
and `ExportCertificate` (line 415: `encryptPrivateKey`) still use it, and they are instance
methods. Only issuance moves to the CA. Both constructors therefore keep their `CertificateGenerator`
parameter and gain the CA next to it (these are the only two constructor shapes in this PR):

```java
    @Inject
    public AcmService(StorageFactory factory, CertificateGenerator certificateGenerator,
                      FlociCertificateAuthority certificateAuthority, EmulatorConfig config,
                      RegionResolver regionResolver) {
        this(factory.create("acm", "acm-certificates.json",
                new TypeReference<Map<String, Certificate>>() {}),
            certificateGenerator, certificateAuthority, regionResolver,
            config.services().acm().validationWaitSeconds());
    }

    AcmService(StorageBackend<String, Certificate> store, CertificateGenerator certificateGenerator,
               FlociCertificateAuthority certificateAuthority, RegionResolver regionResolver,
               int validationWaitSeconds) {
        this.store = store;
        this.certificateGenerator = certificateGenerator;
        this.certificateAuthority = certificateAuthority;
        this.regionResolver = regionResolver;
        this.validationWaitSeconds = validationWaitSeconds;
    }
```

(The two constructor snippets above this paragraph are superseded by these.) Delete
`validateRootCaResource()` (lines 101 to 112) and `getAwsRootCa()` (lines 723 to 734), plus
now-unused imports (`InputStream`, `IOException` if unused elsewhere, `StandardCharsets` if unused).

Lines 152 to 155:

```java
        CertificateGenerator.GeneratedCertificate generated = certificateAuthority.issueServerCertificate(
            domainName, sans, alg, null);
```

Line 185:

```java
        cert.setCertificateChain(certificateAuthority.caPem());
```

Check the import path at line 383 (`ImportCertificate` sets its own chain from the request): unchanged.

- [x] **Step 2: Fix the persistence test constructor**

`AcmServicePersistenceTest.newService(Path dir)`:

```java
    private AcmService newService(Path dir) {
        RegionResolver regionResolver = mock(RegionResolver.class);
        when(regionResolver.getAccountId()).thenReturn("000000000000");

        StorageBackend<String, Certificate> store = load(dir, "acm-certificates.json");
        return new AcmService(store, generator, FlociCertificateAuthority.loadOrCreate(dir.resolve("tls")), regionResolver, 0);
    }
```

Import `io.github.hectorvent.floci.config.FlociCertificateAuthority`; the test's existing `generator` field stays, it is the second constructor argument.

- [x] **Step 3: Run the ACM suites**

Run: `./mvnw test -Dtest='Acm*Test'`
Expected: PASS, including the two Task 1 tests and `AcmImportExportTest` (ExportCertificate returns the stored chain, now the CA PEM).

- [x] **Step 4: Delete the bundled PEM**

```bash
git rm src/main/resources/certs/amazon-root-ca.pem
grep -rn "amazon-root-ca" src/ docs/ || echo "no references left"
```
Expected: `no references left`. If `src/main/resources/certs/` is now empty, git drops the directory.

- [x] **Step 5: Run the ACM suites again plus the CloudFormation ACM resource tests**

Run: `./mvnw test -Dtest='Acm*Test,*AcmCfn*Test'`
Expected: PASS (if no `*AcmCfn*Test` matches, Maven reports "No tests matching pattern" for that half; that is fine).

- [x] **Step 6: Commit**

```bash
git add -A src/main/java/io/github/hectorvent/floci/services/acm src/main/java/io/github/hectorvent/floci/config/FlociCertificateAuthority.java src/main/resources/certs src/test/java/io/github/hectorvent/floci/services/acm
git commit -m "feat(acm): issue AMAZON_ISSUED and PRIVATE certificates from the local CA

The leaf is a TLS server certificate (serverAuth and clientAuth) signed by Floci's root CA and
CertificateChain is that CA's PEM, so pinning Certificate + CertificateChain
from GetCertificate validates Floci's HTTPS endpoint. The bundled Amazon Root CA
resource is gone: nothing Floci serves chained to it."
```

### Task 3: Delete the cosmetic Amazon issuer

**Files:**
- Modify: `SRC/services/acm/CertificateGenerator.java:53, 76-88`
- Modify: `TEST/services/acm/CertificateGeneratorSelfSignedTest.java:55-67`
- Modify: `TEST/services/acm/CertificateGeneratorIssuerTest.java` (last test)
- Modify: `TEST/config/TlsIntegrationTest.java:134`, `TEST/config/TlsCertificateHostnameTest.java:192`, `TEST/services/lambda/launcher/ContainerLauncherCaTrustTest.java:88`

- [x] **Step 1: Delete `generateCertificate` and `ISSUER_DN`**

Remove line 53 (`ISSUER_DN`) and the `generateCertificate` method with its javadoc (lines 76 to 88). Fix the comment inside `buildCertificate` that mentions "cosmetic Amazon issuer DN": it now reads
`// Signed with the subject's own key: generateSelfSignedCertificate keeps issuer == subject.`

- [x] **Step 2: Compile to find every caller**

Run: `./mvnw -q test-compile 2>&1 | grep -E "ERROR.*\.java" | head`
Expected: exactly the four test files listed above.

- [x] **Step 3: Fix the callers**

`CertificateGeneratorSelfSignedTest`: delete `acmStyleCertificateKeepsCosmeticAmazonIssuerAndIsNotACa` (lines 55 to 67) and the `assertNotEquals`/`assertTrue` imports if now unused. Update the class javadoc bullet that mentions `generateCertificate`.

`CertificateGeneratorIssuerTest.existingSelfSignedAndAcmStylePathsAreUnchanged`: rename to `existingSelfSignedPathIsUnchanged` and delete the three `acmStyle`/`acm` lines.

`TlsIntegrationTest` line 134: `gen.generateCertificate(` becomes `gen.generateSelfSignedCertificate(` (same arguments).

`TlsCertificateHostnameTest` line 192: `gen.generateCertificate(` becomes `gen.generateSelfSignedCertificate(`. The test's point (missing metadata triggers regeneration) is unchanged.

`ContainerLauncherCaTrustTest` lines 87 to 89 need "a leaf that is not a self-signed CA". Replace with:

```java
        CertificateGenerator gen = new CertificateGenerator();
        var ca = gen.generateCaCertificate("Throwaway CA");
        var issuer = new CertificateGenerator.Issuer(gen.parseCertificate(ca.certificatePem()), gen.parsePrivateKey(ca.privateKeyPem()));
        Path leaf = writeCert(tempDir.resolve("leaf.crt"),
                gen.generateIssuedCertificate("floci-leaf", List.of(), KeyAlgorithm.RSA_2048, null, issuer,
                        CertificateGenerator.LeafUsage.SERVER).certificatePem());
```

Do the same at `isSelfSignedCaCertificate_falseForLeafCert` (around line 129 to 134) if it also calls `generateCertificate`.

- [x] **Step 4: Run everything that compiles against `CertificateGenerator`**

Run: `./mvnw test -Dtest='CertificateGenerator*Test,TlsIntegrationTest,TlsCertificateHostnameTest,ContainerLauncherCaTrustTest,Acm*Test,CloudHsmV2IntegrationTest,RdsProxyTlsCertificatesTest'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add -A src/main/java/io/github/hectorvent/floci/services/acm/CertificateGenerator.java src/test
git commit -m "refactor(acm): drop the cosmetic Amazon issuer generator

Its only production caller now issues from the local CA. Tests that wanted
'a leaf that is not a CA' build one from a throwaway CA instead."
```

### Task 4: Docs and PR

- [x] **Step 1: `docs/services/acm.md` Emulation Behavior (lines 29 to 35)**

Replace the "Real Cryptography" bullet with two bullets:

```markdown
- **Real Cryptography:** Certificates are generated with real RSA/EC keys and valid X.509 structure
- **One Local CA:** Every issued certificate (`AMAZON_ISSUED` and `PRIVATE`) is signed by Floci's local root CA, and `GetCertificate` returns that CA as `CertificateChain`. Trust it once (`GET /_floci/ca.pem`) and both Floci's HTTPS endpoint and every ACM certificate validate. `ImportCertificate` keeps the chain you upload.
```

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/acm.md
git commit -m "docs(acm): certificates chain to the local CA"
```

```
ACM certificates were self-signed with a cosmetic "CN=Amazon" issuer DN, and CertificateChain
was a bundled Amazon root that had nothing to do with them. A client that trusted the chain
(the documented AWS contract) could not validate the leaf.

- RequestCertificate issues a server leaf (serverAuth + clientAuth) from Floci's local CA for both AMAZON_ISSUED
  and PRIVATE, honouring the requested KeyAlgorithm; CertificateChain is the CA PEM (same
  bytes as GET /_floci/ca.pem). Issuer in DescribeCertificate is the CA's DN.
- The bundled amazon-root-ca.pem and its startup validator are removed.
- CertificateGenerator.generateCertificate (cosmetic issuer) is deleted; tests that wanted a
  plain leaf build one from a throwaway CA.

Tests: AcmIntegrationTest.getCertificate verifies leaf against chain and chain == /_floci/ca.pem;
privateCertificateChainsToTheSameCa does the same for PRIVATE; AcmImportExportTest unchanged.
Depends on the local CA PR.
```

---

## Self-review

- Spec coverage: AMAZON_ISSUED and PRIVATE signed by CA with serverAuth (Task 2); chain = CA PEM (Task 2); issuer DN = CA's (falls out of `generateIssuedCertificate`, asserted via `chain.getSubject == leaf.getIssuer`); `AcmService:185` chain (Task 2); delete `amazon-root-ca.pem`, `validateRootCaResource`, `getAwsRootCa` (Task 2); tests chain parses and leaf verifies for both types, ExportCertificate returns same chain (Task 1 + existing `AcmImportExportTest`); docs (Task 4). Extra: Task 3 deletes the now-dead `generateCertificate` method and `ISSUER_DN`, as the spec's "replace ISSUER_DN line 53" asks (the generator class itself stays).
- Placeholders: none.
- Type consistency: `FlociCertificateAuthority.issueServerCertificate(String, List<String>, KeyAlgorithm, KeyPair)` and `caPem()` as defined in PR 3; `CertificateGenerator.Issuer`, `LeafUsage`, `generateCaCertificate`, `generateIssuedCertificate` as defined in PR 2. `AcmService` keeps its `CertificateGenerator` for import, export and key detection; the earlier draft of this plan removed the field and would not have compiled (adversarial review finding).
