# PR 2: `refactor(acm): one issuer-signing primitive in CertificateGenerator` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give `CertificateGenerator` one primitive that signs a certificate with an arbitrary issuer key, expose a CA generator and an issued-leaf generator on top of it, and delete the private copy of the same code in `CloudHsmV2Service`.

**Architecture:** `CertificateGenerator.buildCertificate` (line 113) always signs with the subject's own key. It becomes a thin wrapper over a new public `signCertificate(subject, subjectKey, issuerDn, issuerKey, sans, asCa, usage)`. Two new public methods use it: `generateCaCertificate(commonName)` and `generateIssuedCertificate(domainName, sans, alg, keyPair, issuer, usage)`. Existing public methods keep their signatures and output. `CloudHsmV2Service.generateCert` (line 537) is deleted and its three call sites use the shared primitive.

**Tech Stack:** BouncyCastle `bcpkix-jdk18on` (already a dependency), JUnit 5.

**Branch:** `refactor/certificate-generator-issuer` from `upstream/main`. Depends on nothing.

---

## File structure

- Modify: `SRC/services/acm/CertificateGenerator.java` (core of the change)
- Modify: `SRC/services/cloudhsmv2/CloudHsmV2Service.java:170-187, 531-554` (delete `generateCert`, inject `CertificateGenerator`)
- Create: `TEST/services/acm/CertificateGeneratorIssuerTest.java`
- Unchanged, regression proof: `TEST/services/acm/CertificateGeneratorSelfSignedTest.java`, `TEST/services/cloudhsmv2/CloudHsmV2IntegrationTest.java`

---

### Task 1: The failing tests for the new API

**Files:**
- Create: `TEST/services/acm/CertificateGeneratorIssuerTest.java`

- [x] **Step 1: Write the test**

```java
package io.github.hectorvent.floci.services.acm;

import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CertificateGeneratorIssuerTest {

    private static CertificateGenerator generator;

    @BeforeAll
    static void setup() {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
        generator = new CertificateGenerator();
    }

    @Test
    void caCertificateIsSelfSignedAndCanSign() throws Exception {
        var ca = generator.generateCaCertificate("Floci Local CA");
        X509Certificate cert = generator.parseCertificate(ca.certificatePem());

        assertEquals(cert.getSubjectX500Principal(), cert.getIssuerX500Principal());
        assertTrue(cert.getBasicConstraints() >= 0, "CA must carry cA=true");
        assertTrue(cert.getKeyUsage()[5], "CA must assert keyCertSign");
        assertNull(cert.getExtendedKeyUsage(), "a CA carries no EKU");
        cert.verify(cert.getPublicKey());
    }

    @Test
    void issuedLeafVerifiesAgainstIssuerAndCarriesServerAuth() throws Exception {
        var ca = generator.generateCaCertificate("Floci Local CA");
        var issuer = new CertificateGenerator.Issuer(
                generator.parseCertificate(ca.certificatePem()), generator.parsePrivateKey(ca.privateKeyPem()));

        var leaf = generator.generateIssuedCertificate("api.example.test", List.of("*.example.test"),
                KeyAlgorithm.RSA_2048, null, issuer, CertificateGenerator.LeafUsage.SERVER);
        X509Certificate cert = generator.parseCertificate(leaf.certificatePem());

        assertEquals(issuer.certificate().getSubjectX500Principal(), cert.getIssuerX500Principal());
        assertNotEquals(cert.getSubjectX500Principal(), cert.getIssuerX500Principal());
        assertEquals(-1, cert.getBasicConstraints(), "leaf must not be a CA");
        assertEquals(List.of("1.3.6.1.5.5.7.3.1", "1.3.6.1.5.5.7.3.2"), cert.getExtendedKeyUsage(),
                "serverAuth and clientAuth, as ACM issues and DescribeCertificate advertises");
        assertEquals(cert.getSigAlgName(), leaf.signatureAlgorithm(), "metadata reports the real signature algorithm");
        assertTrue(leaf.serialNumber().matches("([0-9a-f]{2}:)+[0-9a-f]{2}"), "colon-separated hex serial: " + leaf.serialNumber());
        assertEquals(cert.getSerialNumber(), new java.math.BigInteger(leaf.serialNumber().replace(":", ""), 16));
        cert.verify(issuer.certificate().getPublicKey());
        assertEquals(issuer.certificate().getSubjectX500Principal().getName(), leaf.issuer());
    }

    @Test
    void issuedLeafReusesSuppliedKeyPairAndClientUsage() throws Exception {
        var ca = generator.generateCaCertificate("Floci Local CA");
        var issuer = new CertificateGenerator.Issuer(
                generator.parseCertificate(ca.certificatePem()), generator.parsePrivateKey(ca.privateKeyPem()));
        var first = generator.generateIssuedCertificate("device-1", List.of(), KeyAlgorithm.RSA_2048, null, issuer,
                CertificateGenerator.LeafUsage.CLIENT);
        var keyPair = new java.security.KeyPair(
                generator.parseCertificate(first.certificatePem()).getPublicKey(),
                generator.parsePrivateKey(first.privateKeyPem()));

        var second = generator.generateIssuedCertificate("device-1", List.of(), KeyAlgorithm.RSA_2048, keyPair, issuer,
                CertificateGenerator.LeafUsage.CLIENT);
        X509Certificate cert = generator.parseCertificate(second.certificatePem());

        assertEquals(keyPair.getPublic(), cert.getPublicKey(), "supplied key pair must be reused");
        assertEquals(List.of("1.3.6.1.5.5.7.3.2"), cert.getExtendedKeyUsage(), "clientAuth only");
    }

    @Test
    void existingSelfSignedAndAcmStylePathsAreUnchanged() throws Exception {
        var selfSigned = generator.generateSelfSignedCertificate("localhost", List.of("localhost"), KeyAlgorithm.RSA_2048);
        X509Certificate ss = generator.parseCertificate(selfSigned.certificatePem());
        assertEquals(ss.getSubjectX500Principal(), ss.getIssuerX500Principal());
        assertTrue(ss.getBasicConstraints() >= 0);

        var acmStyle = generator.generateCertificate("localhost", List.of("localhost"), KeyAlgorithm.RSA_2048);
        X509Certificate acm = generator.parseCertificate(acmStyle.certificatePem());
        assertTrue(acm.getIssuerX500Principal().getName().contains("Amazon"));
        assertEquals(-1, acm.getBasicConstraints());
    }
}
```

- [x] **Step 2: Run it and watch it fail to compile**

Run: `./mvnw test -Dtest=CertificateGeneratorIssuerTest`
Expected: COMPILATION ERROR, `cannot find symbol: method generateCaCertificate`, `class Issuer`, `LeafUsage`.

### Task 2: Add the primitive and the two generators

**Files:**
- Modify: `SRC/services/acm/CertificateGenerator.java`

- [x] **Step 1: Add the new types and imports**

After the `GeneratedCertificate` record (line 73), add:

```java
    /**
     * What an issued leaf is for. Decides the Extended Key Usage. A CA passes {@code null}.
     * {@code SERVER} carries both serverAuth and clientAuth, as ACM-issued certificates do (and as
     * {@code DescribeCertificate} already advertises); {@code CLIENT} is clientAuth only.
     */
    public enum LeafUsage { SERVER, CLIENT }

    /** A signer: the issuer's certificate (for its DN) and its private key. */
    public record Issuer(X509Certificate certificate, PrivateKey key) {}
```

Add these imports next to the existing BouncyCastle ones:

```java
import org.bouncycastle.asn1.x509.ExtendedKeyUsage;
import org.bouncycastle.asn1.x509.KeyPurposeId;
import org.bouncycastle.asn1.x500.style.BCStyle;
```

- [x] **Step 2: Add `generateCaCertificate` and `generateIssuedCertificate` after the second `generateSelfSignedCertificate` (line 111)**

```java
    /**
     * A root CA: self-signed, {@code cA=true}, {@code keyCertSign}, ten years. RSA 2048 because
     * every client in the emulator's reach accepts it and it keeps key generation under a second.
     */
    public GeneratedCertificate generateCaCertificate(String commonName) {
        try {
            KeyPair keyPair = generateKeyPair(KeyAlgorithm.RSA_2048);
            X500Name dn = new X500Name("CN=" + commonName);
            X509Certificate cert = signCertificate(dn, keyPair.getPublic(), dn, keyPair.getPrivate(),
                    List.of(), true, null, 3650);
            return toGenerated(cert, keyPair.getPrivate(), dn.toString(), dn.toString());
        } catch (Exception e) {
            LOG.error("Failed to generate CA certificate", e);
            throw new CertificateGenerationException("CA generation failed: " + e.getMessage(), e);
        }
    }

    /**
     * A leaf signed by {@code issuer}. {@code subjectKeyPair} may be {@code null} to mint a new
     * one; pass the previous pair to reissue with an updated SAN list and an unchanged public key.
     */
    public GeneratedCertificate generateIssuedCertificate(String domainName, List<String> sans,
                                                          KeyAlgorithm keyAlgorithm, KeyPair subjectKeyPair,
                                                          Issuer issuer, LeafUsage usage) {
        try {
            KeyPair keyPair = subjectKeyPair != null ? subjectKeyPair : generateKeyPair(keyAlgorithm);
            X500Name subject = new X500Name("CN=" + domainName);
            X500Name issuerDn = X500Name.getInstance(issuer.certificate().getSubjectX500Principal().getEncoded());
            List<String> allSans = new ArrayList<>();
            allSans.add(domainName);
            if (sans != null) {
                allSans.addAll(sans);
            }
            X509Certificate cert = signCertificate(subject, keyPair.getPublic(), issuerDn, issuer.key(),
                    allSans, false, usage, 365);
            return toGenerated(cert, keyPair.getPrivate(), subject.toString(),
                    issuer.certificate().getSubjectX500Principal().getName());
        } catch (Exception e) {
            LOG.error("Failed to generate issued certificate", e);
            throw new CertificateGenerationException("Certificate generation failed: " + e.getMessage(), e);
        }
    }

    /**
     * The one place a certificate is signed. Everything else in this class, and
     * {@code CloudHsmV2Service}, goes through here.
     *
     * @param sans   DNS names or IP addresses; empty for a CA
     * @param asCa   sets {@code BasicConstraints(cA)} and {@code keyCertSign}
     * @param usage  EKU for a leaf, {@code null} for a CA
     */
    public X509Certificate signCertificate(X500Name subject, PublicKey subjectKey, X500Name issuerDn,
                                           PrivateKey issuerKey, List<String> sans, boolean asCa,
                                           LeafUsage usage, int validityDays) throws Exception {
        Instant now = Instant.now();
        BigInteger serial = new BigInteger(128, SECURE_RANDOM);
        X509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
                issuerDn, serial, Date.from(now), Date.from(now.plus(validityDays, ChronoUnit.DAYS)),
                subject, subjectKey);

        if (sans != null && !sans.isEmpty()) {
            List<GeneralName> sanList = new ArrayList<>();
            for (String san : new LinkedHashSet<>(sans)) {
                sanList.add(toGeneralName(san));
            }
            certBuilder.addExtension(Extension.subjectAlternativeName, false,
                    new GeneralNames(sanList.toArray(new GeneralName[0])));
        }

        // keyEncipherment is an RSA key-transport bit; EC keys sign (and agree), they never encipher.
        int keyUsageBits = KeyUsage.digitalSignature;
        if ("RSA".equals(subjectKey.getAlgorithm())) {
            keyUsageBits |= KeyUsage.keyEncipherment;
        }
        if (asCa) {
            keyUsageBits |= KeyUsage.keyCertSign | KeyUsage.cRLSign;
        }
        certBuilder.addExtension(Extension.keyUsage, true, new KeyUsage(keyUsageBits));
        certBuilder.addExtension(Extension.basicConstraints, true, new BasicConstraints(asCa));
        if (usage == LeafUsage.SERVER) {
            certBuilder.addExtension(Extension.extendedKeyUsage, false, new ExtendedKeyUsage(
                    new KeyPurposeId[] {KeyPurposeId.id_kp_serverAuth, KeyPurposeId.id_kp_clientAuth}));
        } else if (usage == LeafUsage.CLIENT) {
            certBuilder.addExtension(Extension.extendedKeyUsage, false, new ExtendedKeyUsage(KeyPurposeId.id_kp_clientAuth));
        }

        String signatureAlgorithm = "EC".equals(issuerKey.getAlgorithm()) ? "SHA512withECDSA" : "SHA512WithRSA";
        ContentSigner signer = new JcaContentSignerBuilder(signatureAlgorithm)
                .setProvider(BouncyCastleProvider.PROVIDER_NAME)
                .build(issuerKey);
        X509CertificateHolder holder = certBuilder.build(signer);
        return new JcaX509CertificateConverter()
                .setProvider(BouncyCastleProvider.PROVIDER_NAME)
                .getCertificate(holder);
    }

    /**
     * Metadata comes from the certificate, not from the arguments: the signature algorithm is the
     * issuer's (an RSA CA signing an EC leaf yields SHA512WITHRSA), and ACM shows the serial as
     * colon-separated hex ({@code 07:71:71:f4:...}).
     */
    private GeneratedCertificate toGenerated(X509Certificate cert, PrivateKey key, String subjectDn,
                                             String issuerDn) throws Exception {
        return new GeneratedCertificate(
                toPem(cert),
                toPem(key),
                colonHex(cert.getSerialNumber()),
                cert.getNotBefore().toInstant(),
                cert.getNotAfter().toInstant(),
                subjectDn,
                issuerDn,
                cert.getSigAlgName());
    }

    static String colonHex(BigInteger serial) {
        String hex = serial.toString(16);
        if (hex.length() % 2 == 1) {
            hex = "0" + hex;
        }
        return String.join(":", hex.split("(?<=\\G..)"));
    }
```

Add `import java.util.LinkedHashSet;` to the imports. Every caller of `toGenerated` drops its
trailing `signatureAlgorithm` argument (and the local computing it): in `buildCertificate`,
`generateCaCertificate` and `generateIssuedCertificate`.

- [x] **Step 3: Route `buildCertificate` through the primitive**

Replace the body of `buildCertificate` (lines 113 to 195) with:

```java
    private GeneratedCertificate buildCertificate(String domainName, List<String> sans, KeyAlgorithm keyAlgorithm,
                                                  String issuerDn, boolean asCa, KeyPair suppliedKeyPair) {
        try {
            KeyPair keyPair = suppliedKeyPair != null ? suppliedKeyPair : generateKeyPair(keyAlgorithm);
            String subjectDn = "CN=" + domainName;
            List<String> allSans = new ArrayList<>();
            allSans.add(domainName);
            if (sans != null) {
                allSans.addAll(sans);
            }
            // Signed with the subject's own key, as before: generateCertificate keeps its cosmetic
            // Amazon issuer DN, generateSelfSignedCertificate keeps issuer == subject.
            X509Certificate cert = signCertificate(new X500Name(subjectDn), keyPair.getPublic(),
                    new X500Name(issuerDn), keyPair.getPrivate(), allSans, asCa, null, 365);
            return toGenerated(cert, keyPair.getPrivate(), subjectDn, issuerDn);
        } catch (Exception e) {
            LOG.error("Failed to generate certificate", e);
            throw new CertificateGenerationException("Certificate generation failed: " + e.getMessage(), e);
        }
    }
```

- [x] **Step 4: Make `toPem` public**

Change line 244 from `private String toPem(Object obj) throws Exception {` to
`public String toPem(Object obj) throws Exception {`.

- [x] **Step 5: Run the new test and the existing generator tests**

Run: `./mvnw test -Dtest='CertificateGenerator*Test'`
Expected: PASS for `CertificateGeneratorIssuerTest`, `CertificateGeneratorSelfSignedTest`, `CertificateGeneratorSanTypeTest`.

One thing to watch: `CertificateGeneratorSelfSignedTest.selfSignedCertificateIsItsOwnIssuerAndACa` checks `getKeyUsage()[5]` (keyCertSign). The new code also sets `cRLSign` (bit 6) for CAs; bit 5 is still set, so the assertion holds.

- [x] **Step 6: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/acm/CertificateGenerator.java src/test/java/io/github/hectorvent/floci/services/acm/CertificateGeneratorIssuerTest.java
git commit -m "refactor(acm): one issuer-signing primitive in CertificateGenerator

buildCertificate always signed with the subject's own key. signCertificate now
takes the issuer DN and key explicitly; generateCaCertificate and
generateIssuedCertificate sit on top of it, with serverAuth or clientAuth EKU on
leaves. Existing public methods keep their output."
```

### Task 3: Delete the private copy in CloudHSM

**Files:**
- Modify: `SRC/services/cloudhsmv2/CloudHsmV2Service.java:170-187, 531-554` and its constructor

- [x] **Step 1: Inject `CertificateGenerator`**

Find the `@Inject` constructor of `CloudHsmV2Service` and add a `CertificateGenerator certificateGenerator` parameter, stored in a `private final CertificateGenerator certificateGenerator;` field. Do the same on the package-private constructor if one exists, and update any test that constructs the service directly (grep `new CloudHsmV2Service(` under `src/test`; at the time of writing there are none, `CloudHsmV2IntegrationTest` is a `@QuarkusTest`).

Add the import: `import io.github.hectorvent.floci.services.acm.CertificateGenerator;`.

- [x] **Step 2: Replace the three `generateCert` calls (lines 174 to 184)**

```java
            KeyPair mfrKeyPair = generateKeyPair();
            X500Name mfrName = new X500Name("CN=HSM Manufacturer CA,O=AWS,C=US");
            certs.setManufacturerHardwareCertificate(certificateGenerator.toPem(certificateGenerator.signCertificate(
                    mfrName, mfrKeyPair.getPublic(), mfrName, mfrKeyPair.getPrivate(), List.of(), true, null, 365)));

            KeyPair awsKeyPair = generateKeyPair();
            X500Name awsName = new X500Name("CN=AWS CloudHSM Hardware CA,O=AWS,C=US");
            certs.setAwsHardwareCertificate(certificateGenerator.toPem(certificateGenerator.signCertificate(
                    awsName, awsKeyPair.getPublic(), mfrName, mfrKeyPair.getPrivate(), List.of(), true, null, 365)));

            KeyPair hsmKeyPair = generateKeyPair();
            X500Name hsmName = new X500Name("CN=HSM Instance " + clusterId + ",O=AWS,C=US");
            certs.setHsmCertificate(certificateGenerator.toPem(certificateGenerator.signCertificate(
                    hsmName, hsmKeyPair.getPublic(), awsName, awsKeyPair.getPrivate(), List.of(), false, null, 365)));
```

- [x] **Step 3: Delete `generateCert` (lines 537 to 554) and now-unused imports**

Remove the method. Then remove imports that only it used; the compiler tells you which
(`X509v3CertificateBuilder`, `JcaX509v3CertificateBuilder`, `ContentSigner`,
`JcaContentSignerBuilder`, `JcaX509CertificateConverter`, `X509CertificateHolder` may still be
used by `parsePemCertificate`; keep whatever still compiles). `generateKeyPair` stays: the CSR
path uses it.

- [x] **Step 4: Run the CloudHSM regression test**

Run: `./mvnw test -Dtest=CloudHsmV2IntegrationTest`
Expected: PASS. The chain assertions at lines 56 to 60 and the `generateCerts(csr)` path at 328 to 345 are the regression proof.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/cloudhsmv2/CloudHsmV2Service.java
git commit -m "refactor(cloudhsmv2): sign emulated hardware certificates through CertificateGenerator

Deletes the private generateCert copy; the shared primitive also marks the two
CA levels of the chain as CAs, which the old code did not."
```

### Task 4: Whole-module check

- [x] **Step 1: Compile and run the ACM and CloudHSM suites together**

Run: `./mvnw test -Dtest='Acm*Test,CertificateGenerator*Test,CloudHsmV2*Test'`
Expected: PASS.

- [x] **Step 2: PR body**

```
CertificateGenerator.buildCertificate always signed with the subject's own key, so nothing
in Floci could issue a certificate from a CA. CloudHsmV2Service had its own private copy of
the signing code to build its three-level hardware chain.

- signCertificate(subject, subjectKey, issuerDn, issuerKey, sans, asCa, usage, days) is the
  one signing primitive. buildCertificate routes through it; generateCertificate and both
  generateSelfSignedCertificate overloads keep their signatures and output.
- generateCaCertificate(cn): self-signed, cA=true, keyCertSign, ten years.
- generateIssuedCertificate(domain, sans, alg, keyPair?, issuer, usage): a leaf signed by an
  Issuer, serverAuth or clientAuth EKU, optional reuse of an existing key pair.
- CloudHsmV2Service.generateCert deleted; its three call sites use the shared primitive.

Metadata now matches ACM: Serial is colon-separated hex, SignatureAlgorithm is the certificate's
real one, EC leaves no longer claim keyEncipherment, and a SERVER leaf carries serverAuth plus
clientAuth as DescribeCertificate already advertised. CloudHsmV2IntegrationTest and
CertificateGeneratorSelfSignedTest pass unchanged. Groundwork for a local root CA (next PR).
```

---

## Self-review

- Spec coverage: overload taking issuer cert and key (Task 2, `generateIssuedCertificate` + `signCertificate`); `generateCaCertificate` (Task 2); EKU split (Task 2, spec PR 2 bullet 3); CloudHSM deletion (Task 3); tests for leaf-verifies-against-issuer and cA=true (Task 1).
- Type consistency: `Issuer(X509Certificate certificate, PrivateKey key)`, `LeafUsage.SERVER/CLIENT`, `signCertificate(X500Name, PublicKey, X500Name, PrivateKey, List<String>, boolean, LeafUsage, int)`, `generateIssuedCertificate(String, List<String>, KeyAlgorithm, KeyPair, Issuer, LeafUsage)`. Later plans use exactly these.
- `toPem` becomes public; PR 3 and PR 4 call it.
- Wire-visible metadata change, deliberate: `Serial` is colon-separated hex and `SignatureAlgorithm` is read off the certificate (both as ACM reports them). `AcmIntegrationTest` asserts neither value's format today; if a test does, update it to the ACM shape.
