# PR 1: `fix(acm): repair the certificate chain PEM` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the corrupt `src/main/resources/certs/amazon-root-ca.pem` with a certificate that parses, and make the ACM integration test fail on any future truncation.

**Architecture:** No code path changes. `AcmService.getAwsRootCa()` (line 723) reads the resource verbatim into `certificateChain`; the file is the bug. The lasting artifact is the test: `AcmIntegrationTest.getCertificate` parses the returned chain with `CertificateFactory` instead of checking a string prefix. PR 5 deletes the file later; the test survives.

**Tech Stack:** Java 25, Quarkus 3.37.4, RestAssured, `java.security.cert.CertificateFactory`, `openssl` on the dev box for a one-off check.

**Branch:** `fix/acm-chain-pem` from `upstream/main`. Depends on nothing.

**Ship or skip:** this is a hotfix with a short life. It makes the chain *parse*; it does not make
it *validate* (Floci's leaves are self-signed with a cosmetic issuer DN, so no chain could). PR 5
replaces the file with a live CA chain and deletes this one. Ship PR 1 only if PR 5 is more than a
few days out; otherwise fold Task 1's `CertificateFactory` assertion into PR 5 and skip the rest.

**Why it ships alone:** tklocal (TEOS) feeds this PEM to `x509.CertPool.AppendCertsFromPEM`, which returns false on the corrupt file, so `httputil.NewClient` returns nil and tklocal cannot build an HTTP client. Nothing in Floci catches it because the only assertion is `startsWith("-----BEGIN CERTIFICATE-----")`.

---

## File structure

- Modify: `src/main/resources/certs/amazon-root-ca.pem` (replace contents; keep the name, the replacement is the real Amazon Root CA 1 so the name becomes accurate)
- Modify: `src/test/java/io/github/hectorvent/floci/services/acm/AcmIntegrationTest.java:253-270`

---

### Task 1: Make the test fail on the corrupt file

**Files:**
- Modify: `TEST/services/acm/AcmIntegrationTest.java:253-270`

- [ ] **Step 1: Replace the prefix assertion with a parse**

Replace the `getCertificate` test body (lines 255 to 270) with:

```java
    @Test
    @Order(12)
    void getCertificate() throws Exception {
        String chain = given()
            .header("X-Amz-Target", "CertificateManager.GetCertificate")
            .contentType(ACM_CONTENT_TYPE)
            .body("""
                {
                    "CertificateArn": "%s"
                }
                """.formatted(createdCertificateArn))
        .when()
            .post("/")
        .then()
            .statusCode(200)
            .body("Certificate", startsWith("-----BEGIN CERTIFICATE-----"))
            .extract().jsonPath().getString("CertificateChain");

        // A truncated PEM still starts with the BEGIN marker; only a real parse catches it.
        java.security.cert.CertificateFactory factory = java.security.cert.CertificateFactory.getInstance("X.509");
        java.security.cert.Certificate parsed = factory.generateCertificate(
            new java.io.ByteArrayInputStream(chain.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));
        assertNotNull(parsed);
    }
```

Add to the imports at the top of the file:

```java
import static org.junit.jupiter.api.Assertions.assertNotNull;
```

- [ ] **Step 2: Run the test and watch it fail on the current file**

Run: `./mvnw test -Dtest=AcmIntegrationTest#getCertificate`
Expected: FAIL with `java.security.cert.CertificateException` (message contains `Could not parse certificate` or `Illegal base64 character`). If it passes, the file was already fixed on `upstream/main`; stop and re-check the branch base.

### Task 2: Replace the PEM

**Files:**
- Modify: `src/main/resources/certs/amazon-root-ca.pem`

- [ ] **Step 1: Confirm the corruption once, for the PR description**

Run:
```bash
openssl x509 -in src/main/resources/certs/amazon-root-ca.pem -noout -subject 2>&1 | head -2
awk 'NR>1 && !/-----/ && length($0)!=64 {print NR": "length($0)" chars"}' src/main/resources/certs/amazon-root-ca.pem
```
Expected: OpenSSL reports an error (`PEM routines::bad base64 decode` or `asn1 encoding routines`), and awk prints one interior line shorter than 64 characters.

- [ ] **Step 2: Download Amazon Root CA 1 and verify it before it touches the tree**

Run:
```bash
curl -sSf https://www.amazontrust.com/repository/AmazonRootCA1.pem -o /tmp/AmazonRootCA1.pem
openssl x509 -in /tmp/AmazonRootCA1.pem -noout -subject -fingerprint -sha256
```
Expected: `subject=C=US, O=Amazon, CN=Amazon Root CA 1` and fingerprint
`8E:CD:E6:88:4F:3D:87:B1:12:5B:A3:1A:C3:FC:B1:3D:70:16:DE:7F:57:CC:90:4F:E1:CB:97:C6:AE:98:19:6E`.
If the fingerprint differs, stop: do not commit a certificate you cannot account for.

- [ ] **Step 3: Replace the file**

Run:
```bash
cp /tmp/AmazonRootCA1.pem src/main/resources/certs/amazon-root-ca.pem
openssl x509 -in src/main/resources/certs/amazon-root-ca.pem -noout -subject
```
Expected: `subject=C=US, O=Amazon, CN=Amazon Root CA 1`.

- [ ] **Step 4: Run the test and watch it pass**

Run: `./mvnw test -Dtest=AcmIntegrationTest`
Expected: all tests in the class PASS, including `getCertificate`.

- [ ] **Step 5: Run the other ACM tests that read the chain**

Run: `./mvnw test -Dtest='Acm*Test'`
Expected: PASS. `AcmImportExportTest` exercises `ExportCertificate`, which copies `certificateChain`.

- [ ] **Step 6: Commit**

```bash
git add src/main/resources/certs/amazon-root-ca.pem src/test/java/io/github/hectorvent/floci/services/acm/AcmIntegrationTest.java
git commit -m "fix(acm): replace the corrupt certificate chain PEM and parse it in the test

The bundled chain had one 63-character base64 line, so the payload was 1 mod 4
and no X.509 parser accepted it. GetCertificate and ExportCertificate returned
it verbatim. The test only asserted the BEGIN marker, which a truncated file
passes; it now parses the chain with CertificateFactory."
```

### Task 3: PR description

- [ ] **Step 1: Open the PR with this body**

```
The chain PEM at src/main/resources/certs/amazon-root-ca.pem was corrupt: one interior
base64 line carried 63 characters, so the payload length was 1 mod 4 and OpenSSL, Java and
Go all reject it. It reached every GetCertificate and ExportCertificate caller verbatim.

- Replaced with Amazon Root CA 1 (sha256 fingerprint 8E:CD:E6:88:...:98:19:6E, from
  amazontrust.com), so the file name is now accurate as well.
- AcmIntegrationTest.getCertificate parses the returned chain with CertificateFactory
  instead of checking a string prefix, so a truncated file fails the build.

No behaviour change beyond the chain being a valid certificate.
```

---

## Self-review

- Spec coverage: both bullets of PR 1 in the spec (replace the file, replace the assertion) map to Task 2 and Task 1.
- No placeholders.
- The only type referenced is `CertificateFactory` from the JDK.
