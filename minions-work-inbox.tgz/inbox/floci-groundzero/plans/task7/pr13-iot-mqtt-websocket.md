# PR 13: `feat(iot): MQTT over WebSocket at /mqtt` Implementation Plan

> **Status 2026-09-06:** implemented as #3150 (head 424bebb7e), every step below done. Deviations, all from reading the vertx-core 4.5.30 sources: the bridge uses one `frameHandler` (text closes 1003, binary and continuation frames are written, control frames left to Vert.x) with back-pressure both ways instead of `binaryMessageHandler`; a `ws.isClosed()` guard covers the client-closed-while-connecting window; the lazy `startIfEnabled()` runs on an unordered `executeBlocking` because it blocks on `listen()` and router handlers are on the event loop. Two extra test classes (`IotMqttWebSocketContractIntegrationTest`, `IotMqttWebSocketFramingIntegrationTest`) cover the AWS handshake and MQTT 3.1.1 section 6 framing. Fixture dir is `target/floci-iot-mqtt-ws-test`, not `/tmp`.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A client dialing `wss://<host>:443/mqtt` (what AWS IoT serves for browsers, the Device SDK's WebSocket transport and secure tunnelling, and what TEOS's `tklocal` tunnel dials) gets an MQTT session from Floci on the same port, path and certificate as HTTPS, with no extra listener and no new config.

**Architecture:** One `@ApplicationScoped` bean, `IotMqttWebSocketBridge`, registers a Vert.x Web route for exactly `/mqtt` through the same `@Observes Router` hook `WebSocketHandler` (API Gateway v2) already uses. On a WebSocket upgrade it opens a `NetClient` connection to the broker's own plaintext listener (`floci.services.iot.mqtt.port`, default 1883) and pipes binary frames both ways, so every broker feature and every future authorization rule (PR 11 and its follow-ups) applies unchanged. Because it lives on the Quarkus HTTP and HTTPS servers, `wss://` gets the CA-issued leaf from PR 3, hostnames learned through PR 6 and the `443:4566` mapping PR 12 documents, for free. The only server-wide change is echoing the `Sec-WebSocket-Protocol` MQTT names from `HttpOptionsCustomizer`, which Paho and the AWS Device SDKs require.

**Tech Stack:** Vert.x Web `Router` observer, `HttpServerRequest.toWebSocket()`, `Vertx.createNetClient()`, `HttpServerOptions.setWebSocketSubProtocols` (all verified against vertx-core 4.5.30 and vertx-web on the classpath), Paho mqttv3 1.2.5 `ws://` and `wss://` in tests, `java.net.http.WebSocket` for the negative handshake test.

**Branch:** `feat/iot-mqtt-websocket` from `upstream/main` after PR 3 merges. The bridge itself needs only the existing broker; PR 3 supplies `FlociCertificateAuthority`, which the `wss://` test uses to trust the Floci CA and nothing else. Independent of PRs 8, 11 and 12 (they can merge in any order; Task 1 notes the one profile line that changes if PR 8 has landed). Supersedes the earlier design of a third `MqttServer` on 8884: no `ws-tls-port`, no `FLOCI_SERVICES_IOT_MQTT_WS_TLS_PORT`, no 8884 anywhere.

Verified against the jars in `~/.m2`: `HttpServerOptions.setWebSocketSubProtocols(List<String>)`; `ServerWebSocket` (via `WebSocketBase`) has `pause()`, `resume()`, `binaryMessageHandler(Handler<Buffer>)`, `textMessageHandler(Handler<String>)`, `writeBinaryMessage(Buffer): Future<Void>`, `closeHandler`, `exceptionHandler`, `isClosed()`, `close()`, `close(short, String)`; `HttpServerRequest.toWebSocket(): Future<ServerWebSocket>`; `NetClient.connect(int, String): Future<NetSocket>`; `NetSocket.handler`, `write(Buffer): Future<Void>`, `closeHandler`, `exceptionHandler`, `close()`. Netty 4.1.136 `WebSocketServerHandshaker13` logs "Requested subprotocol(s) not supported" and completes the handshake without the header when a client asks for a subprotocol the server did not list, so the API Gateway v2 WebSocket clients are unaffected by Task 2. Paho 1.2.5 `WebSocketHandshake` fails with "WebSocket Response header: empty sec-websocket-protocol" when the server does not echo `mqtt`, which is why Task 2 exists.

---

## File structure

`SRC` = `src/main/java/io/github/hectorvent/floci`, `TEST` = `src/test/java/io/github/hectorvent/floci`.

- Create: `SRC/services/iot/IotMqttWebSocketBridge.java` (route `/mqtt`, upgrade, pipe to the plaintext broker listener)
- Modify: `SRC/config/HttpOptionsCustomizer.java` (echo MQTT subprotocols on both servers)
- Create: `TEST/services/iot/IotMqttWebSocketIntegrationTest.java` (`@QuarkusTest`, Paho over `wss://` and `ws://`, negative handshakes)
- Modify: `docs/services/iot.md` (new "MQTT over WebSocket" subsection)

No `EmulatorConfig`, `application.yml` or `pom.xml` changes.

---

### Task 1: The failing integration test

**Files:**
- Create: `TEST/services/iot/IotMqttWebSocketIntegrationTest.java`

- [x] **Step 1: Write the test**

The profile is the same shape PR 8 uses: TLS on with a CA-issued leaf laid down on disk under `quarkus.tls.key-store.pem.0.*`, because `TlsConfigSource` reads system properties and not profile overrides. HTTPS is served on `quarkus.http.test-ssl-port` and HTTP on `quarkus.http.test-port`, exactly as `TlsIntegrationTest` and `TlsEnsureHostIntegrationTest` (PR 6) use them. The broker's plaintext listener is bound to `127.0.0.1:18836` so nothing collides with a developer's 1883.

```java
package io.github.hectorvent.floci.services.iot;

import io.github.hectorvent.floci.config.CertificateMetadata;
import io.github.hectorvent.floci.config.FlociCertificateAuthority;
import io.github.hectorvent.floci.services.acm.model.KeyAlgorithm;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.junit.jupiter.api.Test;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.net.http.WebSocketHandshakeException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@QuarkusTest
@TestProfile(IotMqttWebSocketIntegrationTest.Profile.class)
class IotMqttWebSocketIntegrationTest {

    static final Path DATA_DIR = Path.of("/tmp/floci-iot-mqtt-ws-test");
    static final Path TLS_DIR = DATA_DIR.resolve("tls");
    static final int PLAIN_PORT = 18836;

    @ConfigProperty(name = "quarkus.http.test-ssl-port")
    int testSslPort;

    @ConfigProperty(name = "quarkus.http.test-port")
    int testHttpPort;

    @Test
    void connectSubscribePublishOverWssTrustingOnlyTheFlociCa() throws Exception {
        String topic = "teos/ws/" + System.nanoTime();
        byte[] payload = "over websocket".getBytes(StandardCharsets.UTF_8);

        try (WsClient subscriber = WsClient.connect("wss://127.0.0.1:" + testSslPort + "/mqtt", "ws-sub-" + System.nanoTime(), null, null)) {
            subscriber.subscribe(topic);
            try (WsClient publisher = WsClient.connect("wss://127.0.0.1:" + testSslPort + "/mqtt", "ws-pub-" + System.nanoTime(), null, null)) {
                publisher.publish(topic, payload);
            }
            assertArrayEquals(payload, subscriber.takePayload());
        }
    }

    @Test
    void plainWebSocketWorksOnTheHttpPort() throws Exception {
        try (WsClient client = WsClient.connect("ws://127.0.0.1:" + testHttpPort + "/mqtt", "ws-plain-" + System.nanoTime(), null, null)) {
            assertTrue(client.isConnected());
        }
    }

    @Test
    void customAuthorizerStyleConnectIsAccepted() throws Exception {
        String clientId = "tklocal-" + System.nanoTime();
        String username = clientId + "?x-amz-customauthorizer-name=teos-authorizer";
        try (WsClient client = WsClient.connect("wss://127.0.0.1:" + testSslPort + "/mqtt", clientId, username, "token-" + System.nanoTime())) {
            assertTrue(client.isConnected());
        }
    }

    @Test
    void wrongPathIsNotAnMqttEndpoint() {
        HttpClient http = HttpClient.newHttpClient();
        ExecutionException failure = assertThrows(ExecutionException.class, () -> http.newWebSocketBuilder()
                .subprotocols("mqtt")
                .buildAsync(URI.create("ws://127.0.0.1:" + testHttpPort + "/not-mqtt"), new WebSocket.Listener() { })
                .get(10, TimeUnit.SECONDS));
        WebSocketHandshakeException handshake = assertInstanceOf(WebSocketHandshakeException.class, failure.getCause());
        assertEquals(404, handshake.getResponse().statusCode());
    }

    @Test
    void plainGetOnTheMqttPathIsNotAnUpgrade() throws Exception {
        HttpResponse<String> response = HttpClient.newHttpClient().send(
                HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + testHttpPort + "/mqtt")).GET().build(),
                HttpResponse.BodyHandlers.ofString());
        assertEquals(404, response.statusCode());
    }

    @Test
    void plaintextTcpListenerStillWorks() throws Exception {
        MqttClient client = new MqttClient("tcp://127.0.0.1:" + PLAIN_PORT, "tcp-" + System.nanoTime(), new MemoryPersistence());
        client.connect();
        assertTrue(client.isConnected());
        client.disconnect();
        client.close();
    }

    private static SSLContext trustOnlyFlociCa() throws Exception {
        KeyStore trust = KeyStore.getInstance(KeyStore.getDefaultType());
        trust.load(null, null);
        trust.setCertificateEntry("floci", FlociCertificateAuthority.loadOrCreate(TLS_DIR).certificate());
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trust);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, tmf.getTrustManagers(), null);
        return ctx;
    }

    private static final class WsClient implements AutoCloseable {
        private final MqttClient client;
        private final BlockingQueue<byte[]> payloads = new LinkedBlockingQueue<>();

        private WsClient(MqttClient client) {
            this.client = client;
        }

        static WsClient connect(String url, String clientId, String username, String password) throws Exception {
            MqttClient client = new MqttClient(url, clientId, new MemoryPersistence());
            WsClient wsClient = new WsClient(client);
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) {
                    wsClient.payloads.add(message.getPayload());
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                }
            });
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setConnectionTimeout(10);
            if (url.startsWith("wss://")) {
                options.setSocketFactory(trustOnlyFlociCa().getSocketFactory());
            }
            if (username != null) {
                options.setUserName(username);
                options.setPassword(password.toCharArray());
            }
            client.connect(options);
            return wsClient;
        }

        boolean isConnected() {
            return client.isConnected();
        }

        void subscribe(String topic) throws MqttException {
            client.subscribe(topic, 1);
        }

        void publish(String topic, byte[] payload) throws MqttException {
            client.publish(topic, payload, 1, false);
        }

        byte[] takePayload() throws InterruptedException {
            byte[] payload = payloads.poll(10, TimeUnit.SECONDS);
            assertNotNull(payload, "no publish received over WebSocket within 10s");
            return payload;
        }

        @Override
        public void close() throws MqttException {
            if (client.isConnected()) {
                client.disconnect();
            }
            client.close();
        }
    }

    /**
     * TLS on with a CA-issued leaf on disk, exactly what TlsConfigSource produces in production.
     * TlsConfigSource reads system properties, not profile overrides, so the profile lays the files
     * down and points the TLS registry at them. The broker's plaintext listener is the bridge's target.
     */
    public static final class Profile implements QuarkusTestProfile {

        static {
            try {
                Files.createDirectories(TLS_DIR);
                for (String name : List.of("floci-server.crt", "floci-server.key", "floci-server.metadata.json")) {
                    Files.deleteIfExists(TLS_DIR.resolve(name));
                }
                FlociCertificateAuthority ca = FlociCertificateAuthority.loadOrCreate(TLS_DIR);
                List<String> sans = List.of("localhost", "127.0.0.1", "*.localhost.floci.io");
                var leaf = ca.issueServerCertificate("localhost", sans, KeyAlgorithm.RSA_2048, null);
                Files.writeString(TLS_DIR.resolve("floci-server.crt"), leaf.certificatePem());
                Files.writeString(TLS_DIR.resolve("floci-server.key"), leaf.privateKeyPem());
                Files.writeString(TLS_DIR.resolve("floci-server.metadata.json"),
                        new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(CertificateMetadata.create(sans, "dev")));
            } catch (IOException e) {
                throw new IllegalStateException("could not prepare TLS fixtures", e);
            }
        }

        @Override
        public Map<String, String> getConfigOverrides() {
            return Map.ofEntries(
                    Map.entry("floci.tls.enabled", "true"),
                    Map.entry("floci.tls.self-signed", "true"),
                    Map.entry("floci.storage.persistent-path", DATA_DIR.toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.cert", TLS_DIR.resolve("floci-server.crt").toString()),
                    Map.entry("quarkus.tls.key-store.pem.0.key", TLS_DIR.resolve("floci-server.key").toString()),
                    Map.entry("quarkus.http.insecure-requests", "enabled"),
                    Map.entry("floci.services.iot.mqtt.enabled", "true"),
                    Map.entry("floci.services.iot.mqtt.auto-start", "true"),
                    Map.entry("floci.services.iot.mqtt.host", "127.0.0.1"),
                    Map.entry("floci.services.iot.mqtt.port", Integer.toString(PLAIN_PORT)));
        }
    }
}
```

If PR 8 has merged, `floci.tls.enabled=true` also starts its MQTT-over-TLS listener on the default 8883, which may be taken on a developer machine. In that case add one entry to `getConfigOverrides()`, next to the `port` entry:

```java
                    Map.entry("floci.services.iot.mqtt.tls-port", "18887"),
```

If PR 8 has not merged, leave it out: the key does not exist yet.

`WebSocket.Listener` is an interface whose methods all have defaults, so `new WebSocket.Listener() { }` is a complete listener. `subprotocols("mqtt")` on the negative test makes the failing handshake identical to what Paho sends, so a 404 there proves the server routes on path, not on the subprotocol.

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=IotMqttWebSocketIntegrationTest`
Expected: FAIL. `connectSubscribePublishOverWssTrustingOnlyTheFlociCa`, `plainWebSocketWorksOnTheHttpPort` and `customAuthorizerStyleConnectIsAccepted` fail with `MqttException` (Paho reports the 404 handshake response, or "empty sec-websocket-protocol" once Task 3 lands before Task 2). `wrongPathIsNotAnMqttEndpoint` and `plainGetOnTheMqttPathIsNotAnUpgrade` pass for the wrong reason (nothing serves `/mqtt` either), and `plaintextTcpListenerStillWorks` passes.

- [x] **Step 3: Commit the failing test**

```bash
git add src/test/java/io/github/hectorvent/floci/services/iot/IotMqttWebSocketIntegrationTest.java
git commit -m "test(iot): MQTT over WebSocket at /mqtt, failing"
```

---

### Task 2: Echo the MQTT subprotocols

**Files:**
- Modify: `SRC/config/HttpOptionsCustomizer.java`

- [x] **Step 1: Add the subprotocol list to both servers**

`HttpOptionsCustomizer` already configures both the HTTP and the HTTPS server (`customizeHttpServer`, `customizeHttpsServer`). Add the import, the constant and one line in each method:

```java
import java.util.List;
```

```java
    /**
     * Subprotocol names an MQTT-over-WebSocket client offers in Sec-WebSocket-Protocol. Vert.x only
     * echoes a name that is in this list, and Paho and the AWS Device SDKs refuse a handshake whose
     * response does not echo one. Netty completes handshakes that ask for other names without the
     * header, so API Gateway WebSocket clients are unaffected.
     */
    static final List<String> MQTT_WEBSOCKET_SUBPROTOCOLS = List.of("mqtt", "mqttv3.1", "mqttv3.1.1");
```

```java
    @Override
    public void customizeHttpServer(HttpServerOptions options) {
        options.setMaxFormAttributeSize(-1);
        options.setMaxWebSocketFrameSize(MAX_WS_FRAME_SIZE);
        options.setMaxWebSocketMessageSize(MAX_WS_MESSAGE_SIZE);
        options.setWebSocketSubProtocols(MQTT_WEBSOCKET_SUBPROTOCOLS);
    }

    @Override
    public void customizeHttpsServer(HttpServerOptions options) {
        options.setMaxFormAttributeSize(-1);
        options.setMaxWebSocketFrameSize(MAX_WS_FRAME_SIZE);
        options.setMaxWebSocketMessageSize(MAX_WS_MESSAGE_SIZE);
        options.setWebSocketSubProtocols(MQTT_WEBSOCKET_SUBPROTOCOLS);
    }
```

The 256 KB frame and message limits stay: AWS IoT caps an MQTT payload at 128 KB, and an MQTT packet fits in one WebSocket message.

- [x] **Step 2: Prove the API Gateway WebSocket path is untouched**

Run: `./mvnw test -Dtest='WebSocketConnectionLifecycleTest,WebSocketAwsHttpIntegrationTest,ApiGatewayV2WebSocketIntegrationTest'`
Expected: PASS, same counts as before this change. These clients do not ask for a subprotocol, so the new list never applies to them.

- [x] **Step 3: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/HttpOptionsCustomizer.java
git commit -m "feat(http): echo MQTT WebSocket subprotocols"
```

---

### Task 3: The bridge

**Files:**
- Create: `SRC/services/iot/IotMqttWebSocketBridge.java`

- [x] **Step 1: Write the bridge**

Same package as `IotMqttBrokerService`, so its package-private `startIfEnabled()` (already `synchronized` and idempotent; `IotService` calls it the same way) is reachable and a `wss://.../mqtt` connect works before any IoT API call has warmed the broker.

```java
package io.github.hectorvent.floci.services.iot;

import io.github.hectorvent.floci.config.EmulatorConfig;
import io.vertx.core.Vertx;
import io.vertx.core.http.ServerWebSocket;
import io.vertx.core.net.NetSocket;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;

/**
 * Serves MQTT over WebSocket at {@code /mqtt} on the HTTP and HTTPS ports, the path and port AWS IoT
 * uses for browser clients, the Device SDK's WebSocket transport and secure tunnelling. Frames are
 * piped byte for byte to the broker's plaintext listener, so every broker feature and every
 * authorization rule applies without a second code path. No client certificate is involved: on AWS
 * this path authenticates by SigV4 or a custom authorizer, and the broker stays permissive for it.
 */
@ApplicationScoped
public class IotMqttWebSocketBridge {

    static final String PATH = "/mqtt";
    private static final Logger LOG = Logger.getLogger(IotMqttWebSocketBridge.class);
    private static final short CLOSE_UNSUPPORTED_DATA = 1003;

    private final EmulatorConfig config;
    private final Vertx vertx;
    private final IotMqttBrokerService broker;

    @Inject
    public IotMqttWebSocketBridge(EmulatorConfig config, Vertx vertx, IotMqttBrokerService broker) {
        this.config = config;
        this.vertx = vertx;
        this.broker = broker;
    }

    void init(@Observes Router router) {
        router.route(PATH).handler(this::upgrade);
    }

    private void upgrade(RoutingContext ctx) {
        if (!"websocket".equalsIgnoreCase(ctx.request().getHeader("Upgrade"))) {
            ctx.next();
            return;
        }
        broker.startIfEnabled();
        if (!broker.isRunning()) {
            ctx.response().setStatusCode(503).end();
            return;
        }
        ctx.request().toWebSocket()
                .onSuccess(this::pipeToBroker)
                .onFailure(error -> LOG.debugv("MQTT WebSocket upgrade failed: {0}", error.getMessage()));
    }

    private void pipeToBroker(ServerWebSocket ws) {
        ws.pause();
        vertx.createNetClient().connect(config.services().iot().mqtt().port(), brokerHost())
                .onSuccess(socket -> {
                    wire(ws, socket);
                    ws.resume();
                })
                .onFailure(error -> {
                    LOG.warnv("MQTT WebSocket bridge could not reach the broker on {0}:{1}: {2}",
                            brokerHost(), config.services().iot().mqtt().port(), error.getMessage());
                    closeQuietly(ws);
                });
    }

    private static void wire(ServerWebSocket ws, NetSocket socket) {
        ws.binaryMessageHandler(frame -> socket.write(frame));
        ws.textMessageHandler(ignored -> ws.close(CLOSE_UNSUPPORTED_DATA, "MQTT over WebSocket is binary"));
        ws.closeHandler(ignored -> socket.close());
        ws.exceptionHandler(error -> socket.close());
        socket.handler(bytes -> ws.writeBinaryMessage(bytes));
        socket.closeHandler(ignored -> closeQuietly(ws));
        socket.exceptionHandler(error -> closeQuietly(ws));
    }

    private String brokerHost() {
        String host = config.services().iot().mqtt().host();
        return "0.0.0.0".equals(host) ? "127.0.0.1" : host;
    }

    private static void closeQuietly(ServerWebSocket ws) {
        if (!ws.isClosed()) {
            ws.close();
        }
    }
}
```

Why each piece is there:

- `ctx.next()` on a non-upgrade request hands `/mqtt` to JAX-RS, which answers the same 404 it gives any unknown root path (S3's path-style `GET /{bucket}` returns `NoSuchBucket`). No new HTTP endpoint shape.
- `ws.pause()` before the broker connect: Paho sends CONNECT the instant the handshake completes; without the pause that first frame could arrive before `binaryMessageHandler` is attached and be dropped. `WebSocketBase` buffers paused frames and replays them on `resume()`.
- `brokerHost()`: the broker binds `0.0.0.0` by default, which is not a valid connect target on every platform; loopback is.
- Text frames close with 1003 (unsupported data); MQTT over WebSocket is binary only (AWS IoT and the MQTT spec agree).
- Both directions close the other side on close or error, so a stopped broker (`IotMqttBrokerService.stop()` closes its endpoints) drops the WebSocket, and a vanished WebSocket frees the broker session.
- 503 when the broker is disabled (`floci.services.iot.mqtt.enabled=false`) rather than accepting an upgrade that can only fail.

`WebSocketHandler` (API Gateway v2) also registers `/:stage`, which matches `/mqtt`; it calls `ctx.next()` for any host that is not an execute-api host, so the two routes coexist regardless of observer order. The bridge does not check the host: AWS IoT's WebSocket endpoint is host-agnostic on Floci (`<account>-ats.iot.<region>.localhost.floci.io`, a domain configuration name, or `localhost` all reach the same broker).

- [x] **Step 2: Run the test to verify it passes**

Run: `./mvnw test -Dtest=IotMqttWebSocketIntegrationTest`
Expected: PASS, 6 tests. `connectSubscribePublishOverWssTrustingOnlyTheFlociCa` proves the handshake trusts nothing but the Floci CA and that a publish crosses the bridge in both directions; `customAuthorizerStyleConnectIsAccepted` proves the TEOS tunnel's CONNECT shape (client id `tklocal-<rsid>`, username `<clientId>?x-amz-customauthorizer-name=<name>`, token as password) is accepted.

If `wrongPathIsNotAnMqttEndpoint` reports 101 instead of 404, the route pattern is wrong (must be exactly `/mqtt`, not `/mqtt/*`). If Paho fails with "empty sec-websocket-protocol", Task 2 is missing on the server that answered (both methods of `HttpOptionsCustomizer` must set the list).

- [x] **Step 3: Run the IoT and TLS neighbours**

Run: `./mvnw test -Dtest='IotIntegrationTest,IotMqttEnabledIntegrationTest,IotMqttDisabledIntegrationTest,IotMqttLazyStartupIntegrationTest,TlsIntegrationTest,WebSocketConnectionLifecycleTest'`
Expected: PASS, no count change. `IotMqttDisabledIntegrationTest` matters most: with the broker disabled the new bean must still start (it only observes the router) and `/mqtt` must not break anything else.

- [x] **Step 4: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/iot/IotMqttWebSocketBridge.java
git commit -m "feat(iot): MQTT over WebSocket at /mqtt

Bridges a WebSocket upgrade on /mqtt (HTTP and HTTPS) onto the broker's
plaintext listener, so wss://host:443/mqtt works on the 443:4566 mapping
with the same certificate as HTTPS and no extra listener or config."
```

---

### Task 4: Docs and PR

**Files:**
- Modify: `docs/services/iot.md`

- [x] **Step 1: Docs**

In `docs/services/iot.md`, add a subsection after the MQTT broker section (after PR 8's "MQTT over TLS" if it has merged, otherwise after the existing broker paragraph that mentions `IotMqttBrokerService`):

```markdown
### MQTT over WebSocket

The broker is also reachable as MQTT over WebSocket at `/mqtt` on Floci's HTTP and HTTPS ports
(`ws://<host>:4566/mqtt`, `wss://<host>:4566/mqtt`), the path AWS IoT serves on 443 for browser
clients, the AWS IoT Device SDK's WebSocket transport and secure tunnelling. With `443:4566`
published in Docker the AWS URL `wss://<endpoint>:443/mqtt` works unchanged. The handshake echoes
the `mqtt` subprotocol and uses the same certificate as HTTPS, so hostnames learned at runtime
apply to it too. Frames are piped to the plaintext MQTT listener, so every broker feature behaves
the same on both transports. There is no separate port or setting for it; disabling the broker
(`FLOCI_SERVICES_IOT_MQTT_ENABLED=false`) makes `/mqtt` answer 503 to an upgrade.

No client certificate is requested on this path. On AWS it authenticates by SigV4 or by a custom
authorizer (`<clientId>?x-amz-customauthorizer-name=<name>` as the MQTT username with a token as
the password); Floci accepts such a CONNECT as is and does not evaluate the authorizer yet.
```

If the page has a port table, do not add a row: `/mqtt` shares 4566. Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/iot.md
git commit -m "docs(iot): MQTT over WebSocket at /mqtt"
```

PR body:

```
Clients that dial wss://host:443/mqtt (AWS IoT's WebSocket endpoint: browsers, the Device SDK's
WebSocket transport, secure tunnelling, TEOS's tklocal tunnel) found no MQTT at Floci: a 443 to
4566 mapping lands on Quarkus HTTP, which answers 404.

- IotMqttWebSocketBridge registers /mqtt on the Vert.x Web router (same @Observes Router hook the
  API Gateway v2 WebSocket handler uses) and pipes WebSocket binary frames to the broker's own
  plaintext listener. One code path for every broker feature and every authorization rule.
- Served on the HTTP and HTTPS ports, so wss:// gets the CA-issued leaf, learned hostnames and
  the documented 443:4566 mapping for free. No new listener, port, config key or env var.
- HttpOptionsCustomizer echoes the mqtt, mqttv3.1 and mqttv3.1.1 subprotocols; Paho and the AWS
  Device SDKs refuse a handshake without the echo. Netty completes handshakes that ask for other
  names without the header, so API Gateway WebSocket clients are unaffected (their tests are in
  the run).
- No client certificate on this path: AWS authenticates it by SigV4 or custom authorizer. Floci
  accepts the CONNECT as is, including the ?x-amz-customauthorizer-name username form with a
  token password, and does not evaluate the authorizer yet (documented).
- Tests: Paho wss:// subscribe and publish trusting only the Floci CA, ws:// on the HTTP port,
  custom-authorizer-style CONNECT, wrong path is a 404 handshake not 101, plain GET /mqtt is a
  404, the plaintext TCP listener is unaffected.

Replaces the earlier idea of a third MqttServer on 8884: one port, one certificate, nothing new
to publish or configure.
```

---

## Self-review

- Spec coverage. `wss://<host>:443/mqtt` on the `443:4566` mapping with the HTTPS certificate (Task 3 on the Quarkus servers, docs in Task 4); path exactly `/mqtt` (route pattern plus `wrongPathIsNotAnMqttEndpoint` and `plainGetOnTheMqttPathIsNotAnUpgrade`); subprotocol echo (Task 2, verified against Paho 1.2.5 and Netty 4.1.136 behaviour); no client certificate and custom-authorizer CONNECT accepted (Task 1 test, Task 4 docs); learned hostnames: not retested here because the bridge rides the same HTTPS server whose reload PR 6's `TlsEnsureHostIntegrationTest` already proves against `quarkus.http.test-ssl-port`.
- Placeholders: none. The PR 8 profile line is given in both concrete shapes; every test class named in Task 3 Step 3 exists in the tree today.
- Type consistency: `IotMqttBrokerService.startIfEnabled()` (package-private, `synchronized`) and `isRunning()` (public) are the existing names at lines 67 and 105; `MqttConfig.host()` and `port()` are the existing accessors; `FlociCertificateAuthority.loadOrCreate(Path)`, `certificate()`, `issueServerCertificate(String, List<String>, KeyAlgorithm, KeyPair)` and `CertificateMetadata.create(List<String>, String)` are PR 3's names and the same calls PR 8's profile makes; `HttpOptionsCustomizer.MQTT_WEBSOCKET_SUBPROTOCOLS` is defined and used only in Task 2.
- Ports and dirs: PR 8 uses 18832/18883 under `/tmp/floci-iot-mqtt-tls-test`, PR 11 18834/18885, this PR 18836 (and 18887 only if PR 8 has merged) under `/tmp/floci-iot-mqtt-ws-test`.
- Wire behaviour: no new HTTP endpoint shape; `/mqtt` is the AWS path; non-upgrade requests fall through to the existing JAX-RS 404. Controllers untouched, no `AwsException` surface, no storage, no config.
- Removed from the earlier design: `MqttConfig.wsTlsPort()`, `ws-tls-port`, `FLOCI_SERVICES_IOT_MQTT_WS_TLS_PORT`, port 8884, the shared `ReloadingKeyManager` dependency on PR 8, and PR 11's `handleEndpoint(endpoint, false)` coupling (the bridged connection arrives on the plaintext listener and takes whatever that listener does).
