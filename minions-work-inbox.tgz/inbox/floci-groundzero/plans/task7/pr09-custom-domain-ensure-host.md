# PR 9: `feat: register custom domain hostnames for TLS` Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Creating an API Gateway domain name, an IoT domain configuration, or a Cognito custom domain makes Floci serve that hostname over TLS at once, so TEOS's CDK-deployed `api.<env>.localhost.floci.io` works with the ACM chain the SDK handed back and nothing else.

**Architecture:** Three one-line hooks into `TlsCertificateManager.ensureHost(domain)` (PR 6) at the point each service stores its domain. `ensureHost` never throws, so the AWS operation's outcome is unchanged. Coverage is in two layers: `@QuarkusTest` + `@InjectMock` per hook proving the call happens through the real wire path, and the load-bearing SDK test in `compatibility-tests/sdk-test-java` which requests an ACM certificate, creates the API Gateway domain, then opens a TLS connection with SNI trusting only the ACM `CertificateChain` (PR 5 made that the Floci CA) and checks the domain is in the presented SAN list.

**Tech Stack:** CDI constructor injection, Quarkus `@InjectMock`, AWS SDK v2 (`AcmClient`, `ApiGatewayClient`), `SSLSocket` with SNI.

**Branch:** `feat/custom-domain-ensure-host` from `upstream/main`. Depends on PRs 5 and 6. Also depends on Floci #3040 (`feat/apigateway-cfn-domain`) being merged: `upstream/main`'s `createDomainName` at `ApiGatewayService:1285-1315` only reads `certificateArn`; #3040 stores `regionalCertificateArn`, the field CDK emits for `REGIONAL` endpoints and the one TEOS reads. If #3040 is not merged when you start, do Tasks 1 to 3 anyway and write the SDK test with `certificateArn`; switch to `regionalCertificateArn` on rebase. `IotDomainConfigurationService` exists on `upstream/main` only (from #3008), so branch from upstream, not local `main`.

---

## File structure

- Modify: `SRC/services/apigateway/ApiGatewayService.java` (ctor 75-76, `createDomainName` 1312)
- Modify: `SRC/services/iot/IotDomainConfigurationService.java` (ctors 65-77, `createDomainConfiguration` after the `store.put`)
- Modify: `SRC/services/cognito/CognitoService.java` (ctors 130-197, `createUserPoolDomain` 1115)
- Modify: `TEST/services/cognito/CognitoServiceTest.java:51,1381,1420` (constructor args)
- Modify: `TEST/services/iot/IotDomainConfigurationServiceTest.java:41` (constructor args)
- Create: `TEST/services/apigateway/ApiGatewayDomainEnsureHostIntegrationTest.java`
- Create: `TEST/services/iot/IotDomainConfigurationEnsureHostIntegrationTest.java`
- Create: `TEST/services/cognito/CognitoDomainEnsureHostIntegrationTest.java`
- Create: `compatibility-tests/sdk-test-java/src/test/java/com/floci/test/CustomDomainTlsTest.java`
- Modify: `docs/services/apigateway.md`, `docs/services/iot.md`, `docs/services/cognito.md` (one sentence each)

---

### Task 1: API Gateway

**Files:**
- Create: `TEST/services/apigateway/ApiGatewayDomainEnsureHostIntegrationTest.java`
- Modify: `SRC/services/apigateway/ApiGatewayService.java`

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.services.apigateway;

import io.github.hectorvent.floci.config.TlsCertificateManager;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.mockito.Mockito.verify;

@QuarkusTest
class ApiGatewayDomainEnsureHostIntegrationTest {

    @InjectMock
    TlsCertificateManager certificateManager;

    @Test
    void createDomainNameRegistersTheHostnameForTls() {
        String domain = "api-" + System.nanoTime() + ".teos.localhost.floci.io";

        given()
                .contentType(ContentType.JSON)
                .body("{\"domainName\":\"" + domain + "\",\"regionalCertificateArn\":\"arn:aws:acm:us-east-1:000000000000:certificate/abc\","
                        + "\"endpointConfiguration\":{\"types\":[\"REGIONAL\"]}}")
                .when().post("/domainnames")
                .then()
                .statusCode(201);

        verify(certificateManager).ensureHost(domain);
    }
}
```

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=ApiGatewayDomainEnsureHostIntegrationTest`
Expected: FAIL, `Wanted but not invoked: certificateManager.ensureHost(...)`.

- [x] **Step 3: Inject and call**

`ApiGatewayService` field and constructor (lines 75-76 become):

```java
    private final TlsCertificateManager certificateManager;

    @Inject
    public ApiGatewayService(StorageFactory storageFactory, EmulatorConfig config, TlsCertificateManager certificateManager) {
        this.certificateManager = certificateManager;
```

(Keep the rest of the constructor body.) In `createDomainName`, after `domainStore.put(domainKey(region, domainName), domain);`:

```java
        certificateManager.ensureHost(domainName);
```

Import `io.github.hectorvent.floci.config.TlsCertificateManager`. No test constructs `ApiGatewayService` directly (`grep -rn "new ApiGatewayService(" src/test` is empty).

- [x] **Step 4: Run**

Run: `./mvnw test -Dtest='ApiGatewayDomainEnsureHostIntegrationTest,ApiGatewayCustomDomainIntegrationTest'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/apigateway/ApiGatewayService.java src/test/java/io/github/hectorvent/floci/services/apigateway/ApiGatewayDomainEnsureHostIntegrationTest.java
git commit -m "feat(apigateway): serve a custom domain over TLS as soon as it is created"
```

### Task 2: IoT domain configuration

**Files:**
- Create: `TEST/services/iot/IotDomainConfigurationEnsureHostIntegrationTest.java`
- Modify: `SRC/services/iot/IotDomainConfigurationService.java`
- Modify: `TEST/services/iot/IotDomainConfigurationServiceTest.java:41`

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.services.iot;

import io.github.hectorvent.floci.config.TlsCertificateManager;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@QuarkusTest
class IotDomainConfigurationEnsureHostIntegrationTest {

    @InjectMock
    TlsCertificateManager certificateManager;

    @Test
    void customerManagedDomainRegistersTheHostnameForTls() {
        String domain = "iot-" + System.nanoTime() + ".teos.localhost.floci.io";

        given()
            .contentType("application/json")
            .body("""
                {
                  "domainName": "%s",
                  "serverCertificateArns": ["arn:aws:acm:us-east-1:000000000000:certificate/11111111-1111-1111-1111-111111111111"]
                }
                """.formatted(domain))
        .when()
            .post("/domainConfigurations/ensure-host-" + System.nanoTime())
        .then()
            .statusCode(200);

        verify(certificateManager).ensureHost(domain);
    }

    @Test
    void endpointTypeConfigurationWithoutADomainNameDoesNotRegisterAnything() {
        given()
            .contentType("application/json")
            .body("{}")
        .when()
            .post("/domainConfigurations/ensure-host-endpoint-" + System.nanoTime())
        .then()
            .statusCode(200);

        verify(certificateManager, never()).ensureHost(org.mockito.ArgumentMatchers.anyString());
    }
}
```

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=IotDomainConfigurationEnsureHostIntegrationTest`
Expected: FAIL on the first test, `Wanted but not invoked`.

- [x] **Step 3: Inject and call**

Constructors (65-77) become:

```java
    private final TlsCertificateManager certificateManager;

    @Inject
    public IotDomainConfigurationService(StorageFactory storageFactory, RegionResolver regionResolver,
                                         EmulatorConfig config, TlsCertificateManager certificateManager) {
        this(storageFactory.create("iot", "iot-domain-configurations.json",
                new TypeReference<Map<String, IotDomainConfiguration>>() {}), regionResolver, config, certificateManager);
    }

    IotDomainConfigurationService(StorageBackend<String, IotDomainConfiguration> store, RegionResolver regionResolver,
                                  EmulatorConfig config, TlsCertificateManager certificateManager) {
        this.store = store;
        this.regionResolver = regionResolver;
        this.config = config;
        this.certificateManager = certificateManager;
    }
```

In `createDomainConfiguration`, after the `synchronized (lock) { ... store.put(key, configuration); }` block and before `return configuration;`:

```java
        if (domainName != null) {
            certificateManager.ensureHost(domainName);
        }
```

`IotDomainConfigurationServiceTest:41`:

```java
    private final IotDomainConfigurationService service = new IotDomainConfigurationService(
            new InMemoryStorage<>(), new RegionResolver(REGION, "000000000000"), endpointConfig(),
            mock(TlsCertificateManager.class));
```

Import `io.github.hectorvent.floci.config.TlsCertificateManager` in both files.

- [x] **Step 4: Run**

Run: `./mvnw test -Dtest='IotDomainConfiguration*Test'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/iot/IotDomainConfigurationService.java src/test/java/io/github/hectorvent/floci/services/iot/
git commit -m "feat(iot): serve a customer-managed domain over TLS as soon as it is configured"
```

### Task 3: Cognito custom domain

**Files:**
- Create: `TEST/services/cognito/CognitoDomainEnsureHostIntegrationTest.java`
- Modify: `SRC/services/cognito/CognitoService.java`
- Modify: `TEST/services/cognito/CognitoServiceTest.java:51,1381,1420`

- [x] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.services.cognito;

import com.fasterxml.jackson.databind.JsonNode;
import io.github.hectorvent.floci.config.TlsCertificateManager;
import io.quarkus.test.InjectMock;
import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

import static io.github.hectorvent.floci.services.cognito.CognitoRestAssuredUtils.cognitoJson;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@QuarkusTest
class CognitoDomainEnsureHostIntegrationTest {

    @InjectMock
    TlsCertificateManager certificateManager;

    @Test
    void customDomainRegistersTheHostnameForTls() throws Exception {
        String poolId = createPool();
        String domain = "auth-" + System.nanoTime() + ".teos.localhost.floci.io";

        cognitoJson("CreateUserPoolDomain", """
                {
                  "Domain": "%s",
                  "UserPoolId": "%s",
                  "CustomDomainConfig": {"CertificateArn": "arn:aws:acm:us-east-1:000000000000:certificate/abc"}
                }
                """.formatted(domain, poolId));

        verify(certificateManager).ensureHost(domain);
    }

    @Test
    void prefixDomainDoesNotRegisterAnything() throws Exception {
        String poolId = createPool();

        cognitoJson("CreateUserPoolDomain", """
                {
                  "Domain": "prefix-%s",
                  "UserPoolId": "%s"
                }
                """.formatted(System.nanoTime(), poolId));

        verify(certificateManager, never()).ensureHost(anyString());
    }

    private static String createPool() throws Exception {
        JsonNode pool = cognitoJson("CreateUserPool", "{\"PoolName\": \"EnsureHostPool\"}");
        return pool.path("UserPool").path("Id").asText();
    }
}
```

A prefix domain (`myprefix.auth.<region>.amazoncognito.com` on AWS) is not a hostname Floci serves, so it is deliberately not registered.

- [x] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=CognitoDomainEnsureHostIntegrationTest`
Expected: FAIL on the first test, `Wanted but not invoked`.

- [x] **Step 3: Inject and call**

`CognitoService` public constructor (130-133) gains a parameter and passes it through:

```java
    @Inject
    public CognitoService(StorageFactory storageFactory, EmulatorConfig emulatorConfig,
            RegionResolver regionResolver, LambdaService lambdaService, SesService sesService,
            SnsService snsService, Clock clock, TlsCertificateManager certificateManager) {
        this(
                ... existing eight stores and baseUrl unchanged ...,
                regionResolver,
                lambdaService,
                new VerificationCodeService(storageFactory, clock),
                new CognitoMessageDispatcher(sesService, snsService),
                certificateManager
        );
    }
```

The 9-arg package-private constructor (159-171) passes `null` for the two optional collaborators already; extend the delegation with `null` for the certificate manager as well:

```java
        this(poolStore, clientStore, resourceServerStore, new InMemoryStorage<>(),
                new InMemoryStorage<>(), userStore, groupStore, revokedTokenStore, baseUrl,
                regionResolver, lambdaService, null, null, null);
```

The full package-private constructor (173-197) gains `TlsCertificateManager certificateManager` after `CognitoMessageDispatcher messageDispatcher` and stores it: `this.certificateManager = certificateManager;`. Field: `private final TlsCertificateManager certificateManager;`.

In `createUserPoolDomain`, after `domainStore.put(domain, userPoolDomain);` add:

```java
        if (customDomainConfig != null && certificateManager != null) {
            certificateManager.ensureHost(domain);
        }
```

The null check mirrors how `verificationCodeService` and `messageDispatcher` are optional in the test-only constructor; the CDI path always has one.

`CognitoServiceTest:1381` and `:1420` call the 13-arg constructor; add a 14th argument `mock(TlsCertificateManager.class)` after `messageDispatcher`. Line 51 uses the 9-arg constructor; unchanged. Import `io.github.hectorvent.floci.config.TlsCertificateManager` in both files.

- [x] **Step 4: Run**

Run: `./mvnw test -Dtest='CognitoDomainEnsureHostIntegrationTest,CognitoUserPoolDomainIntegrationTest,CognitoServiceTest'`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/services/cognito/CognitoService.java src/test/java/io/github/hectorvent/floci/services/cognito/
git commit -m "feat(cognito): serve a custom domain over TLS as soon as it is created"
```

### Task 4: The load-bearing SDK test

**Files:**
- Create: `compatibility-tests/sdk-test-java/src/test/java/com/floci/test/CustomDomainTlsTest.java`

- [x] **Step 1: Write the test**

```java
package com.floci.test;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.services.acm.AcmClient;
import software.amazon.awssdk.services.acm.model.GetCertificateResponse;
import software.amazon.awssdk.services.apigateway.ApiGatewayClient;
import software.amazon.awssdk.services.apigateway.model.EndpointConfiguration;
import software.amazon.awssdk.services.apigateway.model.EndpointType;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The scenario TEOS runs: CDK requests an ACM certificate for a custom domain, creates the API
 * Gateway domain name with it, and a client that trusts only the chain ACM returned connects to
 * https://&lt;domain&gt;. Requires Floci with FLOCI_TLS_ENABLED=true; skipped otherwise.
 * DNS is not involved: the socket goes to the Floci host and carries the domain as SNI.
 */
class CustomDomainTlsTest {

    private static AcmClient acm;
    private static ApiGatewayClient apigw;
    private static String certificateArn;
    private static String domainName;

    @BeforeAll
    static void setup() throws Exception {
        Assumptions.assumeFalse(TestFixtures.isRealAws(), "Floci-only: real AWS needs DNS validation");
        Assumptions.assumeTrue(tlsIsServed(), "needs Floci with FLOCI_TLS_ENABLED=true");
        acm = TestFixtures.acmClient();
        apigw = TestFixtures.apiGatewayClient();
        domainName = "api-" + TestFixtures.uniqueName().replace("junit-", "") + ".teos.localhost.floci.io";
    }

    @AfterAll
    static void cleanup() {
        if (apigw != null && domainName != null) {
            try {
                apigw.deleteDomainName(b -> b.domainName(domainName));
            } catch (Exception e) {
                System.err.println("cleanup: deleteDomainName failed: " + e.getMessage());
            }
            apigw.close();
        }
        if (acm != null && certificateArn != null) {
            try {
                acm.deleteCertificate(b -> b.certificateArn(certificateArn));
            } catch (Exception e) {
                System.err.println("cleanup: deleteCertificate failed: " + e.getMessage());
            }
            acm.close();
        }
    }

    @Test
    void clientTrustingOnlyTheAcmChainReachesTheCustomDomain() throws Exception {
        certificateArn = acm.requestCertificate(b -> b.domainName(domainName).validationMethod("DNS")).certificateArn();
        GetCertificateResponse issued = acm.getCertificate(b -> b.certificateArn(certificateArn));
        assertThat(issued.certificate()).contains("BEGIN CERTIFICATE");
        assertThat(issued.certificateChain()).contains("BEGIN CERTIFICATE");

        apigw.createDomainName(b -> b
                .domainName(domainName)
                .regionalCertificateArn(certificateArn)
                .endpointConfiguration(EndpointConfiguration.builder().types(EndpointType.REGIONAL).build()));

        X509Certificate leaf = handshake(issued.certificateChain(), domainName);

        assertThat(sans(leaf)).contains(domainName);
        X509Certificate acmLeaf = parse(issued.certificate()).iterator().next();
        assertThat(leaf.getIssuerX500Principal()).isEqualTo(acmLeaf.getIssuerX500Principal());
    }

    /**
     * The CI workflow runs Floci with FLOCI_TLS_ENABLED=true but hands the SDK tests
     * FLOCI_ENDPOINT=http://floci:4566 (the TLS proxy on 4566 sniffs the first byte and serves
     * both), so the URL scheme says nothing about TLS. Probe instead: fetch the CA over plain
     * HTTP and try one handshake against the same host and port.
     */
    private static boolean tlsIsServed() throws Exception {
        String caPem = HttpClient.newHttpClient().send(
                HttpRequest.newBuilder(URI.create("http://" + host() + ":" + port() + "/_floci/ca.pem")).build(),
                HttpResponse.BodyHandlers.ofString()).body();
        try {
            handshake(caPem, null);
            return true;
        } catch (IOException e) {
            System.err.println("CustomDomainTlsTest: no TLS on " + host() + ":" + port() + " (" + e.getMessage() + "), skipping");
            return false;
        }
    }

    private static String host() {
        return TestFixtures.endpoint().getHost();
    }

    private static int port() {
        URI endpoint = TestFixtures.endpoint();
        if (endpoint.getPort() != -1) {
            return endpoint.getPort();
        }
        return "https".equalsIgnoreCase(endpoint.getScheme()) ? 443 : 80;
    }

    /**
     * TLS to the Floci host trusting only {@code chainPem}. With {@code sniHost} set, sends it as
     * SNI and verifies the presented certificate against it; {@code null} is a bare probe.
     */
    private static X509Certificate handshake(String chainPem, String sniHost) throws Exception {
        KeyStore trust = KeyStore.getInstance(KeyStore.getDefaultType());
        trust.load(null, null);
        int i = 0;
        for (X509Certificate ca : parse(chainPem)) {
            trust.setCertificateEntry("chain-" + i++, ca);
        }
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trust);
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, tmf.getTrustManagers(), null);

        try (SSLSocket socket = (SSLSocket) ctx.getSocketFactory().createSocket(host(), port())) {
            if (sniHost != null) {
                SSLParameters params = socket.getSSLParameters();
                params.setServerNames(List.of(new SNIHostName(sniHost)));
                params.setEndpointIdentificationAlgorithm("HTTPS");
                socket.setSSLParameters(params);
            }
            socket.startHandshake();
            return (X509Certificate) socket.getSession().getPeerCertificates()[0];
        }
    }

    private static Collection<X509Certificate> parse(String pem) throws Exception {
        Collection<? extends Certificate> certs = CertificateFactory.getInstance("X.509")
                .generateCertificates(new ByteArrayInputStream(pem.getBytes(StandardCharsets.UTF_8)));
        return certs.stream().map(X509Certificate.class::cast).toList();
    }

    private static Set<String> sans(X509Certificate cert) throws Exception {
        Set<String> out = new TreeSet<>();
        for (List<?> entry : cert.getSubjectAlternativeNames()) {
            out.add(String.valueOf(entry.get(1)));
        }
        return out;
    }
}
```

With `setEndpointIdentificationAlgorithm("HTTPS")` JSSE checks the presented certificate against the SNI name (`X509TrustManagerImpl.checkIdentity` prefers the requested server name over the socket's host), so the handshake itself fails if the SAN is missing; the explicit `sans(leaf)` assertion is there so the failure message says what was presented.

- [x] **Step 2: Run it against a TLS-enabled Floci**

Start Floci with TLS on from the repo root (in another terminal):

```bash
FLOCI_TLS_ENABLED=true ./mvnw quarkus:dev
```

Then:

```bash
cd compatibility-tests/sdk-test-java && FLOCI_ENDPOINT=http://localhost:4566 ./mvnw -q test -Dtest=CustomDomainTlsTest
```

Expected: `Tests run: 1, Failures: 0`. The SDK clients stay on plain HTTP (no trust store needed); only the handshake under test uses TLS, and it trusts the ACM chain alone. This is exactly the CI layout in `.github/workflows/compatibility.yml` (Floci with `FLOCI_TLS_ENABLED=true`, tests with `FLOCI_ENDPOINT=http://floci:4566`), so the test runs there rather than skipping.

Now the negative: restart Floci without `FLOCI_TLS_ENABLED` and run the same command. Expected: `Tests run: 1, Skipped: 1` and the stderr line `CustomDomainTlsTest: no TLS on localhost:4566 (...), skipping`.

`FLOCI_ENDPOINT=https://localhost:4566` also works but then the `AcmClient` and `ApiGatewayClient` use the JVM default trust store, which must trust the Floci CA (`docs/configuration/tls.md`, process-scoped: `curl -s http://localhost:4566/_floci/ca.pem -o /tmp/floci-ca.pem`, `keytool -importcert ... -keystore /tmp/floci-ca.p12`, `JAVA_TOOL_OPTIONS=-Djavax.net.ssl.trustStore=...`). Not required for this test.

- [x] **Step 3: Commit**

```bash
git add compatibility-tests/sdk-test-java/src/test/java/com/floci/test/CustomDomainTlsTest.java
git commit -m "test(compat): custom domain reachable over TLS trusting only the ACM chain"
```

### Task 5: Docs and PR

- [x] **Step 1: One sentence in each service doc**

`docs/services/apigateway.md`, custom domains section:

```markdown
With TLS enabled, `CreateDomainName` also adds the domain to Floci's server certificate, so
`https://<domain>` verifies against the ACM chain without a restart (names must sit under a local
suffix such as `localhost.floci.io`; see [TLS](../configuration/tls.md)).
```

`docs/services/iot.md`, domain configurations section:

```markdown
A customer-managed domain configuration (`domainName` set) is served over TLS on both the HTTPS
endpoint and the MQTT TLS listener as soon as it is created; see [TLS](../configuration/tls.md)
for the accepted suffixes.
```

`docs/services/cognito.md`, domains section:

```markdown
A custom domain (`CustomDomainConfig` set) is served over TLS as soon as it is created; prefix
domains are not hostnames Floci serves and are left alone. See [TLS](../configuration/tls.md).
```

Run: `make docs-check`. Expected: exit 0.

- [x] **Step 2: Commit and PR body**

```bash
git add docs/services/apigateway.md docs/services/iot.md docs/services/cognito.md
git commit -m "docs: custom domains are served over TLS on creation"
```

```
Floci's server certificate did not know about the custom domains CDK creates, so a client that
trusts the ACM chain still failed hostname verification against https://api.<env>.localhost.floci.io.

- ApiGatewayService.createDomainName, IotDomainConfigurationService.createDomainConfiguration
  (customer-managed only) and CognitoService.createUserPoolDomain (CustomDomainConfig only) call
  TlsCertificateManager.ensureHost(domain). ensureHost never throws; the AWS response is unchanged.
- Each hook has a @QuarkusTest with @InjectMock proving the call through the wire path, including
  the negative cases (ENDPOINT-type IoT configuration, Cognito prefix domain).
- compatibility-tests/sdk-test-java/CustomDomainTlsTest: ACM RequestCertificate, API Gateway
  CreateDomainName with regionalCertificateArn, then a TLS handshake with SNI trusting only the
  ACM CertificateChain and HTTPS hostname verification. Probes for TLS on the endpoint's
  host:port (the URL scheme is http:// in CI even with FLOCI_TLS_ENABLED=true) and skips when
  the probe fails, so it runs in the existing compatibility workflow.

Depends on the ACM-from-local-CA and ensure-host PRs, and on #3040 for regionalCertificateArn.
```

---

## Self-review

- Spec coverage. Spec PR 9: three hooks (Tasks 1 to 3); IoT only when `domainName != null` (Task 2); Cognito custom-domain branch only (Task 3); sdk-test-java test pinning only ACM `Certificate` + `CertificateChain` (Task 4); #3040 dependency noted in the header.
- Placeholders: the `CognitoService` public-constructor snippet elides the eight unchanged `storageFactory.create(...)` lines with "existing ... unchanged"; that is the one intentional elision, the lines are 135-150 of the current file and are not touched.
- Type consistency: `TlsCertificateManager.ensureHost(String)` from PR 6; `@InjectMock` on an `@ApplicationScoped` bean is supported (`quarkus-junit-mockito` is in the pom, `AwsQueryInternalErrorIntegrationTest` uses it).
- CI: an earlier draft skipped the sdk test unless `FLOCI_ENDPOINT` was `https://`, which is never the case in `compatibility.yml` (`FLOCI_ENDPOINT=http://floci:4566` at line 296 while Floci runs with `FLOCI_TLS_ENABLED=true` at line 238), so it would have been permanently skipped. `tlsIsServed()` probes the port instead.
