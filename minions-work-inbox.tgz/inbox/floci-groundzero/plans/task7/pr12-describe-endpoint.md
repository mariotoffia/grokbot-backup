# PR 12: `DescribeEndpoint` shape Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let an operator who has published the AWS IoT ports (8883 and 443) make `DescribeEndpoint` return a bare hostname the way AWS does, without changing what every existing Floci client gets by default.

**Architecture:** One optional setting, `floci.services.iot.endpoint-address` (`FLOCI_SERVICES_IOT_ENDPOINT_ADDRESS`), returned verbatim by `IotService.describeEndpoint` for every endpoint type when set. Unset keeps today's `host:4566`. No auto-detection: from inside a container Floci cannot see host-side port mappings, so "are the AWS ports served" is a fact only the operator has.

**Tech Stack:** SmallRye Config (`Optional<String>` with the `# key: ""` comment convention in `application.yml`), `@QuarkusTest` with `@TestProfile`.

**Branch:** `fix/iot-describe-endpoint-address` from `upstream/main`. Builds and tests alone. Depends on PR 8 (8883 exists) and PR 13 (`/mqtt` WebSocket on 4566) only in the sense that the setting is useless before they land; the code does not touch them.

---

## The decision, written down

Spec PR 12 offered two options. Neither survives contact with how Floci runs:

- **Return a bare hostname whenever TLS is on.** Every IoT Data client (`aws iot-data publish`, the
  `iotdataplane` SDK, `IotTest`, TEOS's own `DSManagerAWS` when `AWS_ENDPOINT_URL` is unset) builds
  `https://<endpointAddress>` and would hit port 443, where Floci serves nothing unless the operator
  mapped it. Inside Docker, Floci cannot tell whether that mapping exists. This would break the
  default `docker run -p 4566:4566 -e FLOCI_TLS_ENABLED=true` for IoT Data.
- **Leave Floci alone, override in TEOS.** Fixes TEOS's `discoverEndpoint`, but every other reader
  of `DescribeEndpoint` (shell scripts with `aws iot describe-endpoint`, the provisioning envelope
  built by a different tool, CDK custom resources) still gets `host:4566`, which devices turn into
  `host:4566:8883`.

So: an explicit override. The operator who writes the compose file that publishes `8883:8883` and
`443:4566` (Floci's TLS-sniffing proxy on 4566 serves HTTPS for the IoT Data plane and, after PR 13,
WSS for `/mqtt`; one port, one certificate, as on AWS where 443 carries both) is the one who sets
`FLOCI_SERVICES_IOT_ENDPOINT_ADDRESS=iot.teos.localhost.floci.io`. Publishing `8443:4566` as well is
harmless and lets the AWS SDK's `iot-data` default of 8443 work too. Everything else stays as is. This
is what LocalStack does with `LOCALSTACK_HOST` for the same problem.

---

## File structure

- Modify: `SRC/config/EmulatorConfig.java:745-750` (`IotServiceConfig.endpointAddress()`)
- Modify: `src/main/resources/application.yml:586-592` (commented example)
- Modify: `src/test/resources/application.yml` (nothing to add: the setting is `Optional` and unset in tests; leave the file alone)
- Modify: `SRC/services/iot/IotService.java:160-168`
- Create: `TEST/services/iot/IotDescribeEndpointOverrideIntegrationTest.java`
- Modify: `docs/services/iot.md`, `docs/configuration/tls.md`

---

### Task 1: The override

**Files:**
- Create: `TEST/services/iot/IotDescribeEndpointOverrideIntegrationTest.java`
- Modify: `SRC/config/EmulatorConfig.java`
- Modify: `SRC/services/iot/IotService.java`
- Modify: `src/main/resources/application.yml`

- [ ] **Step 1: Write the failing test**

```java
package io.github.hectorvent.floci.services.iot;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.QuarkusTestProfile;
import io.quarkus.test.junit.TestProfile;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

/**
 * When the operator has published the AWS IoT ports, DescribeEndpoint returns the bare hostname
 * AWS returns, so devices can append :8883 and SDKs can build https://host as they do against AWS.
 */
@QuarkusTest
@TestProfile(IotDescribeEndpointOverrideIntegrationTest.Profile.class)
class IotDescribeEndpointOverrideIntegrationTest {

    @Test
    void everyEndpointTypeReturnsTheConfiguredAddressVerbatim() {
        for (String type : new String[]{null, "iot:Data-ATS", "iot:Data", "iot:Jobs", "iot:CredentialProvider"}) {
            var request = given();
            if (type != null) {
                request = request.queryParam("endpointType", type);
            }
            request.when().get("/endpoint").then()
                    .statusCode(200)
                    .body("endpointAddress", equalTo("iot.teos.localhost.floci.io"));
        }
    }

    @Test
    void unsupportedEndpointTypeIsStillRejected() {
        given().queryParam("endpointType", "iot:Nonsense")
                .when().get("/endpoint")
                .then().statusCode(400);
    }

    public static final class Profile implements QuarkusTestProfile {
        @Override
        public Map<String, String> getConfigOverrides() {
            return Map.of("floci.services.iot.endpoint-address", "iot.teos.localhost.floci.io");
        }
    }
}
```

The existing `IotIntegrationTest` tests at lines 34-53 keep asserting `localhost:4566` and are the regression guard for the unset case; do not touch them.

- [ ] **Step 2: Run and watch it fail**

Run: `./mvnw test -Dtest=IotDescribeEndpointOverrideIntegrationTest`
Expected: `everyEndpointTypeReturnsTheConfiguredAddressVerbatim` FAILS with `expected "iot.teos.localhost.floci.io" but was "localhost:4566"` (the unknown property is ignored, not an error).

- [ ] **Step 3: Config**

`EmulatorConfig.IotServiceConfig` (745-750):

```java
    interface IotServiceConfig {
        @WithDefault("true")
        boolean enabled();

        /**
         * Returned verbatim by DescribeEndpoint for every endpoint type when set. AWS returns a bare
         * hostname and clients append 8883, 8443 or 443; set this when those ports are published to
         * Floci (8883 to the MQTT TLS listener, 443 and optionally 8443 to 4566, which serves HTTPS
         * and MQTT over WebSocket at /mqtt). Unset, Floci returns the host and port of its base URL.
         */
        Optional<String> endpointAddress();

        MqttConfig mqtt();
    }
```

`src/main/resources/application.yml`, inside the `iot:` block after `enabled: true`:

```yaml
      # endpoint-address: ""  # DescribeEndpoint value when the AWS IoT ports (8883, 8443, 443) are published; default host:port of base-url
```

The test `application.yml` needs nothing: the setting is optional and the test profile above supplies it where wanted.

- [ ] **Step 4: Service**

`IotService.describeEndpoint` (160-168):

```java
    public String describeEndpoint(String endpointType) {
        String effectiveType = endpointType == null || endpointType.isBlank() ? DEFAULT_ENDPOINT_TYPE : endpointType;
        if (!Set.of(DEFAULT_ENDPOINT_TYPE, "iot:Data", "iot:Jobs", "iot:CredentialProvider").contains(effectiveType)) {
            throw new AwsException("InvalidRequestException", "Unsupported endpoint type: " + effectiveType, 400);
        }
        startMqttIfEnabled();
        return config.services().iot().endpointAddress()
                .filter(address -> !address.isBlank())
                .orElseGet(() -> URI.create(config.effectiveBaseUrl()).getAuthority());
    }
```

- [ ] **Step 5: Run**

Run: `./mvnw test -Dtest='IotDescribeEndpointOverrideIntegrationTest,IotIntegrationTest'`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/main/java/io/github/hectorvent/floci/config/EmulatorConfig.java src/main/resources/application.yml src/main/java/io/github/hectorvent/floci/services/iot/IotService.java src/test/java/io/github/hectorvent/floci/services/iot/IotDescribeEndpointOverrideIntegrationTest.java
git commit -m "fix(iot): optional DescribeEndpoint address for published AWS ports"
```

### Task 2: Docs and PR

**Files:**
- Modify: `docs/services/iot.md`
- Modify: `docs/configuration/tls.md`

- [ ] **Step 1: IoT doc**

In `docs/services/iot.md`, after the "MQTT over TLS" section (PR 8) and its "Device verification on 8883" subsection (PR 11), add:

````markdown
### Endpoint address

`DescribeEndpoint` returns `host:4566` by default, the authority of Floci's base URL, because that
is where the HTTP data plane lives and IoT Data clients build `https://<endpointAddress>` from it.

AWS returns a bare hostname and lets clients add the port: 8883 for MQTT, 443 for the HTTPS data
plane and MQTT over WebSocket (`/mqtt`), 8443 as the older HTTPS alternative. Floci serves HTTPS
and WSS on one port (4566), so a single `443:4566` mapping covers both. When you publish those
ports, set `FLOCI_SERVICES_IOT_ENDPOINT_ADDRESS` so `DescribeEndpoint` answers like AWS:

```yaml
services:
  floci:
    image: floci/floci:latest
    environment:
      FLOCI_TLS_ENABLED: "true"
      FLOCI_SERVICES_IOT_ENDPOINT_ADDRESS: iot.example.localhost.floci.io
    ports:
      - "4566:4566"
      - "8883:8883"   # MQTT over TLS
      - "443:4566"    # HTTPS data plane and MQTT over WebSocket (wss://<host>/mqtt)
      - "8443:4566"   # optional: the AWS SDK iot-data default port
```

The value is returned verbatim for every endpoint type, including `iot:CredentialProvider`, which
AWS serves on its own hostname but Floci answers with the same one. Add the hostname with
`floci.dns.extra-suffixes` or an `/etc/hosts` entry if it is not under `localhost.floci.io`.
````

- [ ] **Step 2: TLS doc cross-reference**

In `docs/configuration/tls.md`, at the end of the Docker Compose example section (around line 64), add one sentence:

```markdown
For AWS IoT device clients that append their own ports to the endpoint hostname, see
[Endpoint address](../services/iot.md#endpoint-address).
```

Run: `make docs-check`. Expected: exit 0.

- [ ] **Step 3: Commit and PR body**

```bash
git add docs/services/iot.md docs/configuration/tls.md
git commit -m "docs(iot): DescribeEndpoint address when the AWS ports are published"
```

```
AWS IoT's DescribeEndpoint returns a bare hostname and devices append :8883; Floci returns
host:4566 because IoT Data clients build https://<endpoint> from it. Both are right for their
callers, and Floci inside a container cannot tell whether the operator published 8883/443.

- floci.services.iot.endpoint-address (FLOCI_SERVICES_IOT_ENDPOINT_ADDRESS): when set, returned
  verbatim for every endpoint type. Unset: unchanged behaviour, host:port of the base URL.
- Test profile covers all endpoint types and the still-rejected unknown type; IotIntegrationTest
  keeps guarding the default.
- iot:CredentialProvider is accepted as an endpoint type (it was rejected with 400; the AWS
  SDK and the IoT credentials provider ask for it).
- Docs show the compose port layout that makes the bare hostname work (8883 to the MQTT TLS
  listener, 443 to 4566 for HTTPS and MQTT over WebSocket).

No auto-detection on purpose: the default docker run -p 4566:4566 must keep working for IoT Data.
```

---

## Self-review

- Spec coverage. The spec asked for a decision and "at most a small PR": the decision is recorded above (override, not auto-detect, not TEOS-only), the PR is one config key and three lines in `describeEndpoint`. The spec's suggested regression test ("SDK round trip plus an IoT Data call") is covered by the existing `IotIntegrationTest:34-53` for the default and `IotTest.describeEndpoint` in sdk-test-java, which asserts non-blank and still passes either way; a TEOS compose with the mappings above is the end-to-end check and lives in TEOS.
- Placeholders: none.
- Type consistency: `IotServiceConfig.endpointAddress(): Optional<String>`; `config.services().iot()` is the accessor `IotService` already uses for `mqtt()`.
- Adversarial-review fixes: `iot:CredentialProvider` was in the rejected set (the profile test even asserted the 400; it now asserts the value and `iot:Nonsense` takes the 400 role); the compose layout follows PR 13's redesign (`/mqtt` on 4566, no separate 8884 listener), so 443 maps to 4566.
- AGENTS.md config checklist: `EmulatorConfig` (Task 1), main yml (Task 1), test yml (intentionally untouched, Optional), docs (Task 2), `FLOCI_*` naming follows the SmallRye mapping of `floci.services.iot.endpoint-address`.
