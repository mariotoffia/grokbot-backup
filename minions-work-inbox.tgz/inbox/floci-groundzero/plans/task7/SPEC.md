# Task 7: certificates, trust and TLS for custom domains

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Implementation plans, order and dependencies: [README.md](README.md). Setup steps and the per-PR checklist: [../README.md](../README.md).

Thirteen pull requests, and only five of them are on the critical path. This replaces the earlier
7A to 7D split; 7B, 7C and 7D are folded in below as PRs 8, 11 and 12 with their content intact.
The old 7A was one pull request carrying eight bullets, and it still would not have made a single
TEOS hostname work. Design and reasons: analysis section 10, decision record 10.5. This text has
been through an adversarial review against the AWS APIs, the Floci sources on `upstream/main` and
the TEOS call sites; the corrections it produced are folded in, not appended.

**The finding that reorganised this task.** A wildcard SAN matches exactly one label (RFC 6125).
Floci's server certificate carries `*.localhost.floci.io`, and every name groundzero creates is
deeper than that: `api.<env>.localhost.floci.io` is two labels, `api.auth.<env>.localhost.floci.io`
three, `iot-<region>.<env>.localhost.floci.io` two. All three fail hostname verification today and
would still fail after the old 7A, which only ever reissued the same wildcard SAN list. Exact SANs,
added when a domain is created, are the fix. That is PR 6.

**A second finding, unrelated but shipped here because it is the same file.**
`src/main/resources/certs/amazon-root-ca.pem` is corrupt. Line 7 carries 63 base64 characters where
every other line carries 64, so the payload is 1465 characters, which is 1 mod 4 and cannot decode;
the DER header declares 1101 bytes and only 1098 decode. OpenSSL 3 and Python both reject it. It
reaches every SDK caller verbatim through `AcmJsonHandler.handleGetCertificate`. Nothing caught it
because `AcmIntegrationTest` line 269 only asserts the string starts with
`-----BEGIN CERTIFICATE-----`, which a truncated file passes. It is also misnamed: the DER decodes
to subject `C=US, O=Amazon, OU=Server CA 1B`, an intermediate, not a root.

**Approach.** One root CA in `{persistent-path}/tls/`. Everything Floci issues chains to it: the
server certificate, ACM certificates, IoT device certificates. Clients trust one PEM, fetched from
`GET /_floci/ca.pem`. The server certificate is a single leaf whose SAN list grows at runtime:
`ensureHost(name)` appends the name, reissues the leaf with the **same key pair**, atomically
replaces the certificate file only, and reloads. Same key because the key file is then never
rewritten, so one rename is the whole swap and a reload can never observe a mismatched pair; also
no RSA key generation per hostname during a deploy burst, and anything pinning the public key keeps
working. It is not about live sessions: an established TLS session never re-reads the certificate.
This is `RdsProxyTlsCertificates.ensureHost()` under `services/rds/proxy/` generalised, so the
mechanism is already proven in tree.

Rejected: per-hostname certificates selected by SNI from the ACM certificate the domain references.
More faithful to AWS, but Quarkus resolves `quarkus.http.ssl.sni-hosts` at boot, so a domain created
by `cdk deploy` cannot be mapped without a custom Vert.x key manager or moving TLS termination into
`TlsProxyServer`. Recorded in analysis 10.5 as the upgrade if a maintainer asks for it. The
consequence to document: the certificate ARN a caller passes (`certificateArn` or
`regionalCertificateArn` on API Gateway, `CustomDomainConfig.CertificateArn` on Cognito,
`serverCertificateArns` on IoT) is stored and returned as metadata, but the certificate served is
Floci's growing leaf.

**The invariant that makes this safe, and the test that pins it.** TEOS does inspect the ACM
certificate: `mgrapigwv1/certs.go` reads `GetDomainName().RegionalCertificateArn`, calls
`acm.GetCertificate`, and tklocal (`security/client.go`, `ValidateTeosCertificateChain` defaults
to true) puts `Certificate` and `CertificateChain` into a pool used as the **only** `RootCAs` for
`https://api.<acct>` and `api.auth.<acct>`. So the served leaf must verify against the
`CertificateChain` of any ACM certificate Floci issues. It does, because PR 5 makes every ACM
chain the Floci CA and PR 6 signs the served leaf with the same CA; PR 9 asserts exactly that.

**What already works, so nobody rebuilds it.** The device certificate lifecycle TEOS runs from
Lambda code (`go-core/managers/mgriot/awsmgriot/certmanager_aws.go`: `CreateKeysAndCertificate` with
`SetAsActive`, `AttachThingPrincipal`, `AttachPolicy`; on unprovision `ListThingPrincipals`,
`DetachThingPrincipal`, `ListAttachedPolicies`, `DetachPolicy`, `UpdateCertificate` to `INACTIVE`,
`DeleteCertificate`) is served in full by `IotController` and `IotService`, and Floci refuses to
delete an `ACTIVE` or still-attached certificate as AWS does, so the TEOS order passes. No TEOS
stack creates an `AWS::IoT::Certificate`, so Task 4 rightly has none. Fidelity nit, not a blocker:
Floci answers `InvalidRequestException` 400 where AWS answers `CertificateStateException` 406 and
`DeleteConflictException` 409; TEOS wraps and logs, it never type-checks (analysis 4.16).

**Parallelism.** PRs 1, 2 and 10 depend on nothing in this task and can start together. The
critical path for TEOS is 2, then 3, then 5 and 6 side by side, then 9: four reviews deep. PR 9
also needs Floci #3040 (`feat/apigateway-cfn-domain`, stores `regionalCertificateArn`) merged.
PRs 4, 5, 6, 7 and 8 fan out the moment 3 lands and touch different services, so they do not
conflict; PR 8 additionally waits for Task 4's PR 11 because both edit `IotMqttBrokerService`.
PRs 8, 11, 12 and 13 serve the IoT broker, PR 7 serves launched containers and PR 10 serves the
Cognito token endpoint; none of the five is on the path to a groundzero deploy completing. PR 13
is what the tklocal tunnel needs, so it is on the path to *using* a deployed environment.

## 1. `fix(acm): repair the certificate chain PEM`

Branch `fix/acm-chain-pem`. Depends on nothing. Ships value on its own: tklocal feeds this PEM to
`x509.CertPool.AppendCertsFromPEM`, which returns false on the corrupt file, so
`httputil.NewClient` returns nil and tklocal cannot build an HTTP client at all. PR 5 deletes the
file; until then this is the only fix for that path.

- [ ] Replace `src/main/resources/certs/amazon-root-ca.pem` with a correctly encoded certificate,
      and name it for what it is.
- [ ] `AcmIntegrationTest` line 269: replace the `startsWith` assertion with
      `CertificateFactory.generateCertificate` over the returned chain, so a truncated file fails
      the build. This assertion is the lasting artifact; PR 5 deletes the file itself.

Size: about 30 lines plus the test.

## 2. `refactor(acm): one issuer-signing primitive in CertificateGenerator`

Branch `refactor/certificate-generator-issuer`. Depends on nothing. No behaviour change.

- [ ] `CertificateGenerator.buildCertificate` line 170 always signs with `keyPair.getPrivate()`, so
      every certificate Floci mints is self-signed. Add an overload taking an issuer certificate and
      a signing key.
- [ ] Add `generateCaCertificate()`: self-signed, `BasicConstraints(cA=true)`, `keyCertSign`.
- [ ] `buildCertificate` lines 156 to 163 set no Extended Key Usage. The overload takes one:
      server and ACM leaves get `serverAuth`, IoT device leaves get `clientAuth`. Without this a
      device certificate anyone can mint through `CreateKeysAndCertificate` would also be a valid
      server certificate under the same trusted CA.
- [ ] `CloudHsmV2Service` line 537 already has this privately as
      `generateCert(subject, issuer, pubKey, signerKey)` and builds a real three-level chain with it
      at lines 170 to 184. Delete the private copy and call the shared one.
- [ ] Tests: CloudHSM's existing chain test is the regression proof and stays unchanged. New unit
      tests that a leaf verifies against its issuer's public key and that a CA certificate carries
      `cA=true`.

Size: about 80 lines net, mostly moved.

## 3. `feat(tls): a local root CA that signs Floci's server certificate`

Branch `feat/tls-local-ca`. Depends on PR 2. Worth landing regardless of TEOS: it retires every
`--no-verify-ssl` in `docs/configuration/tls.md`, which is the pitch to the maintainers.

- [ ] `FlociCertificateAuthority`: owns `{persistent-path}/tls/floci-root-ca.{crt,key}`, with
      `loadOrCreate`, `sign` and `caPem`. **A plain class, not a bean.** `TlsConfigSource` is a
      `ConfigSource` and runs before CDI exists, so the CA cannot be injected there. A thin
      `@ApplicationScoped` producer exposes it to services.
- [ ] `TlsConfigSource`: the server leaf is signed by the CA instead of itself, same SANs, same
      persisted key pair. **Replace the `isSelfSigned` regeneration trigger** (lines 100 and 221 to
      228, an issuer equals subject check) with "issued by our CA", or the CA-signed leaf fails the
      check and is regenerated on every boot, with a fresh key pair via the three-argument overload
      at line 192.
- [ ] The CA key is written `rw-------` and its directory `rwx------`, as
      `RdsProxyTlsCertificates.restrictToOwnerOnly` already does at lines 122 to 123.
      `TlsConfigSource` writes keys with default permissions today (lines 197 to 198); fix the
      server key while there.
- [ ] `TlsConfigSource`: replace `quarkus.http.ssl.certificate.files` and `key-files` with
      `quarkus.tls.key-store.pem.0.cert` and `.key`. That is the default TLS registry configuration,
      which the HTTP server picks up with no `quarkus.http.tls-configuration-name`, and it is the
      prerequisite for reload in PR 6.
- [ ] `GET /_floci/ca.pem` on `EmulatorInfoController`, `text/plain`. It already serves `/health`,
      `/info` and `/config` under `@Path("{prefix:(_floci|_localstack)}")`.
- [ ] An unreadable or corrupt persisted CA is regenerated with a WARN, as `TlsConfigSource` already
      does for a stale server certificate. Never silently fall back to self-signed: that would make
      `ca.pem` lie about what signed the connection.
- [ ] Config under `floci.tls.*` in `EmulatorConfig`, both `application.yml`, `FLOCI_TLS_*` names,
      docs table.
- [ ] Tests: the CA carries `cA=true` and `keyCertSign`; the server leaf verifies against it;
      `/_floci/ca.pem` parses as X.509.
- [ ] Docs: `docs/configuration/tls.md` replaces "disable verification" with "trust `ca.pem` once".
      Recommend per-process trust (`AWS_CA_BUNDLE`, `SSL_CERT_FILE`, `NODE_EXTRA_CA_CERTS`,
      `--cacert`) first. If a keychain is wanted, the **login** keychain, never System with `sudo`:
      the CA signs whatever hostname an unauthenticated caller asks for (Floci checks no SigV4
      signature), so machine-wide trust would turn any local process into a MITM for every user.
      State the Go caveat: Go ignores `SSL_CERT_FILE` on macOS below `go 1.27` (or without
      `GODEBUG=x509sslcertoverrideplatform=1`), so plain `net/http` scripts need keychain trust or a
      code-level `RootCAs`; the AWS SDK for Go honours `AWS_CA_BUNDLE` regardless.

Size: about 250 lines plus tests.

## 4. `feat(iot): real device certificates`

Branch `feat/iot-real-device-certs`. Depends on PR 3, which owns the CA that signs them.

- [ ] `IotService` line 282 returns `"-----BEGIN CERTIFICATE-----\n" + uuid + "\n-----END CERTIFICATE-----"`.
      TEOS calls `tls.X509KeyPair(creds.Certificate, creds.PrivateKey)` at `helpers_test.go` line 322
      and errors before a socket is opened, so no device test can pass until this is real.
- [ ] `CreateKeysAndCertificate` issues a real leaf signed by the root CA, `clientAuth` EKU, keyed
      to the returned private key. `certificateId` becomes the lowercase SHA-256 hex of the DER, as
      AWS computes it; today it is two concatenated UUIDs (line 278), the right length and no
      relation to the certificate. Deriving it from the DER costs one `MessageDigest` call and hands
      PR 11 its lookup key: the fingerprint of the certificate a client presents *is* the store key.
- [ ] `CreateCertificateFromCsr` (lines 269 to 274, id from `hashCode()` at 283) stays fake in
      this PR; TEOS only calls `CreateKeysAndCertificate` (`certmanager_aws.go` line 47). The CSR
      parsing it would need already exists in `CloudHsmV2Service` (`PKCS10CertificationRequest`),
      so making it real later is a small follow-up, not a design change.
- [ ] Tests: the returned PEM parses as X.509, its public key matches the returned private key
      (the Java equivalent of the Go call that fails today), it verifies against `ca.pem`, and
      `certificateId` equals `sha256(DER)`.

Size: about 60 lines plus tests. Unblocks PR 11.

## 5. `feat(acm): issue certificates from the local CA`

Branch `feat/acm-ca-signed`. Depends on PR 3.

- [ ] `AMAZON_ISSUED` and `PRIVATE` certificates signed by the root CA, `serverAuth` EKU, with
      `certificateChain` set to the CA PEM. `IMPORTED` untouched. `PRIVATE` is reachable: any
      non-empty `certificateAuthorityArn` makes one (`AcmService` lines 144 to 146), and
      `ExportCertificate` (lines 400, 420) returns whatever chain is stored, so it must not be
      empty. On AWS the chain would be the PCA's; Floci's CA is the only issuer it has, so only
      `type`, status and validation differ from `AMAZON_ISSUED`.
- [ ] The issuer DN becomes the CA's, replacing the cosmetic
      `CN=Amazon,OU=Server CA 1B,O=Amazon,C=US` at `CertificateGenerator` line 53, a DN whose
      signature could never verify because Floci has no Amazon private key.
- [ ] `AcmService` line 185 sets the Amazon chain unconditionally. Replace with the CA PEM.
- [ ] Delete `src/main/resources/certs/amazon-root-ca.pem`: the chain is live now.
- [ ] Tests: `AcmIntegrationTest` asserts the chain parses and the leaf verifies against it, for
      both `AMAZON_ISSUED` and `PRIVATE`, and that `ExportCertificate` returns the same chain.
- [ ] Docs: `docs/services/acm.md` mentions the chain.

Size: about 80 lines plus tests.

## 6. `feat(tls): serve exact hostnames as custom domains are created`

Branch `feat/tls-ensure-host`. Depends on PR 3. **This is the one that makes TEOS names work.**

- [ ] `TlsCertificateManager`, `@ApplicationScoped`: `ensureHost(String)` appends a SAN when the
      name is not already covered, reissues the leaf with the **same key pair** signed by the CA,
      writes the certificate and metadata to temporary files and atomically renames, then reloads.
      **The key file is never rewritten**; that is the whole point of keeping the key. A half-written
      certificate would take TLS down for the whole emulator, not just the new name.
- [ ] Reload is two calls, not one. `TlsConfigurationRegistry.getDefault().get().reload()`
      re-reads the files into the registry; it does **not** touch the running server. Then fire
      `CertificateUpdatedEvent(TlsConfig.DEFAULT_NAME, configuration)` through an injected
      `Event<CertificateUpdatedEvent>`; `HttpCertificateUpdateEventListener` in `quarkus-vertx-http`
      observes it and calls `updateSSLOptions` on each HTTP server it registered. `DEFAULT_NAME` is
      the literal `"<default>"` (verified in `quarkus-tls-registry` 3.37.4). Not
      `quarkus.tls.reload-period`: CDK creates a domain and the harness connects seconds later, so a
      periodic window would produce intermittent handshake failures that look like flake.
- [ ] Metadata: add a `learnedHostnames` field to the JSON `TlsConfigSource` writes (lines 324 to
      364) rather than appending to `hostnames`. `hostnameConfigChanged` is a set-equality test of
      `hostnames` against defaults plus configured names; a superset would read as "config changed"
      and boot would reissue **without** the learned names. Change detection keeps comparing
      `hostnames` only; boot issues with `hostnames` union `learnedHostnames`.
- [ ] **Allow-list the names.** `ensureHost` accepts only names under a suffix Floci itself
      resolves: `localhost.floci.io`, `localhost.localstack.cloud`, `floci.hostname`, the base-url
      host and `floci.dns.extra-suffixes`. Anything else logs WARN and is skipped. Floci verifies no
      request signature, so without this any local process, or any Lambda container Floci launches,
      could `CreateDomainName{domainName:"accounts.google.com"}` and receive a leaf that every
      client trusting `ca.pem` accepts. Every TEOS name passes the allow-list.
- [ ] Idempotent, wildcard-aware (a name an existing SAN already covers is a no-op) and
      synchronized, because a deploy creates domains in bursts.
- [ ] Implements `Resettable` so `/_floci/state/reset` drops learned SANs back to the defaults.
- [ ] Failures log WARN with the hostname and do not propagate; see PR 9 for why. Never an empty
      catch.
- [ ] Tests: the SAN appears; calling twice is a no-op; **the key file's bytes are unchanged and
      the new leaf's public key equals the old**; a wildcard-covered name is skipped; a name outside
      the allow-list is skipped with a WARN; reset restores the defaults; a restart keeps the learned
      names; a client connecting after `ensureHost` sees the new SAN in the served certificate (this
      is the only test that proves the event actually reached the server).

Size: about 250 lines plus tests.

## 7. `feat(container): trust the local CA inside launched containers`

Branch `feat/container-ca-bundle`. Depends on PR 3. Carried over from the old 7A.

- [x] `LaunchedContainerAwsEnv` and `ContainerBuilder`: bind-mount the CA and set `SSL_CERT_FILE`,
      `AWS_CA_BUNDLE`, `NODE_EXTRA_CA_CERTS`, `REQUESTS_CA_BUNDLE` and `CURL_CA_BUNDLE`. Java
      runtimes get a `ca.p12` and `JAVA_TOOL_OPTIONS` trust-store flags.
      Done in #3091 as a copy at the `ContainerLifecycleManager.create` choke point (a bind mount
      fails when Floci itself runs in Docker), of a bundle = JVM public roots + the Floci CA, which
      is what makes the replacing variables safe. No Java trust store (deliberate, see the plan).
- [ ] With `FLOCI_TLS_ENABLED=true`, `ContainerReachableEndpoint.baseUrl()` may hand out `https://`.
      Deliberately not done in #3091: plain HTTP from a container to Floci keeps working.
- [x] Tests: `LaunchedContainerAwsEnvTest` for the env entries. Done as `ContainerCaBundleTest`,
      `ContainerLifecycleManagerCaBundleTest`, `TlsConfigSourceContainerCaBundleTest` and the
      Docker-gated `ContainerCaBundleDockerIntegrationTest` (a real python container reaches Floci
      and a public site through the bundle alone).

Size: about 150 lines plus tests.

## 8. `feat(iot): MQTT over TLS listener`

Branch `feat/iot-mqtt-tls`. Depends on PR 3, and on Task 4's PR 11: both edit `IotMqttBrokerService`,
so rebase rather than conflict. Was 7B. Opened 2026-09-06 as #3142; the key manager follows `CertificateUpdatedEvent` rather than delegating to `TlsCertificateManager`, see the plan's status note.

- [x] A second `MqttServer` in `IotMqttBrokerService.startIfEnabled` with `setSsl(true)` on
      `floci.services.iot.mqtt.tls-port` (default 8883). Client certificates requested
      (`ClientAuth.REQUEST`) so the handshake carries them, but not verified in this PR. 1883 stays
      as it is, permissive.
- [x] `io.vertx.mqtt.MqttServer` has no `updateSSLOptions` (vertx-mqtt 4.5.30), so it cannot be
      told about a reissued leaf the way the HTTP server is. Instead hand it
      `KeyCertOptions.wrap(X509KeyManager)` (vertx-core 4.5.30) with a key manager that delegates
      to `TlsCertificateManager`'s current leaf on every `getCertificateChain` call. New handshakes
      then see new SANs with no restart and no event plumbing. PR 13 reuses the same wrapper.
- [x] Config: `EmulatorConfig`, both `application.yml`, `FLOCI_SERVICES_IOT_MQTT_TLS_PORT`,
      `docs/services/iot.md` broker section and the port table.
- [x] Tests: a TLS connect, subscribe and publish through 8883 trusting `ca.pem`; plaintext 1883
      unchanged; after `ensureHost("x.localhost.floci.io")` a connect with that `ServerName`
      succeeds without restarting the listener.

Size: about 150 lines plus tests.

## 9. `feat: register custom domain hostnames for TLS`

Branch `feat/custom-domain-ensure-host`. Depends on PRs 5 and 6, and on Floci #3040
(`feat/apigateway-cfn-domain`) being merged: `main`'s `createDomainName` at `ApiGatewayService`
line 1299 drops `regionalCertificateArn`, which is the field CDK emits for the default REGIONAL
endpoint type and the one TEOS reads (`certs.go` lines 56 to 60); #3040 stores it. PR 5 is a
dependency because the test below trusts the ACM chain, not `ca.pem`. **The load-bearing test lives
here.**

- [ ] `ApiGatewayService`, on `CreateDomainName`: call `ensureHost(domainName)`.
      `ApiGatewayCustomDomainFilter.findDomainByName` line 57 already routes by `Host`; only the
      certificate was missing. `createV2DomainName` funnels into the same service method, so one
      hook covers API Gateway v1 and v2.
- [ ] `IotDomainConfigurationService.createDomainConfiguration` (upstream/main, from #3008), when
      `domainName != null`: the same call. **Not** `UpdateDomainConfiguration`: on AWS and in Floci
      `domainName` and `serverCertificateArns` are create-only, the update request carries neither
      (Floci lines 131 to 175 read status, authorizer and TLS config only). TEOS's
      `enable-iot-domain` never reaches Floci anyway: it only sends an update when the status is
      `DISABLED`, and Floci creates configurations `ENABLED` (line 100).
- [ ] `CognitoService` line 1101, the `customDomainConfig != null` branch that already requires
      `CertificateArn`: the same call.
- [ ] A failed `ensureHost` warns and the AWS call still succeeds. An emulator that refuses
      `CreateDomainName` because of internal certificate plumbing is worse than one that serves the
      name late, and a failure here is a Floci bug, not a caller error.
- [ ] Document that the stored certificate ARN (`certificateArn`, `regionalCertificateArn`,
      `CustomDomainConfig.CertificateArn`, `serverCertificateArns`) is metadata: the certificate
      served is Floci's growing leaf. Analysis 10.5 carries the reason.
- [ ] Tests: in `compatibility-tests/sdk-test-java`, request an ACM certificate, create a domain
      through the SDK referencing it, then complete a real TLS handshake to that hostname trusting
      **only** `GetCertificate().certificate` plus `certificateChain` from ACM, exactly as tklocal
      does. Then issue a request the Host filter routes. Assert a three-label name explicitly, since
      that is exactly what the wildcard SANs cannot serve. A file assertion cannot prove Quarkus
      reloaded and served the new leaf; trusting `ca.pem` instead of the ACM chain cannot prove the
      invariant tklocal depends on. The Node compatibility suite already runs Floci with
      `FLOCI_TLS_ENABLED=true` (`sdk-test-node/README.md` lines 78 to 84), so the harness precedent
      exists.

Size: about 70 lines plus tests.

## 10. `feat(cognito): route custom domains by Host`

Branch `feat/cognito-host-routing`. Depends on nothing in this task, so it can start on day one: it
needs no certificate, works over plain HTTP, and gains TLS for free once PR 9 lands.

**What actually exists, so the scope is honest.** Floci's hosted-UI surface is
`POST /cognito-idp/oauth2/token` (`CognitoOAuthController` line 39, `client_credentials` only, pool
resolved from `client_id` at `CognitoService` lines 2419 to 2422) and `/cognito-idp/oauth2/userInfo`
(`CognitoUserInfoController` line 60). There is no `/oauth2/authorize`, `/login` or `/logout`, and no
pool-scoped OAuth path. The prefix form `<prefix>.auth.<region>.amazoncognito.com` cannot reach Floci
because `EmbeddedDnsServer` (lines 59 to 68) answers only the two Floci suffixes, so it is out.

- [ ] A `ContainerRequestFilter` resolving the request `Host` against `CognitoService`'s domain
      store (custom `Domain` is the FQDN), rewriting `/oauth2/token` and `/oauth2/userInfo` onto the
      `/cognito-idp/...` paths. `ApiGatewayCustomDomainFilter` and `SqsQueueUrlRouterFilter` are the
      patterns to copy.
- [ ] A `client_id` whose pool is not the domain's pool is refused with `invalid_client`, as AWS
      does. This is the only way the Host carries meaning, since the pool is otherwise chosen by
      `client_id` alone.
- [ ] `CognitoService` lines 2447 to 2455 build `token_endpoint` and friends as
      `baseUrl + "/cognito-idp/oauth2/..."`. For a pool with a custom domain,
      `openid-configuration` advertises `https://<domain>/oauth2/...` instead, or the document points
      clients at URLs the Host filter never sees.
- [ ] Tests: `Host: <domain>` plus `/oauth2/token` reaches the token handler; a pool B client on
      pool A's domain gets `invalid_client`; an unknown host is left untouched; an empty POST still
      answers 400 `invalid_request`, which is what TEOS's `03-check-cognito-token-endpoint` accepts.

Size: about 120 lines plus tests.

## 11. `feat(iot): verify device certificates on the TLS listener`

Branch `feat/iot-mtls`. Depends on PRs 4 and 8. Was 7C. **Slack first**: `docs/services/iot.md`
documents the broker as permissive by design ("certificate and policy authorization are not enforced
at the broker layer yet"), so this is the one piece that changes authorisation semantics.

- [ ] On the 8883 handshake, `MqttEndpoint.sslSession().getPeerCertificates()[0]`, then
      `sha256(getEncoded())` is the `certificateId` from PR 4. Look it up in the certificate store;
      accept only `ACTIVE`, refuse unknown and `INACTIVE`; bind the certificate ARN to the session as
      its principal, which feeds `clientid()` and policy evaluation later. Membership in the store is
      the check, not chain validation: Floci has no `RegisterCertificate` today, so everything in
      the store chains to the Floci CA anyway, and a membership check keeps foreign certificates
      possible later. A `CreateCertificateFromCsr` entry with a fake PEM simply never matches.
- [ ] Evaluate attached policies for `iot:Connect`. `Publish`, `Subscribe` and `Receive` evaluation
      can follow in a later PR.
- [ ] Only 8883. The `/mqtt` WebSocket bridge from PR 13 lands on the plaintext 1883 listener; on
      AWS that path authenticates by custom authorizer, not by client certificate, so it stays
      permissive until Task 4.12 lands.
- [ ] Tests: unknown certificate refused, `ACTIVE` accepted, `INACTIVE` refused, detached refused.
- [ ] Docs: the permissive-broker sentence becomes "1883 permissive, 8883 verifies".

Size: about 200 lines plus tests.

## 12. `DescribeEndpoint` shape

A decision, then at most a small PR. Depends on PRs 8 and 13. Was 7D.

- [ ] AWS returns a bare hostname and clients append 8883, 8443 or 443; Floci returns `host:4566`
      because its HTTP data plane lives there, and every IoT Data client today builds
      `https://<endpoint>` from that value, so changing it is the riskiest line in this task.
- [ ] Options: return the bare hostname only when TLS is on and the AWS ports are actually served
      (8883 from PR 8, 443 from PR 13 via the TEOS mapping, 8443 via the TEOS mapping to 4566),
      keeping `host:4566` otherwise; or leave Floci alone and have TEOS override `discoverEndpoint`
      on the local target. TEOS's own data plane is unaffected either way, because
      `DSManagerAWS.ResolveEndpoint` prefers `AWS_ENDPOINT_URL`; only the provisioning envelope and
      the IoT CNAME record read the raw value.
- [ ] If Floci changes: `fix(iot): return a bare hostname from DescribeEndpoint when the AWS ports
      are served`, with an SDK round trip plus an IoT Data call as the regression test.

## 13. `feat(iot): MQTT over WebSocket at /mqtt`

Branch `feat/iot-mqtt-websocket`. Depends on PR 3 only (the test trusts the Floci CA); touches
neither `IotMqttBrokerService` nor config. Revised after the external critique: the earlier third
`MqttServer` on 8884 needed a new port, a new config key and a second TLS listener to keep in sync,
when the HTTPS server on 4566 already has the right certificate and the right port.

- [x] `server_tunnel.go` line 138 dials `wss://iot-<region>.<acct>:443/mqtt`. Floci has no MQTT
      over WebSocket at all and no `/mqtt` route; a 443 to 4566 mapping lands on Quarkus HTTP,
      which answers 404 and autopaho loops in `OnConnectError`.
- [x] `IotMqttWebSocketBridge` (`@ApplicationScoped`, `services/iot`) registers `/mqtt` through
      the same `@Observes Router` hook the API Gateway v2 `WebSocketHandler` uses. On a WebSocket
      upgrade it opens a `NetClient` to the broker's plaintext listener and pipes binary frames
      both ways; a non-upgrade request falls through (`ctx.next()`) to the existing JAX-RS 404.
      Served on both the HTTP and HTTPS servers, so `wss://` gets PR 3's leaf, PR 6's learned
      hostnames and the `443:4566` mapping PR 12 documents with no extra listener.
- [x] `HttpOptionsCustomizer` echoes `mqtt`, `mqttv3.1`, `mqttv3.1.1` via
      `setWebSocketSubProtocols` on both servers: Paho and the AWS Device SDKs refuse a handshake
      without the echo; Netty completes handshakes that ask for other names without the header, so
      API Gateway WebSocket clients are unaffected.
- [x] No client certificate requested. `tunnel.go` line 135 authenticates as
      `<clientId>?x-amz-customauthorizer-name=<name>` with a token password; the bridged CONNECT
      reaches the permissive 1883 listener, so it is accepted and the fields are ignored until
      Task 4.12 evaluates custom authorizers. Say so in `docs/services/iot.md`.
- [x] Config: none. No `ws-tls-port`, no 8884.
- [x] Tests: Paho `wss://127.0.0.1:<test-ssl-port>/mqtt` subscribe and publish trusting only the
      Floci CA, `ws://` on the HTTP port, the TEOS custom-authorizer CONNECT shape, wrong path is a
      404 handshake not 101, plain `GET /mqtt` is 404, plaintext 1883 unaffected. Learned hostnames
      are covered by PR 6's `TlsEnsureHostIntegrationTest` on the same HTTPS server.

Size: about 90 lines plus tests.

## 14. `fix(iot): accept MQTT packets up to the AWS 128 KB payload limit`

Branch `fix/iot-mqtt-max-message-size` from `main` (#3150 merged 2026-09-09 as c4027bbf5). Found by PR 13: `IotMqttBrokerService`
builds `MqttServerOptions` with host and port only, so vertx-mqtt's `DEFAULT_MAX_MESSAGE_SIZE`
(8092 bytes) caps every packet on 1883, 8883 and `/mqtt`. AWS IoT Core allows 128 KB of payload per
message and disconnects a client that publishes more.

- [ ] `setMaxMessageSize(128 * 1024 + 4096)` on both listeners (payload plus topic, packet id and
      MQTT 5 properties). No receive buffer size is set, so vertx-mqtt's "buffer at least the max
      message" rule does not apply.
- [ ] Tests: a 128 KB publish delivered over TCP, TLS and `wss://`; 128 KB + 1 disconnects the
      client as on AWS. The existing 300 KB WebSocket frame test still closes the session.
- [ ] Docs: one sentence in the broker scope list of `docs/services/iot.md`.

Size: about 5 lines plus tests.

## TEOS side (T10, not Floci PRs)

- [ ] Publish `443:4566` (and optionally `8443:4566`) plus `8883:8883` as Docker port mappings in
      the harness; `/mqtt` (PR 13) shares 4566. `devicecore/mqttprovisioner.go` builds `https://%s:8443`, which the
      `TlsProxyServer` on 4566 demultiplexes to Quarkus and `IotDataController /topics/{topic}`
      serves. `server_tunnel.go` line 138 dials `wss://iot-<region>.<acct>:443/mqtt`, which needs
      PR 13, PR 9's SAN, and (for real authorisation rather than permissive accept) Task 4.12.
- [ ] Replace the Amazon Root CA pinning. `downloadRootCA()` fetches
      `https://www.amazontrust.com/repository/AmazonRootCA1.pem` and `mqttprovisioner.go` line 45
      hands devices those URLs; on the local target both become `/_floci/ca.pem` from PR 3.
- [ ] tklocal needs nothing: it already pins `GetCertificate().Certificate` plus `CertificateChain`
      (`security/client.go` lines 44 to 51), and after PRs 5, 6 and 9 that pool verifies the served
      leaf. Until PR 1 lands the corrupt chain PEM makes `httputil.NewClient` return nil.
- [ ] `03-check-cognito-token-endpoint` and any plain `net/http` lifecycle script: TEOS modules are
      `go 1.25.0`, so `SSL_CERT_FILE` is ignored on macOS. Either set `RootCAs` from `ca.pem` in code
      or trust `ca.pem` in the login keychain. `AWS_CA_BUNDLE` works for every SDK call.
- [ ] Local provision config: `Product.Common.DNS.AccountDomain: <env>.localhost.floci.io` with
      `DelegationRole` empty (analysis 7.1), so every groundzero name resolves to Floci on the host
      and inside launched containers with no `/etc/hosts` edit.

Each PR: the checklist in [../README.md](../README.md) minus the CloudFormation rows, since no resource type is added here;
`make docs-check` on every PR that touches `docs/`.
