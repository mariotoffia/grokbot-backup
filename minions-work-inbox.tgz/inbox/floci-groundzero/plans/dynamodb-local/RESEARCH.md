# DynamoDB Local integration: architectural and licensing research

**Date:** 2026-09-18.

**Status:** Research report only. This is not an approved design, an instruction to implement, or approval to remove TEOS's current workaround.

**Scope:** DynamoDB Local licensing and the complete DynamoDB boundary between Floci and TEOS. Other issue inventory and planning-document synchronization belong to the coordinating session.

**Source snapshots:** Floci `570f975829ab30f2cf2447985fa425e7a9df3b7b`; TEOS `4514f7d53a119fcda38bbc360a954f7c6d4c7f75`. Paths and line references below describe the files inspected in the working trees. The source investigation was read-only.

## 1. Executive conclusion

An optional, externally supplied DynamoDB Local endpoint is technically plausible and is the smallest sound **end-to-end** direction worth taking to maintainers. It is not merely an HTTP proxy.

The correct scope is:

1. DynamoDB Local owns table existence, schemas, indexes, items, transactions, conditional writes, and actual DynamoDB stream records.
2. Floci remains the AWS-facing endpoint and owns its existing request-account resolution, optional IAM enforcement, CloudFormation, Lambda event-source mappings, and Pipes.
3. Every existing in-process DynamoDB caller reaches that same selected database.
4. Floci reads Local's **actual Streams APIs**. It does not manufacture events from intercepted writes or copy them into the native in-memory stream buffer.
5. Unsupported Local features have explicit behavior. They never fall back to a second native table containing different data.
6. The existing Floci implementation stays the default. Users who do not select Local do not acquire a Java-server dependency, Docker requirement, or changed persistence behavior.

There are two important qualifications.

**Licensing:** The current AWS license and the `LICENSE.txt` packaged in DynamoDB Local 3.3.1 contain explicit restrictions on incorporation and distribution. AWS also documents Maven and embedded use. Those facts must be presented together, not resolved by assuming that a Maven artifact is open source. Do not bundle the server into Floci's MIT-licensed image without an applicable permission or legal determination. A user-supplied endpoint, with users obtaining the official image themselves, avoids Floci redistributing that server. It does not waive the user's AWS license obligations.

**Architecture:** Local does not supply Lambda delivery semantics. The present Floci DynamoDB poller lacks several semantics that TEOS's pump already provides. Adding a URL cannot remove the pump safely. Real shard discovery, checkpoints, partial failure, retry limits, bisection, and the failure destination are part of the removal gate.

There is no demonstrated current Floci conditional-write failure in this investigation. TEOS chose Local as a trust and compatibility policy. Current Floci has per-item locking and concurrency tests. That distinction matters when approaching maintainers.

## 2. Method, evidence levels, and limits

I read TEOS's project-root DynamoDB issues first, including their status text and links. I then read the DynamoDB sections of its current plan, the stream-pump design, and the implementation. I traced Floci's public dispatch, direct service callers, metadata readers, stream consumers, account handling, persistence, lifecycle, and existing container patterns.

The report distinguishes:

- **Observed source behavior:** What the inspected code does.
- **AWS-documented behavior:** What current official AWS documents or the published license say.
- **Proposed experiment:** A necessary validation that was not run.
- **Recommendation:** A candidate for an explicit product and architecture decision.

I did not start Docker, run either emulator, call paid AWS APIs, modify source code, create commits or branches, change references, delete source, or upload repository content. Public searches used only generic AWS/product terms. I retrieved the public Maven POM and read only the packaged `LICENSE.txt` from the published 3.3.1 JAR in memory. I did not execute, decompile, or reverse engineer the server. No binary was added to either repository.

I did not run application tests because this task is report-only and explicitly excludes starting the required runtime. Existing test names are evidence of coverage present in source, not a claim that those tests passed during this investigation.

## 3. The originating TEOS issues

The project-root file uses numbered sections, not GitHub issue numbers. Do not invent a `DDB-*` issue ID for them.

| Exact root reference | Symptom and status recorded in `TEOS/ISSUES.md` | Related detailed register entry |
|---|---|---|
| **1.1**, lines 26-57 | CloudFormation creates native Floci tables. The harness copies them to Local. Tests and functions use Local. The host pump invokes functions because Floci's poller sees the empty native database. The file records successful building-service and groundzero runs, not removal of the workaround. | **W-4**, **F-6**, **W-22** |
| **1.2**, lines 59-70 | Lambda receives `AWS_ENDPOINT_URL_DYNAMODB`, but not `AWS_ENDPOINT_URL_DYNAMODB_STREAMS`. A function using a Streams SDK client would read the wrong server. The issue states no current production function uses that client. Open, with a small environment-injection change proposed. | Endpoint split also documented under **W-9**, **C-8**, **C-9** |
| **1.3**, lines 72-84 | A direct IoT, Step Functions, or API Gateway DynamoDB operation stays inside Floci and writes the other database. The stated current rule is to put Lambda between the service and the table. No affected TEOS stack is claimed today. | Architectural consequence of **F-6** and the fixed split |
| **1.4**, lines 86-100 | The pump rejects filtering, nonzero tumbling/batching windows, parallelization above one, and record-age limits other than `-1`. This is a fail-fast limitation, not silently supported functionality. | **W-19**, and **P-22** for Floci mapping-property loss |
| **1.5**, lines 102-113 | Existing mirrored schema differences are rejected, not reconciled. Several metadata settings are deliberately not copied. | **W-22** and table-mirror design |
| **1.6**, lines 115-141 | The 250 ms table mirror is not a deployment barrier. A custom-resource Lambda can execute before its table exists in Local. The issue records a favorable timing measurement and explicitly says the race has not occurred in observed runs. | **W-22** |
| **1.7**, lines 143-149 | Whether Local actually expires TTL items is unverified. No current local test depends on expiration. | No separate numbered detailed-register entry was identified for this experiment |

Important status and link context:

- `TEOS/design-in-progess/floci/ISSUES.md:71` says **W-4, F-6, W-22 are kept**. It describes the post-deploy mirror as decisive and the during-deploy mirror as an early copy.
- `.../ISSUES.md:85` records **W-19 done on 2026-09-17**: unsupported record age is rejected, and a failed failure-destination send makes the harness fail. Keeping containers does not keep the process-scoped pump alive.
- `.../ISSUES.md:264` describes **W-4 done on 2026-09-03** as a workaround. It links to `PLAN_DDB_PUMP.md`, `PLAN.md` sections 5.7 I-2, 5.6, and 3.4.
- `.../ISSUES.md:317` calls **F-6** a consequence of the database split, not inherently a Floci defect. Its statement that upstream will not add an external source is a recorded project assessment, not independently verified maintainer approval or rejection of this broader proposal.
- `.../ISSUES.md:51` records **P-22**: CloudFormation loses mapping settings and the native poller lacks needed delivery behavior.
- `.../ISSUES.md:37` links [floci-io/floci#3060](https://github.com/floci-io/floci/pull/3060) and [floci-io/floci#3203](https://github.com/floci-io/floci/pull/3203) for SDK-path filtering and SQS batching. The source confirms that these do not, by themselves, provide an external DynamoDB stream reader. Their remote review threads were not consulted as architectural authority.
- `TEOS/design-in-progess/floci/PLAN_DDB_PUMP.md:3-22,168-176` explicitly keeps the pump until actual Local writes reach the deployed Lambda through Floci with the required failure handling.
- `TEOS/design-in-progess/floci/PLAN.md:245-257,338-343` makes the Local data-plane choice unconditional. This report does not reopen it silently.

### Corrections and qualifications found by reading the implementation

The root summary is useful but not an exhaustive description of the code:

- The mirror checks primary key schema and **missing index names**. It does not compare complete existing GSI/LSI key and projection definitions. An index with the same name but different schema can escape that check. See `local_mirror.go:150-209`.
- The shared `mirrorTable` operation copies items as well as schema and TTL. The during-deploy watcher calls that same function. The apparent “future” risk of copying a large table during deployment is already a possible behavior of that shared function. See `local_mirror.go:95-149,220-237` and `local_mirror_watch.go:145-168`.
- `mirrorTables` and the watcher use one `ListTables` request, whereas item copies paginate `Scan`. They are not a general-purpose table replication service.
- These are source observations, not newly reproduced TEOS failures. They strengthen the case for one authoritative database rather than growing the mirror.

## 4. Current end-to-end flows

### 4.1 TEOS today

```text
TEOS host AWS SDK and tools
  DynamoDB + Streams per-service endpoint variables
    -> DynamoDB Local

TEOS function
  DynamoDB per-service endpoint variable
    -> http://ddblocal:8000 on the run's Docker network

CloudFormation in Floci
  -> native DynamoDbService
  -> native table metadata and items
        |
        +-> host mirror: schema/indexes/stream settings, items, TTL -> Local

DynamoDB Local actual stream
  -> host Go pump
  -> synchronous Floci Lambda Invoke
  -> deployed handler

Floci native Lambda mapping
  -> native DynamoDbStreamService
  -> no Local writes
```

Evidence:

- `TEOS/deployment/lib/svctest/local_env.go:30-49` sets both host service-specific endpoints.
- `TEOS/deployment/lib/adapters/cdk/lambda/environment.go:248-280` supplies the function's Local DynamoDB endpoint only.
- `TEOS/deployment/lib/svctest/local.go:110-153,279-302` starts Floci, then Local, joins Local to the network, exports environment, mirrors after deploy, and starts the pump.
- `TEOS/deployment/lib/svctest/local_mirror_watch.go:14-56,123-172` implements the periodic deployment copy.
- `TEOS/go-core/utils/testutils/dynamodb_local.go:46,92-103,109-187` pins `amazon/dynamodb-local:3.3.1` by digest, defaults to `-inMemory -sharedDb`, and uses an application-level readiness probe after the TCP probe.

The pump resolves two identities: the Floci-declared stream ARN and Local's actual stream ARN. It reads the latter and puts the former in the Lambda event. It discovers policy from CloudFormation templates, not the incomplete Floci mapping response. See `ddbstreampump/discover.go:28-70,114-146`, `mapping.go:11-20`, and `event.go:23-49`.

The pump is not full AWS parity either:

- It enumerates paginated shards and waits for known parents, then reads each shard in order. See `pump.go:162-235`.
- It renews expired iterators using its last delivered sequence. Checkpoints are process-local. See `pump.go:237-298`.
- It supports partial-batch restart, retries, bisection, and SQS failure records. See `deliver.go:84-178,202-269`.
- Its general invocation-error path consumes the same retry counter as function failures. AWS documents different treatment of errors before invocation. Do not copy this behavior uncritically.
- Its failure-record `streamArn` is Local's ARN, while delivered events use the declared Floci ARN. Its failure-record function field is populated from `FunctionName`. Those are reasons to test the AWS failure envelope independently rather than declaring the existing pump a complete reference.
- Its TTL event conversion does not carry a `userIdentity` field. Attribute conversion does explicitly cover binary values and binary sets.

### 4.2 Floci public requests

DynamoDB is dispatched through the **JSON 1.0** controller:

```text
POST /, application/x-amz-json-1.0
  X-Amz-Target: DynamoDB_20120810.<action>
    -> AwsJsonController
    -> DynamoDbJsonHandler
    -> DynamoDbService / DynamoDbPartiQLHandler

POST /, application/x-amz-json-1.0
  X-Amz-Target: DynamoDBStreams_20120810.<action>
    -> AwsJsonController
    -> DynamoDbStreamsJsonHandler
    -> DynamoDbStreamService
```

`AwsJsonController.java:80-149` selects the handler, resolves region, maps exceptions, and adds DynamoDB CRC32. The descriptor registers both target prefixes at `ResolvedServiceCatalog.java:98-104`.

`docs/services/dynamodb.md:3` currently labels the protocol JSON 1.1. The actual controller and AWS Streams request examples say JSON 1.0. The implementation, not that heading, is the correct starting point for integration.

There is also existing CBOR dispatch to the same handlers at `AwsJsonCborController.java:398-430,474-478`. An implementation must not fix JSON while bypassing or corrupting this alternate path.

### 4.3 Native data and metadata

`DynamoDbService` creates four stores using `StorageFactory`: tables, items, exports, and imports. It also maintains an in-memory per-table item index, item locks, and transaction idempotency state. See `DynamoDbService.java:94-205`.

This is much more than a JSON forwarding target:

- `DynamoDbJsonHandler.java:47-94` dispatches control, item, batch, transaction, tag, resource-policy, TTL, backup-configuration, Kinesis-destination, import/export, and PartiQL operations.
- The handler itself mutates `TableDefinition` after service calls. For example, CreateTable builds indexes and then applies further table settings; see `DynamoDbJsonHandler.java:103-230` and following create-table handling. A replacement only at `StorageBackend` is therefore too low, and replacement only inside a few item methods is incomplete.
- Table descriptions and stream configuration are shared with direct internal callers through `DynamoDbService.java:403-485`.
- Actual native writes capture events and enqueue Kinesis forwarding from inside the write path. The condition check and item mutation are protected together by an item lock at `DynamoDbService.java:595-636`.
- Native TTL removes items from its own maps and emits its own stream and Kinesis events at `DynamoDbService.java:1836-1933`.
- Tags, resource policies, and resource discovery read native table metadata at `DynamoDbService.java:1937-2010,3947-3965`.
- Import/export and replicas also depend on native table/item state. See `DynamoDbService.java:1767-1832,3408-3943`.

The existing `DynamoDbConcurrencyIntegrationTest.java:200-223,287-314,319-383,455-499` tests conditional single-winner behavior, transaction behavior, and stream ordering. This report does not establish that all native semantics are correct. It establishes that “Floci has no conditional writes” would be an inaccurate diagnosis.

## 5. Integration inventory: what an external database must cover

All Floci Java paths below are relative to `src/main/java/io/github/hectorvent/floci/`.

| Boundary | Concrete current path | Consequence for external mode |
|---|---|---|
| Public DynamoDB and Streams | `core/common/AwsJsonController.java:80-149`; `services/dynamodb/DynamoDbJsonHandler.java:47-94`; `DynamoDbStreamsJsonHandler.java:38-154` | Both target families must select the same backend. Preserve AWS request/response envelopes, error detail, CRC32, and service enablement. |
| CBOR compatibility | `core/common/AwsJsonCborController.java:398-430,474-478` | Keep existing handler result shapes and test binary conversion. Do not return an opaque HTTP-client object from the controller. |
| CloudFormation tables/global tables | `services/cloudformation/CloudFormationResourceProvisioner.java:350-351,1786-1920,5717-5725` | Create, describe, tags, stream enable/disable, and delete bypass HTTP today. All must use Local when selected. Successful provisioning must mean the table actually exists there. |
| CloudFormation replicas | Same file `5317-5367` | `applyReplicaUpdates` is another native mutation path. Reject unsupported external global-table/replica behavior explicitly, or implement it against the selected backend. Never silently create native replicas. |
| CloudFormation event-source mappings | `services/cloudformation/provisioners/LambdaEventSourceMappingCfnProvisioner.java:60-150` | Preserve settings through the ordinary AWS resource type. Do not read private TEOS templates inside Floci to recover dropped options. |
| Lambda DynamoDB stream source | `services/lambda/DynamoDbStreamsEventSourcePoller.java:68-100,139-216,231-267` | Uses the native stream service, constant shard, and native checkpoint assumptions. Requires real shard discovery and delivery policy, not just a new client URL. |
| Pipes DynamoDB stream source | `services/pipes/PipesPoller.java:125-155,301-341,518-556,739-750` | Uses the same native stream service and constant shard. Has separate delivery and checkpoint defects relevant to an external stream. Lambda-only work leaves Pipes on the wrong source. |
| IoT DynamoDBv2 action | `services/iot/IotService.java:1432-1463,1527-1531,1673-1706` | Converts the projected IoT document to AttributeValues and calls `DynamoDbService.putItem` directly. Preserve that action and send the resulting operation to Local. |
| Step Functions optimized DynamoDB tasks | `services/stepfunctions/AslExecutor.java:956-971,1724-1806` | Direct put/get/delete/update and a scan-based path use the native service. Keep their existing AWS error-name conventions while changing database selection. |
| Step Functions AWS SDK tasks | Same file `1809-1840` | Calls the JSON handler internally. A network-edge proxy would not intercept it. |
| API Gateway AWS integration | `services/apigateway/AwsServiceRouter.java:145-167` | Calls `DynamoDbJsonHandler.handle` internally. The standard API Gateway integration URI must keep working without a custom endpoint. |
| IAM leading-key/attribute conditions | `core/common/IamConditionContextResolver.java:331-378` | Reads `findTable` for key schema before authorization. It must not read stale native metadata after requests begin using Local. |
| IAM target resource identification | `services/iam/ResourceArnBuilder.java:137-269` | Understands table/resource/stream ARNs, batch map keys, transaction entries, and PartiQL. Authorization uses public Floci/AWS identities, before translation to Local. |
| Resource Explorer/tagged inventory | `services/dynamodb/DynamoDbService.java:3947-3965` | Native table-store enumeration would hide every externally backed table. Use selected-backend enumeration plus supported ancillary metadata. |
| TTL worker | `services/dynamodb/DynamoDbTtlService.java:21-39`; `DynamoDbService.java:1861-1933` | Must not keep deleting an unrelated native map. Local TTL configuration and actual expiration need a stated capability contract. |
| DynamoDB-to-Kinesis destinations | `services/dynamodb/KinesisStreamingForwarder.java:27-46,71-98,136-200`; write calls in `DynamoDbService.java:620-633,1904-1916` | Native write hooks disappear when Local commits writes. They cannot be reused as proof that an external write committed. |
| Import/export, PartiQL, global replicas | `services/dynamodb/DynamoDbJsonHandler.java:78-90`; `DynamoDbService.java:1767-1832,3408-3943` | Route operations to Local when supported. Explicitly reject or separately adapt unsupported extensions. Never export the stale native table or execute native PartiQL against it. |

### Boundaries that are not implemented DynamoDB consumers today

These distinctions prevent unnecessary scope growth:

- **EventBridge rules:** `services/eventbridge/EventBridgeInvoker.java:78-157` dispatches Lambda, SQS, SNS, Batch, Firehose, and event-bus targets. The inspected implementation has no direct DynamoDB target branch. A Lambda target can subsequently write through its SDK. EventBridge **Pipes** is the relevant direct DynamoDB stream consumer and is listed separately above.
- **AppSync:** `services/appsync/AppSyncService.java:309-365,373-401` stores DynamoDB data-source and resolver configuration. `graphql/util/DynamoDbUtil.java` formats AttributeValues. `graphql/AppSyncSchemaParser.java:55-62` registers scalars but no DynamoDB data fetcher, and `graphql/SchemaRegistry.java:33-40` installs the resulting schema. The inspected code does not execute a DynamoDB resolver. An external backend must not advertise that it adds AppSync resolver execution merely because the data-source model names DynamoDB.
- **Application Auto Scaling:** DynamoDB namespaces and dimensions are accepted, but `services/applicationautoscaling/CapacityAdjuster.java:9` names DynamoDB adjustment as future work. It is not an existing data writer to migrate.
- Other bounded matches in Backup, FIS, EC2 endpoint metadata, cost enumeration, and Service Quotas describe resource/service names. No additional direct DynamoDB database client was found there.

### CloudFormation limitations already present

The inspected table-provisioning method reconciles tags and stream enablement. It does not implement a complete UpdateTable reconciliation. On `ResourceInUseException` it describes the existing table. It does not forward `TimeToLiveSpecification` in this method, nor reconcile all index/throughput/encryption settings. See `CloudFormationResourceProvisioner.java:1786-1920`.

Forwarding its existing calls to Local would remove the second-database deployment race. It would not, by itself, make those missing CloudFormation properties work. Acceptance must check exact schemas, stream ARN, TTL settings, and supported update behavior rather than only `CREATE_COMPLETE`.

## 6. Streams and event-source delivery are the largest technical gap

### 6.1 Native streams are a small in-memory implementation

The native stream service has:

- One fixed `SHARD_ID`.
- A maximum of 1,000 retained records per stream, not a 24-hour retention implementation.
- A process-global sequence counter.
- Stream lookup keyed by `region::tableName`, without account in that key.
- A persisted-table bootstrap that reconstructs stream descriptions, not persisted record history.
- A custom base64 iterator encoding with no time-based expiry.
- `GetRecordsResult(records, nextShardIterator)` without a paginated shard description.

See `DynamoDbStreamService.java:35-70,79-136,139-182,211-272,286-376`.

`DynamoDbStreamsJsonHandler.java:52-68,88-119` ignores ListStreams paging and fabricates the one shard for DescribeStream. It cannot represent Local's actual shard pages through its present `StreamDescription` model. Both the API handler and Lambda event builder hardcode `SizeBytes=100`; see `DynamoDbStreamsJsonHandler.java:149-174` and `DynamoDbStreamsEventSourcePoller.java:231-257`.

The absence of account in the native stream key is an existing isolation concern. It must not become the identity model of the external adapter.

### 6.2 Current Lambda mapping behavior

The DynamoDB poller:

- Reads one fixed shard.
- Uses `TRIM_HORIZON` whenever there is no checkpoint, irrespective of the mapping's saved `StartingPosition`.
- Uses `AFTER_SEQUENCE_NUMBER` for a saved checkpoint.
- Applies filter criteria and advances past fully filtered batches.
- Invokes synchronously and advances only when `FunctionError` is absent.
- Does **not** inspect a successful invocation's partial-batch response.
- Does **not** implement bisection, maximum retry attempts, record age, failure destination, batching windows, or parallelization in this path.

See the complete polling algorithm at `DynamoDbStreamsEventSourcePoller.java:139-216`.

`LambdaService.java:1278-1326` and `model/EventSourceMapping.java:16-38` can store several options, including `FunctionResponseTypes`, bisection, destination, and filter criteria. Saving an option is not the same as executing it. The model lacks maximum retry/record-age fields in this snapshot.

On startup the poller explicitly discards all persisted DynamoDB shard checkpoints because native streams lose their records and restart sequence numbering. See `DynamoDbStreamsEventSourcePoller.java:68-100`. That policy must remain native-specific. Applying it to a durable Local stream replays already processed data.

### 6.3 Current Pipes behavior

`PipesPoller.java:301-341` obtains the next iterator and saves it **before** delivery. If delivery and the dead-letter queue both fail, it logs dropped records. `ExpiredIteratorException` and `TrimmedDataAccessException` both discard the saved iterator. The initializer restarts at `TRIM_HORIZON` on the one fixed shard.

`PipesPoller.java:530-556` invokes once and falls back to the dead-letter queue. It also explicitly bypasses enrichment for stream sources. `buildDynamoDbRecordNodes` serializes the native record object rather than building the same AWS nested envelope used by Lambda.

Therefore “Pipes already uses DynamoDbStreamService, so replacing that bean is enough” is not correct. At minimum, real shard selection, source record shape, account scope, and iterator/checkpoint behavior must change. Full Pipes delivery parity is a separate product commitment. If it is deferred, external DynamoDB Pipes must be rejected clearly rather than silently left on the native database.

### 6.4 The required pull-based contract

AWS documents:

- Up to 24 hours of stream retention.
- Ordering of changes for the same item, not global ordering across all shards.
- Parent-before-child processing.
- A new stream identity after disable/re-enable.
- Shard iterator expiry after 15 minutes.
- GetRecords pages of at most 1 MB or 1,000 records.
- Empty pages that are not end-of-stream; null `NextShardIterator` means the shard is closed.

See official sources A8-A10 below. Local's exact retention, restart persistence, and shard-rotation behavior must still be tested for the pinned version.

The external reader must:

1. Page through ListStreams/DescribeStream as needed and discover real shard IDs and lineage.
2. Preserve the underlying stream-generation identity and actual sequence numbers.
3. Remember progress per account, region, mapping/pipe, stream generation, and shard.
4. Keep fetched iterator position separate from the last **disposed-of** record. A successful read is not a successful Lambda invocation.
5. Renew expired iterators from the last committed sequence. Do not reuse Local's token as if it were a native base64 iterator.
6. Treat trimming as possible data loss, with an explicit operational/error policy. Do not silently turn it into a fresh read from the beginning.
7. Preserve pending batches across retry decisions. Checkpoint successful prefixes on partial failure. Never advance past a failed record before success or an explicit discard policy.
8. Honor initial `LATEST` without continually resetting it on empty reads or restart. Newly discovered child shards must start at their beginning after parents are finished.
9. Apply filters to the exact event shape delivered to the function. A filtered record is consumed, but must not cause a later failed matched record to be skipped.
10. Stop and drain workers on mapping deletion, reset, or backend shutdown. A stale worker must not write a checkpoint or invoke a deleted mapping after reset.

Keep independent progress for independent mappings and Pipes. Lambda delivery is at least once: a crash after invocation but before checkpoint persistence, or a lost successful invocation response, can deliver a record again. Handlers still need idempotency. Do not promise exactly-once invocation because the stream contains one record per committed change.

This is ordinary Streams consumption. It needs no custom “inject change” endpoint, event bus masquerading as DynamoDB, or replacement of Local's actual write semantics.

## 7. Account, IAM, ARN, and protocol rules

### 7.1 Public identity stays with Floci

`AccountContextFilter.java:53-76` resolves request account and region from AWS credentials. `RegionResolver.java:129-163` falls back to configured defaults outside active request scope. `StorageFactory.java:46-100` gives native stores account-prefixed keys.

`IamEnforcementFilter.java:107-142` provides optional enforcement with existing permissive/root-bypass behavior. This is not full AWS IAM or signature verification. An external backend must preserve the existing public check rather than trusting Local to supply IAM.

The operation flow should be:

```text
Public AWS request / internal service operation
  -> resolve explicit owner account and region
  -> existing public authorization and service-enable behavior
  -> validate and translate only resource identities
  -> selected DynamoDB backend
  -> translate resource identities in result
  -> AWS-compatible response/event
```

For IAM condition lookup, the key schema must come from the selected database. A bounded metadata cache is possible, but it cannot become the authority for existence or updates. An unavailable Local endpoint must not make the resolver silently use a different table or treat missing metadata as an authorization shortcut.

### 7.2 Signing and Local namespaces

AWS's usage notes say:

- With `-sharedDb`, every client uses one file.
- Without it, filenames are based on access-key ID and region.
- These credentials need not be real AWS credentials.
- Access-key IDs must be alphanumeric.
- Distinct AWS accounts/regions are not natively supported at the client level.

Consequently:

- Do not forward each incoming user's access key unchanged. Two IAM users or rotating STS sessions in the same Floci account would select different Local databases.
- Sign downstream requests using a deterministic dummy identity for the **Floci account**, and the operation's region. A dedicated Local instance without `-sharedDb` can use this documented file separation as the adapter's namespace mechanism.
- Use the service's correct SigV4 signing name for both clients. Do not infer it from the human SDK class name or reuse arbitrary incoming Authorization headers after changing host/body.
- Never forward real customer AWS secrets. Never use the ambient default AWS credential chain for this internal endpoint.
- Never fall back to an AWS regional endpoint on configuration error.
- A shared/in-memory Local server cannot be advertised as multi-account isolated merely by rewriting output ARNs.

**Smallest recommended initial contract:** a dedicated Local endpoint for one Floci instance, using non-shared file-backed Local namespaces and stable account-derived dummy credentials. File storage can still be disposable at the user-managed sidecar lifecycle. This avoids per-table name rewriting and its complications for PartiQL, pagination, maximum name lengths, and mixed-table operations.

If maintainers instead want to support the TEOS driver's current `-inMemory -sharedDb` mode first, that must be a deliberately restricted single-account/single-region mode that rejects other scopes. It is not the same promise. TEOS's startup settings would need adjustment for a general multi-account adapter.

The endpoint alone does not reveal its command-line flags reliably. Startup configuration assertions and black-box isolation tests are necessary. Do not perform destructive scope probes automatically against an arbitrary user endpoint.

### 7.3 Resource identity translation

Do not assume Local's returned account/region strings equal Floci's. Obtain examples from the pinned server.

Translation must cover:

- Table and index ARNs in Create/Describe/Update/Delete results.
- Table ARN accepted as `TableName` by newer Local releases.
- `ResourceArn` in tags/policies and `TableArn` in extension requests.
- Table-name or ARN keys in batch maps and per-operation transaction members.
- `LatestStreamArn`, stream listings, descriptions, and stream-pagination fields.
- Lambda `eventSourceARN`, Pipes source identity, and failure-record `streamArn`.
- Public response region fields where Local emits its own value.

Keep table names unchanged under the credential-partition strategy. Keep Local's actual stream label/generation unchanged. Map the public account/region prefix to the exact Local identity, not a freshly invented timestamp.

Do not globally replace ARN-like strings in JSON. An item can legitimately contain an ARN in an `S` value. Mutating it would corrupt data.

Do not parse or edit Local's opaque shard iterator format. Pass it internally unchanged. For public iteration, determine experimentally whether the token can be forwarded safely with caller credentials. If Local accepts a token from another namespace or exposes backend-only identity that must be hidden, wrap it as an opaque, account-bound Floci token with a bounded lifetime and maximum-size handling. This is an isolation decision, not a reason to reuse the native iterator encoding.

A checkpoint must be invalidated when its backend/table/stream generation truly changes, not on every Floci restart. A Local restart that loses stream state must be detected and reported or handled by an explicit recovery policy.

### 7.4 Asynchronous ownership

Existing useful patterns:

- CloudFormation runs background provisioning under an explicit account scope: `CloudFormationService.java:635-696`.
- Step Functions wraps executions and parallel branches with the state machine's account: `AslExecutor.java:331-390`.
- Lambda stores the owner account on the mapping and uses `getForAccount`/`saveForAccount`: `DynamoDbStreamsEventSourcePoller.java:116-147,264-266`.
- Native TTL and Kinesis forwarding deliberately pass owner account outside request scope: `DynamoDbService.java:1874-1931`; `KinesisStreamingForwarder.java:71-98,136-196`.

But the stream service currently relies on ARN/global maps rather than an explicit account argument. A Local client must receive owner account and region for every asynchronous read.

Pipes keys workers by pipe ARN but derives only the source region in the DynamoDB polling path. IoT's rule runner derives region from the rule ARN while direct `putItem` still depends on ambient account. MQTT work can lack request scope; see `IotService.java:1283-1295,1329-1336,1432-1453,1527-1531`. Those paths need explicit owner propagation at their selected-backend call, not a default-account client cached at startup.

### 7.5 Data and error fidelity

The Local route should preserve DynamoDB AttributeValue JSON rather than converting values to ordinary Java maps or floating-point numbers:

- `B` and each `BS` member stay base64 in JSON, and become bytes only at the relevant SDK/CBOR boundary.
- `N` and `NS` stay strings. Preserve large and fractional decimal values.
- Preserve nested maps/lists, booleans, NULL, empty values where allowed, and absent versus empty image fields.
- Do not reconstruct stream images with GetItem. They represent the item at commit time, not its later state.

Preserve pagination and per-entry errors:

- `LastEvaluatedKey`, `LastEvaluatedTableName`, stream page fields, and PartiQL tokens.
- Filtered empty pages that still have a continuation key.
- `UnprocessedItems` and `UnprocessedKeys`, including original table identity.
- `ConditionalCheckFailedException.Item` when requested.
- Transaction cancellation reasons, their original order, `None` entries, and returned item values.
- Transaction idempotency token behavior. Do not decompose a transaction into independent calls.

`JsonErrorResponseUtils.java:13-51` does not preserve arbitrary upstream error members. The native handler separately constructs transaction cancellation details at `DynamoDbJsonHandler.java:1695-1711,1773-1789`. Simply throwing a generic `AwsException` for every Local error would lose them. The adapter needs a lossless operation result/error representation while keeping controller return values reflection-safe.

Recompute CRC32 after any resource-identity rewriting. Keep transport timeouts separate from AWS domain errors. A write timeout is an ambiguous outcome, not evidence that it did not commit. Avoid an additional blind retry layer that can duplicate successful writes/events.

## 8. One authority, including the awkward features

“One database authority” cannot honestly mean “Local implements every API Floci currently exposes.” Official AWS notes explicitly say Local does not support tags or PITR.

The achievable invariant is:

> There is exactly one owner of table existence, schema, item state, and stream history. Any ancillary metadata that Local cannot store has exactly one explicitly named owner and cannot create or shadow a table.

| Feature | Recommended external-mode ownership | What must not happen |
|---|---|---|
| Table creation, schema, indexes, updates, deletion | Local is authoritative. A returned native `TableDefinition` is a projection of a Local result for existing internal callers, not a second saved table. | Creating a native table first and mirroring later. Persisting a mutated projection as if Local accepted it. |
| Items, conditions, batches, transactions, supported PartiQL | Local executes them. Native expression evaluators do not pre-execute or replay the write. | Evaluating conditions in Floci, then issuing an unconditional Local write. Splitting a Local transaction. |
| Streams | Local creates and retains records. Floci consumes and translates identities only. | Capturing request bodies into native `captureEvent`, inventing old images, sequence numbers, or record success. |
| Tags | A small Floci-owned ancillary store is justified if maintainers want existing tag/CloudFormation behavior in external mode. Use `StorageFactory`; key by scoped table identity plus verified generation. | Claiming Local supports tags; duplicating all table metadata merely to retain tags; preserving old tags after delete/recreate. |
| TTL configuration | Forward supported Local TTL APIs and report their actual state. Whether expiration occurs is a pinned-version experiment. | Reporting expiration parity from an accepted UpdateTimeToLive request, or letting the native sweeper act on another map. |
| TTL expiration if Local does not perform it | Explicitly document unsupported expiration in the opt-in backend, or defer that backend for workloads requiring it. A future scanner/conditional-delete feature requires a separate semantics decision. | Calling synthetic removals equivalent to AWS TTL, especially for stream `userIdentity` and concurrent updates. |
| Resource policies | Preserve Floci's existing enforcement boundaries. If external-mode policy APIs are retained, ancillary storage and deletion/generation handling must be explicit. Otherwise reject those operations. | Claiming IAM/resource-policy parity just because policy JSON can be stored. |
| PITR/backups, import/export, global replicas | Publish a supported operation matrix. Initially reject unsupported operations rather than run native jobs on unrelated data. | Returning native job success while exporting empty native items, or silently accepting a global-table declaration with no replication. |
| Kinesis streaming destinations | Initially reject unsupported external-mode destinations explicitly. A later implementation would have to consume actual committed Local records and preserve the separate destination contract. | Leaving native write hooks active and assuming they observe Local commits. Enabling a destination that never sends records. |
| Resource discovery | Enumerate Local tables for the selected scope and join supported ancillary tags. | Returning the unused native table-store inventory. |

A tags-only ancillary store is not a second item database. It is still an added consistency responsibility: create/delete failure, retry, process crash, and out-of-band Local deletion/recreation must be specified. The smallest safe contract requires all management changes through Floci and a dedicated endpoint. If out-of-band management must be supported, generation validation and reconciliation are additional required work.

The default native backend can retain its current import/export, TTL, Kinesis, and replica implementations. Backend selection must be all-or-nothing for table/data authority, not an undocumented fallback per request.

### Documented Local differences, not defects to hide

AWS usage notes and release history identify differences that integration cannot erase:

- No native distinct-account/region model.
- Ignored provisioned throughput, and no actual throughput throttling.
- No parallel Scan behavior.
- Different index page-size accounting.
- No `TransactionConflictException` simulation.
- Case-insensitive table names, unlike AWS.
- No tags or PITR.
- Different shard creation behavior.
- Null `billingModeSummary`.
- Newer APIs may be accepted but ignored, such as documented vector-index parameters.

The usage notes say ExecuteStatement ignores `Limit`, while release history has an older “Support of Limit Operation” entry. That discrepancy is a reason for a versioned experiment, not a reason to pick whichever sentence supports a desired conclusion.

Using Amazon's implementation is valuable for conditional and transactional semantics, but is not proof of universal AWS parity.

## 9. Lifecycle, configuration, storage, and networking

### Current Floci lifecycle

- `StorageFactory.java:57-100` caches stores by file path, loads them, and wraps them for account scope.
- `StorageFactory.java:106-145` implements load, flush, clear, and shutdown.
- `EmulatorLifecycle.java:191-203` loads state before starting persisted Lambda/Pipes pollers.
- `EmulatorLifecycle.java:302-325` flushes before lengthy container shutdown and later performs final storage shutdown.
- `EmulatorInfoController.java:135-158` invokes all `Resettable.clear()` methods and then clears all stores.
- `DynamoDbService` and `DynamoDbStreamService` do not implement `Resettable` in this snapshot. Their in-memory indexes/buffers are not covered merely by clearing the stores. This is a relevant existing reset limitation, not a safe template for external reset.
- Poller `clear()` cancels timers but does not await all currently executing work. External I/O makes stale work after reset particularly important.

### Configuration ownership

`EmulatorConfig.DynamoDbServiceConfig` currently contains only `enabled()` at `EmulatorConfig.java:1122-1125`. Main and test YAML enable DynamoDB at `src/main/resources/application.yml:268-269` and `src/test/resources/application.yml:127-128`. The effective global storage default is **memory** in both YAML files, not an inferred interface default.

The minimal external option needs a selected backend and endpoint, bounded connection/request timeouts, and an explicit ownership/reset contract. Exact setting names are a maintainer decision. They belong under `floci.services.dynamodb.*`, with `FLOCI_*` environment conventions and defaults preserving the native backend.

Do not make Local a `StorageFactory` storage mode. A remote DynamoDB engine supplies transactions, streams, and protocol semantics. It is not equivalent to swapping a map's persistence implementation.

Use `StorageFactory` for Floci-owned ancillary metadata and existing mapping checkpoints. In external mode:

- Local owns its SQLite/database lifecycle.
- Floci's `memory`, `persistent`, `hybrid`, and `wal` settings govern Floci metadata only.
- A Floci `flushAll()` cannot promise to flush or snapshot Local.
- Persisting Local data while losing all mappings/tags on a Floci memory-mode restart is a real contract choice that must be visible.
- Do not load and expose old native DynamoDB files as shadow external tables.
- Changing backend with existing data is not an implicit migration. Require an explicit empty/test environment or separately approved migration behavior.

### Existing container patterns to reuse, and not copy blindly

ECR's `EcrRegistryManager.java:34-44,165-189,220-260,465-490` already shows a shared backing container, internal versus host endpoints, lazy startup, adoption, reconciliation, and keep-running behavior. Its account/region repository namespace at lines 171-173 is a useful analogy for ownership.

RDS's `container/RdsContainerManager.java:45-61,109-154,175-204` tracks storage/runtime owners and handles startup/cleanup failure. ElastiCache's `container/ElastiCacheContainerManager.java:30-47,75-103,140-155` distinguishes host networking from container networking and probes the actual protocol.

However, ECR/RDS/ElastiCache can deliberately keep management metadata working when the backing container is unavailable. That behavior must **not** be copied as “CreateTable succeeds in native metadata when Local is down.” It would recreate the two-authority defect.

### Recommended first lifecycle: externally owned endpoint

This is smaller than introducing another Floci-managed container:

1. The user or existing test harness obtains and starts the official pinned Local image.
2. Floci connects to an explicit endpoint.
3. No Docker socket is needed by the DynamoDB integration.
4. Floci never stops, adopts, removes, or deletes the user's external container or volume.
5. A signed, side-effect-free ListTables request proves application readiness. Open TCP alone is insufficient.
6. Validate readiness before starting persisted consumers or reporting DynamoDB ready. Fail selected-backend operations clearly during outages; never fall back to native data.
7. On shutdown, stop consumers and cancel/await bounded calls before closing the client and saving final checkpoints. Do not shut down Local.

The existing health endpoint derives service status from `ServiceRegistry`, not from an external database probe; see `EmulatorInfoController.java:55-66`. Its current “running” label must not become a false statement that Local is reachable.

### Network consequences

- If both run on a Docker network, Floci needs `http://ddblocal:8000`, not the host's loopback-mapped port.
- If Floci runs on the host, use the host-published loopback endpoint.
- A remote Docker daemon changes which host a published address refers to. The explicit endpoint remains the least ambiguous first interface.
- Once all callers use Floci, Lambda containers need Floci's usual AWS endpoint, not a separate Local endpoint or route.
- Do not expose Local publicly. Its dummy-credential support is not an authorization boundary.
- Validate that configuration is HTTP(S), not an arbitrary URI, and reject accidental public AWS endpoints by policy unless a separately approved remote-backend feature exists.
- AWS documents Local telemetry and how to disable it. Recommend `-disableTelemetry` or `DDB_LOCAL_TELEMETRY=0` for a local-only test environment. The external operator owns that setting.

TEOS currently starts Floci before Local. Strict external-backend startup readiness requires changing that order or delaying only DynamoDB readiness until Local is attached. The current initialization sequence cannot simply receive an endpoint and remain unchanged.

### Reset is a product decision, not automatic permission to delete

For an externally supplied endpoint, a Floci-wide reset must not enumerate and delete every Local table merely because the endpoint is reachable.

The safest first contract is to refuse destructive DynamoDB reset unless ownership and an explicit reset opt-in are established. Preflight that decision before clearing unrelated Floci stores, so reset cannot return a misleading partial “OK.”

An optional destructive mode could delete only resources/namespaces that this Floci instance explicitly owns, after quiescing readers and writes. It must preserve other accounts or other instances' data according to the chosen ownership contract. Reused names, deletion protection, partial failure, retained CloudFormation resources, and lost ownership metadata all need tests.

A future Floci-managed sidecar can have stronger lifecycle ownership and volume cleanup rules. It is a separate convenience slice, not a prerequisite for the correct database boundary.

## 10. Licensing findings from primary sources

All sources in this section were retrieved on **2026-09-18**. This is engineering research, not legal advice.

### 10.1 Verified sources and short excerpts

| Ref | Primary source and date | Relevant text or finding |
|---|---|---|
| **A1** | [Amazon DynamoDB Local License Agreement](https://aws.amazon.com/dynamodb/dynamodblocallicense/). No revision date displayed in the inspected text. | “License” grants a personal, limited, non-transferable, non-sublicenseable license for owned/controlled equipment, internal business purposes, and use “in connection with the Services.” It also requires an AWS account in good standing. |
| **A2** | [Published 3.3.1 POM](https://repo.maven.apache.org/maven2/software/amazon/dynamodb/DynamoDBLocal/3.3.1/DynamoDBLocal-3.3.1.pom) and [`DynamoDBLocal-3.3.1.jar`](https://repo.maven.apache.org/maven2/software/amazon/dynamodb/DynamoDBLocal/3.3.1/DynamoDBLocal-3.3.1.jar), `LICENSE.txt` entry. Release date from A6: 2026-05-28. | POM names “DynamoDB Local License Agreement,” with URL `classpath:LICENSE.txt`. Packaged text includes the same incorporation/distribution restrictions as A1 and a note about identified files under `THIRD-PARTY-LICENSES.txt`. Only the license entry was read. |
| **A3** | [AWS Service Terms](https://aws.amazon.com/service-terms/), **last updated 2026-09-15** in inspected page. | §1.1 restricts transferring supplied software outside the Services without specific authorization. §1.2 requires compliance with current technical documentation. §1.4 assigns responsibility for software-license compliance. No DynamoDB Local-specific redistribution grant was found. |
| **A4** | [AWS Customer Agreement](https://aws.amazon.com/agreement/), **last updated 2026-08-14**; [AWS Intellectual Property License](https://aws.amazon.com/legal/aws-ip-license-terms/), **last updated 2025-10-27**. | Agreement §6.3 incorporates the IP License; §6.4 contains use/resale restrictions; §11.2 states contract/policy precedence. IP License §3 says a separate license prevails for the content it covers. §4 restricts distribution except where separately permitted. Do not use obsolete section numbers from an older agreement. |
| **A5** | [Deploying DynamoDB locally](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocal.DownloadingAndRunning.html), current documentation, no page revision date. | Documents JAR, Docker Compose, and Maven deployment. It explicitly shows `amazon/dynamodb-local` as a **separate service** next to an application. Recommends Local v3. |
| **A6** | [Local release history](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocalHistory.html). | Latest listed release inspected: **3.3.1, 2026-05-28**. v3 migrates server packages to `software.amazon.dynamodb.services`; earlier entries explicitly refer to “Embedded Mode.” v3.2 adds DescribeStream ShardFilter support. |
| **A7** | [Official `amazon/dynamodb-local` image description](https://hub.docker.com/r/amazon/dynamodb-local), current page, no license revision displayed. | Describes local development/testing and inclusion in containerized builds and CI. Links AWS usage notes. The inspected image description contains no separate permission to redistribute AWS's server as part of another image. Image layers/license files were not pulled. |
| **A8** | [Local usage notes](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocal.UsageNotes.html). | Describes namespace/file flags and differences from AWS, including no tags/PITR and no transaction-conflict simulation. |
| **A9** | [DynamoDB Streams](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Streams.html). | Documents actual stream ordering, shard lineage, retention, and stream generations. |
| **A10** | [GetShardIterator](https://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_streams_GetShardIterator.html) and [GetRecords](https://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_streams_GetRecords.html). | Documents 15-minute iterator expiry, 24-hour retention, 1 MB/1,000-record limits, and closed versus empty shard pages. |
| **A11** | [Partial batch responses](https://docs.aws.amazon.com/lambda/latest/dg/services-ddb-batchfailurereporting.html) and [DynamoDB mapping failure handling](https://docs.aws.amazon.com/lambda/latest/dg/services-dynamodb-errors.html). | Partial failure restarts at the lowest failed sequence; bisection does not consume retry quota; before-invocation failures are not handled identically to function failures. |
| **A12** | [AWS SDK for Java v2 license](https://github.com/aws/aws-sdk-java-v2/blob/master/LICENSE.txt), Apache License **2.0, January 2004**. | §2 grants distribution rights for that SDK. §4 requires license/notice and other applicable preservation obligations. This does not license the separate Local server. |
| **A13** | [Local telemetry documentation](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocalTelemetry.html). | Documents `-disableTelemetry`, `DDB_LOCAL_TELEMETRY=0`, and `DynamoDBEmbedded.create(...)` examples. This is direct evidence that AWS documents embedded technical use. |

The decisive Local license language is in the named **“Limitations”** section, not an Apache license:

- Clause (a): “incorporate any portion of it into your own programs or compile any portion of it in combination with your own programs.”
- Clause (b): includes “distribute” and “sub-license the Software.”
- Clause (d): prohibits reverse engineering, disassembly, and decompilation.

The **“License”** section reserves rights for separately licensed open-source components. The packaged **“Note”** points to identified third-party files. Neither statement licenses the entire server under Apache or MIT.

The **“Amendment”** and **“Conflicts”** sections also matter: current terms can change, and an update can have a different accompanying license. Version pinning alone does not replace checking its license.

### 10.2 Practical licensing matrix

| Scenario | Engineering feasibility | What the verified terms support or constrain | Recommendation |
|---|---|---|---|
| Developer uses AWS's JAR/image locally to build/test an AWS application | Officially documented. | Subject to A1's internal-purpose, Services-connection, equipment-control, and AWS-account conditions. Offline operation and fake SDK credentials do not remove those contractual conditions. | Reasonable documented use case, with license acceptance/compliance owned by the user. Do not advertise “no AWS account required” as a legal conclusion. |
| Private Java tests call the documented embedded API | Technically documented by A5/A6/A13. | A1/A2 incorporation wording creates an interpretation question when applied to embedding. Documentation is evidence of intended technical use, not an explicit general redistribution license. | If desired for a private test harness, have counsel/AWS reconcile the exact use with the license. No assertion here that all embedded use is unlawful or automatically permitted. |
| Merge Local implementation into Floci source | No open-source implementation grant was identified. | Proprietary ownership and modification/incorporation restrictions apply. | Do not pursue. This is not equivalent to importing an Apache SDK. |
| Add Local JAR/native libraries to the published Floci JVM application or native image | JVM embedding is technically possible in principle. Quarkus native-image compatibility is unproved. | A1/A2 expressly constrain incorporation and distribution. No separate redistribution permission was found. | Do not ship without a separately applicable permission/legal determination. Preserve notices if permission is obtained; notices alone are not permission. |
| Build a Floci Docker image with Local copied into it or base it on the Local image and redistribute | Technically possible as a multi-process image. | Redistributes the proprietary server. The Docker description supplies no exception. | Not recommended. Do not relabel the combined image as wholly MIT/Apache. |
| User pulls official Local image, runs it separately, supplies endpoint to unchanged-distribution Floci | Official separate-container topology is documented. | Floci distributes its adapter only, not the AWS server. User remains responsible for Local license compliance. | **Preferred first distribution model.** Link the AWS license and official image; identify it as an optional proprietary external dependency. |
| Floci automatically pulls/runs the official image on user's machine | Technically matches existing container management patterns. | Avoids shipping the bits in Floci's image, but automated procurement/use and acceptance of terms require an explicit product/legal decision. | Later optional convenience, with no rehosting, explicit operator choice, and a clear license notice. Not required for the first adapter. |
| Hosted/shared emulator service using Local for unrelated customers | Technically possible, not the documented internal dev/test topology. | Internal-use and service-bureau/public-communication restrictions are directly relevant. | Outside this recommendation. Requires legal review and likely a separate permission. |
| Include only an AWS SDK client or a signer library | Normal dependency use. | That dependency's Apache or other license governs its own code. It does not extend to Local. | Prefer an existing HTTP/signing capability; if adding the SDK, retain required LICENSE/NOTICE and account for native-image support. |

**Bottom line:** Do not give a blanket legal “yes, merge/redistribute it.” The strongest low-distribution-risk design is protocol integration with a user-obtained external Local process. AWS's documented embedded support and its license wording should be put to legal review if embedding remains a requirement.

## 11. Three real approaches

### A. Embed the Local Java artifact inside Floci

**What it would solve:** Can put the real data engine behind all relevant service calls, avoiding a network hop.

**What it does not solve:** Internal call routing, Local capability gaps, public ARN translation, account partitioning, stream consumers, Lambda/Pipes delivery, reset, and metadata ownership still need work.

**Additional costs:** License incorporation/redistribution concerns; server/JNI dependencies; Jetty/Jackson/SDK dependency interactions; unverified Java 25 and Quarkus native-image behavior; lifecycle and telemetry management inside Floci.

**Verdict:** Not the smallest credible deliverable. Do not choose without a separate legal and native-build feasibility decision.

### B. Add only an external Streams reader to Floci

**What it would solve:** Could remove the host pump after matching its required delivery behavior.

**What remains:** CloudFormation table mirroring, its timing race, separate metadata authorities, per-function endpoint injection, and in-process IoT/Step Functions/API Gateway writes to the wrong database.

**Costs:** Still requires real shard handling, ARN mapping, retry/checkpoint semantics, and external ownership configuration. Much of the hard stream work remains.

**Verdict:** A coherent partial feature if explicitly sold as “external stream source,” not as unified DynamoDB. It does not meet the full issue set and should not be the default recommendation here.

### C. Optional Local-backed DynamoDB service, external endpoint first

**What it solves:** One schema/item/stream authority for HTTP callers and internal service callers. Eliminates the mirror timing race. Allows all ordinary client calls to go through Floci. Can remove the pump once mapping delivery is complete.

**Costs:** A precise operation boundary; explicit ancillary metadata and unsupported-feature policy; account and identity translation; real Streams consumers; lifecycle/health/reset handling.

**Verdict:** **Recommended candidate for approval.** It has the smallest distribution/lifecycle burden among complete solutions and does not require a generic plugin system or replacement of every native DynamoDB method with a new framework.

## 12. Recommended implementation boundary, if approved

Use one concrete Local request client at the DynamoDB service boundary. Reuse Floci's existing handlers, models where adequate, and lifecycle/configuration patterns.

The minimal required structure is:

1. A single selected-backend decision for DynamoDB and DynamoDB Streams.
2. A concrete client that executes ordinary AWS DynamoDB/Streams operations against the explicit endpoint with explicit account/region.
3. An external action path before the existing JSON handler performs native validation, expression evaluation, or `TableDefinition` mutation.
4. Delegation from the small set of actual direct service callers to that same client/selection. Existing typed service methods can translate their arguments and project returned descriptions; they must not maintain a second item/table store.
5. Stream result shapes sufficient for real shard pages, opaque tokens, and full event records. The existing constant-shard model is not sufficient.
6. Separate, narrowly owned ancillary metadata only for explicitly supported APIs that Local lacks.

Do not start by extracting all 3,967 lines of `DynamoDbService` into a speculative interface, inventing a pluggable database framework, or teaching all AWS services about HTTP URLs. The externally backed behavior should be localized, but it cannot omit a listed direct caller.

Keeping handlers transport-oriented still matters. Do not solve every internal caller by making it construct a loopback HTTP request through Floci's public authentication layer. Existing handler-based callers already exist, but that is not a reason to turn all internal business logic into JAX-RS response parsing.

### Why smaller shortcuts fail

| Shortcut | Failure visible to a developer |
|---|---|
| Proxy only `POST /` DynamoDB targets | SDK creates one database, while CloudFormation/IoT/optimized Step Functions use another. |
| Proxy only item APIs | Local receives writes for tables that exist only in native metadata. Index/stream changes drift. |
| Swap `StorageBackend` | Native condition/transaction/stream implementation still runs. Local is reduced to a map rather than being the authority for DynamoDB semantics. |
| Route only Lambda's stream service | Pipes and public Streams still disagree; mirror race persists. |
| Inject events after a proxied write | Cannot reliably determine commit on timeout, transaction cancellation, conditional failure, batch partial success, or old image. Misses out-of-band writes and TTL. |
| Read current item to construct NewImage/OldImage | Races with concurrent writes and invents historical state. |
| Use Local's output ARNs unchanged | CloudFormation references, Lambda mapping ARN, IAM resource matching, and region/account identity disagree. |
| Rewrite every string containing an ARN | Corrupts user item attributes. |
| Reuse incoming credentials downstream | IAM users/STS sessions for one account split into different Local databases. |
| Force `-sharedDb` and change ARN prefixes | Different accounts/regions still share the same table. |
| Clear every checkpoint on Floci startup | Replays durable external records. |
| Advance the iterator before invoking | Loses records on function or destination failure. |
| Let native TTL/Kinesis/import/export continue | These features observe or mutate the abandoned native maps, not Local. |
| Enable native mappings while retaining the TEOS pump | Both consumers invoke the same function for Local records. Tests can pass while duplicate side effects occur. |

## 13. Narrow acceptance experiments, not executed results

Run these only after the relevant approval. Use a pinned official Local image, dummy credentials, disposable **owned** resources, bounded timeouts, and disabled telemetry. No paid AWS calls are required for these local experiments. AWS parity claims beyond the documented contract need separate authorized AWS testing.

| Experiment | Smallest useful setup and evidence | What it decides |
|---|---|---|
| **E1: Local identity and namespaces** | Direct SDK calls to two account-derived credential scopes and two regions. Same table name in each. Record table/index/stream ARNs, distinct items, and behavior with versus without `-sharedDb`. Include two user keys mapped to one Floci account. | Whether the proposed partition/signing scheme isolates correctly. Whether current TEOS flags must change. |
| **E2: Data and error fidelity** | Through Floci external mode, race two conditional writers; run successful and canceled transactions with a token; repeat with changed payload; test batch unprocessed/error shapes. Exercise binary keys, binary sets, nested attributes, 38-digit numbers, returned condition-failure items, and cancellation reasons. Compare with direct Local results. | That Floci preserves Local semantics rather than silently evaluating/reformatting them. |
| **E3: Pagination and alternate protocol** | Small Query/Scan limits with filters that create an empty page plus continuation key; list-table paging; PartiQL limit/token behavior; binary JSON and existing CBOR test paths; CRC validation with a real SDK. | That no operation or error envelope is lossy. |
| **E4: One authority during deployment** | Ordinary CloudFormation table with GSI, stream, tags, TTL property, Lambda, mapping, and a custom resource that writes immediately after a table dependency. Disable mirror and pump. Assert actual backend schema and write visibility, not status alone. Add one API Gateway, IoT, and each Step Functions integration write. | Eliminates sections 1.3 and 1.6 rather than hiding their symptoms. Finds missing CFN property forwarding. |
| **E5: Real stream identity and restart** | Put/update/delete through Floci; read actual Local stream through public Floci APIs and a mapping. Disable/re-enable stream, delete/recreate table, restart Floci while Local stays alive, then restart Local separately. | Stable public identities, changed generations, preserved checkpoints, and explicit recovery when history disappears. |
| **E6: Stream iterator contract** | Read all shard pages, empty pages, closed shards, and renewed iterators. Let a token expire in a bounded dedicated test. Use a fake protocol peer for deterministic parent/child, trim, and transient-error cases Local cannot readily induce. | Correct source-reader algorithm without claiming a single quick run proves retention/shard rotation. |
| **E7: Mapping delivery** | A deployed handler returns one partial failure, then a function error, then success. Verify lowest failed-sequence restart, bisection, no retry-quota charge for bisection, before-invoke throttling, retry exhaustion, and the exact SQS failure envelope. Test fully filtered and partially filtered batches. | Whether the host pump is removable. |
| **E8: Pipes** | A Local stream feeding a normal Pipe target, with filter and a failing target/dead-letter destination. Verify account scope, full DynamoDB event shape, shard progress, and no premature checkpoint. | Whether external DynamoDB Pipes is supported or must be explicitly rejected in the first release. |
| **E9: TTL and unsupported controls** | Enable TTL, write expired and unexpired numeric TTL values, observe actual deletion and stream identity for a documented bounded interval. Probe tags, PITR, replicas, Kinesis destination, and selected unsupported parameters on pinned Local. | Exact external capability matrix. A timeout proves “not observed in this interval,” not universal TTL absence. |
| **E10: IAM and background accounts** | With Floci IAM enforcement enabled, deny one key through `dynamodb:LeadingKeys`; test allowed/denied table ARNs, batch/transaction resources, and copied iterator tokens. Run CFN, Step Functions parallel branches, Lambda mappings, Pipes, and IoT work outside the HTTP request scope in a nondefault account. | No default-account leakage or authorization bypass introduced by translation. |
| **E11: Lifecycle and ownership** | Local unavailable at startup and during writes; delayed readiness; two Floci instances; Floci reset with external deletion denied; owned reset opted in; partial deletion failure; shutdown during a pending batch. Verify an unrelated Local table survives. | Safe health/reset/shutdown contract and no native fallback. |
| **E12: Default regression** | Existing focused DynamoDB, Streams, CBOR, CloudFormation, Step Functions, IAM, and Pipes suites with the option absent. Include JVM and the project's native build path once runtime code changes. | Default Floci behavior and packaging remain intact. |

Existing relevant tests include `DynamoDbConcurrencyIntegrationTest`, `DynamoDbAccountIsolationIntegrationTest`, `DynamoDbCborIntegrationTest`, `DynamoDbLimitBoundaryPaginationIntegrationTest`, `DynamoDbFgacEnforcementIntegrationTest`, `DynamoDbStreamServiceTest`, `DynamoDbStreamsEventSourcePollerTest`, `DynamoDbTtlForwardingTest`, `DynamoDbKinesisStreamingIntegrationTest`, `DynamoDbStreamSpecificationCfnProvisionerTest`, `LambdaEventSourceMappingCfnProvisionerTest`, `StepFunctionsDynamoDbIntegrationTest`, and `PipesPollerTest`. Expand them narrowly rather than adding a second unrelated conformance framework.

## 14. Candidate PR-sized slices and actual dependencies

These are possible ownership boundaries for discussion, **not an approved execution plan**. “Independent” means a slice can be reviewed and merged without claiming that the whole backend is ready. No intermediate PR may publicly activate a half-routed backend.

| Slice | Owner | Bounded content | True merge dependencies |
|---|---|---|---|
| **R0: Decision and license record** | Floci maintainers + legal/package owner; TEOS owner consulted | Decide external versus embedded distribution, supported first-mode scopes/features, tags/TTL/reset contract. Retain this research link and unresolved decisions. | None. Approval prerequisite for backend feature work, not a source PR requirement imposed by this report. |
| **R1: Mapping property preservation** | Lambda + CloudFormation maintainers | Add/validate/persist required DynamoDB retry/age settings and forward required existing CFN properties. Verify create/read/update without changing unrelated source types. | None technically; semantics need agreement. Independently valuable for native Floci. |
| **R2: DynamoDB Lambda delivery correctness** | Lambda maintainer | Partial response, bisection, retry/discard destination behavior, filtering/checkpoint interaction, correct initial position. Use existing native stream and fake-source tests. | R1 for new saved fields. Does not depend on Docker or Local. |
| **R3: Dormant Local transport and contract tests** | DynamoDB/protocol maintainer | Concrete endpoint client, explicit account/region signing, lossless operation/error envelope, bounded timeouts, identity tests. No public selector enabling incomplete routing. | R0's decisions. Independent of R1/R2. |
| **R4: Single-authority control/data routing** | DynamoDB maintainer, with CFN/IoT/Step Functions reviews | Route public and direct internal operations; metadata projection; supported tags/other ancillary policy; IAM lookup and resource enumeration; explicit unsupported-operation behavior. Cover CFN property gaps needed by the accepted contract. | R3. Do not change the legacy CloudFormation monolith broadly or add new types to it. |
| **R5: Actual Streams API and source traversal** | DynamoDB Streams maintainer | Local stream pages/records/tokens, actual shards/lineage, generation-scoped checkpoints, public Streams and Lambda source integration. Native checkpoint-reset behavior stays native-specific. | R3 and agreed identity model from R4. Can be developed beside R4 but cannot declare routing complete without it. |
| **R6: Pipes external stream boundary** | Pipes maintainer | Same actual source, explicit owner scope, AWS event shape, safe progress and selected delivery support. Alternatively, an explicit external-mode rejection if that is the approved scope. | R5. Does not depend on Lambda's failure-policy implementation R2. |
| **R7: Lifecycle/config/activation** | Runtime/config/storage maintainer | Main/test YAML, service metadata mode contract, readiness, client closure, worker quiescing, non-destructive external reset, docs, release-facing capability matrix. Activate only when complete. | R4, R5, R6; R2 is required before advertising TEOS pump replacement. |
| **R8: Optional managed sidecar** | Docker/runtime + legal/package owner | Reuse container/network/storage helpers, official image pin, readiness, ownership/keep-running policy and license notice. No bundling into the Floci image. | R7 and explicit procurement/legal decision. Not needed for the endpoint feature. |
| **R9: TEOS adoption and deletion gates** | TEOS harness/deployment maintainer | Reorder startup as needed, configure Floci backend, point all host/function SDK clients at Floci, stop starting the pump, remove mirror only after proofs, update guards and issue/watch state. | Released/available R7 plus E1-E12 relevant to the chosen TEOS contract. No dependence on R8 if the existing harness owns Local. |

Several independent slices can be discussed in parallel: Lambda property/delivery correctness does not require a Local client; licensing does not require a source refactor; a transport contract test does not require TEOS changes. Public activation is the deliberate join point.

## 15. Removal gates for TEOS

Do not remove a workaround because a new configuration property exists or a mapping response echoes another field.

### Gate A: Remove mirror and deployment watcher

- Ordinary CloudFormation creates the actual Local table and all schema/settings required by the workload.
- A custom resource can write to it immediately after the table dependency completes.
- Create/update/delete/retain behavior is checked against the authoritative database.
- All direct Floci service writes use the same database.
- The test runs with both mirror paths disabled from the start.

Then `local_mirror.go` and `local_mirror_watch.go` become removal candidates. Do not keep them as a second writer “for safety.”

### Gate B: Remove host stream pump

- An actual Local write invokes the deployed function through Floci's ordinary event-source mapping.
- Partial batch failure, retry limits, bisection, filter/checkpoint behavior, and the workload's SQS failure destination are verified.
- The CloudFormation mapping properties survive without consulting a TEOS template from inside the runtime.
- Stream generations, restart, disable/delete, and failure reporting have defined behavior.
- The test runs without the host pump. Native mapping and pump must never both serve the new route.

Then `ddbstreampump` and harness discovery/start/stop/error calls become removal candidates. Current pump limitations are not evidence that a weaker replacement is acceptable.

### Gate C: Remove endpoint split

- Both DynamoDB and Streams SDK clients on host and in Lambda use Floci's normal AWS endpoint.
- Remove the special function injection and host-specific Local endpoint exports/guards together.
- Local remains reachable by Floci, not required by every Lambda container.
- No default AWS credential or endpoint fallback can send a local test to real AWS.

Then sections 1.2 and 1.3 can close with concrete evidence. Local may still run as a separate user-owned process; removal of the **endpoint split** does not mean removal of Local.

### Gate D: Close remaining limitations honestly

TTL expiration and settings not supported by the new mode remain explicit issues until tested and supported. A tags overlay is not PITR. A working Lambda mapping is not proof of Pipes or AppSync parity. Update **W-4/F-6/W-22/P-22** only for the behaviors actually delivered.

## 16. Unanswered product decisions and risks

The following require explicit answers before an implementation plan is approved:

1. **Distribution:** Is user-supplied Local acceptable, or is embedded/bundled delivery a requirement? The latter needs legal permission/interpretation and native-build evidence.
2. **Account contract:** General multi-account/region external backend, or a deliberately restricted single-scope shared/in-memory mode? Do not advertise both from the same unverified setup.
3. **Ancillary metadata:** Are tags supported by a Floci store? What resource-policy and discovery guarantees are required? Who owns cleanup after external table recreation?
4. **Local-only feature gaps:** Which of TTL expiration, PITR, import/export, Kinesis destinations, replicas/global tables, and newer DynamoDB APIs must work in the first release? Unsupported requests need an AWS-shaped, documented failure or an explicit documented Local limitation.
5. **Streams durability:** Does the pinned Local version retain stream history through restart? How is a changed database generation identified without parsing proprietary internals?
6. **Delivery scope:** Is first-release Pipes required, or will external DynamoDB Pipes be rejected? What unsupported Lambda settings are rejected instead of accepted and ignored?
7. **Reset ownership:** Is an external endpoint always dedicated? Is destructive reset ever permitted? How does a global Floci reset report a protected external database?
8. **Out-of-band access:** Are direct Local management calls supported? Allowing them expands tag/generation/reconciliation requirements. The smallest contract makes Floci the sole public management path.
9. **Failure policy:** What must operators see when Local is unreachable, history is trimmed, a failure destination is unavailable, or persisted state refers to a missing table? Logs alone should not let a compatibility test report success.
10. **Legal account requirement:** How will documentation reconcile a local “no cloud calls” developer experience with the license's AWS-account-in-good-standing and Services-connection wording?
11. **Version support:** Which Local version is tested? How are dependency/CVE updates pinned and compatibility-tested? “Latest” is not a stable backend contract.

### Confidence

- **High:** HTTP-only proxying is insufficient; exact in-process callers and stream consumers were identified.
- **High:** Local server licensing is not Apache/MIT; the current official text and packaged 3.3.1 license were both inspected.
- **High:** The current Floci DynamoDB poller cannot replace TEOS's pump just by changing its data source.
- **High:** User-supplied endpoint integration avoids distributing Local inside Floci's own artifact.
- **Medium:** The recommended account-derived signing/file-namespace strategy is the smallest general solution. It follows AWS's documented storage partitioning, but must pass black-box tests on the pinned release.
- **Unverified:** Local TTL deletion, exact restart persistence of stream history, iterator cross-namespace behavior, and all proposed end-to-end acceptance experiments.
- **Not a legal assurance:** Whether a particular embedded, redistributed, automated-pull, or hosted deployment is authorized. That is for qualified legal review/AWS clarification against the exact distribution.

## 17. Source reference guide

Repository roots:

- **Floci:** `/Users/mariotoffia/progs/github/floci`
- **TEOS:** `/Users/mariotoffia/progs/thiink/teos`

Floci Java citations above use the common prefix `src/main/java/io/github/hectorvent/floci/`. Test citations use `src/test/java/io/github/hectorvent/floci/` with the corresponding service package.

Most important entry points to revisit:

| Concern | Path and inspected anchor |
|---|---|
| Actual public protocol | `Floci/src/main/java/io/github/hectorvent/floci/core/common/AwsJsonController.java:80-149` |
| Current operation coverage | `Floci/src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbJsonHandler.java:47-94` |
| Native authoritative state | `Floci/src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbService.java:94-205,403-485` |
| Real writes and synthetic native capture | Same file `595-636,1861-1933` |
| Native stream assumptions | `Floci/src/main/java/io/github/hectorvent/floci/services/dynamodb/DynamoDbStreamService.java:35-70,211-272,286-376` |
| Lambda source algorithm | `Floci/src/main/java/io/github/hectorvent/floci/services/lambda/DynamoDbStreamsEventSourcePoller.java:139-216` |
| Pipes source algorithm | `Floci/src/main/java/io/github/hectorvent/floci/services/pipes/PipesPoller.java:301-341` |
| CFN actual table calls | `Floci/src/main/java/io/github/hectorvent/floci/services/cloudformation/CloudFormationResourceProvisioner.java:1786-1920` |
| Account-aware storage | `Floci/src/main/java/io/github/hectorvent/floci/core/storage/StorageFactory.java:46-100` |
| Reset entry point | `Floci/src/main/java/io/github/hectorvent/floci/lifecycle/EmulatorInfoController.java:135-158` |
| Root user-visible issues | `TEOS/ISSUES.md:24-149` |
| Retained workaround decision | `TEOS/design-in-progess/floci/PLAN_DDB_PUMP.md:3-22,168-176` |
| Mirror implementation | `TEOS/deployment/lib/svctest/local_mirror.go:67-149,150-237` |
| During-deploy race | `TEOS/deployment/lib/svctest/local_mirror_watch.go:22-56,123-172` |
| Actual pump shard reading | `TEOS/go-core/utils/testutils/flocilocal/ddbstreampump/pump.go:162-298` |
| Actual pump delivery | `TEOS/go-core/utils/testutils/flocilocal/ddbstreampump/deliver.go:84-178,202-269` |

**Recommended coordinating action:** Link this research from the bounded DynamoDB decision task. Keep architecture approval pending. Do not silently replace the existing TEOS decision or mark pump/mirror work complete.
