# External DynamoDB Local Adapter Implementation Plan

> **For agentic workers:** Use `subagent-driven-development` or `executing-plans`
> when implementation is authorized. Each numbered leaf is one PR. The steps
> below are inside those PRs, not permission to combine all work or start containers.

**Goal:** Make an already-running DynamoDB Local instance the optional authority
behind Floci's normal DynamoDB endpoint and internal service integrations.

**Architecture:** Implement C's operation and typed capability contracts with
one concrete Local client, and reuse C's API-based stream reader. Preserve public
Floci identities and explicit account/region scope while Local owns actual data
and stream records. Never fall back to native tables or automate Local's lifecycle.

**Tech Stack:** Java 25, Quarkus, Jackson, existing HTTP/signing facilities or the
minimal AWS SDK signing dependency, AWS SDK compatibility clients, user-supplied Local 3.3.1.

---

## Scope, estimates and dependencies

Selected as **D** on 2026-09-18. Status:
[Task 37](../../TEOS_GROUNDZERO_TASKS.md#task-37-external-dynamodb-local-adapter).
The [selected contract](README.md#contract-fixed-for-these-plans) is authoritative;
the old research's managed-sidecar candidate is not selected.

| PR | Scope | Estimate | Merge prerequisites |
| --- | --- | --- | --- |
| 37.1 | Concrete Local operation client | 2-3 days | 36.2 |
| 37.2 | Multi-account/region identity, ARNs and public iterator ownership | 2-4 days | 37.1 |
| 37.3 | Ancillary tags and supported-operation policy | 1-3 days | 37.2 |
| 37.4 | Bind and qualify Local through the shared API stream reader | 2-3 days | 36.3 and 37.2 |
| 37.5 | Configuration, readiness, safe lifecycle and public activation | 1-2 days | 36.4, 37.3, 37.4; 35.1-35.4 and 23.1 for the selected complete delivery release |
| 37.7 | Opt-in TEOS-owned paired container lifecycle | 1-2 days | 37.5 image for integration; helper unit work can proceed independently |
| 37.6 | TEOS adoption and removal of the split | 1-2 days | 37.7 merged and containing image from 37.5 |
| **D total** | Includes paired TEOS helper/adoption; no Floci-managed process | **10-19 developer-days** | |

37.3 and 37.4 can land independently after 37.2. Earlier adapter PRs are dormant:
they can be exercised directly in focused checks but expose no public selector
that activates a half-routed database. Every prerequisite must merge to `main`
before a dependent branch starts. Source refactors are C's responsibility;
D must not rewrite service consumers a second time.
37.7 is a separate TEOS helper PR described in
[the paired-lifecycle plan](TEOS_LIFECYCLE.md). It lands before 37.6 despite
its later number; adoption does not keep a second independent Local owner.

Normal PR completion/docs are included; review queues, a separate qualification
campaign, broad AWS parity and backend migration of existing native data are not.
Treat the low end as optimistic until namespace/stream persistence behavior is
verified on the pinned Local release.

## Files and ownership

Paths are relative to Floci, except the explicit TEOS section at the end.
The C plan defines the native facade and the operation/stream contracts first.
Add the Local implementation under the same DynamoDB package hierarchy:

- `src/main/java/io/github/hectorvent/floci/services/dynamodb/backend/DynamoDbLocalClient.java`:
  signed operation execution and bounded transport.
- `src/main/java/io/github/hectorvent/floci/services/dynamodb/backend/DynamoDbLocalBackend.java`:
  implements `DynamoDbOperations`, `DynamoDbItemAccess` and
  `DynamoDbTableAccess`; identity/capability orchestration.
- `src/main/java/io/github/hectorvent/floci/services/dynamodb/backend/DynamoDbLocalIdentity.java`:
  schema-aware resource identity and known account/region namespaces.
- `src/main/java/io/github/hectorvent/floci/services/dynamodb/backend/DynamoDbLocalIteratorTokens.java`:
  bounded public iterator ownership and underlying opaque Local tokens.
- `src/main/java/io/github/hectorvent/floci/services/dynamodb/backend/DynamoDbLocalMetadata.java`:
  ancillary tags only; never a shadow item/schema store.
- Existing-from-C `backend/DynamoDbApiStreamReader.java`:
  reuse its standard Streams response parser; no Local-only reader class merely
  to satisfy a task title and no second Lambda retry implementation.
- Proposed tests under
  `src/test/java/io/github/hectorvent/floci/services/dynamodb/backend/`:
  `DynamoDbLocalClientTest`, `DynamoDbLocalIdentityTest`,
  `DynamoDbLocalIteratorTokensTest`, `DynamoDbLocalMetadataTest`,
  `DynamoDbLocalBackendTest`, `DynamoDbLocalStreamReaderIntegrationTest`,
  `DynamoDbLocalBackendIntegrationTest`.
- Existing config/lifecycle:
  `src/main/java/io/github/hectorvent/floci/config/EmulatorConfig.java`,
  `src/main/resources/application.yml`, `src/test/resources/application.yml`,
  `src/main/java/io/github/hectorvent/floci/lifecycle/EmulatorLifecycle.java`,
  `src/main/java/io/github/hectorvent/floci/lifecycle/EmulatorInfoController.java`.
- `docs/services/dynamodb.md`, `docs/services/lambda.md`,
  `docs/services/pipes.md`, and the existing configuration docs.
- `pom.xml` only if the selected existing production dependencies do not already
  provide the needed signer. Do not add the DynamoDB Local server artifact.

Each new class has the one responsibility above. Combine purely private helper
logic into its owning class if a separate file buys nothing; do not add a
discovery registry, runtime-loaded plugin system or generic database SPI.
Before activation, integration fixtures instantiate the adapter or use test-only
CDI binding. They do not depend on exposing a production Local selector early.
Local-dependent classes use an opt-in JUnit environment condition for
`FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT`; ordinary native-only runs may skip
those classes without claiming Local coverage. The explicit commands below
provide that variable, and fixture startup must fail on an invalid/unreachable
endpoint rather than skip. All cases required by an opted-in command must run.

## 37.1: Concrete, lossless operation client

- [ ] Consume C's operation request with explicit protocol family, operation,
      account/region and AWS JSON body. The client accepts an explicit endpoint;
      it never consults the default AWS credential or endpoint chain.
- [ ] Use existing production HTTP/signing support where suitable. If there is
      none, use the minimal AWS SDK signing module under the project's dependency
      management, not another handwritten SigV4 implementation or a full
      operation-by-operation DynamoDB SDK adapter. Do not depend on unfinished
      Task 14 just to expose a testable Local client.
- [ ] Sign the exact UTF-8 request bytes, target header and actual endpoint host.
      Use stable dummy account-derived credentials, never the inbound user's
      secret or rotating STS key. Preserve the region explicitly.
- [ ] Forward Local operation names and raw AttributeValue trees without a
      copied supported-action switch. This is how new Local-supported actions
      remain reachable. Distinguish the DynamoDB and DynamoDB Streams target
      prefixes; JSON 1.0 and current CBOR public callers share the contract.
- [ ] Preserve status, structured AWS error body and allowed response metadata.
      In particular keep `CancellationReasons`, `None` entries and conditional
      failure items. Do not turn every error into a generic `AwsException` that
      discards those fields. Recompute public CRC32 after any later translation.
- [ ] Bound connect/request time and cancel calls on shutdown. A write timeout is
      an ambiguous outcome, not permission to retry a possibly committed write.
      Do not add automatic mutation retries above the caller's policy.
- [ ] In `DynamoDbLocalClientTest`, use a local protocol stub to assert exact
      request signing/body/target and returned success/error bodies. Include:
      nested binary/set values, a 38-digit number string, cancellation reasons,
      an unknown operation passed through, a network refusal and a timed-out write.
      Run from Floci root:

```sh
./mvnw test -Dtest=DynamoDbLocalClientTest
```

Expected: the client returns the operation result without changing item data,
losing error details or retrying ambiguous writes. No config selector yet.

## 37.2: Scope and resource identity

- [ ] Require a dedicated Local endpoint configured without `-sharedDb` and
      without the current TEOS shared in-memory mode. Stable dummy access-key
      identity derives from the Floci account, with the operation's region.
      Two IAM keys in the same Floci account must reach the same Local namespace;
      two accounts/regions with the same table name must not share data.
- [ ] Treat Local's launch mode as an operator/deployment precondition. The
      endpoint API does not reliably report its process flags. Do not claim a
      read-only ListTables readiness probe proves isolation, or automatically
      create/delete test tables in an arbitrary supplied endpoint. Establish the
      namespace contract using owned integration fixtures before release.
- [ ] Parse resource identities by field, reusing existing ARN utilities.
      Translate table/index ARNs, ARN-as-TableName, tag ResourceArn, nested
      transaction/batch identities and stream ARNs while preserving the actual
      Local stream label. Validate supplied ownership, never strip an account
      and accidentally address the caller's same-named table.
- [ ] Rewrite endpoint-discovery responses to Floci's existing advertised
      endpoint rather than allowing SDKs to escape directly to Local. Track
      observed account/region scopes through `StorageFactory` for scoped
      resource inventory; Local has no API that lists every namespace at once.
      Do not represent this scope catalog as a second table store.
- [ ] Preserve opaque pagination values. Never globally replace ARN-looking
      strings: this item must return byte-equivalent attribute values:

```json
{"PK":{"S":"one"},"note":{"S":"arn:aws:dynamodb:us-east-1:222222222222:table/example"}}
```

- [ ] Separate internal Local iterators from public iterator tokens. Bind public
      tokens to account/region and stream generation with a bounded lifetime.
      Keep repeated reads legal until expiry; do not make iterators one-use.
      Reuse existing token/storage helpers where possible, otherwise use a
      bounded opaque lookup rather than inventing cryptography. Do not decode
      or rewrite Local's proprietary iterator internals.
- [ ] Exercise `DynamoDbLocalIdentityTest` for all translated fields and copied
      cross-account iterator refusal. With a user-supplied disposable Local
      endpoint, `DynamoDbLocalBackendIntegrationTest` creates equal table names
      in two accounts and two regions, plus two caller keys in one account.
      Compare independent items, descriptions and stream identities.

```sh
./mvnw test -Dtest=DynamoDbLocalIdentityTest,DynamoDbLocalIteratorTokensTest
FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT=http://127.0.0.1:8000 \
  ./mvnw test -Dtest=DynamoDbLocalBackendIntegrationTest
```

The explicit integration command supplies the endpoint; its fixture fails if
that endpoint is unusable. Ordinary default runs do not require Local.
No tool in Floci starts the server. A shared-mode instance must fail the
isolation acceptance case, not be declared supported by editing response ARNs.

## 37.3: Tags and capability policy

- [ ] Implement the bounded item/table capabilities consumed by
      `DynamoDbFacade`, using this same operation executor, not another SDK
      client per service. Project detached table descriptions and only the
      requested UpdateItem image into the facade result. Typed error conversion
      preserves the current consumer's AWS error code; raw replies retain their
      complete error members.
- [ ] Local owns existence, schemas and items. Implement the tag calls needed by
      Floci CFN through a small `StorageFactory` store keyed by scoped table
      identity and creation generation. It cannot create an apparent table,
      answer item reads, or replace a failed Local DescribeTable.
- [ ] Management goes through Floci for this mode. Direct out-of-band Local
      create/delete/recreate is outside the supported metadata contract. Still
      fail visibly if the backing resource is absent; never return stale tags
      as proof it exists. Reconcile create/delete failure and restart boundaries
      without claiming cross-process atomic commit.
- [ ] Let Local execute its supported operations. For native-only extensions
      such as Kinesis destinations, replicas, unsupported import/export or PITR,
      return an explicit AWS-shaped unsupported error or Local's own rejection.
      Never invoke the native implementation as fallback. Resource-policy APIs
      unsupported by the selected mode also fail honestly; existing public IAM
      checks remain in front of backend execution.
- [ ] Forward supported TTL configuration and report its real state. Do not
      implement a replacement TTL sweeper or claim actual expiration from an
      accepted setting. Preserve limitations in a versioned capability table.
- [ ] Keep existing CloudFormation table-property omissions explicit. The adapter
      does not fix omitted properties merely because Local supports the API.
      Do not reopen the unselected native A property-parity work or change a
      provisioner in D to hide a gap; restrict adoption claims to real forwarded
      settings and identify any workload-blocking gap before activation.
- [ ] Assert CFN's unconditional ListTags path works even for an untagged table.
      Cover tagging, untagging, delete/recreate, restart, absent backing table,
      Local outage and a rejected native-only operation. Run:

```sh
./mvnw test -Dtest=DynamoDbLocalMetadataTest,DynamoDbLocalBackendTest,DynamoDbLocalIdentityTest
```

Expected: metadata stays ancillary, errors remain visible, no native table/item
stores are read as external authority. Update the capability/license docs here.

## 37.4: Actual Streams reader

- [ ] Bind C's existing `DynamoDbApiStreamReader` to Local operation execution.
      Preserve ListStreams/DescribeStream/GetShardIterator/GetRecords paging,
      actual shard IDs, parent lineage and actual record metadata. There is no
      duplicate Local response parser. Do not manufacture records from intercepted
      writes or copy them into native `captureEvent`.
- [ ] Preserve string numbers, binary values, absent images, source identity,
      timestamps, sequence numbers and any supplied identity fields. A read
      result is not an acknowledgement. B and C's consumers own disposed-record
      progress and use the same source for Lambda and Pipes.
- [ ] Renew expired iterators from committed progress. Empty pages are not
      closed shards; null next iterator is closure. Process a child from its
      beginning only after its parents complete. Report trimmed history as a
      potential loss, never silently resume from the beginning as if nothing
      happened.
- [ ] Keep progress while Floci restarts and Local's stream generation survives.
      Do not apply the native volatile-stream startup reset to Local. Detect
      stream disable/re-enable and table recreation. If Local restart loses
      history, fail or apply the documented explicit recovery boundary rather
      than pretending persistence was proved.
- [ ] Reuse `DynamoDbApiStreamReaderTest` for deterministic expiry, trimming,
      multi-page descriptions and parent/child traversal. Add Local identity/
      continuity cases in `DynamoDbLocalStreamReaderIntegrationTest`.
      With a supplied endpoint and test-only backend binding, run actual
      Put/Update/Delete through the Floci handlers and read their records,
      then restart the Floci fixture separately from Local.

```sh
./mvnw test -Dtest=DynamoDbApiStreamReaderTest,DynamoDbStreamsEventSourcePollerTest,PipesPollerTest
FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT=http://127.0.0.1:8000 \
  ./mvnw test -Dtest=DynamoDbLocalStreamReaderIntegrationTest
```

Expected: actual Local history is the source, with explicit scope and preserved
generation/progress. No Local-specific retry engine or public activation yet.

## 37.5: Public activation and safe runtime

- [ ] Wire the existing service selector from C to the complete Local adapter.
      Use `floci.services.dynamodb.backend` (`native` default, `local` opt-in),
      `local-endpoint`, and bounded `local-connect-timeout`/`local-request-timeout`
      settings with `FLOCI_SERVICES_DYNAMODB_*` env bindings in both YAML files.
      The initial timeout defaults are 2 seconds connect and 10 seconds request;
      they do not create an additional write-retry policy.
- [ ] Require a configured HTTP(S) endpoint in Local mode. Reject absent or
      accidental AWS regional/public endpoints and unsupported backend values.
      No endpoint guessing, default credential chain, Docker dependency or
      fallback to native on configuration/startup/outage failure.
- [ ] Preserve service enablement. A disabled DynamoDB service must not start
      database workers or make background Local calls merely because an adapter
      class exists. Keep DynamoDB and Streams service routing aligned through
      the existing catalog/controller enablement checks.
- [ ] Validate backend identity before restoring persisted checkpoints or
      ancillary state. Changing a populated deployment from native to Local,
      or pointing it at a different database, is not an automatic migration.
- [ ] Perform a signed nonmutating readiness call before consumers start or
      DynamoDB is reported ready. Surface later outages through operation
      failures and health. Stop/cancel bounded calls and quiesce readers before
      closing the Floci client; leave the external process and data untouched.
- [ ] Expose the actual selected backend as `dynamodb_backend` (`native` or
      `local`) in the existing `GET /_floci/info` response and document it.
      Together with readiness, this lets the TEOS helper reject old images
      that ignore backend configuration. Do not add another endpoint or
      merely echo a caller's requested environment variable as active state.
- [ ] Preflight the existing global reset. Local mode refuses destructive
      database reset before any other store is cleared, using the existing
      emulator error response convention. Do not add a `delete-all-external`
      escape hatch. Full reset of this disposable external environment belongs
      to its operator/test harness.
- [ ] Run the same JSON/CBOR, CFN, IAM metadata, optimized/SDK Step Functions,
      API Gateway and IoT paths through Local. Verify a real ordinary Lambda
      mapping and the supported ordinary Pipes source path. No internal caller
      may read native tables or streams in Local mode.
- [ ] Extend `EmulatorLifecycleTest`, `EmulatorInfoControllerIntegrationTest`
      and the new adapter integration suite. Run the existing focused native
      regression suites with the selector absent, plus the explicit endpoint
      suite with it enabled. Include native-image build/SDK coverage required
      by the repository before advertising the mode as released.

Expected: native remains the unchanged default, complete Local mode is explicit,
all supported callers share one authority, reset is not partly successful, and
unsupported operations cannot masquerade as native success.

## 37.6: TEOS adoption, separate repository PR

**Files, relative to TEOS:**

- `go-core/utils/testutils/flocilocal/` existing driver/options: consume the
  paired option implemented by 37.7 rather than implementing its lifecycle again.
- `go-core/utils/testutils/dynamodb_local.go`: retain the paired runner's
  non-shared namespace configuration and pinned image from 37.7.
- `deployment/lib/svctest/local.go`, `local_env.go`, `local_mirror.go`,
  `local_mirror_watch.go`, `local_pump.go`, `local_keep.go` and their tests.
- `deployment/lib/adapters/cdk/lambda/environment.go` and `environment_test.go`.
- `deployment/stacks/groundzero/service-test/` and the building/event service tests.
- Root `ISSUES.md`, `API_ENDPOINT.md` and the source design/watch register.

- [ ] Require a containing Floci image and use
      `flocilocal.WithDynamoDBLocal()` from 37.7. Remove the harness's independent
      Local start/network attachment and `b.dynamo` lifecycle ownership.
      The paired handle starts Local before Floci and validates the selected
      backend. Do not start a duplicate container or let Floci manage it.
- [ ] Point host and Lambda DynamoDB **and Streams** SDK clients at ordinary
      Floci. Remove the old per-service Local endpoint overrides together,
      including any interim 33.2 injection. Keep the normal local-target and
      real-AWS endpoint safety guards.
- [ ] Run the groundzero custom-resource write with both mirrors disabled from
      the start. Assert exact required table schema and forwarded settings,
      and immediate row visibility. Report omitted CFN settings separately;
      no TTL-expiration or table-property parity claim follows from deployment.
      Run direct IoT/Step Functions/API Gateway writes through the selected
      backend, with no Lambda detour or second table authority.
- [ ] Run building's ordinary Floci event-source mapping with the host pump
      disabled, including partial failure, bisection, retry exhaustion and the
      actual failure queue. Never run both consumers to make a case pass.
- [ ] Only then delete obsolete mirror/pump starts and their now-unused code.
      Retain any helpers with other consumers after a whole-repository caller
      search. Root `ISSUES.md` 1.1-1.6 and W-4/F-6/W-22 close only for proved
      behavior; TTL and unsupported capabilities remain explicit.
- [ ] Update `local_env.go`, deployment-environment checks and keep notices so
      both SDK services use the ordinary Floci address. Preserve checks for
      the local target and safe endpoint; replace the old requirement that
      every function contain a separate DynamoDB Local URL.
- [ ] Close only the Floci pair handle during normal teardown, then clean
      remaining run-owned launched resources/network through existing helpers.
      Avoid double-closing the companion. `TEOS_LOCAL_KEEP` keeps both members
      and their network/CA, and prints both exact cleanup identities using
      the handle's companion accessor. Keep native-only callers option-free.
- [ ] From TEOS root, use the existing selectors:

```sh
CB_SERVICE_TEST=groundzero make test-service
CB_SERVICE_TEST=event-service,building-service,collector-service make test-service
```

Expected: no mirror or host pump, registration and stream-driven behavior still
work, and cleanup is scoped to this harness's owned resources. Groundzero's AWS
target stays read-only. This is the implementation PR's end-to-end acceptance,
not a separately commissioned qualification project.

## 37.7: Paired TEOS helper lifecycle

The [dedicated plan](TEOS_LIFECYCLE.md) defines the optional public API,
existing helper reuse, readiness/start order, reverse-order teardown, rollback,
keep behavior, scoped orphan cleanup and borrowed-resource protection.
This is TEOS automation, not automation inside Floci.
