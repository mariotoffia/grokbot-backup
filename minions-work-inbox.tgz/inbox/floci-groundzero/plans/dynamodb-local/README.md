# DynamoDB Local backend: selected direction

**Status:** On 2026-09-18 the user selected B (native stream delivery),
C (native backend preparation) and D (the external Local adapter), and explicitly
chose multi-account/multi-region isolation. These are approved planning scopes,
not implemented features. No emulator was started or runtime tests run while
writing these plans.

**Decision owner:** [Task 34](../../TEOS_GROUNDZERO_TASKS.md#task-34-dynamodb-local-integration-decision).
Execution is split into the one-PR leaves of Tasks 35, 36 and 37 below.
TEOS owns adoption only after the backend is qualified.
The full source-backed investigation, official licensing citations and proposed
experiments are in [RESEARCH.md](RESEARCH.md).

## Selected architecture

Use an **opt-in, externally supplied DynamoDB Local endpoint** as the single
table/schema/item/stream authority. Keep Floci as the normal AWS endpoint,
including its CloudFormation and service integrations. Keep native DynamoDB the
default, so this feature adds no AWS server dependency to ordinary Floci users.
Local is an already-running, externally owned process. **Floci never downloads,
starts, adopts, stops or deletes that process, container or volume.** Managed
sidecars inside Floci are not part of this plan. The TEOS helper may start
Local before Floci under the selected opt-in paired lifecycle in 37.7.

| Approach | What it fixes | Why not choose it by default |
| --- | --- | --- |
| Embed or bundle the AWS Java server | Can put Local behind service calls | Proprietary incorporation/distribution restrictions; embedded technical support is not a redistribution grant; Java/native-image feasibility unproved |
| Add only an external Streams reader | Could eventually remove the host pump | Leaves the second database, table-copy race and wrong-database direct-service writes |
| External endpoint with shared service routing | Can remove duplicate authority and, after delivery parity, mirror/pump/endpoint split | Selected; actual in-process callers and stream consumers must use it, not just an HTTP proxy |

This is not a generic storage/plugin framework. Select the backend at the
DynamoDB operation boundary, using one concrete Local client. Public JSON 1.0
and existing CBOR requests, direct CloudFormation/IoT/Step Functions calls,
API Gateway integrations, authorization metadata and resource enumeration must
all use the selected authority. Unsupported operations fail explicitly rather
than falling back to abandoned native tables.

Local supplies actual stream records, **not Lambda delivery semantics**. Floci
must consume the real Streams APIs, including shard pages, lineage, opaque
iterators, generations and account-scoped checkpoints. Its current Lambda poller
does not match TEOS's partial-failure/bisection/retry/destination behavior; Pipes
also needs a deliberate support or rejection boundary. Do not synthesize events
from intercepted writes, where conditional failure, transactions and ambiguous
timeouts make such events unreliable.

## AWS licensing boundary

The [official Local license](https://aws.amazon.com/dynamodb/dynamodblocallicense/)
and the license packaged with 3.3.1 restrict incorporation and distribution.
AWS also [documents embedded use](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocalTelemetry.html).
Those facts require interpreting the exact intended use, not assuming a Maven
artifact inherits the AWS SDK's Apache license.

Do not merge AWS server code into Floci or publish a combined Floci/Local image
without separately applicable permission or legal clarification. The recommended
first model distributes only Floci's protocol adapter: the user obtains the
official Local image and supplies its endpoint, as in AWS's documented
[separate-container topology](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBLocal.DownloadingAndRunning.html).
This avoids Floci redistributing the server; it does not waive the user's Local
license obligations, including its AWS-account/internal-use wording. These are
engineering findings, not a legal assurance.

## Contract fixed for these plans

1. Floci owns only its clients, workers and ancillary metadata. The operator
   supplies a dedicated Local endpoint and controls its database lifecycle.
2. Preserve multi-account/multi-region isolation. Use non-shared Local
   namespaces with stable account-derived dummy signing identities and explicit
   region. TEOS's existing `-inMemory -sharedDb` setup is not an accepted
   multi-account configuration. No real credentials, AWS endpoint fallback or
   account isolation implemented only by changing output ARN strings.
3. Local owns tables, items and committed stream history. Floci owns a minimal
   `StorageFactory`-backed tag overlay because ordinary CFN uses tags. Other
   Local-unsupported features fail explicitly; no native shadow table fallback,
   synthetic write events, replacement TTL scanner, replicas or PITR engine.
4. Reset is non-destructive to the external endpoint. Preflight and refuse a
   Floci-wide destructive reset before clearing unrelated stores when it cannot
   reset the selected external backend consistently. Shutdown closes Floci
   clients/workers only. Backend outages fail visibly, never switch to native.
5. Ordinary Lambda and Pipes stream consumers use the selected source. Preserve
   their supported delivery contracts; do not enable a path that silently reads
   native streams in Local mode. B's Lambda delivery and 23.1's CFN forwarding
   are mandatory before TEOS pump removal. Broader Pipes enrichment and AWS-wide
   parity are not smuggled into this scope.

Exact namespace isolation, stream restart history and identity behavior must
be proven on the pinned Local version during adapter implementation. The user
skipped a separate qualification project, not correctness checks inside each
implementation PR. These plans contain those focused acceptance gates.
The research's R0-R9 table is historical exploration; the following task IDs
are the execution source of truth. Its managed-sidecar R8 is not selected.

## Plans and effort

| Selected work | Plan | PR units | Estimate |
| --- | --- | --- | --- |
| B: native Streams delivery | [Native delivery](../dynamodb-streams/README.md) | 35.1-35.4 plus the already-owned 23.1 CFN share | 6-11 days |
| C: native-only backend boundaries | [Backend preparation](../dynamodb-backend/README.md) | 36.1-36.4 | 8-14 days |
| D: external Local adapter, TEOS pair and adoption | [Local adapter](IMPLEMENTATION.md) | 37.1-37.7, with 37.7 before 37.6 | 10-19 days |
| **Total** | One developer; normal PR completion/docs | No duplicate CFN or retry engine | **24-44 developer-days** |

No qualification campaign, review queue, native-correctness estimate A or
Floci-owned container automation is included. TEOS paired lifecycle adds
1-2 days in 37.7. Estimates are source-based ranges, not delivery
promises. Start each dependent PR from `main` after its prerequisites merge.
Task 21 remains unrelated async Lambda invocation policy.

### Ready work and unavoidable dependencies

Start 35.1, 35.2, 35.4 and 36.1 independently on native `main`.
35.3 consumes the three native delivery prerequisites. Existing 23.1 follows
35.1 for the full mapping field set. 36.2 follows 36.1. The concrete shared
API reader in 36.3 needs 36.2's operation contract and 35.4's consumer lifecycle;
36.4 then supplies selected-backend runtime ownership.

37.1 follows the operation boundary, then 37.2 fixes external identity.
37.3 and 37.4 can proceed independently after identity is available, with
37.4 also requiring the source-reader boundary. 37.5 is the deliberate
activation join: all selected operations, readers, lifecycle and delivery paths
must be on `main`. TEOS's 37.7 supplies the paired helper; 37.6 consumes that
merged helper and a containing image, not another repository's unmerged branch.

No native correctness A fix is assumed to have shipped. Default-native
characterization must distinguish preserved behavior from the explicit B fixes.
The Local adapter bypasses native expression/transaction evaluation; it does not
use Local merely as storage underneath an unchanged native condition engine.
The existing `DynamoDbService` stays the native engine. C adds `DynamoDbFacade`
for other services and keeps raw versus typed native behavior distinct, rather
than mechanically renaming the entire engine or creating delegation recursion.
Both backends reuse C's API-based stream reader; D adds no second reader parser.

## Removal gates

| TEOS workaround | Required proof with the workaround disabled from the start |
| --- | --- |
| Table mirror and deployment watcher | CFN creates the authoritative Local table before the dependent custom resource writes; exact schema/settings, create/update/delete/retain and direct-service writes agree |
| Host stream pump | Real Local writes invoke the deployed function through Floci's normal mapping with required filters, partial failures, bisection, retry bounds, checkpoints and failure destination |
| Per-service endpoint split | Host and Lambda DynamoDB **and Streams** clients use the ordinary Floci endpoint, including internal service calls; no real-AWS fallback |

Never enable both the host pump and replacement mapping on the same test path.
Do not delete any workaround because a selector exists or settings read back.
TEOS `flocilocal.WithDynamoDBLocal()` owns the two-container pair: Local starts
first, Floci stops first, and Close/failed-start cleanup covers both.
`TEOS_LOCAL_KEEP` retains both together. With the option absent no Local
container is started. Floci never gains container-management responsibilities
or a Docker socket merely because this backend is enabled. Details:
[paired lifecycle](TEOS_LIFECYCLE.md).

## Additional source findings

The report refines root `ISSUES.md` without claiming new reproduced failures:

- TEOS's mirror checks primary keys and missing index names, not full existing
  index key/projection equality. Its shared copy function also copies items,
  including during deployment, and its table enumeration is not paginated.
- The 250 ms polling race is real as a design boundary even though no observed
  run has failed from it. A favorable cold-start timing does not create a barrier.
- The pump's own retry/destination shapes are an approximation, not an AWS oracle.
  Local's actual TTL deletion and stream persistence need pinned-version evidence.
- Current Floci has locking and conditional-write concurrency tests. This
  investigation did **not** demonstrate a current native conditional-write bug.
  The reason for this option is TEOS's chosen reference backend and consistent
  integration, not a claim that native DynamoDB has no conditional semantics.

Keep 31.6/31.7 for their existing update/cleanup/loss evidence. Conditional
host-pump extensions 33.12-33.16 are now deferred behind the selected Floci path;
revive only for an explicit interim consumer, not in parallel with a replacement
delivery engine. Do not expand them into a general table-replication system.
