# TEOS Paired Floci and DynamoDB Local Lifecycle Implementation Plan

> **For agentic workers:** Use `subagent-driven-development` or `executing-plans`
> when implementation is authorized. Task 37.7 is one TEOS PR; its steps are
> internal to that PR. Task 37.6 adopts it and removes the old split afterward.

**Goal:** Let `flocilocal` opt into a DynamoDB Local companion whose startup,
shutdown, cleanup and retained-run ownership follow the same Floci test instance.

**Architecture:** The TEOS Go helper owns both containers. Start the existing
DynamoDB Local runner first, then start Floci with its external-backend settings.
Floci sees only a ready endpoint and never manages the companion itself.

**Tech Stack:** Existing TEOS Go `flocilocal`/`testutils` helpers, Docker CLI,
the pinned DynamoDB Local image, and the Floci backend from 37.5.

---

## PR boundary and estimate

**Task:** [37.7](../../TEOS_GROUNDZERO_TASKS.md#task-37-external-dynamodb-local-adapter).
**Owner:** TEOS. **Estimate:** 1-2 developer-days in addition to the existing
37.6 adoption estimate. This moves D to 10-19 days and B/C/D to 24-44 days.

The helper can be developed independently with command fixtures. Its integration
gate needs an image containing 37.5, not a stacked source branch. 37.7 must merge
before 37.6 uses the option and deletes the harness's old independent ownership.
It does not depend on the optional Docker-helper extraction in 32.19.

## Public option and ownership

Add `flocilocal.WithDynamoDBLocal()` following the existing no-argument `WithTLS`
style. Its zero/default state is off:

```go
func WithDynamoDBLocal() Option {
	return func(l *Local) { l.dynamoDBLocal = true }
}
```

Add the unexported `dynamoDBLocal bool` field to `Local`; keep its owned
`dynamoDBLocalRunner *testutils.DynamoDbLocal`, container identity and any
helper-created network as private state.

Future usage, not code implemented by this plan:

```go
local := flocilocal.New("orders-integration",
	flocilocal.WithDynamoDBLocal(),
)
```

Existing callers use `Start(ctx)` and defer `Close()` as before. Ordinary
`local.AwsConfig()` remains the client configuration for both DynamoDB and
Streams; do not hand clients a direct Local endpoint.
The option and `New` have no Docker/download side effects. Only `Start` may
obtain/start the official pinned image. Document the AWS Local license alongside
this explicit opt-in; the helper does not redistribute the server inside Floci
or waive the user's license obligations.

| Configuration | Contract |
| --- | --- |
| Option absent | Start only Floci, unchanged native default; no DynamoDB companion or pair-only network |
| Option present | The handle owns a complete pair, selects Floci's Local backend and waits for both services |
| `WithEndpoint` plus the paired option | Reject before any Docker mutation: a borrowed Floci endpoint is not a container this handle can pair/reconfigure |
| Option off, explicit backend URL supplied through existing env configuration | Caller-managed endpoint remains caller-owned; do not start, stop or delete it |
| Conflicting `WithEnv` backend/endpoint values plus the paired option | Reject before startup instead of silently using native mode or leaving an unused companion running |

Expose only the companion identity needed by diagnostics, for example a new
`Local.DynamoDBLocalContainerName() string` returning empty when no companion is
owned. Do not return a mutable runner that callers can close independently or
introduce a general companion-container registry.

## Files

All paths are relative to TEOS:

- `go-core/utils/testutils/flocilocal/options.go`: the option.
- `go-core/utils/testutils/flocilocal/flocilocal.go`: ownership fields and
  Start/Stop/Close integration, keeping the existing public methods.
- New `go-core/utils/testutils/flocilocal/paired_dynamodb.go`: pair-specific
  startup/rollback/cleanup, rather than growing the main driver indefinitely.
- `go-core/utils/testutils/flocilocal/flocilocal_access.go`: diagnostics only.
- `go-core/utils/testutils/flocilocal/orphan_sweep.go`: scoped pair cleanup.
- `go-core/utils/testutils/dynamodb_local.go`: reuse the existing runner and
  pinned image. Add `WithAutoRemove(bool)` with default `true`; the paired path
  selects `false` so Stop can preserve a stopped container/logs like Floci does.
- Existing `options_internal_test.go`, `integration_lifecycle_test.go` in
  `flocilocal`, and `go-core/utils/testutils/dynamodb_local_test.go`.
- Proposed `go-core/utils/testutils/flocilocal/paired_dynamodb_internal_test.go`
  and `integration_dynamodb_backend_test.go`.
- Existing driver/package docs and root `API_ENDPOINT.md` as relevant.

No new Floci Java container-manager dependency or Docker socket requirement is
part of this task.

## Startup

- [ ] Validate paired/borrowed mode and final effective environment before doing
      anything in Docker. Require DynamoDB service enablement. Reject a backend
      other than `local` or a caller endpoint conflicting with the owned pair.
- [ ] Reuse `testutils.NewLocalDynamoDb` with `WithInMemory(false)`,
      `WithSharedDB(false)` and the new `WithAutoRemove(false)`. Keep the
      existing image-list digest pin. File-backed namespaces live in this
      owned container's writable layer, not a shared host database directory.
      Removing the container removes that run's data.
- [ ] Give the child a unique container name and DNS alias associated with the
      particular Floci instance. Record run/owner labels and exact container
      identities. Two Floci instances, even on a caller-shared network, must
      not resolve a common `ddblocal` alias to each other's database.
- [ ] Reuse an explicitly supplied `WithServicesNetwork` network without taking
      ownership of it. Otherwise create a run-scoped private pair network,
      owned by this handle, and attach both containers.
      **Do not populate `ServicesNetwork` just to connect this pair:** today that
      field also mounts the Docker socket in Floci. A database-only pair must
      not grant Floci Docker access. Keep pair connectivity separate from the
      explicit Lambda/ECS services-network capability.
- [ ] Start Local and await its existing application-level ListTables readiness.
      TCP readiness alone is insufficient. Attach it to the selected network
      before starting Floci, and pass the network-reachable address:

```go
l.Env["FLOCI_SERVICES_DYNAMODB_BACKEND"] = "local"
l.Env["FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT"] =
	"http://" + l.dynamoDBLocalRunner.Name + ":8000"
```

Use the unique child name as its network DNS alias. Never configure Floci with
the host's loopback URL. Validate conflicting caller values before assigning
these owned settings; do not silently overwrite an explicit different endpoint.

- [ ] Start Floci on that network using its existing driver path. Await readiness
      and require `GET /_floci/info` to report the selected `local` DynamoDB
      backend from 37.5. A healthy older image that ignores the new environment
      is a startup failure, not successful native fallback.
- [ ] Register cleanup as each resource is acquired. If Local, network attach,
      Floci launch, CA retrieval or backend readiness fails, gather logs from
      both sides and unwind the resources this attempt owns in reverse order.
      Preserve the original error and any cleanup failures.

No custom startup script inside the Floci image and no write-event bridge is
needed. Both containers remain siblings owned by TEOS.

## Stop, Close, keep and failure semantics

| Event | Required result |
| --- | --- |
| `Stop()` | Stop/quiesce Floci before stopping Local; preserve stopped containers and their logs. Pair file-backed data is retained until Close |
| `Close()` | Remove Floci, then its owned Local companion, then only a helper-owned pair network. Caller-owned network stays |
| Repeated Stop/Close or never-started handle | Safe/idempotent; no unrelated resource lookup or deletion |
| Startup fails halfway | Remove the partial owned pair/network after capturing diagnostics; no successful handle is returned |
| Floci cannot be stopped or removed | Do not delete its still-needed database underneath it. Return an actionable error and retain enough ownership state for retry/cleanup |
| Local cleanup fails after Floci is gone | Report the failure and exact owned resource; do not claim complete cleanup or broaden deletion scope |
| `TEOS_LOCAL_KEEP=1` in service harness | Keep the successfully started pair, network and CA together. Print Floci client setup and both cleanup identities; do not suppress startup rollback |
| Owner process crashes | Extend existing explicit orphan sweeping to the paired resources, without touching live owners or arbitrary same-named containers |

- [ ] Reuse the existing cleanup context and bounded Docker commands so a
      cancelled test context cannot prevent cleanup. Return/aggregate genuine
      failures; the existing best-effort Stop/Close implementations that always
      return nil are not sufficient for the new paired branch.
- [ ] Scope operations to captured IDs and verified ownership. Do not inherit
      unconditional name-based replacement of an unrelated live container.
      Refuse ambiguous collisions and ignore only a verified already-gone result.
      There is no broad delete by image, container-name substring or host folder.
- [ ] Preserve current non-paired behavior except directly required runner
      argument/error-handling changes. Do not refactor every other local driver.

This is a lifecycle contract of the TEOS handle, not Docker-level automatic
cascade when someone force-kills a container outside it. Normal cleanup and the
existing orphan mechanism cover the pair; no new permanent supervisor/watcher
is introduced.

## Acceptance

- [ ] Extend the existing command fixtures with option off/on, both startup
      orders, borrowed endpoint conflict, environment conflict, network ownership
      and no accidental Docker-socket mount.
- [ ] Cover Local failure, Floci failure, cancellation, repeated Close, partial
      cleanup failure, two simultaneous pairs, a foreign name collision and a
      retained pair. Verify exact call order and ownership, not merely call counts.
- [ ] Add the opt-in integration case `TestPairedDynamoDBLocalLifecycle`:
      start the pair against a containing Floci image, create/read the same table
      name independently in two accounts through Floci, and close the handle.
      Neither owned container/pair network remains; an unrelated control container
      is untouched. Keep-mode coverage asserts both remain until explicit cleanup.
- [ ] From TEOS `go-core`, use the focused commands:

```sh
go test -short -race -count=1 ./utils/testutils/flocilocal/ ./utils/testutils/
TK_LOCAL_EMULATOR=floci-with-local-backend:dev \
  go test -count=1 -run TestPairedDynamoDBLocalLifecycle ./utils/testutils/flocilocal/
```

The explicit image is supplied by the implementer and must contain 37.5. The
integration case fails for an incompatible image, not skips as a passing feature.
No integration/container run is executed while writing this plan.

## Handoff to 37.6

The service harness uses `WithDynamoDBLocal()` instead of maintaining its own
independent `b.dynamo` lifecycle. It must not start a second Local instance,
double-close a child, keep only Floci, or remove a borrowed network before both
containers are gone.

Update `local_keep.go` and its tests to get companion identity from the Floci
handle. Shell setup points both AWS SDK services at Floci, not at the Local
database port. 37.6 still owns removing the table-copy watcher, post-deploy
mirror, host stream pump, their discovery/error plumbing and obsolete endpoint
injection after the replacement cases pass without those components.
