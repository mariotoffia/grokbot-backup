# Task 6 follow-up designs

## Overview

These designs extend CloudWatch Logs beyond the metric-filter repair.
[TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md) is the only task ledger.
The [Task 6 index](README.md) links each numbered design.

Amazon Web Services (AWS) behavior must be supported by official documentation or
recorded compatibility fixtures. Estimates cover the stated implementation slice
and local tests, not full AWS feature parity. Use local AWS software development
kit (SDK) clients for acceptance tests; these designs require no live AWS calls.

The [core repair](CORE_REPAIR.md) owns per-event sample/default/dimension rules, account
lifecycle/reset/update, runtime partial-publication recovery, atomic shared
quotas, selection `AND`/`OR`, type-local CloudFormation `delete_then_create`, and
the pattern/wire parity corpus and tests. None is deferred by this file.

### Repository surfaces and conventions

Java paths use `SRC` for `src/main/java/io/github/hectorvent/floci`.
`TEST` means the matching tree under `src/test/java/io/github/hectorvent/floci`.
Paths are relative to the repository root.

- `SRC/services/cloudwatch/logs/CloudWatchLogsHandler.java`: JSON 1.1 requests.
- `SRC/services/cloudwatch/logs/CloudWatchLogsService.java`: ingestion, stored
  events, `filterLogEvents`, and subscription-filter definitions.
- `SRC/services/cloudwatch/logs/CloudWatchLogsCrossAccountService.java`: account
  policies and log destinations.
- `SRC/services/cloudwatch/logs/model/`: log groups, events, and filter metadata.
- Core repair surfaces: `CloudWatchLogsMetricFilterService`, ingestion events,
  `services/cloudwatch/logs/filter/`, and `LogsMetricFilterCfnProvisioner`.
- `SRC/services/cloudwatch/metrics/CloudWatchMetricsService.java`: metric writes.
- `SRC/core/storage/StorageFactory.java` and
  `SRC/lifecycle/EmulatorLifecycle.java`: storage creation, load, and shutdown.

Keep protocol parsing in handlers and validation in services. Use `StorageFactory`
for new stores and explicit account access for background work. Extend the core
lifecycle hooks rather than creating another reset or update mechanism.
Each implementation includes focused tests under `TEST/services/cloudwatch`,
local SDK tests where the public API changes, and updates to
`docs/services/cloudwatch.md`. Configuration changes also touch `EmulatorConfig`
and the main/test `application.yml` files.

<a id="task-6-4"></a>
## 6.4: Reuse the engine in FilterLogEvents

### Scope and non-goals

Replace substring matching with the existing filter-pattern compiler and evaluator.
Do not build another parser, expand the core parity corpus as a separate project,
change Logs Insights syntax, or redesign pagination.

### Affected surfaces and design

Change `CloudWatchLogsService.filterLogEvents` and its handler error mapping.
Compile the request pattern once, before scanning events, including empty groups.
Reuse the engine's empty-pattern behavior and validation errors.
Do not charge an ad hoc query against stored metric/subscription regex quotas.

Evaluate original event messages. Preserve stream restrictions, time bounds,
event ordering, response fields, and cursor behavior with regression tests.
Task 6.9 must not switch this operation to transformed messages.

### Dependencies and acceptance examples

Depends on the core compiler/evaluator and its wire error contract.

- Store `{"status":500}` and `{"status":200}`. The supported JSON pattern
  `{ $.status = 500 }` returns only the first event.
- A malformed pattern fails on an empty group as well as on a populated group.
- An empty pattern returns the same ordered pages as before. A multi-stream
  query retains each event's stream name.
- Existing core fixtures produce the same match decisions through `TestMetricFilter`
  and `FilterLogEvents`, without coupling query pagination to metric publication.

### Effort and uncertainty

1-2 days. The estimate assumes the engine exposes a reusable compiled predicate.
Any existing pagination defects need separate scope, not a query rewrite here.
References: [FilterLogEvents][filter-events], [filter syntax][filter-syntax].

<a id="task-6-5"></a>
## 6.5: Log-group class metadata and metric-filter eligibility

### Scope and non-goals

Persist `logGroupClass` and enforce Standard-only metric-filter eligibility.
This is not complete Infrequent Access or Delivery class emulation. It does not
implement their retention, pricing, query, or delivery behavior.

### Affected surfaces and design

Extend `model/LogGroup`, group create/describe handling, and `LogsCfnProvisioner`
where it passes `AWS::Logs::LogGroup` properties to the service.
Accept the documented class values `STANDARD`, `INFREQUENT_ACCESS`, and `DELIVERY`.
An omitted class and legacy stored groups without the field mean `STANDARD`.
Reject unknown values. Preserve the documented immutability of the class.

Check eligibility in the metric-filter service before mutating definitions or
reserving quota. Direct API and CloudFormation writes must use that check.
Prevent publication by an ineligible legacy filter without blocking its cleanup.
Use documented API errors and record any remaining class limitations in service
documentation; accepting class metadata does not make every class feature work.

### Dependencies and acceptance examples

Depends on the core metric-filter write path. Reuse existing log-group storage.

- A group created without a class reports `STANDARD`; a metric filter can be added.
- An `INFREQUENT_ACCESS` group reports its class but rejects a metric-filter write.
  The rejected write leaves the definition store and quota count unchanged.
- A `DELIVERY` group also rejects a metric-filter write.
- Restart preserves explicit classes. Loading an older group record retains
  Standard eligibility. An attempted class change cannot mutate the stored class.

### Effort and uncertainty

1-2 days. Verify the modeled eligibility error and CloudFormation class-update
behavior against documentation or existing fixtures before selecting assertions.
References: [CreateLogGroup][create-group], [PutMetricFilter][put-filter],
[CloudFormation LogGroup][cfn-group].

<a id="task-6-6"></a>
## 6.6: Crash-recoverable pending metric publication

### Scope and non-goals

Persist each per-event publication intent before its first metric write.
For example, a nonmatching event's default keeps its event timestamp and publication
identity across restart after the durable boundary. Do not change core per-event rules.
Recovery excludes samples discarded under the approved overflow policy or ingestion
that never produced a durable intent. This extends core runtime recovery.
It is not distributed exactly-once delivery or a general transaction framework.

### Affected surfaces and design

Reuse the core's 10,000-sample failed-publication retry queue, immutable account,
definition, and sample snapshots, and stable internal storage publication identifiers.
Add durable pending state through `StorageFactory`; preserve snapshots and identifiers
across restart. Do not build another queue or evaluate the current filter during replay.
Queue overflow remains `ERROR` with successful ingestion under the approved policy.

Use this write order:

1. Persist and confirm the intent before the first metric write, not only after
   a failure enters the runtime queue.
2. Replay each sample using its existing internal storage publication identifier.
   Repeated writes with that identifier must retain one contribution.
3. Reach the metric store's durable boundary before durably removing the intent.

Reuse the existing idempotent internal metrics path and persist its identifier mapping.
Ordinary `PutMetricData` is not a replay interface; do not expose internal identifiers
as non-AWS request fields. A separate "already sent" record cannot close the crash
gap unless it commits with the metric contribution. Never deduplicate separate events
by metric name, timestamp, or equal default values.

### Storage modes and lifecycle

| Mode | Required recovery contract |
| --- | --- |
| `memory` | Runtime retry only. Restart loses state; make no durability claim. |
| `persistent` | Writes replace a file. Prove failure reporting and intent/metric/removal ordering before claiming process-crash recovery. |
| `hybrid` | Periodic flush leaves an unflushed tail. Require a confirmed flush at each durable boundary or document that tail as outside the guarantee. |
| `wal` | The write-ahead log (WAL) appends changes. Test append/replay and compaction boundaries; a stream flush is not proof of power-loss durability. |

Evaluate both Logs and Metrics modes. Durable pending state with a memory-only
metric sink cannot safely discard the sole recoverable copy after publication.
Reject that durability configuration or retain a recoverable contribution under
an approved bounded policy.

`StorageBackend.put` and `flush` do not expose a commit receipt. Existing
persistent and WAL implementations log write failures. A caller cannot treat
return as evidence of durable success without addressing that gap.
Establish a narrow, testable failure-reporting contract before claiming recovery;
do not silently turn this task into a storage-layer rewrite.

Resume the existing managed one-second retry worker after `StorageFactory.loadAll`,
using explicit account access. Extend `Resettable` before/after hooks, not a second
worker or reset mechanism. Stop publication before shutdown flushes; restart must
not restore work that core deletion, snapshot, or reset rules discarded.

### Dependencies and acceptance examples

Reuse the core sink, retry worker, and snapshot/lifecycle contracts. Verified
storage commit and failure boundaries are the remaining prerequisite.

- Assert intent persistence precedes the first metric write, including a successful
  first attempt. Terminate a separate process after persistence; restart publishes
  the pending sample without another log batch.
- Terminate after a metric write but before intent removal. Replay leaves one
  contribution, including when only part of a multi-datum emission was written.
- Write two events with the same timestamp and default value. Both contributions
  survive replay; retrying either one cannot add a third.
- Inject disk-write failure, test mixed storage modes, and verify that recovery
  cannot claim success while dropping pending work. Test reset and shutdown races.

### Effort and uncertainty

2-4 days if existing stores can provide the required boundaries with narrow
changes. Failure propagation, mixed-mode guarantees, and power-loss durability
may require a separate estimate. No distributed exactly-once guarantee is included.
Reference: [PutMetricData][put-metric-data] defines the public write contract.

<a id="task-6-7"></a>
## 6.7: Original source account and region metadata

### Scope and non-goals

Carry source identity separately from the account and region that own the receiving
log group. This is metadata support, conditional on a trusted source ingestion path.
It is not a log-centralization service, replication engine, or permission model.

### Affected surfaces and design

Extend `model/LogEvent`, the internal ingestion entry point, and `LogEventsIngested`.
Use per-event source metadata if a batch can contain several origins. Do not use a
single destination-account field to represent both ownership and origin.

The trusted producer supplies original account and region. Direct local ingestion
derives them using the existing explicit-account path. Do not accept invented
`PutLogEvents` fields or trust `@aws.account` text inside a user message.
Persist origin with the event and preserve it through transformation and replay.
Legacy local records can use known destination identity; do not invent an origin
for a centralized record whose source is unknown.

Extend the existing `fieldSelectionCriteria` and `emitSystemFieldDimensions` inputs
with provenance. Matching local events already emit requested account/region
system dimensions; that behavior does not depend on centralization. Keep metric
storage in the destination partition. Tasks 6.9 and 6.10 use the same provenance.

### Dependencies and acceptance examples

First identify a real internal producer that can supply source identity.
If none exists, the producer is a prerequisite with its own scope and estimate.
Do not add a centralization endpoint to satisfy this task.

- An event with source `111122223333`/`us-east-1` enters a group owned by
  `444455556666`/`us-west-2`. Selection on `@aws.account` uses `111122223333`;
  an emitted `@aws.region` dimension is `us-east-1`. The sample belongs to the
  receiving account and region.
- Two origins in one batch retain distinct system dimensions after restart.
- A message containing a forged `@aws.account` property cannot change provenance.
  Direct account-specific ingestion still uses its resolved account, not a default.

### Effort and uncertainty

2-4 days for metadata only once the source path exists.
Choose that path and the missing-origin rule before implementation.
References: [PutMetricFilter][put-filter], [PutLogEvents][put-events].

<a id="task-6-8"></a>
## 6.8: High-cardinality metric-filter safeguard

### Scope and non-goals

Bound distinct emitted dimension name/value pairs per metric filter.
For example, `requestId=a` and `requestId=b` are two pairs; repeating
`requestId=a` does not add a third.
This is a documented emulator policy after AWS evidence review, not a new regex
quota or a claim to reproduce AWS's disabling algorithm.

AWS says it might disable a filter that generates 1000 different dimension
name/value pairs over a period of time. The published period is unspecified.
Do not describe an invented one-minute or one-hour window as AWS behavior.

### Affected surfaces and design

Add bounded observation state at the metric-filter publication boundary.
Partition by account, region, group, and filter generation. Count distinct pairs,
not whole dimension combinations or event count. Use only publishable samples.
Cap retained state at the configured threshold and synchronize concurrent updates.

Before coding, approve a local threshold, observation interval, disabled-state
lifetime, and re-enable rule. State whether system dimensions count, based on the
evidence. Use an injectable clock and label every local policy choice in
configuration and service documentation.

At the chosen threshold, stop further publication by that filter and record an
operator-visible reason without deleting its definition or rejecting log ingestion.
Keep the behavior independent of the core shared regex-quota reservation.

### Dependencies and acceptance examples

Depends on the core publisher and generation lifecycle. Review
[PutMetricFilter][put-filter] and retain the relevant evidence before selecting policy.

- With a test threshold of three and interval `W`, reach three distinct pairs
  inside `W` and assert the chosen disable boundary. Repeated pairs do not advance it.
- Verify expiry and re-enable behavior using the clock, not sleeps.
- Another filter or account remains unaffected. Concurrent publication cannot
  grow the observation set beyond its bound.
- Disabled filters remain describable and deletable; logs remain readable.

### Effort and uncertainty

1-2 days after evidence and emulator policy approval.
The AWS observation window remains unknown unless new evidence establishes it.

<a id="task-6-9"></a>
## 6.9: A limited set of working log transformers

### Scope and non-goals

A transformer runs an ordered list of processors at ingestion.
Choose only `parseJSON`, `addKeys`, and `renameKeys` for this slice.
For example, parse `{"status":"ERROR"}`, add `stage=local`, and rename
`status` to `severity`. The transformed record contains `severity` and `stage`;
the original message remains unchanged.

This is not the full processor catalog, historical reprocessing, or a new Logs
Insights query language. The full catalog requires an inventory and a new estimate.

### Affected surfaces and design

Add `PutTransformer`, `GetTransformer`, `DeleteTransformer`, and `TestTransformer`
handling with AWS request/response shapes. Store group definitions through
`StorageFactory`. Compile and validate the selected processors before replacing
a definition. Reject unsupported processors explicitly rather than storing a
definition that pretends to execute.

Use one executor for `TestTransformer` and ingestion. Test execution does not
store events or publish metrics. Cover processor ordering, field paths, missing
fields, type mismatches, and rename collisions using the official contracts.

Extend `CloudWatchLogsCrossAccountService` so `TRANSFORMER_POLICY` is executable,
not only stored. Compile its processor document and evaluate its documented
account/region and log-group selection criteria. Do not assume metric-selection
grammar is interchangeable. Include policy removal through `DeleteAccountPolicy`
if that operation is absent; do not implement other policy runtimes here.

A group transformer takes precedence over an applicable account transformer.
Do not run both in sequence. Removing the group definition exposes the applicable
account definition for subsequent ingestion. Establish the documented rule for
overlapping account policies before choosing an executor.

Store original and transformed views with the same event identity. Apply the
effective transformer once at ingestion, not again when filters or policies change.
Preserve source metadata supplied by 6.7, without making centralized ingestion
a prerequisite for ordinary local transformation.

Metric filters select the proper view through `applyOnTransformedLogs`.
`GetLogEvents` and `FilterLogEvents` continue returning original messages.
Connect stored transformed data to existing Logs Insights reads where AWS requires
it, without expanding query syntax. Task 6.10 uses the selected subscription view.
Specify processor failure and no-active-transformer behavior using evidence;
do not silently use the wrong view or discard the original event.

### Dependencies and acceptance examples

Depends on core metric-filter integration and lifecycle hooks. Use 6.5 class
eligibility when available and verify transformer class restrictions separately.

- `PutTransformer`/`GetTransformer` round-trip the selected processor definition.
  `TestTransformer` and ingestion produce the same transformed fields.
- With both an applicable account policy and a group transformer, only the group
  processor output appears. After group deletion, a new event uses the account policy.
- An excluded group and another account do not inherit the policy.
- A pattern on `severity` matches the transformed view in the example. The same
  filter on the original view does not match. Original-message reads stay unchanged.
- A malformed definition cannot replace a working one. Restart preserves definitions
  and stored views; policy updates do not rewrite older events.

### Effort and uncertainty

10-20 days for the three selected processors, management operations, account
applicability, and data integration. Confirm overlap rules, failure semantics,
and processor option coverage before coding. Inventory every additional processor
before estimating a full catalog.
References: [PutTransformer][put-transformer], [GetTransformer][get-transformer],
[DeleteTransformer][delete-transformer], [TestTransformer][test-transformer],
[Processor][processor], [PutAccountPolicy][put-account-policy],
[DeleteAccountPolicy][delete-account-policy], [GetLogEvents][get-events].

<a id="task-6-10"></a>
## 6.10: Subscription delivery to one destination type

### Scope and non-goals

Implement delivery to a Lambda function in the same account and region.
An `ERROR` event selected by a subscription must reach that function, not only
appear in `DescribeSubscriptionFilters`.
Kinesis Data Streams, Amazon Data Firehose, cross-account destinations, and
account-wide subscription policies need separate designs and estimates.

### Affected surfaces and design

Extend subscription definitions, handler validation, and ingestion dispatch in
CloudWatch Logs. Use the core pattern engine and atomic metric/subscription quota.
Pass delivery to the existing Lambda invocation service, not a custom HTTP endpoint
or a speculative destination framework.

Send the real Lambda subscription envelope: `awslogs.data` holds Base64-encoded
gzip data. Its decoded object carries `owner`, `logGroup`, `logStream`,
`subscriptionFilters`, `messageType`, and `logEvents` with event identifiers,
timestamps, and messages. Cover `DATA_MESSAGE` and documented `CONTROL_MESSAGE`
behavior. Keep batch sizes within the documented destination limits.

Check the Lambda resource policy using the CloudWatch Logs service principal,
`lambda:InvokeFunction`, and the applicable source resource/account conditions.
An Amazon Resource Name (ARN) identifies the function and source group.
Reject a missing or forbidden destination with the documented error behavior.
Do not treat a destination ARN or unused `roleArn` as permission to invoke.

Use bounded asynchronous delivery with stable event identifiers. Implement the
documented retry horizon and suspension behavior. Distinguish throttling and
temporary service failures from permission or missing-destination failures.
Expose expired batches and failures in diagnostics; do not report a successful
delivery for a swallowed exception.

After Lambda accepts an asynchronous invocation, its runtime owns function-error
retries. The Logs worker must not repeat an accepted invocation because execution
later failed. Subscription delivery can still produce duplicates, as AWS documents.
Define queued-batch behavior for filter update/delete and stop workers during reset.
Avoid recursive delivery of a subscriber's own logs using documented restrictions.

### Dependencies and acceptance examples

Requires core matching/quota behavior and a Lambda invocation path with the needed
permission checks. Use class metadata in 6.5 when present.
Original-message delivery does not depend on 6.9; transformed delivery does.
Use 6.7 metadata for supported system fields without adding cross-account delivery.

- A local Lambda subscriber decodes the envelope and observes the matching event's
  original identifier, timestamp, and message. A nonmatching event is absent.
- Missing permission blocks delivery; granting the documented permission permits it.
- Inject throttling, a temporary service failure, permission loss, and destination
  deletion. Assert retry/suspension/expiry using a controlled clock.
- Lambda acceptance followed by a function error does not trigger a Logs-layer retry.
  Updates, deletion, and reset cannot redirect stale work to another destination.
- When 6.9 is available, `applyOnTransformedLogs` selects the documented view.

### Effort and uncertainty

5-10 days for this one destination type. Permission gaps, durable delivery queues,
or additional destination types require separate estimates. Confirm queue lifecycle
and destination validation behavior before coding.
References: [PutSubscriptionFilter][put-subscription],
[subscription delivery][subscriptions], [Lambda subscription example][lambda-subscription].

<a id="task-6-11"></a>
## 6.11: Conditional general CloudFormation replacement framework

### Scope and non-goals

Deferred and not recommended for Task 6. Allocated effort: 0 days.
Use the core type-local `delete_then_create` repair first. Do not create interfaces,
replacement planners, generic journals, or other speculative abstractions.

### Trigger, affected surfaces, and bounded design

Consider this only if a reproducible core case proves that type-local repair cannot
work and a maintainer approves a bounded design. For example, a failing stack test
must show which dispatcher or rollback constraint prevents the metric-filter
provisioner from safely replacing a named filter.

The proposal must identify the minimum change to the CloudFormation dispatcher,
provisioning context, rollback handling, and `LogsMetricFilterCfnProvisioner`.
Name affected resource types and explain why a local change is insufficient.
Do not migrate unrelated provisioners or create a shared transaction system.

### Dependencies and acceptance examples

Requires the failing type-local test, maintainer approval, and a revised estimate
before implementation. Core replacement tests remain owned by the core repair.

Any approved proposal must demonstrate that replacement and rollback preserve the
right physical identifiers, restore prior filter properties after a failed create,
respect quota, and cannot delete a different account's resource.
Include regression tests for every other resource type touched by the bounded change.

### Effort and uncertainty

0 days allocated to Task 6. There is no framework implementation estimate without
the failure evidence and approved scope.
Reference: [CloudFormation update behaviors][cfn-updates].

[filter-events]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_FilterLogEvents.html
[filter-syntax]: https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/FilterAndPatternSyntax.html
[create-group]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_CreateLogGroup.html
[put-filter]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutMetricFilter.html
[cfn-group]: https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-logs-loggroup.html
[put-metric-data]: https://docs.aws.amazon.com/AmazonCloudWatch/latest/APIReference/API_PutMetricData.html
[put-events]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutLogEvents.html
[put-transformer]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutTransformer.html
[get-transformer]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_GetTransformer.html
[delete-transformer]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_DeleteTransformer.html
[test-transformer]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_TestTransformer.html
[processor]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_Processor.html
[put-account-policy]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutAccountPolicy.html
[delete-account-policy]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_DeleteAccountPolicy.html
[get-events]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_GetLogEvents.html
[put-subscription]: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutSubscriptionFilter.html
[subscriptions]: https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/Subscriptions.html
[lambda-subscription]: https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/SubscriptionFilters.html#LambdaFunctionExample
[cfn-updates]: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html
