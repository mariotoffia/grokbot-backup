# Task 6.1: landing plan for the metric-filter repair

**Status source:** [Task 6](../../TEOS_GROUNDZERO_TASKS.md#task-6-optional-metric-filters-dashboards-event-invoke-config).
**Core design:** [CORE_REPAIR.md](CORE_REPAIR.md). **Source of truth for the code:** branch
`feat/logs-metric-filters` at `b035d79df`, preserved as `backup/pr3233-b035d79df`.

## Why the PR did not land

At closure floci-io/floci#3233 was green on all 24 checks and mergeable. It stalled on shape:
93 files and 19,333 insertions in one PR, unrelated changes bundled in (an SQS test fix, a core
reset-lifecycle change), speculative migration code for a format no release ever wrote, and a new
repository rule requiring signed commits that none of the nine branch commits met.

## Target shape: two pull requests (PR A dropped)

**Executed 2026-09-17.** PR A was dropped: upstream #3757 (`8d755c20d`) replaced the throttle sleep
with a latch, which is the root cause of the flake, and the test passes in 0.2 s on `main`. C targets
`main`, not the B branch, because branches in a fork cannot serve as a PR base in `floci-io/floci`;
its first body line names #3233 and the commit split, per `plans/README.md`. B landed as three
commits, not four: the service file carries both operations and publication, so a compiling split
between them was not possible without an artificial intermediate version.

### Original target shape

| PR | Branch | Base | Contents |
| --- | --- | --- | --- |
| A `fix(sqs)` | `fix/sqs-move-task-cancellation-tests` | `main` | Only the SQS executor-injection seam and the two deterministic cancellation tests. Independent of metric filters. |
| B `feat(logs)` (#3233 reopened) | `feat/logs-metric-filters`, rewritten | `main` | Metric filter operations, pattern engine, shared quota, per-event publication with bounded retries, `Resettable` hooks, the `AWS::Logs::MetricFilter` provisioner and its hooks, the two basic SDK tests, docs and the verification record. |
| C `test(compat)` | `test/logs-metric-filter-compat` | `feat/logs-metric-filters` | Publishing/Query SDK assertions, module-local fixture copies with the byte-sync test, the opt-in Python replay under `tests/`, READMEs. No Dockerfile changes. |

The user chose to fold the `Resettable` hooks and the CloudFormation provisioner hooks into B
rather than separate PRs; B's description justifies each hook in one paragraph, which is what the
maintainer asked the separate PRs to provide. Head branches live in the fork, so GitHub native
stack registration is unavailable; C is an ordinary dependent PR whose body names its parent and
B's body carries a `## Stacked pull requests` row, following `plans/README.md`.

## Review items resolved in B

| Item | Resolution |
| --- | --- |
| `DescribeMetricFilters` pair validation (blocker) | Reject `metricNamespace` without `metricName` too, `InvalidParameterException`, with service, HTTP and SDK reverse regressions. |
| 10,000-character `TestMetricFilter` message limit | Declined. Live AWS in `eu-west-1` accepted 10,001, 100,000, 262,145 and 2,000,000 character messages on 2026-09-17; the API model documents no maximum. Reply on the thread with that evidence. |
| Baseline snapshot migration | Delete `normalizeBaselineSnapshot`, the version-1 `readSnapshot` upgrade, the legacy pipe-split identity branch, the two `metric-filter-head-*.json` fixtures, `CloudFormationLogsMetricFilterHeadSnapshotIntegrationTest` and the legacy-provenance tests. Delete `normalizeExistingState` and its dispatcher call if nothing but that legacy path used it; the full CFN suite decides. Conservative `UNKNOWN` handling for the current state format stays. |
| Type-specific check in `CloudFormationService` (UPDATE_FAILED path) | Replace the `METRIC_FILTER_UPDATE_SNAPSHOT_ATTR` lookup with a default-false `CfnResourceProvisioner.retainsFailedUpdateState(StackResource)` hook that only the metric-filter provisioner overrides. |
| `FlociMetricFilterNameMode` | Rename to `__FlociMetricFilterNameMode`; verify snapshot restore and cleanup still see it. |
| `capture_filter_patterns.py` under test resources | Move to `tools/aws-capture/cloudwatchlogs/`; update the verification doc and fixture provenance text. |
| Compat Dockerfiles | Back to upstream. The Java image already runs `mvn test`; the Python replay lives under `tests/` so no COPY change is needed. |
| PR body | Plain description of what the PR does and how it was verified, only `feat:` ticked, hook paragraphs, evidence table kept, stacked-PR row for C. |
| Signed commits | Every commit on all three branches is SSH-signed with the key GitHub already verifies as `valid` (probe commit `9223532` on 2026-09-17). |
| Closing comment | Delete issue comment 5708758992 and reopen #3233 before force-pushing its branch. |

## B commit series

Rebuilt on current `upstream/main` as four signed commits, each compiling:

1. `feat(logs): metric filter operations, filter-pattern engine and shared regex quota`
2. `feat(logs): publish metric filter samples per event with bounded retries` (includes the
   `Resettable` hooks, `performReset` ordering and a controller-level order test)
3. `feat(cloudformation): provision AWS::Logs::MetricFilter` (provisioner, hooks, inventory,
   fixture wiring, CFN SDK test, generated resource table)
4. `docs(logs): metric filter documentation and verification record`

## Verification gates

- A: `SqsServiceTest`, `SqsIntegrationTest`; GitHub CI.
- B: the focused root union used at closing (about 2,550 cases), `make docs-test docs-check`,
  `mkdocs build --strict`, SDK Java tests against a fresh JVM build, GitHub CI 24/24.
- C: offline Python tests, Java compile, SDK tests against a JVM built from B plus C, GitHub CI.
- All: `git log --format=%G?` shows `G` for every branch commit and GitHub reports `verified`.
