# Task 6.1: CloudWatch Logs metric-filter core repair

**Approved scope:** the complete core repair discussed on 2026-09-16, including publication-failure
handling and verification of the advertised filter-pattern syntax.
**Worktree:** `.claude/worktrees/feat-logs-metric-filters`, starting at `8787f91e41e0`.
**Task status:** [Task 6](../../TEOS_GROUNDZERO_TASKS.md#task-6-optional-metric-filters-dashboards-event-invoke-config).
**Deferred capabilities:** [follow-up designs](FOLLOW_UPS.md).

**Completion evidence:** the local core repair passed independent production and test/replay reviews.
The final focused root run passed 2,549 cases; fresh JVM and Linux ARM64 native each passed 12 SDK
cases plus an offline loader. Module-context Docker checks and quiet-last replay run without a
repository-root fixture dependency. Detailed commands, artifact hashes and limitations are retained
in the worktree's `target/core-closing-result.json`. The repair was committed and pushed as
`fd4d5310f` without a Copilot byline; the PR remains unmerged. Task status remains solely in the
task index.

**Temporal design correction:** live AWS observations obtained after the initial design approval
contradict the proposed once-per-minute default cap. Three nonmatching events in one request with
default 7 produced Sum 21 and SampleCount 3 without subsequent ingestion. A mixed nonmatch and
numeric match of 5 with default 17 produced Sum 22 and SampleCount 2 in the same minute.
Delete the default-minute accumulator rather than repairing its invalid deduplication rule.
Grammar, quota and CFN repairs remain independently valid.

## Outcome and boundary

Keep the existing AWS Logs JSON protocol, per-service CloudFormation provisioner, storage factory,
and filter-pattern engine. Correct their behavior rather than replacing CloudWatch or creating a
general replacement framework. A default must become observable without another ingestion call,
both filter write paths must enforce the same quota atomically, and changing or deleting a filter
must not corrupt another account's state or reinterpret old events under a new transformation.

Runtime publication failures belong to this repair. Crash-durable pending work, actual transformers,
subscription forwarding, centralized ingestion, class metadata, and cardinality disabling are separate
Task 6 capabilities. Already published metrics and stored filter definitions retain their configured
storage semantics. The repair must not claim that an in-memory pending queue survives process loss.
For a sustained storage outage, the user explicitly selected bounded best-effort retries:
ingestion remains successful, an exhausted retry capacity is reported as an error with the
dropped publication count, and durable recovery stays in Task 6.6. Do not claim lossless operation
after that bound is exhausted.

## Evidence before semantics

The reviewed head passes 112 focused cases while nine independent diagnostic expectations fail.
The diagnostics are not themselves a complete acceptance suite: direct helper calls must be promoted
to tests of the real operation and lifecycle paths.

Use authoritative sources in this order for each disputed behavior: observed AWS requests/responses
with recorded context, explicit AWS contract text, then a clearly identified emulator policy for
behavior neither source establishes. An empty early metric read is not proof of absent publication.
The API model supplies wire shapes; user-guide examples establish aggregation behavior; the
CloudFormation registry supplies resource-specific schema and replacement requirements.

Authorized live probes use CLI profile `devlocal` in `eu-west-1`, isolated synthetic resources and
verified cleanup. They settle the regex counting unit, default and metric timestamp behavior,
extraction edge cases, transformed-log eligibility, and `Ref` encoding before those choices become
regression expectations. Preserve a sanitized, runnable opt-in corpus in the compatibility module.
Do not copy credentials, account identifiers, temporary ARNs or local profile names into public
fixtures. Custom metric series cannot be explicitly deleted; record that residual separately from
deletable resource cleanup.

Primary references:

- [PutMetricFilter](https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutMetricFilter.html)
- [PutSubscriptionFilter](https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutSubscriptionFilter.html)
- [Metric-filter concepts](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/MonitoringLogData.html)
- [Metric-filter syntax and values](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/FilterAndPatternSyntaxForMetricFilters.html)
- [Regex syntax and quotas](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/FilterAndPatternSyntax.html)
- [CloudFormation registry schema](https://schema.cloudformation.us-east-1.amazonaws.com/CloudformationSchema.zip)
- Local schema: `local/aws/cfn-resource-schemas/us-east-1/aws-logs-metricfilter.json`.

### Observed contract decisions

The authorized 2026-09-16 eu-west-1 probe accepted five metric filters containing two regex
expressions each and rejected a sixth regex-bearing filter with `LimitExceededException`.
The group quota counts filters containing regex, not individual expressions. Changing a filter
to a plain pattern releases its slot; a rejected plain-to-regex replacement preserves the plain
definition.

The same probe observed CloudFormation `Ref` returning the filter name only. Public reference
values and internal cleanup identifiers must be distinguished until the physical-resource-ID
observation is also recorded.

AWS accepted a numeric default together with an emitted account system dimension, while rejecting
ordinary transformation dimensions together with a default. Do not generalize the ordinary-dimension
prohibition to system dimensions.

For timing, newly ingested events published in their event-timestamp minutes, including a timestamp
before the filter was created. A nonmatch with default 11 followed by a later matched value 3 for
that same old minute produced Sum 14 and SampleCount 2, with no retraction of the default.
This does not establish retroactive processing of events ingested before filter creation.

The isolated extraction probe matched on a separate discriminator: a missing or explicitly null
metric-value field emitted the configured default; a numeric field emitted its value. Nonnumeric
strings produced no point while positive controls succeeded. Preserve the final observation
window in the evidence record for negative results.

## Publication and pending state

Do not implement a clock-driven default deduplication mechanism merely to preserve the original
design. The observed default samples are per event, while CloudWatch aggregates the resulting
datapoints by minute. Emit a default for each nonmatching event, and the observed fallback for a
matching event with a missing/null extracted metric value. A match elsewhere in the batch or
minute does not suppress that contribution. No events means no points.

Delete `MetricFilterMinutes` and its history, cleanup and settlement machinery. Keep each datum
at the event timestamp and let the existing Metrics service aggregate it. Distinguish event and
ingestion timestamps in tests. A retry clock, if used, schedules retry attempts, not metric
eligibility or minute-wide suppression.

Any pending retry work has explicit ownership: resolved account, Region, log group, filter identity and the
transformation that accepted the event. Capture publication identity and values rather than looking
up the newest transformation when old work becomes due. Updates cannot manufacture old samples in
a replacement namespace. Account-scoped filter/group deletion cancels only its own pending work.
Actual emulator reset clears pending work on the existing live instance through `Resettable`.

Retry and ingestion must not race into duplicate samples or lost matching samples. A successful
publication retires its pending work. A failure retains the retryable work and is logged with useful
identity; a partially successful write must not cause already-written samples to be added again.
Reuse internal metric storage capabilities or stable internal output identifiers rather than changing
the AWS PutMetricData wire contract. Do not make runtime retry guarantees into a distributed
exactly-once or crash-durability claim.

If a periodic worker is needed for publication retries, it respects service enablement, carries
explicit account context, survives an individual tick failure and stops at shutdown. Completed work
is released. Do not retain minute histories for an append-only publication rule.

The implementation uses one retry worker and a fixed capacity of 10,000 failed samples.
Healthy writes are still attempted when that capacity is full. Samples beyond the bound are
reported at ERROR with ownership and dropped count, without discarding earlier queued samples.
Retries use stable internal metric-storage identifiers; ordinary AWS PutMetricData calls remain
append-only.

Reset coordination uses default no-op `beforeReset` and `afterReset` hooks on the existing
`Resettable` interface. The controller quiesces prepared services before wiping storage, retains
the existing storage-before-bootstrap `clear` ordering, and resumes in `finally`. Publication
releases its canonical backend monitor before the factory wipe, avoiding an inverted lock order.

The synchronous storage API has no cancellation or deadline contract. A storage call that never
returns can delay the initial shutdown/reset drain; the worker's five-second termination wait
does not bound that drain. Likewise, a backend failure that is logged but not thrown cannot be
detected by the retry layer. These storage-boundary limitations are disclosed, not presented as
verified lossless or deadline-bounded behavior.

## Shared quota and grammar

Metric and subscription puts must use one counting rule and one atomic check-and-write boundary.
Replacement accounting excludes the old contribution only in its own filter family and identity.
Deletion releases its contribution. Failure leaves the previous definition untouched. Store failures
and invalid stored patterns must not silently count as an empty group.

Share only the necessary accounting and coordination. Avoid a dependency cycle between Logs and
the metric-filter service. Use the existing `StorageFactory` and constructor-injection patterns; do
not create a second independent store for the same resources.

The implemented coordination uses the canonical metric-filter backend itself as the shared
monitor. `CloudWatchLogsService` obtains it from `StorageFactory` and the metric-filter service
reuses that exact instance. Both families' puts/deletes and group creation/deletion hold it across
existence checks, validation and writes. Direct constructors receive the same backend explicitly;
no coordinator class, callback registration or shadow store is required.

System-field selection is a different language from log-message filter patterns. Accept the
documented `AND` and `OR` with tested truth tables and precedence without accidentally enabling new
operators in JSON log patterns. Numeric and container validation happens before mutation. Assertions
cover presence and node types, not coercions that turn missing values into success-shaped defaults.

## CloudFormation

The resource schema declares `delete_then_create`. A name or group replacement must follow that
ordering and work when the old group contains 100 filters. Keep the prior complete definition and
identity needed to recover if replacement creation fails after deletion.

The live CFN probe confirmed deletion-before-creation, the corresponding DELETE/CREATE resource
events, and restoration of the previous backing definition after a failed replacement. Both `Ref`
and `PhysicalResourceId` were the filter name alone. The tested `UpdateReplacePolicy: Retain`
rename still deleted the old filter before creation; do not import another type's retain behavior
into this provisioner. This does not change stack `DeletionPolicy` behavior.
Normalized evidence is in `src/test/resources/cloudwatchlogs/metric-filter-cfn-aws.json`.

After three ownership findings around ambiguous storage effects, the user approved a type-local
mutation-outcome correction rather than another isolated flag patch. Create, delete and restore
must use consistent applied, not-applied and unknown outcomes, inspected and recorded under the
same canonical storage monitor. A thrown exception is not evidence that the mutation had no effect.
Known deletion requires guarded recreation; unknown ownership must retain failed metadata instead
of triggering an unguarded upsert or delete.

The acceptance matrix covers failures before an effect, after an effect, and during outcome
inspection for each mutation, with competing creators admitted after the monitor is released.
Forward execution, rollback and actual DeleteStack must all respect the recorded outcome.
Callback failures must not be misclassified as storage failures. This correction remains local to
the metric-filter integration, not a general CloudFormation replacement framework.

On a later stack-update failure, restore the actual backing filter, not only its physical ID.
Failures restoring or deleting resources remain visible and retryable through the existing
provisioner lifecycle. Cover relevant replacement/deletion policy interactions explicitly; do not
alter unrelated resource types or weaken the 100-filter quota.

The API and CloudFormation have different input shapes and some different schema constraints.
Validate each layer's shape without treating one schema as proof of the other's provider behavior.
Verify the actual AWS `Ref` and physical-ID representation; a composite schema identifier alone does
not establish its string serialization.

## Verification design

Existing JUnit, Mockito, RestAssured and AWS SDK facilities are sufficient. Add each failing
regression before its production fix, observe its failure, and rerun the smallest covering selector.
Do not count a constructor mismatch or unrelated boot error as the intended regression.

The temporal suite separates event and ingestion times. Its observed control sends three
nonmatching events with default 7, stops ingestion, and expects Sum 21 and SampleCount 3 in the
event minute. Further reads or retry ticks must not add copies, and a minute with no events
must not manufacture data. Retain the late default-then-match Sum 14 / SampleCount 2 observation.
Negative assertions extend through the relevant publication/retry path and have a positive control.

Concurrency tests use barriers and bounded joins, not sleeps as an ordering mechanism. Cover
multiple streams, mixed match/miss order, parallel quota writers, deletion/update/reset racing
settlement and failure on one publisher while another succeeds.

Integration tests exercise real account-scoped create/delete/reset paths and SDK wire behavior.
Read emitted metrics through both CloudWatch Query and JSON paths, GetMetricStatistics and
GetMetricData, with relevant alarm checks. CFN tests inspect backing filters and emitted metrics,
including the 100-filter replacement and failure after deletion. A generated-name stability test
changes a mutable property instead of requiring success for an identical-template update.

Pattern fixtures record their evidence source and exact extraction/acceptance expectations.
Authorized AWS observations distinguish conflicting documentation, not just duplicate local output.
Strict wire tests cover nulls, scalar/container mismatches, required members and numeric boundaries
without treating Jackson coercion as the contract.

Reload tests cover filter definitions and already-written metrics in memory, persistent, hybrid and
WAL modes. Runtime pending-state reset/retry tests are core; durable pending-state replay is 6.6.
Finish with focused source/SDK tests, relevant schema/inventory gates, docs-sync/docs-check and a
correctness review of the complete diff. No commit, push or PR-thread resolution is implicit.

## Implementation order and file ownership

First establish the AWS observation corpus. Grammar and handler work is isolated under
`services/cloudwatch/logs/filter/` and `CloudWatchLogsMetricFilterHandler`. CFN repair is isolated
to `LogsMetricFilterCfnProvisioner`, its directly necessary rollback metadata and its tests.

Coordinate shared quota changes in `CloudWatchLogsService` and
`CloudWatchLogsMetricFilterService` before combining them with publication changes.
Publication changes touch `MetricFilterMinutes`, the filter service, explicit-account metric
writes, lifecycle wiring and their tests. Avoid simultaneous edits to these shared files.

The final integration pass updates `docs/services/cloudwatch.md`, generated documentation when its
inputs changed, and the SDK compatibility fixtures. Task completion is recorded only in the task
index after the corresponding acceptance evidence exists.
