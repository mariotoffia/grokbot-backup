# Task 6 design navigation

## Overview

Task 6 covers Amazon Web Services (AWS) CloudFormation provisioners for CloudWatch
Logs metric filters, CloudWatch dashboards, and Lambda event-invoke configuration.
A metric filter turns matching log events into metric samples. For example, an
`ERROR` event can add `1` to an application error metric.

[TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md) owns task tracking,
implementation status, and pull request history. This directory holds designs.
The [shared task guide](../README.md) covers setup and provisioner conventions.
The [groundzero design](../../TEOS_GROUNDZERO_DESIGN.md) provides project context.

## Core design

[CORE_REPAIR.md](CORE_REPAIR.md) defines the metric-filter repair for Task 6.1:

- Per-event sample appends using event timestamps, including defaults and dimensions.
- Account lifecycle, reset, and filter-update behavior.
- Runtime partial-publication recovery with a 10,000-sample retry queue, immutable
  snapshots, stable internal publication identifiers, and a managed one-second worker.
- Atomic quota enforcement shared by metric and subscription filters.
- Field-selection `AND` and `OR` semantics.
- Type-local CloudFormation `delete_then_create` replacement.
- Filter-pattern and wire-protocol parity fixtures and tests.

Nonmatches emit the configured default per event. Missing or null metric values
use the configured default; nonnumeric values produce no sample. Incomplete
ordinary dimensions fall back to a dimensionless sample. Matching events emit
requested account/region system dimensions; pattern-nonmatch defaults are dimensionless.

Queue overflow logs an `ERROR` and leaves ingestion successful. This is bounded
best-effort runtime recovery. These repairs belong to the core design, not to the follow-ups.
Persisting an unpublished sample across a process crash is a separate concern in
[6.6](FOLLOW_UPS.md#task-6-6).

## Follow-up designs

Each entry links to scope, affected code, dependencies, acceptance examples, and
an effort estimate. Scheduling and completion belong in the task tracker.

| Task | Design |
| --- | --- |
| 6.4 | [Reuse the filter engine in FilterLogEvents](FOLLOW_UPS.md#task-6-4) |
| 6.5 | [Log-group class metadata and metric-filter eligibility](FOLLOW_UPS.md#task-6-5) |
| 6.6 | [Crash-recoverable pending metric publication](FOLLOW_UPS.md#task-6-6) |
| 6.7 | [Original source account and region metadata](FOLLOW_UPS.md#task-6-7) |
| 6.8 | [High-cardinality metric-filter safeguard](FOLLOW_UPS.md#task-6-8) |
| 6.9 | [A limited set of working log transformers](FOLLOW_UPS.md#task-6-9) |
| 6.10 | [Subscription delivery to Lambda](FOLLOW_UPS.md#task-6-10) |
| 6.11 | [Conditional general CloudFormation replacement design](FOLLOW_UPS.md#task-6-11) |

## Implementation references

- Task 6.1: [metric-filter pull request #3233](https://github.com/hectorvent/floci/pull/3233).
  `CloudWatchLogsMetricFilterService` consumes `LogEventsIngested` and
  `LogGroupDeleted` events emitted by `CloudWatchLogsService`. The pattern engine
  lives in `services/cloudwatch/logs/filter/`; `LogsMetricFilterCfnProvisioner`
  handles `AWS::Logs::MetricFilter`.
- Task 6.2: [dashboard pull request #3231](https://github.com/hectorvent/floci/pull/3231).
  `CloudWatchDashboardCfnProvisioner` handles named and generated dashboards.
  `__FlociDashboardUpdateSnapshot` is a reference for in-place rollback.
- Task 6.3: [event-invoke-config pull request #3230](https://github.com/hectorvent/floci/pull/3230).
  The physical identifier is `FunctionName|Qualifier`.
  `__FlociEventInvokeConfigSnapshot` is a reference for in-place rollback.
  Cross-account function-reference behavior belongs to Task 24 in the
  [task tracker](../../TEOS_GROUNDZERO_TASKS.md), not to the metric-filter repair.
- [CloudWatch service documentation](../../../docs/services/cloudwatch.md)
  describes the public service surface.
