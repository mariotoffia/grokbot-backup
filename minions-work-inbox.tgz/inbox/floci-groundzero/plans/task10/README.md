# Task 10: ACM certificate options and the custom-resource certificate path

Index: [TEOS_GROUNDZERO_TASKS.md](../../TEOS_GROUNDZERO_TASKS.md). Setup steps and the checklist every provisioner PR ends with: [../README.md](../README.md).

Follow-ups to Task 1, split off after #3003 merged. One small Floci PR and one verification; analysis items 1.4 and 1.8.

## 10A. `feat(acm): map CertificateExport and CertificateTransparencyLoggingPreference onto the certificate options`

Branch `feat/acm-cfn-certificate-options` from `upstream/main`, worktree `.claude/worktrees/feat-acm-cfn-certificate-options`, PR #3111 opened 2026-09-05. Independent of every open PR.

- [x] In `AcmCfnProvisioner.provision`, resolve `CertificateExport` and `CertificateTransparencyLoggingPreference`, build `new CertificateOptions(ctLogging, export)` (defaults `ENABLED` / `DISABLED` as `CertificateOptions.defaultOptions()`), and pass it where `requestCertificate(...)` receives `null` today.
- [x] `CertificateExport` is createOnly in the schema: add it to `sameCreateOnlyProperties` so a changed value replaces the certificate through the existing `deletePriorOrUnwind` path. `CertificateTransparencyLoggingPreference` is updatable: on an in-place update call `acmService.updateCertificateOptions(arn, options, region)` next to the tag reconcile.
- [x] Tests: `AcmCfnProvisionerTest` asserts the options reach `requestCertificate` and that `DescribeCertificate` returns `Options.CertificateTransparencyLoggingPreference` and `Options.Export`; an update case for each property (replace versus in place).
- [x] Docs: the coverage table rows for both properties in the PR body flip to ✅; `docs/services/cloudformation.md` is regenerated only if `tools/docs/cfn_resource_types.yaml` gains a note. No new config, no TSV change (same type).
- [x] `CertificateAuthorityArn` stays ignored: private CA is not emulated, as #3003's body states. Say so in this PR's body too.

## 10B. Smoke-test the `DnsValidatedCertificate` custom-resource path (verification, no code)

groundzero's `api.auth.<acct>` certificate is a CDK custom resource, not the provisioner. The CDK Lambda calls `RequestCertificate` in `us-east-1`, polls `DescribeCertificate` until every `DomainValidationOptions[]` has a `ResourceRecord`, UPSERTs those CNAMEs with `ChangeResourceRecordSets`, polls until `ISSUED`, and on delete removes the CNAMEs and calls `DeleteCertificate`. Floci already generates the validation records and reports `ISSUED` at once, so nothing should need building.

- [x] Run one CDK stack with a `DnsValidatedCertificate` against the fork image (or the first groundzero service-test run, which exercises it anyway) and confirm `CREATE_COMPLETE`, a real ARN in `ListStackResources`, and a clean delete.
- [x] Watch for: the Lambda container reaching Floci (`AWS_ENDPOINT_URL` injected by `LaunchedContainerAwsEnv`), and `DeleteCertificate` being retried by the Lambda once #3035's `InUseBy` marks the certificate as used by the Cognito domain (the stack deletes the domain first, so it should pass; if it does not, that is a finding for #3035, not for this task).
- [x] If it fails, the fix is a Floci PR in whichever service returned the wrong shape; open it as its own task then. It failed: `DescribeCertificate` reported `ValidationStatus: PENDING_VALIDATION` on an `ISSUED` certificate and the CDK handler's `CertificateValidated` waiter never returned. Fixed by #3112 (validation status follows issuance; the configured validation wait now settles on read). Re-run with #3112 and `FLOCI_TLS_ENABLED=true`: `CREATE_COMPLETE`, real ARN, CNAME in the zone, clean destroy. Throwaway app and driver: `.claude/worktrees/feat-acm-cfn-certificate-options/target/cdk-smoke/`.
