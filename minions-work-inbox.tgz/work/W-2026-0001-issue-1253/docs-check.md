# Docs check: issue #1253 (origin/main)

## 1. Claim and generator
- #1253 says `sur/model/surmodel/model_*.go` is gitignored and comes only from a Docker codegen step. In a worktree bootstrapped without Docker, `make vet/lint/test` fail (`undefined: surmodel.*`) and `make tidy` drops `gopkg.in/validator.v2`. It asks for the models to be committed/vendored, or for docs that say Docker is required.
- Generator: `go-services/providers/eastbound/sur/Makefile:14` `generate-code:` runs `docker run openapitools/openapi-generator-cli` and writes `model/surmodel/model_*.go`.
- Call chain: root `Makefile:114` `generate` → `:122` `generate-code` → `make -C go-services generate-code` (`go-services/Makefile:90`, runs every sub-Makefile that has `generate-code:`) → sur `generate-code`.
- Gitignored: yes, by `go-services/providers/eastbound/sur/model/surmodel/.gitignore:1` `model_*.go`. That is intended.
- Note: `go-services/Makefile:90-97` should exit 1 when docker fails, but the issue reports `make generate` rc=0. That needs a separate check; it could be a gate bug.

## 2. Does setup say to run it?
Yes. `make generate` is a required bootstrap step, and it produces surmodel:
- `AGENTS.md:131-143` "MUST: bootstrap a new worktree or clone": `make dep`, then `make generate` "(needs dep, and Docker)".
- `AGENTS.md:306-315`: install → dep → generate, in that order.
- `README.md:79-82`: install → dep → generate → build.
- `DEVELOPMENT.md:16-21`: Linux getting started: dep → generate → build → test.
- `DEVELOPMENT.md:572-576`: the pipeline diagram shows `openapi-generator-cli (Docker)`.
- `GROKBOT.md:130-146`: the box setup installs and starts Docker.
- The SUR service has no README.

## 3. Gaps that led to #1253
- `DEVELOPMENT.md:5-10` Prerequisites lists Go, Node, pnpm and AWS CLI, but not Docker.
- `DEVELOPMENT.md:409` and `README.md:81` describe `make generate` without saying it needs Docker.
- `AGENTS.md:139` "(needs dep, and Docker)" is the only place that says it, and only in a code comment. Nothing says that `make generate` without Docker leaves the tree incomplete, or what the symptoms are (`undefined: surmodel.*`, deleted `go-services/model/*api` files).
- `AGENTS.md:141-143` says missing files mean "the worktree is not bootstrapped", but it doesn't say that a bootstrap without Docker counts as not bootstrapped. The minion's `make generate` returned 0, so it concluded the repo was broken.
- `AGENTS.md:321` "make test ... no Docker ... needed" can be read as "the gates don't need Docker".

## 4. Proposed fix
```diff
--- a/DEVELOPMENT.md
+++ b/DEVELOPMENT.md
@@ -9,2 +9,3 @@
 - pnpm 9.x+ (web monorepo package manager, installed via `make install`)
 - AWS CLI configured
+- Docker, running: `make generate` uses it to generate API models (for example SUR `surmodel`). Without it the build, lint and tests fail.
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -141,3 +141,5 @@
 Missing files, unresolved embeds and `command not found` from these tools mean
 the worktree is not bootstrapped, not that the code is broken. Failures after
 both commands are real.
+Docker must be running for `make generate`. If it was not running, the generated models are missing (for example `undefined: surmodel.*`).
+Start Docker and run `make generate` again. Do not commit generated files or file an issue for this.
```
