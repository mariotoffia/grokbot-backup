# W-2026-0013: why the Dependabot npm PRs #1456-#1463 fail Unit Tests

## Shared cause
Not a stale base and not the npm bumps. All 8 PRs are based on a361264bcd, which is current origin/main (checked 2026-11-05 07:00 CET). Main itself fails the same Unit Tests job at that commit: "Build and Test" push run 41906784761 fails Unit Tests with the same two Go tests. Main has been red since 3c56f00c66 (2026-11-04 15:11 CET); bdaaec495d (13:25 CET) was the last green.

Every failing Unit Tests run fails in the Go suite, in `go-core/cbanalytics/authoring`:
- `TestDesignSamplesAreTheDesignsText` (design_samples_test.go:327, "rule9_room_rate.rego: this paragraph is not in the design")
- `TestEveryDesignMonitorHasASample` (design_samples_test.go:363, "no design sample holds this block of the design")

#1461 and #1462 also hit a 600 s timeout in `go-services/eventsvc/deployment/features/alarm` (flaky/slow test, not npm related). The prettier/vitest/JS steps that ran before the Go suite passed. No lockfile or pnpm install errors.

Consequence: a combined PR will still show red Unit Tests until main's cbanalytics tests are fixed (out of scope; we keep off cbanalytics). The @hookform/resolvers 7 major is only proven by local gates.

| PR | Package | Head | Base = main? | Unit Tests run | Error |
|---|---|---|---|---|---|
| #1456 | eslint group 10.13.0→10.14.0 | b197f3f239 | yes | 41928238467 | 2 cbanalytics/authoring tests |
| #1457 | @testing-library/user-event 14.6.7→14.6.8 | 399c665698 | yes | 41928302446 | same |
| #1458 | @hookform/resolvers 6.0.2→7.0.1 (major) | 1cbc679b96 | yes | 41928370522 | same |
| #1459 | react-router 8.4.0→8.5.1 | ad6a23529b | yes | 41928452698 | same |
| #1460 | @dagrejs/dagre 3.1.1→3.1.3 | a60c0905b8 | yes | 41928573089 | same |
| #1461 | elkjs 0.12.0→0.12.1 | 3c18bfa14e | yes | 41928643172 | same + eventsvc alarm 600 s timeout |
| #1462 | globals 17.13.0→17.14.0 | 3f4c7d5158 | yes | 41928716656 | same + eventsvc alarm 600 s timeout |
| #1463 | react-hook-form 7.90.0→7.91.0 | 67b7567530 | yes | 41928848640 | same |
