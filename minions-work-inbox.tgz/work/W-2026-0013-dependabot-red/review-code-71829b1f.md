# Code review: PR #1465 @ 71829b1f (packet 1240, code-reviewer)

**Verdict: CHANGES REQUESTED** (one High finding: a required gate is missing. The code and lockfile are clean.)

Board: W-2026-0013 is on BOARD.md line 27 (GO by Mario). The PR title and commit subject are both `chore(deps): bump frontend dependencies`, with no W-/T- ID.

## 1. Bumps vs lock (all 8 match)
| package | from | to | lock-resolved |
|---|---|---|---|
| @hookform/resolvers | ^6.0.2 | ^7.0.1 | 7.0.2 |
| elkjs | ^0.12.0 | ^0.12.1 | 0.12.1 (0.9.3 transitive, unchanged) |
| react-hook-form | ^7.90.0 | ^7.91.0 | 7.91.0 |
| react-router | ^8.4.0 | ^8.5.1 | 8.5.1 |
| @testing-library/user-event | ^14.6.7 | ^14.6.8 | 14.6.8 |
| eslint | ^10.13.0 | ^10.14.0 | 10.14.0 |
| globals | ^17.12.0 | ^17.14.0 | 17.14.0 (was 17.13.0) |
| @dagrejs/dagre | ^3.1.1 | ^3.1.3 | 3.1.3 |

Note: resolvers resolves to 7.0.2 rather than 7.0.1. That is in range and is a patch fix for io-ts only.

## 2. Transitive majors
None. The only package outside the 8 targets that changed is @dagrejs/graphlib 4.0.5 -> 4.0.6, a patch pulled in by dagre. The only major jump is @hookform/resolvers 6 -> 7, which is a target bump.

## 3. @hookform/resolvers v7
The v7.0.0 notes list only one breaking change: the typebox resolver moves to `typebox` ^1 (and @sinclair/typebox is dropped from the peer deps). 7.0.1 and 7.0.2 are fluentvalidation and io-ts fixes. The only uses in the code are 3 imports of `zodResolver` from `@hookform/resolvers/zod` in cmd/tklocal/webui (LoginPage, AuthConfigPage, GlobalConfigPage), and that API is unchanged. Peer deps are met: react-hook-form ^7.55.0 is satisfied by 7.91.0, and zod ^3.25 || ^4 by 4.6.7. No code change is needed.

## 4. Gates
local-gates.txt shows rc=0 for: serial `pnpm -r build`, `make -C web lint`, `make -C web typecheck`, `pnpm -r test` (rc=1 on the first run from a flaky showcase timeout, then rc=0 on rerun), lint-arch, and `install --frozen-lockfile`. No ESLint boundaries plugin is configured in the web packages, so that part of lint does not apply.

PR CI: CodeQL and Analyze pass. Build, Unit Tests, Static Analysis and Architecture are skipping because the PR is a draft. Even after that is fixed, the approval would be conditional on CI. Dev-lead also notes that Unit Tests is red on main from cbanalytics, which is out of scope here.

Limits: I did not rerun any gates. This review is based on the logs and the diff.

## Findings
- **H1 (High): the required format gate was not run.** web/Makefile `fmt` (`pnpm run format`) does not appear in local-gates.txt or gates-full.log. The risk is small, because only package.json files and pnpm-lock changed. Fix: run `make -C web fmt` (or the format check) on 71829b1f, confirm there is no diff, and add the RC line to local-gates.txt. Once that passes, the verdict becomes APPROVED-conditional on CI.

No Medium findings.

## Re-check H1 (packet 1244)
- **PR head:** still 71829b1fe543fb3256d1071d1986356b2f07fc5f.
- **local-gates.txt line 10:** `fmt: make -C web fmt @71829b1f rc=0, no diff (git status clean). 2026-11-05 07:13 CET`.
- **My own check:** I ran `npx prettier@3.9.10 --check` (the version pinned in root package.json) with the repo's .prettierrc.json, which uses no plugins. It ran on the 71829b1f package.json files from web/design/{showcase,tokens,ui} and web/teos, plus cmd/tklocal/webui/package.json. Result: rc=0, "All matched files use Prettier code style!".
- **Not covered by `format`:** pnpm-lock.yaml and cmd/tklocal/webui/package.json fall outside the `format` globs (`web/**` and `cmd/tklocal/webui/src/**`). There were no source changes.
- **Limits:** I did not run a full-repo `pnpm run format:check`, because there are no node_modules on the box.

**H1 resolved. New verdict: APPROVED-conditional**, on CI Build, Unit Tests, Static Analysis and Architecture passing once the PR is ready for review. Unit Tests also depends on the separate cbanalytics fix on main.
