# Code review: PR #1394 at 9ebcab81 (packet 1132)

## Verdict: APPROVED, conditional on CI (Unit Tests pending)

No High or Medium findings.

### Scope
- Base: 26777a6e. Head: 9ebcab81. There are exactly 2 commits, touching 2 files (+1/-7):
  - **ea5f1655:** `iam/deployment/service-test/catalog_test.go` deletes the `if harness.Target().IsLocal() { t.Log(...) }` note at lines 81-84. It was log-only, so no test behaviour changes.
  - **9ebcab81:** the `gobridge/deployment/service-test/main_test.go` package doc comment now says "The same tests run on both targets". The change is comment-only.
- **Naming:** the title ("test: run the Floci-skipped tests on the local target"), the commit subjects and the diff have no W-/T- IDs.

### Gates
- fmt, generate, lint, lint-arch, vet, vet-e2e and the prereqs are rc=0.
- test-service-iam is rc=0. `--- PASS: TestCatalogPackDrivesNewClient (63.21s)`, and the iam package is ok.
- test-service-gobridge is rc=2 at deploy: `docker login ... dkr.ecr...localhost: EOF`. That's the known ECR TLS gap 39.21/39.22, and it's accepted because the gobridge change is comment-only.

### CI on 9ebcab81
- Pass: Architecture, CodeQL, Static Analysis, Analyze (actions), Analyze (javascript-typescript).
- Pending: Unit Tests.
- Skipping (label-gated): Build, GoBridge Docker integration.

### Sweep (not blocking)
- The only remaining `floci: Missing Implementation for` markers in code are the 3 kept on purpose: eventsvc alarm_stack_test.go:155, the eventsvc stack-policy scripts, and tklocal status_test.go:72.
- The other test `IsLocal()` branches are target plumbing (endpoints, CA, provision config) or have a stated reason (CloudWatch log latency on AWS: eventsvc alarm_stack:225, operator_commands:125, clwlog query_integration:46). None is an unskip leftover.
- The other `t.Skip` calls are short-mode/Docker, manual or TestConfigInEffect skips.
- Gobridge plan docs (PLAN-04:11636 and others) still describe the two old skips. Those are historical plan docs, not code.

### Limits
- Static review plus the owner's gate logs; I ran no tests.
- Board-only: I didn't look at cbanalytics.

## Delta 9ebcab81..1549d10d (packet 1136)

### Verdict: APPROVED, conditional on CI (Unit Tests and Static Analysis pending)

No High or Medium findings.

- **Delta:** 1 commit, 1549d10d "tklocal: run the device status test on Floci". 1 file, `tklocal/deployment/service-test/status_test.go` (+1/-8). It drops the `floci: Missing Implementation` comment and the `!IsLocal()` guard in `releaseStatus`.
- **Bounded wait:** `awaitStatus` is `require.EventuallyWithT(..., flowTimeout=2m, pollEvery=3s)` (flows_test.go:22-23). There's no `time.Sleep` in status_test.go or mqtt_test.go.
- **What it asserts:** the full check still runs. It reads the retained message via GetRetainedMessage and asserts rsid, clientId and status == "offline", then clears it.
- **On AWS:** unchanged, because that branch already called `awaitStatus(t, d, "offline")`.
- **Who calls it:** `releaseStatus` is called from the cleanup in `connectDevice` (mqtt_test.go:102), so every test that connects a device runs it.
- **Gate (test-service-tklocal-1549d10d…log):** rc=0 on Floci. `--- PASS: TestDeviceLogin (3.94s)` with both subtests, `--- PASS: TestPresenceReachesTheStatusTopic`, and the package is ok (243s). The log has 0 `--- SKIP` lines. The `.terminated.log` is an earlier aborted run, superseded by the full rc=0 run.
- **Naming:** no W-/T- IDs in the commit subject or comments.
- **Other gates:** fmt, lint, lint-arch, vet and vet-e2e are rc=0.
- **CI on 1549d10d:**
  - Pass: Architecture, CodeQL, Analyze (actions), Analyze (javascript-typescript).
  - Pending: Unit Tests, Static Analysis.
  - Skipping (label-gated): Build, GoBridge Docker integration.
- **Limits:** static review plus the owner's gate log; I ran no tests and used no AWS.
