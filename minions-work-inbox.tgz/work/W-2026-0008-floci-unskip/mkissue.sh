#!/bin/bash
# usage: mkissue.sh "<title>" <bodyfile> "<labels>"
set -euo pipefail
R=Thiink-LLC/teos
URL=$(gh issue create -R $R -t "$1" -F "$2" -a mariotoffia -l "$3" --type Task)
N=${URL##*/}; echo "issue $URL"
ID=$(gh issue view $N -R $R --json id -q .id)
gh api graphql -f query='mutation($i:ID!,$p:ID!,$s:ID!){setIssueFieldValue(input:{issueId:$i,issueFields:[{fieldId:"IFSS_kgDOAVq1qQ",singleSelectOptionId:$p},{fieldId:"IFSS_kgDOAsLCxw",singleSelectOptionId:$s}]}){clientMutationId}}' -f i=$ID -f p=IFSSO_kgDOAl6mDg -f s=IFSSO_kgDOBNUasQ >/dev/null
ITEM=$(gh project item-add 2 --owner Thiink-LLC --url $URL --format json -q .id)
gh project item-edit --project-id PVT_kwDOBoJzxs4BKY5X --id $ITEM --field-id PVTSSF_lADOBoJzxs4BKY5Xzg6RWQI --single-select-option-id 1f493ca5 >/dev/null
SPRINT=$(gh api graphql -f query='{node(id:"PVT_kwDOBoJzxs4BKY5X"){... on ProjectV2{field(name:"Sprint"){... on ProjectV2IterationField{configuration{iterations{id title startDate}}}}}}}' --jq '.data.node.field.configuration.iterations|sort_by(.startDate)|last|.id')
[ -n "$SPRINT" ] && gh project item-edit --project-id PVT_kwDOBoJzxs4BKY5X --id $ITEM --field-id PVTIF_lADOBoJzxs4BKY5Xzg7d7CM --iteration-id $SPRINT >/dev/null
gh issue view $N -R $R --json issueType,assignees,labels,projectItems -q '{type:.issueType.name,a:[.assignees[].login],l:[.labels[].name],p:.projectItems}'
gh api graphql -f query="{repository(owner:\"Thiink-LLC\",name:\"teos\"){issue(number:$N){issueFieldValues(first:10){nodes{... on IssueFieldSingleSelectValue{name field{... on IssueFieldSingleSelect{name}}}}}}}}" -q '.data.repository.issue.issueFieldValues.nodes'
