## Goal
Prove on the local target that `cbdeploy cfn stack delete` can get out of a stack delete that failed: when the stack is in DELETE_FAILED because a bucket still holds data, the retain hint names that bucket, and the delete run again with it retained removes the stack, keeps the bucket's data and removes the sibling bucket that was not retained.

## Acceptance
- A Floci-backed integration test (skipped under -short) drives RunCloudUndeploy in JSON mode through both deletes.
- It asserts DELETE_FAILED after the first delete, the retain hint, the stack gone after the second, the retained object intact, and the sibling bucket removed.
