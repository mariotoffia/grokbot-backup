#!/bin/bash
rc=0
for m in $(go work edit -json | python3 -c 'import json,sys;print("\n".join(u["DiskPath"] for u in json.load(sys.stdin)["Use"]))'); do
  echo "== $m"; (cd $m && go vet -tags e2e ./...) || { echo "FAIL $m"; rc=1; }
done
exit $rc
