Run every TEOS test that was skipped, or branched off, for Floci on the local target now that `mariotoffia/floci:latest` (sha256:357dd433…) covers the gaps behind it.

Groundzero tasks 27.18, 27.19, 27.26, 27.28, 27.30, 27.31 and 27.33 landed with #1343 (Refs #1341). This issue covers the sweep for what is left: stale local-only notes and branches in the service tests, and any skip that still names a Floci gap is either removed (gap fixed in the image) or kept with its gap written up.

Work item: W-2026-0008 (floci.unskip). Status: /workspace/minions/work/W-2026-0008-floci-unskip/STATUS.md
