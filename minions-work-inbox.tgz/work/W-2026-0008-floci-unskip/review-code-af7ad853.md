# Code review (KISS): PR #1397 at af7ad853 (id 1126)

Verdict: APPROVED conditional on CI. High/Medium findings: none.

- Scope: one commit, af7ad853 "cbdeploy: prove a retained bucket keeps its data through a stack delete"; one new file, go-services/appstore/cmd/cbdeploy/internal/cfn/cloud_undeploy_retain_integration_test.go (+143). No production code changed.
- TEOS behaviour: calls the production RunCloudUndeploy (cloud_undeploy.go:25) twice (:97, :109). It asserts the exact TEOS retain_hint text "Re-run with --retain Kept" (:106), which fails if the hint logic breaks or names Sibling, and that the retain retry succeeds and removes the stack (:109-113). Data survival and the sibling removal follow from the retain path.
- Cleanup: t.Cleanup closes a per-test Floci emulator (:56) that holds every stack and bucket, so nothing leaks even on failure. Names are unique by UnixNano (:54, :73-76).
- Tags and AWS: no build tag but a testing.Short skip (:44). This matches the repo's flocilocal convention (e.g. auth/integration_login_test.go:68), and unit targets run -short. The environment is forced onto the emulator endpoint and an empty profile and config (:61-71), so there's no path to real AWS.
- Waits: the SDK waiter is bounded at 3m (:87-89), the whole test at 10m (:50), and there are no sleeps.
- IDs: none in the title, commit subject or code.
- Gates: floci-cbdeploy-retain-af7ad853.log shows `--- PASS: TestUndeployRetainingTheStuckResourceKeepsItsData (14.25s)` (RUN, then PASS, not SKIP). The earlier .blocked.log run FAILed; it was superseded. unit-cbdeploy-cfn -short: ok.
- CI af7ad853: CodeQL, Architecture, Analyze (actions) and Analyze (javascript-typescript) pass; Static Analysis and Unit Tests pending; Build skipping.
- Limits: diff, grep and gate-log reads only, no rerun.
