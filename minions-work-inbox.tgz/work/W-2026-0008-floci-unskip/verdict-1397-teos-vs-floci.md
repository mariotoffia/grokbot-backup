# #1397 @2d55ca8b: does it test TEOS or Floci?

== Verdict ==
NO, mostly not Floci: (C) mixed, keep (trimmed). The TEOS retain-hint and RetainResources path has no other test, and the current Client cannot be faked cheaply.

== Evidence ==
Paths are under go-services/appstore/cmd/cbdeploy/internal/cfn/ at 2d55ca8b. T = cloud_undeploy_retain_integration_test.go.
1. Template: inline, the test's own (T:33-38: two AWS::S3::Bucket resources, no DeletionPolicy). The test creates it directly with the SDK (T:91-98), so it is not TEOS code. Stack setup, PutObject (T:100) and all checks use raw SDK clients (T:87-89).
2. TEOS code executed (RunCloudUndeploy is called twice, at T:106 and T:118):
   - cloud_undeploy.go:35 NewClient → cfn.go:57 (env and endpoint resolution).
   - :46 DescribeStack, and :57-70 batch_start/service_start events.
   - :119-124 the branch: retain non-empty → DeleteStackRetaining (cfn.go:487-496 passes RetainResources), otherwise DeleteStack (cfn.go:346).
   - :139 waitWithRetainRetry (:197-261): WaitForStackDeletion, then ListDeleteFailedResources (cfn.go:471-482 filters ResourceStatusDeleteFailed). Then diffStringSet against the retain set, and in JSON mode it emits retain_hint "Re-run with --retain "+ids (:222-231) and returns the error.
   - :162 forgetPendingScripts, and :164-176 service_complete/batch_complete success.
3. Assertion classes:
   - TEOS-decided: T:107 (the first call returns an error); T:115 (the hint text names exactly the DELETE_FAILED id "Kept", not "Sibling"); T:118 (the retained call reports success, which needs RetainResources to reach CFN).
   - CFN/Floci semantics: T:112 (DELETE_FAILED on a non-empty bucket); T:122 (the stack is gone); T:124-129 (the retained object survives); T:131-133 (the sibling is deleted). T:122 is only indirect evidence that TEOS passed RetainResources.
4a. TEOS breaks → this test fails:
   - Wrong or extra hint ids: T:115 fails.
   - RetainResources dropped (cfn.go:496 or the :120 branch): the second delete hits DELETE_FAILED again, so T:118 fails.
   - DELETE_FAILED handling removed (:208-231): T:114 fails with no retain_hint.
   Existing unit tests (cloud_undeploy_retain_test.go): TestMergeStringSet :13, TestDiffStringSet :39, TestPluralize :62, TestWaitForStackDeletionStopsWhenTheCommandIsCancelled :78. They cover only helpers and cancellation. No unit test references retain_hint, DeleteStackRetaining or ListDeleteFailedResources (git grep over go-services *_test, excluding T, returns nothing). A faked-client unit test would catch the same TEOS bugs, but Client wraps the concrete *cloudformation.Client (cfn.go:50-53) with no interface. A fake would need an httptest CFN server or a refactor, so it is not "simple" today.
4b. Floci breaks: T:98/T:112 (create, DELETE_FAILED), T:122, T:125/129 and T:133 fail. A Floci break can then cascade into T:114/115/118 (no DELETE_FAILED means no hint), which is a false red against TEOS.

== Rationale ==
Mario's suspicion is half right. 4 of the 7 meaningful assertions (T:112, 122, 124-129, 131-133) only check that Floci emulates CFN/S3, and the template is the test's own, so those parts are Floci tests. Our earlier APPROVED framed them as proving "TEOS retain behaviour", which overstated it. That was wrong framing, though the test was not wrong to exist.
The remaining 3 (T:107, 115, 118) check TEOS decisions that nothing else tests: which ids go in the hint, that the retain list reaches DeleteStack, and the success reporting. Deleting the test outright loses that coverage.
KISS options, in order:
(1) Keep it and drop T:124-133, with an optional drop of T:112/T:122 to a require only. That leaves a TEOS-focused integration test.
(2) Replace it with a unit test after adding a small CFN API interface to Client, or with an httptest fake. Then delete the test. That costs more code.
Do not delete it with no replacement.
