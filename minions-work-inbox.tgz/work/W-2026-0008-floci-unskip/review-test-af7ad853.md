== Verdict ==
APPROVED af7ad853ba26715bc0afb2b300ab586a96540994

== Findings ==
none

== Rationale ==
- Tests teos, not Floci: Floci only hosts the stack. The test calls teos RunCloudUndeploy twice: in JSON mode with no retain, then with retain=[Kept]. It asserts the retain_hint event that cloud_undeploy.go:226-229 builds from ListDeleteFailedResources, and that the retry succeeds.
- Assertions: the hint must equal exactly "Re-run with --retain Kept" (line 106), so Sibling cannot appear. DELETE_FAILED is checked through DescribeStacks before the retry (103). Absence after the retry is DescribeStacks returning an error (113), which is real absence, not a status string. The retained object is read back and compared to "keep me" (115-120). HeadBucket on Sibling must error (122-123). Lines 113/123 accept any error rather than a typed not-found, but the emulator answered GetObject in between, so a false pass is not credible. Not a Medium.
- Cleanup and isolation: t.Cleanup closes the per-test Floci container, so the in-memory storage, including the retained bucket, goes with it and runs on failure too. Names are UnixNano-unique. The testing.Short() skip matches the repo's other Floci integration tests, and the unit gate (-short) does not run it.
- Determinism: the create uses an SDK waiter bounded at 3m, everything sits under a 10m context, and there are no bare sleeps or order dependence.
- Evidence: the floci log (15:30 CET) shows `=== RUN` / `--- PASS` (14.25s), not skipped, rc=0. The .blocked.log (15:23 CET) is rc=1 from before the networking fix: Floci never became ready because its DynamoDB Local sidecar was unreachable after 30s (an environment problem, not the test). unit-cbdeploy-cfn, lint, lint-arch, vet, vet-e2e and fmt are all rc=0.

## Delta (af7ad853..2d55ca8b) — r2

== Verdict ==
APPROVED 2d55ca8b4afb297c51bc32e93f55fe11be43915f

== Findings ==
none

== Rationale ==
- Diff (gh compare): one file, cloud_undeploy_retain_integration_test.go, +12/-2. It adds the errors and s3types imports, a comment, and four t.Setenv lines (AWS_ENDPOINT_URL_{CLOUDFORMATION,S3,SSM} = the Floci endpoint, AWS_IGNORE_CONFIGURED_ENDPOINT_URLS=false). It changes require.Error to require.ErrorContains(err, "does not exist") on DescribeStacks, and assert.Error to errors.As(err, *s3types.NotFound) on HeadBucket. Nothing else changed.
- TEOS retain behaviour: as in the af7ad853 review, the retain_hint, the second-delete success and the GetObject "keep me" assertions are unchanged. The two tightened checks are stricter, so they still prove that the stack is gone and the non-retained bucket was removed. An unrelated error such as a wrong endpoint or auth failure can no longer pass them.
- Floci compatibility, proven by a run: gates/floci-cbdeploy-retain-2d55ca8b….log (16:25 CET) ran without -short, `-run TestUndeployRetainingTheStuckResourceKeepsItsData`, and got `--- PASS (16.20s)`, ok, rc=0. Both tightened asserts ran against real Floci and passed, so Floci returns a "does not exist" ValidationError and a HeadBucket 404 that SDK v2 maps to *s3types.NotFound. The S3 check uses HeadBucket, and HeadBucket returns only NotFound (no NoSuchBucket body), so the single type is the right one.
- Env isolation: every pin uses t.Setenv, which is restored at test end and blocks t.Parallel, so nothing leaks.
- CI at 2d55ca8b: Static Analysis, Unit Tests, Architecture, CodeQL Analyze, Lint, Build and Test and ArchLint all succeeded. The cited runs 41321289956, 41321289974 and 41321290036 are completed/success with headSha 2d55ca8b. Unit Tests did not exercise this test: it uses testing.Short() and t.Skip at lines 46-47, and the local unit gate runs `go test -short` (rc=0). The Floci gate above is the only proof that the test passes.
- Local gates at 2d55ca8b: fmt, lint, lint-arch, unit-cbdeploy-cfn and floci-cbdeploy-retain are all rc=0.

## Delta (2d55ca8b..e1b3dafc) — r3

== Verdict ==
APPROVED e1b3dafc7103340c74bb45a38cb3a2ef846eea53

== Findings ==
none

== Rationale ==
- Diff (gh compare): one file, +4/-20. It removes the errors, io and s3types imports, the post-retry DescribeStacks "does not exist", GetObject "keep me" and HeadBucket NotFound asserts, and rewrites the doc comment to "checks only what TEOS decides". The DELETE_FAILED require gains the message "precondition: the stack is stuck in DELETE_FAILED". Nothing else changed.
- No Floci-only claims remain. The inline template, CreateStack/waiter and PutObject are setup, and the DELETE_FAILED check is now labelled a precondition (a require, so it fails fast at setup).
- The TEOS asserts are intact and exact: require.Error on the first RunCloudUndeploy; require.Equal "Re-run with --retain Kept" (an exact string, so an extra id such as Sibling fails); require.NoError on RunCloudUndeploy(..., []string{"Kept"}, ...), whose non-empty retain list takes the DeleteStackRetaining → RetainResources branch (cloud_undeploy.go:120-121, cfn.go:496).
- Cleanup and skip are unchanged: the testing.Short() skip, t.Cleanup(local.Close) and the t.Setenv pins. kept and sibling are still used by the template and PutObject, and vet is rc=0.
- Gates at e1b3dafc: floci-cbdeploy-retain (20:51 CET, no -short) shows RUN and `--- PASS (15.65s)`, ok 16.037s, rc=0. fmt, vet, lint and lint-arch are all rc=0. None are missing.
