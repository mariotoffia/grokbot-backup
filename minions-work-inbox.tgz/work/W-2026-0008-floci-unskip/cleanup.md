# W-2026-0008 cleanup (2026-11-01 22:35:45 CET, dev-lead 1150)

Pre-check: no go/golangci/make/cbdeploy/run.sh processes; no docker containers running. Inodes before: 50%

## .worktrees/W-2026-0008 (PR #1394 MERGED 3b791a85)
- dirty files: 0
- worktree removed
- local branch minion/W-2026-0008 deleted (was 98c8c9b4)
- remote branch: already auto-deleted

## .worktrees/W-2026-0008-retain (PR #1397 MERGED c59282a1)
- dirty files: 0
- worktree removed
- local branch minion/W-2026-0008-retain deleted (was e1b3dafc)
- remote branch: already auto-deleted

## make clean-caches (sg docker, no FORCE)
- rc=0
- inodes after: 27%
```
----> Cleaning Go test caches across all go.work modules...
----> Removing cmd/tklocal/webui/.vite
----> Cleaning Go build cache /home/box/.cache/go-build (go clean -cache -fuzzcache)
----> Cleaning Go module cache (go clean -modcache)
----> Cleaning golangci-lint cache (golangci-lint cache clean)
----> Removing unused unnamed Docker volumes
Total reclaimed space: 1.479GB
----> Removing the Docker build cache
Total reclaimed space: 0B
----> Removing untagged Docker images
Total reclaimed space: 0B
```

## Remaining git worktree list
```
/workspace/repos/teos                                                                    5d9346b5 [main]
/workspace/repos/teos/.worktrees/W-2026-0006-funcs.merge                                 cac54b8d [minion/W-2026-0006-funcs.merge]
/workspace/repos/teos/.worktrees/W-2026-0006-package.isolate                             d4614efe [minion/W-2026-0006-package.isolate]
/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime  376519e6 [chore/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime]
```
