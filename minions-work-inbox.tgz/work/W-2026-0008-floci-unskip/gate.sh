#!/bin/bash
# usage: gate.sh <name> <command...>   (run from worktree)
G=/workspace/minions/work/W-2026-0008-floci-unskip/gates
SHA=$(git rev-parse HEAD); n=$1; shift
L=$G/$n-$SHA.log
{ echo "# sha=$SHA cmd=$* date=$(date -Iseconds) $(grep SigIgn /proc/self/status)"; "$@" 2>&1; echo "rc=$?"; } > $L 2>&1
echo "$n: $(tail -1 $L) $L"
