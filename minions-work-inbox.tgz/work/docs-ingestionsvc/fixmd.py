import sys,re,textwrap
def cells(r): return [c.strip() for c in r.strip().strip('|').split('|')]
def wrap(text, first, rest):
    # avoid breaking inside backticks: textwrap on words; tokens with spaces in code are rare
    return textwrap.wrap(text, 80, initial_indent=first, subsequent_indent=rest, break_long_words=False, break_on_hyphens=False)
for p in sys.argv[1:]:
    L=open(p).read().split('\n'); out=[]; i=0
    while i<len(L):
        l=L[i]
        if l.startswith('<!-- cspell:words') and len(l)>80:
            ws=l[len('<!-- cspell:words '):-len(' -->')].split()
            chunk=[]
            for w in ws:
                if len(' '.join(chunk+[w]))>55: out.append('<!-- cspell:words '+' '.join(chunk)+' -->'); chunk=[]
                chunk.append(w)
            out.append('<!-- cspell:words '+' '.join(chunk)+' -->'); i+=1; continue
        if l.startswith('|') and i+1<len(L) and re.match(r'^\|[-| :]+\|$',L[i+1]):
            j=i; rows=[]
            while j<len(L) and L[j].startswith('|'): rows.append(L[j]); j+=1
            hdr=cells(rows[0]); body=[cells(r) for r in rows[2:]]
            fmt=['| '+' | '.join(hdr)+' |','| '+' | '.join(['---']*len(hdr))+' |']+['| '+' | '.join(r)+' |' for r in body]
            if max(len(x) for x in fmt)<=80: out+=fmt
            else:
                for r in body:
                    head='**'+r[0]+'**' if not r[0].startswith('[') else r[0]
                    parts=[f'{hdr[k].lower()}: {r[k]}' if k>1 or len(hdr)>2 else r[k] for k in range(1,len(r)) if r[k]]
                    if len(hdr)==2: text=head+': '+r[1]
                    else: text=head+': '+'; '.join(parts)+'.' if parts else head
                    text=text.replace('..','.')
                    out+=wrap(text,'- ','  ')
            i=j; continue
        out.append(l); i+=1
    open(p,'w').write('\n'.join(out))
