# Post-merge cleanup W-2026-0013 (packet dev-lead 1248) — 2026-11-05 07:28 CET
## PR
#1465 MERGED 2026-11-05 07:20 CET, head minion/W-2026-0013 @71829b1f (matches local), merge 83235b54
## Removed
- worktree .worktrees/W-2026-0013 (clean status, no process cwd) via git worktree remove
- branch: warning: deleting branch 'minion/W-2026-0013' that has been merged to
         'refs/remotes/origin/minion/W-2026-0013', but not yet merged to HEAD
Deleted branch minion/W-2026-0013 (was 71829b1fe).
## Remote
origin/minion/W-2026-0013 gone (auto-deleted); nothing deleted remotely.
## Skipped
None.
## Pre-check
ps filter: no matches. docker ps: no containers.
## clean-caches
rc=0 (clean-caches.log)
Before:
Filesystem      Inodes  IUsed   IFree IUse% Mounted on
/dev/vdb       2097152 682997 1414155   33% /
Filesystem      Size  Used Avail Use% Mounted on
/dev/vdb        128G   25G  103G  20% /
After:
Filesystem      Inodes  IUsed   IFree IUse% Mounted on
/dev/vdb       2097152 580204 1516948   28% /
Filesystem      Size  Used Avail Use% Mounted on
/dev/vdb        128G   20G  109G  16% /
## Final git worktree list
/workspace/repos/teos                                                                    5d9346b57 [main]
/workspace/repos/teos/.worktrees/W-2026-0006-funcs.merge                                 d93166d19 [minion/W-2026-0006-funcs.merge]
/workspace/repos/teos/.worktrees/W-2026-0006-package.isolate                             047c8990d [minion/W-2026-0006-package.isolate]
/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime  376519e64 [chore/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime]
