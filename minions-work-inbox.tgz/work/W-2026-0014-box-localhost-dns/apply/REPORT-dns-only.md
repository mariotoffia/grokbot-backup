# W-2026-0014 DNS-only apply (Europe/Stockholm)

Mario (10:58 CET): "yes to dns-only sudo". Did **not** run machine-setup.sh / apt / edit box-env-restore.

## Worktree
- `/workspace/repos/teos/.worktrees/W-2026-0014-apply` detached @ `654925ae6` (#1467; already latest origin/main after fetch)

## DNS apply
| run | log | rc | key lines | stub pid | dockerd | containers |
|---|---|---|---|---|---|---|
| 1 | `dns-run1.log` | 0 | CHANGE install BIN; CHANGE start stub; CHANGE write resolv; OK localhost DNS | 1608401 | 22575 | empty unchanged |
| 2 | `dns-run2.log` | 0 | OK stub on 127.0.0.53 (upstream 10.0.0.2); **no ` CHANGE ` lines** | 1608401 (same) | 22575 | empty unchanged |

Script stayed DNS-only (no docker/daemon.json mentions in CHANGE sense).

## Final /etc/resolv.conf
```
nameserver 127.0.0.53
nameserver 10.0.0.2
options timeout:1
```

## Checks
| # | result | log |
|---|---|---|
| 0 | PASS — foo.localhost / x.localhost.floci.io / api.auth.sso1.localhost.floci.io → `::1`; example.com → `198.18.0.1` (egress unchanged) | `check0-dns.log` |
| 1 | PASS — TestSSOLoginAgainstTheLocalEmulator (+ refresh/logout) ~9s under `sg docker` + cbtest local exec | `check1-sso.log` rc=0 |
| 2 | PASS — Resolve / Reach / Certificate / TokenEndpoint ~75s (svctest unique teos-1659005-784981) | `check2-groundzero.log` rc=0 |

Floci names were unique (cbdeploy-sso-$nano / teos-$pid-$id); TestMain/cleanup removed them; no leftover containers. Only cleaned what we started (none left).

## Persistence note (unchanged; not edited)
box-env-restore still does not restart the stub; after box reboot re-run `localhost-dns.sh` or add the previously reported line.
