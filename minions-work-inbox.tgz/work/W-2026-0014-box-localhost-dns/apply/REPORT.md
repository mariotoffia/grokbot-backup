# W-2026-0014 box-ops apply report (Europe/Stockholm)

## Step 1 — checkout
- Main `/workspace/repos/teos` is on `main` but **dirty** (deleted noda webui dist assets) and was behind origin → **not touched**.
- Used: `git worktree add .../W-2026-0014-apply origin/main --detach`
- HEAD: `654925ae6 build: replace box dnsmasq with localhost DNS stub (#1467)`
- Confirmed: `scripts/grokbot/localhost-dns.sh`, `localdns.py`, `machine-setup.sh` present.

## Step 2 — baseline (`apply/baseline.log`)
- `docker ps`: **empty** (no running containers)
- dockerd pid: **22575**
- `/etc/docker/daemon.json`: **missing**
- `/etc/resolv.conf`: `nameserver 10.0.0.2`
- `getent hosts`: `foo.localhost`, `api.auth.sso1.localhost.floci.io`, `example.com` all → **198.18.0.1**
- python3/make/gcc present (`Python 3.13.5`)

## Step 3 — `--check` (`apply/check.log`, rc=**3**)
- Ran: `bash scripts/grokbot/machine-setup.sh --check` from the apply worktree (script sudo's itself; --check made no changes).
- Key lines:
  - `WOULD-CHANGE apt packages (...)`
  - `WOULD-CHANGE localhost DNS stub (...)`
  - `OK docker engine` (static 29.9.2 recognized; will **not** reinstall)
  - `OK dockerd running`
  - `WOULD-CHANGE /etc/docker/daemon.json ... (restarts dockerd on change)`
  - SUMMARY `would-change=10`
- Containers running: **0** → daemon.json restart is **allowed** (rule is only STOP while containers run).
- **Apt abort analysis**:
  - `apt-get update` probe rc=**100** (`apply/apt-update-probe.log`): HTTP 500 from `198.18.0.1` for deb.debian.org; repos "not signed".
  - Missing: build-essential, git-lfs, zip, zsh, lsof, upx-ucl, nsis, asciidoctor, restic, bind9-dnsutils (`apply/blocker-state.log`).
  - In script: apt is hard `step` (not `soft_step`); on apply failure → restore + **`exit 1`**.
  - DNS step is **immediately after** apt → **never reached** if apt fails.
  - Documented CLI: only `[--check]`. No FORCE, no step filter, no SKIP. GROKBOT.md / README do not document a partial machine-setup run.
  - `localhost-dns.sh` is a separate documented helper, but Mario approved **`machine-setup.sh`**; task says do not hack around apt abort → **did not** run DNS alone.

## Step 4 — apply
- **NOT RUN** (BLOCKED). No `run1.log` / `run2.log`.
- dockerd pid unchanged: still **22575**. Container list unchanged: still empty.

## Step 5 — verify checks 0–2
- **Not run** (DNS not applied). Baseline shows check 0 would currently fail (198.18).
- `repair_dead_loopback_resolv`: **verified by reading**. Triggers only when every nameserver is loopback **and** nothing listens on UDP/53; then rewrites resolv to `10.0.0.2`. Current resolv has `10.0.0.2` → would no-op. Did not kill stub to exercise (no stub running).

## Step 6 — restart persistence
- `/workspace/minions/box-env-restore.sh` ≡ `/usr/local/sbin/box-env-restore.sh` (identical).
- Restore covers docker/dockerd/binfmt/floci/nvm — **no** localdns / resolv / box-localdns.
- `machine-setup.sh` / `localhost-dns.sh` **do** restart the stub on rerun after reboot (GROKBOT.md: "Run the script again"), but nothing auto-invokes them at boot (no systemd).
- **Exact line needed** (NOT added): after dockerd restore block in `box-env-restore.sh`, e.g.
  ```bash
  if [ -x /usr/local/sbin/box-localdns.py ]; then
    if ! pgrep -f '/usr/local/sbin/box-localdns.py' >/dev/null; then
      sudo sh -c 'nohup python3 /usr/local/sbin/box-localdns.py 127.0.0.53 53 10.0.0.2 >>/var/log/box-localdns.log 2>&1 & echo $! >/run/box-localdns.pid'
    fi
  fi
  ```
  Or, once teos main has #1467: `bash /workspace/repos/teos/scripts/grokbot/localhost-dns.sh` (idempotent; prefers that over hand-rolled nohup).

## BLOCKED — exact state
- Cannot safely/usefully run `sudo scripts/grokbot/machine-setup.sh` because apt step will fail (proxy 500) and abort before DNS.
- Docker/daemon.json side was idle-safe; not the blocker.
- Need: apt egress fixed, **or** Mario/docs allow running `scripts/grokbot/localhost-dns.sh` alone (and optionally daemon.json when idle), then re-verify 0–2.
