# Test review delta: PR #1467 babc29b4..fa08bb41 (packet 1269)

== Verdict ==
APPROVED. No High or Medium findings.

== Findings ==
None at High/Medium.

== Rationale ==
- What changed in the script: state_ok now also needs `cmp -s SRC BIN` (localhost-dns.sh:222-223), so an updated source no longer exits early as OK. apply_state restarts the stub whenever it just installed a new binary (:236-252).
- The new test case (localhost-dns_test.sh:137-175) runs on a writable copy of the source, so the repo is untouched. First, an identical copy must be a no-op with no ` CHANGE ` line, which keeps the rerun guarantee. Then the copy is bumped, and the test asserts the install and "start stub" lines, a new pid, BIN matching the new source, the new process's /proc cmdline pointing at BIN, and the old pid gone. These are the script's own decisions: reinstall on drift, and restart after a reinstall.
- The red run is real. restart-red.mutation.diff restores the old "restart only if unhealthy" branch. The log fails exactly the 3 restart asserts ("start stub" missing, pid unchanged, old stub still running), and the install asserts still pass, as they should.
- The state_ok cmp change has no red run of its own. Without it the script would exit OK before installing, and "install after SRC change" and "BIN matches new SRC" would fail, so the asserts already cover it. Not blocking.
- I reran it green myself at fa08bb41 from a path-limited scratch copy (`git archive` of scripts/grokbot): 33 PASS, ALL PASSED, rc=0. The scratch copy has been removed.
