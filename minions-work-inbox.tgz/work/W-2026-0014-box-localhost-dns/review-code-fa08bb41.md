# Code review: PR #1467 at fa08bb41 (packet 1268, W-2026-0014) — re-check M1

Delta reviewed: `3829ebd4..fa08bb41`
- `babc29b43` test: assert localhost DNS rerun changes nothing
- `fa08bb410` fix: restart localhost DNS stub when it is updated

Head confirmed via `gh`: fa08bb4101d1340f6204f94b81d5da4bed2e92e7.

## Verdict: APPROVED

M1 is fixed. Local gates at fa08bb41 are green. No new High or Medium findings. Under Mario’s cost rule, local gates stand in for the label-gated CI jobs, so approval does not wait on them. Commit subjects have no W-/T- prefix.

### M1 resolution
In `scripts/grokbot/localhost-dns.sh` `apply_state`:
- `installed=0`, then set to `1` when the install path runs (`! stub_installed` or `cmp` differs).
- Restart condition is now: `if [ "$installed" = 1 ] || ! stub_running || ! stub_answers; then stop_stub; start_stub; else OK`.
- Restart is skipped only when the binary was already identical and the process is healthy.
- `state_ok` also requires `cmp -s "$SRC" "$BIN"`, so a stale binary keeps the step pending.

### Edge cases checked (static)
- **start fails after stop:** `set -euo pipefail` makes a failed `start_stub` abort `apply_state` and the script with a non-zero status, so the error surfaces. On an update, resolv.conf is already the stub + `10.0.0.2` + `timeout:1`, so other names still fall back to `10.0.0.2` after the timeout while the stub is down.
- **pidfile:** `stop_stub` clears the pidfile and orphans for `$BIN`; `start_stub` writes a new one. `is_our_pid` rejects stale pids.
- **set -e in `if` tests:** the `installed` / `stub_running` / `stub_answers` condition is in an `if`, so a non-zero status there does not abort the script.

### Test coverage and red proof
New section `== updated stub source restarts the process ==` bumps a writable SRC copy, then asserts install + start, pid change, BIN matches SRC, new cmdline points at BIN, and the old pid is gone. The stronger idempotent-rerun checks (pidfile / mtimes / no CHANGE) are also in the delta.

Owner red proof (`gates/localhost-dns_test.restart-red.log` + mutation.diff): with the pre-fix branch restored, FAILED=3 (no "start stub", pid unchanged, old stub still running). `green-after-revert` and `localhost-dns_test.log` are ALL PASSED.

I re-ran `localhost-dns_test.sh` in a scratch dir at fa08bb41: ALL PASSED, exit 0.

### Gates at fa08bb41
| Gate | Evidence |
|---|---|
| localhost-dns_test | ALL PASSED (`localhost-dns_test.log`, green-after-revert) |
| restart red proof | FAILED=3 on mutated old code |
| bash -n | OK (`localhost-dns.bash-n.log`) |
| py_compile | empty success log; I re-ran `python3 -m py_compile` on the scratch copy, exit 0 |
| shellcheck | empty success log at 09:54; earlier `gates/shellcheck.log` at 09:52 was OK for all three scripts. `shellcheck` is not on PATH in this review shell, so I relied on the owner logs plus my own test/py_compile/bash -n runs |

### New H/M in the delta
None.

### Limits
- Read-only plus scratch-dir test / py_compile / bash -n. No `machine-setup.sh` (including `--check`), no sudo, no docker, no system DNS changes, no GitHub writes.
- shellcheck binary was unavailable in this shell; owner gate logs used for that check.
