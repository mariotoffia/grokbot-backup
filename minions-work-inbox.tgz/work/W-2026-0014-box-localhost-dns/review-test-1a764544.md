# Test review delta: PR #1467 04f51114..1a764544 (packet 1275)

== Verdict ==
CHANGES REQUESTED. One Medium is still open, part (1). Parts (2) and (3) are fixed.

== Findings ==
- [Medium] The rollback test can't catch the orphan it checks for, and the script really does leave one. localhost-dns_test.sh:181 uses a bad source that runs `sys.exit(1)`. That process is already gone before the orphan loop runs (:209-220), so "no failed or orphan BIN process left" passes whatever the script does. On rollback, apply_state (localhost-dns.sh:266-271) moves `${BIN}.prev` back and calls start_stub without first stopping the failed new process. I swapped the bad source for one that runs but never answers (`import time; time.sleep(600)`) in a scratch copy at 1a764544. The test then fails: `FAIL orphan process still running (pid 1560380)`, FAILED=1. That's the same case I asked to be asserted in r1 (1272-r item 1). On the real box such a process may hold :53, so the restored stub fails to bind and DNS stays down. Fix: make the test's bad source hang instead of exiting; the current code is then the red. Then add a stop_stub before the restore in the script, which makes it green. Keep the exit(1) case if you like, but the hang case is the one that guards this decision.

== Rationale ==
- (2) Foreign resolv.conf is fixed. The test writes `nameserver 1.1.1.1` before the remove apply, then asserts the `left unchanged` line and that the file is byte-identical. The red (unconditional restore) fails both asserts (FAILED=2), and the "ours" remove case still asserts the restore after a re-install.
- (3) is_our_pid is fixed. A `vim`-named `tail -f $BIN` with its pid in the pidfile must survive apply. The red (old loose grep) fails exactly "fake editor pid was killed by apply" (FAILED=1). The test kills it again in cleanup. Its --check assert doesn't tell the old and new code apart (WOULD-CHANGE either way, because the stub doesn't answer), but the kill assert does, so that's fine.
- The rollback red (drop the restore) fails the 4 restore asserts, which is real for the restore itself.
- Green: I reran it at 1a764544 from a path-limited scratch copy, 53 PASS, ALL PASSED, rc=0. I removed the scratch copy, and no stub processes are left over.
