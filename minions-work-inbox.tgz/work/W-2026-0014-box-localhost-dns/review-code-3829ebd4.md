# Code review: PR #1467 at 3829ebd4 (packet 1263, W-2026-0014)

Board: BOARD.md:24 `teos.box.localhost-dns` (W-2026-0014 / PR #1467, GO by Mario) is on the board.

## Verdict: CHANGES REQUESTED

One Medium finding. No High. Fix M1, then this becomes APPROVED-conditional on the label-gated CI jobs (Build, Unit Tests, Static Analysis, Architecture) once the draft is ready. Do not add labels.

### M1: updated stub binary is not loaded (localhost-dns.sh ~apply_state)
- **Where:** `scripts/grokbot/localhost-dns.sh` in `apply_state`, the block that installs then starts the stub (the `cmp -s "$SRC" "$BIN"` / `stub_running && stub_answers` sequence).
- **Problem:** when `$SRC` differs from `$BIN`, the script installs the new file and then, if the old process is still running and answering, logs OK and leaves that process alone. The new code never runs until the process dies or something else restarts it. That breaks Mario’s inspect-then-change rule: the running stub still differs from the installed binary.
- **Why it matters:** a later fix to `localdns.py` followed by a normal `machine-setup.sh` rerun would look green while the box kept answering with the old stub.
- **Fix:** if the install path ran (cmp failed or binary was missing), force `stop_stub` then `start_stub` even when the old process still answers. Only skip the restart when the binary was already identical and the process is healthy.

### Mario’s requirements
| Req | Result |
|---|---|
| (a) Inspect first; change only what differs; safe to rerun | Met for DNS and Docker, except M1 on stub binary updates. `localhost-dns.sh` and the `step` helper check before apply. |
| (b) Skip or remove stub when host already resolves *.localhost to loopback | Met. `host_localhost_ok` probes upstream `10.0.0.2` (or `LOCALDNS_PROBE` in tests). Skip / remove branches are covered by `localhost-dns_test.sh`. |
| (c) No dockerd restart / daemon.json rewrite when already correct | Met. `check_daemon_json` is semantic via `jq` (`.group == "docker" and ((.dns // null) == null)`), so key order and extra whitespace do not force a rewrite. Apply runs only when the check fails, refuses to restart while containers are running, and defers in that case. No `dns` key is written. |
| (d) KISS | Met. Stdlib UDP stub, small shell wrapper, fixed three-line resolv.conf, no systemd. |

### Other review notes (not findings)
- **localdns.py matching / answers:** `localhost` and `localhost.floci.io` exact or as a suffix. A → `127.0.0.1`, AAAA → `::1`. Other names are relayed byte-for-byte to `10.0.0.2`. Static check of the matcher (7 cases) passed; no privileged bind.
- **Stub death / fallback:** resolv.conf is stub first, then `10.0.0.2`, with `options timeout:1`. Other names fall back after the timeout. There is no supervisor (box has no systemd); reboot / next script run restarts a missing stub when resolv is still ours. That matches GROKBOT.md.
- **Other DNS:** while the stub is up, non-local queries are relayed upstream. Docker is not pointed at the stub (`daemon.json` has no `dns` key), so containers keep `10.0.0.2`.
- **Ports / privileges / races:** listen defaults to `127.0.0.53:53` (needs root; tests use a high port). Pidfile checks `/proc/.../cmdline` via `is_our_pid`. `stop_stub` clears the pidfile and orphans for the same binary. Rerun leaves a healthy stub alone (aside from M1).
- **Shell:** `set -euo pipefail` on the new scripts; inspect-before-change is consistent; shellcheck and `bash -n` are clean in the owner gates.
- **Naming:** title and commit subject are `build: replace box dnsmasq with localhost DNS stub` (no W-/T- prefix).

### Gates (`gates/`)
| Gate | Result |
|---|---|
| `localhost-dns_test.sh` | ALL PASSED (also re-run by me in a scratch dir, exit 0) |
| Red proof | FAILED=7 with forced probe fail; green after revert |
| shellcheck -x on the three shell scripts | OK |
| `python3 -m py_compile localdns.py` | OK |
| `bash -n` on the three scripts | OK |
| `machine-setup.sh --check` (owner only) | exit 3, would-change includes localhost DNS; no apply |

I did not run `machine-setup.sh` (including `--check`), any make setup target, sudo, docker, or real DNS changes.

### CI (`gh pr checks 1467`)
- Pass: CodeQL, Analyze (actions), Analyze (javascript-typescript).
- Skipping on draft: Build, Unit Tests, Static Analysis, Architecture.

### Limits
- Read-only review plus a scratch-dir run of `localhost-dns_test.sh` and a pure-Python matcher / `py_compile` check. No bind on port 53, no system DNS changes, no machine-setup, no docker.
- I did not review whether an old dnsmasq left by a previous script version is still installed as a package; the new stub listens on `127.0.0.53`, and resolv is rewritten away from `127.0.0.1`, so a leftover dnsmasq would be unused.
