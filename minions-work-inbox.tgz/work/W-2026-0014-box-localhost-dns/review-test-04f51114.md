# Test review delta: PR #1467 fa08bb41..04f51114 (packet 1272)

== Verdict ==
CHANGES REQUESTED. One Medium.

== Findings ==
- [Medium] The Copilot fix added three decisions to scripts/grokbot/localhost-dns.sh, and localhost-dns_test.sh has no test for any of them. The test file is unchanged in this delta. The existing cases only take the happy path through each one, so a broken version of any of them still passes (the green copilot-fix.log shows exactly that). All three can be tested without sudo in the current temp-dir setup, and each needs its own red run:
  1. Rollback to `${BIN}.prev` after a failed start (:264-276). Nothing makes a start fail. Test: after the restart case, write a source that exits at once (e.g. `import sys; sys.exit(1)`), then apply. Assert the `restore previous stub` line, that BIN matches the previous good copy, and that the stub still answers foo.localhost. Red: drop the restore branch. Also assert that the failed new process isn't left running: the restore calls start_stub with no stop_stub, so a new binary that started but never answered would stay behind as an orphan.
  2. remove_stub leaves a foreign resolv.conf alone (:221-227). The remove case only covers "resolv is ours, so restore it". Test: in that case, write something else (e.g. `nameserver 1.1.1.1`) to resolv.conf before the apply, then assert it is byte-identical afterwards and the `left unchanged` line appears. Red: call restore_resolv unconditionally.
  3. is_our_pid rejects a process that only mentions $BIN in its argv (:100-113). This guards against killing the wrong process, and only the accept path is covered. Test: start a non-python process with $BIN in its argv (e.g. `bash -c 'exec -a vim sleep 300' x "$LOCALDNS_BIN" &`), put its pid in the pidfile, run --check, and assert the stub doesn't count as running (WOULD-CHANGE). After an apply, assert `kill -0` on that pid still succeeds. Red: put back the old `grep box-localdns.py` match.

== Rationale ==
- The existing asserts still cover what they covered before: install, restart on change, an unchanged rerun, and removal (copilot-fix.log ALL PASSED). The exact python-plus-$BIN match still accepts the real stub, since the rerun pid check and the restart cmdline check pass.
- Not blocking: repair_dead_loopback_resolv in machine-setup.sh (:225-251) rewrites the real /etc/resolv.conf with sudo and `ss`, the same as the daemon.json path. Same treatment (KISS, no new harness): verify it on the box sudo run. With resolv.conf holding only a dead loopback nameserver, one run must log `repair` and leave `nameserver 10.0.0.2`. With our three-line body (a non-loopback entry present), it must change nothing.
