# Test review delta: PR #1467 1a764544..1b4df42e (packet 1278)

== Verdict ==
APPROVED. Medium (1), the rollback orphan, is fixed, and there are no new High or Medium findings.

== Findings ==
None at High/Medium.

== Rationale ==
- The test (localhost-dns_test.sh:182) now uses a bad source that hangs (`time.sleep(600)`). The failed process is still alive when the orphan loop runs, so the assert can now fail. The comment on :180 still says the stub "exits immediately"; that's stale wording and doesn't block.
- The script (localhost-dns.sh:270-272) calls stop_stub before the `.prev` restore. The hung process is `python3 $BIN`, so is_our_pid accepts it and it gets killed.
- The red is real. gates/localhost-dns_test.rollback-orphan-red.log, run on the old script, fails exactly `orphan process still running` (FAILED=1), the same as my probe in 1275-r.
- Green: I reran it at 1b4df42e from a path-limited scratch copy, 53 PASS, ALL PASSED, rc=0. I removed the scratch copy, and no stub or sleep processes are left over.
- Still to do on the box sudo run (not blocking, from earlier rounds): Docker daemon.json no-restart on an unchanged rerun, and repair_dead_loopback_resolv.
