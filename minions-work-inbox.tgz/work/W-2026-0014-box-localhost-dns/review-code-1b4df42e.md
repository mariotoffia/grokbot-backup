# Code review: PR #1467 at 1b4df42e (packet 1277, W-2026-0014) — stop before rollback

Delta reviewed: `04f51114..1b4df42ef8cf69f2c48f074e174b08b5ec97633f`
- `1a7645445` test: cover localhost DNS rollback, foreign resolv and pid match
- `1b4df42ef` fix: stop failed localhost DNS stub before rollback

Touches: `scripts/grokbot/localhost-dns.sh` (+3), `scripts/grokbot/localhost-dns_test.sh` (+123).
Head confirmed via `gh`: `1b4df42ef8cf69f2c48f074e174b08b5ec97633f`.
Commit subjects have no W-/T- prefix.

## Verdict: APPROVED

No High or Medium findings. The stop-before-rollback fix is correct, the hung-stub test covers it (with red proof), error still surfaces, and `10.0.0.2` fallback is unchanged. Local gates at this head are green; under Mario’s cost rule they stand in for label-gated CI.

## Fix verification (`localhost-dns.sh` apply_state)

On failed `start_stub` with `${BIN}.prev` present (`:267-274`):
1. log CHANGE restore
2. **`stop_stub`** (new)
3. `mv -f "${BIN}.prev" "$BIN"`
4. `start_stub` or FAIL + `exit 1`

**Stop before restore:** confirmed; comment explains hang-without-answer orphans holding the listen port.

**`stop_stub` safe with no process/pidfile** (`:169-178`):
- `p=$(pidfile_pid || true)` — empty when missing/stale; kill skipped
- orphan loop uses `pgrep ... || true` and `is_our_pid` filter
- kills use `|| true`; `rm -f "$PIDFILE"` is always success
- under `set -euo pipefail`, none of these abort before the `mv`

**set -e cannot abort before rollback:** the new `stop_stub` call sits in the `if ! start_stub` failure branch and itself cannot fail the script (all fallible ops guarded). Rollback `mv` / second `start_stub` then run as before.

**Error still surfaces:** after a successful restore start, `state_ok` still fails `cmp SRC BIN` → main path `FAIL` + `exit 1`. Green test: `apply after bad SRC exits 1`. Hard fail on restore-start uses `exit 1` immediately.

**`10.0.0.2` fallback intact:** this delta does not touch `RESOLV_BODY`, relay/`UPSTREAM`, or early repair; still stub then `nameserver 10.0.0.2` + `options timeout:1`.

## Hung failed stub test

Section `== failed start rolls back to previous binary ==` installs a SRC that `time.sleep(600)` (hang, no bind/answer) so `start_stub`’s health check fails while the process stays alive. Asserts: apply exit 1, restore logged, BIN restored, restored stub answers `foo.localhost`, **no orphan BIN process**, then re-sync exit 0.

Owner red (`gates/localhost-dns_test.rollback-orphan-red.*`): same hang test against pre-fix `1a764544` (restore without `stop_stub`) → `FAIL orphan process still running` / `FAILED=1`. Green after fix: ALL PASSED.

Also covered in the test-only commit (still exercised at this head): foreign resolv left alone on remove; `is_our_pid` rejects non-python with BIN in argv.

## KISS

Three-line production fix; proportional to the orphan/:53 hold risk. No Medium for overcomplication.

## Gates at 1b4df42e
| Gate | Evidence |
|---|---|
| localhost-dns_test | ALL PASSED (`gates/localhost-dns_test.log`, `green-after-revert`); scratch re-run ALL PASSED exit 0 (~53s, includes 5s hung-start wait) |
| rollback-orphan red | FAILED=1 without stop_stub |
| bash -n | empty success logs at 10:23; scratch `bash -n` on sh + test exit 0 |
| py_compile | empty success log; scratch `python3 -m py_compile localdns.py` exit 0 |
| shellcheck / git-diff-clean | empty success logs at 10:23 |

Safety: inode 31%; never ran `machine-setup.sh` / `--check` / sudo / apt / docker / resolv / `.env`; temp ref `refs/rv/1467f` and scratch removed; no GitHub writes/labels.
