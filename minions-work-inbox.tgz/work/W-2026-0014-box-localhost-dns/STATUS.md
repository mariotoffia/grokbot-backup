# W-2026-0014 — box *.localhost DNS
Phase: done (✅)
Next step: none — DNS applied + checks 0–2 PASS; restart-persistence line for box-env-restore still optional (not approved)
Blockers: none

## Log
- 2026-11-05 09:22 Mario GO (t844u) via chat with dev-lead; owner platform-lead; board row added.
- 2026-11-05 09:23–09:27 platform-lead: root cause = egress DNS answers every name with 198.18.0.1; wrote localdns.py + design.md; baseline verify logged; phase awaiting-privileged-apply.
- 2026-11-05 09:36 cto watchdog: board reconciled; Slack/buzz approval request for privileged apply; no Mario thread answers yet.

- 2026-11-05 09:38 release-config-mgr: start — idempotent machine-setup + localhost DNS stub (pl-1261/1262); worktree reset to origin/main
- 2026-11-05 09:46 release-config-mgr milestone: pushed minion/W-2026-0014 @ 3829ebd47; issue #1466 (Task, Medium/Hours, R&D Incoming, Sprint 22)
- 2026-11-05 09:47 release-config-mgr done: draft PR #1467 closes #1466; localhost DNS stub + probe-skip + no-sudo test; commit 3829ebd47
- 2026-11-05 09:49 code-reviewer 1263 start: PR #1467 at 3829ebd4
- 2026-11-05 09:50 test-reviewer start+finish: packet 1264, #1467 @3829ebd4 test review CHANGES REQUESTED, 1 Medium (rerun idempotency assert can't fail) (review-test-3829ebd4.md).
- 2026-11-05 09:52 release-config-mgr milestone: fix rerun idempotency assert (pl-1265); babc29b4366867593707b68866d875d8832450e7; red FAILED=2 (always-write resolv + skip early OK), green ALL PASSED
- 2026-11-05 09:53 code-reviewer 1263 finish: PR #1467 at 3829ebd4 CHANGES REQUESTED (M1 stub binary update without restart); review-code-3829ebd4.md
- 2026-11-05 09:53 test-reviewer start+finish: packet 1266, #1467 delta 3829ebd4..babc29b4 APPROVED (review-test-babc29b4.md).

## 2026-11-05 09:55 CET pl-1267-rcm M1 restart-on-binary-update
- head: fa08bb4101d1340f6204f94b81d5da4bed2e92e7 (on babc29b)
- fix: state_ok requires SRC==BIN; apply_state stop+start whenever install ran
- test: SRC-copy bump → pid change + BIN==SRC + cmdline→BIN; unchanged-rerun still green
- mutation: skip restart after install (keep old if stub_running&&stub_answers)
- gates:
  - localhost-dns_test.restart-red.log rc=1 FAILED=3
  - localhost-dns_test.restart-red.mutation.diff
  - localhost-dns_test.log / green-after-revert.log rc=0
  - localhost-dns.shellcheck.log rc=0
  - localhost-dns.bash-n.log rc=0
  - localhost-dns.py_compile.log rc=0
  - localhost-dns.git-diff-clean.log rc=0
- push: origin minion/W-2026-0014; PR #1467 stays draft; no labels
- 2026-11-05 09:56 code-reviewer 1268 start: re-check M1 on PR #1467 at fa08bb41
- 2026-11-05 09:56 test-reviewer start+finish: packet 1269, #1467 delta babc29b4..fa08bb41 APPROVED (review-test-fa08bb41.md).
- 2026-11-05 09:57 code-reviewer 1268 finish: PR #1467 at fa08bb41 APPROVED (M1 fixed, local gates green, no new H/M); review-code-fa08bb41.md

## 2026-11-05 09:59 CET pl-1270-rcm ready + Copilot requested
- gh pr ready 1467: isDraft=false
- Copilot requested via REST reviewers=copilot-pull-request-reviewer[bot] (GraphQL shows Bot requested); also @copilot comment
- no labels added
- polling reviews up to ~15 min

## 2026-11-05 10:07 CET cto watchdog
- Phase draft-pr → copilot-fix. Head still fa08bb4101d1340f6204f94b81d5da4bed2e92e7.
- Internal code + test reviews APPROVED @fa08bb41; PR ready (not draft); CI Arch/Build/Static/Unit SKIPPED (scripts-only), CodeQL green.
- Copilot review 10:04 CET: Changes recommended, 6 open unresolved threads (3 High, 3 Medium). Not 👀.
- Issued P-2026-0014-01 to release-config-mgr (via platform-lead): fix Copilot findings, push, re-request.
- Blockers: Copilot threads; Mario privileged apply still after merge (machine-setup.sh with sudo).
- No Mario answers in #teos-grokbot threads (09:36 privileged-apply / flow-gaps still open).

## 2026-11-05 10:09 CET pl-1270-rcm Copilot + code fixes (STOP for PL delta)
- ready: yes (isDraft=false); no labels
- Copilot review on fa08bb41: COMMENTED, 6 threads
- threads:
  - localhost-dns.sh:106 PID match — REAL — fixed in 04f511145fa95c1e0fdfa7560734332bb12c4816 (exact python+BIN); resolved
  - machine-setup.sh:77 python3 APT — REAL — fixed in 04f511145fa95c1e0fdfa7560734332bb12c4816; resolved
  - machine-setup.sh:819 DNS order — REAL — early dead-loopback repair + DNS step after apt; resolved
  - localdns.py:42 TCP — NOT A BUG (UDP-only by design + upstream fallback); replied+resolved
  - localhost-dns.sh:209 restore unmanaged resolv — REAL — only restore if resolv_is_ours; resolved
  - localhost-dns.sh:249 failed update — REAL — BIN.prev rollback; resolved
- new commit: 04f511145fa95c1e0fdfa7560734332bb12c4816 (code touched: localhost-dns.sh + machine-setup.sh) — DID NOT re-request Copilot; stopping for Platform Lead delta re-check
- gates (gates/*.copilot-fix.log): test=0 shellcheck=0 bash-n=0 py_compile=0 git-diff=0
- CI: see report
- 2026-11-05 10:11 code-reviewer 1271 start: delta fa08bb41..04f51114 PR #1467
- 2026-11-05 10:11 test-reviewer start+finish: packet 1272, #1467 delta fa08bb41..04f51114 CHANGES REQUESTED, 1 Medium (3 new localhost-dns.sh decisions untested) (review-test-04f51114.md).
- 2026-11-05 10:14 code-reviewer 1271 finish: APPROVED 04f51114 — 5 Copilot claims OK; UDP pushback holds; no H/M; gates green

## pl-1273-rcm 2026-11-05T10:17:48+01:00 head=1a764544534762008b35eb8c4dc7d5990a2673b0
- Added three sudo-free tests in localhost-dns_test.sh: rollback after failed start, foreign resolv leave-alone, is_our_pid rejects non-python with BIN in argv.
- Reds: localhost-dns_test.rollback-red (rc=1), .foreign-resolv-red (rc=1), .is-our-pid-red (rc=1); green suite + green-after-revert ALL PASSED; bash -n / shellcheck / py_compile rc=0; git diff --exit-code rc=0.
- NEW commit only (no amend/force); no labels; Copilot NOT re-requested.
- Push: see gates/git-push.log
- 2026-11-05 10:20 test-reviewer start+finish: packet 1275, #1467 delta 04f51114..1a764544 CHANGES REQUESTED, 1 Medium (rollback orphan assert vacuous; hanging stub leaves orphan) (review-test-1a764544.md).

## pl-1276-rcm 2026-11-05T10:23:50+01:00 head=1b4df42ef8cf69f2c48f074e174b08b5ec97633f
- Rollback orphan: test bad source now hangs (time.sleep(600)); current script was the red (gates/localhost-dns_test.rollback-orphan-red.log + .note.txt).
- Fix: stop_stub before ${BIN}.prev restore in apply_state; green suite ALL PASSED; bash-n/shellcheck/py_compile/git-diff rc=0; no leftover test BIN processes.
- NEW commit only; no labels; Copilot NOT re-requested.
- 2026-11-05 10:24 code-reviewer 1277 start: delta 04f51114..1b4df42e PR #1467
- 2026-11-05 10:25 test-reviewer start+finish: packet 1278, #1467 delta 1a764544..1b4df42e APPROVED (review-test-1b4df42e.md).
- 2026-11-05 10:27 code-reviewer 1277 finish: APPROVED 1b4df42e — stop-before-rollback OK; hung test+red; no H/M; gates green

## pl-1279-rcm 2026-11-05T10:28:30+01:00 head=1b4df42ef8cf69f2c48f074e174b08b5ec97633f
- Re-requested Copilot via REST reviewers=copilot-pull-request-reviewer[bot]; GraphQL shows Bot requested. Waiting for review on 1b4df42e.
- Copilot review on 1b4df42e at 2026-11-05T09:30:53Z: Needs a closer look, **No open issues**; 1 resolved since last review (stop failed DNS before restore).
- Triage: no NEW actionable Copilot threads on latest head; all 7 reviewThreads resolved (0 unresolved). Optional stale test comment :180 not fixed (no push).
- No new commits this packet. Gates unchanged from 1b4df42e.
- CI non-label-gated: CodeQL=pass; Analyze(actions)=pass; Analyze(javascript-typescript)=pass; copilot-pull-request-reviewer=success; Cursor Bugbot=neutral/skipping (Error). Label-gated skipped (no labels): Architecture, Build, Static Analysis, Unit Tests.

## 2026-11-05 10:39 CET cto watchdog
- Phase copilot-fix → awaiting-mario-merge (👀).
- Head `1b4df42ef8cf69f2c48f074e174b08b5ec97633f`. Internal code+test APPROVED (53 PASS). Copilot clean: 7/7 reviewThreads resolved, latest review "No open issues". CodeQL green; Architecture/Build/Static/Unit label-skipped.
- P-2026-0014-01 complete (rcm fixed + Copilot clean). Board row → 👀.
- Blockers: Mario merge of #1467; then Mario decides when to run `scripts/grokbot/machine-setup.sh` with sudo (verify 0–2).
- No Mario answers in #teos-grokbot (10:08 Copilot / 09:36 privileged-apply / flow-gaps threads empty).
- arm64 OK; SUR done (key name present, not pending); no unacked handoffs; no held locks.
2026-11-05 10:48 release-config-mgr: packet 1281 cleanup: W-2026-0014 worktree/branch SKIPPED (pid 1554840 'vim 999999' cwd inside); main pull SKIPPED (3 tracked webui dist deletions in main); remote branch gone; clean-caches rc=0

## 2026-11-05 10:50 CET platform-lead privileged apply STOPPED (BLOCKED)
- Mario approved sudo machine-setup (#1467 merged @654925ae6).
- Main checkout dirty → worktree `.worktrees/W-2026-0014-apply` on origin/main.
- `--check` rc=3; apt WOULD-CHANGE but `apt-get update` rc=100 (egress proxy 500); hard step would abort before DNS.
- No apply. Logs: apply/baseline.log, check.log, apt-update-probe.log, blocker-state.log, REPORT.md.
- next: fix apt egress or authorize localhost-dns.sh-only apply; then verify 0-2.

## 2026-11-05 11:03 CET platform-lead DNS-only apply DONE
- Mario "yes to dns-only sudo"; localhost-dns.sh run1 rc=0 / run2 rc=0 (no CHANGE); stub 1608401; dockerd 22575 unchanged.
- checks 0–2 PASS (check0-dns / check1-sso / check2-groundzero). phase=done.

## 2026-11-05 11:08 CET cto watchdog
- Confirmed #1467 MERGED 10:46 CET @1b4df42e → 654925ae; #1246 closed.
- status.json already phase=done (platform-lead DNS-only apply 11:03; checks 0–2 PASS).
- STATUS.md header reconciled to done; board row purged to done/2026-11-05.md.
- No Mario answers in #teos-grokbot threads; flow-gaps still waiting.
- No unacked handoffs; no held locks; arm64 OK; SUR done (key name present, not pending).
- Phase-change Slack/buzz + board mirror this run.
