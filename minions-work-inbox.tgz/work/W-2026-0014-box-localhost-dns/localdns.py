#!/usr/bin/env python3
"""W-2026-0014: tiny stdlib DNS stub. *.localhost and *.localhost.floci.io -> 127.0.0.1 / ::1;
everything else is relayed byte-for-byte to the upstream (egress) resolver."""
import socket, struct, sys, threading
LISTEN = (sys.argv[1] if len(sys.argv) > 1 else "127.0.0.53", int(sys.argv[2]) if len(sys.argv) > 2 else 53)
UPSTREAM = (sys.argv[3] if len(sys.argv) > 3 else "10.0.0.2", 53)
LOCAL = ("localhost", "localhost.floci.io")
def qname(p):
    i, labels = 12, []
    while p[i]:
        labels.append(p[i+1:i+1+p[i]].decode("ascii", "replace")); i += 1 + p[i]
    return ".".join(labels).lower(), i + 1
def local_answer(p):
    name, end = qname(p)
    if not any(name == d or name.endswith("." + d) for d in LOCAL): return None
    qtype = struct.unpack(">H", p[end:end+2])[0]
    rr = {1: socket.inet_pton(socket.AF_INET, "127.0.0.1"), 28: socket.inet_pton(socket.AF_INET6, "::1")}.get(qtype)
    hdr = p[:2] + struct.pack(">HHHHH", 0x8580, 1, 1 if rr else 0, 0, 0)
    ans = (b"\xc0\x0c" + struct.pack(">HHIH", qtype, 1, 60, len(rr)) + rr) if rr else b""
    return hdr + p[12:end+4] + ans
def relay(s, p, addr):
    u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); u.settimeout(5)
    try: u.sendto(p, UPSTREAM); s.sendto(u.recv(4096), addr)
    except OSError: pass
    finally: u.close()
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.bind(LISTEN)
while True:
    p, addr = s.recvfrom(4096)
    try: a = local_answer(p)
    except Exception: a = None
    if a: s.sendto(a, addr)
    else: threading.Thread(target=relay, args=(s, p, addr), daemon=True).start()
