# W-2026-0014 box *.localhost DNS

## Root cause
nsswitch `files dns`; /etc/hosts only has exact `localhost`; resolv.conf -> 10.0.0.2 (egress). The egress DNS
answers EVERY name with fake-IP 198.18.0.1 (even direct UDP to 8.8.8.8 is intercepted), so public DNS's
`*.localhost.floci.io -> 127.0.0.1` (verified via DoH) never reaches us. No resolved/myhostname stub exists, and Go (pure and cgo, 1.27.3)
does not special-case `.localhost`. Test dials http://api.auth.sso<nanos>.localhost.floci.io:<port> through the egress proxy -> 500.

## Why not /etc/hosts
Test name is dynamic (`sso<UnixNano>`), so exact entries are impossible.

## Fix (zero new software: python3 stdlib, ~40 lines)
localdns.py on 127.0.0.53:53: `*.localhost`, `*.localhost.floci.io` -> 127.0.0.1 / ::1; everything else relayed byte-for-byte to 10.0.0.2.
resolv.conf: `nameserver 127.0.0.53` then `nameserver 10.0.0.2` (fallback if stub is down).

## Containers
Not needed: the test process (host) dials the login host; Floci is reached via published 127.0.0.1 port.
Docker drops loopback nameservers from resolv.conf, so containers keep 10.0.0.2 -> unchanged behaviour.

## Privileged apply (NOT done)
    sudo install -m 0755 /workspace/minions/work/W-2026-0014-box-localhost-dns/localdns.py /usr/local/sbin/box-localdns.py
    sudo sh -c 'nohup /usr/local/sbin/box-localdns.py >/var/log/box-localdns.log 2>&1 &'
    sudo sh -c 'printf "nameserver 127.0.0.53\nnameserver 10.0.0.2\noptions timeout:1\n" > /etc/resolv.conf'
Restore-script line (both box-env-restore.sh copies):
    pgrep -f box-localdns.py >/dev/null || nohup /usr/local/sbin/box-localdns.py >/var/log/box-localdns.log 2>&1 & grep -q 127.0.0.53 /etc/resolv.conf || printf "nameserver 127.0.0.53\nnameserver 10.0.0.2\noptions timeout:1\n" > /etc/resolv.conf
Rollback: `printf "nameserver 10.0.0.2\n" > /etc/resolv.conf; pkill -f box-localdns.py`.
Verify after: getent hosts foo.localhost / api.auth.sso1.localhost.floci.io -> 127.0.0.1; example.com -> 198.18.0.1; rerun the test.

## Follow-up: PR #1248 dnsmasq (scripts/grokbot/machine-setup.sh)
Confirmed as the root cause: #1248's dnsmasq is gone, not just stopped. `/usr/sbin/dnsmasq` is not installed (dpkg has no dnsmasq),
`/etc/dnsmasq.d` and the resolv.conf change are missing, so the box was reset, not just rebooted. The script's restart-after-reboot path
(line 257) requires the binary. Rerunning it = `apt-get install dnsmasq` -> BLOCKED (apt proxy 500).
`--check` also shows a full rerun would reinstall the docker engine and rewrite /etc/docker/daemon.json (dns=[172.17.0.1]),
which RESTARTS dockerd and would kill other runs' Floci containers. Do NOT rerun it in full now.
Decision: use the zero-package python3 stub above (same address= mapping as #1248's teos-box.conf). When apt works again, switch to
`scripts/grokbot/machine-setup.sh` at a quiet time and drop the stub.
If apt is fixed first, the dnsmasq-only equivalent is (also privileged):
    sudo apt-get install -y dnsmasq-base && scripts/grokbot/machine-setup.sh   # still restarts dockerd; coordinate

## Verification (from W-2026-0001 analysis.md), run from /workspace/repos/teos, after `make cbtest-bin`
0. `getent hosts api.auth.sso1.localhost.floci.io foo.localhost`  -> 127.0.0.1 for both
1. `_dist/_output/bin/cbtest local exec --resources-only --provision-config deployment/provision-config.yaml -- sh -c 'cd go-services/appstore/cmd/cbdeploy && go test -tags=integration,floci -count=1 -race -v -timeout 600s -run "^TestSSOLoginAgainstTheLocalEmulator$" ./internal/auth/'`
2. `cd deployment/stacks/groundzero/service-test && CB_SERVICE_TEST=groundzero go test -tags=e2e,floci -count=1 -v -timeout 30m -run '^(TestThePublicNamesResolveToThisMachine|TestThePublicNamesReachTheEmulator|TestThePublicNamesPresentAVerifiedCertificate|TestTheTokenEndpointAnswersOnTheLoginDomain)$' .`
3. (optional) `_dist/_output/bin/cbtest local exec --resources-only --provision-config deployment/provision-config.yaml -- sh -c 'cd deployment/lib && go test -tags=integration,floci -count=1 -race -v -timeout 1800s -run "^TestLocalBackendStandsUpAnEmulatorACdkCanDeployTo$" ./svctest/'`
Baseline 2026-11-05 (before fix): 0 -> 198.18.0.1; 1 FAIL; 2 ResolveToThisMachine FAIL (198.18.0.1), Reach/Certificate/TokenEndpoint PASS; 3 not run.
