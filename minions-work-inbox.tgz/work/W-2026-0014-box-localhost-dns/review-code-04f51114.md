# Code review: PR #1467 at 04f51114 (packet 1271, W-2026-0014) — Copilot harden delta

Delta reviewed: `fa08bb41..04f511145fa95c1e0fdfa7560734332bb12c4816`
- `04f511145` fix: harden localhost DNS stub lifecycle and early resolv repair

Touches: `scripts/grokbot/localhost-dns.sh`, `scripts/grokbot/machine-setup.sh`.
Head confirmed via `gh`: `04f511145fa95c1e0fdfa7560734332bb12c4816`.
Commit subject has no W-/T- prefix.

## Verdict: APPROVED

No High or Medium findings. All five claimed Copilot fixes hold under static review. UDP-only pushback holds for the box. Local gates (owner `gates/*.copilot-fix.log` + scratch re-runs) are green. Under Mario’s cost rule, local gates stand in for label-gated CI.

## Claim verification

### 1. PID match requires python + exact `$BIN` argv — OK
`is_our_pid` (`localhost-dns.sh:100-113`) now `mapfile`s `/proc/$p/cmdline`, requires `args[0]` in `python|python3|*/python|*/python3`, and `args[1] = "$BIN"`. Editors that only mention the path in argv are rejected.

### 2. `python3` added to `APT_PKGS` — OK
`machine-setup.sh:77` includes `python3` at the end of `APT_PKGS`.

### 3. Early dead-loopback repair + DNS step after apt — OK
- `repair_dead_loopback_resolv` (`machine-setup.sh:227-251`) runs **before** apt. Shell-only (`ss` + `sudo tee`); no python3 required.
- Condition: every `nameserver` is loopback (`127.*`/`::1`), none non-loopback, and no UDP/53 listener → rewrite to `nameserver 10.0.0.2`. Otherwise no-op (idempotent).
- When managed resolv is already stub + `10.0.0.2` and the stub is dead (reboot), non-loopback is present so repair leaves resolv alone; apt still works via the upstream after `timeout:1`; the DNS step after apt restarts the stub.
- `step "apt packages..."` then `step "localhost DNS stub..."` (`machine-setup.sh:268-279`). DNS after apt so `python3` is present.
- Does not break apt when DNS was fully dead: repair restores upstream first.
- Inspect-then-change: repair only mutates when the inspect predicates match; `--check` skips the write (`CHECK_ONLY` early return) so check mode stays read-only. The DNS step still uses the normal `step` check/apply path. (Bootstrap repair does not emit WOULD-CHANGE; acceptable for this emergency path and consistent with other apply-only housekeeping in the same script.)

### 4. `remove` restores resolv only when `resolv_is_ours` — OK
`remove_stub` (`localhost-dns.sh:219-227`): `stop_stub`, `rm -f "$BIN" "${BIN}.prev"`, then `restore_resolv` only inside `if resolv_is_ours`; otherwise logs OK and leaves resolv unchanged.

### 5. Failed start after update rolls back to `${BIN}.prev` — OK
- `install_stub` (`:180-189`): if `$BIN` exists, `cp -p` to `${BIN}.prev`; else `rm -f` `.prev` (first install / missing handled).
- Start failure path (`:267-276`): if `.prev` exists → `mv` back to `$BIN`, `start_stub` again (old stub restarted); if that fails → `FAIL` + `exit 1`. If no `.prev` → `FAIL` + `exit 1`.
- After a successful rollback start, apply continues, then main `state_ok` fails on `cmp SRC BIN` (new source vs restored old binary) → `FAIL` + `exit 1`, so the update error still surfaces while the previous stub keeps answering.
- `10.0.0.2` fallback intact: `RESOLV_BODY` is still stub, then `nameserver 10.0.0.2`, then `options timeout:1`; stub relay/`UPSTREAM` unchanged; early repair also points at `10.0.0.2`.

## UDP-only pushback — holds
- Managed `resolv.conf` order: `127.0.0.53` then `10.0.0.2` with `timeout:1`.
- Stub (`localdns.py`) is UDP (`SOCK_DGRAM`) only by design.
- glibc: tries nameservers in order; UDP first. A TCP connect to the stub with nothing listening gets a fast RST (not a multi-second timeout), then the next nameserver (`10.0.0.2`) is used.
- `*.localhost` / `*.localhost.floci.io` answers are tiny (no TC bit), so normal getaddrinfo never needs TCP for those names.
- Nothing on the box’s intended workload needs TCP DNS specifically for `*.localhost`. TCP DNS for non-localhost names is covered by `10.0.0.2`. Edge `dig +tcp` against a localhost name would fall through to the fake-IP upstream; not a real box requirement.

## KISS
Delta is proportional to the Copilot findings (stricter PID match, apt python3, bootstrap repair, conditional resolv restore, `.prev` rollback). No Medium for overcomplication.

## Gates
| Gate | Evidence |
|---|---|
| localhost-dns_test | ALL PASSED (`gates/localhost-dns_test.copilot-fix.log`); scratch re-run ALL PASSED exit 0 |
| bash -n | OK (`gates/localhost-dns.bash-n.copilot-fix.log`); scratch re-run OK for `localhost-dns.sh`, `_test.sh`, `machine-setup.sh` |
| py_compile | empty success log; scratch `python3 -m py_compile localdns.py` exit 0 |
| shellcheck | empty success log (same pattern as 1268); not on PATH here; relied on owner log + bash -n/test |
| git-diff-clean | empty success log |

Safety: inode 31% before work; never ran `machine-setup.sh` / `--check` / `make box-setup` / sudo / apt / docker / resolv / `.env`; temp ref `refs/rv/1467e` and scratch `/tmp/rv-1467-r3-*` removed; foreign refs untouched; no GitHub writes/labels.
