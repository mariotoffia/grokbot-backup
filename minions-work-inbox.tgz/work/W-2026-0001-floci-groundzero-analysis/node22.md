# node22 — user-level Node 22 for teos tklocal web UI (release-config-mgr, W-2026-0001)
Date: 2026-10-22 20:36–20:39 Europe/Stockholm (CEST). Result: **PASS**

## Install
- nvm v0.40.3 (official install.sh, PROFILE=/dev/null so no rc files were edited) -> `~/.nvm` (/home/box/.nvm)
- `nvm install 22` -> Node **v22.23.4**, npm 10.9.9, at /home/box/.nvm/versions/node/v22.23.4/bin. `nvm alias default 22`.
- System Node untouched: /usr/bin/node = **v20.19.2** (no sudo, nothing in /usr changed).
- Note: agent shells have `/exec-daemon/node` (v22.14.0, the agent runtime) first on PATH. Don't rely on it: it's below the teos engines floor.

## teos requirements
- Root package.json `engines.node`: `^22.22.2 || ^24.15.0 || >=26.0.0` (v22.14/v20 don't satisfy it, v22.23.4 does). pnpm >=10 (packageManager pins pnpm 10.33.0 via corepack).
- `.nvmrc` = `v24.19.0`, so a bare `nvm use` in the repo picks 24 (not installed). Use `nvm use 22` explicitly, or `nvm install 24` if you want .nvmrc parity.
- The Makefiles don't select node themselves. They use whatever `node`/`pnpm` is on PATH (SHELL=/bin/zsh, non-login, so nothing from rc files gets sourced). Activate BEFORE calling make.

## Activate (per shell)
```
unset NPM_CONFIG_PREFIX   # box sets it to ~/.local; nvm refuses to work with it set
export NVM_DIR=$HOME/.nvm; . "$NVM_DIR/nvm.sh" --no-use; nvm use 22 >/dev/null
export COREPACK_HOME=$HOME/.cache/node/corepack PATH=$HOME/go/bin:$PATH
corepack enable   # once per node version: puts pnpm shim in the nvm node bin
```
Output: `node -v` -> v22.23.4 (`which node` -> ~/.nvm/versions/node/v22.23.4/bin/node), `/usr/bin/node -v` -> v20.19.2.
Caveat: unsetting NPM_CONFIG_PREFIX affects global npm installs in that shell only (they go to the nvm node's prefix, not ~/.local).

## tklocal web UI step (isolated clone)
- `git clone /workspace/repos/teos /tmp/teos-node22-3870` (HEAD a3543337), no worktree, nothing pushed. Deleted afterwards.
- Root `make generate` -> `$(MAKE) -C cmd/tklocal generate-code` -> `react-build` (design-tokens build, `pnpm -F tklocal-webui generate:api`, typecheck, build) then `go generate`. Only react-build was run:
  `pnpm install --frozen-lockfile` (rc=0) then `make -C cmd/tklocal react-build` -> **rc=0**
- Tail: `Total: 18.4 MB -> 5.0 MB (72.7% reduction) / Deleted 68 originals - only .gz files remain. / Done! Assets ready for go:embed.`
- Warnings only: a pnpm "approve-builds" notice, a vite dynamic URL warning, and a chunk-size warning. No engine errors.

## Remaining issues
- .nvmrc (24) vs installed 22 mismatch (cosmetic; engines allow 22.22.2+).
- `go generate` part of generate-code was not run (out of scope).

## Proposed env-note change (NOT applied to shared scripts)
box-env-restore.sh is a root script for docker/binfmt. Node activation is per user shell, so it doesn't belong there. Proposed addition to the w0-env.md "Required env" line:
`unset NPM_CONFIG_PREFIX; export NVM_DIR=$HOME/.nvm; . $NVM_DIR/nvm.sh --no-use; nvm use 22 >/dev/null; export PATH=$HOME/go/bin:$PATH COREPACK_HOME=$HOME/.cache/node/corepack`

## Node 24.19.0 follow-up (2026-10-22 20:40–20:47 CEST, msg-W-2026-0001-platform-lead-116) — PASS
- `nvm install 24.19.0` -> /home/box/.nvm/versions/node/v24.19.0 (npm 11.17.0). `nvm alias default` is still `22 (-> v22.23.4)`. /usr/bin/node is still v20.19.2.
- A plain `nvm use` in /workspace/repos/teos (read-only) -> "Found .nvmrc with version <v24.19.0> / Now using node v24.19.0".
- `corepack enable` under v24 -> pnpm shim in ~/.nvm/versions/node/v24.19.0/bin. Outside the repo, corepack's default pnpm is 12.14.0. Inside the repo, packageManager pins pnpm 10.33.0.
- Throwaway clone /tmp/teos-node24-2122 (HEAD a3543337), node v24.19.0 confirmed: `pnpm install --frozen-lockfile` rc=0, `make -C cmd/tklocal react-build` **rc=0**. Tail: "Deleted 68 originals (18.4 MB) - only .gz files remain. / Done! Assets ready for go:embed." No engine or ERR lines. Clone deleted.
- Gotchas:
  1. The agent shell tool re-exports NPM_CONFIG_PREFIX on every call, so the preamble (unset + source nvm.sh) must be in the same command as make.
  2. Don't pipe `nvm use` (e.g. `| tail`): that runs it in a subshell and the version change is lost. Two early attempts silently ran on v22 and were discarded.
  3. Without the nvm node active, `corepack enable` hits the system corepack and fails with EACCES (/usr/bin/yarn).
- Activation for v24: `unset NPM_CONFIG_PREFIX; export NVM_DIR=$HOME/.nvm; . $NVM_DIR/nvm.sh --no-use; cd <teos> && nvm use` (or `nvm use 24.19.0`).
