#!/bin/bash
run(){ cd /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/aws-serverless-cdk/teos-bsvc/$2; echo "## $(date '+%F %H:%M:%S') svc=$1 sha=$(git rev-parse HEAD)"
env -i HOME=/home/box USER=box PATH=/home/box/go/bin:/home/box/.local/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin COREPACK_HOME=/home/box/.cache/node/corepack SVC=$1 bash -c 'set -a; . /workspace/repos/teos/.env; set +a; export TK_LOCAL_EMULATOR=mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 CB_SERVICE_TEST=$SVC; unset AWS_PROFILE; exec sg docker -c "go test -tags=e2e,floci -count=1 -v -timeout 30m ./..."'
echo "## rc=$? $(date '+%F %H:%M:%S')"; }
run building-service go-services/buildingsvc/deployment/service-test > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/aws-serverless-cdk/bsvc-run3.tmp 2>&1
run sur-provider go-services/providers/eastbound/sur/deployment/service-test > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/aws-serverless-cdk/sur-run3.tmp 2>&1
