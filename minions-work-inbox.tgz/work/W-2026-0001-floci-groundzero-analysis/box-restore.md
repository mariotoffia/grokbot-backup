# Box restore — 2026-10-22 21:49 (Europe/Stockholm) — aws-serverless-cdk

0. No box-env-restore.sh found anywhere (rg --files /).
1. Docker 29.9.2 installed via get.docker.com. dockerd started in background: `sudo nohup dockerd >/tmp/dockerd.log 2>&1 &` (no systemd; must be restarted after box restart).
   User box added to group docker; current sessions lack the group, so use `sg docker -c '<docker cmd>'` (new login shells won't need it).
   Fix applied: /var/run was a root-only 0700 dir (not a symlink to /run), which blocked the socket; ran `sudo chmod 755 /var/run`.
   `sg docker -c 'docker run --rm hello-world'` → "Hello from Docker!" OK.
2. Pulled mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1; RepoDigests = ["mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1"] ✔
3. /etc/hosts does NOT contain `127.0.0.1 000000000000.dkr.ecr.eu-west-1.localhost` (0 exact matches). /etc/hosts.bak-W-2026-0001-t39-11 does NOT exist. (Not edited.)
4. ~/.nvm does not exist → node v22.23.4 / v24.19.0 not present.
- 2026-10-22 21:50 CEST T-39.11 (golang-pro, approved msg-229): re-added '127.0.0.1 000000000000.dkr.ecr.eu-west-1.localhost' to /etc/hosts for the #1234 test-integration rerun; fresh backup /etc/hosts.bak-W-2026-0001-t39-11-202610222150. platform-lead reverts it after #1234 merges.

# Node/nvm reinstall + restore script — 2026-10-22 21:50 (Europe/Stockholm) — release-config-mgr

## Reinstalled
- nvm v0.40.8 (latest official install.sh) → $HOME/.nvm (PROFILE=/dev/null, no rc edits)
- Node v22.23.4 (nvm default) and v24.19.0; corepack enabled + pnpm 10.33.0 for both (COREPACK_HOME=$HOME/.cache/node/corepack)
- /usr/bin/node (system v20.19.2) untouched. Docker/floci were already restored by aws-serverless-cdk (section above).

## Script
`/workspace/minions/box-env-restore.sh` — idempotent, set -euo pipefail, logs skip/done per step.
Usage: `bash /workspace/minions/box-env-restore.sh` (uses sudo for docker install/dockerd/chmod/usermod; uses `sg docker` if the session lacks the docker group).
Steps: docker-install, chmod-var-run, dockerd (nohup), docker-group, floci-pull (mariotoffia/floci@sha256:a31d6e08…d5c1), nvm-install, node-<v>, pnpm-<v>, nvm-default. No secrets, no /etc/hosts, no AWS.

## Runs (both rc=0; run 1 after manual nvm reinstall, so all skip)
```
== run 1
[2026-10-22T21:50:43+02:00] docker-install: skip
[2026-10-22T21:50:43+02:00] chmod-var-run: skip
[2026-10-22T21:50:43+02:00] dockerd: skip
[2026-10-22T21:50:43+02:00] docker-group: skip
[2026-10-22T21:50:43+02:00] floci-pull: skip
[2026-10-22T21:50:43+02:00] nvm-install: skip
[2026-10-22T21:50:43+02:00] node-22.23.4: skip
[2026-10-22T21:50:43+02:00] pnpm-22.23.4: skip
[2026-10-22T21:50:43+02:00] node-24.19.0: skip
[2026-10-22T21:50:44+02:00] pnpm-24.19.0: skip
[2026-10-22T21:50:44+02:00] nvm-default: skip
rc=0
== run 2
[2026-10-22T21:50:44+02:00] docker-install: skip
[2026-10-22T21:50:44+02:00] chmod-var-run: skip
[2026-10-22T21:50:44+02:00] dockerd: skip
[2026-10-22T21:50:44+02:00] docker-group: skip
[2026-10-22T21:50:44+02:00] floci-pull: skip
[2026-10-22T21:50:44+02:00] nvm-install: skip
[2026-10-22T21:50:44+02:00] node-22.23.4: skip
[2026-10-22T21:50:44+02:00] pnpm-22.23.4: skip
[2026-10-22T21:50:44+02:00] node-24.19.0: skip
[2026-10-22T21:50:45+02:00] pnpm-24.19.0: skip
[2026-10-22T21:50:45+02:00] nvm-default: skip
rc=0
```

## Verification
- nvm default `node -v` → v22.23.4 ✔
- `nvm ls` shows v24.19.0 ✔ (note: `node`/`stable` aliases point at 24.19.0; `default` → 22.23.4)
- `sg docker -c 'docker info'` → server 29.9.2 ✔
- floci RepoDigests = mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 ✔
- Failures: none. Caveat: "done" branches for docker/floci not exercised on this box (already present).

## 2026-10-22 22:02 CEST — aws-serverless-cdk: DynamoDB-local timeout diagnosis (#1240, T-27.16.1) — DIAGNOSIS ONLY, all reverted

### Root cause
Stale **iptables-legacy** filter tables (left from an earlier dockerd run before `/etc/alternatives/iptables` was switched to iptables-nft at 21:48) with `FORWARD` policy **DROP** and ACCEPT rules only for `docker0`. Current dockerd programs nft only. With `net.bridge.bridge-nf-call-iptables=1`, bridged packets go through BOTH the nft and the legacy FORWARD hooks, so all traffic on user-defined bridges (teos-net-*, where Floci reaches `<name>-ddblocal:8000`) and published-port DNAT is dropped by legacy FORWARD → Floci "HTTP connect timed out" → "DynamoDB Local ... not reachable after 30s". Not proxy/DNS/Ryuk related (repro used `--noproxy '*'` and container names on a docker network).

### Temporary changes (all reverted)
1. Created docker network `t1240-net` + container `t1240-ddb` (amazon/dynamodb-local:3.3.1 pinned digest, -p 18000:8000) for repro. Before fix: host curl 000, c2c curl rc=28 (timeout). Reverted: `docker rm -f t1240-ddb; docker network rm t1240-net` (done).
2. Saved legacy rules to `iptables-legacy-backup-aws-serverless-cdk.rules` (this dir), then flushed/deleted all legacy tables and set legacy FORWARD ACCEPT. After: host curl localhost:18000 → 400 (DynamoDB alive), c2c → 400 rc=0. Reverted: `sudo iptables-legacy-restore < iptables-legacy-backup-aws-serverless-cdk.rules` (done; legacy FORWARD DROP again → box is back to the broken state). Backup file kept as evidence (harmless; `rm` it to clean).
3. Started the T-27.16.1 eventsvc service test (worktree b049c8ae, read-only) → failed early on a separate prerequisite: `cbdeploy not found on PATH` (no Floci started). Killed; no containers/networks left. Log: impl/T-27.16.1/gates/test-service-b049c8ae-aws-serverless-cdk-verify.log.
4. Task 2 (/etc/hosts) cancelled before execution: /etc/hosts not touched, no backup created.

### Fix for scripts/grokbot/machine-setup.sh (idempotent)
```bash
# Step: drop stale iptables-legacy rules when docker uses iptables-nft
# CHECK (already applied / not needed => exit 0):
iptables_legacy_ok() { ! command -v iptables-legacy >/dev/null || \
  { sudo iptables-legacy -S FORWARD | grep -q '^-P FORWARD ACCEPT' && \
    [ "$(sudo iptables-legacy-save | grep -c '^-A')" -eq 0 ]; }; }
# APPLY:
iptables_legacy_ok || { for t in filter nat mangle raw; do
  sudo iptables-legacy -t $t -F; sudo iptables-legacy -t $t -X; done
  sudo iptables-legacy -P FORWARD ACCEPT; }

# Step: pin dockerd to the nft backend so it never re-creates legacy rules
# CHECK:
[ "$(readlink -f /etc/alternatives/iptables)" = /usr/sbin/iptables-nft ]
# APPLY:
sudo update-alternatives --set iptables /usr/sbin/iptables-nft && \
sudo update-alternatives --set ip6tables /usr/sbin/ip6tables-nft
# (order: set alternatives BEFORE starting dockerd; run the legacy flush AFTER, then restart nothing — no dockerd restart needed)

# Verify:
# docker network create v; docker run -d --rm --name vddb --network v -p 18000:8000 amazon/dynamodb-local:3.3.1@sha256:ff89bd48ff32cd8d9be5fee8873b65b8854dc408f1afe881be6eb00247bc0dab; sleep 8
# curl -s --noproxy '*' -o /dev/null -w '%{http_code}' localhost:18000   # expect 400
# docker run --rm --network v --entrypoint curl amazon/dynamodb-local:3.3.1@sha256:ff89... -s -o /dev/null -w '%{http_code}' http://vddb:8000  # expect 400
# docker rm -f vddb; docker network rm v
```
Undo of the fix: `sudo iptables-legacy-restore < iptables-legacy-backup-aws-serverless-cdk.rules`.

## release-config-mgr machine-setup (2026-10-22T22:18:46+02:00)
- apt pkgs incl. dnsmasq bind9-dnsutils shellcheck: `sudo apt-get remove <pkg>`
- git lfs global: `git lfs uninstall`
- npm -g aws-cdk@2.1146.1 prettier@3.9.10 (node 22): `npm -g rm aws-cdk prettier`
- ~/.local/bin links (cdk relinked from ../lib/node_modules/aws-cdk): `ln -sfn ../lib/node_modules/aws-cdk/bin/cdk ~/.local/bin/cdk`
- ~/.config/teos-box/env.sh + source line in ~/.bashrc/.profile: restore ~/.bashrc.bak.* / ~/.profile.bak.*, rm env.sh
- iptables alternatives nft: `sudo update-alternatives --set iptables /usr/sbin/iptables-legacy`
- iptables-legacy flush (first run): `sudo /usr/sbin/iptables-legacy-restore < /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/machine-setup/iptables-legacy.20261022T220559.rules`
- dnsmasq conf /etc/dnsmasq.d/teos-box.conf + nohup process (pid file /run/dnsmasq-teos-box.pid): `sudo kill $(cat /run/dnsmasq-teos-box.pid); sudo rm /etc/dnsmasq.d/teos-box.conf`
- resolv.conf: `sudo cp /etc/resolv.conf.bak.20261022T220559 /etc/resolv.conf`
- daemon.json dns: `sudo rm /etc/docker/daemon.json` then restart dockerd
- user box in docker group: `sudo gpasswd -d box docker`
- box-env-restore.sh Floci pin -> :latest (manual edit; previous digest a31d6e08…)
- images pulled: curlimages/curl, alpine, floci:latest, dynamodb-local: `docker rmi <img>`

## aws-serverless-cdk dns-containers-1248 (2026-10-22 22:20–22:24 CEST)
Baseline: dnsmasq teos-box.conf already running (pid 146588), resolv.conf=127.0.0.1, daemon.json dns=[172.17.0.1] — all left untouched (md5 conf 27aae595…, daemon.json 33c41966…).
- docker network `dnst` (DNS probe on a user-defined network) — reverted: `docker network rm dnst`
- container `dnst-floci` (mariotoffia/floci:latest, --network dnst alias floci, docker.sock, 127.0.0.1:14566) + its anonymous volume f049f16a… — reverted: `docker rm -f`, `docker volume rm`
- Floci-launched Lambda container floci-aws-dnst-dnsprobe-* (python3.12 image 25aee9bac65f was already present/cached) — reverted: `docker rm -f` by label floci_namespace=dnst
- /tmp/dnst.sh, /tmp/lf (probe Lambda zip) — reverted: rm -rf
- Throwaway alpine/curlimages/curl containers ran with --rm (nothing left over). No dnsmasq/resolv/daemon.json changes were made.
- root Go caches from the sudo DDB test (/root/go, /root/.cache/go-build): `sudo rm -rf /root/go /root/.cache/go-build`

## Box restore 2 — 2026-10-23 07:34–07:40 (Europe/Stockholm)
- Script: scripts/grokbot/machine-setup.sh @ 2c935e22 (PR #1248), worktree reused.
- --check exit 3 (would-change=18); run exit 0 (changes=16); rerun exit 0 (changes=0).
- Verify: docker hello-world OK, GNU Make 4.4.1, node v22.23.4 (nvm default), x.localhost.floci.io -> 127.0.0.1, sts.eu-west-1 -> public IP, image mariotoffia/floci:latest present.
- Logs: machine-setup/box-restore-2/{1-check,2-run,3-rerun,verify}.log. No script bug found.

## arm64 emulation restore — 2026-10-23 07:53 (Europe/Stockholm)
- Mounted binfmt_misc (was not mounted after box swap) — undo: `sudo umount /proc/sys/fs/binfmt_misc`
- Registered qemu-aarch64 (flags POCF) via `tonistiigi/binfmt@sha256:400a4873…` --install arm64 — undo: `echo -1 | sudo tee /proc/sys/fs/binfmt_misc/qemu-aarch64` (or `sudo docker run --privileged --rm tonistiigi/binfmt@sha256:400a4873b838d1b89194d982c45e5fb3cda4593fbfd7e08a02e76b03b21166f0 --uninstall qemu-aarch64`)
- Pulled images tonistiigi/binfmt@sha256:400a4873…, alpine:latest — undo: `docker rmi <img>`
- Verify: `sudo docker run --rm --platform linux/arm64 alpine uname -m` -> `aarch64`. Not reboot-persistent (no systemd); see #1251. Log: machine-setup/arm64-restore/restore.log
