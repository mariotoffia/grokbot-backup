# Code review (delta): PR #1255 "test(ingestionsvc): assert Firehose transform and Logs output on Floci"

- Reviewer: code-reviewer (read-only), 2026-10-23 UTC+2. Prior verdict: APPROVED at 849de752 (review-1255-code.md).
- Range: 849de752..5124119ea41976dc1f4bceca22c1e89cf5b2eabc. The head is unchanged.
- There is one commit, 5124119e "test(ingestionsvc): paginate CloudWatch Logs queries in log assertions". The diff touches only `go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go` (+32/-6), as claimed.
- Titles: the PR title and the commit subject have no W-/T- prefix. There are no plan IDs in code comments (grep for `W-20`/`T-<n>` finds nothing).

## Correctness
- **Paginator loop:** `NewFilterLogEventsPaginator` with `HasMorePages`/`NextPage`. It ends when NextToken is nil. The first error is returned together with the events collected so far.
- **Callers:**
  - The transform check passes `stopAtFirst=true`, so it returns on the first non-empty page. This fixes the single-page false negative (an empty page with a NextToken). It stays inside `require.Eventually`, so ingestion lag is still polled, and an error is logged and retried.
  - The error groups pass `stopAtFirst=false`, so every page is read before `assert.Empty`. This fixes the single-page false pass. The `require.NoError` "log group must exist" semantics are kept.
- **Filters:** unchanged. `StartTime=since.UnixMilli()`, the stream filter applies only to the Firehose error stream, and there is no filter pattern, so every event counts. These are correct for "from this run" and "no errors".
- **Context:** the caller's `ctx` is passed to every `NextPage`, so cancellation propagates.
- **Logs:** messages are truncated with `%.300s`. Only log content from Floci is printed, with no credentials or config.
- **Eventual consistency:** the transform side is polled. The error side is a point-in-time check after the transform events are seen, which is the same as at 849de752.

## Gates
- Logs in impl/T-27.16.4/copilot/r1/*-5124119e.log, each with sha/HEAD 5124119e: all rc=0.
  - gofmt
  - golangci-lint with `--build-tags=e2e,floci` (0 issues)
  - root `make lint-arch` (9 checked)
  - `go vet -tags=e2e,floci ./...`
  - tidy
  - unit
  - Floci service test via svcroot-copilot.sh, which runs `go test -tags=e2e,floci -count=1 -v -race` (ok, 181.7s; transform events = 2; image floci@sha256:07ced9c6…)
- Own rerun in a clean temp worktree (removed afterwards), service-test module: `gofmt -l .` is empty, `go vet -tags=e2e,floci ./...` rc=0, and `go vet -tags=e2e ./...` rc=0.

## Findings
- [Low] [hard-to-test] sinks_helpers_test.go:135 (`NewFilterLogEventsPaginator(logs, in)`) — `StopOnDuplicateToken` is not set and the query has no EndTime. A backend that echoes the same NextToken would make the loop spin until ctx or the go test timeout. Inside `require.Eventually` the goroutine would outlive the poll timeout. Fix: `NewFilterLogEventsPaginator(logs, in, func(o *cloudwatchlogs.FilterLogEventsPaginatorOptions){ o.StopOnDuplicateToken = true })`, or set EndTime to now, or use a per-call timeout context.
- [Info] [non-testable] gates.sh unit gate — `go test` runs without `-race`. The changed file is e2e-only and is covered by the `-race` Floci service run, so this does not block.
- [Info] [non-testable] r1/svcroot-wrapper.log is empty. The service evidence is in test-service-5124119e.log.

## Verdict: APPROVED at 5124119e (1 Low, non-blocking)

## Delta 2: 5124119e..14aad90b

- Head: 14aad90bcfd22460652f6295af038eb2c8a80818, as expected.
- Commits: 9ede5279 "test(ingestionsvc): bound log paging and match per-record transform logs" and 14aad90b "test(ingestionsvc): use ifcore.CbContext timeouts in the log paging helper".
- Titles: the commit subjects and the PR title have no W-/T- prefix. A grep for W-20xx/T-n in service-test finds no plan IDs in code or comments.
- Files: logpages_test.go (new), logpages_unit_test.go (new), provision-config.yaml (1 line) and sinks_helpers_test.go.

### Earlier L1 (StopOnDuplicateToken): FIXED
logpages_test.go:29-30 sets `o.StopOnDuplicateToken = true`. It also adds `maxLogPages=100` and a 30s per-call timeout.

### Cap and timeout semantics
- **Cap:** at n == 100, while pages remain, the helper returns the collected events together with `fmt.Errorf("... more than 100 pages")`. This is an error, not silent truncation.
  - On the error groups, `require.NoError` fails the test, so error events cannot be hidden by the cap.
  - On the transform check, the error is logged and `Eventually` retries.
- **Duplicate token:** the SDK ends paging with no error. That is the SDK's normal end-of-results behaviour (see Info).
- **Timeout:**
  - Transform: `ctx.WithTimeout(logsCallTimeout)` is created inside the `Eventually` closure with `defer cancel()`, so it is cancelled on every poll iteration.
  - Error groups: one ctx is created per group and `cancel()` is called right after the query, before the `require`, so nothing leaks on failure.
  - `CbContext.WithTimeout` (go-core/ctx/ctx.go:296) returns `(ctx, cancel, err)`, and the err is handled on both paths.
  - The helper now accepts `cloudwatchlogs.FilterLogEventsAPIClient`, which allows the fake.

### Unit tests (logpages_unit_test.go)
- There are no build tags on either new file, so the unit tests run in a plain `go test`, and the e2e files can still use the helper. This is intended and correct.
- **Duplicate token:** `sameToken` gives exactly 2 calls for both stopAtFirst values. This is meaningful.
- **Cap:** fresh tokens give an error, `f.calls == maxLogPages`, and `NotErrorIs(errRunaway)`. A runaway guard of 1000 keeps a broken cap from hanging the test. This is meaningful. tdd-red.log shows a FAIL with the old helper and tdd-green.log a pass.
- Error propagation, multi-page accumulation and the stopAtFirst early return are **not** tested, although the packet claimed error and multi-page coverage. See Low L2.

### Transform filter
- `"About to transform"` is a quoted-phrase CloudWatch Logs pattern. It matches the trace log in dstransform/main/main.go:67/69 in both forms: `Msgf("About to transform: '%s'")` and `Msg("About to transform")` with RawJSON.
- It excludes the runtime START/END/REPORT lines.
- The Floci run shows "per-record log events since run start: 1".

### logLevel=trace scope
- A repo-wide grep at 14aad90b finds `logLevel: trace` only in go-services/ingestionsvc/deployment/service-test/provision-config.yaml:11.
- No deployment/default or production config uses trace. All other service-test, testdata and groundzero configs are debug.

### Gates
- r2 logs, each tagged with sha/HEAD 14aad90b, all rc=0:
  - gofmt
  - golangci-lint with e2e,floci tags (0 issues)
  - root `make lint-arch`
  - `go vet -tags=e2e,floci`
  - tidy
  - unit, including `-run TestFilterLogEvents` (2 PASS)
  - Floci service test with `-race` (ok, 236.6s; TestIngestionServiceFlow PASS)
  - TDD red then green logs are present. svcroot-wrapper.log is empty again (Info carried).
- Own rerun in a clean temp worktree (removed afterwards):
  - `gofmt -l .` is empty.
  - `go vet ./...` rc=0 and `go vet -tags=e2e,floci ./...` rc=0.
  - `go test -race -count=1 -run TestFilterLogEvents ./...`: both PASS, rc=0.

### Findings
- [Low] [testable] logpages_unit_test.go — the claimed error and multi-page cases are missing. Nothing tests that a `NextPage` error is returned with the partial events, that events from several pages accumulate, or that `stopAtFirst` returns on the first non-empty page after empty ones. Fix: give `fakeLogs` scripted pages and errors, and add these three cases.
- [Info] [non-testable] logpages_test.go:29-30 — `StopOnDuplicateToken` ends paging without an error. For the "no error events" checks, a backend that repeats a token while holding more events would end in a pass. This is SDK end-of-results semantics and is acceptable. An error on a duplicate token would be stricter.
- [Info] [non-testable] service-test/provision-config.yaml:11 — trace makes dstransform log full raw record payloads (main.go:60-62 warns about this). That is fine for Floci test data. If this config is ever run against a real AWS account, test payloads land in CloudWatch. The transform check now depends on trace, which the const comment documents.

### Verdict: APPROVED at 14aad90b (1 Low, non-blocking)

## Delta 3 (14aad90b..9f33caca) — APPROVED

Head confirmed 9f33caca (did not move). One commit: "test(ingestionsvc): keep trace logLevel out of the template region and count transform logs per record". 4 files, +103/-7. Process note: `df -h` ran after the checks rather than first (/ is at 33%, 86G free).

Verified
- yaml-equivalence: I parsed 14aad90b and 9f33caca with PyYAML myself. They are equal (`common.logLevel: trace` in both). Putting logLevel after the `# end::service-override[]` comment is valid YAML because it is still indented under `common`.
- Markers: the only reader is deployment/_design/provision-config.adoc:371 (`include::...[tag=service-override]`). It is an AsciiDoc include, not tooling. The docs snippet now leaves out trace, which is what we want. The snippet is still valid YAML and still matches the bullet list after it. No Go or yaml tooling reads these tags.
- Count: Eventually now waits until `>= recordsSent` (stopAtFirst=false, so all pages are read), then `require.Equal` runs after it. dstransform main.go:60-70 is an if/else, so it writes one trace line per record. No double count. The r3 service log shows "1 (records sent: 1)".
- Scripted fakes: the three cases mean what they claim. Error after partial events returns ErrorIs plus the partial [a,b]. Accumulation works across an empty middle page (4 calls). stopAtFirst skips 2 empty pages and stops at call 3. The fake fails on any read past the script.
- Gates (r3): gofmt, golangci (0 issues), lint-arch-root, tidy, vet, unit and test-service are all rc=0, and each has a sha/HEAD 9f33caca header. The aborted 67878d42 log is clearly labelled as superseded.
- My rerun in a clean worktree: gofmt clean, vet clean (untagged and e2e,floci), `go test -race -run TestFilterLogEvents` 5/5 PASS. The worktree was removed.
- Title and subject have no W-/T- prefix. No plan IDs in the service-test code.

Findings
- [Info] [hard-to-test] sinks_helpers_test.go:115 — strict `==` fails if Firehose or Lambda re-invokes the transform (a retry after a timeout or error). It also only samples once, right after the count reaches >=1, so a late duplicate is not caught. This is acceptable because a retry is itself a defect signal. Fix (optional): log the stream names in the failure message to help triage.
- [Info] [non-testable] r3/yaml-equivalence.log — one line ("yaml same: True trace") with no command or sha header. My own parse confirms the result. Fix: record the command and the two shas.
- Carried forward: unit gate has no -race (Info, from Delta 1).
