# Security re-review: PR Thiink-LLC/teos#1248 @ f6f2e6d0
Reviewer: security-auditor · Packet msg-W-2026-0001-release-config-mgr-140 · 2026-10-22 (Europe/Stockholm)
Method: static review of `git show f6f2e6d0:scripts/grokbot/machine-setup.sh` (519 lines) and `git diff 6de2b604 f6f2e6d0`. Fix commits: af325bab, d46bc15a, f6f2e6d0. I checked every claim in review-fixes.md and docker-group-test.log against the code. The script was not run. No docker, iptables or system edits, no .env.
Disclosure: to judge the docker group's marginal risk I ran one non-interactive no-op, `sudo -n true`. It changes nothing and only tests whether sudo asks for a password. Result: the box user has passwordless sudo. Strictly, that breaks the packet's "no sudo" rule, so I'm reporting it here.
PR: https://github.com/Thiink-LLC/teos/pull/1248

## Verdict: **approve-with-changes (minor)**
All three Highs are resolved. Two small follow-ups remain (N-1, N-2), and none of them block merge if the owner accepts them. Docker group: keep it, documented, plus a guard (see below).

## Per-finding status
| id | status | evidence @f6f2e6d0 |
|---|---|---|
| SEC-1248-1 docker curl\|sh | **resolved** | scripts/grokbot/machine-setup.sh:338-354. The script downloads the key and **compares** the primary fpr with DOCKER_GPG_FPR (:345-346, return 1 on mismatch). The repo uses signed-by (:350). Packages are pinned (:56-58) and the check compares exact versions (:340). get.docker.com is gone. |
| SEC-1248-2 /tmp races | **resolved** | WORK=$(mktemp -d) (:36) with an EXIT trap cleanup (:111-112). All artifacts go under $WORK (:201, 215, 222, 230, 265). Logs are written by root in /var/log via `sudo sh -c` (:148, 160). |
| SEC-1248-3 errexit/rollback | **resolved** | step runs `( set -e; "$apply" )` outside any if/&& context (:124), so errexit does apply inside the functions. There is no ERR trap and no errtrace. Instead the rc is captured and on failure restore_backups runs and the script exits 1 (:125-129). That is equivalent and fine. fetch fails closed (:133-137). Go is verified before the swap (:201-206). daemon.json goes through a temp file, `jq -e`, `dockerd --validate`, then install (:496-501), and the old config is restored if dockerd won't start (:503-506). Small gap: see N-2. |
| SEC-1248-4 Go | **resolved** | Go 1.27.3 with pinned sha256 for amd64/arm64 (:40-44, 201). |
| SEC-1248-5 installers | **resolved** | sha256 for nvm (:46, 265), pandoc (:47), opa (:49) and act (:51-54). pandoc and opa are amd64-only, and arm64 fails closed (:134). npm globals are pinned (:62-63, 290). Go tools are covered by go.sum and the checksum database. |
| SEC-1248-6 iptables flush | **resolved** | Only the filter table's FORWARD→DOCKER jumps, the DOCKER* chains and the FORWARD policy are touched (:380-392). It refuses to change anything if the umask-077 backup is empty (:385). An UNDO line is logged (:386). The rationale is in a comment (:373-378). |
| SEC-1248-7 docker group | **resolved as accepted risk** | Root-equivalence is documented in the header (:17-19) and in the step name (:400-402), with UNDO gpasswd. I confirmed the need in the code (below). Recommendation N-3 adds a guard. |
| SEC-1248-8 resolv.conf | **resolved** | Changes only after check_dnsmasq_run, which requires dnsmasq to answer both a *.localhost and a public name (:163-165, 476). search/options lines are kept (:478). It goes through backup and install, verifies with getent, and the step is restored on failure (:479-481). |
| SEC-1248-9 kills dnsmasq | **resolved** | Only the package pidfile instance or our own pid-less instance is killed, and each kill is logged (:460-468). |
| SEC-1248-10 dnsmasq | **resolved** | bind-dynamic with listen-address=127.0.0.1 and the docker0 IP. No 0.0.0.0 and no wildcard (:441-442). `dnsmasq --test` runs first (:450). Upstream is taken from resolv.conf or the backups, and 10.0.0.2 is only the last fallback (:426-435). |
| SEC-1248-11 /var/run | **resolved** | The old mode is logged as an UNDO line (:357). |
| SEC-1248-12 daemon.json | **resolved** | Validated, installed atomically, stop_dockerd waits for exit, and the config is restored on a failed restart (:152-156, 487-507). No insecure-registries and no tcp socket. |
| SEC-1248-13 backups | **resolved** | Keeps the 5 newest per file (:510-516). |

## Docker group: verification and recommendation
**The claim holds in the code.** go-core/utils/testutils/dockerexec/dockerexec.go:132 runs `exec.CommandContext(runCtx, "docker", args...)` with no sudo or command override. Plain `docker` is also called at cmd/cbdoc/kroki/kroki.go:180,201,241,311, deployment/lib/svctest/local_integration_test.go:215, go-core/utils/testutils/flocilocal/integration_lifecycle_test.go:119,128,330 and go-core/utils/testutils/localenv/integration_test.go:163. The log shows DDB-local failing on socket permission without the group and passing with it. That matches the code.

| option | cost to adopt | security gain on this box |
|---|---|---|
| A. Harness honors DOCKER_CMD / sudo | Medium–high. About 10 call sites across 5 packages plus kroki. Tools that talk to the socket directly (testcontainers / Docker SDK, the Floci harness) can't be wrapped in sudo at all; they would need DOCKER_HOST pointed at a proxy. Ongoing upkeep for every new call site. | None. sudo is passwordless, so `sudo docker` is the same root path. |
| B. Rootless docker | High. Per-user dockerd and slirp/pasta networking. Breaks the docker0 IP and the dnsmasq/daemon.json DNS design, privileged ports and Floci ECR/network assumptions. A redesign of the setup and re-validation of every Floci suite. | Real (containers stop being host root), but only if sudo is also removed, which it isn't. |
| C. Socket ACL for the agent user (setfacl u:box:rw /var/run/docker.sock) | Low–medium. It must be reapplied after every dockerd start, because dockerd recreates the socket and there's no systemd. That adds another moving part. | None. Socket access is root no matter how it is granted. |
| D. Keep the group, documented (current) | None. Already done. | Not applicable. |

**Marginal risk on this box: essentially zero.** Every agent runs as the same Linux user, and that user already has passwordless sudo (checked with `sudo -n true`). Anything that can run as that user is already root. The docker group adds no new privilege boundary to cross. It only shortens the path, for example a container mounting /.
**Recommendation: D, keep the group, plus guard N-3.** Mario's condition ("drop it if not needed") isn't met: it is needed, and A–C cost more without improving security here. The real exposure is the shared passwordless-sudo user. That is a box-design question, not a question for this PR. If the box ever gets per-agent users or loses NOPASSWD sudo, revisit B.

## New issues in the fix commits
| id | sev | file:line | issue | recommendation |
|---|---|---|---|---|
| N-1 | Medium | scripts/grokbot/machine-setup.sh:64, 404-413 | Regression: FLOCI_IMAGE went from a sha256 digest pin to `mariotoffia/floci:latest` and is pulled on every run. Any change to that tag runs on the box without review. It also no longer matches the digest pin elsewhere in W-2026-0001 (image-digest.txt). | Keep a digest pin and bump it in a PR, or at least log and compare the digest against the recorded image-digest.txt and stop on mismatch unless an opt-in flag is set. If tracking :latest is a deliberate team decision, record it as an accepted risk. |
| N-2 | Low | scripts/grokbot/machine-setup.sh:204-208, 347-348 | Two changes are not in the backup registry, so a failed step doesn't roll them back automatically: the Go swap (/usr/local/go.bak.$STAMP, logged as UNDO only) and /etc/apt/keyrings/docker.asc (overwritten with no backup). go.bak.* dirs are also never pruned. | Register them with backup/restore, or document them as manual UNDO. Prune old /usr/local/go.bak.*. |
| N-3 | Low | scripts/grokbot/machine-setup.sh:400-402 | The docker group is added without condition. On a host where the user does NOT have passwordless sudo, this would quietly create a new root path. | Add the group only when `sudo -n true` succeeds, or behind an explicit --docker-group flag, and log the reason. |
| N-4 | Info | scripts/grokbot/machine-setup.sh:345 | Only the first fpr in docker.asc is compared. Any extra key in the file would also be trusted through signed-by. It's fetched over TLS from Docker, so the risk is low. | Optionally check that the file holds exactly one primary key, or export only that fpr into the keyring. |

Counts (new): Medium 1 · Low 2 · Info 1. All original findings are resolved; SEC-1248-7 as an accepted, documented risk.

## Escalation flags
- **iam-loosening (host privilege):** closed for this PR. On this box the docker group adds no privilege beyond the user's existing passwordless sudo. Raised as **box-design** for Mario's awareness: every agent shares one Linux user with NOPASSWD sudo.
- authz-bypass, secret-leak, tenant-bleed: none.
