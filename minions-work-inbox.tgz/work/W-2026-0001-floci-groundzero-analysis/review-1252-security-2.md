# Security re-review: PR #1252 @88f6e88f (since 2aaf336e)
Reviewer: security-auditor · 2026-10-23 (Europe/Stockholm) · git diff only. I ran no sudo, executed nothing and read no .env.
Commits: 3541fb31 (#1248: --allow-downgrades comment), 4e83a3be (B-1..B-5), 6c8bd9f4 (code-review follow-up), 88f6e88f (merge of #1248 @3541fb31).

## Verdict: **approve**. All of B-1..B-5 are resolved. Two new findings, both Low, are optional and don't block merge.

## Status of the earlier findings
| id | status | evidence |
|---|---|---|
| B-1 C flag | Resolved (documented) | The script comment explains each of POCF and why C is accepted. GROKBOT.md lists the flags `POCF`. r2-4 log: `flags: POCF`. |
| B-2 interpreter unchecked | Resolved | binfmt_registered now also requires `interpreter /usr/bin/qemu-aarch64`. A foreign or other-interpreter entry is replaced. Magic and mask are still not compared; that's acceptable because only root can register entries. |
| B-3 network | Resolved | Both the binfmt container and the test container run with `--network none`. |
| B-4 spurious UNDO | Resolved | It returns early when the registration is already correct, and the UNDO line is logged only after a successful install and verification. |
| B-5 pin context | Resolved | The comments record the tag/version for both pins: binfmt "latest as of 2026-10-23, qemu-aarch64 v10.2.3" and alpine "3.24.3". |
| I-1 (#1248) | Resolved | 3541fb31 adds a comment explaining --allow-downgrades. |

Also improved: `--check` now only reads `/proc/sys/fs/binfmt_misc` and runs no container.

## The save-and-re-register rollback
- **Where the saved state comes from:** the saved entry is read from the kernel's own `/proc/sys/fs/binfmt_misc/qemu-aarch64` (root-owned and written only by the kernel). It is kept in a shell variable, with **no temp file**, so the mktemp, permission and TOCTOU questions don't apply. A user-writable saved file that could be tampered with doesn't exist.
- **Injection:** fields are parsed with awk by keyword and rebuilt as `:qemu-aarch64:M:off:magic:mask:interp:flags`. The rollback re-registers exactly the entry that was active a moment before, so it can't introduce an interpreter or flags that weren't already active. It only restores state that was rejected for being non-compliant (no F, or the wrong interpreter). That's intended (restore what was there before), and only root could have created that state. The entry name is fixed (`qemu-aarch64`) and the destination is the root-only `register` file.
- **F-flag nuance (Info):** if the old entry had F, re-registering it re-opens the interpreter *path* now. If that path changed in the meantime, a different binary gets pinned. Writing there needs root, so this is accepted.
- **set -e:** the step runs inside the step() subshell. `if ! docker … || ! binfmt_registered` and the `[ ] || …` / `… && log` lists are all errexit-safe, and the function ends with `return 1`, so the step fails and the run stops in the usual way.

## New findings
| id | sev | where | issue | recommendation |
|---|---|---|---|---|
| B-6 | Low | binfmt_register_line / rollback | If the rollback's `register` write fails (for example the old entry was extension-type `E`, so there's no `magic` line, or the field format was unusual), the `printf … | sudo tee … && log` list fails silently: no log line, and the previous entry is lost. | Add `|| log FAIL "rollback of qemu-aarch64 failed; previous entry: <old line>"` so the old register string is logged for a manual restore. |
| B-7 | Low | rollback | A previously **disabled** entry (`disabled` in /proc) comes back **enabled**, because the register string doesn't carry the enabled state. | After re-registering, write `0` to the entry if it had been disabled, or document this. |

The rollback paths (replacing an existing entry, and a failed install) are still untested on the box per pr-body. They fail closed: the step fails and the run stops.

## #1248
The head is now 3541fb31; the only delta since c3c4a816 is the comment. My approve verdict for #1248 still stands.

## Escalation flags
None (no authz-bypass, secret-leak, tenant-bleed or iam-loosening).
