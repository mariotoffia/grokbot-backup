# Code review: PR #1271 (Thiink-LLC/teos), ingestionsvc docs
- Head SHA: 55b5f33a8acdca5325ed5e272ae869a401b78f69 (unchanged from requested 55b5f33a)
- Closes: #1258; 7 files, all under go-services/ingestionsvc/
- **Verdict: APPROVED** (only Low findings)

## Gates
| Gate | Result |
|---|---|
| Docs vs code | PASS. Spot-checked against handlers/dstransform/main/main.go, ingestioncore/*.go, errorcodes/codes.go, deployment/stack.go, deployment/stack_part2.go, manifest/*, .go-arch-lint.yml and Makefile. Every line anchor checked (stack_part2.go#L118 IoT SQL, stack.go#L165 enable check, main.go#L28/#L75/#L89/#L101/#L219, serialization.go#L12, transform.go#L21/#L54) points at the right code. Names, sizes and timeouts all match: Lambda 128 MB / 60 s / AL2023 / ARM64 / norpc; Firehose DirectPut, 60 s buffer, GZIP, ingestion/ and errors/ prefixes; 90-day expiry and 7-day abort; one-month log retention; the three stack outputs and their exports; force-enable; manifest pn/pd/pt/st/fd and the groundzero dependency; lookup.IngestionObjectCreatedTopic in actuationsvc/deployment/stack_part2.go:279 |
| Governance docs (DDD/UBIQUITOUS/ARCHITECTURE/LINT) | PASS, all four present |
| docs/adr + docs/plans layout | PASS. NNNN-kebab ADR name; README.md index, same as go-services/eventsvc/evidencemonitor/docs/{adr,plans}. gobridge uses plans/_index.md, so the repo mixes both styles. The referenced root LINT.md, root docs/adr/0001-go-arch-lint-map-per-service.md and the LINT.md "Adding a map" anchor all exist |
| W-/T- prefixes | PASS. PR title and commit subject "docs: ingestionsvc service docs"; issue title "ingestionsvc: add service docs (DDD, ubiquitous language, architecture, lint, ADRs, plans)" |
| Plan IDs (AGENTS.md:277) | PASS. grep '\b[WT]-[0-9]{4}' over the PR files finds nothing |
| cspell (`npx cspell@8 -c cspell.json <files>`) | PASS: "Files checked: 7, Issues found: 0" |
| markdownlint (`npx markdownlint-cli2 <files>`, repo has no config, so defaults apply) | PASS: "Linting: 7 files, 0 issues" |
| CI (gh pr checks 1271) | GREEN. CodeQL, Analyze (actions) and Analyze (javascript-typescript) pass; Build, Architecture, Static Analysis and Unit Tests skipping (path filters). Both Analyze jobs were pending at the first check and passed on the recheck |
| Issue #1258 | Assignee mariotoffia; labels documentation, core; Priority=Medium, Size=Hours; board Status **Progress** (not Incoming); Roadmap unset |

## Findings
- **Low L-1** DDD.md "Context" (Category line): stray ")" in "`core` in the manifest, provider type `transformation`)".
- **Low L-2** ARCHITECTURE.md "Error codes", 2802: says "the shadow has no building id". In the code, 2802 is raised per sensor in TransformDsSensorToReport for an empty buildingID (ingestioncore/transform.go:67-71). A topic with no building id already fails earlier inside ToDsBuilding/NewDsFullBuildingWithTopic as 2800 (go-core/model/dsmodel/building.go:200 SetBuildingID). Suggest "buildingID empty at transform (normally unreachable; topic decode failures are 2800)".
- **Low L-3** ARCHITECTURE.md "Output modes": does not mention that when array mode fails to marshal, the record's data becomes a bare "\n" (main.go:160-183, rr.Data = append(rd, '\n') with rd nil). Edge case only.
- **Low L-4** Issue #1258 board Status is Progress, not Incoming (defensible while the PR is open).
- Info: the doc's own "Open points" (2803 naming inversion, the stale ExtractSensorComponents code comment at transform.go:17-20, omitempty on c/o, objectExpirationDays missing from the schema, root.md wording) are accurate against the code.

## Evidence
```
gh pr view 1271 --json headRefOid,title,commits,files
git fetch origin pull/1271/head:refs/pr/1271; git worktree add --detach /tmp/w1271 refs/pr/1271 (removed after)
cat -n handlers/dstransform/main/main.go ingestioncore/*.go errorcodes/codes.go; grep deployment/stack*.go
npx -y cspell@8 --no-progress -c cspell.json <7 files>; npx -y markdownlint-cli2 <7 files>
gh pr checks 1271; gh issue view 1258; gh api graphql issueFieldValues/projectItems
```

## Delta 1 (55b5f33a..4c3aedd8), reviewed 2026-10-24 12:25 CEST
- Head: 4c3aedd86de7b5c3918d003de176b992fcad08ea (matches the claimed head). Commits: 71de5670, d2daabcb, 4c3aedd8
- **Verdict: CHANGES_REQUESTED.** Blocked by pending CI; one new Low below.

| Gate | Result |
|---|---|
| L-1 stray ")" | FIXED (DDD.md Context) |
| L-2 2802 wording | FIXED. ARCHITECTURE.md error list and DDD.md rule 2 now say "empty building id, per sensor; a topic with no building id fails earlier as 2800". Matches transform.go:67-71 and the 2800 path in ToDsBuilding |
| L-3 bare newline in array mode | FIXED. "A record that fails to serialize is emitted as a bare \n" matches main.go:160-183 |
| Regrouped open points | Mostly accurate. The 2803 inversion, the stale comment at transform.go:17-20, objectExpirationDays missing from the schema, and the Makefile having no `lint` target (matches LINT.md Known gaps) are all correct. "Not a bug": CbSensorReportItem.MarshalJSON (go-core/model/ingestionmodel/types.go:161-165) omits c/o only when they are 0 and writes -1, as stated. See D1-L1 |
| cspell change | LEGITIMATE. 4c3aedd8 only changes "serialise" to "serialize" in ARCHITECTURE.md. No cspell.json change (empty diff vs main), no new words/ignore directives |
| cspell / markdownlint (local) | PASS: 7 files, 0 issues each |
| Commit subjects / plan IDs | PASS (no W-/T- prefixes; no plan IDs in files) |
| CI | PENDING: CodeQL, Analyze (actions), Analyze (javascript-typescript) pending; rest skipping |
| Temp checkout | /tmp/w1271 removed and worktree pruned |

Findings:
- **Low D1-L1** ARCHITECTURE.md Open points: the root.md item is filed under "Corrected here:", but manifest/features/root.md is not in this PR (the 7 changed files contain no root.md change). The section intro also still says "none is changed here". Either include the root.md wording fix or move the item back under the tracked follow-ups.

## Delta 2 — 4c3aedd8..2d59cb27 (head verified 2d59cb27, unchanged)

**Verdict: APPROVED**

Commit: `2d59cb27 docs: ingestionsvc feature note sns wording` (no W-/T- prefix).

- D1-L1 resolved. root.md:15-16 now says the service "Publishes to its own SNS topic; `actuationsvc` subscribes to it". That matches the code: ingestionsvc `deployment/stack.go:357` sends S3 OBJECT_CREATED (`ingestion/` prefix) to `ingestionsvc-s3-object-created` and exports `IngestionObjectCreatedTopicArn` (stack.go:362-365). actuationsvc `deployment/stack_part2.go:279` looks it up with `lookup.IngestionObjectCreatedTopic(stack)` and adds an SQS subscription with RawMessageDelivery.
- The ARCHITECTURE.md Open points intro ("No code is changed in this PR; only the last item is a doc fix made here") now agrees with the "Corrected here:" item, which is written in the past tense and is in this diff.
- root.md:4: "standardised" changed to "standardized"; legitimate.
- cspell: 0 issues (2 files). markdownlint-cli2: 0 issues. No plan IDs.
- CI: CodeQL, Analyze (javascript-typescript) and Analyze (actions) pass. Architecture, Build, Static Analysis and Unit Tests were skipped (docs-only). Nothing is pending or red.
- Carried over: Low on the #1258 board status (Progress) is unchanged; it does not block.

## Delta 3: 2d59cb27..b8ea2be7 (head verified b8ea2be7; only ARCHITECTURE.md changed)

**Verdict: APPROVED**

Commit: `b8ea2be7 docs: ingestionsvc copilot review fixes`. It has no W-/T- prefix, and the diff has no plan IDs. The diffstat shows 1 file changed (+10/-4).

### Claim 1: buffering hints apply to S3 delivery

Correct. In `deployment/stack_part2.go`:

- `BufferingHints{IntervalInSeconds: 60, SizeInMBs: 5}` (:60-63) sits on `ExtendedS3DestinationConfiguration` (:55).
- The Lambda processor (:70-83) sets only the `LambdaArn` parameter (:77-78). It has no `BufferSizeInMBs` or `BufferIntervalInSeconds`, so Firehose uses its defaults for the processor.

### Claim 2: the 200-byte limit applies only to ToDsBuilding's own preview

Correct. `ingestioncore/serialization.go:24-27` truncates its preview to 200 bytes, but :29-31 appends `err.Error()` unchanged.

- That error comes from `NewDsFullBuildingWithTopic` (serialization.go:20, called at `go-core/model/dsmodel/building.go:195`).
- That function calls `NewDsFullBuilding` (building.go:171). On a JSON unmarshal failure it embeds `string(payload)` in full (:174-178), so warn logs can contain the whole record.

### Gates

- cspell and markdownlint-cli2: 0 issues.
- CI at 12:50 CEST: CodeQL and both Analyze jobs pass. The other checks were skipped, including Cursor Security Agent and Cursor Bugbot. Nothing is pending or red.

### Carried over

- Low: issue #1258's board status is Progress. It does not block.
- Info: the doc now records the full-payload warn log as a fact. A code fix (truncate or wrap the inner error) belongs in a follow-up, not in this docs PR.
