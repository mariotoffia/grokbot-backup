# Audit: PRs that test only Floci, not TEOS (W-2026-0001)

Directive (Mario, 15:24): "Go through all PRs that actually just test floci emulator not the TEOS functionality - all that shall be removed."
Classification only. I made no pushes, closes, comments or commits.
Auditor: Code Reviewer minion, 2026-10-23 (UTC+2).

Scope: open PRs whose branch matches W-2026-0001* or whose body mentions it, plus the PRs listed in the brief.
- #1257 has branch `chore/ingestionsvc-arch-lint-map`, with no W id. I included it because the brief names it and #1255 depends on it.
- No other open PRs matched.

## Summary

| PR | Title | Head | Class | Tests/files to drop | Notes |
|---|---|---|---|---|---|
| #1242 | test(groundzero): API Gateway v1 contract cases on Floci | 75c3be6b | **B** | Whole PR: `apigw_contract_test.go` (both tests), the README.md section, and the go.mod `cloudwatchlogs` line | Builds its own throwaway REST API with a MOCK integration and deploys no TEOS stack. Both tests check emulator/AWS parity only. Recommend closing #1242 and #1241. |
| #1248 | machine setup script for the Linux build box | 36292726 | N/A | none | Box infrastructure (script + docs), no tests |
| #1250 | buildingsvc: add go-arch-lint map and lint-arch target | 798b11c5 | N/A | none | Architecture lint config for TEOS code, no tests |
| #1252 | build: machine-setup check-mode gap, arm64 binfmt, restore-script parity | 8cac9d1d | N/A | none | Box infrastructure, no tests |
| #1255 | test(ingestionsvc): assert Firehose transform and Logs output on Floci | 9f33caca | **A** (one borderline file) | none required. Optional: `logpages_unit_test.go` (see borderline 2) | Runs the deployed TEOS ingestion pipeline end to end and asserts its config and dstransform output |
| #1257 | ingestionsvc: add go-arch-lint map and lint-arch target | 7139f4b8 | N/A | none | Architecture lint config, no tests |
| #1260 | docs: ADR for a go-arch-lint map per service | 392d8a7e | N/A | none | Docs (ADR) only |

## Per-PR detail

### #1242: Class B, remove
File: `deployment/stacks/groundzero/service-test/apigw_contract_test.go`, build tags `e2e && floci`.
- The setup (`newContractAPI`, about line 215: `CreateRestApi`, MOCK integration, `ApiKeyRequired`) builds a throwaway API inside the test. It does not deploy groundzero or any product stack, and the file's own header says "It deploys no product stack and depends on no product API's auth configuration".
- `TestRestAPIContract` (:80) has 7 subtests (:84, :88, :93, :100, :107, :112, :138). They assert API Gateway's own 403/200 responses and `{"message":...}` bodies for missing, unknown, disabled, unbound and unlinked keys and for an unknown path. No TEOS handler, Lambda or authorizer is involved, so this is AWS parity on Floci. **Drop.**
- `TestTheLogsCapEvictsNothingUnderNormalVolume` (:162) writes events with PutLogEvents (:184) and reads them back with GetLogEvents (:190) to pin Floci's 20,000-event CloudWatch Logs cap. This is pure emulator behaviour. **Drop.**
- `README.md`: the whole new file documents only the Floci log cap. **Drop.**
- `go.mod`: `+ cloudwatchlogs` is needed only by the dropped test. **Drop.**
- Net effect: nothing remains, so close the PR and issue #1241. My earlier code-review APPROVED (R2) is moot.

### #1255: Class A, keep
Directory: `go-services/ingestionsvc/deployment/service-test/`
- `ingestion_test.go` `TestIngestionServiceFlow` (:42). The PR removes the Floci skip (old :43-46) and adds step 7 (:302-303). The test drives TEOS: IoT shadow update → TEOS IoT rule → Firehose → TEOS `dstransform` Lambda → S3, and validates `CbSensorReportItem`. **Keep.**
- `sinks_helpers_test.go` `assertFirehoseDeliveryStream` (:51) checks that TEOS's deployed delivery stream config is correct: the transform Lambda, GZIP, the target bucket and the log group. That is deployment/provisioning logic. **Keep.**
- `sinks_helpers_test.go` `assertLogsOutput` (:93) asserts that the TEOS transform Lambda logged once per record and that the TEOS Firehose and IoT-rule error log groups are empty. That is TEOS behaviour. **Keep.**
- `logpages_test.go` `filterLogEvents` (:28) is a pagination helper used by the assertions above. **Keep.**
- `logpages_unit_test.go` (:66, :77, :138, :150, :162: duplicate token, page cap, partial error, accumulate, stopAtFirst) has unit tests of the test helper against a fake client. These test neither Floci nor TEOS product code. **Borderline**, see below.
- `provision-config.yaml`: logLevel debug → trace, scoped to service tests. Not a test, but see borderline 3.
- `go.mod`: SDK dependencies for the helpers. **Keep.**

### #1248, #1252: N/A
`scripts/grokbot/machine-setup.sh`, `GROKBOT.md` and the README are setup for the Linux build box (Docker, binfmt, dnsmasq, Node, cbdeploy). They are infrastructure, not tests, so the directive does not apply.

### #1250, #1257: N/A
`.go-arch-lint.yml`, Makefile `lint-arch` and `LINT.md` are static architecture rules for TEOS services. No tests.

### #1260: N/A
ADR 0001 and the ADR index. Docs only.

## Borderline calls needing a decision
1. **#1242, whole PR.** You could argue it pins AWS edge behaviour that TEOS clients depend on (the shape of API-key 403s). But no TEOS code or stack is under test, and that is exactly the case the directive describes, so I classed it B. If Mario wants the edge contract kept, it would have to be rewritten against a deployed TEOS API.
2. **#1255 `logpages_unit_test.go`.** It tests a test-only helper, not Floci and not TEOS product code. It is not in scope for "only tests Floci", so keep it by default. Drop it only if the intent is "no tests that don't exercise TEOS".
3. **#1255 `provision-config.yaml` logLevel trace.** Not a Floci-only test, so it stays under the directive. It is flagged because the transform-count assertion depends on trace logs, which contain raw payloads. It is limited to service tests.
4. **#1255 dependency on #1257.** If #1257 stays open, #1255's service-level lint-arch is still n/a. Not a Floci issue.
