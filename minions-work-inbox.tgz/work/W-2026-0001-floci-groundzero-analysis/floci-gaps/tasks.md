# Floci gaps hit by W-2026-0001: draft task entries (for dev-lead)

Drafted 2026-10-22 (Europe/Stockholm) by golang-pro (msg-197). Docs only. This file does NOT edit
Mario's floci/.vscode/TEOS_GROUNDZERO_TASKS.md. Task numbers 50.x are placeholders: dev-lead picks the
real numbers after checking for duplicates.
The style reference is the box copy /workspace/minions/inbox/floci-groundzero/TEOS_GROUNDZERO_TASKS.md
(mtime 2026-10-21 19:44). It predates Task 48 and Task 49, so neither is in it. Task 49 is described only in
STATUS.md (10:13) and stale-markers-scan.md. UNVERIFIED: whether Mario's copy has gained a Firehose-CFN or SQS-metric entry since then.
Floci source read: /workspace/repos/floci at upstream/main 5beb8d47b (2026-10-22 05:09 Europe/Stockholm).

| Gap | Draft | Status | Duplicates | Blocks |
|---|---|---|---|---|
| FG-1 Firehose CFN drops ProcessingConfiguration/CloudWatchLoggingOptions | 50.1, plans/FG-1.md | NEW | none found (4.2 is the IoT firehose rule action, a different thing) | T-27.16.4 / teos#1232 (local commit f7acb910, unpushed) |
| FG-2 no AWS/SQS metrics | 50.2, plans/FG-2.md | NEW (dev-lead said in qa-verdict it would record this; UNVERIFIED whether that entry exists yet) | none in box copy | T-27.16.1 / PR #1240 alarm subtest (MANUAL_VERIFY) |
| FG-3 IoT shadow deep merge/metadata | plans/FG-3.md | RESOLVED: Floci Task 48 (+ 9.6), image a31d6e08 | 9.6, 48 | none now. Was T-27.21 / PR #1226 |
| FG-4 usage plan apiStages read-back | plans/FG-4.md | DUPLICATE of 44.1 (still open at 5beb8d47b) | 44.1 (44.2 needs it) | 27.1 caveat (ANALYSIS), 27.28 key binding, 3 TEOS skip sites |
| (no id; was FG-5) 27.29 gzip body, not a gap | none | Does NOT reproduce on a31d6e08 (impl/T-27.29/gates/gzip-probe-output.txt); fixed by 44.3 / floci#5131 | 44.3 | none |
| FG-8 27.29 log import never reaches CloudWatch | plans/FG-8.md (no 50.3: duplicate; numbering left to dev-lead) | DUPLICATE, open on a31d6e08 | 9.2/9.3 (message suffix), 49.1 (PutLogEvents missing group) | T-27.29 / PR #1238 |
| Task 49 / stale-scan gaps (Logs suffix, missing group, UpdateThing merge, retained epoch, scope 401, data-plane Publish, greedy, RetainResources) | none | DUPLICATE: already recorded (9.2, 9.3, 16, 42.1, 44.4, 44.5, 44.7, 49.1) per STATUS 10:13 | see stale-markers-scan.md §3 | not W-2026-0001 tasks in flight |

Side note on the 27.29 gzip probe (no id; was FG-5), unverified: in the probe the execute-api vhost URL (`<id>.execute-api.localhost.floci.io:47566/test/logs`)
printed an empty body for both POSTs, while the `/restapis/.../_user_request_/` path worked. Whether this is a
probe/DNS artefact or a Floci gap is unknown. It is not raised as a gap.

---

## Task 50: Floci gaps found by W-2026-0001 (draft)

Found 2026-10-22 by the W-2026-0001 Floci groundzero work on `mariotoffia/floci:latest`
sha256:a31d6e08, while un-skipping TEOS service tests 27.16.4 and 27.16.1. Causes read on
`upstream/main` `5beb8d47b`.

- [ ] 50.1 **Forward a CloudFormation Firehose stream's processing and logging configuration.** Thiink-LLC/teos#1232: the ingestion service's `AWS::KinesisFirehose::DeliveryStream` declares a Lambda transform in `ExtendedS3DestinationConfiguration.ProcessingConfiguration`. On Floci the S3 object holds the raw shadow document, not the transformed NDJSON, and `DescribeDeliveryStream` returns no `ProcessingConfiguration`. Read: `services/cloudformation/provisioners/FirehoseCfnProvisioner.java:39-59` reads only `CompressionFormat`, `BucketARN`, `Prefix` and `BufferingHints`. It drops `ProcessingConfiguration`, `CloudWatchLoggingOptions`, `ErrorOutputPrefix` and `RoleARN`. The API path already transforms (`FirehoseLambdaTransformer`, floci #3393). What a person sees: a CDK/CFN-created stream never calls its transform Lambda, so nothing is transformed and the Lambda writes no logs. Change: on create and update, resolve the intrinsics in these four properties and store them the way `CreateDeliveryStream` does. Acceptance: a stack stream with a Lambda processor has `ProcessingConfiguration` in `DescribeDeliveryStream`, a record put to it is delivered to S3 transformed, and `CloudWatchLoggingOptions` reads back. TEOS 27.16.4 reruns on f7acb910.
- [ ] 50.2 **Publish AWS/SQS queue metrics.** Thiink-LLC/teos PR #1240 (27.16.1): the eventsvc monitor alarm on `AWS/SQS` `ApproximateNumberOfMessagesVisible` (QueueName dimension) never leaves OK when the quarantine queue holds a message. Read: `AWS/SQS` occurs nowhere in `src/main`. What a person sees: queue-depth alarms never fire locally. Change: emit the AWS/SQS queue metrics (at least `ApproximateNumberOfMessagesVisible`, `ApproximateNumberOfMessagesNotVisible`, `ApproximateAgeOfOldestMessage`, `NumberOfMessagesSent/Received/Deleted`) per queue into CloudWatch metrics, so `GetMetricData` and alarm evaluation see them. Acceptance: an alarm `Maximum >= 1` over 1 period on a queue goes to ALARM after one message is sent and back to OK after a purge, with no `PutMetricData`. TEOS removes the 27.16.1 skip.
