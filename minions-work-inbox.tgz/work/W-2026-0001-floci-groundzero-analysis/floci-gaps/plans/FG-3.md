# FG-3: IoT shadow deep merge / per-leaf metadata (27.21). RESOLVED

Status: RESOLVED by Floci Task 48 (local ledger entry, upstream/main db76a5e5f; Floci PR closed per Mario, STATUS.md 2026-10-21 16:38).
Related ledger item 9.6 (shadow metadata). Fixed in image a31d6e08 (pinned at STATUS.md 11:47).

## Repro (historical)
Two nested UpdateThingShadow calls. On the old image 9710d466 the second update replaced the nested state, and the test got "expected -14.1 actual nil".

## Expected AWS behaviour
The shadow merges desired/reported leaf by leaf and keeps per-leaf metadata timestamps.
https://docs.aws.amazon.com/iot/latest/developerguide/device-shadow-data-flow.html (HTTP 200 checked 2026-10-22)

## Actual Floci behaviour now (evidence)
/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.21/evidence.md:4,9,16. On a31d6e08 the probe shows a deep merge with per-leaf metadata. cbtarget -race: 24 pass / 0 fail / 0 skip.

## Floci code location
services/iot (shadow handling). The exact fix commit is not on the box ledger copy; see Task 48 in Mario's file.

## Acceptance test
Already met: TEOS sensor filter tests pass unskipped (PR Thiink-LLC/teos#1226).

## Blocks
Nothing now. corerouter TestMirrorIngestFlow/IdtFlow skips in T-27.21 evidence:33 belong to the 27.16.3 topic-rule gap, not this one.
