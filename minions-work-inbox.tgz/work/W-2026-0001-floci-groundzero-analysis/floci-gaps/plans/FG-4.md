# FG-4: usage plan apiStages not returned. DUPLICATE of Floci 44.1

Status: DUPLICATE of 44.1 (open). 44.2 (floci#5450) depends on it.

## Repro
`aws apigateway create-usage-plan --name p --api-stages apiId=<id>,stage=v1`, then get-usage-plan / get-usage-plans: no apiStages
(stale-markers-scan.md, probe on 9710d466). Not re-probed on a31d6e08 (UNVERIFIED), but the source is unchanged (see below).

## Expected AWS behaviour
UsagePlan.apiStages = [{apiId, stage, throttle}], and GetUsagePlans honours keyId.
https://docs.aws.amazon.com/apigateway/latest/api/API_UsagePlan.html (HTTP 200 checked 2026-10-22)

## Actual Floci behaviour (evidence)
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/stale-markers-scan.md table rows and spot-check #5: buildingsvc TestLCSAPIClient fails "Could not find usage plan: 'system' for API: 'lcs'".
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/ANALYSIS.md 27.1 caveat.

## Floci code location
/workspace/repos/floci/src/main/java/io/github/hectorvent/floci/services/apigateway/ApiGatewayController.java:2459-2471:
toUsagePlanNode writes only id, name, description and tags (checked @5beb8d47b). The model already stores the stages (UsagePlan.java:17, ApiGatewayService.java:1516).

## Acceptance test
As 44.1: create and CFN ApiStages read back from both GET calls, and add/remove patches work.

## Blocks
TEOS skip-key-bind sites buildingsvc helpers_api_test.go:223, sur helpers_auth_test.go:209, testutils/integrationtests/client.go:180,
27.1 caveat, and 27.28 (via 44.2).
