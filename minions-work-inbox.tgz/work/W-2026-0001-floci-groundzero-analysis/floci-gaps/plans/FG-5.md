# FG-5 (draft 50.3): CloudWatch alarm does not return to OK after its datapoints stop

Status: NEW. Found 2026-10-22 on mariotoffia/floci:latest@sha256:a31d6e08 (T-27.16.1, PR Thiink-LLC/teos#1240). Source read at /workspace/repos/floci 5beb8d47b.

## Repro
1. Create a metric alarm in the TEOS monitor.go shape: namespace AWS/SQS, metric ApproximateNumberOfMessagesVisible, dimension QueueName=q, Statistic Maximum, Period 300, EvaluationPeriods 1, Threshold >= 1, TreatMissingData notBreaching.
2. PutMetricData with one datapoint of value 1. The alarm goes to ALARM, as expected.
3. Send no more datapoints. Poll DescribeAlarms for more than one period, 8 minutes in this run.

## Expected AWS behaviour
Once the period that holds the breaching datapoint has passed, the period is missing. With notBreaching, the alarm goes back to OK.
https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html#alarms-and-missing-data

## Actual Floci behaviour (evidence)
- impl/T-27.16.1/gates/test-service-0ab00e78.log:26 says `must reach OK by itself within 8m0s (last state seen: "ALARM")`.
- The alarm does go to OK once a non-breaching value of 0 is put (gates/test-service-d3e75aa1.log). So evaluation runs, and only the missing-data path is wrong.

## Likely Floci code location (UNVERIFIED hypothesis)
src/main/java/io/github/hectorvent/floci/services/cloudwatch/metrics/AlarmEvaluator.java.
- Around lines 96-107, the evaluator prefers real datapoints that reach further back.
- At line 146 and after, `real.size() >= evaluationPeriods` seems to keep counting the older breaching datapoint, so the missing-data branch (around lines 157-168, notBreaching) is never reached.
- Check how the evaluation window is bounded by the period before deciding the fix.

## Acceptance test
For the alarm in the repro: one datapoint of 1 gives ALARM. With no more data, the alarm is OK within about one period plus one evaluator tick, without PutMetricData or SetAlarmState.

## TEOS removal pointer
Thiink-LLC/teos `go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:158-163` (PR #1240, HEAD b049c8ae (local)).
- Remove the `floci: ... (Floci gap FG-5)` comment and `putDatapoint(0)`, so the subtest waits for OK with no data.
- Rename the subtest back to "... cleared when data stops".
