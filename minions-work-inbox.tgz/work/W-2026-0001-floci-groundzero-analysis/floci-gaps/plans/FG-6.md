# FG-6 (draft 50.4): CloudWatch DescribeAlarmHistory is not supported

Status: NEW. Found 2026-10-22 on image a31d6e08 (T-27.16.1, PR Thiink-LLC/teos#1240). Source read at /workspace/repos/floci 5beb8d47b.
This replaces the earlier T-27.29 FG-6, which golang-pro stream 2 renamed to FG-8 at 20:33 CEST (msg-210).

## Repro
`aws cloudwatch describe-alarm-history --alarm-name <any> --history-item-type StateUpdate` (the SDK uses the JSON protocol).

## Expected AWS behaviour
It returns AlarmHistoryItems, with a StateUpdate item ("Alarm updated from OK to ALARM") for each state change.
https://docs.aws.amazon.com/AmazonCloudWatch/latest/APIReference/API_DescribeAlarmHistory.html

## Actual Floci behaviour (evidence)
impl/T-27.16.1/gates/test-service-0ab00e78.log:31 shows `api error UnsupportedOperation: Operation DescribeAlarmHistory is not supported by CloudWatch JSON.`

## Floci code location
- src/main/java/io/github/hectorvent/floci/services/cloudwatch/metrics/CloudWatchMetricsJsonHandler.java:57-78. The switch has no `DescribeAlarmHistory` case and falls to `default -> 400`.
- src/main/resources/aws/query-services.json:1486 lists the operation. The Query handler is unverified.
- Change: record a history item on every state transition in CloudWatchMetricsService and AlarmEvaluator (SetAlarmState too), and on configuration updates. Serve them from both handlers with AlarmName, HistoryItemType, StartDate/EndDate, MaxRecords/NextToken and ScanBy filters.

## Acceptance test
After OK, then ALARM, then OK, DescribeAlarmHistory returns StateUpdate items newest first. The summaries contain "from OK to ALARM" and "from ALARM to OK", and the HistoryData JSON has oldState and newState.

## TEOS removal pointer
Thiink-LLC/teos `go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:168-172` (PR #1240, HEAD b049c8ae (local)). Delete the `if onFloci() { ... Floci gap FG-6 ... return }` block, so the history assertion runs on Floci too.
