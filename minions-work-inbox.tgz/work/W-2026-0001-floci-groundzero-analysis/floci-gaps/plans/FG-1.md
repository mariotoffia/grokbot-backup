# FG-1 (draft 50.1): CloudFormation Firehose provisioner drops ProcessingConfiguration / CloudWatchLoggingOptions

Status: NEW. No existing Floci task found in the box copy of the ledger (4.2 is the IoT rule action).

## Repro
1. Floci mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1.
2. Deploy a stack with an AWS::KinesisFirehose::DeliveryStream whose ExtendedS3DestinationConfiguration has
   ProcessingConfiguration {Enabled: true, Processors: [{Type: Lambda, Parameters: [{ParameterName: LambdaArn, ParameterValue: !GetAtt Fn.Arn}]}]}
   plus CloudWatchLoggingOptions.
3. `aws firehose describe-delivery-stream`: ExtendedS3DestinationDescription.ProcessingConfiguration is missing.
4. PutRecord, then read the S3 object: it is the raw record, and the Lambda was never invoked.
TEOS repro: ingestionsvc service test (skip removed), commit f7acb910 in worktree W-2026-0001-t27-16-4-ingestion-firehose-logs.

## Expected AWS behaviour
CFN passes ProcessingConfiguration/CloudWatchLoggingOptions/ErrorOutputPrefix/RoleARN to the stream. Firehose invokes the
Lambda per buffer and delivers its output.
- https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-kinesisfirehose-deliverystream-extendeds3destinationconfiguration.html (HTTP 200 checked 2026-10-22)
- https://docs.aws.amazon.com/firehose/latest/dev/data-transformation.html (HTTP 200 checked)

## Actual Floci behaviour (evidence)
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.4/evidence.md: the S3 object (225 bytes .gz) holds raw shadow JSON. storeloader parses 1 empty item,
  ingestion_test.go:294 fails, and sinks_helpers_test.go:52 sees ProcessingConfiguration nil.
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.4/gates/test-service-run1.log (rc=1, 17:12-17:15 Europe/Stockholm)
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.4/gates/floci-gap-source.log (source excerpt)

## Likely Floci code location
/workspace/repos/floci/src/main/java/io/github/hectorvent/floci/services/cloudformation/provisioners/FirehoseCfnProvisioner.java:39-59
(last change 4e842a85a, 2026-10-02). The API path with transform support is services/firehose/FirehoseLambdaTransformer.java (#3393).
Unverified: the exact model setters the provisioner needs on DeliveryStreamDescription.S3Destination.

## Acceptance test
- Floci CFN test: a stack stream with a Lambda processor has ProcessingConfiguration and CloudWatchLoggingOptions in DescribeDeliveryStream.
- PutRecord leads to the Lambda being invoked once per buffer and the S3 object holding the Lambda output.
- Stack update that changes the LambdaArn is applied.
- TEOS: ingestionsvc service test green on f7acb910 with no test change (expected, unverified).

## Blocks
T-27.16.4 / Thiink-LLC/teos#1232 (local commit f7acb910, not pushed, no PR).
