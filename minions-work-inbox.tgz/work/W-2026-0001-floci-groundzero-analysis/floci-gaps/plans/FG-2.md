# FG-2 (draft 50.2): Floci publishes no AWS/SQS CloudWatch metrics

Status: NEW in the box ledger copy. qa-verdict.md says dev-lead records a Floci gap task for it (UNVERIFIED that it exists).

## Repro
1. Floci a31d6e08. Create queue q, then an alarm: namespace AWS/SQS, metric ApproximateNumberOfMessagesVisible, dimension QueueName=q,
   Maximum >= 1, period 300 (TEOS monitor.go:336-348 shape).
2. Send one message to q and wait more than 2 periods.
3. describe-alarms: StateValue stays OK (or INSUFFICIENT_DATA). get-metric-data for that metric returns no datapoints.

## Expected AWS behaviour
SQS sends queue metrics to CloudWatch every minute, so the alarm goes to ALARM.
https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-available-cloudwatch-metrics.html (HTTP 200 checked 2026-10-22)

## Actual Floci behaviour (evidence)
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/gates/test-service-run1.log: alarm never reached ALARM, rc=1 (per review-code.md:21)
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/qa-verdict.md: subtest MANUAL_VERIFY, Floci publishes no AWS/SQS metrics
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/review-code.md:9, review-test.md:8 (the Floci skip in mapping_alarm_runtime_test.go:103-106)
- Source: `rg 'AWS/SQS' src/main` in /workspace/repos/floci @5beb8d47b finds no match.

## Likely Floci code location
Emitter: services/sqs (queue counts) feeding services/cloudwatch/metrics/CloudWatchMetricsService.java. AlarmEvaluator.java already
evaluates stored datapoints (the PutMetricData subtest passes). Unverified: whether any AWS/* namespace is auto-emitted today. One
can serve as a pattern (ApplicationAutoScalingService references AWS/* metrics).

## Acceptance test
An alarm as in the repro goes OK -> ALARM after one SendMessage and -> OK after PurgeQueue, without PutMetricData.
GetMetricData returns ApproximateNumberOfMessagesVisible datapoints per QueueName.

## Blocks
T-27.16.1 / Thiink-LLC/teos PR #1240: the queue-metric alarm subtest (now MANUAL_VERIFY plus the Floci skip that review-code flags High).
Also review-test "ec-gap" (real-AWS path never run). That is out of scope, because the work is Floci only.
