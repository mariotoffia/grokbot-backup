# FG-8: T-27.29 "Failed to enumerate log streams". DUPLICATE of Floci 9.2/9.3 (suffix) and 49.1 (missing group)

Status: DUPLICATE, still open on image a31d6e08 (re-probed 2026-10-22 19:09 CEST). Numbered FG-8 per dev-lead msg-210 (FG-5..7 taken by the other stream).

## What fails
teos PR #1238, TestSurApiLogImportAndVerify (impl/T-27.29/gates/test-service-sur-4a413e84.log): ExportLogs succeeds, then for 60s
the test's DescribeLogStreams(logGroupName=/teos/rsid/log/svctest, orderBy=LastEventTime, descending=true, limit=10)
errors (wrapped by clwlog logstream.go:136 as "Failed to enumerate log streams").

## Probe (impl/T-27.29/gates/describe-log-streams-probe.txt, standalone Floci a31d6e08, dummy creds)
- DescribeLogStreams with the exact test params on an existing group: 200 with the stream. The operation and params are fine.
- Same on the missing group /teos/rsid/log/svctest: ResourceNotFoundException "The specified log group does not exist: /teos/rsid/log/svctest". So the group was never created.
- PutLogEvents to a missing group: ResourceNotFoundException "The specified log stream does not exist: nostream" (wrong resource, plus a ": name" suffix).

## AWS contract
API_PutLogEvents / API_DescribeLogStreams: ResourceNotFoundException. AWS text "The specified log group does not exist." for a missing group,
and "The specified log stream does not exist." for a missing stream in an existing group, with no name appended.
teos go-core clwlog put.go:248-256 is written against that exact text.

## Chain
logimport Lambda -> clwlog PutLogEvents with CreateStreamIfMissing(true) -> Floci answers the stream message with a suffix -> the switch at put.go:247
falls to default (LogErrorWhileLogPut), so the group is never auto-created -> no events -> the test's DescribeLogStreams gets ResourceNotFound.

## Verdict
Floci gap, primary: the message text and the resource check diverge from AWS. teos's code is AWS-correct, though it is brittle because it matches the exact message.
Fix path: Floci 9.2/9.3 (drop the ": name" suffix) + 49.1 (check the group first in putLogEventsForAccount, CloudWatchLogsService.java:684-690 @5beb8d47b).
Optional teos hardening (not done): match on the "log group"/"log stream" substring instead of the exact text.
Secondary, UNVERIFIED: the import Lambda should then return a 5xx, yet the test saw ExportLogs succeed. Check whether sendLogData's error reaches the client
(handler main.go -> httphandler.go:35, ExportLogs client) once the stack is up again.

## Blocks
T-27.29 / teos PR #1238 (keep it blocked; do not re-add a skip). Same root cause as the clwlog integration skips at cloudwatch_integration_test.go:168,207,237.
