# FG-7 (draft 50.5): API Gateway ApiKeyRequired 403 has no x-amzn-ErrorType header

Status: NEW. Found 2026-10-22 on image a31d6e08 (T-27.1, PR Thiink-LLC/teos#1242). Source read at /workspace/repos/floci 5beb8d47b.

## Repro
1. Create a REST API (key source HEADER) with a GET method where ApiKeyRequired=true and a MOCK integration. Deploy it to stage `test`.
2. Call `GET {AWS_ENDPOINT_URL}/execute-api/{id}/test/{path}` with no x-api-key, with an unknown key, with a disabled key, and with a key that is no longer bound.

## Expected AWS behaviour
The response is 403 `{"message":"Forbidden"}` with `x-amzn-ErrorType: ForbiddenException:http://internal.amazon.com/coral/com.amazon.coral.service/`. It is the INVALID_API_KEY / MISSING... gateway response, and API Gateway sets that header on its error responses.
https://docs.aws.amazon.com/apigateway/latest/developerguide/supported-gateway-response-types.html

## Actual Floci behaviour (evidence)
- impl/T-27.1/gates/test-service-591db968.log: the four forbidden cases fail with `x-amzn-ErrorType ""`. Status 403 and message "Forbidden" are correct.
- An unknown path does carry `MissingAuthenticationTokenException`.

## Floci code location
src/main/java/io/github/hectorvent/floci/services/apigateway/ApiGatewayExecuteController.java.
- :488 returns `gatewayResponse(scope, GatewayResponseType.INVALID_API_KEY, 403, "Forbidden")` without the header.
- Compare :3189 and :3212, which set `x-amzn-ErrorType`.
- Change: have `gatewayResponse` add x-amzn-ErrorType for each GatewayResponseType (ForbiddenException for INVALID_API_KEY, and the other types as AWS does).

## Acceptance test
Each of the four requests in the repro returns 403 `{"message":"Forbidden"}`, and x-amzn-ErrorType starts with `ForbiddenException`.

## TEOS removal pointer
Thiink-LLC/teos `deployment/stacks/groundzero/service-test/apigw_contract_test.go:328-333` (PR #1242, HEAD 87ab8715). Delete the `if errType == "" && harness.Target().IsLocal() { ... Floci gap FG-7 ... }` block in `assertForbiddenErrorType`.
