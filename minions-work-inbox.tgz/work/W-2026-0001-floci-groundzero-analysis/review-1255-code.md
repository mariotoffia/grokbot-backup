# Code review — PR #1255 (Closes #1232), T-27.16.4
Reviewer: code-reviewer · 2026-10-23 11:35 (UTC+2) · Verdict: **CHANGES_REQUESTED**
SHA reviewed: ce280894007f53bcce40d797f22d0c4304c7175a (PR HEAD unchanged). Merge-base origin/main dc86df55; delta 2 commits (f7acb910, ce280894), 3 files (go.mod, ingestion_test.go, new sinks_helpers_test.go). Not stacked.

## Findings
1. **High — standard linter gate not green at reviewed sha.** static-f7acb910.log is at f7acb910, not ce280894: `golangci-lint` rc=127 (not found) and a repo-target lint rc=1 (2 forbidigo context.Context hits). ce280894 claims to fix those, but no lint run at ce280894 is logged. Re-run gofmt/vet/golangci-lint/lint-arch at ce280894 and log sha, command, dir, rc=.
2. **High — gate logs incomplete.** static log has no sha/command/dir headers; service-local `make lint-arch` rc=2 (no target), only root rc=0 recorded. Required format per CONVENTIONS §1 not met.
3. **Medium — #1232 issue-first: board Status is "Progress", not Incoming; Priority and Size not set** (GraphQL shows only Status). Assignee (mariotoffia), labels (e2e, unit-test, core) OK; Roadmap unset OK.
4. **Low — `DescribeLogGroups` result discarded** in assertLogsOutput (sinks_helpers_test.go); redundant with FilterLogEvents error check — drop it or assert the group exists.
5. **Low — `runStart := time.Now().Add(-5s)`** uses a magic skew; name it as a const with a comment (clock skew vs emulator).

## Positive / verified
- Correctness: Floci skip removed; Firehose describe asserts ACTIVE, ext-S3 bucket, GZIP, Lambda transform ARN, CW logging group/stream; Logs asserts transform events (Eventually 90s/3s) and empty Firehose/IoT error groups. Uses ifcore.CbContext. go.mod promotes firehose/cloudwatchlogs to direct — correct. `//go:build e2e` tag present. No security concerns.
- Tests: test-service-ce280894-07ced9c6.log: HEAD ce280894, Floci mariotoffia/floci:latest (digest 07ced9c6 recorded, not pinned in code), `ok ... 156.150s`, rc=0. Floci evidence accepted (W-2026-0001 Floci-only).
- Floci pin: none found in delta.
- Title rule: PR title "test(ingestionsvc): assert Firehose transform and Logs output on Floci" and both commit subjects carry no W-/T- prefix — OK.
- Governance docs: no service-local DDD/UBIQUITOUS/ARCHITECTURE/LINT docs touched.

## Round 2 — delta ce280894..849de752 (2026-10-23 12:45 UTC+2)
Verdict: **PROVISIONAL APPROVED** (pending test-service -race log). SHA reviewed: 849de75274f004d5a88ba8373b31f5443b520977 (= PR HEAD).
Delta: 0ca387e5 (runStartClockSkew const + comment), 849de752 (drop unused DescribeLogGroups). Both correct; FilterLogEvents still fails on a missing log group so existence is still asserted. No Floci pin in code (logs use mariotoffia/floci:latest, digest 07ced9c6 only recorded).

Round 1 findings:
- H1 RESOLVED — golangci-849de752.log (`golangci-lint run --build-tags=e2e,floci`, rc=0; golangci-lint now installed); make-lint-849de752.log full `make lint` rc=0 (attempts 1/2 failed on missing webui/dist embeds, fixed by tklocal-react-build rc=0; env, not code).
- H2 RESOLVED — gofmt, vet (-tags=e2e,floci), tidy, lint-arch-root (9 maps), lint-arch-service (no service map; covered by root), make-test, test-integration (N/A, no integration pkg) all carry sha/dir/cmd/rc=0.
- M1 RESOLVED — #1232 issueFieldValues: Priority=Medium, Size=Hours; board Status=Incoming; title "Run the ingestionsvc pipeline service test on Floci and assert Firehose/Logs output" (no T- prefix).
- L1, L2 RESOLVED.
Title rule: PR title, all 4 commit subjects, issue title — no W-/T- prefix. OK.

Open:
1. **High (gating, pending)** — test-service-849de752-07ced9c6.log present but incomplete at review time (last line "No matching S3 event yet, retrying...", no rc= line). It also lacks `cmd` and `dir` header lines. Needed: that file completed with `ok` + rc=0 on mariotoffia/floci:latest, plus cmd (with -race) and dir headers. Turns APPROVED once that's in place.

## Final — 849de752 (2026-10-23 12:45 UTC+2)
Verdict: **APPROVED**. SHA: 849de75274f004d5a88ba8373b31f5443b520977 (PR HEAD confirmed unchanged).
test-service-849de752-07ced9c6.log: HEAD 849de752; image mariotoffia/floci@sha256:07ced9c6…, run as mariotoffia/floci:latest (no pin); `--- PASS: TestIngestionServiceFlow (80.21s)`, `PASS`, `ok … 146.694s`, `rc=0`, end 12:40:13 CEST; no DATA RACE / FAIL lines. Round 2 High closed.
Info: dir/cmd headers were added after the run (marked). Nothing in the log body shows race instrumentation (it only prints DATA RACE when a race happens), but the -v output fits the cmd line, and impl/_tools/svcroot.sh (mtime 11:06, before the 12:37 run) hard-codes `-race` on line 37. Accepted as Info, not blocking.
Open findings: none.
