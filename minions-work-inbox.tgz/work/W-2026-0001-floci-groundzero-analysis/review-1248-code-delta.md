# PR #1248 delta re-review (code-reviewer)

- Head: da3c2fb2fba6b89bda1db59f6173e9ec3838353d (unchanged, OPEN, not draft, 0 unresolved threads)
- Range reviewed: f6f2e6d0..da3c2fb2. That is 22 commits, covering GROKBOT.md and scripts/grokbot/machine-setup.sh. f6f2e6d0 is an ancestor of 3541fb31, so this covers both f6f2e6d0..3541fb31 (19 commits: Go version/GOBIN/GODIR rollback, OPA and tool version checks, DNS IPv4, merged dnsmasq step, ipt_legacy subshell, daemon.json mode, prune) and 3541fb31..da3c2fb2 (ae0d86f8, 9a152afc, da3c2fb2).
- Title: "machine setup script for the Linux build box". No W-/T- prefix. All 22 commit subjects are prefix-free.
- Gates: `bash -n` passes (rc 0). `shellcheck -x` gives rc 1 at the head; it was rc 0 at f6f2e6d0. There is no shellcheck job in CI or the Makefile.

## Verdict: CHANGES_REQUESTED

## Findings
- [Medium] [testable] scripts/grokbot/machine-setup.sh:370 (apply_rc, 9a152afc) — `stat -c %a "$HOME/.bashrc"` reads the symlink itself when ~/.bashrc is a symlink (common with dotfile managers). It returns 777 (verified: link=777, target=600). The script then does `chmod 777` on the temp file and `mv` replaces the link, leaving a world-writable ~/.bashrc and defeating the intent of the commit. Fix: `stat -L -c %a`, or write through the resolved path (`readlink -f`).
- [Low] [testable] scripts/grokbot/machine-setup.sh:368-372 — If chmod or mv fails inside `( set -e )`, rollback restores ~/.bashrc but leaves ~/.bashrc.XXXXXX behind. Fix: remove the temp file on failure (trap in the subshell).
- [Medium] [testable] scripts/grokbot/machine-setup.sh:463 (eed42527) — New shellcheck SC2024 (info) finding: `sudo "$IPTL-restore" <"$f"`. The file is clean at f6f2e6d0 and flagged at the head. It is not a CI gate; raise to High if shellcheck-clean is treated as a gate. Fix: the redirect works here because $f is user-readable in $WORK. Add `# shellcheck disable=SC2024` with a reason, or pass the file as an argument.
- [Low] [non-testable] GROKBOT.md:223 (da3c2fb2) — The root `go test` PATH now puts the user-writable ~/.local/bin first, so root runs whatever is there. The expansion is correctly quoted and is a one-off doc command, so idempotency and duplication are not a concern. The note line is 135 chars long, mid-paragraph. Fix: put ~/.local/bin after the system dirs, or name only the tools needed. Rewrap the line.

## Checks requested
- .bashrc mode: GNU `stat -c` is fine for this Debian/Ubuntu-only script. Symlinks are broken (above). Rollback is fine: backup() runs `cp -pL` before the change and step() restores it on failure.
- --check: WOULD-CHANGE increments PENDING (line 139), and line 626 still has `[ "$PENDING" -eq 0 ] || exit 3`. The missing Floci image now counts as pending. OK.

## Carried items
- N1 (go.bak rollback/prune): RESOLVED. GODIR rollback entry added, GO_VERSION>=GO_REQUIRED check, prune keeps 3 Go trees.
- N2 (prune drops original resolv.conf backup): RESOLVED. The oldest backup is kept.
- N3 (gpg|awk SIGPIPE): RESOLVED. gpg output is captured into a variable first (line 392).
- M3 (exit 3 / UNDO docs): RESOLVED. GROKBOT.md:39 documents exit 3, :51/:76/:206 cover UNDO.
- M6 ("never in teos source" vs #1244): RESOLVED in effect. #1244 is CLOSED, so the conflict is gone. The rule stays at GROKBOT.md:10.

## Delta 2: da3c2fb2..4c447ac7

- Head: 4c447ac7379cfee6af3d388e14d6e3980ea47205 (as expected). da3c2fb2 is an ancestor. 3 commits: cb8ad2ea, 5638f465, 4c447ac7. All subjects are prefix-free, and so is the PR title.
- Gates: `shellcheck -x` rc 0 and `bash -n` rc 0 (re-run here). They agree with 1248-sec-delta/m2-verify.log and m2-check-before/after.log (check summary changes=0, failed=0, rc 0). mask-test.log (777->755, 666->644) is consistent.
- --check: PENDING increments are unchanged (lines 145 and 503), and line 637 still has `[ "$PENDING" -eq 0 ] || exit 3`. OK.
- iptables-restore: the man page (iptables 1.8.13) gives the synopsis `iptables-restore [...] [file]`, and its description says to "specify file as an argument". The positional form is valid and has root read the file. M2 FIXED.
- GROKBOT.md:223 onwards: ~/.local/bin is now last in both examples and the text is rewrapped. L2 FIXED.
- daemon.json: `mask_go_w` on `stat -Lc` keeps the owner and clears g/o write. This is a sensible extra hardening.

### M1 re-test (temp HOME; the real ~/.bashrc was not touched)
I ran a harness built from apply_rc, step, restore_backups, mask_go_w and cleanup extracted from 4c447ac7. The setup was HOME/.bashrc -> dot/bashrc with the target at 0600.
- Success: the link is preserved, the target is written through and stays 600, the source line is first, and nothing is group- or world-writable. M1 FIXED.
- Forced `mv` failure: rc 1, the target is unchanged (600, original content), the link is intact, and the rollback is fine. But `dot/bashrc.XXXXXX` (600) is left behind.

### Verdict: CHANGES_REQUESTED (Low only; approve once L1 is fixed, or accept it as a waiver)
- [Low] [testable] scripts/grokbot/machine-setup.sh:132,379-382 — The L1 fix does not work. step() runs apply in `( set -e; "$apply" )`, so `RC_TMP=` is set only in that subshell. The parent's EXIT trap sees an empty RC_TMP, and the subshell never runs the EXIT trap. The temp file leaks on failure (reproduced). It is mode 600, so there is no exposure. The trap itself does not clobber anything: there is a single `trap cleanup EXIT`, and the rollback is unaffected. Fix: set an EXIT trap inside apply_rc after mktemp that removes the temp file (it runs in the subshell), or write the temp path to a file under $WORK so the parent cleanup removes it.
- Carried items N1-N3, M3 and M6 are still resolved.

## Final: 4c447ac7..f23dd485

- Head: f23dd48511da3a04f68c385881a97150fcad9367 (as expected). 1 commit, f23dd485 "build: clean bashrc temp file inside apply_rc". No W-/T- prefix.
- Gates: `shellcheck -x` rc 0 and `bash -n` rc 0 (re-run here). The SC2064 disable is justified because $tmp is expanded on purpose when the trap is set.
- --check: still ends with `[ "$PENDING" -eq 0 ] || exit 3` (line 639).
- Re-test (temp HOME, ~/.bashrc -> dot/bashrc at 0600, harness extracted from f23dd485):
  - Success: rc 0, the link is kept, the target is 600 with the source line first, 0 leftovers, 0 group/world-writable files, and the top-level trap is still `trap -- 'cleanup' EXIT`.
  - Forced mv failure: rc 1, the target is unchanged (600, original content), the link is kept, 0 leftovers, and the top-level cleanup still ran ($WORK removed).
- Trap scope: apply_rc is called only through step() at line 391, so it always runs in the `( set -e )` subshell. Its EXIT trap and `trap - EXIT` are confined to that subshell. Info: if apply_rc were ever called directly in the main shell, `trap - EXIT` would drop `cleanup`. A path containing `'` would break the trap quoting (not realistic for HOME).
- Matches 1248-sec-delta/l1-after.log (0 leftovers, .bashrc unchanged) and l1-verify.log (shellcheck, bash -n and --check all rc 0).
- L1: FIXED. All earlier items (M1, M2, L2, N1-N3, M3, M6) are resolved.

### Verdict: APPROVED at f23dd485

## Delta 3 (post-approval): f23dd485..36292726

- `df -h /`: 79G free (39% used). Head: 3629272620caac5452afbf3649cd6a8f60c8484f, as expected.
- Commits: 976af623, 6cc60c09, 078c5fe0, 4072ea39, 768f782d, 36292726. All are conventional `build:`/`docs(grokbot):` subjects with no W-/T- prefix. PR title "machine setup script for the Linux build box" is clean.
- Gates (run here): `shellcheck -x` rc=0 and `bash -n` rc=0 on the head script. The real `--check` (temp worktree, removed afterwards) gives rc=0, SUMMARY changes=0 would-change=0. No apply path was run and binfmt_misc was not touched.
- `--check` exit 3: a harness extracted from step/soft_step at head shows a pending step gives PENDING=1 and rc=3. A missing soft_step only WARNs and stays rc=0, as designed. Lines 142, 690-691 are unchanged.
- Regressions: none.
  - M1: the symlink mode is untouched (ln -sfn at 255 and 373).
  - L1: the per-subshell temp trap (402-411) and top-level cleanup are unchanged.
  - M2: the SC2024 disables at 491 and 651 are intact.
  - L2: root PATH still keeps ~/.local/bin last (GROKBOT.md 235 and 243).
- Per commit:
  - 976af623: root-owns Go before the mv. The act check matches the exact `act version X`. iproute2 and procps are added to APT_PKGS. The DOCKER-USER guard runs before any UNDO or switch in apply_ipt_alt, and after the backup but before any change in apply_ipt_legacy.
  - 6cc60c09: captures the chain into a variable before grep, so there is no SIGPIPE. `grep -x` anchors the whole alternation. An empty or missing chain counts as default. OK.
  - 078c5fe0:
    - The dnsmasq pid only counts when /proc/<pid>/comm is dnsmasq, which fixes stale or reused pids. It also filters the pgrep fallback, which previously matched the `sudo sh -c` wrapper.
    - The package cmdline is captured before the kill and restarted on rollback only when ours is not running.
    - soft_step restores backups on failure, and only a verified apply increments CHANGES.
  - 4072ea39: pnpm checks corepack lastKnownGood.json `.pnpm`. The format was confirmed on the box (`{"pnpm":"10.33.0"}`).
  - 768f782d: oapi now uses an exact modver match, like regal. The nvm check runs in a child bash with `--no-use`, so it is side-effect free.
  - 36292726: docs only, accurate.
- Evidence (1248-copilot-r8): summary.md R7 says the Copilot pass on 36292726 was clean (no issues, none missed) and checks are pass/skipping. r8-check.log ends `changes=0 would-change=0 failed=0 mode=check`. Both are confirmed and match my own --check. Note: "green" means CodeQL passed and the other checks were skipped, not a full CI run.

### Findings
- [Low] [testable] scripts/grokbot/machine-setup.sh:249 — `sudo chown -R root:root "$WORK/go-new/go"` happens before the `sudo mv`. If the run aborts in between (the rm or mv fails), the user-run `cleanup()` (`rm -rf "$WORK"`) cannot remove the root-owned tree, which leaks into /tmp with permission-denied noise. Fix: chown after the mv (`sudo chown -R root:root /usr/local/go.new`), or make cleanup use `sudo rm -rf` for go-new.
- [Info] [hard-to-test] machine-setup.sh:613-615 — `mapfile </proc/$pkg/cmdline` fails if the package dnsmasq exits between the pid check and the read. Inside the step's `set -e` subshell that aborts the apply and rolls back, which is safe, but the cause is not logged. Optional fix: `|| pkg_cmd=()` with a log line.
- [Info] [non-testable] soft_step: `--check` returns rc=0 while cbdeploy is missing, even though apply would try to install it. This is a documented design choice (make build owns it).

### Verdict: APPROVED at 36292726 (1 Low, non-blocking)
