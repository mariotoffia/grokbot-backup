# Security delta check: PR #1248, 1bd4d95e → dcd0282f
Reviewer: security-auditor · 2026-10-22 (Europe/Stockholm) · git diff/show only. No sudo, nothing run, no .env.
Range: 163d9b63, 4fc25574, 9d638e8c, 4265b733, 89b367a2, 465fbb3c, dcd0282f (GROKBOT.md and machine-setup.sh).

## Verdict: **approve** (one Low doc follow-up, D-1)

## (a) Floci rule: resolved
machine-setup.sh:60-64 quotes Mario verbatim: "always use latest - it should be in the comment - we will never accept a pinning of the mariotoffia/floci image except latest!!". FLOCI_IMAGE is mariotoffia/floci:latest. The msg-133 reference is gone from the script and GROKBOT.md. GROKBOT.md "Floci image" states the same rule. log.jsonl:137 records the decision (release-config-mgr, source "Mario direct 2026-10-22 22:26 CEST", commit 4265b733). This closes N-5 and N-1, now accepted per Mario.
Minor provenance note: that entry's `via` field is msg-W-2026-0001-security-auditor-015. I didn't relay Mario's decision. The exact quote appears only in the commit, not in log.jsonl. This doesn't block merge.

## (b) Docker group step: removed
No usermod, no gpasswd and no `sudo -n` remain in the script (git grep @dcd0282f). ME= and the check/apply functions are gone. The only remaining mentions are in GROKBOT.md: the undo hint for people added by older versions (:223) and the cspell word list (:5). Both are fine. The comment (script :414-416, GROKBOT.md :215-217) says group membership is root-equivalent because a member can mount the host fs from a container. That is accurate.

## (c) Tests as root
GROKBOT.md:219 and script :415 say "Tests that need Docker access run as root with sudo". Neither gives a concrete `sudo env -i HOME=/root … go test` command. In effect, though, the docs tell agents to run go test as root.
Risks:
- Test code from any PR branch runs as root. On this box (shared user, passwordless sudo) that gives no extra privilege, but it does widen the blast radius of a mistake (rm -rf in a test, writes outside the repo).
- Root-owned files appear in the worktree (testdata outputs, coverage, generated files, .worktrees) and in any shared cache when HOME/GOCACHE/GOMODCACHE are not separated. Later non-root builds then fail with permission errors.
- `env -i` drops PATH, GOFLAGS, GOWORK and proxy settings. Tests then run with a different toolchain or config than CI.

| id | sev | location | issue | recommendation |
|---|---|---|---|---|
| D-1 | Low | GROKBOT.md:219; machine-setup.sh:415 | "Run tests as root" is policy without a safe recipe. It risks root-owned files in the repo and caches, and runs arbitrary test code as root. | Document one recipe: `sudo env -i HOME=/root PATH=/usr/local/go/bin:/usr/bin:/bin GOCACHE=/root/.cache/go-build GOMODCACHE=/root/go/pkg/mod go test …` so root has its own caches. Run only the Docker-dependent packages that way. Afterwards, `sudo chown -R "$USER": <worktree>` or check with `find . -user root`. Alternatives: a socket ACL (setfacl u:<user>:rw on docker.sock, reapplied on each dockerd start) or a DOCKER_HOST proxy. Those would let tests run as the normal user, but they are root-equivalent just like the group, and on this passwordless-sudo box they give no security gain, so Mario's no-group choice stands. |

## (d) Regressions: none
I checked SEC-1248-1..13 and N-2/N-3/N-4. N-3 is now moot because the step was removed. The fingerprint-set check, fetch sha256, subshell set -e with rollback, iptables backup refusal, the resolv.conf gate, the dnsmasq binds and the daemon.json validation are all unchanged. The only script changes are the comments and the removed group step. GROKBOT.md additions (rollback and prune docs, key rotation steps, container→Floci networking) match the code and contain no secrets.

## Escalation flags
None.
