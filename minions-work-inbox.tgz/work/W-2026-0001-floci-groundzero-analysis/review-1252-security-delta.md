# Security delta review: PR #1252, 901ae3ed → 57708ced (head confirmed)
Reviewer: security-auditor · 2026-10-23 (Europe/Stockholm) · static review (git diff and evidence logs). I ran no sudo, made no binfmt writes, executed nothing and read no secrets.
Commits: 768f782d, 36292726, ba062a7a (merge of #1248 fixes), f053fc58, 6ee90a10, e2b9a5db, 4a0628b3, 57708ced.

## Verdict: **approve**. T-1, T-2 and T-3 are resolved. No new findings above Info.

## Status of my #1248 Lows
| id | status | evidence / assessment |
|---|---|---|
| T-1 identity check | **Resolved** | `is_dnsmasq_pid` requires a numeric pid, `sudo readlink /proc/<pid>/exe` **exactly equal** to `/usr/sbin/dnsmasq`, and `/proc/<pid>` owner uid in {0, nobody, dnsmasq}. Allowing nobody and dnsmasq is fine. A process's exe link can't be faked: it points at the binary that is actually executing, so a spoofer would have to *be* the real dnsmasq binary, and comm/argv tricks no longer work. dnsmasq drops to nobody or dnsmasq after start, so those uids are expected. The box user (uid 1000) running the real binary is rejected. If `id -u dnsmasq` fails, it yields "", which can never equal a numeric uid. **`(deleted)` suffix:** after a dnsmasq package upgrade the exe link reads `/usr/sbin/dnsmasq (deleted)`. The strict comparison then treats the process as not dnsmasq. That fails closed (the process isn't signalled; the new start fails on port 53 and is rolled back). It's operational, not security (I-1). |
| T-1 rollback | **Resolved** | The cmdline replay is gone. It restarts with a fixed command: `/etc/init.d/dnsmasq start`, else `/usr/sbin/dnsmasq -x /run/dnsmasq/dnsmasq.pid`, gated by a boolean `pkg_stopped`. |
| T-2 IPv6 | **Resolved** | `docker_user_custom` checks both iptables-legacy and ip6tables-legacy. The cleanup takes one 0600 user-owned backup per family (`<tool>.$STAMP.rules`, under umask 077, checked non-empty). Rollback restores every saved family with its own `-restore` and logs FAIL per family. A failed backup aborts before anything is touched. |
| T-3 fail closed | **Resolved** | A listing error is treated as "custom" in docker_user_custom, unless the output contains `No chain/target/match by that name`. In legacy_docker_state it becomes state ("listing failed"), so the check stays pending and the cleanup subshell exits 1 before cleaning. A localized error message would also fail closed. `-w 10` waits for the xtables lock. |

## Other items checked
- **Per-run STAMP** `YYYYmmddTHHMMSS-$$`: unique across concurrent runs (a pid can't be shared at the same second) and still sorts by time for pruning. The rules backups keep umask 077 (0600, user-owned). System `.bak.$STAMP` files are created through `backup()` as before. Writes use `>` rather than O_EXCL, but with time plus pid a collision isn't realistic (I-2, no action needed).
- **EXIT trap restarting dockerd:**
  - The marker file `$WORK/dockerd-stopped` is created in the step subshells and seen by the parent through the filesystem, which is the correct way to cross the subshell boundary.
  - `cleanup` restarts only if the marker exists **and** `! pgrep -x dockerd`, so it can't restart twice. Success paths remove the marker once dockerd is up.
  - It runs on normal exit, `exit 1` from step() and set -e exits. Bash also runs EXIT traps on SIGINT and SIGTERM, but not on SIGKILL (I-3).
  - `start_dockerd || log FAIL` can't abort the trap.
  - No trap is clobbered: apply_rc's EXIT trap lives only in its subshell.
  - `rm -rf "$WORK" || sudo rm -rf "$WORK"`: WORK comes from `mktemp -d` under set -e, so it's never empty. Using sudo rm on it is acceptable.
- **Go:** the chown to root now happens after the move into /usr/local/go.new (no root tree is left in WORK). The download is still sha256-verified.
- **binfmt UNDO:** the log line contains the old register string, `%q`-quoted, so it's log text only and nothing is executed.
- **.profile newline fix, nvm `--no-use`, exact oapi-codegen version:** benign.
- **IPv6 cleanup** sets legacy ip6 FORWARD to ACCEPT only when DOCKER chains exist in that family and DOCKER-USER is at its default. That's the same accepted rule as IPv4, and nft rules aren't touched.
- **Evidence (r5):** check-before would-change=1, run changes=1, check-after would-change=0, failed=0 throughout.

## Info
- I-1: a dnsmasq that was upgraded while running (`exe … (deleted)`) is not recognized. It fails closed. Optionally strip ` (deleted)` and also compare the inode, or just log it.
- I-2: STAMP collision is theoretical only.
- I-3: on SIGKILL dockerd stays stopped. A rerun starts it again (the dockerd step).

## Escalation flags
None (no authz-bypass, secret-leak, tenant-bleed or iam-loosening).
