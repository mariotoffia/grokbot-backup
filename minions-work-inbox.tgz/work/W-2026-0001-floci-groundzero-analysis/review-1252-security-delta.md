# Security delta review: PR #1252, 901ae3ed → 57708ced (head confirmed)
Reviewer: security-auditor · 2026-10-23 (Europe/Stockholm) · static review (git diff and evidence logs). I ran no sudo, made no binfmt writes, executed nothing and read no secrets.
Commits: 768f782d, 36292726, ba062a7a (merge of #1248 fixes), f053fc58, 6ee90a10, e2b9a5db, 4a0628b3, 57708ced.

## Verdict: **approve**. T-1, T-2 and T-3 are resolved. No new findings above Info.

## Status of my #1248 Lows
| id | status | evidence / assessment |
|---|---|---|
| T-1 identity check | **Resolved** | `is_dnsmasq_pid` requires a numeric pid, `sudo readlink /proc/<pid>/exe` **exactly equal** to `/usr/sbin/dnsmasq`, and `/proc/<pid>` owner uid in {0, nobody, dnsmasq}. Allowing nobody and dnsmasq is fine. A process's exe link can't be faked: it points at the binary that is actually executing, so a spoofer would have to *be* the real dnsmasq binary, and comm/argv tricks no longer work. dnsmasq drops to nobody or dnsmasq after start, so those uids are expected. The box user (uid 1000) running the real binary is rejected. If `id -u dnsmasq` fails, it yields "", which can never equal a numeric uid. **`(deleted)` suffix:** after a dnsmasq package upgrade the exe link reads `/usr/sbin/dnsmasq (deleted)`. The strict comparison then treats the process as not dnsmasq. That fails closed (the process isn't signalled; the new start fails on port 53 and is rolled back). It's operational, not security (I-1). |
| T-1 rollback | **Resolved** | The cmdline replay is gone. It restarts with a fixed command: `/etc/init.d/dnsmasq start`, else `/usr/sbin/dnsmasq -x /run/dnsmasq/dnsmasq.pid`, gated by a boolean `pkg_stopped`. |
| T-2 IPv6 | **Resolved** | `docker_user_custom` checks both iptables-legacy and ip6tables-legacy. The cleanup takes one 0600 user-owned backup per family (`<tool>.$STAMP.rules`, under umask 077, checked non-empty). Rollback restores every saved family with its own `-restore` and logs FAIL per family. A failed backup aborts before anything is touched. |
| T-3 fail closed | **Resolved** | A listing error is treated as "custom" in docker_user_custom, unless the output contains `No chain/target/match by that name`. In legacy_docker_state it becomes state ("listing failed"), so the check stays pending and the cleanup subshell exits 1 before cleaning. A localized error message would also fail closed. `-w 10` waits for the xtables lock. |

## Other items checked
- **Per-run STAMP** `YYYYmmddTHHMMSS-$$`: unique across concurrent runs (a pid can't be shared at the same second) and still sorts by time for pruning. The rules backups keep umask 077 (0600, user-owned). System `.bak.$STAMP` files are created through `backup()` as before. Writes use `>` rather than O_EXCL, but with time plus pid a collision isn't realistic (I-2, no action needed).
- **EXIT trap restarting dockerd:**
  - The marker file `$WORK/dockerd-stopped` is created in the step subshells and seen by the parent through the filesystem, which is the correct way to cross the subshell boundary.
  - `cleanup` restarts only if the marker exists **and** `! pgrep -x dockerd`, so it can't restart twice. Success paths remove the marker once dockerd is up.
  - It runs on normal exit, `exit 1` from step() and set -e exits. Bash also runs EXIT traps on SIGINT and SIGTERM, but not on SIGKILL (I-3).
  - `start_dockerd || log FAIL` can't abort the trap.
  - No trap is clobbered: apply_rc's EXIT trap lives only in its subshell.
  - `rm -rf "$WORK" || sudo rm -rf "$WORK"`: WORK comes from `mktemp -d` under set -e, so it's never empty. Using sudo rm on it is acceptable.
- **Go:** the chown to root now happens after the move into /usr/local/go.new (no root tree is left in WORK). The download is still sha256-verified.
- **binfmt UNDO:** the log line contains the old register string, `%q`-quoted, so it's log text only and nothing is executed.
- **.profile newline fix, nvm `--no-use`, exact oapi-codegen version:** benign.
- **IPv6 cleanup** sets legacy ip6 FORWARD to ACCEPT only when DOCKER chains exist in that family and DOCKER-USER is at its default. That's the same accepted rule as IPv4, and nft rules aren't touched.
- **Evidence (r5):** check-before would-change=1, run changes=1, check-after would-change=0, failed=0 throughout.

## Info
- I-1: a dnsmasq that was upgraded while running (`exe … (deleted)`) is not recognized. It fails closed. Optionally strip ` (deleted)` and also compare the inode, or just log it.
- I-2: STAMP collision is theoretical only.
- I-3: on SIGKILL dockerd stays stopped. A rerun starts it again (the dockerd step).

## Escalation flags
None (no authz-bypass, secret-leak, tenant-bleed or iam-loosening).

---
## Delta @c9f11a29 (dnsmasq `(deleted)` exe), 2026-10-23 (Europe/Stockholm): head SHA reviewed **c9f11a29**
c9f11a29 is the current PR head. The only commit since e4155eb0 is c9f11a29, which changes 6 lines in machine-setup.sh. Static review.

### Verdict: **approve**. This closes I-1 from my previous section. One new Info item (I-4).

- **Exact match only:** `is_dnsmasq_exe` compares with `[ "$1" = /usr/sbin/dnsmasq ] || [ "$1" = "/usr/sbin/dnsmasq (deleted)" ]`. Inside `[ ]` with `=`, these are plain string comparisons (no glob or prefix matching; the right-hand side has no wildcards and the second one is quoted). `/usr/sbin/dnsmasq-evil`, `/usr/sbin/dnsmasq (deleted)x` and the empty string (readlink failure) are all rejected. `$(…)` strips only trailing newlines, so a crafted name containing a newline would have to be in /usr/sbin, which needs root.
- **Unchanged:** the numeric pid check, the uid rule {0, nobody, dnsmasq} and the fail-closed returns are as before.
- **Spoof analysis:**
  - `(deleted)` means the process exec'd the file that was at /usr/sbin/dnsmasq when it started, and that file has since been unlinked or replaced. /usr/sbin is root-only.
  - A file literally named `dnsmasq (deleted)` in /usr/sbin also needs root.
  - So in the host mount namespace this is no weaker than the original exact match.
- **I-4 (Info, not new in this commit):**
  - The script runs in the host pid namespace, so it sees container processes too.
  - Readlink of `/proc/<pid>/exe` is resolved against the reader's root. A file in a container's overlay rootfs, which isn't reachable from the host root, is shown relative to its mount. That often reads exactly `/usr/sbin/dnsmasq`.
  - So a dnsmasq running in a container, as root (no userns remap) or as nobody, can pass both the exe check and the uid check.
  - Exposure: only the pids in the root-owned `/run/dnsmasq/dnsmasq.pid` and `$DNSMASQ_PID` files, and processes whose command line contains `dnsmasq -C /etc/dnsmasq.d/teos-box.conf`. The only effect is `sudo kill`, since the root replay was removed in T-1. At worst a container process gets killed; there's no privilege gain.
  - Optional hardening: also require the process to be in the host's mount namespace (`[ "$(sudo readlink /proc/$1/ns/mnt)" = "$(readlink /proc/self/ns/mnt)" ]`) or check `readlink /proc/$1/root` = `/`.
- **The rest of the delta:** none (comment and function only).

### Escalation flags
None.

---
## Delta @09bef205 (keep dockerd marker until restart succeeds), 2026-10-23 (Europe/Stockholm): head SHA reviewed **09bef205**
09bef205 is the current PR head. The only commit since c9f11a29 is 09bef205: machine-setup.sh +2/-1, inside apply_ipt_alt's failure path. Static review.

### Verdict: **approve**. No new findings; one Info note (I-5).

- **Order:** on a failed switch, the iptables and ip6tables alternatives are put back to the old backend (`update-alternatives --set … "$old4"/"$old6"`) before `start_dockerd`. A restarted dockerd therefore comes up on the original backend, the same state as before the run.
- **After a failed start:**
  - The backend is the original one.
  - The legacy DOCKER-USER chain is untouched: apply_ipt_alt never edits rules, and docker_user_custom refuses the switch when custom rules exist.
  - With dockerd down, no container traffic flows. Host filter rules are not flushed by this path.
  - When dockerd is started later, by the EXIT trap, the dockerd step or a rerun, it re-creates its own DOCKER/isolation chains and an empty DOCKER-USER on the active backend, so isolation is rebuilt. This doesn't weaken anything: administrator DOCKER-USER rules were never removed, since the switch is refused when they exist.
- **Marker:**
  - Location: `$WORK` is a `mktemp -d` directory (mode 0700, owned by the user).
  - It's removed only after `start_dockerd` succeeds. If not, `cleanup` (EXIT) retries exactly once when the marker exists and `pgrep -x dockerd` finds nothing. A failure there is logged with `|| log FAIL`, so it can't abort or loop.
  - `rm -rf "$WORK"` then always runs.
  - The `|| true` on the line keeps `return 1` (and with it restore_backups and the stop) reached.
- **I-5 (Info):** start_dockerd only times out the readiness wait; it doesn't kill a slow dockerd. If dockerd comes up after 30 s, the trap's pgrep guard skips the retry, so no second dockerd is started. That dockerd still starts on the restored backend. This is acceptable.
- **Rest of the delta:** none.

### Escalation flags
None.

---
## Delta @17c16b3c (link_points_to helper), 2026-10-23 (Europe/Stockholm): head SHA reviewed **17c16b3c**
17c16b3c is the current PR head. The only commit since 09bef205 is 17c16b3c: machine-setup.sh +5/-3, in check_links. Static review.

### Verdict: **approve**. No findings; one Info note (I-6).

- **link_points_to:**
  - It's `[ "$(readlink "$LOCAL_BIN/${1%%=*}" 2>/dev/null)" = "${1#*=}" ]`. Everything is quoted, and the comparison is a plain string comparison (no glob).
  - It uses plain `readlink` (one level, no `-f`), so it checks the link's literal target and doesn't resolve through chains. A missing link or a non-link gives an empty string, so the check fails (pending/apply).
  - The function is defined before the `step` call that uses it (resolved at call time).
  - Behaviour change in check mode: before, any symlink counted as satisfied; now the link must point at the expected target. That's stricter, so it fails safe.
- **apply_links:** unchanged. It runs as the user (no sudo): `mkdir -p` and `ln -sfn "$target" "$LOCAL_BIN/$name"`, quoted. `-n` treats an existing symlink to a directory as the link itself, so `ln` replaces it instead of creating a link inside the directory it points to.
  - **I-6 (Info):** `-n` doesn't help when the name is a *real* directory. ln would then create the link inside that directory. That would need a user-created directory such as `~/.local/bin/node/` (same user, no privilege boundary). check_links would keep reporting it as failing, so it's visible.
- **Target trust:** the targets come from `$NVM_DIR=$HOME/.nvm/versions/node/v…/bin` and GOBIN, both owned by the user. The links themselves are in `~/.local/bin`, owned by the user. No root writes.
- **S-2 still holds:** the PATH snippet, root PATH handling and secure_path are not touched by this delta. The script's own PATH export (line 113) runs as the user and is unchanged.
- **Rest of the delta:** comment only.

### Escalation flags
None.

---
## Delta @e1bc4ca7 (marker order, relative links, docker info timeout, optional links), 2026-10-23 (Europe/Stockholm): head SHA reviewed **e1bc4ca7**
e1bc4ca7 is the current PR head. Commits since 17c16b3c: 0a27dcbd, 1d81ffbc, e1bc4ca7. Static `git diff` only; no shells or tests run.

### Verdict: **approve**. Three Info notes (I-7, I-8, I-9); no Low or higher findings.

- **Marker before stop_dockerd (1d81ffbc):**
  - The marker is written only inside the `if pgrep -x dockerd` branch. A dockerd that was intentionally down before the run never gets a marker, and is never started by the trap.
  - If the stop fails, apply_ipt_alt returns 1 *before* any `update-alternatives`, so the backend is unchanged.
  - The trap restarts dockerd only if it's gone (`pgrep` guard), and then on the original backend. If dockerd is still running, nothing happens.
  - **I-7 (Info):** a dockerd that is still shutting down when the trap runs passes the pgrep guard, so the trap skips the restart. Once it exits, dockerd stays stopped (fails safe and is logged; same class as I-3).
- **link_points_to (e1bc4ca7):** `[ -L link ] && [ "$(readlink -m link)" = "$(readlink -m target)" ]`.
  - Fully quoted; exact string compare.
  - The `-L` guard rejects regular files and directories.
  - `-m` normalizes `..` and relative targets against the link's directory, and works on targets that don't exist.
  - **I-8 (Info):** `readlink -m` *does* follow the whole symlink chain on both sides, the same as `-f`. So the check passes for any link whose chain ends at the same file as the expected target, not only the literal target. The resolved binary is identical, the links are in `~/.local/bin` owned by the user (same user, no boundary), and this is only a check result: apply always rewrites with the literal target. Acceptable. Stale links (old Node version) still resolve differently and are reported as pending.
- **`sudo timeout 5 docker info`:**
  - timeout runs as root and kills a hung client; there are no variable arguments.
  - A non-zero exit (including 124) means "not ready" and a retry; after 30 tries it returns 1, so it fails closed.
  - **I-9 (Info):** the worst case is about 30×(5+1) s ≈ 180 s, while the log line says "30s". This is a log-wording mismatch only.
- **Optional links (0a27dcbd):**
  - `OPTIONAL_LINKS=" cbdeploy "` matches the exact name (space-padded).
  - It only affects the check-mode prediction for a *missing* target. If the target exists, the link is still verified.
  - apply_links is unchanged (it already skipped missing targets).
  - cbdeploy is built from the repo, not downloaded. No checksum or pin verification is in this path or affected by it, so nothing security-relevant is hidden.

### Escalation flags
None.

---
## Delta @0a30f39f (restore iptables alternatives on legacy-cleanup rollback), 2026-10-23 (Europe/Stockholm): head SHA reviewed **0a30f39f**
0a30f39f is the current PR head. The only commit since e1bc4ca7 is 0a30f39f (+12/-2). Static `git diff`/`git show` only; nothing run.

### Verdict: **approve**. One Low (L-1, non-blocking) and one Info (I-10).

- **Capture:**
  - `ORIG_IPT4/6=$(readlink /etc/alternatives/ip{,6}tables 2>/dev/null || true)` runs once at script scope. That's after the earlier docker/package steps and before the step "iptables alternative = nft", so it's the pre-switch backend.
  - It's a one-level readlink of a link in a root-owned directory, so a non-root user can't plant a value.
  - An empty value means that family is skipped (`[ -z … ] ||`), so `--set` is never called with an empty string.
  - Anything that isn't a registered alternative is rejected by `update-alternatives --set` itself and goes to `log FAIL`. It can't point at an arbitrary path.
  - apply_ipt_alt now uses the same values (`old4=$ORIG_IPT4`), so its behaviour is unchanged.
- **restore_ipt_alternatives:**
  - Quoted.
  - It's a no-op when the current link already equals the original (the guard compare), so a rollback in a run that never switched does nothing.
  - Each family is independent; failures are logged with `log FAIL` and don't abort.
- **Ordering in the apply_ipt_legacy rollback:** `*-restore` of the saved legacy rules (v4 and v6) runs first, then alternatives back to the original, then `start_dockerd` (only if it was running). dockerd therefore builds its chains on the same backend as the restored rules, which is the original state. Nothing is flushed and no ACCEPT policy is set; only saved rulesets are restored. The earlier ipt_alt failure path (restore → start, @09bef205) is unchanged.
- **L-1 (Low, non-blocking):**
  - If one family's restore fails (for example v4 restored and v6 `--set` fails), the error is only logged and `start_dockerd` still runs, so v4 and v6 can end up on different backends.
  - Impact: dockerd's ip6tables chains go to a different backend than the restored v6 rules. That's only relevant with Docker IPv6 enabled (off by default). It is a mismatch or breakage, not an opened firewall: dockerd still creates its own isolation/DROP rules wherever it writes them, and the restored legacy rules remain.
  - Suggestion: if either `--set` fails, skip `start_dockerd` (leave the marker/log so it fails safe as "docker stopped").
- **I-10 (Info):** a rollback in apply_ipt_legacy deliberately reverts a backend switch that succeeded earlier in the same run, which is consistent with the restored legacy rules. The run then stops, because the step fails. Expected.

### Escalation flags
None.

---
## Delta @f234681a (EXIT trap restores alternatives before dockerd restart), 2026-10-23 (Europe/Stockholm): head SHA reviewed **f234681a**
f234681a is the current PR head. The only commit since 0a30f39f is f234681a (+6/-2). Static `git diff`/`git show` only; nothing run.

### Verdict: **approve**. L-1 still open (Low, non-blocking); nothing new.

- **Trap context:**
  - `trap cleanup EXIT` is at line 154; `ORIG_IPT4/6` and `restore_ipt_alternatives` are at lines 536-540, at script scope in the parent shell, so they're visible to the parent's trap.
  - The restore only runs when `$WORK/dockerd-stopped` exists. That marker can only be created at line 551 or later, after the variables and the function exist.
  - An exit before then never reaches the call. The `${ORIG_IPT4:-}` form also makes it safe under `set -u`, and an empty value means skip.
  - Quoting is fine.
- **Key point: no wrong revert of an intended switch on a successful run.** The trap acts only if the marker exists *and* `pgrep -x dockerd` finds nothing. On a run that succeeds:
  - After a successful switch, apply_ipt_legacy sees the marker, sets `was_running=1`, and must get `start_dockerd` to succeed (otherwise rc=1, which is a failed run).
  - It then removes the marker while dockerd is running.
  - The "dockerd running" step also requires `docker info` to answer.
  - So at a normal exit, dockerd is up and/or the marker is gone, and the trap does nothing. A switch done on purpose stays.
  - The revert only happens on a failed run that left dockerd stopped. Examples: a step between the switch and the legacy cleanup fails, or the legacy step returns early (backup failure, custom DOCKER-USER). In those cases a stopped dockerd must not come back on nft next to legacy FORWARD DROP, so going back to the original backend before the restart is the correct fail-safe. It's the same state as before the run.
- **Interaction with the rollback inside the step:** if apply_ipt_legacy already restored the alternatives, the guard compare (`current = ORIG`) makes the trap's call a no-op. Restoring twice is harmless.
- **L-1 (still open, Low):** in the trap, a failed `--set` is only logged and `start_dockerd` still runs, so v4 and v6 can end up on different backends (the same as in the step). The suggested fix still applies: have restore_ipt_alternatives return non-zero on any failure, and skip `start_dockerd` in both callers, logging "dockerd left stopped".

### Escalation flags
None.
