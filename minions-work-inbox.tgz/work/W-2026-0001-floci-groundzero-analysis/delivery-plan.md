# W-2026-0001: Delivery plan, Floci groundzero TEOS tasks

> **Floci image policy (overrides everything below and every packet P-2026-0001-08..32/34/36):** always use `mariotoffia/floci:latest`. Never pin a tag or digest. Any digest recorded in this plan, a task brief or evidence is the digest `latest` resolved to for that run, not a pin.

Author: the Project Lead minion (`project-lead`). Packet P-2026-0001-01. Rewritten under the MUST "we work as agents, not humans" (README, CONVENTIONS, agents/project-lead.md; msg-W-2026-0001-076/077).
Every teammate is an AI agent. Ready work starts **now**. Estimates are **active agent effort in minutes/hours** plus **named waits**. The only allowed waits are: Mario, a named blocker, a busy owner, or a running result that takes N minutes.

**Scope rule (Mario via dev-lead msg-W-2026-0001-dev-lead-094): Floci-only.** No real-AWS tests or deploys of any kind, including the shared dev account. Every gate is Floci-local.

Start gate: **go-approved** (Mario A/D/A, autonomous; recorded in STATUS.md). Repo flow (CONVENTIONS "Repository flows are authoritative" + teos GITHUB.md) applies to every task.

## Scope (one TEOS PR each)
27.1, 27.10, 27.12, 27.13 (closed inside the 27.14 PR; already on main), 27.14, 27.16.1, 27.16.2, 27.16.3, 27.16.4, 27.16.6, 27.20, 27.21 (**parked**), 27.25, 27.27, 27.29, and the 39.11 follow-up.
Out of scope: 27.28 (needs upstream 44.1) and the teos#902 switch back to `floci/floci`.

## Parallelism
At most 4 implementing owners for this feature, and 6 team-wide; file locks also limit it. A freed slot is filled **at once** by the next ready task.

## Per-PR flow: effort and running-result waits
| Step | Owner | Active effort | Running-result wait (N min) |
|---|---|---|---|
| Test plan / red tests | test-designer | 15–30 min | none |
| Implement + §1 gates (fmt, lint-go, interim arch gate, vet, test, tidy) + local Floci | golang-pro | 30–120 min (per task) | local integration/service test ≈ 10–20 min (gobridge ≈ 60 min) |
| Internal reviews (code, hexagonal, clean-arch in parallel) | reviewers | 15 min each | none |
| Push + draft PR + Copilot review request | dev-lead | 5 min | Copilot review ≈ 10–20 min |
| Copilot fix round + re-review of the latest commit | golang-pro | 10–30 min | Copilot ≈ 10–20 min |
| Workflows | CI | none | CI ≈ 15–25 min |
| Merge | Mario | none | **W-MARIO** |

## Gates (every task, Floci-local only)
1. `make fmt`, `make lint` (lint-go + interim arch gate: hexagonal + clean-arch sign-off, since lint-arch is missing), `make vet`, `make test`, `make tidy` with a clean diff.
2. Local Floci on digest 9710d466: go-core → `make test-integration`; service → `CB_SERVICE_TEST=<svc> make test-service`.
3. **Marker-deletion qualification:** the un-skipped test passes on local Floci at the resolved digest, with evidence: digest, executed tests listed apart from skips, and `rg` proof that the marker is gone. No real-AWS run happens (risk R15).

## Named waits
| Code | Meaning |
|---|---|
| W-MARIO | PR is **merge-ready** (internal reviews passed, Copilot reviewed, workflows green) and waits for Mario's merge or approval |
| W-DEP | Predecessor PR not yet merged (27.14→27.20, 27.25→27.16.6→27.16.1), or an upstream Floci fix is missing (27.21 → Floci Task 48) |
| W-BLOCK | A named blocker is open (red workflow, verify-failed, infra, need-input) |
| W-OWNER | The owner minion is busy on another packet |
| W-RUN(N) | A running result: CI, Copilot or local Floci integration/service test, N minutes as above |
The board names the active wait for any task that is not moving.

## Escalation rule (CTO msg-W-2026-0001-077)
A chain PR enters W-MARIO when it is merge-ready: internal reviews passed, Copilot reviewed, workflows green. At that moment the CTO pings Mario in #teos-grokbot. Mark the PR milestone-at-risk if it is still in W-MARIO after Mario's next merge pass or after the next daily digest, whichever comes first.
Any W-BLOCK on a chain task (27.14, 27.25, 27.16.6, 27.16.1) is escalated to cto at once.

## Reporting
A status report goes to cto whenever a milestone changes (met, at risk, or slipped behind a named wait). There is no fixed reporting schedule.

## Gates (ordered, event-based)
| Gate | Exit event | Tasks |
|---|---|---|
| **M0 W0** | **MET:** image digest 9710d466 recorded, pins match, building/SUR 0 × 403, #5131 gzip YES | W0.1–W0.5 |
| M1 W1 | all W1 PRs merged by Mario after the Floci-local gates pass | 27.12, 27.14 (+27.13) |
| M2 W2 | all W2 PRs merged | 27.25, 27.10 (both **running**, pulled forward by CTO msg-064), 27.20, 27.16.2 |
| M3 W3 | all W3 PRs merged; shared 19.1 marker gone (rg) | 27.16.6, 27.16.3, 27.16.4, 39.11 follow-up |
| M4 W4 | all W4 PRs merged; marker table updated by technical-writer | 27.16.1, 27.1, 27.27, 27.29 |
Gates show dependency order only. A later task starts as soon as a slot frees and its own predecessors are merged.

## Tasks, owners, effort
Active effort covers test plan + implementation + reviews + Copilot fixes (the qa-lead cloud step is removed) (agent minutes/hours). Waits are W-RUN times (minutes) plus named waits.
| Task | Gate | Checklist | Implementer | Reviewers / consults | Named waits | Active effort | W-RUN total |
|---|---|---|---|---|---|---|---|
| 27.12 | M1 | §C | golang-pro | code, hex, clean | W-MARIO (running now) | ≈ 2.5 h | ≈ 50 min |
| 27.14 (+27.13) | M1 | §A | golang-pro | code, hex, clean | W-MARIO (running now) | ≈ 1.5 h | ≈ 50 min |
| 27.25 (chain 1/3) | M2 | §A | golang-pro | code-reviewer | W-MARIO (running now) | ≈ 1.5 h | ≈ 50 min |
| 27.10 | M2 | §A | golang-pro | code, test-reviewer | W-MARIO (running now) | ≈ 2.5 h | ≈ 50 min |
| 27.20 | M2 | §C | golang-pro | code, test-reviewer | W-DEP 27.14 merged; W-OWNER slot | ≈ 1.5 h | ≈ 50 min |
| 27.16.2 | M2 | §A | golang-pro | code-reviewer | W-OWNER slot | ≈ 2.5 h | ≈ 60 min |
| 27.16.6 (chain 2/3) | M3 | §A | golang-pro | code-reviewer | W-DEP 27.25 merged | ≈ 3 h | ≈ 70 min (retry timing) |
| 27.16.3 | M3 | §A | golang-pro | code-reviewer | W-OWNER slot | ≈ 2.5 h | ≈ 60 min |
| 27.16.4 | M3 | §A | golang-pro | code-reviewer | W-OWNER slot | ≈ 2.5 h | ≈ 60 min |
| 39.11 follow-up | M3 | §A | golang-pro | code, observability-sre | W-OWNER slot | ≈ 1.5 h | ≈ 100 min (one 60-min local run) |
| 27.16.1 (chain 3/3) | M4 | §A | golang-pro | code-reviewer | W-DEP 27.16.6 merged | ≈ 4 h | ≈ 80 min |
| 27.1 | M4 | §A | golang-pro | code, api-designer, security-auditor | W-OWNER slot | ≈ 3 h | ≈ 50 min |
| 27.27 | M4 | §A | golang-pro | code-reviewer | W-OWNER slot | ≈ 1.5 h | ≈ 50 min |
| 27.29 | M4 | §A | golang-pro | code, api-designer | W-OWNER slot; must un-skip LogImport | ≈ 2.5 h | ≈ 50 min |
| 27.21 | parked | §C | golang-pro | code | W-DEP Floci Task 48 in image | ≈ 1.5 h | ≈ 50 min |

Total active agent effort ≈ 32 h (was ≈ 33 h with qa-lead cloud steps); total W-RUN ≈ 830 min (≈ 13.8 h) summed across parallel owners (was ≈ 1430 min), spread over up to 4 parallel owners (+1.5 h for 27.21 when it is unparked).

## Critical path (sequence + effort + named waits)
27.25 (≈ 1.4 h + W-RUN ≈ 50 min) → **W-MARIO** → 27.16.6 (≈ 2.9 h + W-RUN ≈ 70 min) → **W-MARIO** → 27.16.1 (≈ 3.9 h + W-RUN ≈ 80 min) → **W-MARIO** → M4.
That is ≈ 8.25 h of active effort plus ≈ 200 min of running results (was 8.5 h + 320 min) plus three Mario merge waits. Mario's merges are the dominant unknown.
Secondary chain: 27.14 → W-MARIO → 27.20. All other tasks run in parallel, so they don't lengthen the chain.

## Dependency map
- W0 digest → all tasks (met).
- 27.14 → 27.20; 27.25 → 27.16.6 → 27.16.1 (same eventsvc package).
- 27.16.2/.3/.4 share the 19.1 marker: final rg at M3.
- 27.29 → LogImport un-skip; 27.21 → Floci Task 48.
