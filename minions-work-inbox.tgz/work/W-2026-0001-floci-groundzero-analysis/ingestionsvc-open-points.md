# ingestionsvc ARCHITECTURE.md "Open points": triage

Ref: `origin/minion/docs-ingestionsvc` (PR #1271), read with `git show` (no checkout). Paths are relative to the repo root.
Note: the doc's "Open points" lists only 5 items. Item 6 (lint-arch) comes from LINT.md:76-79 and was added by the brief.

| # | Verdict | Severity | Size |
|---|---------|----------|------|
| 1 | Real defect, but only in the message and the name. Behaviour is correct | Low | <1 h |
| 2 | Real (stale comment). Doc is correct | Low | <15 min |
| 3 | Not a bug. Doc is partly misleading | Low (doc) | <15 min |
| 4 | Real latent bug: the setting can't be used | Med | 1-2 h |
| 5 | Doc error in root.md. Doc's correction is right | Low | <15 min |
| 6 | Real gap, but lint-arch still runs in CI | Low | <15 min |

## 1. 2803 nil inversion
- Evidence: `go-services/ingestionsvc/ingestioncore/transform.go:74-78`. The code does `if nil == value { ... ErrorNilValueRequired ... "value must be nil while transform sensor" }`, so it rejects nil, and the message says the opposite. The constant is at `errorcodes/codes.go:7` `ErrorNilValueRequired = 2803`. The behaviour (reject nil) is what we want: callers skip that sensor.
- Fix: change the message to "value must not be nil". Rename the constant to `ErrorNilValueNotAllowed` and keep 2803. Update `_design/overview.adoc:297-298`.

## 2. ExtractSensorComponents codes
- Evidence: the comment at `ingestioncore/transform.go:17-20` lists codes 1, 2 and 3. The code returns `ErrorUnableToUnmarshalPayload` (2800) for an empty id (`:24-31`) and `ErrorUnableToConvertCircuitData` (2801) for any `Parse()` failure, including a bad ordinal (`:35-44`). Code 3 is never returned.
- Fix: change the comment to "2800 empty sensor id; 2801 any parse failure (circuit/ordinal/zone/area), position in message".

## 3. Circuit/Ordinal omitempty and -1
- Evidence: `go-core/model/ingestionmodel/types.go:34,36` has the tags `json:"c,omitempty"` / `json:"o,omitempty"`. The tags are shadowed by the custom `MarshalJSON` (`:154-166`): `if rep.Circuit != 0 { m["c"] = ... }`, and the same for Ordinal. That gives the same visible result (0 omitted, -1 written). `UnmarshalJSON` (`:215-220`) leaves the Go zero value when the key is absent, so 0 is omitted, reads back as 0, and the round trip is lossless. -1 ("no circuit/ordinal", `transform.go:15`) is written explicitly. That costs a few bytes per item but is not ambiguous. A consumer that sees a missing `c` and treats it as "no circuit" would be wrong, but that is a contract question, not a bug in this service.
- Fix (docs only): reword to "0 is omitted by MarshalJSON (absent means 0), -1 means unbound". Optionally drop the dead `omitempty` tags.

## 4. settings.objectExpirationDays vs provision schema
- Evidence: `go-services/ingestionsvc/deployment/stack.go:268-273` reads `cfg.Settings["objectExpirationDays"].(float64)`, default 90 (`:36-37`). `go-services/ingestionsvc/manifest/provision-schema.json:12-18` allows only `audit` with `"unevaluatedProperties": false`. The base contract (`deployment/schemas/platform/base-config.schema.json`) adds only `enabled`, `features`, `apis` and `iam`, with no `settings`. Any provision config that sets it fails schema validation, so the knob can't be used and every bucket gets 90 days. Today nobody sets it (the service-test provision-config.yaml doesn't set it either), so nothing breaks yet.
- Fix: add `"settings": {"type":"object","properties":{"objectExpirationDays":{"type":"integer","minimum":1}},"additionalProperties":false}` to provision-schema.json, plus a schema test. Or remove the dead read in the stack.

## 5. root.md "notifies actuation"
- Evidence: `go-services/ingestionsvc/manifest/features/root.md:15` reads "Notifies the actuation service so westbound providers can react". The stack only publishes S3 OBJECT_CREATED to its own SNS topic (`deployment/stack.go:180-182, 355` `NewSnsDestination(objectCreatedTopic)`) and never calls actuation. `actuationsvc` subscribes (`go-services/actuationsvc/.../actuation-system-context.mmd:17` "ingestionsvc-s3-object-created"). root.md:5 already says "emits SNS notifications".
- Fix: change it to "Publishes S3 object-created events to an SNS topic (today consumed by actuationsvc)".

## 6. No `lint` target depending on lint-arch in the local Makefile
- Evidence: `go-services/ingestionsvc/Makefile:1-8` has only `clean` and `lint-arch`. The repo-root `Makefile:570` `lint: ... lint-go lint-arch` and `:640-653` find every Makefile with `^lint-arch:`, so root `make lint` and CI (`act-lint`, `:613`) still enforce the map. Peers have a local `lint: lint-arch`: `go-services/eventsvc/Makefile:56`, plus appstore and realestatecore. Only `make lint` run inside ingestionsvc is missing. golangci-lint for this package runs from the root (`lint-go`, `:581`).
- Fix: add `lint: lint-arch` (plus a golangci-lint run on `./ingestionsvc/...` from the root, as eventsvc does) to the local Makefile.
