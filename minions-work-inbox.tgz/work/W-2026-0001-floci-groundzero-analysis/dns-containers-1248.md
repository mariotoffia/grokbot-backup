# Which containers resolve *.localhost / *.localhost.floci.io? (PR #1248, f6f2e6d0)
aws-serverless-cdk, 2026-10-22 22:24 CEST. Floci image mariotoffia/floci:latest (resolved locally to image id sha256:07ced9c6…).

## Answer
**No container in the teos Floci or service-test flows needs the host dnsmasq to answer these names with something other than 127.0.0.1. No dnsmasq change is needed.**

| Consumer | Resolves the names? | Evidence |
|---|---|---|
| Floci Lambda containers | Yes, but **through Floci's own DNS**, not through the host's dnsmasq | Floci starts each Lambda with `HostConfig.Dns=[<floci IP> 8.8.8.8 8.8.4.4]`, `ExtraHosts=[host.docker.internal:host-gateway]`, on `FLOCI_SERVICES_DOCKER_NETWORK`. Inside a real Lambda: `api.devlocal02.localhost.floci.io` → 172.18.0.2 (Floci), `iot-eu-west-1.devlocal02.localhost.floci.io` → 172.18.0.2. An HTTP GET to it on :4566 reached Floci and got a 404 back from Floci's Host-based routing. Injected env vars: `AWS_ENDPOINT_URL=http://floci:4566`, `FLOCI_ENDPOINT=http://floci:4566`, `FLOCI_HOSTNAME=floci` (the network alias). |
| TEOS code in Lambdas | Does not depend on DNS for account-domain names | API_ENDPOINT.md §4: httputil opens connections for `<acct>.localhost.floci.io` and the names under it to the host:port of `AWS_ENDPOINT_URL`. SDK clients use `AWS_ENDPOINT_URL`. lambda/environment.go:254 says "the emulator gives every function it runs the AWS_ENDPOINT_URL of itself" (confirmed above). |
| DynamoDB-local | No | Reached by container name: `FLOCI_SERVICES_DYNAMODB_LOCAL_ENDPOINT=http://<ddb name>:8000` (flocilocal/dynamodb.go:172) on the shared or paired network |
| Floci container itself | No | It gets `FLOCI_HOSTNAME=<alias>` or `FLOCI_BASE_URL=http://127.0.0.1:<port>` (container_args.go:104-110). |
| ECR image pulls (`000000000000.dkr.ecr.eu-west-1.localhost`) | Yes, in the **host dockerd** | The host resolves through resolv.conf → dnsmasq → 127.0.0.1, which is correct there. |
| Service-test / go test drivers | They run on the host, not in a container | Floci is published on `127.0.0.1:<port>` (container_args.go:23) |

No `--add-host`, `--dns` or `extra_hosts` settings for these names turned up in teos or .worktrees. The non-doc hits for localhost.floci.io are only config baseDomain values, dns.go, and tklocal/security/platform.go.

## Empirical tests (dnsmasq already running as #1248 configures it, unchanged)
Every name was checked with both `nslookup` and `getent` from Alpine.
- Default bridge (resolv `nameserver 172.17.0.1`): `foo.localhost`, `api.devlocal02.localhost.floci.io`, `iot-eu-west-1.devlocal02.localhost.floci.io` and `000000000000.dkr.ecr.eu-west-1.localhost` all → 127.0.0.1. `example.com` → 198.18.0.1.
- User-defined network (resolv 127.0.0.11, which forwards to the host's dnsmasq): same answers.
- Reachability from a container on Floci's network: `http://floci:4566` → 200. `http://127.0.0.1:4566` fails, as does `http://api.devlocal02.localhost.floci.io:4566` when resolved through the host's dnsmasq (127.0.0.1). `http://172.17.0.1:14566` fails from either network, because flocilocal publishes on 127.0.0.1 only.
- Consequence: a dnsmasq answer of 172.17.0.1 would **not** reach Floci anyway, because nothing listens on docker0:4566. The working path is the alias on the services network plus Floci's DNS, and that is what Floci already does.
- Real Lambda invocation (Floci only, python3.12 zip, Floci with `FLOCI_SERVICES_DOCKER_NETWORK=dnst` and `FLOCI_HOSTNAME=floci`): results as in the table above. The Lambda's resolv.conf showed `ExtServers: [172.18.0.2 8.8.8.8 8.8.4.4]`. Separately, `foo.localhost` → 127.0.0.1.

## Recommended fix
None: keep #1248's dnsmasq as is. The listener on 172.17.0.1 serves plain containers on the default bridge, which get daemon.json dns=172.17.0.1, so they can reach the internet. For those containers, 127.0.0.1 is the honest answer for these names.

If a future plain container (not launched by Floci) on the default bridge must reach Floci by a *.localhost.floci.io name, two conditions apply. Do **not** change dnsmasq, because the published port is loopback-only. Instead, put that container on the services network and use the Floci alias, or `--add-host <name>:host-gateway` plus a 0.0.0.0/docker0 publish. If you still want the interface-specific answer, these are the minimal, idempotent lines. They are **not verified**, because no consumer needs them:
```
# CHECK:
grep -qx 'localise-queries' /etc/dnsmasq.d/teos-box.conf && grep -qx 'interface-name=api.devlocal02.localhost.floci.io,docker0/4' /etc/dnsmasq.d/teos-box.conf
# APPLY (would need a matching edit to DNSMASQ_BODY, otherwise check_dnsmasq_conf rewrites it):
printf 'localise-queries\ninterface-name=api.devlocal02.localhost.floci.io,docker0/4\n' | sudo tee -a /etc/dnsmasq.d/teos-box.conf && sudo kill "$(cat /run/dnsmasq-teos-box.pid)" && sudo sh -c 'nohup dnsmasq -C /etc/dnsmasq.d/teos-box.conf --log-facility=/var/log/dnsmasq-teos-box.log >/dev/null 2>&1 &'
```
Caveat: `interface-name` answers with docker0's address to everyone, including the host. That breaks the host's 127.0.0.1 path to loopback-published Floci, which is one more reason not to do this.

## Changes made and reverted
See box-restore.md, section "aws-serverless-cdk dns-containers-1248": temporary network dnst, the dnst-floci container plus its anonymous volume, the probe Lambda container, and /tmp probe files. All were removed. I did not touch dnsmasq, resolv.conf or daemon.json (md5 unchanged). There were no teos source changes and no commits.
