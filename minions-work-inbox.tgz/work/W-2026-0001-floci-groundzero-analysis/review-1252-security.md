# Security review: DRAFT PR #1252 @2aaf336e (Closes #1251, stacked on #1248 @c3c4a816)
Reviewer: security-auditor · 2026-10-23 (Europe/Stockholm) · static review (git diff c3c4a816..2aaf336e).
I ran no sudo, executed nothing from the script and read no .env. My only network calls were anonymous Docker Hub registry HEAD requests to check the digest.

## Verdict: **approve-with-changes** (no blockers; 2 Low, 3 Info)

## Image provenance
- `BINFMT_IMAGE=tonistiigi/binfmt@sha256:400a4873…66f0`. Docker Hub currently returns this exact index digest for `tonistiigi/binfmt:latest` (checked 2026-10-23). Tõnis Tiigi, a Docker/BuildKit maintainer, publishes the image; it is the upstream that Docker's buildx docs and `docker/setup-qemu-action` use. Pinning it is correct, and the Floci `:latest` rule does not apply to this image.
- `ARM64_TEST_IMAGE=alpine@sha256:be265606…` is pinned to the official library image. It is unprivileged and runs with `--rm`.
- `docker run --privileged --rm "$BINFMT_IMAGE" --install arm64` has no mounts, no host networking and no extra env. It only runs when the registration is missing (`binfmt_registered ||`). `--privileged` is what writing to binfmt_misc requires; `--cap-add SYS_ADMIN` would not be enough for every runtime, so I accept it.

## Findings
| id | sev | where | issue | recommendation |
|---|---|---|---|---|
| B-1 | Low | apply_binfmt; 1251/4-arm64-test.log `flags: POCF` | The **C (credentials) flag IS set**: tonistiigi/binfmt registers with POCF by default. With C plus F, a setuid/setgid arm64 binary runs under qemu with the binary's credentials, and qemu-user is not a security boundary, so a setuid-root foreign binary becomes a root path. O (open-binary) is set as well. The real risk on this box is small: a setuid-root arm64 file on the host needs root to create, all agents share one user with passwordless sudo, and inside containers the user is already root. The PR body and comments don't mention C. | Document the flags (POCF) and why C is accepted next to the F-flag comment. Alternatively register without C. That requires a custom registration (`echo ':qemu-aarch64:M::…:/usr/bin/qemu-aarch64:F' > register`) instead of the image, which isn't worth doing here. I recommend documenting it. |
| B-2 | Low | binfmt_registered / check_binfmt | The check accepts any enabled `qemu-aarch64` entry whose flags contain F, without checking the `interpreter` path or the magic/mask. A tampered or foreign registration (with F, its interpreter fd is pinned for every arm64 exec, in all containers and namespaces) would be reported OK. Writing a registration needs root, so this is defence in depth only. | Also check `interpreter /usr/bin/qemu-aarch64` (as in the log), or the expected flags, before reporting OK. Otherwise replace the entry. |
| B-3 | Info | apply_binfmt | The binfmt container uses the default bridge network although it needs none. | Add `--network none`. |
| B-4 | Info | apply_binfmt | `log UNDO "echo -1 …"` is logged even when the script registered nothing (only the mount ran). The undo command is still harmless. | Log the UNDO only when the docker run actually ran. |
| B-5 | Info | BINFMT_IMAGE comment | The pin is to whatever `:latest` was today, with no tag or qemu version recorded, so future reviewers can't tell which qemu it contains. | Add the matching tag (e.g. `qemu-vX.Y.Z`) to the comment. |

## F flag implications
F makes the kernel open `/usr/bin/qemu-aarch64` from the image at registration time and keep the fd. The handler then works in every mount namespace and container and stays until it is unregistered or the box reboots. This is intended (containers don't need qemu inside), and it is also why B-2 matters: whatever binary is registered is executed for all arm64 programs host-wide. The script registers only arm64 (`--install arm64`), not `all`, so the handler set is minimal.

## iptables-legacy check change
- This only affects `--check`. When iptables-legacy is missing, it returns 1 (pending) if `CHECK_ONLY=1` and the docker package step is still pending; otherwise it returns 0 as before. Run mode doesn't change.
- It doesn't touch FORWARD or firewall rules, and nothing is loosened.
- set -e: the `[ ] && ! check && {…}` list is safe, because a failing && list doesn't trigger errexit and `return 0` follows. `check_docker_pkg` is read-only.
- Failure mode: at worst `--check` over-reports one pending item (exit 3). That fails safe.

## Escalation flags
None (no authz-bypass, secret-leak, tenant-bleed or iam-loosening). The privileged container and the C flag are host-privilege items within the accepted box model (passwordless sudo).
