# Clean Architecture review: T-27.16.4, PR #1255 (DRAFT)
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-4-ingestion-firehose-logs · HEAD ce280894 (matches the request and `git ls-remote refs/pull/1255/head` = ce280894007f). Reviewed from a clean `git archive ce280894` export in /tmp/r1255, because the worktree was dirty (see the Low finding). Floci only; no GitHub or Slack posts. This review is the interim arch gate (W-2026-0003).

== Verdict ==
APPROVED with notes

== Findings ==
- [Medium] [non-testable] go-services/ingestionsvc/ — DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md and adr/ are all missing (only _design/*.adoc and manifest/features/root.md exist), and no .go-arch-lint.yml covers ingestionsvc. This gap existed before the PR. Fix: add the docs and a map under W-2026-0003. Not blocking here.
- [Low] [known gap W-2026-0003] No arch map covers the changed package. `PATH=$HOME/go/bin:$PATH make lint-arch`: rc=0, 9 maps checked, none of them ingestionsvc. The hand-built import map below is the evidence.
- [Low] [non-testable] Provided gate evidence: static-f7acb910.log is for the parent commit and records lint rc=1 (forbidigo context.Context ×2), lint rc=127 (golangci-lint missing from PATH) and a per-module lint-arch rc=2 before root lint-arch rc=0. No static log exists for ce280894. I re-ran the gates at ce280894 (below) and they are green. Fix: keep a static-ce280894 log next to the test log.
- [Low] [non-testable] Worktree hygiene: during the review (mtime 11:30:54 (UTC+2)), someone outside this review left uncommitted edits in ingestion_test.go (runStartClockSkew) and sinks_helpers_test.go (DescribeLogGroups removed). Three nodabuilding webui/dist files are also deleted and unrelated. I did not touch them. They are not part of ce280894, which is the version reviewed. Fix: the owning minion should commit or discard them.
- [Info] `go vet` rc=0 with `-tags e2e` and with `-tags "e2e floci"`. With no tags or with `-tags integration`/`floci` alone, rc=1 and the output is "no packages to vet", because the package is e2e-only. golangci-lint `--build-tags e2e` on the package gives rc=0, 0 issues. make generate was not run.
- Out of scope: port and adapter shape (hexagonal-reviewer) and test quality (test-reviewer).

Test-only claim: confirmed. origin/main...ce280894 has 2 commits (f7acb910, ce280894) and changes 3 files, +131/-7, all in go-services/ingestionsvc/deployment/service-test/: go.mod (firehose and cloudwatchlogs become direct requires; the versions are unchanged), ingestion_test.go (Floci skip removed, runStart added, step 7 calls the sink assertions), and sinks_helpers_test.go (new, `//go:build e2e`). The helpers take ifcore.CbContext. No production, domain, handler or adapter code changed. No .go-arch-lint.yml or ADR change.

Arch map (go list -test -tags e2e, direct imports):
- ingestionsvc/deployment/service-test imports deployment/lib/{svctest,core/domain/wellknown}, go-core (cbenv, cberror, ctx, interfaces/ifcore, managers/mgrstore/{awamgrstore,storeloader}, model/{dsmodel,ingestionmodel,storagemodel}, utils/testutils/awstestutil), aws-lambda-go/events, aws-sdk-go-v2 (aws, sns, firehose, firehose/types, cloudwatchlogs), testify and stdlib.
- Import delta: firehose, firehose/types, cloudwatchlogs, strings and ifcore are added. The package does not import any ingestionsvc handler or ingestioncore package. The cloud SDK is used only in the e2e test layer, the outermost ring, so the dependency direction is correct. No domain package changed, so no cloud SDK reaches the domain.

Gate evidence check (impl/T-27.16.4/gates/test-service-ce280894-07ced9c6.log): HEAD ce280894007f…, image mariotoffia/floci@sha256:07ced9c6…, target=local Floci with account 000000000000 and endpoints floci:4566 (no real AWS). `--- PASS: TestIngestionServiceFlow (80.18s)`, ok, rc=0, cbdeploy undeploy ran, 11:19–11:22 (UTC+2). The log is valid and genuinely passing. The repo does not pin a Floci image: svctest doc.go documents TK_LOCAL_EMULATOR=floci/floci:<tag>. The run used floci:latest recorded by digest, which is acceptable.

== Rationale ==
Every change sits in the e2e service-test layer, which is allowed to depend on infrastructure. No domain, application or handler package changed or gained an import, so there is no dependency inversion, domain leak or business logic in adapters. All required gates pass at ce280894: lint-arch, vet with tags, golangci-lint and the Floci service test. The Medium finding is a governance-doc gap that existed before this PR. The Lead Architect minion should track it under W-2026-0003.
