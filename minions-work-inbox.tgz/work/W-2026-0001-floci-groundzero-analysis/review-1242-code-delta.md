# Code delta review: PR #1242 (4b08764e..f9497460)

Reviewer: Code Reviewer minion (read-only). Head confirmed: f94974607dadcc8f54394889765580435d17c16f (not moved).

## Verdict: CHANGES_REQUESTED

## Decision checks (Mario 10:41)
- x-amzn-ErrorType / MissingAuthenticationTokenException asserts: all gone. `call` returns (status, body); `assertForbiddenErrorType` removed. The only mention left is the header line saying it is not asserted. OK
- FG-7 skip/log: gone. OK
- FG-4 unlinked-plan case: strict, `t.Skip` removed, asserts 403 + "Forbidden" + no echo. Passed on Floci (-race log). OK
- Header comment: updated (no ErrorType in the 403 bullets, "Only the status and the body are asserted"). OK
- PR body notes gap 50.5. OK

## Gates (logs *f9497460*)
- fmt: make fmt-check-go rc=0; gofmt -l rerun clean.
- golangci-lint: make lint-go rerun rc=0 (first run failed only on missing webui/dist embed, an environment problem).
- go-arch-lint: rc=0, no warnings.
- vet: make vet rerun rc=0; go vet -tags e2e,floci rerun on service-test: OK.
- tests -race: groundzero service-test PASS, all 7 TestRestAPIContract subtests pass on Floci (sha256:07ced9c6...). test-service rc=0.
- test-integration: only cmd/cblicense fails (AWS_ENDPOINT_URL unset). Tracked by issue #1245 (open), so out of scope.

## Findings
### Medium
- M1: PR title starts with `T-27.1: `. CONVENTIONS.md section 61 says no W-/T- id prefix. Rename to `test(groundzero): API Gateway v1 contract cases on Floci`. All commit subjects are fine.
- M2 (AGENTS.md MUST, no plan ids in comments): the header of apigw_contract_test.go, which this delta edits, still has `(W-2026-0001 T-27.1)`, `(Floci 44.1)` and `tracked with 27.28 / Floci 44.1`. Remove the ids and describe the behaviour only. These lines predate the delta, but the delta rewrote this block.
### Low
- L1: the PR body integration note should cite #1245 for the cblicense failure.
- L2: the new header line "Only the status and the body are asserted, never x-amzn-ErrorType" comes close to AGENTS.md's "describe what the code does NOT do". It is acceptable as a constraint on future edits. Optional: "Assertions cover status and body only."

No High findings. All required gates are green, so the CHANGES_REQUESTED verdict comes from M1/M2 only.

---
## R2: delta f9497460..75c3be6b

Head confirmed: 75c3be6be9835bd141dde6e1cc17bc780830058d (not moved).

### Verdict: APPROVED

- Diff touches only the header comment of apigw_contract_test.go (+5/-4). There is no code change, and the PR title and body changes are metadata only.
- M1 resolved: the title is exactly `test(groundzero): API Gateway v1 contract cases on Floci`. The new commit subject `groundzero: describe the contract checks without plan ids` has no W-/T- prefix.
- M2 resolved: grep for W-2026, T-27, "Floci 44", 27.28 (and FG-) in the file finds nothing.
- L1 resolved: the PR body integration note ends with "Tracked in #1245."
- L2 resolved: the line now states what is checked (403 status, exact message, no echo) instead of what is not.
- Gates: the *-comment-precommit logs (gofmt, golangci-lint e2e,floci, vet e2e,floci) are all rc=0. They ran on f9497460 plus the uncommitted edit, and that edit matches the committed diff. My own rerun at 75c3be6b in a clean worktree: gofmt -l is empty and go vet -tags e2e,floci is OK. The R1 test and lint gates still apply because no code changed.

### Findings
- None blocking.
- Info: "tracked separately" in the header is vague but acceptable. The PR body still has plan IDs (W-2026-0001, 27.1, 27.28, FG-4), which is allowed in a PR body.
