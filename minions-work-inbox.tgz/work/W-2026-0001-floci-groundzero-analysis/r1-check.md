# R1 Floci check — aws-serverless-cdk (packet msg-W-2026-0001-platform-lead-092)
Date: 2026-10-22 15:06–15:30 (Europe/Stockholm)

## Verdict: INCONCLUSIVE — blocked (dependency + need-input). Neither "R1 clean" nor "R1 hit"
No test reached the API layer, so neither run could show the 44.2 API-key 403 or rule it out. There were 0 matches for 403, forbidden or api-key in either log.

## Commit tested
origin/main = b45acb61468f561934b6e0c3d29baeab58bdd9ec (2026-10-22 14:43:28 +0200, "chore(deps-dev): bump ajv-formats … (#1219)"), as a detached worktree at aws-serverless-cdk/teos-main (now removed).

## Commands
Clean env, run in each module dir (script: aws-serverless-cdk/run.sh):
```
env -i HOME=/home/box USER=box PATH=/home/box/go/bin:/home/box/.local/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin \
  COREPACK_HOME=/home/box/.cache/node/corepack \
  TK_LOCAL_EMULATOR=mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 \
  CB_SERVICE_TEST=<name> sg docker -c 'go test -tags=e2e,floci -count=1 -v -timeout 30m ./...'
```
- buildingsvc: go-services/buildingsvc/deployment/service-test, CB_SERVICE_TEST=building-service
- sur: go-services/providers/eastbound/sur/deployment/service-test, CB_SERVICE_TEST=sur-provider
- Change from the packet: the literal values `buildingsvc` and `sur` are not manifest names. TestMain exited 0 straight away and ran no tests (logs in aws-serverless-cdk/attempt1-noop/). The manifest names `building-service` and `sur-provider` were used instead. `~/.local/bin` was added to PATH because cdk lives there.
- `sudo /usr/local/sbin/box-env-restore.sh` was run before the tests.

## Counts
| service | PASS | FAIL | SKIP | result |
|---|---|---|---|---|
| building-service | 0 | 0 tests (package FAIL in TestMain deploy) | 0 | FAIL rc=1, 103 s |
| sur-provider | 0 | 0 | whole package skipped in TestMain | ok rc=0 (no tests ran) |

## Log excerpts (redacted; no keys in the logs)
building-service:
```
[svctest] target=local: Floci mariotoffia/floci:latest@sha256:a31d6e08…c1 at https://127.0.0.1:42177 …
FATAL: deploy failed: deploy service building-service: cbdeploy cfn deploy building-service: exit status 1
Failed to create IAM stack: create infrastructure: create API gateway: create OpenAPI builder: load spec from file: open ../_dist/_output/api/http-api.yaml: no such file or directory
Error deploying iam-service: exit status 1
Error undeploying building-service: exit status 1
```
sur-provider:
```
skipping: CB_DEFAULT_GEOCODERAPI_KEY is not set. Set it in .env at the root of the repository, as .env-example lists it, or export it in the shell.
```

## Blockers / env issues
1. **dependency**: a fresh origin/main checkout has no generated artifacts (`_dist/_output/api/http-api.yaml`, produced by `make generate`). The packet forbids `make generate`, so the iam-service dependency stack cannot deploy. Options: (a) allow `make generate` (it needs PATH=~/go/bin and sg docker) inside the throwaway worktree only, or (b) accept copying the generated `_dist` from /workspace/repos/teos. Option (b) is weaker evidence, because that checkout is at a3543337, not b45acb61.
2. **need-input**: the sur-provider test needs CB_DEFAULT_GEOCODERAPI_KEY. The env -i rule strips it, and the worktree has no .env. Options: allow the run to load /workspace/repos/teos/.env (never printed), or treat SUR as skip-by-design for R1.
- Teardown: the building-service undeploy also failed (CFN delete still failing after cleanup). The Floci containers are per-run and none were left running (`docker ps` empty).

---
# Update 2026-10-22 15:55 (Europe/Stockholm): msg-095 (SUR only) and msg-097/098 (building-service with isolated make generate)

## FINAL VERDICT: **R1 clean**. Both services reached the API through the Floci API gateway, with 0 HTTP 403s and 0 forbidden/API-key errors
(This supersedes the inconclusive verdict above. building-service is no longer on hold: qa-lead approved make generate in an isolated clone, msg-097.)

## SUR run2 (msg-095): worktree of origin/main 4454b5af647902a2137fac64edca7c853d2e12d9 (2026-10-22 15:23:37 +0200)
- Result: package FAIL, rc=1, 63.6 s, 0 PASS / 0 FAIL / 0 SKIP tests. Did not reach the API.
- Cause: same as building-service run 1. The iam-service dependency deploy needs `../_dist/_output/api/http-api.yaml` (no such file or directory) and there was no make generate. 0 matches for 403/forbidden/api-key.
- Log: aws-serverless-cdk/sur-run2.log (and .raw.log). Worktree removed.

## Run3 (msg-097): isolated clone, both services
- Clone: `git clone --no-hardlinks /workspace/repos/teos aws-serverless-cdk/teos-bsvc` + `git checkout --detach b45acb61` → **b45acb61468f561934b6e0c3d29baeab58bdd9ec**. Not a worktree, nothing committed or pushed.
- Floci: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1. The log confirms `[svctest] target=local: Floci …@sha256:a31d6e08…`.
- _dist was generated in the isolated clone with `env -i HOME PATH(~/go/bin,~/.local/bin,…) COREPACK_HOME sg docker -c 'make generate'`. The stale a3543337 _dist was not used. make generate exited non-zero at the end, in `cmd/tklocal react-build` (`tsc: not found`, web node_modules not installed and Node v20 < required 22). That was after the API specs had been bundled, and `_dist/_output/api/http-api.yaml` existed. The tklocal web UI is not used by these tests. Log: aws-serverless-cdk/bsvc-make-generate.log.
- Test command, run in each service-test dir (script aws-serverless-cdk/run3.sh):
  `env -i HOME=/home/box USER=box PATH=/home/box/go/bin:/home/box/.local/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin COREPACK_HOME=/home/box/.cache/node/corepack bash -c 'set -a; . /workspace/repos/teos/.env; set +a; export TK_LOCAL_EMULATOR=<digest above> CB_SERVICE_TEST=<svc>; unset AWS_PROFILE; exec sg docker -c "go test -tags=e2e,floci -count=1 -v -timeout 30m ./..."'`
  The .env was loaded only into that subshell. No values were printed, and there was no set -x.

| service | PASS | FAIL | SKIP | 403s | reached API | rc / time |
|---|---|---|---|---|---|---|
| building-service | 10 (5 top-level tests + 5 subtests) | 0 | 0 | 0 | yes | ok rc=0, 280.3 s |
| sur-provider | 5 | 0 | 1 | 0 | yes | ok rc=0, 165.1 s |

Evidence of reaching the API:
- building-service: `Waiting 30 seconds to let the API key propagate...`, then requests to `api.devlocal02.localhost.floci.io` (Public API), then `--- PASS: TestLCSAPIClient` with QueryBuildingNotFound, InsertDeleteBuilding, InsertBuildingAndProvidersQueryAndDelete, InsertBuildingAndServicesQueryAndDelete and DeleteBuildingWithCFOSettings. Also ConfigDispatcherFlow, CfgImportFlow, ProviderConfigChangeRoundTrip, ProviderConfigChangeWithABAC. The one api-key grep match is that propagation message, not an error.
- sur-provider: TestSurApiIngest, TestSurApiActuate, TestSurApiSubscribeAndAck, TestSurApiGeoLookup PASS against `api.devlocal02…` / `api.auth.devlocal02…` (Cognito token `Token RSID: svctest`), plus TestConfigChangeWritesToS3 PASS.
- SKIP: `TestSurApiLogImportAndVerify`: "the local emulator ignores the binary media types of the SUR API, so it hands the gzip body to the log import function as text" (this is R2 / #5131, not R1).
- Noise, not failures: X-Ray "context missing" ERROR lines, and an S3 GetObject 404 while polling before the config object arrived.
- Logs: aws-serverless-cdk/bsvc-run3.log, sur-run3.log (and .raw.log). Redaction scan: 0 .env values found.

## Cleanup / secrets
- teos-bsvc clone deleted, and the run2 worktree removed. Shared worktrees and /workspace/repos/teos were untouched.
- Every file under aws-serverless-cdk/, plus r1-check.md and STATUS.md, was scanned by script for every .env value (≥4 chars), without printing them: 0 hits. `find aws-serverless-cdk -name '.env*'` returned nothing.
