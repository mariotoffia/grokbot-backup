# Code review — PR #1250 (buildingsvc go-arch-lint map, Closes #1249) — round 3 (r2 file)

- Reviewer: code-reviewer (READ-ONLY; no commits/pushes/GitHub posts)
- Sha reviewed: 798b11c5953536721a95f55fd53e2730efb70dae (GitHub head re-confirmed 2026-10-23 11:37 CEST, unchanged; base main 41409305; draft, mergeable clean; 0 Copilot/review threads)
- Commits: 812bec95 "chore(buildingsvc): add go-arch-lint map and lint-arch target", 798b11c5 "chore(buildingsvc): drop unused client self edge, list the map in LINT.md"
- df -h /: 128G, 52G used, 76G free (41%)
- Earlier static round (08:2x–08:37 CEST, box down): head confirmed, M1/L1 resolved, #1253/#1254 verified and linked; H1 left unverified, no verdict.

## Verdict: CHANGES_REQUESTED (one gate log only)

## H1 — gate logs gates/r3/ at 798b11c5
All 10 logs carry `# sha 798b11c5…`, `# cmd`, `# cwd`, `# at` (08:08–08:14 CEST) and an `rc=` line. tidy-touched.txt is an attachment of tidy.log (no header needed).

| Log | Scope | rc | OK |
|---|---|---|---|
| gofmt.log | gofmt -l go-services/buildingsvc | 0 | yes |
| lint-arch-buildingsvc.log | make lint-arch in go-services/buildingsvc ("OK - No warnings found") | 0 | yes |
| lint-arch.log | root make lint-arch | 0 | yes |
| vet-buildingsvc.log | scoped make vet | 0 | yes |
| test-buildingsvc.log | go test -short -race buildingsvc/... + deployment | 0 | yes |
| tidy.log | make tidy + diff go-services/buildingsvc | 0 | yes (only SUR go.mod/go.sum touched, #1253) |
| **lint-go-buildingsvc.log** | scoped make lint-go, LINT_FLOCI_MODULES= | **2** | **no** |
| vet.log / lint.log / test.log | whole repo | 2 | pre-existing, tracked |

- [High] [testable] gates/r3/lint-go-buildingsvc.log:11 — the scoped golangci-lint gate ends rc=2 (`make: *** [Makefile:575: lint-go] Error 7`). Every module pass prints "0 issues.", and the error is the empty-floci pass (`pattern ./...: directory prefix . does not contain modules listed in go.work`), so there's no lint finding — but the required gate log is not rc=0. Fix: rerun the scoped lint so it exits 0 (e.g. `golangci-lint run ./...` per module in go-services, go-services/buildingsvc/deployment, …/service-test, or a LINT_FLOCI_MODULES value that doesn't create an empty pass), with the same sha/cmd/cwd/rc header.

Repo-wide rc=2 confinement (verified):
- vet.log: every failing package is under go-services/providers/eastbound/sur (handlers/async-sv/service, handlers/esv, internal/core/application, internal/core/ports/inbound): undefined surmodel.* → #1253.
- lint.log: 1 typecheck issue in sur/internal/core/ports/inbound (undefined surmodel.*) → #1253.
- test.log: 12 failing packages = 11 SUR `[build failed]` (#1253) + deployment/lib/tests/unit with only `--- FAIL: TestBuildingServiceSpec` (#1254). No buildingsvc failures.

## Other findings
- M1 LINT.md 11 maps + recipe row: resolved.
- L1 client→client self edge: resolved.
- Tracking: #1253 and #1254 exist, describe the right failures and are linked from the rc=2 row. [Info] their Priority/Size are empty (not blocking). Sprint not required.
- Title rule (no W-/T- prefixes): PR title "buildingsvc: add go-arch-lint map and lint-arch target", #1249 title the same, both commit subjects `chore(buildingsvc): …` — all compliant, no Low. The earlier missing-ID Low is withdrawn.
- [Info] [non-testable] PR body line 1 still says "W-2026-0001 · T-27.27a"; the rule covers titles only, so this is fine.

## To approve
Re-run lint-go-buildingsvc.log to rc=0 at 798b11c5 (or the new head). Nothing else is open.

## Round 3 final (2026-10-23 11:42 CEST)
Verdict: **APPROVED** at 798b11c5953536721a95f55fd53e2730efb70dae (head unchanged).
- impl/buildingsvc-arch-lint/gates/r3/lint-go-buildingsvc.log: sha 798b11c5 header, cmd, cwd present; floci pass now covers the scoped modules; all three passes "0 issues."; rc=0. Blocker resolved.
- #1253 and #1254 org Issue Fields (via gh api graphql issueFieldValues): Priority=Medium, Size=Hours on both. Earlier Info resolved.
- Titles: PR title, #1249 title and both commit subjects ("chore(buildingsvc): add go-arch-lint map…", "chore(buildingsvc): drop unused client self edge…") have no W-/T- prefix.
Nothing open.

## R3 (798b11c5..37d14373, merge of origin/main) — APPROVED

Head confirmed 37d14373 (did not move). Merge parents: 798b11c5 and 98331222. Since then origin/main has moved one commit, to 01910b2b (#1260, an ADR doc). `git merge-tree` shows the PR still merges cleanly with the current main. `df -h /` showed 32% used.

Verified
- Three-dot diff `origin/main...pr/1250` touches only LINT.md (+2/-2), buildingsvc/.go-arch-lint.yml (+68) and buildingsvc/Makefile (+8/-1). The buildingsvc service-test changes in 798b11c5..37d14373 came in from main, not from the PR.
- Count: the merged tree has 12 `.go-arch-lint*.yml` maps across 11 Makefile `lint-arch` targets. eventsvc/Makefile runs evidencemonitor and evidencecollector. ingestionsvc came from #1257 and buildingsvc from #1250. LINT.md:225 "Maps in place today (12)" lists exactly those 12 names, ingestionsvc and buildingsvc included. The table at LINT.md:223 lists buildingsvc next to ingestionsvc in the `--project-path ..` row, which matches the Makefile recipe. "Not yet mapped" no longer lists either one. LINT.md has no conflict markers.
- Gates r5: gofmt, golangci (0 issues), govet, lint-arch (11 targets, "Architecture maps checked: 11"), test (0 FAIL) and tidy are all rc 0, and each has a `sha: 37d14373` header.
- My own `make lint-arch` in a clean temp worktree: rc=0, 11 targets including buildingsvc, all OK. The worktree was removed. The first attempt failed with rc 127 because go-arch-lint was not on PATH; it passed after adding ~/go/bin.
- PR title "buildingsvc: add go-arch-lint map and lint-arch target" and merge subject "Merge remote-tracking branch 'origin/main' into chore/W-2026-0001-buildingsvc-arch-lint" have no W-/T- prefix. The plan ID appears only inside the auto-generated branch name, which is not a finding.

Findings
- [Info] [testable] Makefile:631-645 (root) — "Architecture maps checked: 11" counts targets, while LINT.md says 12 maps. LINT.md:225 explains the difference, but the log line looks like a mismatch. This wording predates the PR. Fix (optional): print "targets" instead, or count maps.
- [Info] [non-testable] docs/adr/0001 (main, #1260) — the ADR's dated snapshot still lists buildingsvc and ingestionsvc as not mapped, with PR refs. It points to LINT.md as the living list, so this is fine and not part of this PR.
