import boto3, gzip, hashlib, io, json, os, time, urllib.request, zipfile
EP = "http://127.0.0.1:4599"; R = "eu-west-1"
kw = dict(endpoint_url=EP, region_name=R, aws_access_key_id="test", aws_secret_access_key="test")
lam = boto3.client("lambda", **kw); apigw = boto3.client("apigateway", **kw)
zb = io.BytesIO(); zf = zipfile.ZipFile(zb, "w"); zf.write("handler.py"); zf.close()
fn = lam.create_function(FunctionName="w0gzip", Runtime="python3.12", Role="arn:aws:iam::000000000000:role/x",
    Handler="handler.handler", Code={"ZipFile": zb.getvalue()}, Timeout=30)["FunctionArn"]
for _ in range(60):
    if lam.get_function(FunctionName="w0gzip")["Configuration"].get("State") in ("Active", None): break
    time.sleep(2)
def mkapi(name, binary):
    a = {"name": name}
    if binary: a["binaryMediaTypes"] = ["application/gzip", "application/octet-stream"]
    api = apigw.create_rest_api(**a)["id"]
    root = [r for r in apigw.get_resources(restApiId=api)["items"] if r["path"] == "/"][0]["id"]
    res = apigw.create_resource(restApiId=api, parentId=root, pathPart="log")["id"]
    apigw.put_method(restApiId=api, resourceId=res, httpMethod="POST", authorizationType="NONE")
    apigw.put_integration(restApiId=api, resourceId=res, httpMethod="POST", type="AWS_PROXY", integrationHttpMethod="POST",
        uri=f"arn:aws:apigateway:{R}:lambda:path/2015-03-31/functions/{fn}/invocations")
    apigw.create_deployment(restApiId=api, stageName="test")
    return api
payload = gzip.compress((json.dumps({"level":"info","message":"w0 probe","traceId":"w0-a2"})+"\n").encode() * 50)
print("SENT len=%d sha256=%s" % (len(payload), hashlib.sha256(payload).hexdigest()))
for name, binary, ctype in [("w0-binary", True, "application/gzip"), ("w0-binary-octet", True, "application/octet-stream")]:
    api = mkapi(name, binary)
    url = f"{EP}/restapis/{api}/test/_user_request_/log"
    req = urllib.request.Request(url, data=payload, method="POST", headers={"Content-Type": ctype})
    try:
        r = urllib.request.urlopen(req, timeout=120); print(name, ctype, "HTTP", r.status, r.read().decode())
    except urllib.error.HTTPError as e: print(name, ctype, "HTTP", e.code, e.read().decode()[:300])
