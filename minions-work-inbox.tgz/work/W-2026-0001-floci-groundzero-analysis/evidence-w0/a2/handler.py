import base64, hashlib, json
def handler(event, context):
    body = event.get("body") or ""
    b64 = event.get("isBase64Encoded", False)
    raw = base64.b64decode(body) if b64 else body.encode("utf-8", "surrogateescape")
    return {"statusCode": 200, "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"isBase64Encoded": b64, "len": len(raw),
                                "sha256": hashlib.sha256(raw).hexdigest(),
                                "gzip_magic_ok": raw[:2] == b"\x1f\x8b"})}
