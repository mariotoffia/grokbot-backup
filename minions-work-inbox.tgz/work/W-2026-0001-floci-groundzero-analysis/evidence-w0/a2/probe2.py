import boto3, gzip, hashlib, json, urllib.request
EP="http://127.0.0.1:4599"; R="eu-west-1"
kw=dict(endpoint_url=EP,region_name=R,aws_access_key_id="test",aws_secret_access_key="test")
apigw=boto3.client("apigateway",**kw)
fn="arn:aws:lambda:eu-west-1:000000000000:function:w0gzip"
spec={"openapi":"3.0.1","info":{"title":"w0-import","version":"1"},
 "x-amazon-apigateway-binary-media-types":["application/gzip","application/octet-stream"],
 "paths":{"/log":{"post":{"responses":{"200":{"description":"ok"}},
  "x-amazon-apigateway-integration":{"type":"aws_proxy","httpMethod":"POST",
   "uri":f"arn:aws:apigateway:{R}:lambda:path/2015-03-31/functions/{fn}/invocations"}}}}}
api=apigw.import_rest_api(body=json.dumps(spec).encode())
print("imported binaryMediaTypes =", api.get("binaryMediaTypes"))
apigw.create_deployment(restApiId=api["id"],stageName="test")
payload=gzip.compress((json.dumps({"level":"info","message":"w0 probe","traceId":"w0-a2"})+"\n").encode()*50)
print("SENT len=%d sha256=%s"%(len(payload),hashlib.sha256(payload).hexdigest()))
for ct in ["application/gzip","application/octet-stream"]:
    req=urllib.request.Request(f"{EP}/restapis/{api['id']}/test/_user_request_/log",data=payload,method="POST",headers={"Content-Type":ct})
    try: r=urllib.request.urlopen(req,timeout=120); print("import",ct,"HTTP",r.status,r.read().decode())
    except urllib.error.HTTPError as e: print("import",ct,"HTTP",e.code,e.read().decode()[:300])
