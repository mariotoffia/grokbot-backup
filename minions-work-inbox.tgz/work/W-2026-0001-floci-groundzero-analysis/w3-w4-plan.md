# W-2026-0001 remaining W3/W4 plan (dev-lead, 2026-10-22 15:33)

| Task | Scope | Owner | Depends on | Start state |
|---|---|---|---|---|
| 27.16.3 | corerouter shadow skips | golang-pro | none | IN PROGRESS: PR #1230; test-reviewer fixes and issue link pending |
| 27.16.4 | ingestionsvc ingestion_test.go:44 skip + assert Firehose/Logs output | golang-pro | none | ready, waiting on Mario's go |
| 39.11 | delete 2 gobridge skips (:176 Container Insights, :279 awslogs); 60-min run | golang-pro (observability-sre consult) | none | ready, waiting on Mario's go |
| 27.16.1 | eventsvc ESM/alarm evidence (new coverage) | golang-pro | 27.25, 27.16.6 merged (done) | ready, waiting on Mario's go |
| 27.1 | APIGW compatibility cases (API key bound directly, not via apiStages/44.1) | golang-pro; api-designer consult; security-auditor read-only | none | ready, waiting on Mario's go |
| 27.27 | remove Cognito CustomDomain workarounds + GetAccountDomain check | golang-pro | R1 clean (qa-lead running) | blocked on R1, then Mario's go |
| 27.29 | SUR gzip log import un-skip; first prove the gzip body arrives intact | golang-pro | R1 clean | blocked on R1, then Mario's go |

Order once go'd: 27.16.4, 39.11, 27.16.1 and 27.1 run in parallel (separate packages); 27.27/27.29 follow R1.
golang-pro is the only Go implementer, so suggested sequence: 27.16.4 -> 27.16.1 -> 27.1 -> 39.11 (long run in background).
Go status: Mario's direct go covers 27.16.3 only. The question on the other four is with Mario.
