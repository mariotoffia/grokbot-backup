# Issue audit: Thiink-LLC/teos issues #1245 and up

- Date: 2026-10-23 (TZ=Europe/Stockholm)
- main: f3a1d6d7 (`test(ingestionsvc): address review comments on log assertions (#1263)`)
- Method: `gh issue list --state all --limit 200` with number>=1245 (PRs excluded). GraphQL `closedByPullRequestsReferences` + `CROSS_REFERENCED_EVENT` for each issue. `git log`/`git grep`/`git cat-file`/`git show f3a1d6d7:path` in /workspace/repos/teos after fetching, with no checkout. Read-only: nothing on GitHub was changed.
- Rules: (a) no tests that only exercise Floci; (b) no adapting TEOS source to the box environment; (c) no duplicates and nothing already on main.

| # | title | state | linked PR (state) | relevant? | verdict | reason + evidence |
|---|---|---|---|---|---|---|
| 1245 | cmd/cblicense integration tests need AWS_ENDPOINT_URL when TEOS_DEPLOYMENT=local | OPEN | none closing; xref #1236 (MERGED), #1242 (CLOSED) | yes | keep | Real TEOS test bug: under `cbtest local exec` the tests fail in network-profile handling. This happens on any machine, not only this box. Not fixed on main: `git log f3a1d6d7 -- cmd/cblicense` has no fix, and there is no AWS_ENDPOINT_URL handling in cmd/cblicense (`cmd/cblicense/op_create_command_test.go:107`). |
| 1246 | cbdeploy TestSSOLoginAgainstTheLocalEmulator cannot resolve *.localhost.floci.io behind a fake-IP DNS resolver | OPEN | none closing; xref #1236 (MERGED, unrelated) | no | close-not-planned (same cause as #1243) | Caused by this box: the egress proxy's fake-IP DNS (198.18.0.0/15). Fixing it means adapting a TEOS test to the box, which breaks rule (b). #1243 has the same cause and was closed NOT_PLANNED, and its PR #1244 was closed unmerged. See the notes. |
| 1247 | machine setup script for the Linux build box | CLOSED/COMPLETED | #1248 (MERGED) | done | close-completed (already closed) | `scripts/grokbot/machine-setup.sh` at f3a1d6d7, commit ec00bd89 |
| 1249 | buildingsvc: add go-arch-lint map and lint-arch target | CLOSED/COMPLETED | #1250 (MERGED) | done | close-completed (already closed) | `go-services/buildingsvc/.go-arch-lint.yml`, commit 865f50cc |
| 1251 | machine-setup.sh: check-mode iptables-legacy gap, arm64 binfmt step, restore-script parity | OPEN | #1252 (OPEN) | borderline | keep (pending #1252) | Only touches box tooling under `scripts/grokbot/`, not teos service source, so it is not a rule (b) source adaptation. If Mario does not want box tooling in teos, close-not-planned it together with #1252. |
| 1253 | sur: surmodel needs Docker codegen; repo-wide make vet/lint/test fail without it | OPEN | none; xref #1250 (MERGED) | no | close-not-planned | Only shows up in a worktree with no Docker. The Docker-based codegen (`make -C .../sur generate-code`) is how the repo is designed to work. Changing it to suit a Docker-less box breaks rule (b). |
| 1254 | deployment: TestBuildingServiceSpec in deployment/lib/tests/unit fails on main | OPEN | none; xref #1250 (MERGED) | yes | keep | Real test bug that does not depend on the environment. At f3a1d6d7, `deployment/lib/tests/unit/openapi_all_specs_test.go` (around line 395) still takes the first http-api.yaml whose path contains "buildingsvc", which is the wrong spec. |
| 1256 | ingestionsvc: add go-arch-lint map and lint-arch target | CLOSED/COMPLETED | #1257 (MERGED); xref #1255 (MERGED) | done | close-completed (already closed) | `go-services/ingestionsvc/.go-arch-lint.yml`, commit 8f6c4f33 |
| 1258 | ingestionsvc: add service docs (DDD, ubiquitous language, architecture, lint, ADRs, plans) | OPEN | none | yes | keep | `go-services/ingestionsvc/DDD.md` does not exist at f3a1d6d7. Docs per CONVENTIONS. |
| 1259 | docs: ADR for a go-arch-lint map per service | CLOSED/COMPLETED | #1260 (MERGED) | done | close-completed (already closed) | `docs/adr/0001-go-arch-lint-map-per-service.md`, commit 01910b2b |
| 1261 | buildingsvc: move AWS SDK and CMDB client calls behind outbound ports | OPEN | none; xref #1250, #1260 (MERGED) | yes | keep | `go-services/buildingsvc/.go-arch-lint.yml:32` still has `depOnAnyVendor: true` at f3a1d6d7 |
| 1262 | ingestionsvc: address Copilot review comments on log assertions | CLOSED/COMPLETED | #1263 (MERGED) | done | close-completed (already closed) | commit f3a1d6d7 (#1263) |
| 1264 | build: clean golangci-lint cache in clean-caches | CLOSED/COMPLETED | #1265 (MERGED) | done | close-completed (already closed) | `Makefile:226` has `clean-golangci-cache`, commit 5c3a6251 |
| 1266 | Web apps: use the Thiink design system through the shared web/design packages | OPEN | none | yes | keep | Product work. `@thiink-llc/design-system` is not referenced anywhere under web/ or cmd/tklocal/webui at f3a1d6d7. |

Numbers 1248, 1250, 1252, 1255, 1257, 1260, 1263 and 1265 are PRs, so they are excluded.

## Notes on #1246

#1246 is not valid under Mario's rules:

1. **The cause is this box, not TEOS.** The issue says `*.localhost.floci.io` resolves to the egress proxy's fake IP range (198.18.0.0/15) instead of 127.0.0.1. Public DNS returns 127.0.0.1, so the test is correct wherever DNS behaves normally. The issue's own "done when" asks for the test to pass on a resolver that works and to skip or fail on a fake-IP resolver. That is a change made only to suit this box (rule b).
2. **Same cause as #1243, which was already rejected.** #1243 (`TestThePublicNamesResolveToThisMachine` behind fake-IP DNS) is CLOSED/NOT_PLANNED, and its fix PR #1244 ("skip the public-name lookup behind a fake-IP DNS resolver") was closed unmerged. #1246 even says it is "possibly the same cause as #1243 … as #1243 decides". That decision was not to do it.
3. **No TEOS change on main.** `integration_login_test.go` at f3a1d6d7 only has a `-short` skip (line 69) and no fake-IP handling. It is linked only to #1236 by cross-reference, and that PR is unrelated.

Recommendation: close #1246 as not planned and reference #1243/#1244. If the test needs to pass on the box, fix the box's DNS (machine setup) rather than TEOS.
