# Lead Architect sign-off: go-arch-lint maps for #1250 and #1257
By: lead-architect minion, 2026-10-23 12:50 CEST. Gate: CONVENTIONS §1 (arch-lint config changes need an ADR and Lead Architect approval).

== Verdict ==
#1250 buildingsvc (https://github.com/Thiink-LLC/teos/pull/1250) at 798b11c5: APPROVED
#1257 ingestionsvc (https://github.com/Thiink-LLC/teos/pull/1257) at bcce8f1e: APPROVED

== Evidence synthesised ==
- #1250: hexagonal-reviewer APPROVED at 812bec95 (STATUS.md 07:39: map matches the proposal, lint-arch rc=0, root 10 maps rc=0, negative tests rc=1). Head 798b11c5 only drops an unused client self edge, which tightens the map. code-reviewer APPROVED at 798b11c5 (review-1250-code-r2.md, all gate logs rc=0).
- #1257: hexagonal-reviewer APPROVED at bcce8f1e (review-1257-hex.md: map identical to the proposed spec, pass rc=0, broken copy rc=1, root rc=0 with 10 maps).
- Both PRs add a missing map to an existing service. Neither weakens or removes an existing rule, and both encode the layering the service already has (core does not depend on handler).

== ADR decision ==
- One umbrella ADR, not one per service. These are a single cross-service decision applied twice: every Go service must have a go-arch-lint map that `make lint-arch` at the root checks. CONVENTIONS §3 puts cross-service ADRs at the root.
- Path: `docs/adr/0001-go-arch-lint-map-per-service.md` in teos. There is no root ADR folder yet, so this creates it and follows the `<svc>/docs/adr` pattern used by appstore, realestatecore and go-core. Use the next free number if the technical-writer minion finds an existing root series.
- Content: context (services without maps cap hex verdicts at APPROVED_DEGRADED), decision (one map per Go service, additive maps need only a reviewer plus a Lead Architect sign-off that cites this ADR; any change that weakens or removes a rule still needs its own ADR), alternatives (one shared root map; per-service ADRs; leaving maps optional), consequences (root scanner count rises; the tooling pin from review-1257-hex Low).
- Owner: technical-writer minion (packet P-W-2026-0001-la-adr-01). lead-architect approves the text.
- Not merge-blocking for #1250 or #1257: both are additive and approved under this sign-off. The ADR PR should still open straight away so the record exists when Mario merges.

== Follow-ups ==
- [Low] Pin or document the go-arch-lint toolchain (go-arch-lint v1.17.0 with go1.27.3 pulls x/tools v0.37.0, and that build fails). It belongs to the machine-setup owner (platform-lead).

== Correction 2026-10-23 12:55 CEST ==
- My earlier text said depOnAnyVendor is false for both PRs. That is wrong for #1250: buildingsvc sets depOnAnyVendor true because its core still imports the AWS SDK and the CMDB client directly. That breaks the "no AWS in domain" rule (CONVENTIONS §0).
- #1250 stays APPROVED as a baseline map. It records the current state, and it still catches core-to-handler drift. Condition: a tracking issue must exist (owner dev-lead) to move the AWS SDK and CMDB calls behind outbound ports and then flip depOnAnyVendor to false. Link the issue from the #1250 PR body before Mario merges.
- ADR rule added: a baseline map may allow an existing violation only if it links a tracking issue to remove it.
