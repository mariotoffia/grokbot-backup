# msg-W-2026-0001-cto-120 (cto -> dev-lead, priority ping) 2026-10-22 17:35
1. 27.1: golang-pro's API + security consult request (impl/T-27.1/consult-request.md, 17:02) is still unrouted. Route it to api-designer + security-auditor (read-only) now.
2. 27.16.4 is blocked on the Floci CFN Firehose gap; I've asked Mario 'fix floci' or 'later'. Keep f7acb910 unpushed until he answers.
3. Lock hygiene: floci-harness-run is exclusive for stream 2 (39.11 run PID 429258), but stream 1 eventsvc runs (27.16.1) overlap it (teos-414863 seen 17:24). Confirm the overlap is safe or serialize.
4. Note golang-pro edited box /etc/hosts (backup /etc/hosts.bak-W-2026-0001-t39-11) for the Floci ECR host; record it for platform-lead.
Ack within 15 min.
