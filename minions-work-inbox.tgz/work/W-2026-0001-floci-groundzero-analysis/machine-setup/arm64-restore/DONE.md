# arm64 restore DONE — 2026-10-23 07:53 (Europe/Stockholm)

qemu-aarch64 registered (flags POCF). `sudo docker run --rm --platform linux/arm64 alpine uname -m` -> `aarch64`.
Lost on reboot until #1251 lands; re-run: see restore.log. Undo in ../../box-restore.md.
