# PR #1248 review fixes (supersedes security-fixes.md)
Fix commits: af325bab (main hardening), d46bc15a (docker pins, backup prune), f6f2e6d0 (shellcheck clean).

| source | finding | fix SHA / justification |
|---|---|---|
| security | SEC-1248-1 get.docker.com piped to sh | af325bab signed apt repo, key fpr 9DC8…CD88 checked; d46bc15a pins docker-ce/cli/containerd/buildx/compose versions |
| security | SEC-1248-2 fixed /tmp paths | af325bab mktemp -d + EXIT trap; logs in /var/log |
| security | SEC-1248-3 errexit off in apply, no rollback | af325bab apply in `( set -e )`, backup registry + restore on failure, Go verified before swap, iptables refused without backup, daemon.json temp+jq -e+dockerd --validate+install |
| security | SEC-1248-4 Go unpinned | af325bab Go 1.27.3 + sha256 (amd64/arm64) |
| security | SEC-1248-5 nvm/pandoc/opa/act/npm unverified | af325bab sha256 for nvm install.sh, pandoc, opa, act; aws-cdk@2.1146.1, prettier@3.9.10 |
| security | SEC-1248-6 full legacy flush | af325bab only DOCKER* chains, FORWARD jumps and FORWARD DROP policy; backup mode 600; rationale comment |
| security | SEC-1248-7 docker group = root | KEPT: tested 22:16 CEST, harness runs plain `docker` (dockerexec.go:132), DDB test fails without group (permission denied), passes with it; see docker-group-test.log. Header documents root-equivalence |
| security | SEC-1248-8 resolv.conf rewritten after dnsmasq failure | af325bab only after dig @127.0.0.1 answers; search/options kept; restore on failure; UNDO logged |
| security | SEC-1248-9 kills every dnsmasq | af325bab kills only package default pidfile instance or our own pid-less instance, logged |
| security | SEC-1248-10 dnsmasq residuals / hard-coded upstream | af325bab bind-dynamic + listen-address; upstream from resolv.conf/backup, 10.0.0.2 only fallback; MACHINE_SETUP_UPSTREAM_DNS absent |
| security | SEC-1248-11 /var/run old mode | af325bab UNDO logs old mode |
| security | SEC-1248-12 daemon.json non-atomic, pkill | af325bab validate + install, stop_dockerd waits, restart restores config on failure |
| security | SEC-1248-13 backups pile up | d46bc15a keep 5 newest per file |
| code | H1/H2 step/errexit | af325bab (with SEC-3) |
| code | --check exit code | af325bab exit 3 when pending |
| code | dnsmasq after reboot | af325bab early restart block + bind-dynamic |
| code | undo commands for backups | af325bab UNDO log lines |
| code | M5 installers unverified | af325bab |
| code | Lows (USER fallback, empty version, pipefail grep, offline pnpm check) | af325bab |
| code | shellcheck | f6f2e6d0 clean |
| code | M6 GROKBOT.md | no change, correct as is |
| code | M3/M4 GROKBOT docs stale | technical-writer owns; reported only |

## Re-review round 2 (security review-1248-security-2.md, code review approved at 4d44b98e)
| source | finding | fix SHA / justification |
|---|---|---|
| security | N-1 Floci :latest regression | 1bd4d95e: comment records it as an accepted risk (Mario's rule, platform-lead msg-W-2026-0001-platform-lead-133, 2026-10-22); digest logged each run, never compared. image-digest.txt is an evidence file outside the repo; neither the script nor the repo reads it (git grep: no references), so it is left as is |
| security | N-2 Go swap / docker.asc not rolled back; go.bak not pruned | 1bd4d95e Go swap registered (GODIR) and restored on failure; docker.asc backed up; go.bak.* pruned to 3 newest |
| security | N-3 docker group unconditional | 1bd4d95e only when `sudo -n true` succeeds; otherwise an INFO SKIP line with the reason |
| security | N-4 only first fingerprint checked | 1bd4d95e all fpr records must equal {9DC8…CD88 primary, D330…FCD8 subkey} |
| code | N1 go.bak rollback + Go pin >= go.mod | 1bd4d95e rollback as N-2; startup fails clearly if GO_VERSION < go/toolchain requirement |
| code | N2 keep original resolv.conf backup | 1bd4d95e oldest resolv.conf.bak always kept plus newest 5 |
| code | N3 SIGPIPE in gpg|awk | 1bd4d95e gpg output captured to a variable, then parsed |

## Round 3: docker group decision (Mario 22:27, dev-lead, platform-lead)
| source | finding | fix SHA / justification |
|---|---|---|
| decision | SEC-1248-7 / N-3 docker group root-equivalent | dcd0282f step, sudo -n guard and UNDO removed; header updated; comment "Deliberately NOT adding the user to the docker group ... (Mario, 2026-10-22)". Tests needing Docker run as root via sudo: DDB-local test fails as box user without sg (permission denied), passes under sudo (docker-access-test.log). Box user NOT removed from the group on the box |
| security | N-6 sudo -n in --check | moot: the probe was removed with the group step in dcd0282f |
| decision | Floci :latest comment | 4265b733 Mario's rule quoted verbatim |
