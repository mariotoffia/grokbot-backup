Closes #1251

**Stacked on #1248.** This branch is branched from `minion/W-2026-0001-machine-setup` at `c3c4a816`. #1248's later commits `3541fb31` and `da3c2fb2` are merged in with `--no-ff` merges (`88f6e88f`, `640c6597`) rather than a rebase, so nothing was force-pushed. Until #1248 merges, this PR's diff against `main` also includes #1248's commits. The commits owned by this PR are `2aaf336e`, `4e83a3be`, `6c8bd9f4` and later review fixes. Merge policy: if #1248 gets more commits, they are merged into this branch with `git merge --no-ff`; this branch is never rebased or force-pushed.

## Changes (`scripts/grokbot/machine-setup.sh` only)
- **Check-mode gap:** when `iptables-legacy` is not installed yet and the docker engine step is still pending, `--check` now reports the iptables-legacy cleanup as WOULD-CHANGE (exit 3). The docker install can leave stale legacy chains behind, which the real run then removes (the 18 pending vs 16 changes mismatch).
- **arm64 binfmt step:** checks that `qemu-aarch64` is registered under `/proc/sys/fs/binfmt_misc`, enabled, with the F flag, and that an arm64 container prints `aarch64`. It mounts binfmt_misc if needed, replaces a registration that lacks the F flag, and installs with pinned `tonistiigi/binfmt@sha256:400a4873…`. The test image is a pinned `alpine@sha256:be265606…`. `--check` stays read-only and does not pull the test image. The registration is lost on reboot and there's no systemd, so the step runs after `dockerd` and re-registers on every run, the same way dockerd/dnsmasq come back after a reboot. Floci stays `:latest`.
- **Restore-script parity audit:** I compared this script with `box-env-restore.sh`. The only missing item was binfmt; the rest were already covered or are deliberately left out.

## Verified (box, 2026-10-23, at head `88f6e88f`)
Logs: `machine-setup/1251/r2-*.log`. Each log starts with `# sha <head>` and `# cmd <command>`, and ends with `rc=`.
- `shellcheck -S warning`: rc=0. cspell and markdownlint pass on GROKBOT.md.
- `--check`: rc=3, with the arm64 step pending. It only inspects `/proc/sys/fs/binfmt_misc` and runs no container.
- The run started with no registration: rc=0, changes=1, with the UNDO line logged. The rerun gave rc=0, changes=0.
- Replacing a registration without the F flag (flags POC) was run at `b627fdaf`, which has the same tree as `88f6e88f`: `git diff` between them is empty.
- `docker run --rm --platform linux/arm64 alpine uname -m` printed `aarch64` (flags POCF).

## Security / review hardening
- The POCF flags are documented, including why C is accepted.
- The interpreter must be `/usr/bin/qemu-aarch64`.
- The installer runs with `--network none`.
- The UNDO line is logged only when the script registered something.
- Each digest comment gives the image tag and version.
- If installing the replacement fails, the old registration is re-registered.
- GROKBOT.md documents the step and how it behaves after a reboot.

## Untested paths
- The new iptables-legacy `--check` branch. It needs a box without docker or iptables-legacy installed.
- The rollback that re-registers the previous entry when the binfmt install or post-check fails.
- The script mounting binfmt_misc itself; it was already mounted during these runs.
- Replacing a registration that has the F flag but a different interpreter. Only the missing-F case was exercised.
- A real reboot or box swap followed by a rerun.
- An arm64 host, where the step is skipped.
- A run where the pinned binfmt or alpine image can't be pulled (offline).

## Parity audit vs box-env-restore.sh
- Added: arm64 binfmt (qemu-aarch64, F flag).
- Already present: docker install, /var/run 755, dockerd start, Floci :latest pull, nvm, node 22/24, pnpm, nvm default, apt tools, git-lfs init, pandoc, opa, act, go, go tools/regal/oapi-codegen/cbgenerate, npm globals (cdk), ~/.local/bin links (including pnpx).
- Not needed:
  - docker group: left out on purpose because membership is root-equivalent; Docker is used via sudo.
  - legacy `FORWARD -i/-o br-+ ACCEPT` rules: the nft alternative plus the legacy cleanup with FORWARD ACCEPT removes the cause.
  - docker.sock root:docker 660: dockerd already creates it that way.
