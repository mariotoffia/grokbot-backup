# Code review: PR #1252 (draft) @ 2aaf336e, Closes #1251
Reviewer: code-reviewer (read-only, static; no machine-setup.sh, binfmt or docker privileged commands run), 2026-10-23 07:58 Europe/Stockholm. Disk: / 36% used.
GitHub head = 2aaf336ec5143719f020eb1a3810adbe213ca795 and matches the brief. Reviewed sha: 2aaf336e.
Base used: c3c4a816, the current #1248 head on minion/W-2026-0001-machine-setup. I confirmed it is an ancestor of 2aaf336e. The GitHub PR base is main, so the PR's GitHub diff also includes #1248's commits.
Delta: one commit (2aaf336e), scripts/grokbot/machine-setup.sh only (+51/-1). bash -n OK. In scope. No secrets.
Issue: #1251 is OPEN (labels enhancement, devops, build; Size Hours; Priority Low). closingIssuesReferences=[1251]. Assignee mariotoffia. Copilot threads: 0.

## Verdict: CHANGES_REQUESTED
Blocking: H1 (evidence has no sha and no rc lines) and M1 (GROKBOT.md doesn't mention binfmt or the reboot rerun).
The code logic is sound.

## Checks
- Idempotency: OK.
  - binfmt_registered needs qemu-aarch64 to be "enabled" with "flags: …F".
  - apply only removes a registration that fails that test, and only installs when the registration is absent.
  - The rerun log shows the arm64 step OK and changes=0.
- --check: OK.
  - step() never calls apply in check mode. check_binfmt returns 1 before touching docker when the registration is missing (1-check.log: WOULD-CHANGE, would-change=1).
  - No pulls: when the test image is absent it checks the registration only. The binfmt image is only used in apply.
  - Caveat L3: when the alpine image is cached, check mode does run a container.
- Rollback: the pattern matches #1248, with apply in a ( set -e ) subshell, a post-check and restore_backups. There is nothing to back up for the mount or registration, so only UNDO lines are logged. See L1.
- Reboot: the script header (:6-7) and the step comment say to rerun after a reboot, and the step re-registers on every run. There is no boot hook, consistent with dockerd and dnsmasq. GROKBOT.md (reboot/box-swap section ~:199-202) does not mention binfmt (M1).
- set -euo pipefail:
  - The && chains in check_ipt_legacy and binfmt_registered are not the last command, so a false result doesn't trip errexit.
  - `echo -1 | sudo tee` is fine under pipefail.
  - `$(cat …)` runs only after the -f guard.
  - No issues.
- Pins: BINFMT_IMAGE and ARM64_TEST_IMAGE are @sha256. I resolved both digests read-only against Docker Hub: both are multi-arch indexes that include amd64 and arm64. FLOCI_IMAGE is still mariotoffia/floci:latest, unpinned as required.
- iptables --check fix: correct.
  - It returns 1 only when CHECK_ONLY=1, iptables-legacy is absent and the docker engine step is still pending. In that case the docker install can create legacy state that the run cleans up, which explains the 18-vs-16 mismatch.
  - In apply mode the old behaviour is kept (absent → OK), and the step runs after the docker engine step (:400 then :477), so apply sees the real binary.
  - No regression.
- Floci-only: no AWS calls were added.

## Evidence (machine-setup/1251, arm64-restore)
Files are timestamped 07:54:41–07:54:51 Europe/Stockholm.
- 1-check.log: WOULD-CHANGE for arm64 only, SUMMARY would-change=1, mode=check.
- 2-run.log: CHANGE, "installing: arm64 OK", UNDO line, changes=1.
- 3-rerun.log: OK, changes=0, would-change=0.
- 4-arm64-test.log: uname aarch64, flags POCF.
- 0-shellcheck.log: rc=0.
- arm64-restore/restore.log: the earlier manual restore pulled by the same digests and shows POCF and aarch64.
- The box now shows /proc/sys/fs/binfmt_misc/qemu-aarch64 enabled with flags POCF (read-only cat).
- The logs support the claims, but see H1.

## Findings
- H1 [High] [testable] machine-setup/1251/1-check.log, 2-run.log, 3-rerun.log — no "# sha 2aaf336e" header and no exit codes. The brief's rc=3 / rc=0 / rc=0 can't be verified; only the SUMMARY lines exist. 0-shellcheck.log and 4-arm64-test.log carry no sha either. Fix: re-run check, run and rerun at 2aaf336e with a sha header and an "rc=$?" line in each log, as in the #1248 evidence.
- M1 [Medium] [non-testable] GROKBOT.md (reboot/box-swap section, ~:199) — it does not say that the arm64 binfmt registration is lost on reboot and comes back on rerun. The step list doesn't mention the binfmt step or its pinned images either. Fix: add binfmt to the reboot paragraph and the step list.
- L1 [Low] [hard-to-test] machine-setup.sh apply_binfmt (replace path) — an existing registration without the F flag is removed (`echo -1`) before the install. If the install or post-check fails, restore_backups cannot restore it, so the box ends up worse than before (no qemu-aarch64 at all). Fix: save the old registration line before removing it, or install first; at least log how to re-register.
- L2 [Low] [testable] apply_binfmt last line — `log UNDO "echo -1 …"` is logged even when apply registered nothing (for example, already registered but the container test failed). Fix: log UNDO only on the branch that ran the installer.
- L3 [Low] [testable] check_binfmt — in --check with the alpine image cached, it runs `docker run --rm --platform linux/arm64 …`. No pull and no lasting change, but it is not strictly read-only. Fix: in check mode, check the registration only, or document that a container is run.
- L4 [Low] [hard-to-test] — these paths are untested, as the PR body says: the new iptables --check branch, the F-less replacement, the mount, and a real reboot. Fix: optionally simulate the F-less case with a temporary registration on a scratch box.
- L5 [Low] [non-testable] PR #1252 and issue #1251 titles — they don't start with W-2026-0001; the minion convention is "<W-id> T-<x>: …". Fix: retitle both.
- I1 [Info] — #1248's head is now c3c4a816 (GOBIN tweak). This branch is rebased onto it, as the body says.
- I2 [Info] — the binfmt step runs before the dnsmasq, resolv and daemon.json steps. On a fresh box the pulls rely on the host resolver; the #1248 early dnsmasq restart covers the reboot case.

# Re-review — PR #1252 @ 88f6e88f (2026-10-23 08:03 Europe/Stockholm)
GitHub head = 88f6e88ffad100d451e66d2ef30fa342d27043f9 and matches the brief. Reviewed sha: 88f6e88f. Draft.
Base used: 3541fb31, the current #1248 head (confirmed via gh). It is an ancestor of 88f6e88f.
Delta vs base: GROKBOT.md +11, machine-setup.sh +80/-1. Commits 2aaf336e, 4e83a3be and 6c8bd9f4, plus the merge 88f6e88f. In scope. bash -n OK. No secrets. Copilot threads: 0.
Merge: `git merge-tree --write-tree 6c8bd9f4 3541fb31` = 138afc49 = 88f6e88f^{tree}. That is a clean merge with no conflict edits. Its first-parent delta is the same 3-line machine-setup.sh change as c3c4a816..3541fb31, and nothing else.

## Verdict: APPROVED
No High or Medium remains. Floci is still mariotoffia/floci:latest (:68). Both binfmt images stay @sha256-pinned and now carry a tag/version comment.

## Earlier findings
- H1 RESOLVED. Every r2-*.log carries "# sha 88f6e88f…" and an rc line (08:01:47–08:01:52 Europe/Stockholm):
  - r2-1-check: arm64 WOULD-CHANGE, would-change=1, rc=3.
  - r2-2-run: CHANGE, "installing: arm64 OK", UNDO, changes=1, rc=0.
  - r2-3-rerun: OK, changes=0, rc=0.
  - r2-0-shellcheck: rc=0.
  - r2-4-arm64-test: records its cmd, rc=0.
- M1 RESOLVED. GROKBOT.md has an "arm64 emulation" bullet in the step list (POCF, pinned images, Exec format error, --check reads /proc only). The reboot section has a paragraph saying the registration is lost and a rerun restores it. Words added to cspell.
- L1 RESOLVED (untested, logic sound). Before the old entry is removed (echo -1), binfmt_register_line rebuilds ":qemu-aarch64:M:offset:magic:mask:interpreter:flags" from the entry, with magic and mask hex turned into \xNN escapes that the kernel parses.
  - If the install or post-check fails (inside an if, so errexit doesn't fire), it removes any partial entry, writes the old line to /register, and returns 1. step() then logs FAIL and exits 1.
  - A failure of the save or the removal aborts under set -e before anything is lost.
  - binfmt_registered now also requires interpreter /usr/bin/qemu-aarch64.
  - Noted as untested in the PR body.
- L2 RESOLVED. apply returns early when already registered. UNDO is logged only after a successful install, plus the mount UNDO only when it mounted.
- L3 RESOLVED. In --check (CHECK_ONLY=1) check_binfmt returns after reading $BINFMT and runs no container. Container runs (apply-mode check and install) use --network none.
- L4 RESOLVED. The PR body "Untested paths" lists:
  - the iptables --check branch
  - the rollback re-register
  - the self-mount
  - replacing a registration with a different interpreter
  - a reboot
  - an arm64 host
  - offline pulls
- L5 RESOLVED. PR title "W-2026-0001: build: machine-setup check-mode gap, …". Issue #1251 title "W-2026-0001: machine-setup.sh: …" (gh).

## New findings (none blocking)
- N1 [Low] [hard-to-test] machine-setup.sh binfmt_register_line — the rollback re-registers the old entry as enabled even if it was disabled. A "disabled" state is not restored. Fix (optional): if the saved entry was disabled, write 0 to the entry after re-registering.
- N2 [Info] r2-4-arm64-test.log ran `alpine` by tag, not the pinned ARM64_TEST_IMAGE. It is evidence only; the script's own check uses the digest.
- N3 [Info] The PR body says both "merged, nothing force-pushed" and "will be rebased onto it". Pick one policy for future #1248 updates. The live PR body differs slightly from the local pr-body.md (whitespace or edit); the live one carries the fields checked above.
