#!/usr/bin/env bash
# Harness: run only apply_rc from machine-setup.sh in a throwaway HOME, with mv forced to fail.
S=${1:?script}; T=$(mktemp -d); export HOME=$T/home; mkdir -p "$HOME" "$T/bin"
echo 'echo orig' >"$HOME/.bashrc"; chmod 600 "$HOME/.bashrc"
printf '#!/bin/sh\necho "shim mv: forced failure" >&2\nexit 1\n' >"$T/bin/mv"; chmod +x "$T/bin/mv"
SOURCE_LINE=$(grep -m1 '^SOURCE_LINE=' "$S" | cut -d= -f2-)
FUNCS=$(grep -E '^mask_go_w\(\)' "$S"; awk '/^apply_rc\(\) \{/,/^}/' "$S")
( eval "SOURCE_LINE=$SOURCE_LINE"; backup() { :; }; eval "$FUNCS"
  PATH=$T/bin:$PATH; set +e; ( set -e; apply_rc ); echo "apply_rc rc=$?" )
echo "HOME=$HOME contents:"; ls -A "$HOME"
n=$(find "$HOME" -name '.bashrc.*' | wc -l); echo "leftover .bashrc.* count=$n"
echo ".bashrc unchanged: $(cat "$HOME/.bashrc")"; rm -rf "$T"; [ "$n" -eq 0 ]
