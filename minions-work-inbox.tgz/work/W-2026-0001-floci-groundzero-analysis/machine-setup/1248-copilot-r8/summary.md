# PR 1248 Copilot loop r8 (2026-10-23 CEST)
R1 f23dd485: 2 new threads (Go root-owned, DOCKER-USER guard) + 3 missed (iproute2/procps, act/nvm version checks) -> fixed 976af623, threads replied+resolved.
R2 976af623: 1 thread (DOCKER-USER SIGPIPE) -> fixed 6cc60c09, replied+resolved.
R3 6cc60c09: NOT clean. Open threads: PRRT_kwDOQ12eZc6vj68b dnsmasq PID ownership (L562); PRRT_kwDOQ12eZc6vj69O restore package dnsmasq on failed replacement (L579). Missed: cbdeploy capability check (L298), defer cbdeploy until generated code (L300). Unfixed: hit the 3-round cap.
Checks: CodeQL/Analyze pass; others skipping.
R4 6cc60c09 (user directed): dnsmasq pid via /proc comm, pkg dnsmasq restart on rollback, soft cbdeploy -> 078c5fe0; PR comment on cbdeploy decision. Harness r4-harness.sh 8/8.
R5 078c5fe0: 1 thread (cbdeploy check/apply consistency) + missed pnpm active version -> 4072ea39.
R6 4072ea39: no open issues/threads. Missed notes (no threads, unfixed): oapi-codegen version regex unanchored (L309); nvm check sources nvm.sh without --no-use (L324).
R7 768f782d (oapi exact, nvm --no-use) + docs 36292726 pushed; Copilot pass on 36292726 clean (no issues, no missed); checks pass/skipping.
