#!/bin/bash
# Extracts the pid helpers and restart_pkg_dnsmasq; signals nothing real.
set -euo pipefail
S=/workspace/repos/teos/.worktrees/W-2026-0001-machine-setup/scripts/grokbot/machine-setup.sh
eval "$(sed -n '/^is_dnsmasq_pid()/p;/^pidfile_dnsmasq()/p' "$S")"
eval "$(sed -n '/^restart_pkg_dnsmasq()/,/^}/p' "$S")"
log() { echo "LOG $*"; }; sudo() { echo "SUDO $*"; }
t=$(mktemp -d); ok=0; bad=0; chk(){ if eval "$2"; then echo "PASS $1"; ok=$((ok+1)); else echo "FAIL $1"; bad=$((bad+1)); fi; }
echo $$ >"$t/self"; echo 99999999 >"$t/gone"; echo junk >"$t/junk"
chk "own bash pid is not dnsmasq" '! pidfile_dnsmasq $t/self >/dev/null'
chk "dead pid is not running" '! pidfile_dnsmasq $t/gone >/dev/null'
chk "non-numeric pid rejected" '! pidfile_dnsmasq $t/junk >/dev/null'
chk "missing file not running" '! pidfile_dnsmasq $t/none >/dev/null'
real=$(pgrep -x dnsmasq | head -1 || true)
[ -z "$real" ] || { echo "$real" >"$t/real"; chk "real dnsmasq pid recognised (read only)" '[ "$(pidfile_dnsmasq $t/real)" = "$real" ]'; }
dnsmasq_running() { return 1; }
chk "restart issued when pkg was running" '[ "$(restart_pkg_dnsmasq /usr/sbin/dnsmasq -x /run/dnsmasq/dnsmasq.pid | grep -c "^SUDO /usr/sbin/dnsmasq")" = 1 ]'
chk "no restart when pkg was not running" '[ -z "$(restart_pkg_dnsmasq)" ]'
dnsmasq_running() { return 0; }
chk "no restart when ours answers" '! restart_pkg_dnsmasq /usr/sbin/dnsmasq | grep -q SUDO'
echo "pass=$ok fail=$bad"; [ "$bad" = 0 ]
