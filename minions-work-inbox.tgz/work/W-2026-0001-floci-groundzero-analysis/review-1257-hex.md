# Hexagonal review — DRAFT PR #1257 @ bcce8f1e (ingestionsvc go-arch-lint map, Closes #1256)
Reviewer: hexagonal-reviewer minion (read-only). 2026-10-23 12:45 CEST. Floci-only, no AWS.

== Verdict ==
APPROVED

## Scope
- 1 commit: bcce8f1e "chore(ingestionsvc): add go-arch-lint map and lint-arch target". PR title: "ingestionsvc: add go-arch-lint map and lint-arch target". Neither has a W-id prefix.
- Diff (vs merge-base): go-services/ingestionsvc/.go-arch-lint.yml (+44) and go-services/ingestionsvc/Makefile (+6, lint-arch target). Nothing else changed.

## Spec match
- After stripping comments and blank lines, the map is identical to impl/T-27.16.4/review-hex/proposed-ingestionsvc.go-arch-lint.yml: workdir ingestionsvc, depOnAnyVendor false, components errorcodes/core/handler, excludes _test.go and deployment/.

## Evidence
| Check | Implementer | Reviewer (worktree /tmp/hx1257) |
|---|---|---|
| map pass | impl/ingestionsvc-arch-lint/gates/lint-arch-service-pass-bcce8f1e.log rc=0 | review-hex-evidence/1257-pass-bcce8f1e.log rc=0 "OK - No warnings found" |
| broken copy | lint-arch-service-broken-fail-bcce8f1e.log rc=1 | review-hex-evidence/1257-broken-bcce8f1e.log rc=1 (core mayDependOn [handler]: 2 violations core->errorcodes, serialization.go:8 and transform.go:10) |
| root make lint-arch | lint-arch-root-bcce8f1e.log rc=0, 10 maps | review-hex-evidence/1257-root-bcce8f1e.log rc=0, 10 maps (849de752 shows 9) |

== Findings ==
- [Low] [non-testable] tooling: a clean `go install github.com/fe3dback/go-arch-lint@v1.17.0` with go1.27.3 pulls x/tools v0.37.0 and fails ("internal error: package go-core/cberror without types"), so the gate cannot run. The box binary ~/go/bin/go-arch-lint (v1.17.0, x/tools v0.50.0) works. This is not a defect in the map. Fix: pin or document the toolchain for lint-arch (machine-setup).
- [Info] CONVENTIONS §1 requires an ADR and Lead Architect approval for arch-lint config changes. This PR adds a new map and does not weaken an existing one. Confirm that the Lead Architect sign-off is recorded before Mario merges.

## delta @7139f4b8 — 2026-10-23 12:50 CEST
Commits: 5c0480ac "chore(ingestionsvc): drop the unused cberror grant from the handler", 7139f4b8 "docs(lint): list the ingestionsvc architecture map". Neither subject has a W-id prefix. PR is still OPEN/draft.

== Verdict ==
APPROVED. The deviation from my spec (cberror moved out of core-pure into a new vendor group, core-errors, that only core may use) is ACCEPTED: it is stricter than the spec and is proven to work.

## Diff
- Map bcce8f1e→7139f4b8 (+2/-2): adds `core-errors: { in: github.com/Thiink-LLC/teos/go-core/cberror }`, removes cberror from core-pure, and changes core to `canUse: [core-errors, core-pure]`. Handler canUse is unchanged (core-pure, core-runtime, aws-lambda, zerolog), so the handler no longer gets cberror.
- Whole PR vs merge-base: .go-arch-lint.yml (+44), ingestionsvc/Makefile (+6), and also **LINT.md (+2/-2, docs only)**: ingestionsvc is added to the "package inside a larger module" row and the list of maps grows from 10 to 11. That is more than "map plus Makefile", but it is the right doc update for the map (CONVENTIONS §3), so I accept it. The LINT.md count of 11 and the root count of 10 are consistent: LINT.md already explains that the two eventsvc maps are counted once.

## Checks
- go list: handlers/... have **0 direct imports** of go-core/cberror. They reach it only through ingestioncore, and go-arch-lint checks direct imports only. Dropping the grant does not hide a violation.
- core-errors is exactly one package path (no `/**`), and only core's canUse includes it. ingestioncore imports cberror directly, so core really does need it. The group is not too broad.
- Implementer gates in impl/ingestionsvc-arch-lint/gates/, every header sha 7139f4b8: gofmt rc=0, vet rc=0, golangci rc=0 (also a cached run, rc=0), lint-arch-service rc=0, lint-arch-root rc=0 with 10 maps, test rc=0. lint-arch-root-7139f4b8-interrupted.log has no rc; the complete run replaces it. There is no implementer broken-copy log at 7139f4b8; my rerun below covers that.

## Reviewer runs (~/go/bin/go-arch-lint v1.17.0, worktree /tmp/hx1257, removed afterwards)
| Case | rc | Log |
|---|---|---|
| map pass | 0, OK | review-hex-evidence/1257-pass-7139f4b8.log |
| old broken copy (core mayDependOn [handler]) | 1, 2 violations core→errorcodes (serialization.go:8, transform.go:10) | review-hex-evidence/1257-broken-7139f4b8.log |
| new negative: blank import of cberror added to handlers/dstransform/main/main.go, map unchanged | 1, "Component handler shouldn't depend on go-core/cberror" main.go:4 | review-hex-evidence/1257-handler-cberror-neg-7139f4b8.log |
| root make lint-arch | 0, 10 maps | review-hex-evidence/1257-root-7139f4b8.log |

== Findings ==
- [Info] The PR also touches LINT.md (docs only). Accepted.
- [Low] Unchanged from the first review: the go-arch-lint toolchain needs pinning, because a clean v1.17.0 install with go1.27.3 fails.
- [Info] Unchanged from the first review: the Lead Architect sign-off required by CONVENTIONS §1 still needs to be confirmed before merge.
