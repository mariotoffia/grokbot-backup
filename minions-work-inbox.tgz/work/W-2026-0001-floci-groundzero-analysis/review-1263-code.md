# Code review: PR #1263 (draft, Closes #1262)

Head confirmed: 72f404c67d01234754541055f118b5180abc59ec (not moved). Base is main 865f50cc.
The diff is the 2 claimed files only: `go-services/ingestionsvc/deployment/service-test/ingestion_test.go` (+9/-1) and `sinks_helpers_test.go` (+15/-5). There is one commit.

## Verdict: CHANGES_REQUESTED

## 1. Copilot threads on #1255
Earlier pagination threads 4358717898 and 4358717928 were already fixed in 5124119e on #1255 and are not part of this delta.

The 3 newer threads:
- 4359882943, AWS reuse without trace: addressed. The Logs checks are gated on `harness.Target() == cbenv.DeploymentTargetLocal` (ingestion_test.go:307), with a t.Logf on other targets.
- 4359986238, same point at ingestion_test.go:303: addressed by the same gate.
- 4359986309, count across all devices: addressed. `assertLogsOutput` takes `thingName` and counts only events containing `$aws/things/<thing>/`. The IoT rule SQL is `SELECT *, topic() as topic ...` (stack_part2.go:118), and dstransform logs `RawJSON("record", ...)` at trace (dstransform/main/main.go:63-69), so the topic is in the logged message.

The gate goes further than Copilot asked, see M1.

## 2. Mario's 15:24 rule (no Floci-only tests)
- On Floci, TestIngestionServiceFlow still drives TEOS end to end: shadow update → TEOS IoT rule → Firehose → TEOS dstransform Lambda → S3 → CbSensorReportItem validation, plus assertFirehoseDeliveryStream on the deployed config. The Logs checks assert TEOS Lambda output and TEOS error log groups. It is not emulator-only. OK.
- On AWS only the Logs block is skipped. The S3/domain assertions and assertFirehoseDeliveryStream still run there, and the skip is logged, not silent. OK, with one exception (M1).

## 3. Per-item count
- The trailing `/` in `$aws/things/<thing>/` prevents prefix collisions such as svctest-abc vs svctest-abcd. The thing name carries a per-run suffix (ingestion_test.go:90). The counter is reset on every Eventually attempt, and every attempt reads all pages. Eventually waits for >= recordsSent, then require.Equal checks exactly 1.
- Not flaky in practice. The only theoretical double count is a Firehose retry re-invoking the Lambda for the same record, which happens only after a transform failure and would then rightly fail the test. The Floci run logged 1 event for 1 record sent.

## 4. Gates
Logs in impl/ingestion-log-review-followup/gates/:
- gofmt, vet, golangci, lint-arch-root, tidy and unit all rc=0, each with a `sha 72f404c6...` header.
- test-service-race has a `HEAD 72f404c6` header and rc=0: TestIngestionServiceFlow PASS (80s), per-thing count 1/1.
- svcroot-wrapper.log rc=0 has no sha header (Info).

My reruns in a clean worktree at 72f404c6:
- gofmt -l: empty.
- go vet: OK with `-tags e2e,floci`, with `-tags e2e`, and with no tags.
- go test -race: service-test (unit), handlers/... and ingestioncore/... all ok.

All gates are green.

## 5. Issue #1262 and process
- Title `ingestionsvc: address Copilot review comments on log assertions`: no prefix. OK.
- Assignee mariotoffia. Labels follow-up, go, core. Issue Fields Priority=Medium and Size=Hours. OK.
- Board (R&D Sprint Board #2): Status = **Progress**, not Incoming (see L1). Roadmap is unset. OK.
- PR title `test(ingestionsvc): address review comments on log assertions` and the commit subject: no W-/T- prefix. OK.
- Comments in the touched files: no plan IDs (I grepped for W-20, T-2, FG-, Floci 44, 27.). OK.

## Findings
### Medium
- M1: The Floci gate also skips TEOS assertions that don't need trace. Inside `assertLogsOutput`, only the transform-count part needs `logLevel: trace`. The "Firehose delivery error stream is empty" and "IoT rule error log group is empty" checks (sinks_helpers_test.go, the loop after the count) assert TEOS pipeline health at any log level. They worked on AWS before this change and are now skipped there, which hides TEOS coverage on real AWS. Fix: split the helper so that only the trace-dependent count is gated, e.g. `assertTransformLogged` (local only) and `assertNoPipelineErrors` (all targets). Also fix the comment and the t.Logf, which say the Logs checks as a whole need trace.
### Low
- L1: The project Status for issue #1262 is "Progress", not Incoming as the issue-first checklist requires. It may simply have moved on with the PR, so confirm or reset it.
### Info
- I1: svcroot-wrapper.log has no sha/HEAD header, though rc=0.
- I2: The gate uses `== cbenv.DeploymentTargetLocal`, while the file elsewhere uses `harness.Target().IsLocal()`. The behaviour is the same, but the style is inconsistent.

All required gates are green. CHANGES_REQUESTED is for M1 only.

---
## Delta 1: 72f404c6..d1ec3658

Head confirmed: d1ec3658b4fb2879cc617618fe47a3d58c4ecae5 (not moved).
Files: ingestion_test.go, provision-config.yaml, sinks_helpers_test.go, and the new s3items_test.go and s3items_unit_test.go (+71/-83).

### Verdict: APPROVED

1. **M1 fixed.** `assertNoPipelineErrors` (sinks_helpers_test.go) runs on every target. git grep finds no `DeploymentTargetLocal`, `IsLocal` or target branch left in service-test.
2. **itemsForThing** (s3items_test.go) does an exact `LocationID == thingName` match, which is safe against prefix collisions. LocationID is the thing name taken from the topic by dstransform. The helper filters the items of the one object already loaded. It does no S3 listing itself, so it neither pages nor polls. Eventual consistency is handled upstream by the existing SQS poll (15s × up to 180s) for the ObjectCreated notification. See L2.
3. **Exact count.** The rule `WHERE endswith(clientToken,'inbound')` on update/accepted makes one accepted update produce one Firehose record, so the mapping is 1:1. A rejected update errors out of UpdateThingShadow before `recordsSent++`. dstransform emits one item per sensor (main.go:119), and the payload has 1 sensor, so expecting 1 item is correct (L3). Firehose buffering puts one record in one object. A duplicate is possible only on a Lambda/Firehose retry after a failure, which should fail the test anyway. On Floci the run loaded 1 item from 1 object. Not flaky on Floci. On shared AWS see L2.
4. **Unit tests.** `TestItemsForThingKeepsOnlyThatThing` covers order, multiple matches and the `svctest-ab` prefix collision. `TestItemsForThingNoMatch` covers the empty result. Small but meaningful for an exact-match filter.
5. **Trace revert.** provision-config.yaml no longer has the logLevel override, so the stack default is info. git grep finds no `assertLogsOutput`, `transformRecordPattern`, `transformLogGroupName`, `logsEventually*` or "About to transform". The only remaining "trace" in service-test code is the step-7 comment saying nothing needs it. The others are go.sum otel entries.
6. **15:24 rule holds.** The test drives TEOS (IoT rule → Firehose → dstransform → S3 → SNS/SQS) and asserts the transformed domain items exactly per thing, plus the deployed Firehose config and the TEOS error log groups. None of it is emulator-only.

Gates:
- The `*-d1ec3658.log` files all have rc=0 and a sha header: gofmt, golangci, lint-arch-root, tidy, unit and vet, plus test-service-race with a HEAD header (TestIngestionServiceFlow PASS, 80s).
- svcroot-wrapper-d1ec3658.log rc=0 still has no sha header (Info).
- My reruns in a clean worktree at d1ec3658: gofmt empty; go vet OK with e2e,floci, with e2e and with no tags; go test -race ok, with all 7 unit tests passing.

Process:
- The board Status for #1262 is now **Incoming**, so the R1 L1 is resolved.
- New commit subject `test(ingestionsvc): check S3 items per thing and run error-log checks…`: no prefix.
- No plan IDs in comments.

### Findings
- L1 (Low, dead code per AGENTS.md cleanup): `filterLogEvents`'s `stopAtFirst` is now only ever passed `false` (sinks_helpers_test.go:99). The `true` branch (logpages_test.go:40) and `TestFilterLogEventsStopAtFirstAfterEmptyPages` exist only to test it. Drop the parameter and that test.
- L2 (Low, existing before this delta): the test loads only the first `ingestion/` ObjectCreated notification. On a shared AWS deployment another device's object can arrive first, and then `require.Len(..., 1)` fails, as `found` did before. It is fine on Floci. Optional hardening: keep polling and load objects until this thing's items appear.
- L3 (Low, wording): "exactly one transformed item per update" is true only because the payload has one sensor. dstransform emits one item per sensor. Consider naming it expectedItems = recordsSent × len(Sensors), or saying so in the comment.
- I1 (Info): svcroot-wrapper log has no sha header.

## Delta 2: d1ec3658..0cc8726b (head 0cc8726bcbac7224907e3d0f08d7a4a6b1a42c34, unchanged) — 2026-10-23 16:33 CEST

**Verdict: APPROVED**

Fix check:
- L1 is fixed. stopAtFirst is removed from filterLogEvents, the StopAtFirst unit test is gone, all callers are updated, and git grep finds no remaining references.
- L2 is fixed. Each new ingestion/ object announced over SQS is deduped by S3 key, loaded, filtered to this thing, and its items are summed.
  - Time window: there is no time filter, but the queue is a fresh per-test subscription and the thing name is unique per run, so stale or foreign objects add 0 items.
  - Redelivered SQS messages (they are never deleted) are deduped by key, so nothing is counted twice.
  - The loop stops at >= expected. require.Len(expected) then catches any over-count already seen.
- L3 is fixed: expected = recordsSent × len(sensors).
- I1 is fixed. svcroot-wrapper-0cc8726b.log has the full sha on line 2, after the "wrapper start" line. Every other *-0cc8726b.log has a sha/HEAD header and rc=0.

Findings:
- I2 (Info): require.Nil inside loadThingItems aborts the test if any foreign object fails to load. On shared AWS, skip-and-log would be more robust. Under Floci this is harmless.
- I3 (Info): stopping at >= expected means items that arrive late (Firehose retry duplicates) are not detected.

Gates:
- Logs are all rc=0. TestIngestionServiceFlow PASS (80s), loaded 1/1 items.
- My rerun in a clean worktree, with TEOS_DEPLOYMENT, AWS_ENDPOINT_URL and TEOS_LOCAL_KEEP unset:
  - gofmt is clean.
  - vet passes with e2e,floci, with e2e, and untagged.
  - go test -race: ok, all unit tests pass.
- gh pr checks: CodeQL, actions and JS pass. Build, Arch, Static, Unit and Bugbot were skipped (this is a path filter, not a failure).
- Copilot: 0 inline comments. Its overview review says "Approval recommended".

Hygiene: the commit subject has no W-/T- prefix, there are no plan IDs in the code, and the 15:24 rule is met (the test drives the TEOS pipeline and dstransform).
