# W0 QA — P-2026-0001-03 rerun (qa-lead) — 2026-10-21 15:20–15:40 (UTC+2)

## Image digest
- TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7
- docker inspect RepoDigests: ["mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7"]; Id sha256:3e16af2e77b24b728a968cd934acdaaaeca2c07bff0331e3dc72f839b0f0e034 (amd64). The emulator reports itself as "AWS Local Emulator 2.3.0". Neither :latest nor the superseded sha256:6e4341f3 was used.

## Commit
/workspace/repos/teos HEAD = a3543337fecc19d11bcfe78157a9ef36731546c5 (origin/main). `git status --porcelain` was empty after the runs: no repo edits.

## Commands
Wrapper /tmp/w0/run.sh (copy in evidence-w0/):
```
export PATH=$HOME/go/bin:$HOME/.local/bin:$PATH COREPACK_HOME=$HOME/.cache/node/corepack
export TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7
cd /workspace/repos/teos/$1 && CB_SERVICE_TEST=$2 go test -tags=e2e,floci -count=1 -v -timeout 30m ./...
```
- `sg docker -c 'bash /tmp/w0/run.sh go-services/buildingsvc/deployment/service-test building-service'`
- `sg docker -c 'bash /tmp/w0/run.sh go-services/providers/eastbound/sur/deployment/service-test sur-provider'`

Env debug round (1/1, used): the first building run failed because Floci could not reach DynamoDB Local (container-to-container timeout). Cause: the box has iptables-legacy FORWARD policy DROP, while dockerd uses nft. Fix, box only and not persistent: `iptables-legacy -I FORWARD 1 -i br-+ -j ACCEPT` and `-o br-+ -j ACCEPT`. After the fix a busybox probe confirmed containers on the same network can reach each other.

## A1 (W0.3) result (rerun 2026-10-21 ~15:31–15:36 UTC+2)
Precheck: /proc/sys/fs/binfmt_misc/qemu-aarch64 = enabled, interpreter /usr/bin/qemu-aarch64, flags POCF. Repo at a3543337 with a clean working tree (porcelain count 0). Same wrapper and digest as above, with no further env fixes needed (debug round not used).

### building-service: PASS, 0 HTTP 403s (#5450 / 44.2 not reproduced)
`sg docker -c 'bash /tmp/w0/run.sh go-services/buildingsvc/deployment/service-test building-service'` gave `ok ... service-test 275.012s`, rc=0 (log: evidence-w0/building2.log).
Tests: TestLCSAPIClient (+ subtests QueryBuildingNotFound, InsertDeleteBuilding, InsertBuildingAndServicesQueryAndDelete, InsertBuildingAndProvidersQueryAndDelete, DeleteBuildingWithCFOSettings), TestProviderConfigChangeWithABAC, TestProviderConfigChangeRoundTrip, TestConfigDispatcherFlow, TestCfgImportFlow: all PASS, none FAIL or SKIP.
`grep -c -E "\b403\b|AccessDenied|Forbidden" building2.log` = 0.
The first rerun's failure (arm64 Exec format error) was fixed by binfmt.

### sur-provider: PASS, 0 HTTP 403s (rerun 2026-10-21 ~15:43–15:46 UTC+2)
CB_DEFAULT_GEOCODERAPI_KEY was present in .env (presence check only, never printed). Command: `sg docker -c 'bash /tmp/w0/run.sh go-services/providers/eastbound/sur/deployment/service-test sur-provider'` gave `ok ... 164.142s`, rc=0. Log: evidence-w0/sur2.log, scanned for the key value: 0 occurrences.
Counts: 5 PASS, 0 FAIL, 1 SKIP. PASS: TestSurApiIngest, TestSurApiActuate, TestSurApiSubscribeAndAck, TestConfigChangeWritesToS3, TestSurApiGeoLookup. SKIP: TestSurApiLogImportAndVerify (repo hard-skips it on local targets, citing the floci binary-media-types gap; this is the 27.29 marker).
`grep -c -E "\b403\b|AccessDenied|Forbidden" sur2.log` = 0.

## A2 (W0.5) #5131 gzip binary body reaches Lambda intact: YES, by a standalone probe against the pinned image
The repo has no local check (the SUR log-import test skips locally), so I ran a probe outside the repo (evidence-w0/a2/handler.py, probe.py, probe2.py):
- Started the pinned Floci (docker socket mounted, network w0a2, FLOCI_SERVICES_DOCKER_NETWORK) and created a python3.12 Lambda that returns isBase64Encoded, the decoded length, sha256 and the gzip magic bytes. Called it through a REST API AWS_PROXY integration with binary media types application/gzip and application/octet-stream.
- `python probe.py` (binaryMediaTypes set through CreateRestApi):
  SENT len=99 sha256=54c98ee9af9858516afa88a471f7e25f3c93534dfb67ef61df6fffa9d0c75c73
  application/gzip → HTTP 200 {"isBase64Encoded": true, "len": 99, "sha256": "54c98ee9…3c73", "gzip_magic_ok": true}
  application/octet-stream → HTTP 200, identical len and sha256.
- `python probe2.py` (ImportRestApi with OpenAPI `x-amazon-apigateway-binary-media-types`, the path the repo skip comment says is unsupported):
  imported binaryMediaTypes = ['application/gzip','application/octet-stream']
  SENT len=99 sha256=69faf709be6704e15b9bb89367af647f30908e6fb2a6de68216d44cb13ff8fe2
  both content types → HTTP 200, isBase64Encoded true, len 99, identical sha256, gzip_magic_ok true.
- Caveat: this is not the real SUR stack deployed through CDK/cbdeploy (that path is blocked as in A1). It shows the emulator API Gateway → Lambda path keeps the gzip bytes intact. The repo's local skip in e2e_logs_geo_test.go:51-54 now looks stale.

## Verdict: GO
- W0.3: building-service (10 PASS) and sur-provider (5 PASS, 1 local-only SKIP) against mariotoffia/floci@sha256:9710d466..., commit a3543337: **no 403/AccessDenied/Forbidden**. R1 / 44.2 hazard not observed, and the W0.4 hold condition is not triggered.
- W0.5: YES (accepted; standalone probe).
- 27.27 (Cognito domain markers in buildingsvc helpers_api_test.go:52 / sur helpers_auth_test.go:50 + production GetAccountDomain check): gate is "W0.3 clean", which is MET. This run exercised those helpers (all passing) but did not test GetAccountDomain or remove markers; that remains W4 work.
- 27.29 (SUR gzip log import, marker e2e_logs_geo_test.go:52): gate is "W0.3 clean and W0.5 yes", which is MET. The relevant test still SKIPS locally (marker present), so the real SUR path is not yet proven end-to-end; the 27.29 work should remove the skip and verify.
- No reason to hold 27.27/27.29 based on W0; the CTO's "held for 27.27/27.29" condition (W0.4 on a 403) does not apply.
