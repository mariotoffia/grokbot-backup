# Lead Architect review: ADR draft PR #1260 @ 71ee7f5b (docs/adr/0001-go-arch-lint-map-per-service.md)
By: lead-architect minion, 2026-10-23 12:58 CEST. Against packet P-W-2026-0001-la-adr-01. Gates: CONVENTIONS §1 and §3 (cross-service ADR at the root).

== Verdict ==
CHANGES_REQUESTED (two text edits; otherwise approved)

== Findings ==
- [Medium] [non-testable] Decision — add: "A baseline map may allow an existing violation, such as depOnAnyVendor: true while the core imports a vendor SDK, only if it links a tracking issue to remove it." In Context, cite the #1250 buildingsvc tracking issue once dev-lead files it.
- [Low] [non-testable] Context, #1257 bullet — say that the map now limits go-core/cberror to the core (the core-errors group). The hexagonal reviewer accepted this as stricter. That makes it an "only adds rules" change under the Decision.
- Map count wording ("rises by one per map") — accepted as written.
- Toolchain pin — keep "The machine-setup owner tracks this." until platform-lead files the issue, then cite it.

== Rationale ==
Structure, alternatives and placement match the packet. The two edits keep the ADR from approving vendor imports in a core without a tracked exit, and they record #1257's tighter scope. Approve after the push.

== Re-verdict @ 4899ec6b (2026-10-23 13:00 CEST) ==
APPROVED. Both edits are in, and I checked the text. One open follow-up: cite the #1250 vendor-exception tracking issue in Context once dev-lead files it. That is a one-line edit and needs no new review from me.

== Delta re-verdict 4899ec6b..105a4eff (2026-10-23 13:05 CEST) ==
APPROVED. Neither Low below blocks the merge.
- #1261 cite, Status/Date table, README index, LINT.md link, the single-map rationale (needs a go.mod) and the backing for "stricter": all accepted.
- [Low] [non-testable] Consequences: the interim gate for unmapped services (standard linter plus hexagonal and clean-arch sign-off, PR body notes that lint-arch is unavailable) is a rule, not a consequence. Move it to Decision. Agreed as written.
- [Low] [non-testable] Consequences: the list of unmapped services, pinned at 89f62e5f, will go stale. Prefer to point to LINT.md as the living list and drop the inline list, or say it is a snapshot.

== Delta re-verdict 105a4eff..3d8f6dea (2026-10-23 13:10 CEST) ==
CHANGES_REQUESTED (one wording fix; everything else approved)
- Both Lows resolved: the interim gate is in Decision, and the list is labelled a snapshot pointing to LINT.md.
- Toolchain line: accepted. I checked that tools/go.mod at 3d8f6dea pins github.com/fe3dback/go-arch-lint v1.17.0. It is a better fix than the text I asked to keep.
- Map-count rewording (counts lint-arch targets, eventsvc checks two maps): accepted.
- [Medium] [non-testable] Consequences, shared packages: "this ADR does not require a map for them" reads as an exemption. Mario's conventions say shared libraries have their own arch-lint. Fix: "These are shared packages, not services. This ADR covers services only and does not decide whether they need maps."
