# Test review — PR #1263 (Closes #1262), draft, head 72f404c6

Rule applied as stated by the Dev Lead (Mario, 15:24; I could not verify it): no real-AWS coverage may be lost, and there may be no Floci-only assertions.

== Verdict == CHANGES_REQUESTED

== Findings ==
[Major] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:307-311 — The target gate drops real-AWS assertions that don't need trace. All of assertLogsOutput is now local-only, including the error-group checks at sinks_helpers_test.go:~128-140:
  - FilterLogEvents must succeed, which proves the Firehose delivery-error group/stream and the IoT rule error group exist.
  - Both groups must be empty for the run.
  These ran on every target at main 9f33caca/merged #1255, and they read error logs, not trace lines. This breaks the "no coverage lost on real AWS" rule.
  Fix: split assertLogsOutput into assertTransformLogged (trace-dependent) and assertNoErrorLogs, and call assertNoErrorLogs unconditionally.
[Major] [hard-to-test] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:307-308, sinks_helpers_test.go:~98-125 — The per-record transform count is now a Floci-only assertion with no real-AWS equivalent. That breaks the second half of the rule.
  Fix: give AWS a target-neutral check that the transform ran for this run without trace. Examples:
  - The Lambda's REPORT/START lines since runStart (count >= 1) on the transform log group.
  - Or the transform's per-record output already in S3: ingestion_test.go:265 checks only len > 0; tighten it to exactly the items for thingName.
  Otherwise get a written exception from Mario that the trace count may be Floci-only, and record it in the PR body and evidence.
[Minor] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:310 — On AWS the gate is a t.Logf, not a t.Skip or subtest, so a green AWS run gives no visible sign that the check was skipped. If any part stays target-gated, wrap it in t.Run("cloudwatch logs", …) and use t.Skipf there, so the skip shows in -v output and test reports.
[Minor] [testable] go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go:~112-120 — "Per item" is per thing, not per item. The filter is strings.Contains(message, "$aws/things/<thing>/") on the raw "About to transform" record, and recordsSent is still the hard-coded const 1 next to the single UpdateThingShadow call. Results are deterministic, because thingName = svctest-<TestSuffix> is unique per run (run: svctest-zkcp610c) and the substring ends in "/" so it can't prefix-match another thing. But the expected count is still derived by hand, not from the items sent. Fix (optional): derive recordsSent from the update calls made, for example a counter incremented at each UpdateThingShadow, and match the topic as a JSON field rather than any substring of the message.
[Info] [testable] There is no dead code: the strings import is used, all assertLogsOutput callers were updated, and golangci reports 0 issues. The naming is fine. Determinism of the logs path is unchanged: Eventually 90s/3s, then an exact Equal.
[Info] [non-testable] PR body — The reasoning (AWS may reuse an existing info-level deployment, and trace would log raw payloads on AWS) is a valid argument against requiring trace on AWS. It is not an argument for dropping the error-group checks.

== Rationale ==
The per-thing filter is a correct hardening against cross-device counts on a shared rule. But the target gate is too coarse: it removes the error-log assertions from real AWS, and it leaves the only proof that the transform ran per record with no AWS counterpart. Both break the stated rule.
Note that on AWS with a reused info-level stack, the trace count at #1255 could never have passed. So gating that one assertion fixes a real AWS false failure, but it needs an AWS replacement or an explicit exception.

Evidence (impl/ingestion-log-review-followup/gates/):
- test-service-race-72f404c6.log:
  - HEAD 72f404c67d01. Image mariotoffia/floci@sha256:07ced9c6…2ba1, the resolved digest, recorded.
  - dir and cmd headers present; cmd is go test -tags=e2e,floci -count=1 -v -race.
  - target=local. TestIngestionServiceFlow PASS (80.12s), with "per-record log events for svctest-zkcp610c since run start: 1 (records sent: 1)". The 5 paging unit tests PASS.
  - ok 143.513s, rc=0, 15:42:21–15:44:52 CEST. No DATA RACE / FAIL lines.
- gofmt, vet, golangci, lint-arch, tidy and unit at 72f404c6 are all rc=0, each with a sha header.
- There is no real-AWS run, which is expected: Floci only, so the AWS branch is unexercised.

CI at 72f404c6:
- Analyze (actions): SUCCESS.
- Analyze (javascript-typescript): pending.
- CodeQL: NEUTRAL.
- Build, Unit Tests, Static Analysis, Architecture: SKIPPED.
- No CI job runs the service test.

---
# Re-review at d1ec3658 (2026-10-23), delta 72f404c6..d1ec3658

== Verdict == APPROVED_DEGRADED (both Majors closed; degraded because CI doesn't run the service test or the unit tests, and because of the Minors below)

== Findings ==
[Minor] [non-testable] impl/ingestion-log-review-followup/gates/tdd-red-itemsForThing.log — The red run was a build failure ("undefined: itemsForThing"), not a failing assertion. That shows the test was written first, but not that it rejects a wrong filter, for example HasPrefix, which TestItemsForThingKeepsOnlyThatThing's "svctest-ab" case would catch. Acceptable, but weak as a red. Fix (optional): stub itemsForThing to return items unfiltered and record that failing run.
[Minor] [hard-to-test] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:~140-200,276-279 — The S3 object is the first ObjectCreated under ingestion/ from SQS, and it isn't scoped to this thing. On a shared real-AWS stack, another device's object can arrive first, and then require.Len(thingItems, recordsSent) fails with 0. Exact counting from a single object also assumes Firehose puts all of this run's records into one object, which holds for recordsSent=1. This was already there at main (the old found==true assert had the same object pick), so it isn't a regression. The wait is bounded at 180s, with the old time.Sleep(15s) polling. Fix (optional): keep polling until an object contains thingName items, or list ingestion/ objects after runStart and sum itemsForThing across them.
[Minor] [testable] go-services/ingestionsvc/deployment/service-test/logpages_test.go:22, sinks_helpers_test.go:99 — The only non-test caller now passes stopAtFirst=false, so the stopAtFirst=true branch and TestFilterLogEventsStopAtFirstAfterEmptyPages cover code nothing in the suite uses. Fix: drop the parameter, along with that unit case and the true iteration in the duplicate-token test, or keep it with a stated reason.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:276-292 — The S3 check is exact and scoped. itemsForThing keeps LocationID == thingName exactly; unit tests cover two matches out of four, the "svctest-ab" prefix decoy, and no match. require.Len equals recordsSent, and every matching item is validated: sensor, provider, value and non-zero timestamp. The old code validated only the first item and then broke out. The thing name is svctest-<suffix>, unique per run (run: bn=svctest-c6y5ysm4).
[Info] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:127-132 — recordsSent is a var incremented right after the only UpdateThingShadow passes require.NoError. It's derived from accepted sends, and a future second update will update it automatically if the same pattern is followed.
[Info] [testable] There are no Target(), DeploymentTargetLocal, IsLocal or t.Skip gates in the service-test package (git grep at d1ec3658). The only hit is an option name in _design/overview.adoc. assertNoPipelineErrors runs unconditionally on every target.
[Info] [testable] Nothing that ran on real AWS at main (9f33caca) is lost:
  - assertFirehoseDeliveryStream: unchanged.
  - Error-group existence and emptiness: now run on every target, via assertNoPipelineErrors.
  - S3 item checks: stricter.
  - The trace-based transform log count is removed for every target. It couldn't pass on an info-level AWS stack, and the exact S3 item count proves the per-record transform more strongly. "The transform Lambda wrote logs" isn't asserted anywhere now, which is acceptable because the S3 output implies the transform ran.
  - logLevel: trace was removed from provision-config.yaml, which also eliminates the raw-payload concern.
  - Dead constants and the strings usage went with it, and golangci reports 0 issues.

== Rationale ==
The Dev Lead's four claims hold: error logs run unconditionally, the S3 count is exact per thing, recordsSent is derived from accepted updates, and no gates or skips remain. Under the stated rule there is no real-AWS coverage loss and no Floci-only assertion. What's left is a weak red (a compile failure) and a pre-existing object-selection flake risk on shared AWS.

Evidence (impl/ingestion-log-review-followup/gates/):
- test-service-race-d1ec3658.log:
  - HEAD d1ec3658b4fb. Image mariotoffia/floci@sha256:07ced9c6…, the resolved digest, recorded.
  - dir and cmd headers; cmd is go test -tags=e2e,floci -count=1 -v -race -timeout 60m.
  - TestIngestionServiceFlow PASS (80.11s), plus the 5 paging and 2 itemsForThing unit tests PASS.
  - ok 177.665s, rc=0, 15:59:21–16:02:24 CEST. No DATA RACE / FAIL lines.
- gofmt, vet, golangci, lint-arch, tidy, unit and the svcroot wrapper at d1ec3658 are all rc=0 with sha headers.
- tdd-red-itemsForThing.log shows the build-failure red.

CI at d1ec3658:
- Analyze (actions): SUCCESS.
- Analyze (javascript-typescript): pending.
- CodeQL: NEUTRAL.
- Build, Unit Tests, Static Analysis, Architecture: SKIPPED.
- No CI job runs the service test or these unit tests.

---
# Delta review d1ec3658..0cc8726b (2026-10-23)

== Verdict == APPROVED_DEGRADED (Minors 2 and 3 from d1ec3658 closed; degraded only because CI doesn't run the service test or unit tests)

== Findings ==
[Minor] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:133,~283 — expectedItems = recordsSent × len(Sensors). If the fixture ever had 0 sensors, expectedItems would be 0, the wait would exit on its first pass and require.Len(thingItems, 0) would pass trivially. The removed require.Greater(len(loadedItems), 0) was the guard against that. The fixture has 1 sensor today, so it isn't live. Fix: add require.Positive(t, expectedItems) right after computing it.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:~140-250 — There is no explicit runStart or LastModified filter on objects. The objects come from notifications on a per-run SQS queue subscribed at :74 before the update. Only items with LocationID == thingName are counted, and thingName is unique per run, so items from older objects or other things can't be counted. That makes "newer than run start" effectively guaranteed. Fix (optional): skip records whose eventTime is before runStart to save loads on a busy shared stack.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:~160-250 — The loop is bounded and deterministic.
  - It has a 180s deadline, with 15s polls carried over from the old code.
  - seenKeys de-duplicates SQS redeliveries of the same object key, so one object is never counted twice.
  - Each object load requires storeloader to succeed.
  - The loop exits once len(thingItems) >= expectedItems, then require.Len checks the exact count. A duplicate that arrives in the same or an earlier poll fails; one that arrives after the exit isn't seen, the same lenient direction as before.
  - On timeout, the partial count fails require.Len with a clear "N of M" message.
  - Item checks (sensor, provider, value, timestamp) run on every item.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/logpages_test.go, logpages_unit_test.go — Removing stopAtFirst loses no live coverage. The branch had no non-test caller. The remaining tests still cover duplicate-token (2 calls), page cap (100), error after partial events, and accumulation across pages including an empty middle page.
[Info] [testable] No dead code is left: there are no stopAtFirst references, s3ObjectKey and loadedItems were removed, and the loader logic moved into loadThingItems. golangci reports 0 issues.

== Rationale ==
Summing across new objects closes the shared-stack object-pick flake. Counting per sensor is derived from the payload actually sent. The exact assertion is kept. The only gap is a missing positive-count guard, and it can't trigger with today's fixture.

Evidence (gates/*-0cc8726b.log):
- test-service-race-0cc8726b.log:
  - HEAD 0cc8726bcbac. Image mariotoffia/floci@sha256:07ced9c6…, recorded.
  - dir and cmd headers; cmd is go test -tags=e2e,floci -count=1 -v -race -timeout 60m.
  - The log shows "0 of 1 items … retrying" three times, then 1 item loaded from one object.
  - TestIngestionServiceFlow PASS (80.23s), plus 4 paging and 2 itemsForThing unit tests PASS.
  - ok 227.786s, rc=0, 16:15:13–16:19:50 CEST. No DATA RACE / FAIL lines.
- gofmt, vet, golangci, lint-arch, tidy, unit and the wrapper are all rc=0 with sha headers.

CI at 0cc8726b:
- CodeQL and Analyze (actions, javascript-typescript): SUCCESS.
- Bugbot: NEUTRAL.
- Build, Unit Tests, Static Analysis, Architecture: SKIPPED.
