# Security delta check: PR #1248, dcd0282f → c3c4a816 (8 commits)
Reviewer: security-auditor · 2026-10-23 (Europe/Stockholm) · git diff only. I ran no sudo, executed nothing and read no .env.

## Verdict: **approve**. D-1 is resolved; 1 Info item.

- **D-1 resolved** (75c20e32, 94f3716d). GROKBOT.md now gives the recipe `sudo env -i HOME=/root PATH=… GOCACHE=/root/… GOMODCACHE=/root/…` and says to run only the Docker-dependent packages that way. It notes the CI drift from `env -i` and gives the `find . -user root` / `chown -R` cleanup.
- **iptables-legacy** is tighter than before:
  - a FORWARD DROP policy is only treated as docker's when DOCKER chains exist; otherwise it's an admin policy and is left alone;
  - live rules are left alone while containers are running;
  - dockerd is stopped and restarted around the cleanup;
  - the cleanup runs in `set +e; ( set -e; … ); rc=$?; set -e`, which avoids the set-e-in-if pitfall correctly;
  - on failure it restores from the 600-mode backup.
  Nothing is loosened.
- **dnsmasq:** the config, restart and health check are now one step. On failure it restores the backup and restarts the previous config. The bind addresses are unchanged (127.0.0.1 and docker0).
- **daemon.json** rollback now stops the unhealthy daemon before restoring.
- **Other changes:**
  - `GOTOOLCHAIN=local`: no implicit toolchain download, so `--check` stays read-only.
  - `GO_REQUIRED` now uses `find` with prunes. It only reads `go`/`toolchain` lines.
  - The go tool checks compare `go version -m` against the version in go.mod.
  - `/var/run` is now fixed through `readlink -f`.
  - `.bashrc` and `.profile` now go through `backup()`.
  - `--check` now reports a missing Floci image as pending. Floci stays `:latest`, per Mario's rule.
  - The env snippet puts `~/.local/bin` first in PATH. Same user, so no privilege change.
- **I-1 Info:** `apt-get install --allow-downgrades` for the pinned Docker packages. It's acceptable, because the versions are pinned in the script and come from a signed repo with a fingerprint-set check. It could still downgrade a box that was patched later. A comment about why would help.
- No regressions in SEC-1248-1..13 or N-1..N-7. No escalation flags.
