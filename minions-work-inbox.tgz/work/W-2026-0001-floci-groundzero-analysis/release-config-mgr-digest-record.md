# Release digest record: W0.2 (P-2026-0001-02)
Recorded 2026-10-21 14:46 CEST (UTC+2), release-config-mgr.

- Image: `mariotoffia/floci:latest`, OCI index `sha256:6e4341f39a803fda90fe2b25f075565ad317c997da5d3a0f319e8ab36b6e6ea7`
  - amd64 `sha256:49c010697bb01bde57cfad89defa3b9cb751e252555997eb28355c7b34294d90`
  - arm64 `sha256:f3ca0213acb64af767f4329405ebbca05b2e476d8acf63379ef9a36b1969acab`
- Pushed 2026-10-21 09:36:44 CEST. Required floci main `7c0d592b8` committed 14:23:14 CEST, so **this image predates it (A1 FAIL / blocked: dependency)**.
- Revision label `f9d3e906…` is inherited from the UBI9-micro base image (same as `vcs-ref`), so it is not a floci commit. The build does not stamp the floci revision.

## Pins (/workspace/thiink/teos, read-only)
| File | Line 34 | Match |
|---|---|---|
| go-core/utils/testutils/flocilocal/consts.go | `DefaultImage = "mariotoffia/floci:latest"` | yes |
| deployment/provision-config.yaml | `emulator: mariotoffia/floci:latest` | yes |
| customers/umea-energi/provision-config.yaml | line 34 is a device description; no floci pin in file | n/a |

Both pins use a mutable tag, not a digest. The digest above will change on rebuild.

## Update 2026-10-21 14:45 (UTC+2)
Rebuilt image recorded: index sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (pushed 14:43 UTC+2). Pins unchanged (tag latest).
