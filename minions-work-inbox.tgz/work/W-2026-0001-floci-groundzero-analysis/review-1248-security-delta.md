# Security delta review: PR #1248, 3541fb31 → da3c2fb2
Reviewer: security-auditor · 2026-10-23 (Europe/Stockholm) · git diff only. I ran no sudo, executed nothing and read no .env.
Commits: ae0d86f8 (daemon.json mode, DNS probe, firewall recovery), 9a152afc (.bashrc mode), da3c2fb2 (docs: root go test PATH).

## Verdict: **approve-with-changes**. One Medium (S-1), two Low, one Info. No escalation flags.

## Findings
| id | sev | where | issue | recommendation |
|---|---|---|---|---|
| S-1 | Medium | apply_rc (9a152afc) | `stat -c %a "$HOME/.bashrc"` does **not** follow symlinks. If ~/.bashrc is a symlink (as dotfile managers like stow or chezmoi create), it returns `777`. The temp file is then chmod'ed 777 and `mv`'d over the link, which leaves a **world-writable ~/.bashrc**: any local uid can inject code that runs in every interactive shell. It also silently replaces the symlink with a regular file. The comment's intent ("never readable by others") is defeated in this case. | Use `stat -Lc %a`. Either refuse symlinked rc files with a log line, or write through to the target. Also mask the result, e.g. `chmod "$(printf '%o' $((8#$mode & 8#755)))"` or `chmod go-w`, so a group- or world-writable result is never produced. |
| S-2 | Low | GROKBOT.md root test recipe (da3c2fb2) | `sudo env -i … PATH="$HOME/.local/bin:/usr/local/go/bin:/usr/bin:/bin"` puts a **user-writable directory first in a root PATH**. `env` resolves `go` (and the test then resolves `docker`, `git` and so on) through this PATH, so sudo's `secure_path` does not protect it. Anything able to write to ~/.local/bin (any agent or process running as the shared `box` user, an npm/pnpm global install, a stray link) can shadow `go`, `docker` or `git` and get code run as root. On this box that is no *new* privilege, because the same user already has passwordless sudo. It does turn accidental shadowing (wrong Node, a stale tool) into root execution, and the recipe would become a real privilege-escalation path on any host without passwordless sudo. | Append instead: `PATH="/usr/local/go/bin:/usr/bin:/bin:$HOME/.local/bin"`, so system binaries win and user tools are only a fallback. Better still, list only the specific tools the tests need, with absolute paths. Add one sentence saying that ~/.local/bin is user-writable. |
| S-3 | Low | apply_rc / apply_daemon_dns (ae0d86f8) | Preserving the existing mode also preserves an insecure one: a group- or world-writable .bashrc, or a world-writable daemon.json, stays that way. Keeping daemon.json's mode and owner is otherwise good, since a 600 file holding proxy credentials is no longer widened to 644. | Clear the group and other write bits (`& 755`, or `0600`/`0644` maximum) when copying the mode. |
| S-4 | Info | apply_rc | If the step fails between mktemp and mv, `~/.bashrc.XXXXXX` is left behind. It's 0600, so it doesn't leak. | Remove the temp file on failure, or clean it up in the WORK trap. |

## What I checked and found OK
- **.bashrc temp handling:** mktemp is created under `umask 077` in the same directory as .bashrc, so the rename is atomic on the same filesystem. Ownership is the running user, as before. The backup is taken first. mktemp's random name rules out a pre-created-file race.
- **PATH in the user's env snippet:** the snippet prepends `~/.local/bin` for the user only (unchanged since c3c4a816, accepted). Its `case` guard makes it idempotent. It doesn't reach root: sudo `secure_path` applies, and root has no snippet. The only root exposure is the documented recipe in S-2.
- **DNS probe:** now requires dig exit 0 and a real IPv4 A record, which rules out false positives from timeout text.
- **iptables-legacy:** a failed dockerd restart after cleanup now counts as a failure and restores the legacy backup. Nothing is loosened.
- **daemon.json:** `sudo install -m <mode> -o -g` with values read through `sudo stat`. Validation (jq, `dockerd --validate`) is unchanged.

## Escalation flags
None. S-2 touches root execution, but on this box the same user already has passwordless sudo, so it is not iam-loosening. If the recipe is ever used on a host without passwordless sudo, treat it as iam-loosening.

---
## Re-check @5638f465 (2026-10-23, Europe/Stockholm): head SHA reviewed **5638f465**
5638f465 is the current PR head. **No SC2024 commit has landed**, so there was nothing to review there. Commits: cb8ad2ea, 5638f465. Static review only: git diff plus one bash semantics test in a scratch shell, unrelated to the script.

### Verdict: **approve**. S-1, S-2 and S-3 are resolved. S-4 is still not effective, but it's only Info and doesn't block merge.

| id | status | evidence |
|---|---|---|
| S-1 | **Resolved** | `readlink -f` gives the target, and `stat -Lc %a` reads the target's mode. The temp file is created as `mktemp "$target.XXXXXX"` under umask 077, in the same directory as the target, so the rename is atomic and the symlink is kept (written through). The mode goes through `mask_go_w` (`& ~022`) and then `chmod go-w`, so the result can never be group- or world-writable. mask-test.log: 777→755, 666→644, 600→600, 644→644. |
| S-3 | **Resolved** | daemon.json uses `mask_go_w "$(sudo stat -Lc %a …)"`; the owner is still kept. Info: if /etc/docker/daemon.json were a symlink, `install` would replace the link with a regular file. That file is root-owned and not group- or world-writable, so it is safe. |
| S-2 | **Resolved** | Root PATH is now `/usr/local/go/bin:/usr/bin:/bin:$HOME/.local/bin`, so system binaries win. The doc note says ~/.local/bin is user-writable (including npm/pnpm globals), must stay last and must never shadow go, docker or git. The one remaining exposure is that tools found only in ~/.local/bin still run as root. That's acceptable on this passwordless-sudo box and is documented. |
| S-4 | **Not effective (Info)** | `step()` runs apply as `( set -e; "$apply" )`, a **subshell**. `RC_TMP` is assigned inside that subshell, so the parent's EXIT trap sees an empty `RC_TMP`, and bash doesn't run the parent's EXIT trap in a `( )` subshell either. I confirmed this with a scratch test: `X=; trap 'echo X=$X' EXIT; ( set -e; X=/tmp/f; false )` prints `X=`. On failure, the 0600 `<target>.XXXXXX` file is still left behind. It doesn't leak anything. Fix: set a trap inside apply_rc (`trap 'rm -f "$RC_TMP"' EXIT` in the subshell), or do the cleanup with `|| { rm -f "$RC_TMP"; return 1; }`. |

### SC2024
No commit yet. When one lands, check that any `sudo cmd > file` replacement (for example `| sudo tee`) does not create root-owned files under $HOME or BACKUP_DIR. The iptables backup is meant to stay user-owned, mode 600. Also check that the replacement doesn't widen a file's mode.

### Escalation flags
None.

---
## Delta @4c447ac7 (SC2024), 2026-10-23 (Europe/Stockholm): head SHA reviewed **4c447ac7**
4c447ac7 is the current PR head. Static review (git diff only).

### Verdict: **approve**. No new issues; 1 Info. S-4 from the previous section is still open (Info).

- **Change:** only the rollback line changed: `sudo "$IPTL-restore" <"$f"` became `sudo "$IPTL-restore" "$f"`, and a doc paragraph was re-wrapped.
- **No root-owned files:** passing the file as an argument means root *reads* `$f`; nothing is written. The backup is still created as before by the user: `( umask 077; sudo "$IPTL-save" >"$f" )` runs the redirect in the user's shell, so the file is user-owned, mode 0600, and the check that it isn't empty is still there. Nothing new is created under $HOME or BACKUP_DIR.
- **Right file:** `$f` is the same local variable as the save path (`$BACKUP_DIR/iptables-legacy.$STAMP.rules`) and is double-quoted, so there's no word splitting or globbing. `iptables-restore` accepts a file operand.
- **Fails safely:** if the restore fails, it still logs FAIL, tries to restart dockerd and returns 1, so the step fails and the run stops. The UNDO log line still shows the equivalent `< $f` form, which is fine for a manual undo.
- **Trust:** the file is user-writable, and root now opens it directly instead of the user's shell feeding it through stdin. The trust is the same as before: in both cases the content comes from the user-owned file, and the path is a fixed pattern in a 0700/0600 user area, not a predictable path in /tmp.
- **I-2 Info:** `MACHINE_SETUP_BACKUP_DIR` comes from the environment. A relative value starting with `-` would turn `$f` into an option for iptables-restore. Optional fix: `sudo "$IPTL-restore" -- "$f"`, or require an absolute BACKUP_DIR.

### Escalation flags
None.

---
## Delta @f23dd485 (S-4 fix), 2026-10-23 (Europe/Stockholm): head SHA reviewed **f23dd485**
f23dd485 is the current PR head. Static review (git diff) plus the evidence logs.

### Verdict: **approve**. S-4 is resolved. All S-1..S-4 findings are now closed; I-2 (Info, optional `--`) is still open.

- **The trap fires:** `trap "rm -f -- '$tmp'" EXIT` is set inside apply_rc, which runs in step()'s `( set -e; … )` subshell. A set -e exit in that subshell runs the subshell's own EXIT trap. Evidence: in l1-before.log (old code), a forced `mv` failure leaves `.bashrc.nQnXBI`, count=1. In l1-after.log (new code), count=0 and .bashrc is unchanged.
- **Only the temp file is removed:** `$tmp` is expanded when the trap is set (SC2064 suppressed on purpose), with `--` and quotes. If mktemp failed, set -e exits before the trap exists, so there's never an `rm` with an empty variable. Info: a single quote in the resolved .bashrc path would break the trap string. That's not realistic for $HOME, so no action is needed.
- **No other trap is clobbered:** subshells don't inherit the parent's EXIT trap, so the top-level `cleanup` (rm WORK) is untouched and runs at the script's exit as before. The global RC_TMP was removed.
- **Success path:** `mv "$tmp" "$target"; trap - EXIT`. The trap is cleared after the rename. Even if it fired, it would remove the temp path, which no longer exists, never the real .bashrc or its target.
- l1-verify.log: shellcheck and `bash -n` exit 0, `--check` exit 0.

### Escalation flags
None.

---
## Delta @36292726, 2026-10-23 (Europe/Stockholm): head SHA reviewed **36292726**
36292726 is the current PR head. Commits: 976af623, 6cc60c09, 078c5fe0, 4072ea39, 768f782d, 36292726. Static review (git diff only). I ran no sudo, made no binfmt writes and executed nothing.

### Verdict: **approve**. No blockers; 2 Low, 3 Info. No escalation flags.

| id | sev | where | issue | recommendation |
|---|---|---|---|---|
| T-1 | Low | restart_pkg_dnsmasq / is_dnsmasq_pid | After a failed replacement, the package dnsmasq is restarted by replaying `/proc/<pid>/cmdline` **as root** (`sudo "$@"`). The only identity check is `/proc/<pid>/comm == dnsmasq`, but any process can set its own comm (prctl PR_SET_NAME) and argv. If the root-owned pid file is stale and the pid was reused by a non-root process calling itself "dnsmasq", the script kills that process (harmless) and, on rollback, runs its argv as root. This needs pid reuse plus a hostile process, and on this box the user already has passwordless sudo, so it's defence in depth only. | Identify the process by `readlink /proc/$p/exe` = `/usr/sbin/dnsmasq` and owner uid 0 (`stat -c %u /proc/$p`). Better still, don't replay argv: restart with a fixed command (`sudo /usr/sbin/dnsmasq` with the package defaults, or `service dnsmasq start`). |
| T-2 | Low | docker_user_custom / apply_ipt_alt | The DOCKER-USER guard checks IPv4 `iptables-legacy` only, but apply_ipt_alt also switches **ip6tables** to nft. Custom IPv6 DOCKER-USER rules in ip6tables-legacy would silently stop applying, which loosens the IPv6 firewall. Affected boxes only: IPv6 is not used here today. | Run the same check with `/usr/sbin/ip6tables-legacy` before switching ip6tables. |
| T-3 | Info | docker_user_custom | Any listing failure (`|| true`) reads as "no custom rules". For a missing chain that's correct. If iptables-legacy itself errors, the guard fails open, although the later steps would probably fail as well. | Treat a non-zero exit as "custom" (fail closed), except when the chain doesn't exist. |
| T-4 | Info | dnsmasq stop paths | There's a small TOCTOU between the comm check and `sudo kill` (pid reuse within milliseconds). Acceptable. pgrep -f is limited to the exact `dnsmasq -C <our conf>` command line and is now also comm-checked. | None needed (the exe check from T-1 would cover it). |
| T-5 | Info | check_nvm | The check sources the user-writable `nvm.sh` in a child bash, so it does run code during `--check`. It runs as the user, not root. The "side-effect-free" claim holds only in the sense that nvm with `--no-use` changes nothing. | None needed. |

### What I checked and found OK
- **Go toolchain:** the download is still sha256-verified by `fetch` (pinned GO_SHA256 per arch). It's extracted into the private 0700 WORK directory, sanity-run, then `sudo chown -R root:root` before moving it into /usr/local. A root `go` can no longer be rewritten by the user. The extraction runs as the same user before the chown, so there's no new window. The /usr/local/bin/go symlinks and the GODIR rollback are unchanged. Old `/usr/local/go.bak.*` trees may still be user-owned, but they aren't on PATH.
- **DOCKER-USER guard:** this only adds refusals. A custom chain stops both the nft switch and the legacy cleanup. FORWARD and DOCKER-USER are never loosened. The chain is captured into a variable before grep, which fixes the SIGPIPE false negative, and grep uses `--` and an exact-line regex. The backup is taken before the guard, so an early return leaves an extra backup file and nothing else.
- **cbdeploy as a soft step:** it builds an internal repo tool with `make install` and skips no integrity or security check. A failure is logged as WARN, its backups are restored, and `--check` warns. Nothing security-relevant is hidden.
- **Pins:**
  - act: exact `act version X` match, and fetch with pinned sha256 is unchanged.
  - oapi-codegen: exact module version (`modver`); installed with `go install` through the Go checksum database.
  - nvm: exact version; the installer is fetched with a pinned sha256, not piped from curl into sh.
  - pnpm: through corepack, with the active version checked via `lastKnownGood.json`. Corepack verifies the npm registry's integrity.
  - Floci stays `mariotoffia/floci:latest`, per Mario's rule.
- **Package dnsmasq pid:** now read through `pidfile_dnsmasq` (numeric and comm check) instead of a bare `kill -0`, and the stop paths no longer signal unrelated pids.
- **APT:** iproute2 and procps added, from the distro's signed repos.
- **Docs:** they explain why `~/.local/bin` must be in root's PATH (cdk, cbdeploy), keep it last, and honestly note that the verified root run used an earlier form of the command.

### Escalation flags
None. T-2 would count as iam-loosening only on a box that has custom IPv6 DOCKER-USER rules.
