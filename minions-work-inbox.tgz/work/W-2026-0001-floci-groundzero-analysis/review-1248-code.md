# Code review — PR #1248 (issue #1247), draft, machine setup script
Reviewer: the Code Reviewer minion (code-reviewer). READ-ONLY, static analysis only. machine-setup.sh was NOT executed, including --check (see L3).
Reviewed HEAD: 13298dd2 (13298dd2…; head at review end: 13298dd2). Brief time: 22:08 Europe/Stockholm.
The head moved during review: 6de2b604 (first seen) → 13298dd2 (9 more commits, 22:07–22:09 Europe/Stockholm). It is a draft and still receiving pushes; re-check the sha before acting on this review.
df -h /: 24% used. Fresh merge-base with origin/main: 45ba749f. Files: GROKBOT.md (+155), scripts/grokbot/README.md (+11), scripts/grokbot/machine-setup.sh (+341). Nothing outside scope.
bash -n: OK. shellcheck: not installed on the box, so not run.

== Verdict ==
CHANGES_REQUESTED.

== High ==
- H1 [testable] scripts/grokbot/machine-setup.sh:58 + 88-93. Apply functions run inside `if "$apply" && …`, so set -e is DISABLED inside every apply_*. A failing command does not stop the function. In apply_go, if the go.dev VERSION fetch or the download fails, :90 still runs `sudo rm -rf /usr/local/go` and the box is left without Go. In apply_resolv (:314-317), resolv.conf is overwritten even if the backup cp failed. Fix: chain each apply with && (or `set -e` in a subshell: apply() ( set -e; … )), download into a temp dir and verify before `rm -rf`, and abort apply_resolv if the backup fails.
- H2 [testable] scripts/grokbot/machine-setup.sh:332. `jq … <<<"$cur" | sudo tee "$DAEMON_JSON"`: if the existing daemon.json is invalid JSON, jq fails, but tee has already truncated the file. daemon.json is left empty, set -e is off (H1), and dockerd is then killed (:333) and fails to restart, so Docker is down. Fix: write jq output to a temp file, validate it with `jq -e .`, then `sudo install`/mv. Skip the dockerd restart if that fails.

== Medium ==
- M1 [testable] scripts/grokbot/machine-setup.sh:341 and GROKBOT.md:42. --check always exits 0 when nothing FAILs, even with WOULD-CHANGE>0, so callers cannot detect a dirty box. Fix: in check mode, exit with a distinct non-zero code (e.g. 3) when PENDING>0, and document the exit codes (0/2/3/1).
- M2 [testable] scripts/grokbot/machine-setup.sh:311-319. Ordering and guard. If the dnsmasq run step FAILs, the script carries on and still points /etc/resolv.conf at 127.0.0.1, which kills all DNS on the shared box. Fix: make apply_resolv (and apply_daemon_dns) require check_dnsmasq_run, plus a test query (getent hosts api.devlocal02.localhost.floci.io → 127.0.0.1).
- M3 [non-testable] GROKBOT.md (the "dockerd and dnsmasq run without systemd" section). After a box restart, resolv.conf still says 127.0.0.1 but nothing starts dnsmasq, so DNS is dead until the script is rerun. That rerun needs network (apt, Go, Floci pull) before the dnsmasq step. Fix: document a restore command (`sudo cp /etc/resolv.conf.bak.<stamp> /etc/resolv.conf`, which the iptables step already logs for its own case). Log the resolv and daemon.json backup paths and undo lines like the iptables step, or move the dnsmasq step earlier.
- M4 [non-testable] GROKBOT.md:47-48 is stale. It documents MACHINE_SETUP_UPSTREAM_DNS (default 10.0.0.2), but 13298dd2 removed that variable. Upstream now comes from resolv.conf or the newest .bak, with 10.0.0.2 as a fallback. Fix: update the doc.
- M5 [non-testable] scripts/grokbot/machine-setup.sh:205, 143. `curl https://get.docker.com | sudo sh` and `curl nvm install.sh | bash` run unverified remote scripts (get.docker.com unpinned, as root). Fix: use the Docker apt repo with its signed key (or pin and checksum), and pin and checksum the nvm installer. This is a supply-chain concern; specialist: security-auditor.
- M6 [non-testable] GROKBOT.md:10-14 says box workarounds "never go into teos source code, tests". That contradicts open PR #1244, which adds a fake-IP skip to public_names_test.go. Fix: dev-lead to decide which one stands, then align (drop #1244 or soften the rule).

== Low ==
- L1 [testable] scripts/grokbot/machine-setup.sh:232. The iptables-legacy step flushes and deletes every chain in all 4 legacy tables rather than removing only the stale DROP or docker rules. It is documented (GROKBOT.md) and backed up with an undo line, and it is idempotent (the check at :227 counts -A rules). There are no -A appends, so -C/-A does not apply. Not minimal; acceptable for the box, but note it in the PR.
- L2 [testable] scripts/grokbot/machine-setup.sh:227, 97, 116-117, 129, 196, 244. `producer | grep -q` under pipefail: grep -q exits early, the producer can get SIGPIPE, and pipefail reports failure. That is a false "not OK", which triggers a needless apply. Fix: `grep -c … >/dev/null` or capture output first.
- L3 [testable] scripts/grokbot/machine-setup.sh:152. In --check, check_pnpm runs `pnpm -v` through the corepack shim, which can download pnpm into COREPACK_HOME. That is a write plus network access in dry-run mode. Every other check is read-only (sudo docker inspect, dpkg --audit, ss, jq -e, iptables -S/-save, the Floci path at :251-252). For that reason I did not run --check. Fix: check `$COREPACK_HOME` contents, or set COREPACK_ENABLE_DOWNLOAD_PROMPT=0 and COREPACK_ENABLE_NETWORK=0 in check mode.
- L4 [testable] scripts/grokbot/machine-setup.sh:244-246. $USER is unset in some non-login contexts; under set -u the script aborts. Fix: ${USER:-$(id -un)}.
- L5 [testable] scripts/grokbot/machine-setup.sh:30-36. If the sed/awk version extraction matches nothing, the result is empty, so pandoc's check greps " $" and `go install …@` runs with an empty version. Fix: fail fast if any extracted version is empty.
- L6 [testable] scripts/grokbot/machine-setup.sh:270-277. The upstream guard only skips 127.*. An upstream equal to DOCKER0_IP or a box IP (dnsmasq listens there) would loop. no-resolv (:281) is correct. Fix: also reject $DOCKER0_IP.
- L7 [non-testable] scripts/grokbot/machine-setup.sh:315 and :331. Timestamped backups (.bak.$STAMP) never clobber the original on rerun, which is good. A symlinked resolv.conf is replaced by a regular file (cp -pL keeps the target content, but mv breaks the link). They accumulate in /etc. Fix: if resolv.conf is a symlink, back up the link target path too and document restoring the link.
- L8 [testable] scripts/grokbot/machine-setup.sh:333-335. dockerd restart: if pkill does not stop it within 30s, a second dockerd is started anyway; there's no pid-file check. Fix: fail if it is still running after the wait, or kill -9 after the timeout; use --pidfile.

== OK / verified ==
- Idempotency: every step is check-gated. .bashrc is prepended once (head -1 check), .profile is appended once (grep -x), the env snippet is a full-content compare, and dnsmasq.conf and daemon.json are content-compared. Backups are timestamped and only made when a change happens.
- dnsmasq config (:280-287): no-resolv; server=<detected upstream>, which on this box is 198.18.0.53 from resolv.conf; address=/localhost/ and /localhost.floci.io/ → 127.0.0.1 (subdomains included); bind-interfaces on 127.0.0.1 and docker0. Everything else goes upstream. No self-loop for 127.* (see L6).
- daemon.json merges (`.dns = [ip]` keeps other keys) and refuses to restart dockerd while containers are running, but see H2.
- Floci: FLOCI_IMAGE=mariotoffia/floci:latest (:29) with no digest pin. It is pulled on every apply run, and --check only inspects. This complies with Mario's rule. (6de2b604 had the a31d6e08 digest pinned; fixed by 545befb0.)
- Secrets: none read or written; no tokens or keys in the files. NO_PROXY handling is fine.
- Scope: only GROKBOT.md and scripts/grokbot/*.
- Issue link: "Closes #1247" in closingIssuesReferences; #1247 "W-2026-0001: machine setup script for the Linux build box" is OPEN.
- Copilot: 0 review threads (draft; no Copilot review yet).
- §1 Go gates: N/A (no Go changes). A shell lint gate is missing: shellcheck was not run because it is not installed. Recommend running it in CI or installing it.

# Re-review — PR #1248 @ f6f2e6d0 (2026-10-22 22:20 Europe/Stockholm)
GitHub head = f6f2e6d0b9ba523a95c2ebe18d2506cf2d7a29af and matches the brief. Reviewed sha: f6f2e6d0.
Static only: bash -n OK; machine-setup.sh and lintarch/run.sh were not executed.
Fresh merge-base 45ba749f. Scope: GROKBOT.md (+177), scripts/grokbot/README.md (+11), scripts/grokbot/machine-setup.sh (+519). Nothing else changed.
New commits since 13298dd2: 7254f1bb, a4f98ec7, 9230d0cc, 4aa8cd94 (docs), af325bab, d46bc15a, f6f2e6d0.

== Verdict ==
APPROVED. M3/M4 are with technical-writer and do not block; M6 is dev-lead's call; docker-group membership is left out of the verdict as instructed.

== Earlier findings ==
- H1 RESOLVED.
  - step() runs apply as `( set -e; "$apply" )` outside an if-condition (:124), so errexit is live.
  - On failure it restores the backups registered for the step and exits 1 (:126-129).
  - Go is fetched, sha256-verified, extracted and smoke-run (:201-203) before /usr/local/go is moved aside (:205), and the swap is a rename.
  - The resolv backup (:479) runs before install, so a failed backup aborts before the overwrite.
- H2 RESOLVED. daemon.json goes into a private temp file (:496-497), is checked with jq -e (:498) and dockerd --validate (:499), then backed up and installed atomically (:500-501). stop_dockerd waits on pgrep (:152-156). If the restart fails, the old config is restored and dockerd is started again (:503-506).
- M1 RESOLVED. Exit 3 when --check finds pending changes (:519), documented at :9-10. 1-check.log shows rc=3 with would-change=3.
- M2 RESOLVED. dns_answers needs probe.localhost → 127.0.0.1 and an upstream answer (:163-166). apply_resolv (:476) and apply_daemon_dns (:489) refuse to run unless dnsmasq answers. resolv.conf keeps its search/options lines (:478) and is checked with getent after the switch (:481). The step order is now config, then run, then resolv, then daemon.json.
- M5 RESOLVED.
  - Docker comes from the signed apt repo with a fingerprint check (:344-346), and its package versions are pinned (:56-58).
  - nvm install.sh, Go, pandoc, opa and act are sha256-pinned via fetch() (:133-137); a missing arch pin fails cleanly.
  - aws-cdk and prettier are version-pinned (:290); Go modules go through the sum database.
- L2 MOSTLY RESOLVED. has() greps captured text (:144) and is used at :213/236/237/250; legacy_docker_state uses || true (:380). Residual: check_group (:400), out of verdict scope, and gpg|awk (:345), see N3.
- L3 RESOLVED. check_pnpm reads the corepack cache dir and no longer runs the shim (:278).
- L4 RESOLVED. ME=${USER:-$(id -un)} (:34).
- L5 RESOLVED. Every repo-derived version is checked non-empty and the script fails fast (:75-77).
- L6 RESOLVED. first_ns rejects 127.* and the docker0 IP (:427).
- L7 RESOLVED/ACCEPTED. A symlinked resolv.conf is logged as becoming a plain file (:477). Backups carry UNDO lines (:101), and the 5 newest are kept (:511-516). Residual: see N2.
- L8 RESOLVED. dockerd runs with --pidfile (:148), stop_dockerd fails if dockerd is still alive after 30s (:155), and that fails the step before a second start.
- L1 (iptables) IMPROVED. Only the legacy filter FORWARD→DOCKER jumps, DOCKER* chains and the FORWARD DROP policy are removed (:380-392). It refuses to run without a non-empty mode-600 backup (:385) and logs UNDO.
- M3 (technical-writer, non-blocking) PARTIAL. GROKBOT.md:132 covers the rerun after a box swap, and the script now restarts dnsmasq early (:168-174). GROKBOT.md:43 still says only "exits non-zero if any step failed", with no mention of exit 3 or the UNDO lines.
- M4 (technical-writer, non-blocking) RESOLVED. GROKBOT.md:111 describes the detected upstream with 10.0.0.2 as a last resort. MACHINE_SETUP_UPSTREAM_DNS is gone from both the doc and the script.
- M6 (dev-lead) OPEN. GROKBOT.md:11-14 ("never go into teos source") still conflicts with #1244's test-side skip. The fix authors say it is correct as is; dev-lead to decide.

== Evidence (machine-setup/*.log, all headed "# sha f6f2e6d0", 22:18:10–22:18:17 Europe/Stockholm, before the push at 22:18:46) ==
- 1-check.log: 3 WOULD-CHANGE (apt: bind9-dnsutils and gnupg new; dnsmasq conf; dnsmasq run). Floci is inspected only, not pulled. changes=0, rc=3. Correct.
- 2-run.log: the same 3 CHANGE, an UNDO line for the dnsmasq conf, changes=3, rc=0.
- 3-rerun.log: 0 CHANGE, changes=0, rc=0. Idempotency is shown.
- Upstream 10.0.0.2 is read from /etc/resolv.conf.bak.20261022T220559. I verified that file holds nameserver 10.0.0.2 (this box's original), so there is no loop.
- Not exercised by the logs: the daemon.json/dockerd restart path, the Go swap and the rollbacks. These paths are confirmed statically only.

== New findings (none blocking) ==
- N1 [Low] [testable] machine-setup.sh:205-206. The old Go is moved to go.bak.$STAMP but is not registered in BACKUPS. If :206 fails, or the post-check fails because the pinned GO_VERSION 1.27.3 is lower than GO_REQUIRED, rollback leaves /usr/local/go missing or wrong. go.bak dirs are never pruned (about 250MB each). Fix: check ver_ge GO_VERSION GO_REQUIRED before downloading, and restore go.bak on failure.
- N2 [Low] [testable] machine-setup.sh:511-516. Pruning to the 5 newest resolv.conf backups can drop the original pre-dnsmasq backup. :431 relies on a backup with a real nameserver; after enough cycles that falls to 10.0.0.2. Fix: keep the oldest (original) backup as well as the newest.
- N3 [Low] [testable] machine-setup.sh:345. `gpg … | awk '{…; exit}'`: awk exits early, gpg can get SIGPIPE, and pipefail plus errexit fails the step spuriously. Fix: capture the gpg output first (as has() does).
- N4 [Info] dns_answers (:165) resolves sts.eu-west-1.amazonaws.com as the upstream probe. It is a DNS query only, with no AWS API call, so "nothing talks to AWS" still holds. A neutral name would be cleaner.
- N5 [Info] A step failure now aborts the whole run (exit 1 after rollback), which is intended and documented at :13. The Floci pull failure also exits 1 (:412).
No secrets. Copilot: 0 threads (re-checked). Closes #1247.
== Head moved after this review ==
At 22:20:22 Europe/Stockholm, 4d44b98e was pushed on top of f6f2e6d0. It adds 7 comment-only lines in machine-setup.sh above check_group explaining why the docker group is kept, with no code change. That topic is out of scope for the verdict. The verdict carries over to 4d44b98e as a comment-only delta; the f6f2e6d0 logs stay valid because the trees differ only in a comment.
