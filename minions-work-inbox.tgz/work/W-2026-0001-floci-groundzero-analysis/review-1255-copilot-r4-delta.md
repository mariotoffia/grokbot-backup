# #1255 delta 9f33caca..c402a3f4 (Copilot r4), for Dev Lead
- ingestion_test.go: assertLogsOutput runs only when harness.Target()==local (Floci). AWS skips with t.Logf, because a reused deployment logs at info and trace would log raw payloads.
- sinks_helpers_test.go: assertLogsOutput takes thingName and counts only transform events whose message contains "$aws/things/<thing>/".
- Gates r4 all rc=0. Floci -race rc=0, 80s, per-record 1/1. Logs are in copilot/r4/.
