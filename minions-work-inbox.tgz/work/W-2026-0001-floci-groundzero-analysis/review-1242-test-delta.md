# Test review — PR #1242 (T-27.1), delta 4b08764e..f9497460

== Verdict == CHANGES_REQUESTED (evidence only; the test code in the delta is approvable)

== Findings ==
[Major] [non-testable] impl/T-27.1/gates/test-service-f9497460.log:5, test-service-race-f9497460.log:5 — Both green runs used image mariotoffia/floci@sha256:07ced9c6d987…2ba1, not the pinned a31d6e08f9a8…dd5c1. image-digest.txt and evidence.md still name a31d6e08, so the evidence doesn't match the pin. The strict FG-4 pass is proven on 07ced9c6 only. Fix: either rerun groundzero with -tags=e2e,floci -count=1 -race -v on a31d6e08 at f9497460 and get rc=0 with all 7 TestRestAPIContract subtests passing, or record a deliberate re-pin to 07ced9c6 in image-digest.txt and evidence.md, with the Dev Lead's or CTO's sign-off.
[Major] [non-testable] impl/T-27.1/evidence.md — The newest HEAD it records is 4ac29c54. There is no entry for f9497460, no rc for the race run, and nothing on the dropped header assertions or on FG-4 now being strict. Fix: add an f9497460 section citing test-service-race-f9497460.log (rc=0) and test-service-f9497460.log (make test-service, rc=0).
[Minor] [testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:90-97 — Coverage lost beyond the 403 Forbidden header: the MissingAuthenticationTokenException header check on the unknown-path case is gone too. Floci did set that header (see the 4ac29c54 evidence), so this was a passing, meaningful check. Unknown path and missing key are still distinguishable by body message, so the impact is small. Fix: optionally keep the MissingAuthenticationTokenException check. Otherwise record in the PR body/evidence that both header checks were dropped by decision, and that FG-7 no longer has a test hook.
[Info] [non-testable] impl/T-27.1/gates/test-integration-rerun-f9497460.log — rc=2 from cmd/cblicense (TestCreateCommandRefusesAnotherAccountDomainForAnIssuedLicense, TestCreateCommandWritesAnIssuedLicenseGivenItsOwnAccountDomain). That package is not touched by this PR, so it isn't blocking here, but it should be noted in evidence as pre-existing or environmental. test-service-f9497460-goflags-race-cgo-fail.log is a void run ("-race requires cgo") and is superseded by test-service-race-f9497460.log.

== Rationale ==
Remaining assertions: assertForbidden and the unlinked-plan case assert status == 403 and message(body) == "Forbidden" exactly. message() unmarshals JSON and calls t.Errorf on a non-JSON body, so the check is neither loose nor tautological. The unknown path asserts 403 plus the exact "Missing Authentication Token". assertNothingEchoed still runs first, with boolean no-echo checks for the key, API id, path, stage and run suffix. Each of these can fail. The bound-key 200 + JSONEq positive control remains, so the negatives aren't trivially passing.

SEC-1 coverage:
- (a) Unlinked plan → "key in a plan not linked to the stage is forbidden": strict 403 + "Forbidden".
- (b) Disabled key → "disabled key is forbidden" via assertForbidden.
- (c) Bound then unbound → "key bound and then unbound is forbidden": 200 while bound, then EventuallyWithT 403 after DeleteUsagePlanKey.

FG-4 is now strict. The status==200 && IsLocal skip is removed, and nothing conditional is left in the subtest. The only remaining IsLocal is in contractHTTP (endpoint selection, not an assertion).

Dead code: assertForbiddenErrorType was deleted and call() now returns (status, body). There are no unused helpers or imports ("strings" is still used by assertNothingEchoed, harness by contractHTTP), and lint-go-f9497460-rerun.log shows 0 issues, rc=0.

Determinism is unchanged: no sleeps, unique per-run names, cleanup per create, and EventuallyWithT for revocation.

Evidence (both at HEAD f94974607dad…, image 07ced9c6):
- test-service-race-f9497460.log: -tags=e2e,floci -count=1 -v -race, all 7 TestRestAPIContract subtests PASS including the strict FG-4 case, TestTheLogsCapEvictsNothingUnderNormalVolume PASS, ok, rc=0, end 12:37 CEST.
- test-service-f9497460.log: make test-service, rc=0. TestThePublicNamesResolveToThisMachine PASSes on this box now.

The only gap is that this is the wrong (unrecorded) image.

CI at f9497460: Analyze (actions) SUCCESS. Analyze (javascript-typescript) shows no conclusion (pending). CodeQL NEUTRAL. Build, Unit Tests, Static Analysis and Architecture SKIPPED. Bugbot and the Security Reviewer NEUTRAL. No CI check runs e2e.

---
# Re-review at 75c3be6b (2026-10-23)

== Verdict == APPROVED_DEGRADED

== Findings ==
[Info] [non-testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go — f9497460..75c3be6b is comment-only: 1 file, +5/-4, and every changed line is a `//` comment (task ids out of the header, the rejection doc now says status 403 + exact body + no echo). The f9497460 runs therefore still apply. The new doc matches what the code asserts.
[Info] [non-testable] image-digest.txt, impl/T-27.1/evidence.md — Both match the logs: HEAD f94974607dad and image 07ced9c6d987…2ba1 on lines 1 and 5 of both f9497460 logs. The race and make test-service runs are rc=0, with 7/7 TestRestAPIContract PASS and 0 FAIL/SKIP. Integration is rc=2, from cblicense only (#1245), and the run without cgo is marked void. Both header drops are disclosed, MissingAuthenticationTokenException included. Both files now record digests as what :latest resolved to, not pins, so the earlier Major findings are closed.
[Minor] [non-testable] STATUS.md:229 — The dev-lead line "Floci digest for remaining W-2026-0001 tasks pinned to a31d6e08" contradicts the new recorded-not-pinned policy. My own line at 626 ("not pinned a31d6e08") repeats the old framing. Fix: append a STATUS line that supersedes :229 (STATUS is append-only).
[Minor] [non-testable] delivery-plan.md:31, impl/T-27.16.3/task.md:19, impl/T-27.16.4/task.md:16, packets/P-2026-0001-{08..32}.yaml "Marker rule … pinned Floci image (sha256:9710d466)", packets/P-2026-0001-34/36.yaml "pinned digest", impl/T-27.16.3/evidence.md:3 "a31d6e08 (TK_LOCAL_EMULATOR pinned)" — These still require marker qualification on a pinned digest. Fix: reword them as "on mariotoffia/floci:latest, with the resolved digest recorded in evidence", or add a single policy note in delivery-plan.md that supersedes them. This isn't blocking for #1242.
[Info] [non-testable] floci-gaps — Task 50 still lists FG-7, which no longer has a test hook. That is fine if the list is meant as Floci gaps rather than test hooks.

== Rationale ==
The PR content and its own evidence are now consistent: the code at 75c3be6b equals f9497460 apart from comments, and there are green -race Floci runs with 7/7 subtests and a strict FG-4 on a recorded digest. Coverage, SEC-1 a/b/c and determinism are unchanged from the delta review. The verdict is DEGRADED rather than APPROVED for two reasons: e2e runs only locally (CI skips Build, Unit Tests and the static jobs), and older work-dir docs still use "pin" language. Those docs are a process clean-up, not a defect in the PR.
