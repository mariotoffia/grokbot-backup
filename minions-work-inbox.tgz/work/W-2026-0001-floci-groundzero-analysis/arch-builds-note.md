== Design Note ==
Question: arch-selectable Lambda builds (local = host arch, AWS = arm64). Sizing at a3543337.

Context:
- Runtime arch is already configurable. `common.architecture` (provision-config, e.g. deployment/stacks/groundzero/service-test/provision-config.yaml:21, provision-config.local.yaml:35, both `arm64`) flows to BaseProperties.Architecture (deployment/lib/adapters/cdk/construct/properties.go:205-208, default ARM64; :121-123). function.go:227-229 then maps it to Architecture_ARM_64/X86_64.
- Host detection exists: product/defaults.go:76-95 (`CB_LAMBDA_ARCH` env, else runtime.GOARCH), used only when architecture is empty.
- Compile arch is hard-coded. `lambda.WithCompile(native.ARM64, …)` (options.go:120) passes the arch straight to the compiler (native/compiler.go:197 GOARCH). There are about 100 calls in about 66 stack files, e.g. groundzero/registrar.go:236-237, ingestionsvc/deployment/stack.go:239, devicesvc/deployment/stack.go:230, buildingsvc/deployment/services/lambda_base.go. So an `amd64` config would give an x86 function running an arm64 bootstrap: that mismatch is the Exec format error.
- Others: root Makefile:26-37 already uses the host GOARCH (tools only); devops/handlers/devops-clean-table/Makefile:9 `GOARCH := arm64`; devops/gh-backup (ECS, --platform linux/arm64, out of scope). flocilocal (go-core/utils/testutils/flocilocal) has no arch logic. CI (.github/workflows) runs only ubuntu-latest x86, with no arm64 or QEMU job.

Options:
A (Recommended) Single source of truth: WithCompile ignores its arch argument (or gains `native.Auto`) and uses props.GetArchitecture(), resolved in compileOp from the build context. Local configs set `architecture: auto` (or omit it, falling back to detectArchitecture). cbdeploy/provisioncfg rejects anything but arm64 for non-local targets. Stack edits are mechanical.
B Keep the per-stack arch argument and add a global override (`CB_LAMBDA_ARCH` read in compileOp). Smallest diff, but two sources of truth remain and the CDK Architecture can still drift from the binary.
C Keep arm64 everywhere and require binfmt/qemu locally (done on this box, see w0-env.md). Zero code, but it's slow, emulated, and needs re-setup after a host reset.

Recommendation: A. Effort is about 3–4 days:
- 1.0 d: compileOp resolves arch from properties; Auto value; unit tests.
- 0.5 d: provisioncfg validation (non-local => arm64), `auto` in local configs, defaults.go precedence.
- 0.5–1.0 d: sweep about 100 WithCompile calls (mechanical) + devops Makefile.
- 0.5 d: CI QEMU arm64 smoke job.
- 0.5–1.0 d: docs (DEPLOYMENT.md, SERVICE_TEST.md), ADR, review, svctest run on x86 and arm64.

Risks / ADRs:
- An x86 local run doesn't fully prove arm64 behaviour. All compiles are CGO=0 with lambda.norpc, so pure Go is largely arch-neutral. Residual risks: unsafe/alignment or 64-bit atomics assumptions, arch-specific asm or deps, float/SIMD edge cases, binary size and cold-start differences. AWS deploys stay arm64, so the dev/test envs catch these.
- CI: keep arm64 the release artifact. Add a cheap `GOARCH=arm64 go build ./...` gate plus a QEMU (or arm64 runner) smoke test of a few handlers.
- Reproducible-build hashes will differ per arch. Asset hashes and code signing should be checked for local-vs-AWS confusion.
- An ADR is warranted ("arm64 is the only deployed arch; local builds follow host"). No .go-arch-lint.yml change: those maps (e.g. go-services/appstore/.go-arch-lint.yml) govern package dependencies, not CPU arch.

Handoffs:
- platform-lead: implement A in deployment/lib (compileOp, provisioncfg) + sweep.
- qa-lead: rerun groundzero/building svctests natively on x86 without binfmt, then a QEMU smoke.
- cto: approve the ADR; decide whether arm64 CI runners are worth the cost vs QEMU.
