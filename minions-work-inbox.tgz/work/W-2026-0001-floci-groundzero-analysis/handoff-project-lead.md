⟦MINION v1 | id=msg-W-2026-0001-004 | w=W-2026-0001 | type=handoff | from=dev-lead | to=project-lead | re=msg-W-2026-0001-001 | hop=1 | ttl=24h | state=analysis-done⟧
STATUS: done
PACKET: P-2026-0001-01
ARTIFACTS:
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/ANALYSIS.md — verdicts, upstream state, waves, risks
- /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/handoff-project-lead.md — this packet
SUMMARY: All 16 tasks are doable on floci-io/floci main. Every referenced fix is merged, including #5262 and #6054 today, plus #5261, which was missed. mariotoffia/floci:latest (09:36 CEST) predates those two merges, so rebuild it from main first. 39.11 is already done; only its two skip removals are left. New risk: 44.2 (#5450) is merged, so API-key enforcement may break building/SUR local tests until 27.28 / 44.1. Please plan delivery for 5 waves, at most 4 agents per wave.
NEXT_HINT: Route via CTO; Mario's explicit go is required before any implement packet.

```yaml
id: P-2026-0001-01
work_id: W-2026-0001
type: delivery
autonomy: pair
phase: planning
assignee: project-lead
reply_to: cto
issued_by: dev-lead
issued_at: 2026-10-21T14:40:00+02:00
ttl: 24h
skills_to_use: [writing-plans]
skills_forbid: []
may_consult: [qa-lead, platform-lead, release-config-mgr]
inputs:
  - kind: note
    path: /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/ANALYSIS.md
  - kind: brief
    path: /workspace/minions/inbox/floci-groundzero/TEOS_GROUNDZERO_TASKS.md
  - kind: f-spec
    path: /workspace/minions/inbox/floci-groundzero/plans/teos-adoption/README.md
  - kind: note
    text: >-
      Scope: TEOS tasks 27.1, 27.10, 27.12, 27.13, 27.14, 27.16.1, 27.16.2, 27.16.3, 27.16.4, 27.16.6,
      27.20, 27.21, 27.25, 27.27, 27.29 and the 39.11 follow-up (remove the two GoBridge skips). One TEOS PR each.
      Order: 27.20 after 27.14; eventsvc tasks SERIAL (27.25 then 27.16.6 then 27.16.1).
      W0 = rebuild mariotoffia/floci:latest from floci main (7c0d592b8 or newer), record the digest, and check
      building/SUR local tests for 403 from 44.2 (#5450). If they fail, hold 27.27 and 27.29 and raise 44.1 upstream.
      Waves W1-W4 as in ANALYSIS.md §3. Cap 4 agents per wave (6 team-wide).
      Checklists: §C for go-core tasks, §A for service-test tasks.
      Gates: §1 make fmt / lint (lint-go + lint-arch) / vet / test / tidy, plus local Floci integration or service
      test, plus an AWS cloud run by qa-lead before any marker deletion.
acceptance:
  - id: A1
    text: "delivery-plan.md with the five waves, owners by roster slug, and the order 27.14 -> 27.20 and the eventsvc chain"
  - id: A2
    text: "milestones.yaml with W0 image rebuild + digest as the first milestone and per-wave qa-lead cloud qualification"
  - id: A3
    text: "risk-register.md covering 27.28/44.2 API-key hazard, #5131 coverage of gzip binary bodies (27.29), MQTT vs HTTP shadow path, image pin drift (consts.go vs provision-config.yaml), shared-box Docker capacity"
  - id: A4
    text: "No worktree, branch or implement packet until Mario's go is recorded in STATUS.md (go-approved)"
budget:
  cloud_agent_runs: 0
  fix_loop_rounds: 3
  wall_clock: 8h
  tokens_hint: null
constraints:
  owns: ["/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/**"]
  read_only: false
  no_credentials: true
context_bundle:
  conventions: /workspace/minions/CONVENTIONS.md
  plans: [/workspace/minions/inbox/floci-groundzero/plans/]
  architecture: [/workspace/thiink/teos/AGENTS.md, /workspace/thiink/teos/TESTS.md, /workspace/thiink/teos/SERVICE_TEST.md]
on_blocked:
  escalate_to: cto
  reason_codes_ok: [need-input, need-approval, dependency, conflict, unclear-brief]
```
