# AC4 AWS gate: VOID (cancelled by CTO decision msg-W-2026-0001-cto-089)

Scope rule: W-2026-0001 is Floci-only, so no real AWS (including devlocal). These AC4 runs are void and are not gate evidence.

- Requested: PR 1214 (event-service @3b13732a), 1215 (collector-service @fe87f139), 1213 (device-service @6cd7cd45), 1212 (@05844b9f).
- Stopped at 19:41 CEST before any results were reported. No partial logs were saved.
- Created in devlocal (account 033549287452, eu-west-1): stacks teos-event (created 18:58 CEST) and teos-collector (created 19:24 CEST). Both were already DELETE_COMPLETE by the test teardown.
- Leftover resources found and removed: log groups /aws/lambda/eventsvc-clwsubscriber, /aws/lambda/teos-collector-CustomS3AutoDeleteObjectsCustomReso-ytEUlsnPH63F, /aws/lambda/teos-event-CustomS3AutoDeleteObjectsCustomResource-NATtbbikqHYa.
- No stacks are in progress or failed, and no S3 buckets were created after 18:45 CEST.
- Local: worktrees ac4-pr1212..1215 removed. There were no running test-service-cloud processes.
- Not checked: device-service and 27.12 never deployed (no stacks found).
