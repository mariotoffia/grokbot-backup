# Security review: PR #1270 @425a10cf (fix for #1252 L-1)
2026-10-24 (Europe/Stockholm). Static `git diff` review only (merge-base..425a10cf); nothing run, no sudo, no comments. Head confirmed: **425a10cf** (one commit; machine-setup.sh +16/-6).

## Verdict: **approve**. L-1 is closed as scoped (legacy rollback + EXIT trap). One Low (L-2, recommended in this PR) and one Info (I-1).

### L-1 check
- **restore_ipt_alternatives:**
  - `local rc=0`. Each family's `--set` failure now does `{ log FAIL …; rc=1; }`, and the function ends with `return "$rc"`.
  - Both families are always attempted; a v4 failure doesn't skip v6.
  - The no-op guard (current link equals ORIG) and the empty-value skip are unchanged and both return 0.
  - Quoting is fine.
- **apply_ipt_legacy rollback:** `if restore_ipt_alternatives; then start_dockerd (if it was running) …; else log FAIL "dockerd left stopped"`.
  - The `if` context suppresses `set -e`, which is intended: the step still reaches `return 1`.
  - The marker is removed only if dockerd is running, so it stays when dockerd was deliberately left stopped.
- **cleanup (EXIT):** same pattern. It retries the restore once; if that fails, it logs FAIL and leaves dockerd stopped. There's no loop, and `rm -rf "$WORK"` always runs.
- **Fail-closed result:** when the backends are mismatched, Docker is left stopped (no container traffic) and the error is visible in the log. It's never started on split v4/v6 backends.

### Findings
- **L-2 (Low): the same divergence remains in apply_ipt_alt's own failure path.**
  - That path (a failed nft switch) still restores inline with `sudo update-alternatives --set iptables "$old4" || true` and the same for v6. It then runs `start_dockerd` unconditionally (if dockerd was running).
  - So if the v4 or v6 restore fails there, dockerd still starts with the families split. Also, `--set iptables ""` is attempted when `old4` is empty (it fails harmlessly, but there's no empty guard).
  - Impact is as for L-1: a backend mismatch, not an opened firewall; relevant mainly with Docker IPv6 on.
  - Fix: replace those two lines with `if restore_ipt_alternatives; then [ "$was_running" = 0 ] || { start_dockerd && rm -f "$WORK/dockerd-stopped"; } || true; else log FAIL "…dockerd left stopped"; fi`.
- **I-1 (Info):** when dockerd is left stopped on purpose, nothing beyond the FAIL log tells the operator to fix the alternatives and rerun. Optionally add a hint to that FAIL line (for example "fix update-alternatives for iptables/ip6tables, then rerun").

### Other checks
- No new fail-open paths.
- No PATH changes.
- The marker/trap logic is unchanged apart from the gating.
- No firewall rules flushed or opened.
- No secrets touched.

## Escalation flags
None.

---
## Delta @1a1ca117 (425a10cf..1a1ca117), 2026-10-24 (Europe/Stockholm)
1a1ca117 is the current PR head. One commit. Static `git diff` only; nothing run.

### Verdict: **approve**. L-2 and I-1 are closed; one new Info (I-2, theoretical).

- **L-2 closed:**
  - apply_ipt_alt's failure path now does `if restore_ipt_alternatives; then` start dockerd if it was running, and removes the marker only after a successful start. `else log FAIL "$IPT_RESTORE_HINT"`, and dockerd stays stopped.
  - `return 1` is always reached.
  - The marker stays when dockerd stays stopped, so the EXIT trap retries the restore once, under the same restore-success condition, and then gives up.
- **Empty-value guards:**
  - `old4/old6=${ORIG_IPT*:-}` (safe under `set -u`). The UNDO log line for v4 is now guarded with `[ -z "$old4" ] ||`.
  - The restore goes through the helper, which skips empty values, so `--set iptables ""` is no longer possible.
- **I-1 closed:** `IPT_RESTORE_HINT` is defined at script scope, next to ORIG_IPT*. It's used in all three FAIL sites: the trap, apply_ipt_alt and apply_ipt_legacy. The text names `update-alternatives --config iptables (and ip6tables)` and says to rerun. It's a static string: no secrets, no variable expansion of untrusted data. In the trap it's reached only after a marker exists, which is after the definition.
- **I-2 (Info, theoretical):**
  - If `ORIG_IPT4` was empty (no iptables alternative before the run) but the v4 `--set` to nft succeeded and v6 then failed, the helper can't revert v4 and returns success, so dockerd starts.
  - That needs `update-alternatives --set` to succeed for a group whose `/etc/alternatives` link didn't exist at capture time. That's practically impossible: the docker/iptables package creates the group earlier, and the capture runs after the package steps.
  - No action needed. Optionally, treat an empty ORIG as a restore failure when the current link exists.
- **Regression scan:**
  - The other paths are unchanged.
  - No new fail-open paths: every failure branch leaves dockerd stopped and logs it.
  - No PATH, quoting or firewall-rule changes.

### Escalation flags
None.
