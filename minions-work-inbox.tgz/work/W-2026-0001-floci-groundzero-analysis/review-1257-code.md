# PR #1257 code review (code-reviewer): ingestionsvc go-arch-lint map

- Head: bcce8f1e0899473a3e0c9a530529436051816e85 (unchanged, DRAFT, base main, Closes #1256)
- Range: merge-base 89f62e5f (fresh origin/main)..bcce8f1e. 1 commit, not stacked. Files: go-services/ingestionsvc/.go-arch-lint.yml (+44) and go-services/ingestionsvc/Makefile (+6).
- df -h: / 52% used, 62G free.

## Verdict: CHANGES_REQUESTED

## Map vs real imports (go list, non-test, deployment excluded)
- ingestioncore imports errorcodes, cberror, ifcore, model/{coremodel,dsmodel,eqmodel,ingestionmodel}. All are allowed via mayDependOn [errorcodes] and canUse [core-pure].
- handlers/dstransform/main imports ingestioncore, ifcore, model/{coremodel,ingestionmodel}, lambdasupport, logger, logger/log, providercontext, tkdisp/{cblambda,runtime}, aws-lambda-go/events and zerolog. All are allowed.
- errorcodes imports nothing (no deps entry, correct).
- No missing edges and no self-edges. The core cannot reach the runtime, AWS or handlers, so the hexagonal shape holds. Re-run here: `make lint-arch` rc 0. Negative test: injecting a lambdasupport import into ingestioncore gives rc 2 with "Component core shouldn't depend on ...lambdasupport". That agrees with lint-arch-service-broken-fail-bcce8f1e.log (rc=1).
- Makefile target: `lint-arch:` is at column 0, so the root discovery `grep -q '^lint-arch:'` finds it. It uses the same `cd .. && --project-path . --arch-file` pattern as LINT.md:223 for a package inside a larger module. OK.

## Findings
- [High] [testable] impl/ingestionsvc-arch-lint/gates/ — The scoped gates for format, golangci-lint, vet and tests are missing; only the lint-arch logs exist (those are fine: sha, cmd, dir, rc=0). I re-ran them here at bcce8f1e (gofmt clean, golangci-lint 0 issues, vet rc 0, tests ok), so the code is fine, but the evidence is required. Fix: add sha/cmd/dir/rc= logs for each, including a golangci-lint pass that is not empty.
- [Medium] [non-testable] LINT.md:225 — Not updated. The count still says "Maps in place today (10)" and ingestionsvc is not listed. The LINT.md:223 table example list could also name it. Fix: 11 maps (or 12 if #1250 buildingsvc lands first; rebase and recount), and add `ingestionsvc`. Root log: "Architecture maps checked: 10" Makefiles, which is consistent (eventsvc counted once).
- [Medium] [non-testable] #1256 board status is "Progress", not "Incoming" (it was Incoming at creation per issue-create.log). Sprint 21 is set, which is allowed. Roadmap is unset. Fix: set it back to Incoming per the issue-first rule, or confirm that Progress is intended once the PR is open.
- [Info] [non-testable] .go-arch-lint.yml handler canUse core-pure includes cberror, which the handler does not import. This is a vendor grant only; it is harmless, but it decays silently (LINT.md:236).

## Compliance
- #1256: assignee mariotoffia, label core, Priority=Medium, Size=Hours (issueFieldValues), OPEN.
- Titles: the PR title "ingestionsvc: add go-arch-lint map and lint-arch target", the commit subject "chore(ingestionsvc): add go-arch-lint map and lint-arch target" and the #1256 title have no W-/T- prefix. OK.
- Repo-wide failures: there are no repo-wide gate logs, so nothing to confine (covered by the High above).

## Round 2: bcce8f1e..7139f4b8

- Head: 7139f4b854aece379ef30bd1a68b7bd2821253ff (as expected). 2 commits: 5c0480ac "chore(ingestionsvc): drop the unused cberror grant from the handler" and 7139f4b8 "docs(lint): list the ingestionsvc architecture map". The PR title is unchanged. None of them carry a W-/T- prefix.
- Map: the new `core-errors` vendor group = go-core/cberror only, granted to the core only. go list confirms ingestioncore imports cberror and handlers do not, so the grant matches real use exactly and widens nothing. The handler canUse is now [core-pure, core-runtime, aws-lambda, zerolog], with every entry used. The hexagonal shape holds.
- Re-run here at 7139f4b8: service `make lint-arch` rc 0. Negative tests: handler->cberror gives rc 2 ("handler shouldn't depend on ...cberror"), and core->zerolog gives rc 2.
- LINT.md:223/225: ingestionsvc is listed in the in-module table row and in the map list, and the count is 11. The count is maps, which is distinct from the root "Architecture maps checked: 10" (Makefiles, eventsvc counted once), so it is consistent.
- Gates (*-7139f4b8.log): all have sha, cmd, dir and rc=0.
  - gofmt: empty output.
  - golangci-lint: fresh cache, 3 packages listed, 13 active linters, 0 issues. Not an empty pass.
  - vet: rc 0.
  - test -race: 2 ok.
  - lint-arch service and root: rc 0.
  - lint-arch-root-7139f4b8-interrupted.log is a terminated earlier attempt, superseded by the complete root log. Info only.
- #1256 (checked read-only): R&D Sprint Board Status=Incoming, Sprint 21, Roadmap unset, Priority Medium, Size Hours, assignee mariotoffia, label core.
- #1258 "ingestionsvc: add service docs (DDD, ubiquitous language, architecture, lint, ADRs, plans)": follow-up for the missing ingestionsvc service docs found in the #1255 hexagonal review. Docs only. Assignee mariotoffia, labels documentation and core, Priority Medium, Size Hours, Status Incoming. No prefix. Compliant.

### Findings
- [Low] [non-testable] LINT.md:225 — Ordering conflict with #1250 (OPEN, 798b11c5). It also changes "(10)" to "(11)" (adding buildingsvc). Whichever PR merges second will get a textual conflict and must say 12 and list both. Fix: rebase after the first merge and set 12. Track it in whichever PR lands second.
- Round 1 H1 (gates): FIXED. M1 (LINT.md): FIXED. M2 (#1256 status): FIXED. Info (cberror grant): FIXED.

### Verdict: APPROVED at 7139f4b8 (the Low is a merge-order note, not a blocker; the PR is still a DRAFT)
