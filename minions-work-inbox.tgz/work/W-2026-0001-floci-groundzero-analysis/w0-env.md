# w0-env — box environment setup (P-2026-0001-04, platform-lead)
Date: 2026-10-21 ~14:55 Europe/Stockholm (CEST)

## A1 — clean teos clone: FAIL (need-input)
- Remote identified from docs/go.mod (README.md, cmd/cbgenerate/go.mod, minions/TEOS_CONVENTIONS.md): https://github.com/Thiink-LLC/teos.git, branch main.
- /workspace/thiink/teos is not a git checkout (no .git) — left untouched.
- No credentials on the box: `gh auth status` = not logged in; no ~/.git-credentials, no credential.helper, no ~/.ssh, no GH_/GITHUB_ env vars.
- `git ls-remote https://github.com/Thiink-LLC/teos.git` -> "could not read Username" (private repo).
- Cursor GitHub connector: scm_repo_not_accessible for Thiink-LLC/teos.
- Clone /workspace/thiink/teos-main NOT created; no SHA/commit date.
- Missing (one of): (a) grant Thiink-LLC/teos to Cursor's GitHub App (https://github.com/apps/cursor/installations/new) AND a git credential on the box, or (b) a read-only fine-grained PAT / deploy key for Thiink-LLC/teos installed via `gh auth login` on the box, or (c) a git bundle/tarball of origin/main with its SHA.

## A2 — make + cbdeploy build: PARTIAL
- make installed: `sudo apt-get install -y make` -> GNU Make 4.4.1. PASS.
- Go: go1.27.3 at /usr/local/bin/go (DEVELOPMENT.md requires Go 1.25+) — satisfies.
- README.md/DEVELOPMENT.md setup order: `make install` -> `make dep` -> `make generate` -> `make build` (cbdeploy is installed by `make install`; see DEPLOYMENT.md). NOT run: these must run inside a real clone and the clone is blocked by A1. Followed so far: prerequisites check only (Go version, make).
- cbdeploy build / go.sum check: NOT RUN (blocked by A1).

## A3 — docker socket: PASS
- Before: srw-rw-rw- root:docker (666). Group docker existed (gid 102).
- Agent shells run as user `box` (uid 1000; only human-range user, owns all agent processes). Added box to docker.
- After: srw-rw---- root:docker (660).
- `sg docker -c 'docker ps'` as box: OK. As orbitd and nobody: permission denied.
- Persistence: no systemd (PID 1 = tini); dockerd started manually with no flags (14:47:08). dockerd recreates the socket on restart with group `docker` mode 660 by default; wrote /etc/docker/daemon.json `{ "group": "docker" }` to make it explicit (no conflicting -G flag, so safe). Not restarted dockerd.
- Caveat: existing shells don't have the new group; new login shells will, otherwise use `sg docker -c '...'` or `newgrp docker`. Whoever started dockerd with a 666 chmod must not re-chmod after restart.

## Retry after Mario's GitHub grant (2026-10-21 ~14:55 CEST)
- Connector get_branch(main) and list_commits(main): still `scm_repo_not_accessible` -> no main SHA available.
- Connector search_repositories DOES see Thiink-LLC/teos (private, default_branch main, pushed_at 2026-10-21 14:04:12 CEST, account has admin). So the user account sees it, but the Cursor GitHub App installation doesn't grant per-repo access yet (wrong org/installation selected, "selected repos" missing teos, or propagation pending).
- `GIT_TERMINAL_PROMPT=0 git clone https://github.com/Thiink-LLC/teos.git /workspace/thiink/teos-main` ->
  `fatal: could not read Username for 'https://github.com': terminal prompts disabled`
  (no git credentials on the box; the connector grant doesn't give git a credential, and I won't extract one from it).
- A1 still FAIL (need-input); A2 make install/dep/generate/build not run.

## RESOLVED run on /workspace/repos/teos (2026-10-21 15:04–15:22 CEST) — supersedes the teos-main notes above
### A1: PASS
- Clone: /workspace/repos/teos, remote https://github.com/Thiink-LLC/teos.git, branch main tracking origin/main.
- After `git fetch`: `## main...origin/main` (not ahead or behind), working tree clean.
- HEAD = origin/main = a3543337fecc19d11bcfe78157a9ef36731546c5, commit date 2026-10-21 14:04:10 CEST.
- /workspace/thiink/teos untouched; teos-main never created.

### A2: PASS (only box-environment fixes were needed)
Steps followed from README.md "make install / dep / generate / build" and DEVELOPMENT.md Initial Setup (Go 1.25+ -> go1.27.3):
1. `make install` failed first: `make: /bin/zsh: No such file or directory` (Makefile SHELL=/bin/zsh). Fix: `apt-get install zsh` (first attempt hit a deb mirror 500; worked after apt-get update). Rerun rc=0.
2. `make dep` failed: pnpm/corepack `Failed to create cache directory ... (/usr/local/share/corepack)`. Fix: env `COREPACK_HOME=$HOME/.cache/node/corepack`. Rerun rc=0.
3. `make generate` failed at fmt-go: `client_gen.go/iam_api_gen.go/noda_api_gen.go:1:1: expected 'package', found 'EOF'`. Cause: `~/go/bin` (oapi-codegen, installed by make install) not on PATH, and the shell had no docker group yet (openapi-generator runs in docker). Fix: `PATH=$HOME/go/bin:$PATH` and running under `sg docker`. Rerun rc=0 (and it restored the files that the failed run had blanked or deleted).
4. `make build` rc=0.
- cbdeploy: /home/box/go/bin/cbdeploy (built 15:17), `cbdeploy version 1.0.0`.
- `git status --porcelain` after the build: empty, so no go.sum/go.mod or other changes. Nothing committed or reverted.
- Required env for future shells: `export PATH=$HOME/go/bin:$PATH COREPACK_HOME=$HOME/.cache/node/corepack`, plus docker group (new login or `sg docker`).
- Caveat: Node v20.19.2 is EOL (tools warn; support in new releases ends 2026-10-29). Not blocking.

## P-2026-0001-05 (2026-10-21 ~15:35 CEST): arm64 emulation + bridge firewall persistence
Restore script: **/usr/local/sbin/box-env-restore.sh** (root, idempotent). Run: `sudo /usr/local/sbin/box-env-restore.sh`
When to run it: after any box restart or kernel reset (binfmt is lost) and after any dockerd restart (docker rewrites the firewall chains). It's safe to run any time.
What it does:
1. Mounts binfmt_misc if it isn't mounted. On this box it was NOT mounted, which is why the first `tonistiigi/binfmt --install` silently didn't stick.
2. If /proc/sys/fs/binfmt_misc/qemu-aarch64 is absent, runs `docker run --privileged --rm tonistiigi/binfmt@sha256:400a4873b838d1b89194d982c45e5fb3cda4593fbfd7e08a02e76b03b21166f0 --install arm64` (pinned digest, image cached locally).
3. Docker-bridge allow rules (qa-lead's fix; iptables-legacy FORWARD policy is DROP, dockerd uses nft), check-before-add:
   `iptables-legacy -C FORWARD -i br-+ -j ACCEPT || iptables-legacy -I FORWARD 1 -i br-+ -j ACCEPT` and the same with `-o br-+`.
4. Re-applies docker.sock root:docker 660.

### A1: PASS
- `docker run --rm --platform linux/arm64 alpine uname -m` -> `aarch64`.
- Registration: interpreter /usr/bin/qemu-aarch64, flags POCF. With the F flag the kernel keeps the interpreter loaded, so emulation works after the installer container exits.
- Durability: no systemd/rc.local/boot hook on the box (PID 1 tini), so the registration is lost on reboot or kernel reset and must be restored with the script. I didn't use the apt qemu-user-static/binfmt-support route: without systemd-binfmt it gives no boot-time persistence either.

### A2: PASS (persisted via the script + documented)
- Rules present now: `-A FORWARD -i br-+ -j ACCEPT`, `-A FORWARD -o br-+ -j ACCEPT` (iptables-legacy, ahead of DOCKER-USER).
- I didn't use iptables-persistent: it needs a boot service (systemd/netfilter-persistent) that never runs here.
- No startup hook added: there's no reliable boot mechanism, and a profile.d hook would need root on every login (fragile).

### Idempotency proof
- Run 1 and run 2 on the current state: all "already registered/present", no changes.
- I then removed the qemu-aarch64 registration and the `-i br-+` rule. Run 3 output: "registered qemu-aarch64", "added FORWARD -i br-+ ACCEPT", "-o present". Run 4: all present. Exactly 2 br- rules (no duplicates). arm64 uname still prints aarch64.

## Note (2026-10-22, release-config-mgr): Node 22 for teos
User-level Node v22.23.4 via nvm in ~/.nvm (system /usr/bin/node v20 untouched). Activate before make: `unset NPM_CONFIG_PREFIX; export NVM_DIR=$HOME/.nvm; . $NVM_DIR/nvm.sh --no-use; nvm use 22 >/dev/null`. Details: node22.md.
