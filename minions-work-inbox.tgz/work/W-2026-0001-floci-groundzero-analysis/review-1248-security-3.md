# Security re-check: PR Thiink-LLC/teos#1248 @ 1bd4d95e
Reviewer: security-auditor · Packet msg-W-2026-0001-release-config-mgr-147 · 2026-10-22 (Europe/Stockholm)
Method: `git diff f6f2e6d0 1bd4d95e` and `git show 1bd4d95e:scripts/grokbot/machine-setup.sh` only. New commits: 4d44b98e, 590972f6 (docs), 1bd4d95e. No sudo of any kind, nothing from the script run, no .env. Line numbers are @1bd4d95e.
PR: https://github.com/Thiink-LLC/teos/pull/1248

## Verdict: **approve** (on condition that N-1 provenance is fixed in the comment or confirmed by Mario, see below)

## Per-item status
| item | status | evidence |
|---|---|---|
| N-2 Go/docker.asc rollback + prune | **resolved** | The Go swap registers `GODIR <bak>` in $BACKUPS immediately after moving the old tree (:216-218). restore_backups handles GODIR with `rm -rf /usr/local/go; mv <bak> /usr/local/go` (:116-117). docker.asc goes through `backup` before install (:365). If no key existed before, the "-" entry deletes the new one on rollback. Prune keeps 3 go.bak.* (:556) and 5 docker.asc backups (:555). The prune runs only after a fully successful apply run (:552). |
| N-3 docker group guard | **resolved** | `SUDO_NOPASSWD=0; sudo -n true 2>/dev/null && SUDO_NOPASSWD=1` (:428). Because this is an && list, set -e doesn't fire when it fails. The step runs only if the value is 1 (:430-431). Otherwise the script logs `INFO SKIP docker group … would add a new root path` (:433). The rationale and undo are in a comment (:418-424). |
| N-4 all fingerprints | **resolved** | Every `fpr` record (primary key and subkeys) goes through sort and is compared for exact set equality with DOCKER_GPG_FPRS (:56, 360-363). An extra or missing key fails. An empty set (no keys or unparseable file) gives "" ≠ expected and fails closed. A gpg error fails the `keys=$(…)` assignment under the subshell's set -e. |
| N-1 :latest accepted risk | **comment present, provenance NOT confirmed** | The comment at :65-68 calls it Mario's rule, relayed by msg-W-2026-0001-platform-lead-133. I searched all of /workspace/minions (work/, inbox/, archive/, log.jsonl, packets): **no msg-W-2026-0001-platform-lead-133 exists**. Only review-fixes.md and security-fixes.md cite that id, and both were written by the fixing team. The closest real Mario record is packets/P-2026-0001-02.yaml:14 ("Mario approved … image = mariotoffia/floci:latest built from floci-io/floci main"), plus log.jsonl:2 (judge by merged-on-main in :latest). Those show Mario chose the :latest image. They do **not** say "never pin to a tag or digest". The repo-side pin (TK_LOCAL_EMULATOR @sha256, image-digest.txt) actually points the other way. |

## SEC-1248-1..13 regression check
All still resolved. In detail: SEC-1 got stronger (full fingerprint set). SEC-3 got stronger (Go and the key rollback are now in the registry). SEC-13 now also covers docker.asc and Go trees and always keeps the oldest resolv.conf backup, the box's original (:554). Nothing else changed. A new start-up guard refuses to run if GO_VERSION is older than the repo's go/toolchain requirement (:83-86), which is good. GROKBOT.md (docs only) contains no secrets.

## New issues
| id | sev | location | issue | recommendation |
|---|---|---|---|---|
| N-5 | Medium (governance) | scripts/grokbot/machine-setup.sh:65-67 | The accepted-risk comment cites a message id that can't be found in the shared message log or work files, and states a rule ("never pinned") stronger than Mario's recorded decision. | Point the comment at P-2026-0001-02.yaml:14, or have platform-lead put msg-…-133 (with Mario's exact words) in log.jsonl. If neither can be done, ask Mario to confirm through the CTO before merge. |
| N-6 | Info | scripts/grokbot/machine-setup.sh:428 | `sudo -n true` also runs in --check mode. It is harmless (no change, no prompt). | Optional: skip it when CHECK_ONLY=1 and report WOULD-CHANGE. |
| N-7 | Info | scripts/grokbot/machine-setup.sh:56 | Because the subkey is pinned, a Docker key rotation or new subkey makes installs fail closed until the set is updated. That is intended, and safe. | Note it in GROKBOT.md maintenance. |

## Escalation flags
None new. The box-design note from review 2 (shared user with passwordless sudo) still stands. N-5 is a governance/provenance flag for the CTO, not an authz-bypass, secret-leak, tenant-bleed or iam-loosening.
