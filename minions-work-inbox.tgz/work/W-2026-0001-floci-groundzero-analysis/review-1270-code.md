# Code review: PR #1270 (Thiink-LLC/teos)
- Head SHA: 425a10cffe685c03ae5d75c740e4b3a6ecb43baa (unchanged from requested 425a10cf)
- Closes: #1269 (from #1252 L-1)
- Reviewed: 2026-10-24 12:18 CEST
- **Verdict: CHANGES_REQUESTED**

## Gates
| Gate | Result |
|---|---|
| Correctness (restore_ipt_alternatives + callers) | Partial: see M-1 |
| bash -n scripts/grokbot/machine-setup.sh | PASS (no output, rc 0) |
| shellcheck -x scripts/grokbot/machine-setup.sh | PASS (no output, rc 0) |
| CI (gh pr checks 1270) | PENDING: Analyze (javascript-typescript) pending; Analyze (actions) pass; Architecture/Build/CodeQL/Static Analysis/Unit Tests skipping. Branch protection API lists no required contexts |
| Title/commit prefix | PASS: "build: keep dockerd stopped when iptables alternatives restore fails" (no W-/T- prefix) |
| Plan IDs in code comments | PASS (none added) |
| Issue #1269 hygiene | Assignee mariotoffia; labels follow-up, build, groundzero; Priority=Low, Size=Hours; board status **Progress** (not Incoming); iteration Sprint 21; no Roadmap value |

## Findings
- **Medium M-1** scripts/grokbot/machine-setup.sh:565-569 (apply_ipt_alt rollback). When the nft switch fails, this path restores alternatives inline with `|| true` on each update-alternatives call and then runs start_dockerd anyway. It does not call restore_ipt_alternatives and does not check whether the restore worked. So dockerd can still start with v4 and v6 on different backends, which is the L-1 failure class. Fix: call `restore_ipt_alternatives` (old4/old6 == ORIG_IPT4/6) and gate start_dockerd on it, e.g. `if restore_ipt_alternatives; then [ "$was_running" = 0 ] || { start_dockerd && rm -f "$WORK/dockerd-stopped"; } || true; else log FAIL ...; fi`.
- **Low L-1** CI not settled: CodeQL Analyze (javascript-typescript) is still pending at the head.
- **Low L-2** Issue #1269 project status is Progress, not Incoming as the convention expects (defensible while the PR is open). Roadmap is unset (OK). The iteration is set to Sprint 21.
- OK: restore_ipt_alternatives (541-548) now uses local rc and sets rc=1 when either family's update-alternatives fails. It still treats an empty ORIG_IPT4/6 as a no-op success, as before. The cleanup EXIT trap (145-153) and apply_ipt_legacy rollback (655-660) both gate start_dockerd on its result. Since the restore runs inside `if`, set -e does not abort. The trap ends with rm -rf and never calls exit, so the original exit status is kept: bash keeps $? from before the trap. If restore fails, the marker is left in place and dockerd stays stopped. `[ "$PENDING" -eq 0 ] || exit 3` (967) and readlink -m link_points_to (425) are untouched.

## Informational (#1252 open Lows, not touched)
- Lines 210/215 still say "30s".
- Comment at 141 ("only survives a failed run") is unchanged.
- DNS restart after the nft switch can still revert to legacy (marker not cleared after the dockerd step). Untouched.

## Evidence
```
gh pr view 1270 --json headRefOid,title,commits
git fetch origin pull/1270/head:refs/pr/1270; git diff $(git merge-base origin/main refs/pr/1270) refs/pr/1270
git show refs/pr/1270:scripts/grokbot/machine-setup.sh > /tmp/ms.sh; bash -n /tmp/ms.sh; shellcheck -x /tmp/ms.sh
gh pr checks 1270
gh issue view 1269 --json assignees,labels,projectItems; gh api graphql (issueFieldValues, projectItems.fieldValues)
```

## Delta 1 (425a10cf..1a1ca117), reviewed 2026-10-24 12:20 CEST
- Head: 1a1ca117581d02b2da72de6f9d4a6d9ec37e0b84 (matches the claimed head)
- **Verdict: CHANGES_REQUESTED.** Blocked only by pending CI; the code is acceptable.

| Gate | Result |
|---|---|
| M-1 | RESOLVED: machine-setup.sh:567-572 gates start_dockerd on restore_ipt_alternatives; on failure it logs IPT_RESTORE_HINT and keeps the marker |
| No dockerd start after failed restore | PASS. All start_dockerd callers (147, 569, 647, 659, 683, 941/945) checked; none run after a failed restore |
| Guards / hint | PASS. local old4=${ORIG_IPT4:-}; UNDO logs guarded on empty values. IPT_RESTORE_HINT is a plain global set at top level, before cleanup can be reached through main. Restore calls sit inside `if`, so set -e is unaffected. The trap still never calls exit |
| bash -n / shellcheck -x | PASS (no output, rc 0 for both) |
| Commit subjects | PASS (no W-/T- prefix); no plan IDs in comments (grep '#.*[WT]-[0-9]' returns nothing) |
| CI | PENDING: Analyze (actions) and Analyze (javascript-typescript) pending; others skipping |

Findings:
- **Low D1-L1** machine-setup.sh:567: if ORIG_IPT4 was empty (no iptables alternative at start), restore_ipt_alternatives now reports success without resetting iptables. A half-applied nft switch then restarts dockerd on nft. Previously `--set iptables ""` failed and was ignored, then dockerd restarted anyway, so this is no worse than before. It is an edge case; optional: treat an empty ORIG_IPT4 as a failure in this path.
- **Low (carried over)**: Issue #1269 board status is Progress, not Incoming.
- The informational #1252 Lows are still untouched.

Evidence: git diff 425a10cf refs/pr/1270; bash -n / shellcheck -x on the extracted file; grep start_dockerd|restore_ipt_alternatives; gh pr checks 1270.

## Delta 1 final

APPROVED at 1a1ca117. CI is green: CodeQL and both Analyze jobs pass. Architecture, Build, Static Analysis and Unit Tests were skipped for this shell-only change, matching the pattern on #1252. D1-L1 is declined by dev-lead (msg-465) as theoretical (security I-2).
