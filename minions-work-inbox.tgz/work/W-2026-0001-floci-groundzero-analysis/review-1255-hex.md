# Hexagonal review — PR #1255 @ ce280894 (T-27.16.4 ingestionsvc Firehose + Logs on Floci)
Reviewer: hexagonal-reviewer minion (read-only). Merge-base dc86df55. Floci-only; no AWS touched.

== Verdict ==
CHANGES_REQUESTED  (capped at APPROVED_DEGRADED even after gates fixed: no ingestionsvc arch-lint map)

## Diff (3 files, +131/-7, all black-box e2e test module)
- go-services/ingestionsvc/deployment/service-test/go.mod (firehose, cloudwatchlogs indirect -> direct)
- .../service-test/ingestion_test.go (Floci t.Skip removed; runStart; calls new asserts)
- .../service-test/sinks_helpers_test.go (new; //go:build e2e)

## Hexagonal check
- Touched code is a black-box e2e test (exempt from port substitution); uses AWS SDK directly, acceptable there. Uses ifcore.CbContext (forbidigo fixed in ce280894). No production code touched.
- Production structure (go list direct imports): ingestioncore -> go-core/{cberror,interfaces/ifcore,model/*}, ingestionsvc/errorcodes only — no infra SDK (pre-existing, clean). handlers/dstransform/main (inbound adapter + composition root) -> ingestioncore, aws-lambda-go/events, go-core lambda/logger runtime — inward-only. No adapter-to-adapter coupling, no port in adapter, no domain leak in adapter. No ports exist (core is a pure transform function; nothing to substitute).

== Findings ==
- [High] [testable] gates/ — required gates not evidenced at HEAD ce280894: static-f7acb910.log is at f7acb910 (lint rc=1 forbidigo sinks_helpers_test.go:34,76 there; also first lint rc=127, local lint-arch rc=2 no target); no `make test` log; no test-integration log. Fix: rerun fmt/vet/lint/lint-arch/tidy, make test, test-integration at ce280894 and save logs. (Reviewer rerun at ce280894 for touched pkg: gofmt clean, vet -tags integration,floci,e2e rc=0, golangci-lint rc=0, tidy rc=0 — evidence only, not a substitute.)
- [Medium] [non-testable] go-services/ingestionsvc/ — no arch-lint map (.go-arch-lint.yml) and no `lint-arch` Makefile target; root `make lint-arch` checks 9 maps, not this one (pre-existing). Fix: add map below (ADR + lead-architect approval per CONVENTIONS).
- [Medium] [non-testable] go-services/ingestionsvc/ — missing service-local DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md, adr/, plans/ (pre-existing; only manifest/features/root.md). Fix: follow-up issue.
- [Low] [testable] service-test/ingestion_test.go:125 — runStart = now-5s couples to box/Floci clock skew; acceptable, note only.

## Gate table
| Gate | Commit | rc | Evidence | Status |
|---|---|---|---|---|
| gofmt | f7acb910 | 0 | gates/static-f7acb910.log | stale commit |
| vet | f7acb910 | 0 | same | stale |
| lint | f7acb910 | 1 (forbidigo) | same | FAIL at that commit; reviewer rerun ce280894 rc=0 (review-hex/lint.log) |
| lint-arch (root) | f7acb910 | 0, 9 maps | same | ingestionsvc not covered |
| tidy | f7acb910 | 0 | same | reviewer ce280894 rc=0 |
| make test | — | — | none | MISSING (High) |
| test-service Floci | ce280894, floci@sha256:07ced9c6 | 0 | gates/test-service-ce280894-07ced9c6.log | PASS TestIngestionServiceFlow (80.18s), 0 skips (Floci skip removed) |
| test-integration | — | — | none | MISSING (High) |
| vet -tags integration,floci,e2e (reviewer) | ce280894 | 0 | this review | PASS |

## Missing lint-arch map spec
- Path: go-services/ingestionsvc/.go-arch-lint.yml; module is go-services (ingestionsvc not its own module) => `workdir: ingestionsvc`.
- Makefile target in go-services/ingestionsvc/Makefile: `lint-arch:` -> `cd .. && go-arch-lint check --project-path . --arch-file ingestionsvc/.go-arch-lint.yml` (root lint-arch auto-discovers it).
- Components: errorcodes (errorcodes), core (ingestioncore), handler (handlers/**). Deps: core mayDependOn errorcodes, canUse go-core cberror/ifcore/model/** only; handler mayDependOn core, canUse core-pure + go-core lambdasupport/logger(/**)/providercontext/tkdisp/** + aws-lambda-go + zerolog. depOnAnyVendor:false; exclude _test.go and deployment/ (separate modules).
- Tested from /tmp: proposal rc=0 "OK - No warnings found"; broken copy (core canUse []) rc=1 with violations. Files: impl/T-27.16.4/review-hex/{proposed-ingestionsvc.go-arch-lint.yml,good.log,bad.log}.

== Rationale ==
Change is test-only and hexagonally neutral; production ingestionsvc is clean (pure core, thin inward Lambda adapter). Verdict blocked by missing/stale required gate evidence at HEAD. Map absence caps final verdict at APPROVED_DEGRADED. No escalation needed.

## re-review @849de752 — 2026-10-23 12:45 CEST
Reviewer: hexagonal-reviewer minion (read-only). Merge-base unchanged; commits since ce280894: 0ca387e5 (named skew), 849de752 (drop unused DescribeLogGroups). Floci-only, no AWS.

== Verdict ==
APPROVED_DEGRADED — upgrades to APPROVED once #1257 merges (still OPEN/draft at bcce8f1e). Not conditional on -race: the -race service run finished rc=0.

## Gate table (every log header sha = 849de75274f0…)
| Gate | rc | Evidence |
|---|---|---|
| gofmt | 0 | impl/T-27.16.4/gates/gofmt-849de752.log |
| vet | 0 | impl/T-27.16.4/gates/vet-849de752.log |
| golangci-lint | 0 (0 issues; forbidigo fixed) | impl/T-27.16.4/gates/golangci-849de752.log |
| make lint | 0 (attempts 1–2 rc=2 were missing web dist, superseded) | impl/T-27.16.4/gates/make-lint-849de752.log |
| lint-arch root | 0, 9 maps (ingestionsvc not covered until #1257) | impl/T-27.16.4/gates/lint-arch-root-849de752.log; reviewer rerun review-hex-evidence/1255-root-849de752.log rc=0, 9 maps |
| lint-arch service | n/a, no map | impl/T-27.16.4/gates/lint-arch-service-849de752.log |
| tidy | 0 | impl/T-27.16.4/gates/tidy-849de752.log |
| make test | 0, 597 ok, 0 FAIL; the allowed cblicense/cbdeploy failures did not occur | impl/T-27.16.4/gates/make-test-849de752.log |
| test-integration | 0, no integration package (documented NONE); change is e2e/floci-tagged only | impl/T-27.16.4/gates/test-integration-849de752.log |
| test-service (Floci sha256:07ced9c6, -race, tags e2e,floci) | 0, PASS TestIngestionServiceFlow 80.21s, ended 12:40 CEST | impl/T-27.16.4/gates/test-service-849de752-07ced9c6.log |
| vet -tags integration,floci,e2e (reviewer, worktree /tmp/hx1255) | 0 | this review |

## Hexagonal check
- Diff is still 3 files, all in the e2e module deployment/service-test (go.mod, ingestion_test.go, sinks_helpers_test.go). No production code touched.
- go list -deps -test (tags integration,floci,e2e): ingestionsvc imports only its own test package plus go-core/deployment/lib harness packages (svctest, flocilocal, ifcore). No ingestionsvc adapter→adapter coupling, no ports in adapters, no domain leak. Black-box test uses the AWS SDK directly, which is fine there.
- Skew fix verified: ingestion_test.go:125 `runStart := time.Now().Add(-runStartClockSkew)`, with const runStartClockSkew = 5*time.Second and a doc comment in sinks_helpers_test.go. It is a named constant now; the behaviour is unchanged.

== Findings ==
- [High] gates not evidenced — RESOLVED.
- [Medium] no ingestionsvc lint-arch map — OPEN, being fixed by #1257 (not merged). This is the reason for the APPROVED_DEGRADED cap.
- [Medium] [non-testable] missing service docs (DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md, adr/, plans/) — OPEN, existed before this PR, needs a follow-up issue.
- [Low] clock-skew sensitivity — RESOLVED (named constant). Note only.
