# Test review — PR #1255 (T-27.16.4), delta 849de752..5124119e

== Verdict == CHANGES_REQUESTED

== Findings ==
[Major] [testable] go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go:136 (filterLogEvents) — There is no guard against a repeated token and no page cap. The helper calls cloudwatchlogs.NewFilterLogEventsPaginator(logs, in) with default options, and in aws-sdk-go-v2 FilterLogEventsPaginatorOptions.StopOnDuplicateToken defaults to false. If Floci or AWS echoes the same NextToken, the loop never ends: on the transform group while there are no events, and on the error groups always, since stopAtFirst=false there. require.Eventually does not cancel ctx at 90s, so the condition goroutine runs until go test -timeout (60m), and the error-group calls hang the test outright. Fix: build the paginator with func(o *cloudwatchlogs.FilterLogEventsPaginatorOptions){ o.StopOnDuplicateToken = true } and add a page cap (for example a const maxLogPages = 100 that returns an error once exceeded). For the error groups, use a bounded per-call context.WithTimeout. Optionally add a unit test with a fake client that returns the same token twice.
[Minor] [testable] go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go:91-99 — There is no FilterPattern, so "transform Lambda has events" accepts any line from the Lambda, including START/END/REPORT runtime lines and an error log. Paging doesn't change this; the loose matching was already there at 849de752. The run at 5124119e logged "transform Lambda log events since run start: 2". Fix (optional): filter on a message the transform writes per record, or on the run's record id, so the check proves this run's records went through.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go:82-120 — The window is StartTime = runStart − 5s (runStartClockSkew), with no EndTime. That isn't loose for the positive check, because the groups are per-deploy and created after runStart. For the error-group assert.Empty it is the strict direction. Neither causes flakiness.
[Info] [testable] ingestion_test.go:79,143 — time.Sleep(5s) and time.Sleep(15s) are outside this delta and pre-existing. The new code waits only with require.Eventually (90s/3s) and has no sleeps.
[Info] [non-testable] evidence — Every check below holds, with no gaps.

== Rationale ==
Paging fixes a real false-negative and false-positive risk: one FilterLogEvents page can be empty while it still carries a NextToken. The fix follows NextToken until the SDK reports HasMorePages()==false, i.e. a nil token. Each call starts a fresh paginator, so no tokens carry over between Eventually ticks.

Assertions stay unconditional. The positive check is require.Eventually on len(events)>0. For each error group, the code requires FilterLogEvents to succeed (so the group must exist) and then asserts no events, logging the first 300 characters of each one. Both checks can fail.

No coverage is lost. The same groups, stream filter, StartTime and messages are used, and the only change is that every page is now read. There are no dead helpers: cwltypes is used, filterLogEvents has two callers, and golangci reports 0 issues.

What blocks APPROVED is the item you explicitly asked about: without a duplicate-token guard and a page cap, the new loop can hang. It's a two-line fix.

Evidence: copilot/r1/test-service-5124119e.log
- HEAD 5124119ea419. Image line mariotoffia/floci@sha256:07ced9c6…2ba1, run as floci:latest (resolved digest recorded, per project policy).
- go test -tags=e2e,floci -count=1 -v -race (svcroot-copilot.sh).
- --- PASS: TestIngestionServiceFlow (80.16s), ok 181.725s, rc=0. Started 14:29:01 and ended 14:32:12 CEST.
- 0 DATA RACE / FAIL / SKIP lines.

Static gates at 5124119e are all rc=0: gofmt, vet, golangci (e2e,floci; 0 issues), tidy, lint-arch (9 maps), and unit plus the e2e compile-only check.

CI at 5124119e:
- CodeQL and Analyze (actions, javascript-typescript): SUCCESS.
- Build, Unit Tests, Static Analysis, Architecture: SKIPPED.
- Bugbot and Security Reviewer: NEUTRAL.
- No CI job runs e2e.

Copilot r2 (14:47 CEST) left no new comments.

---
# Re-review at 14aad90b (2026-10-23), delta 5124119e..14aad90b

== Verdict == APPROVED_DEGRADED

== Findings ==
[Minor] [testable] go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go:94-111 — The transform check still tests only count > 0. stopAtFirst=true returns on the first page that has events, so nothing is compared with the number of records sent. Also, dstransform/main.go:63-70 logs "About to transform" before the nil-State guard and before the transform itself, so the line proves the Lambda received a record, not that it transformed one. The successful transform is still proven elsewhere in the flow: ingestion_test.go:225/265 require an S3 object with at least one CbSensorReportItem. Fix (optional): use stopAtFirst=false and assert.Equal(sentRecords, transformEvents) inside the Eventually, which works because Floci emits 1 event per record. Or log a line after the transform succeeds and match on that.
[Minor] [non-testable] go-services/ingestionsvc/deployment/service-test/provision-config.yaml:11 — logLevel: trace is inside the tag::service-override region. deployment/_design/provision-config.adoc:371 includes that region verbatim, and SERVICE_TEST_WRITING.md:54 tells authors to "Start from" this file. So trace becomes the documented, copy-paste example, even though dstransform/main.go:60-62 says trace "must NEVER be enabled in production" because it logs whole raw payloads. At runtime the setting is scoped to the service test, on synthetic data in Floci. Fix: move logLevel outside the tag region, or add a comment in the file saying trace is test-only, needed for the per-record match, and must never be used in production.
[Minor] [non-testable] impl/T-27.16.4/copilot/r2/test-service-14aad90b.log — The log has no cmd line, so -race is only shown by svcroot-copilot.sh line 33 (go test -tags=e2e,floci -count=1 -v -race) and by the script's mtime of 15:00:34, which matches the run start. svcroot-wrapper.log is empty. Fix: write the cmd and dir header lines into the log, as the r1 gate logs already do.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/logpages_unit_test.go — Both fake-client tests exercise the real paths and assert on the result.
  - Duplicate token: the fake returns "same" every time, and the test checks calls==2 for both stopAtFirst values plus NoError. With StopOnDuplicateToken, the second identical token clears nextToken. The fake's 1000-call runaway error turns a broken guard into a failure, not a hang.
  - Page cap: the fake returns a fresh token every time. The test checks require.Error, NotErrorIs(errRunaway) and calls==maxLogPages (100). It doesn't check the error text; asserting Contains "more than 100 pages" would be a nit-level improvement.
  - Neither file has a build tag, so both tests run in plain unit runs (unit-14aad90b.log) and in the e2e run.
[Info] [non-testable] r2/tdd-red.log — The red run failed for the right reason: it used the old helper with only the const added. The duplicate-token test hit errRunaway, and the cap test hit errRunaway with calls=1001 against an expected 100, showing both guards were missing. It ended rc=1, then tdd-green.log passed with rc=0 at 14:59 CEST.
[Info] [testable] go-services/ingestionsvc/deployment/service-test/sinks_helpers_test.go:95-100,127-130 — The timeout is applied correctly. Each Eventually tick gets a fresh ctx.WithTimeout(30s) and cancels it with defer at the end of that call. Each error-group query gets its own 30s context, cancelled right after the call and before the require. A token loop is now bounded three ways: duplicate-token stop, 100-page cap, and 30s.
[Info] [testable] filterLogEvents now accepts cloudwatchlogs.FilterLogEventsAPIClient, so it can be faked, and it moved to logpages_test.go. No dead code is left: the cwltypes import was removed from sinks_helpers_test.go, and golangci reports 0 issues.

== Rationale ==
The Major from 5124119e is fixed and proven test-first. The Minor on the filter is partly fixed: START/END/REPORT lines no longer pass, and the run logged "per-record log events since run start: 1". The check is still not a count of transformed records, but S3 content assertions cover the transform outcome, so this doesn't block. The trace setting has no runtime side effect outside the service test, but it does leak into the docs as the example config.

Evidence: r2/test-service-14aad90b.log
- HEAD 14aad90bcfd2. Image mariotoffia/floci@sha256:07ced9c6…2ba1, the resolved digest, recorded.
- Run via svcroot-copilot.sh: -tags=e2e,floci -count=1 -v -race.
- --- PASS: TestIngestionServiceFlow (80.15s), and both TestFilterLogEvents* tests PASS.
- ok 236.603s, rc=0, started 15:00:34 CEST. 0 DATA RACE / FAIL lines.

Static gates at 14aad90b are all rc=0: gofmt, vet, golangci (0 issues), tidy, lint-arch, and unit (including the two new tests).

CI at 14aad90b:
- Analyze (actions): SUCCESS.
- Analyze (javascript-typescript): pending.
- CodeQL, Bugbot, Security Reviewer: NEUTRAL.
- Build, Unit Tests, Static Analysis, Architecture: SKIPPED.
- No CI job runs these tests, so the new unit tests aren't run in CI either.
