# Floci gap summary: W-2026-0001 (read-only analysis)

Written 2026-10-24 by golang-pro (Core Services Developer). No code, commit or GitHub writes, and no real AWS.

## Sources
- Ledger: `TEOS_GROUNDZERO_TASKS.md` is **not in /workspace/repos/teos** (main @f3a1d6d7). The only box copy is `/workspace/minions/inbox/floci-groundzero/TEOS_GROUNDZERO_TASKS.md` (mtime 2026-10-23 10:54 CEST). It has **no Task 50**, though it has the related 9.2/9.3/9.6, 44.1-44.7 and 49.1. The Task 50 text exists only as the draft in `floci-gaps/tasks.md`, with plans in `floci-gaps/plans/FG-1..8.md`. UNVERIFIED: whether Mario's own copy has Task 50 by now.
- Image: `sudo docker pull mariotoffia/floci:latest` on 2026-10-24 12:2x CEST said "Image is up to date". It resolves to **sha256:07ced9c6d987de7ca432fa35d0f1856ad1c8c87a4fdb96ac3b00b6e68bba2ba1**, created 2026-10-22 22:04 CEST. That is the same digest recorded on 2026-10-23, and it is appended to image-digest.txt. The OCI labels belong to the UBI base image, so they cannot tie the image to a Floci commit.
- Floci source: floci-io/floci upstream/main @307380750 (2026-10-24 06:35 CEST), read with `git log` and `git grep`.
- Probe: on 2026-10-24 about 12:25 CEST I ran a standalone container `fgprobe` on 07ced9c6 at 127.0.0.1:47999. It ran with `env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL`, under the `floci-harness-run` lock in locks.json. Afterwards I released the lock and removed the container.

## Gaps

| Id | Description | Status on :latest 07ced9c6 | Evidence | Blocks |
|---|---|---|---|---|
| FG-1 / 50.1 | The CFN Firehose provisioner drops ProcessingConfiguration, CloudWatchLoggingOptions, ErrorOutputPrefix and RoleARN | **FIXED** | 27.16.4 svc test rc=0 on 07ced9c6 (STATUS 2026-10-23 11:28). Upstream fix is deeb3b307 (#6277). | none now. It was 27.16.4 / #1232, which shipped as PR #1255 (merged). |
| FG-2 / 50.2 | No AWS/SQS CloudWatch metrics | **FIXED** | My probe: after a SendMessage, about 75 s later ListMetrics AWS/SQS lists ApproximateNumberOfMessagesVisible, NumberOfMessagesSent and NumberOfMessagesReceived for QueueName=q1. Upstream fix is ba353021e (#6280). | none on Floci. 27.16.1 (#1240) was merged with the SQS-alarm subtest skipped, so restoring that subtest is optional follow-up. |
| FG-3 | IoT shadow deep merge and per-leaf metadata (Floci 48 / 9.6) | **FIXED** (since a31d6e08) | impl/T-27.21/evidence.md. Upstream fix is 71cc70431 (#6217). | none. 27.21 / #1226 merged. |
| FG-4 (dup of 44.1) | Usage plan apiStages are not read back | **FIXED in image** (golang-pro probe on 07ced9c6, STATUS 2026-10-23 07:56). Upstream main still shows no apiStages in toUsagePlanNode, so the fix appears to exist only in Mario's build. | STATUS 07:56 / 08:05 | 27.1 caveat and the key-bind skips. 27.1 itself was dropped (#1241 not planned). |
| FG-5 / 50.3 | An alarm with TreatMissingData=notBreaching does not return to OK after its datapoints stop | **UNVERIFIED** | Reproducing it needs an alarm period of 8 minutes or more, so I did not probe it. Upstream main has no AlarmEvaluator commit since 2026-10-22, so the gap is likely still open. | the 27.16.1 "OK by itself" subtest (#1240 merged with a workaround: it puts a 0 datapoint) |
| FG-6 / 50.4 | DescribeAlarmHistory is unsupported | **OPEN** | My probe returned `UnsupportedOperation: Operation DescribeAlarmHistory is not supported by CloudWatch JSON.` Upstream main has no DescribeAlarmHistory in services/cloudwatch. | 27.16.1 alarm-history assertions (dropped in #1240) |
| FG-7 / 50.5 | The 403 for an API-key-required method has no `x-amzn-ErrorType: ForbiddenException` | **OPEN** | It persists on 07ced9c6 (STATUS 2026-10-23 07:56: 5 TestRestAPIContract subtests). Upstream ApiGatewayExecuteController.java:488 is still `gatewayResponse(INVALID_API_KEY, 403)` and sets no header. | 27.1 contract cases (#1242 closed unmerged, #1241 not planned). It blocks nothing in flight. |
| FG-8 (dup of 9.2/9.3 + 49.1) | PutLogEvents to a missing group answers "log stream does not exist: <name>", so clwlog never auto-creates the group | **OPEN on image** | My probe returned `ResourceNotFoundException "The specified log stream does not exist: s"` for group /nope. Upstream fix is 613347407 (#6340, 2026-10-23 16:08 CEST), which postdates the image. | 27.29 LogImport (#1238 merged, so this is only a follow-up). TEOS clwlog put.go auto-create on real AWS semantics. |
| (former FG-5) gzip body on 27.29 | Not a gap. It does not reproduce (44.3 / floci#5131). | n/a | impl/T-27.29/gates/gzip-probe-output.txt | none |

Counts (8 gaps, FG-1..8): **fixed 4** (FG-1, FG-2, FG-3, FG-4), **open 3** (FG-6, FG-7, FG-8), **unverified 1** (FG-5).
- The CTO's 2026-10-23 07:35 line "50.1-50.5 fixed in :latest" is wrong for 50.4 and 50.5, and 50.3 is unverified.
- FG-8 is fixed upstream and FG-4 is fixed in the image, but upstream main still lacks the FG-4 fix. A Floci image rebuilt from upstream main would pick up FG-8 and lose FG-4. That is UNVERIFIED, because the build source of Mario's image is unknown.
- Other ledger gaps hit only by the stale-marker scan (16, 42.1, 44.4, 44.5, 44.7) are not W-2026-0001 blockers and were not re-checked.

## Remaining Floci-only tasks

The scope is the 16 W-2026-0001 tasks plus their follow-ups. Done (merged or closed): 27.10, 27.12, 27.13 (already on main), 27.14, 27.25 (#1212-1215); 27.16.2, 27.16.3, 27.16.6, 27.20, 27.21; 27.16.1 (#1240), 27.27 (#1236), 27.29 (#1238), 39.11 (#1234); 27.16.4 (#1255); and the follow-ups #1250 (27.27a), #1257, #1263, #1248, #1252 (merged 2026-10-24, after the last watchdog line that still called it OPEN) and #1256/#1262 (closed completed).

| Task | State | Blocker | Owner suggestion |
|---|---|---|---|
| 27.1 API Gateway v1 contract cases | Dropped: #1242 closed unmerged and #1241 closed not planned by Mario on 2026-10-23 15:24 CEST, because the tests exercised Floci, not TEOS. Branch kept. | A rescope decision from Mario. Restarting it needs a TEOS-behaviour test, and its 403 header assertion depends on FG-7 (open). | platform-lead (scope), then golang-pro, with qa-lead checking that the test exercises TEOS |
| #1258 ingestionsvc service docs | OPEN, not started | none (docs only) | golang-pro (docs), with architect/DDD review |
| #1245 cblicense integration tests need AWS_ENDPOINT_URL when TEOS_DEPLOYMENT=local | OPEN (Incoming) | not triaged or prioritised | golang-pro |
| #1246 cbdeploy SSO test cannot resolve *.localhost.floci.io behind a fake-IP DNS resolver | OPEN (Incoming) | box DNS (198.18 fake-IP, see dns-198-18.md) | platform-lead |
| Task 50 ledger entry (50.1-50.5 + FG-8 dup) | The draft exists only in floci-gaps/tasks.md. It is not in the box ledger copy. | Mario owns TEOS_GROUNDZERO_TASKS.md, and his copy is not on the box. | platform-lead to hand the draft to Mario |
| Optional re-skip cleanup: 27.16.1 SQS-alarm subtest (FG-2 fixed), alarm-history (FG-6), missing-data OK (FG-5) | Not started; needs a go | FG-6 open, FG-5 unverified. The SQS subtest is unblocked now. | golang-pro + qa-lead (must assert TEOS behaviour, given the #1241/#1242 lesson) |
| Optional 27.29 follow-up once FG-8 is in the image | Not started | FG-8 is not in :latest 07ced9c6 | golang-pro |

#1268 (web design system) is Mario's own item, not a minion task.
