#!/usr/bin/env bash
# usage: gates.sh <round>
WT=/workspace/repos/teos/.worktrees/W-2026-0001-ingestion-log-review-followup
O=/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/ingestion-log-review-followup/gates; mkdir -p $O
export PATH=/home/box/.local/bin:/home/box/go/bin:/usr/local/go/bin:$PATH; export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0='*'; unset TEOS_LOCAL_KEEP
SHA=$(git -C $WT rev-parse --short=8 HEAD); ST=go-services/ingestionsvc/deployment/service-test
run(){ n=$1; d=$2; shift 2; { echo "sha $(git -C $WT rev-parse HEAD)"; echo "dir $d"; echo "cmd $*"; echo "start $(date '+%F %T %Z')"; (cd $d && bash -c "$*") 2>&1; echo "rc=$?"; echo "end $(date '+%F %T %Z')"; } > $O/$n-$SHA.log 2>&1; echo "$n $(grep ^rc= $O/$n-$SHA.log)"; }
run gofmt $WT/$ST 'gofmt -l . ; test -z "$(gofmt -l .)"'
run vet $WT/$ST 'go vet -tags=e2e,floci ./...'
run golangci $WT "LINT_FLOCI_MODULES=./$ST golangci-lint run --allow-parallel-runners --build-tags=e2e,floci ./$ST/..."
run lint-arch-root $WT 'make lint-arch'
run tidy $WT/$ST 'go mod tidy && git diff --exit-code go.mod go.sum'
run unit $WT/go-services 'go test -count=1 ./ingestionsvc/... && cd ingestionsvc/deployment/service-test && go test -count=1 -v -run "TestFilterLogEvents|TestItemsForThing" ./... && go test -count=1 -tags=e2e,floci -run XXX_compile_only ./...'
