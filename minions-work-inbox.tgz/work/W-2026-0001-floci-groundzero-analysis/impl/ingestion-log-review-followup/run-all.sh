#!/usr/bin/env bash
# usage: run-all.sh [svc]  -- gates, then Floci svc -race if arg svc
I=/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/ingestion-log-review-followup; WT=/workspace/repos/teos/.worktrees/W-2026-0001-ingestion-log-review-followup; D=go-services/ingestionsvc/deployment/service-test; SL=$I/gates/state.log
SHA=$(git -C $WT rev-parse --short=8 HEAD)
echo "$(TZ=Europe/Stockholm date '+%F %T %Z') gates start $SHA" >> $SL
cd $I; bash gates.sh > gates-$SHA.out 2>&1; tr '\n' ' ' < gates-$SHA.out | sed "s/^/$(TZ=Europe/Stockholm date '+%F %T %Z') gates $SHA: /" >> $SL; echo >> $SL
if [ "$1" = svc ]; then env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL -u TEOS_LOCAL_KEEP ./svcroot.sh $WT $D ingestion-service $I/gates/test-service-race-$SHA.log > $I/gates/svcroot-wrapper-$SHA.log 2>&1
echo "$(TZ=Europe/Stockholm date '+%F %T %Z') svc-race $SHA $(grep ^rc= $I/gates/test-service-race-$SHA.log|tail -1)" >> $SL; fi
echo ALLDONE >> gates-$SHA.out
