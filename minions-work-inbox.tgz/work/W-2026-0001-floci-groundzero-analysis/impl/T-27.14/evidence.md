# T-27.14 evidence (golang-pro minion, packet P-2026-0001-14)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-14-fleet-indexing-readiness
Branch: chore/W-2026-0001-t27-14-fleet-indexing-readiness. Base a3543337. 1b5b316d is pushed (draft PR #1213); 6cd7cd45 is a new local commit on top, not pushed.
Commits:
- 1b5b316d test(devices): qualify local fleet indexing readiness (the test-designer's fleetindexing_test.go, committed as is)
- 6cd7cd45 test(devices): use require.NoError and name the fleet indexing source of truth (review round 1, Low)

Floci image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (docker image inspect Id sha256:3e16af2e77b2...; the svctest harness log prints the same digest).

## AC map
| AC | Result |
|---|---|
| 1 TestFleetIndexingIsConfiguredAfterDeploy | PASS |
| 2 TestFleetIndexingUpdateIsIdempotent | PASS |
| 3 TestTheThingIndexBecomesReady | PASS |
| 4 guard removal | No readiness guard exists, so nothing was removed (search below). |
| 5 AWS run | for qa-lead via cto (no credentials here) |
There is no red phase: the tests pass on base. That matches the test plan's FLAG.

## AC4 guard search (at 6cd7cd45, git-tracked files)
`git grep -l -i -E "fleet.?index|IndexingConfiguration|DescribeIndex|AWS_Things" -- '*.go' '*.sh'` matches the indexing setup (stack_fleet_indexing.go, scripts/created/enable-fleet-indexing), the device searcher, tklocal admin-api code and the new test. None of these wait for or guard on index readiness.
`git grep -n t.Skip` in every *_test.go that mentions fleet or indexing finds only go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go:45 ("the local emulator has no IoT fleet index"), :49 (short mode) and :60 (indexing off in the account). That file belongs to 27.20 and is outside these owns, so it was left alone.

## Gates (repo root, run 2026-10-21, Europe/Stockholm, at 6cd7cd45)
| Gate | Result |
|---|---|
| make dep | The apt step (make install) failed on a deb.debian.org mirror 500 (infra). The tools were already installed, so every other dep sub-target was run by hand: install-hooks, -C web install, go-work-sum, -C go-core/go-services/deployment/lib/cmd/tklocal/documentation/asciidoc dep, all rc=0 |
| make generate | rc=0 |
| make fmt | PASS |
| make lint (lint-examples + golangci-lint 2.14.0, 0 issues + lint-arch with go-arch-lint 1.17.0 over all 9 maps + web lint) | PASS |
| make vet | PASS |
| make test | PASS (rc=0) |
| make tidy && git diff --exit-code | PASS / clean |
| CB_SERVICE_TEST=device-service make test-service (cdk at ~/.local/bin on PATH) | PASS rc=0: devicesvc service-test 21 passed, 0 failed, 0 skipped, including the 3 fleet indexing tests. Other modules: ok. |
The first test-service attempt failed only because the cdk CLI was not on PATH (bootstrap panic). It was rerun with PATH fixed.

## Not done: 27.13 docs commit (addendum 057)
Blocked, need-input: there is no TEOS_GROUNDZERO_TASKS.md in the teos repo. It is not in the worktree, not on origin/main, and not in any commit (`git log --all -- '*GROUNDZERO_TASKS*'` is empty). The only copy is /workspace/minions/inbox/floci-groundzero/TEOS_GROUNDZERO_TASKS.md, outside the repo. Adding a new file would be outside the owns globs, so it needs dev-lead to choose a path. Proposed change once a path is chosen: mark 27.13 done, with evidence TestGetDeviceTypeReadsEveryAnswerOfAWSIoT (go-core/managers/mgriot/awsmgriot; nil guard in devicemanager_aws.go already on main), commit `docs(tasks): mark device type metadata read as done`.

## git diff --stat a3543337..HEAD
```
 .../deployment/service-test/fleetindexing_test.go  | 150 +++++++++++++++++++++
 1 file changed, 150 insertions(+)
```
Only owns-glob files changed. .env was not touched. Nothing was pushed by me.

## Review round 2 (Copilot, dev-lead msg-096), Floci only
- New commit 2d35f941 test(devices): poll fleet indexing with EventuallyWithT so no state is shared. Both waits now use require.EventuallyWithT with *assert.CollectT. Failure details go through the collector, so the DescribeIndex wait shares no variables. The indexing configuration is handed over under a sync.Mutex, so nothing races once the wait gives up.
- Gates at 2d35f941 (PATH includes ~/go/bin and ~/.local/bin; TK_LOCAL_EMULATOR pinned to sha256:9710d466...):
  make fmt PASS; make lint (golangci-lint 0 issues + lint-arch over 9 maps) PASS; make vet PASS; make test PASS; make tidy PASS and git diff --exit-code clean;
  CB_SERVICE_TEST=device-service make test-service PASS (rc=0, devicesvc 21 passed);
  -race proof: CB_SERVICE_TEST=device-service go test -race -tags=e2e,floci ./... in devicesvc/deployment/service-test (the command make test-service runs, plus -race) PASS: 21 passed, 0 failed, 0 skipped, 0 data races. The 3 fleet tests also pass alone under -race with 0 races.
  GOFLAGS=-race make test-service stops before devicesvc. gobridge's service-test TestMain hits a data race inside the third-party jsii-runtime-go (internal/kernel/process), which is not in this diff and not in our code. That is why devicesvc was run directly as above.
- No real AWS and no devlocal profile were used.
