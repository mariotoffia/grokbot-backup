> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.14 test plan (test-designer minion, packet P-2026-0001-13)
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-14-fleet-indexing-readiness (base a3543337, uncommitted). Image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7.

== Test Plan ==
| AC | Case | Type / tags | Package, file | Seam | Assertion | Red before change? |
|---|---|---|---|---|---|---|
| 1 | TestFleetIndexingIsConfiguredAfterDeploy | e2e (+floci locally) service test | servicetest, go-services/devicesvc/deployment/service-test/fleetindexing_test.go (new) | harness.AWSConfig() -> iot client, GetIndexingConfiguration | REGISTRY_AND_SHADOW, namedShadow ON, connectivity STATUS, filter [building], both custom fields (ElementsMatch) | NO, passes on base |
| 2 | TestFleetIndexingUpdateIsIdempotent | same | same | a second UpdateIndexingConfiguration with the stack's settings | no error; config after equals config before and still matches AC1 | NO, passes on base |
| 3 | TestTheThingIndexBecomesReady | same | same | DescribeIndex(AWS_Things) polled with assert.Eventually (2 min cap, 2 s tick), no fixed sleep | IndexStatus ACTIVE | NO, passes on base |
| 4 | guard removal | grep | - | - | dev-lead pre-check found no readiness guard. The only fleet skip is devicesearcher_aws_integration_test.go:43-46 (27.20), which is not in scope and is left alone | n/a |
| 5 | Floci-local gate | e2e | same | `CB_SERVICE_TEST=device-service make test-service` against mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 | un-skipped test passes locally; evidence in impl/T-27.14/evidence.md | - |

FLAG: all three tests already pass on base a3543337 with the pinned image. This matches the pre-check: there is no guard to remove, so 27.14 is "add the qualification test only". There is no red phase. golang-pro only needs to run the gates. No production change is expected in stack_fleet_indexing.go or enable-fleet-indexing.
Note: wantedCustomFields repeats the stack's two custom fields. The deployment package is "main" and cannot be imported. Keep the two in sync.

== Run (2026-10-21, Europe/Stockholm) ==
`sg docker -c 'TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7; cd go-services/devicesvc/deployment/service-test && CB_SERVICE_TEST=device-service go test -tags=e2e,floci -count=1 -v -run "TestFleetIndexing|TestTheThingIndexBecomesReady" ./...'`
```
--- PASS: TestFleetIndexingIsConfiguredAfterDeploy (0.00s)
--- PASS: TestFleetIndexingUpdateIsIdempotent (0.00s)
--- PASS: TestTheThingIndexBecomesReady (0.00s)
ok  github.com/Thiink-LLC/teos/go-services/devicesvc/deployment/service-test 68.547s   (deploy + undeploy by the harness)
```
Lint: golangci-lint with LINT_TAGS, and with LINT_TAGS+floci, on the service-test module gives 0 issues. go vet for e2e and for e2e,floci is clean. devicesvc has no lint-arch target.
