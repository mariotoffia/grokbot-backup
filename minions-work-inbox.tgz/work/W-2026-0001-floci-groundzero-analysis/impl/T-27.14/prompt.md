# Cloud-agent prompt — TEOS 27.14: test(devices): qualify local fleet indexing readiness

You are a Go engineer working in the GitHub repository **Thiink-LLC/teos**. This prompt is self-contained.

## Setup
- Base commit: `a3543337fecc19d11bcfe78157a9ef36731546c5` (main). Create branch **`chore/W-2026-0001-t27-14-fleet-indexing-readiness`** from it. Do not rebase onto newer main unless CI requires it.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`. They are authoritative.
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`. Errors before these finish mean "not bootstrapped", not "broken code". Build/test per module via make targets; `./...` does not work at the repo root.
- Floci image pin: test against `mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7` (index digest; amd64 sha256:5d596cb6e4fab671ae69426cfee0c6fc5241de907774db5759ff1d39e75b5561, arm64 sha256:356ab7fdb21f0dca9146d37e124064e9a3c55ecc996edac1e6865170d5ea98a3; pull it, then confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:9710d466`). If the digest differs, stop and write `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins.

## Goal
Qualify the devicesvc fleet-indexing lifecycle locally: UpdateIndexingConfiguration, GetIndexingConfiguration and index readiness through the existing devicesvc lifecycle path (CDK AwsCustomResource in deployment/stack_fleet_indexing.go and scripts/created/enable-fleet-indexing). Remove ONLY the fleet-indexing readiness guard/exclusion. Floci 9.4 (floci-io/floci#4896) is in the pinned image. Do NOT remove search, connectivity or reserved-event exclusions (those are 27.20 and later).

## Before you code
PRE-CHECK FINDING (dev-lead, a3543337): I could not find an explicit fleet-indexing readiness guard in go-services/devicesvc or deployment/lib/svctest by grep. First step: locate it (svctest local stubbing of Custom::AWS / AwsCustomResource, provision-config.local*, harness exclusions). If no guard exists, add the qualification test only and say so in the PR; if the guard lives outside the Owns globs (e.g. deployment/lib/svctest/**), stop and reply `ESCALATION: conflict` with the path before editing it.

## Files you may change
- `go-services/devicesvc/scripts/created/enable-fleet-indexing/**`
- `go-services/devicesvc/deployment/stack_fleet_indexing.go`
- `go-services/devicesvc/deployment/service-test/** (new fleet-indexing test file + provision-config.yaml only if needed)`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Service test (device-service, e2e,floci): after deploy, GetIndexingConfiguration returns thingIndexingMode REGISTRY_AND_SHADOW, namedShadowIndexingMode ON, connectivity STATUS, filter namedShadowNames [building] and both custom fields.
2. Service test: re-running the lifecycle step is idempotent (second UpdateIndexingConfiguration succeeds, config unchanged).
3. Service test: index readiness is observed (indexing status reported ready / config readable) without a fixed sleep.
4. The readiness guard that skipped/stubbed fleet indexing locally is removed; search/connectivity exclusions remain (grep shows them unchanged).
5. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=device-service make test-service`; evidence in impl/T-27.14/evidence.md.

## How to work
- **TDD**: write the failing test first, run it, see it fail for the right reason, then the minimal change, then green. Tests in `<package>_test` packages; reuse `go-core/utils/testutils`, `awstestutil`, `go-core/managers/**`.
- **Systematic debugging** on any failure: reproduce, read the full error, form one hypothesis, test it, fix root cause. No retries-until-green, no new skips, no weakened assertions.
- Code comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English everywhere (AGENTS.md banned-metaphor list applies).

## Gates (all must pass; paste commands + pass/fail into the PR description)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `CB_SERVICE_TEST=device-service make test-service`
Marker check: `rg -n "floci: Missing Implementation for" go-services/devicesvc/scripts/created/enable-fleet-indexing/** go-services/devicesvc/deployment/stack_fleet_indexing.go go-services/devicesvc/deployment/service-test/**`

## PR rules (GITHUB.md + DEVELOPMENT.md)
- Conventional commits, e.g. `test(devices): qualify local fleet indexing readiness`. **No byline / Co-Authored-By.** **No GitHub closing keywords** (fixes/closes/resolves #N) anywhere in commits or PR body.
- One PR for this task only, to `main`. Never push to main, never merge, never force-push a shared branch.
- CI is label-gated: add labels `build`, `unit-test`, `lint` (`gh pr create --label ...` or `cbtest pr set lint unit build`); an unlabeled PR runs nothing.
- PR body, written for an engineer who never opened the repo: what changed, why, what you did NOT do and why, image digest used, tests run vs skipped, marker grep output, gate results.
- GitHub API discipline: poll at most once per 5 minutes, never during coding/tests; serialize requests; on rate limit stop and wait for Retry-After/X-RateLimit-Reset. After each push request a Copilot review once (unless that commit already has one); later fix confirmed findings and give every finding a reasoned reply.
- No real-AWS runs (Floci-only scope). Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=device-service make test-service`; evidence in impl/T-27.14/evidence.md.

## Stop condition
Stop when the PR is open, all gates above are green locally, CI labels are set and the CI workflows you triggered are green (or still running — say which). Then reply with: PR URL, branch, head SHA, gate table, tests run vs skipped, image digest, marker grep.

## ESCALATION convention
If you cannot proceed, put one line at the top of the PR description (or your final reply if no PR) and stop:
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done.
Give details below that line. Do not work around the problem.
