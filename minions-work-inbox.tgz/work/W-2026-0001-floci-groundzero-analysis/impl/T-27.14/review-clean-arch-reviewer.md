# Clean Architecture review: P-2026-0001-17 (T-27.14)
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-14-fleet-indexing-readiness · Diff: a3543337..HEAD · HEAD = 1b5b316d (matches the packet; single commit) · Tree clean.

== Verdict ==
APPROVED

== Findings ==
- [Low] [testable] go-services/devicesvc/deployment/service-test/fleetindexing_test.go:28-31,49-56,141-146 — the expected indexing configuration (modes, the `building` filter, the custom fields) is now written out in three places: stack_fleet_indexing.go:49-53, scripts/created/enable-fleet-indexing/main.go:70, and this test. This is a drift risk, not a layering break, because these are separate modules (deployment, service-test and scripts) and sharing the values would add cross-module coupling. Fix: optional. Keep the duplication and give the test a comment that names stack_fleet_indexing.go as the source of truth, or leave it as is.
- [Low] [non-testable] go-services/devicesvc — devicesvc has no `.go-arch-lint.yml`, ARCHITECTURE.md or LINT.md of its own (it is not among the 10 maps in LINT.md), and `make lint-arch` is unavailable (W-2026-0003), so I checked the arch gate by hand against the direct-import map below. This gap is already there and the change does not cause it. Fix: none in this change.
- Out of scope: port or adapter shape goes to the hexagonal-reviewer minion and aggregates to the ddd-reviewer minion. The diff has neither.

Arch map (direct imports of the new file, package servicetest, `//go:build e2e` like every other file in service-test/):
- aws-sdk-go-v2/aws, service/iot, service/iot/types (service/iot v1.73.0 already in service-test/go.mod), testify, go-core/cbenv, go-core/ctx, go-core/interfaces/ifcore.
- Checks: the file is an outbound-facing service test in `<svc>/deployment/service-test/`, as TEOS_CONVENTIONS §I requires. It imports no devicesvc domain, application or handler package, so no inbound-to-outbound reach and no domain contamination. It makes no `.go-arch-lint.yml`, ADR, go.mod or provision-config.yaml change. It touches nothing outside the owns globs, and it leaves alone the 27.20 marker at go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go.

== Rationale ==
The diff adds one service-test file and nothing else. Its use of the AWS SDK is expected for a deployed-stack qualification test, and none of it reaches a domain or application layer. The test uses only the shared harness (harness.AWSConfig) and the go-core context, which matches how the sibling service tests are built. It adds no business logic: the test only reads, plus one idempotent update that copies the lifecycle step. No readiness guard existed before, so this change moves no logic between layers. The only note is the duplicated expected configuration, which is low risk and optional.

## Addendum (2026-10-22 13:06 Europe/Stockholm): real `make lint-arch`
- Root cause of "unavailable": go-arch-lint v1.17.0 is installed at ~/go/bin/go-arch-lint, but ~/go/bin is not on PATH in agent shells (login shells too), so `make lint-arch` fails with "make: go-arch-lint: No such file or directory" (Error 127). W-2026-0003 itself is a separate thing: no map covers go-core/* outside cbanalytics or devicesvc, and that is still true.
- Ran (PATH=$HOME/go/bin:$PATH): make install (rc=2: apt mirror deb.debian.org 500), make dep (rc=2: corepack cannot write /usr/local/share/corepack), make generate (rc=2: docker.sock permission denied, plus corepack; it deleted 45 tracked generated files under go-services/model/*api, which I restored with git checkout, tree clean). None of these failures affect lint-arch.
- `make lint-arch` at worktree HEAD 2d35f941 (now past the reviewed 1b5b316d; I did not re-review those commits): rc=0, "Architecture maps checked: 9" (9 Makefiles, 10 maps, every one "OK - No warnings found").
- Coverage: none of the 10 maps covers the package this change touches (go-services/devicesvc/deployment/service-test), so the pass confirms the repo-wide maps are not broken but does not check this diff. The hand-built import map stays the arch evidence. Verdict unchanged: APPROVED.
