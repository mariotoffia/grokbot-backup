> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.14 — test(devices): qualify local fleet indexing readiness

Work item: W-2026-0001 · Packet: P-2026-0001-07 (split) · Wave: W1 · Implementer: golang-pro (Cursor cloud agent) · Reviews: code-reviewer + test-designer
Repo: Thiink-LLC/teos · Base: `a3543337fecc19d11bcfe78157a9ef36731546c5` (origin/main, 2026-10-21 14:04 CEST) · Branch: `chore/W-2026-0001-t27-14-fleet-indexing-readiness`
Floci image: `mariotoffia/floci:latest` @ sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7

## Goal
Qualify the devicesvc fleet-indexing lifecycle locally: UpdateIndexingConfiguration, GetIndexingConfiguration and index readiness through the existing devicesvc lifecycle path (CDK AwsCustomResource in deployment/stack_fleet_indexing.go and scripts/created/enable-fleet-indexing). Remove ONLY the fleet-indexing readiness guard/exclusion. Floci 9.4 (floci-io/floci#4896) is in the pinned image. Do NOT remove search, connectivity or reserved-event exclusions (those are 27.20 and later).

## Pre-check note
PRE-CHECK FINDING (dev-lead, a3543337): I could not find an explicit fleet-indexing readiness guard in go-services/devicesvc or deployment/lib/svctest by grep. First step: locate it (svctest local stubbing of Custom::AWS / AwsCustomResource, provision-config.local*, harness exclusions). If no guard exists, add the qualification test only and say so in the PR; if the guard lives outside the Owns globs (e.g. deployment/lib/svctest/**), stop and reply `ESCALATION: conflict` with the path before editing it.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-services/devicesvc/scripts/created/enable-fleet-indexing/**`
- `go-services/devicesvc/deployment/stack_fleet_indexing.go`
- `go-services/devicesvc/deployment/service-test/** (new fleet-indexing test file + provision-config.yaml only if needed)`

## Acceptance criteria (as regression-test behaviour)
1. Service test (device-service, e2e,floci): after deploy, GetIndexingConfiguration returns thingIndexingMode REGISTRY_AND_SHADOW, namedShadowIndexingMode ON, connectivity STATUS, filter namedShadowNames [building] and both custom fields.
2. Service test: re-running the lifecycle step is idempotent (second UpdateIndexingConfiguration succeeds, config unchanged).
3. Service test: index readiness is observed (indexing status reported ready / config readable) without a fixed sleep.
4. The readiness guard that skipped/stubbed fleet indexing locally is removed; search/connectivity exclusions remain (grep shows them unchanged).
5. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=device-service make test-service`; evidence in impl/T-27.14/evidence.md.

## TEOS_CONVENTIONS checklist: §A (existing uService go-services/devicesvc; no new service)
- §0: `make dep` + `make generate` first in a fresh checkout; per-module builds (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English in PR and commits; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change.
- §I: integration tests use `integration` (+ `floci` for Floci-specific) build tags; service tests in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:9710d466). A local skip is not evidence.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `CB_SERVICE_TEST=device-service make test-service`

## Evidence a done reply needs
- Floci image digest used (`docker image inspect` / pull by digest) = sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7.
- Tests run vs skipped, per package (go test -v -count=1 output summary; skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-services/devicesvc/scripts/created/enable-fleet-indexing/** go-services/devicesvc/deployment/stack_fleet_indexing.go go-services/devicesvc/deployment/service-test/**` (expected: no hit for this task's marker).
- PR URL, head commit, internal reviews (code-reviewer, test-designer) passed, Copilot review requested on the latest commit, CI labels set and workflows green.
- Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=device-service make test-service`; evidence in impl/T-27.14/evidence.md.
