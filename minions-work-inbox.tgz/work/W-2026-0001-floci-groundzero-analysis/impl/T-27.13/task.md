# T-27.13 — fix(devices): handle absent thing type metadata

Work item: W-2026-0001 · Packet: P-2026-0001-07 (split) · Wave: W1 · Implementer: golang-pro (Cursor cloud agent) · Reviews: code-reviewer + test-designer
Repo: Thiink-LLC/teos · Base: `a3543337fecc19d11bcfe78157a9ef36731546c5` (origin/main, 2026-10-21 14:04 CEST) · Branch: `fix/W-2026-0001-t27-13-nil-safe-thing-type-metadata`
Floci image: `mariotoffia/floci:latest` @ sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7

## Goal
Make the AWS IoT device manager read thing-type metadata nil-safely: absent ThingTypeMetadata, absent DeprecationDate on a non-deprecated type, a normal type and a deprecated type. Also a real-AWS bug. No Floci dependency, no marker.

## Pre-check note
PRE-CHECK FINDING (dev-lead, a3543337): devicemanager_aws.go:374-378 already guards `res.ThingTypeMetadata != nil` and uses aws.ToTime for DeprecationDate, and TestGetDeviceTypeReadsEveryAnswerOfAWSIoT (devicemanager_aws_test.go:141) already has cases for non-deprecated without deprecationDate, deprecated, and name-only (no metadata). The task may already be done on main. First step: confirm. If every AC case is already covered and passes, make NO code change, open NO PR, and reply `ESCALATION: already-done` with the test names as evidence so the task can be ticked. Only if a gap exists (e.g. another unguarded read, or a missing explicit case) add the failing test first, then the fix.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-core/managers/mgriot/awsmgriot/devicemanager_aws.go`
- `go-core/managers/mgriot/awsmgriot/devicemanager_aws_test.go`

## Acceptance criteria (as regression-test behaviour)
1. Unit test (package awsmgriot_test): GetDeviceType with no thingTypeMetadata returns the type with zero Created/Deprecated/DeprecationDate and no panic.
2. Unit test: non-deprecated type whose metadata has no deprecationDate returns Deprecated=false and zero DeprecationDate.
3. Unit test: a normal type with creationDate returns Created set.
4. Unit test: a deprecated type returns Deprecated=true and its DeprecationDate.
5. Any other read of ThingTypeMetadata / DeprecationDate in go-core/managers/mgriot/** is nil-safe (grep and cover).

## TEOS_CONVENTIONS checklist: §C (go-core library change; existing package, no new library)
- §0: `make dep` + `make generate` first in a fresh checkout; per-module builds (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English in PR and commits; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change.
- §I: integration tests use `integration` (+ `floci` for Floci-specific) build tags; service tests in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:9710d466). A local skip is not evidence.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `make test-integration`

## Evidence a done reply needs
- Floci image digest used (`docker image inspect` / pull by digest) = sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7.
- Tests run vs skipped, per package (go test -v -count=1 output summary; skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-core/managers/mgriot/awsmgriot/devicemanager_aws.go go-core/managers/mgriot/awsmgriot/devicemanager_aws_test.go` (expected: no hit for this task's marker).
- PR URL, head commit, internal reviews (code-reviewer, test-designer) passed, Copilot review requested on the latest commit, CI labels set and workflows green.
- Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `make test-integration`; evidence in impl/T-27.13/evidence.md.
