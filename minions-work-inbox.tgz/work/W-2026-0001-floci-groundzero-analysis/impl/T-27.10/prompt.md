# Minion prompt — TEOS 27.10: test(collector): rely on real parameter change events

You are the golang-pro minion working in **Thiink-LLC/teos** on the shared computer. This prompt is self-contained; the packet's flow wins over anything here.

## Setup
- Worktree (already created by dev-lead): `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-10-real-ssm-change-events` on branch **`chore/W-2026-0001-t27-10-real-ssm-change-events`** from base `a3543337fecc19d11bcfe78157a9ef36731546c5`. Do not rebase onto newer main unless CI requires it.
- `.env` in the worktree is a symlink to the repo's gitignored `.env`. Never print, cat, copy, `git add` or commit it; never replace the symlink.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `SERVICE_TEST.md`, `SERVICE_TEST_WRITING.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`, and the local docs under `go-services/collectorsvc`. They are authoritative. Then `/workspace/minions/CONVENTIONS.md` (§0, §1, §A, §I) and `/workspace/minions/TEOS_CONVENTIONS.md` (§0, §1, §A, §I).
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`.
- Floci image pin: `mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7`. Confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:9710d466`; otherwise stop with `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins.

## Goal
Remove the synthetic SSM Parameter Store Change event from the collector service test. Floci now normalises the parameter ARN (15.1, floci-io/floci#5261) and emits `source: aws.ssm`, `detail-type: Parameter Store Change` on successful mutations (15.2, floci-io/floci#5262); both are merged on floci main and in the pinned image. Only a real PutParameter must drive the deployed EventBridge rule -> param-change queue -> rule-manager Lambda that creates the collector rule.

## Before you code
PRE-CHECK (dev-lead, a3543337): not done on main. injectSSMParameterChangeEvent is defined at go-services/collectorsvc/deployment/service-test/helpers_test.go:64-~95 (marker :73) and called only at e2e_collection_test.go:115-122 (marker :118, inside `if harness.Target().IsLocal()`); the package doc in main_test.go:15-20 also carries the marker and describes the injection. Note: the repo/inbox TEOS_GROUNDZERO_TASKS.md row still says '15.2 open'; ANALYSIS.md verified #5262 merged on floci main and W0 image is built from main 7c0d592b8+, so the dependency is met. If the real event does not reach the rule on the pinned image, reply ESCALATION: verify-failed with the event/queue evidence; do not re-add a synthetic event or sleeps.

## Files you may change
- `go-services/collectorsvc/deployment/service-test/helpers_test.go`
- `go-services/collectorsvc/deployment/service-test/e2e_collection_test.go`
- `go-services/collectorsvc/deployment/service-test/main_test.go (package doc + marker only)`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Service test (collector-service, local Floci on the pinned digest): after the test writes its registration parameter with PutParameter, the deployed rule manager creates the collector rule with no synthetic event; Phase 1 passes on the local target exactly as on AWS (polled with require.Eventually, no fixed sleep).
2. injectSSMParameterChangeEvent, its call in e2e_collection_test.go and all three `floci: Missing Implementation for SSM Parameter Store Change events.` markers (helpers_test.go:73, e2e_collection_test.go:118, main_test.go:20) are deleted; the main_test.go package doc describes the real path; unused imports (e.g. eventbridge client) removed only if no longer used.
3. rg -n 'injectSSMParameterChangeEvent|SSM Parameter Store Change events' over the repo returns no hit.
4. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=collector-service make test-service`; evidence in impl/T-27.10/evidence.md.

## How to work
- Architecture: every TEOS project is **DDD + hexagonal (ports & adapters) + clean architecture**. Keep test helpers in the service-test package, reuse svctest/testutils, do not pull adapters or SDK types into domain/ports.
- **TDD**: start from the test-designer's test plan (impl/T-27.10/test-plan.md); see the test fail for the right reason, make the minimal change, then green.
- **Systematic debugging** on any failure: reproduce, read the full error, one hypothesis at a time, fix the root cause. No retries-until-green, no new skips, no weakened assertions, no fixed sleeps.
- Comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English (AGENTS.md banned-metaphor list applies).

## Gates — CONVENTIONS.md §1 / TEOS_CONVENTIONS.md §1 (all must pass; commands + pass/fail in evidence.md)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint; lint-arch is unavailable, backlog W-2026-0003: interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=collector-service make test-service`
- Arch gate: `lint-arch` is unavailable (W-2026-0003). The arch gate is the standard linter plus hexagonal-reviewer and clean-arch-reviewer sign-off; the PR body must say so.
Marker check: `rg -n "floci: Missing Implementation for" go-services/collectorsvc/deployment/service-test/`

## Commit / PR rules
- Conventional commit titled like `test(collector): rely on real parameter change events`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets.
- Do NOT push and do NOT open the PR. dev-lead pushes and opens the draft PR (labels build, unit-test, lint) after the three internal reviews pass, then requests Copilot once per pushed commit. The PR body (dev-lead) records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest 9710d466); no real-AWS runs".

## Stop condition
Local commit(s) on `chore/W-2026-0001-t27-10-real-ssm-change-events`, all gates green, evidence in `/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.10/evidence.md`. Reply `done` to dev-lead in the ⟦MINION v1⟧ envelope.

## ESCALATION convention
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done. Details below that line. Do not work around the problem.
