# T-27.10 — Test Plan (Mode B) — test-designer minion

Packet: P-2026-0001-28 (re msg-W-2026-0001-063; doorbell msg-W-2026-0001-064 + correction msg-W-2026-0001-067 — the correction text was not found on disk under /workspace/minions; plan follows the packet YAML + task.md).
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-10-real-ssm-change-events (base a3543337, branch chore/W-2026-0001-t27-10-real-ssm-change-events). Lock: registry/locks.json task 27.10 (holder golang-pro; test-designer works as flow step 1, owns globs only).
Floci image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (pinned with TK_LOCAL_EMULATOR).
Scope: Floci-only per msg-W-2026-0001-dev-lead-090 — nothing is tested against or deployed to real AWS (devlocal included); all evidence comes from Floci image 9710d466 (mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7).

== Test Plan ==

| # | AC | Case | Type / tags | Seam | Data | Assertion | Why it fails before the change | Determinism notes |
|---|----|------|-------------|------|------|-----------|--------------------------------|-------------------|
| 1 | AC1 | `TestCollectorEndToEndFlow` (package `servicetest`, `go-services/collectorsvc/deployment/service-test/e2e_collection_test.go`) with no synthetic event | Service test, `e2e` + `floci` (local Floci target) | Real `ssm:PutParameter` (createSSMRegistration) -> Floci-emitted `aws.ssm`/`Parameter Store Change` -> collector EventBridge rule -> param-change SQS -> rule-manager Lambda -> collector rule | Registration param `/{env}/services/collector/registrations/{pn}/{pg}/{op}`, fake provider queue with ABAC policy, unique `svctest-<suffix>` location | Phase 3 `waitForEventBridgeRule(rulePrefix, 180s)` finds the rule (polled), Phases 4-5 pass on Floci | On base, local relies on `injectSSMParameterChangeEvent`; red edit removes the call (uncommitted) so only the real event can drive it. If Floci #5261/#5262 are in the image this case is GREEN at red time (flagged) — it is a removal task, the red signal is the static checks 2-3. | Polling only (no new sleeps); unique suffix per run; rule-manager dedups so at-least-once events are harmless. Needs docker + cdk + cbdeploy. |
| 2 | AC2 | Helper, call and 3 markers deleted; package doc describes the real path | Static | `rg -n "floci: Missing Implementation for SSM Parameter Store Change events" go-services/collectorsvc/deployment/service-test/` | Base: helpers_test.go:73, e2e_collection_test.go:118, main_test.go:20 | 0 hits; main_test.go doc no longer says the test publishes the event; `eventbridge` import kept (still used by `waitForEventBridgeRule`), `ebtypes`/`encoding/json` removed only if unused; `go vet -tags=e2e,floci` and `-tags=e2e` clean; golangci `unused` clean | 3 hits on base; after the red edit helper is unused (golangci `unused` would flag it — golang-pro deletes it) | Deterministic |
| 3 | AC3 | Repo-wide absence | Static | `rg -n 'injectSSMParameterChangeEvent\|SSM Parameter Store Change events' .` | — | No hit | Hits on base | Deterministic |

== Error-injection strategy ==
- None added; the synthetic event is exactly what must go. Failure to report, not mask: rule not found within 180 s on the pinned image -> ESCALATION verify-failed with evidence: SSM PutParameter response, EventBridge rule `collectorsvc-ssm-param-change` targets, param-change queue `ApproximateNumberOfMessages`/DLQ depth, rule-manager Lambda logs. Never re-add PutEvents or sleeps.

== Concurrency strategy ==
- Single test, own local environment; disjoint from 27.25/27.12/27.14 (separate modules, separate Floci containers). Unique registration path per run avoids cross-run rule collisions.

== Red run ==
See "Red run evidence" below (appended after the run).

== Red run evidence (2026-10-21 ~18:20 CEST, image 9710d466) ==
Red edit (uncommitted, owns glob only): e2e_collection_test.go lines 113-122 deleted (comment, marker, IsLocal-guarded injectSSMParameterChangeEvent call). Helper in helpers_test.go and main_test.go doc/marker left for golang-pro (AC2).
Command:
```
PATH=$HOME/go/bin:$(npm prefix -g)/bin:$PATH \
TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 \
CB_SERVICE_TEST=collector-service go test -tags=e2e,floci -count=1 -v -timeout 45m \
  -run '^TestCollectorEndToEndFlow$' ./...
```
Output (tail):
```
    e2e_collection_test.go:107: Created SSM registration: /devlocal/services/collector/registrations/svctestprovider/svctest/sv = {...}
    e2e_collection_test.go:177: Found EventBridge rule: collector-1min (state=ENABLED)
    e2e_collection_test.go:183: Phase 3 complete (1m2.194s)
    e2e_collection_test.go:223: Received ProviderEvent: provider=svctestprovider config_items=1
--- PASS: TestCollectorEndToEndFlow (124.77s)
ok  github.com/Thiink-LLC/teos/go-services/collectorsvc/deployment/service-test 194.750s
```
Result: PASS without the synthetic event (not red). FLAG: already passing on the pinned image — the real Parameter Store Change event drives the rule (fresh environment, so the rule did not pre-exist). Red signal for this removal task is static: AC2/AC3 rg still hits (helpers_test.go:73, main_test.go:20; injectSSMParameterChangeEvent still defined). Note for golang-pro: after deleting the helper, drop ebtypes/encoding/json imports only if unused; eventbridge client stays (ListRules). Full log: /workspace/redruns/t27-10.log.
