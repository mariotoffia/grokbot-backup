# T-27.10 evidence — golang-pro minion (P-2026-0001-29)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-10-real-ssm-change-events
Branch: chore/W-2026-0001-t27-10-real-ssm-change-events · Base a3543337
Commit: fe87f139353353f9afcb0a134d4b28359d429bc9 `test(collector): rely on real parameter change events` (local only, no push, no PR, no co-author trailer)
Floci image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7, pinned with TK_LOCAL_EMULATOR. The `latest` tag is not present locally.
Note: impl/T-27.10/test-plan.md did not exist on disk when this work started. The start followed dev-lead msg-073, which said both plans had landed.

## Change
- e2e_collection_test.go: removed the local-only synthetic event block, including its marker (adopted the test-designer deletion).
- helpers_test.go: removed the now-unused injectSSMParameterChangeEvent and its marker, and dropped the unused ebtypes import.
- main_test.go: the package doc now describes the real path (PutParameter emits the change event on both targets). The marker is removed.

## Gates
| Gate | Result |
|---|---|
| make fmt | PASS rc=0 |
| make lint | PASS rc=0. The first try failed with "parallel golangci-lint is running", a lock held by another worktree's run. The retry was clean. |
| make vet | PASS rc=0 |
| make test | PASS rc=0 |
| make tidy && git status | PASS, clean |
| CB_SERVICE_TEST=collector-service make test-service | PASS rc=0 |
| Arch gate | lint-arch is formally unavailable (W-2026-0003), so the gate is the standard linter plus sign-off from hexagonal-reviewer and clean-arch-reviewer (pending). The go-arch-lint passes inside make lint ran and passed. |

## Service test (collectorsvc, local): 1 PASS, 0 FAIL, 0 SKIP
TestCollectorEndToEndFlow: PASS (125.21s). The package took 198.3s. Phase 1 rule creation was driven only by the real PutParameter event.

## AC2/AC3: greps
- `rg -n "floci: Missing Implementation for" go-services/collectorsvc/deployment/service-test/` returns no hits.
- `rg -n 'injectSSMParameterChangeEvent|SSM Parameter Store Change events' .` (repo) returns no hits.

## git diff --stat a3543337..HEAD
```
 .../deployment/service-test/e2e_collection_test.go | 10 -------
 .../deployment/service-test/helpers_test.go        | 35 ----------------------
 .../deployment/service-test/main_test.go           | 14 ++++-----
 3 files changed, 6 insertions(+), 53 deletions(-)
```

## Open
AC4: the AWS run (`CB_SERVICE_TEST=collector-service make test-service-cloud`) by qa-lead via cto.
