# Clean Architecture review: P-2026-0001-32 (T-27.10, PR #1215)
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-10-real-ssm-change-events · Diff: a3543337..HEAD · HEAD = fe87f139 (matches; single commit) · Tree clean.

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] go-services/collectorsvc — collectorsvc has no `.go-arch-lint.yml` (it is not among the 10 maps in LINT.md), and `make lint-arch` is unavailable (W-2026-0003). I checked the arch gate by hand against the direct-import map below. This gap predates the change. Fix: none in this change.
- Out of scope: port and adapter shape (hexagonal-reviewer minion) and aggregates (ddd-reviewer minion). The diff has neither.

Test-only claim: confirmed. The diff touches three files, all in `deployment/service-test/` (`//go:build e2e`). It removes `injectSSMParameterChangeEvent` (helpers_test.go:63-96) and its local-only call site (e2e_collection_test.go:114-122), and rewrites the package doc in main_test.go:12-18 (the doc and the marker only, as the owns list allows). The result is 6 lines added and 53 removed. No production code changed.

Arch map (`go list -tags e2e,floci -f '{{.TestImports}}'` plus the diff): the only edge change is that `service/eventbridge/types` is gone. Nothing is added. The remaining go-core and deployment/lib/svctest edges were already there, and `eventbridge` and `ifcore` are still used, since `go vet -tags e2e,floci` is clean. The test imports no collectorsvc domain, application or handler package. The change makes no `.go-arch-lint.yml`, ADR or go.mod change, and stays inside the owns globs.

== Rationale ==
Taking out the test-side event injection removes a test double that stood in for the platform (EventBridge publishing directly). Now the deployed path, from the SSM write through the rule to the queue and the rule manager, is the only path on both targets. That makes the test more faithful to the architecture, not less. The change adds no dependency, logic or layer. Whether the pinned Floci really emits Parameter Store Change events is a question of marker-rule evidence for code-reviewer and qa-lead.

## Addendum (2026-10-22 13:06 Europe/Stockholm): real `make lint-arch`
- Root cause of "unavailable": go-arch-lint v1.17.0 is installed at ~/go/bin/go-arch-lint, but ~/go/bin is not on PATH in agent shells (login shells too), so `make lint-arch` fails with "make: go-arch-lint: No such file or directory" (Error 127). W-2026-0003 itself is a separate thing: no map covers go-core/* outside cbanalytics or devicesvc, and that is still true.
- Ran (PATH=$HOME/go/bin:$PATH): make install (rc=2: apt mirror deb.debian.org 500), make dep (rc=2: corepack cannot write /usr/local/share/corepack), make generate (rc=2: docker.sock permission denied, plus corepack; it deleted 45 tracked generated files under go-services/model/*api, which I restored with git checkout, tree clean). None of these failures affect lint-arch.
- `make lint-arch` at worktree HEAD fe87f139: rc=0, "Architecture maps checked: 9" (9 Makefiles, 10 maps, every one "OK - No warnings found").
- Coverage: none of the 10 maps covers the package this change touches (go-services/collectorsvc/deployment/service-test), so the pass confirms the repo-wide maps are not broken but does not check this diff. The hand-built import map stays the arch evidence. Verdict unchanged: APPROVED.
