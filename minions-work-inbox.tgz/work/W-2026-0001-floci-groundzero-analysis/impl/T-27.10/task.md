> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.10 — test(collector): rely on real parameter change events

Work item: W-2026-0001 · Packets: see waves.json (pulled into W1 by CTO decision msg-W-2026-0001-063, start immediately) · Implementer: golang-pro (minion, shared computer) · Tests: test-designer · Reviews: code-reviewer + hexagonal-reviewer + clean-arch-reviewer
Repo: Thiink-LLC/teos · Base: `a3543337fecc19d11bcfe78157a9ef36731546c5` (origin/main) · Branch: `chore/W-2026-0001-t27-10-real-ssm-change-events` · Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-10-real-ssm-change-events`
Floci image: `mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7`

## Goal
Remove the synthetic SSM Parameter Store Change event from the collector service test. Floci now normalises the parameter ARN (15.1, floci-io/floci#5261) and emits `source: aws.ssm`, `detail-type: Parameter Store Change` on successful mutations (15.2, floci-io/floci#5262); both are merged on floci main and in the pinned image. Only a real PutParameter must drive the deployed EventBridge rule -> param-change queue -> rule-manager Lambda that creates the collector rule.

## Pre-check note
PRE-CHECK (dev-lead, a3543337): not done on main. injectSSMParameterChangeEvent is defined at go-services/collectorsvc/deployment/service-test/helpers_test.go:64-~95 (marker :73) and called only at e2e_collection_test.go:115-122 (marker :118, inside `if harness.Target().IsLocal()`); the package doc in main_test.go:15-20 also carries the marker and describes the injection. Note: the repo/inbox TEOS_GROUNDZERO_TASKS.md row still says '15.2 open'; ANALYSIS.md verified #5262 merged on floci main and W0 image is built from main 7c0d592b8+, so the dependency is met. If the real event does not reach the rule on the pinned image, reply ESCALATION: verify-failed with the event/queue evidence; do not re-add a synthetic event or sleeps.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-services/collectorsvc/deployment/service-test/helpers_test.go`
- `go-services/collectorsvc/deployment/service-test/e2e_collection_test.go`
- `go-services/collectorsvc/deployment/service-test/main_test.go (package doc + marker only)`

## Acceptance criteria (as regression-test behaviour)
1. Service test (collector-service, local Floci on the pinned digest): after the test writes its registration parameter with PutParameter, the deployed rule manager creates the collector rule with no synthetic event; Phase 1 passes on the local target exactly as on AWS (polled with require.Eventually, no fixed sleep).
2. injectSSMParameterChangeEvent, its call in e2e_collection_test.go and all three `floci: Missing Implementation for SSM Parameter Store Change events.` markers (helpers_test.go:73, e2e_collection_test.go:118, main_test.go:20) are deleted; the main_test.go package doc describes the real path; unused imports (e.g. eventbridge client) removed only if no longer used.
3. rg -n 'injectSSMParameterChangeEvent|SSM Parameter Store Change events' over the repo returns no hit.
4. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=collector-service make test-service`; evidence in impl/T-27.10/evidence.md.

## TEOS_CONVENTIONS checklist: §A (existing uService go-services/collectorsvc; service-test change only, no new service) + §I
- CONVENTIONS.md §0/§1: DDD + hexagonal (ports & adapters) + clean architecture; dependencies point inward; no adapter/SDK leaks into domain or ports. Test-only change, but reviewers check the boundaries anyway.
- TEOS §0: `make dep` + `make generate` first in a fresh worktree; per-module make targets (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil + deployment/lib/svctest; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change; never hand-edit go.mod.
- §I: service tests live in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:9710d466). A local skip is not evidence.
- Secrets: `.env` in the worktree is a symlink to /workspace/repos/teos/.env (gitignored). Never print, cat, copy, `git add` or commit it; do not replace the symlink. No secrets in code, logs, commits or chat.
- Commits: conventional commits, **no byline / Co-Authored-By / AI co-author trailer**, no GitHub closing keywords.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint; lint-arch is unavailable, backlog W-2026-0003: interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=collector-service make test-service`
- Arch gate: `lint-arch` is unavailable (backlog W-2026-0003). Interim arch gate = the standard linter above **plus** hexagonal-reviewer and clean-arch-reviewer sign-off. The PR body must state this.

## Evidence a done reply needs
- Floci image digest used (`docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:9710d466`).
- Tests run vs skipped, per package (skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-services/collectorsvc/deployment/service-test/` (expected: no hit for this task's marker; other markers unchanged).
- `git diff --stat a3543337..HEAD` (owns-glob files only).
- Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=collector-service make test-service`; evidence in impl/T-27.10/evidence.md.

## Scheduling
No chain dependency; PARALLEL-OK with 27.12, 27.14 and 27.25 (disjoint modules).
