# Code review — PR #1244 (issue #1243, msg-218) @ f0c44aa2, Floci a31d6e08
Task folder: impl/msg-218, inferred from issue #1243's title "W-2026-0001 msg-218: …", the branch name msg218-public-names-fake-ip-skip, and the existing impl/msg-218/gates. Date: 2026-10-22 21:45 Europe/Stockholm.
df -h /: 20%. The GitHub head is f0c44aa2 and matches. Fresh merge-base 45ba749f; 2 files (+52/-1).
Background: dns-198-18.md. The sandbox egress proxy answers every name with 198.18.0.1, so public DNS cannot be observed.
== Verdict ==
CHANGES_REQUESTED, for a missing gate only. The code is approvable.
== Findings ==
- [High] [testable] No e2e,floci service-test log at f0c44aa2. The change edits the e2e TestThePublicNamesResolveToThisMachine, and the skip path has not been shown firing on the box. Fix: run the groundzero service test at f0c44aa2 and expect a SKIP naming 198.18.0.1, not a FAIL.
- [Low] [testable] deployment/stacks/groundzero/service-test/fake_ip_dns_test.go:19-26 and public_names_test.go:80: the skip fires if ANY answer is in the range. A mixed answer set (for example 127.0.0.1 plus 198.18.x) would skip rather than check the other answers. A real fake-IP resolver returns only fake answers. Fix: skip only when ALL answers are in 198.18.0.0/15, or still run the loopback check on non-fake answers.
- [Low] [non-testable] There is no way to force the strict check (for example in CI where real DNS is expected). Optional: add an env toggle to fail instead of skip. Not required.
- [Info] The CIDR check is exact and narrow: a /15 net.IPNet and Contains. Boundaries are tested: 198.17.255.255 and 198.20.0.0 return false; 198.19.255.255 and IPv4-mapped ::ffff:198.18.0.1 return true; loopback and garbage return false. It cannot catch loopback or the box IP, so a real resolver returning 127.0.0.1 or 172.30.x still runs the strict check, and real failures are not masked. The skip happens after NoError/NotEmpty, so NXDOMAIN and empty answers still fail.
- [Info] Skip message: it names the host, the fake address, the range, the cause (fake-IP resolver / sandbox egress proxy) and all answers. This is environmental, not a Floci gap, so no "floci: Missing Implementation"/FG marker applies. CONVENTIONS.md has no skip-marker rule for this case. The comment above the test documents the caveat beside the existing rebinding-router note. OK.
- [Info] The untagged unit test runs in make test (package ok, "(cached)"; cache is content-keyed, so acceptable).
== Gates (impl/msg-218/gates, stamped f0c44aa2) ==
fmt, vet, lint, lint-arch (no map covers groundzero/service-test; W-2026-0003 interim sign-off given), make test with env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL, and tidy: all rc=0. The service test is MISSING (High).
== Links ==
Closes #1243 is in closingIssuesReferences; #1243 is OPEN and matches. Copilot: 0 review threads.
== Correctness ==
The helper is pure, the ParseIP nil check is handled, the IPv6-mapped case is handled, and there are no build-tag surprises: the file is untagged, the package compiles without e2e, and fakeIPAnswer is used by the e2e file. Fine.
