# Test review — msg-218 (no T- task id; W-2026-0001), PR #1244 @ f0c44aa2, Closes #1243

== Verdict == CHANGES_REQUESTED (PROVISIONAL on evidence as well)

== Findings ==
[Major] [testable] deployment/stacks/groundzero/service-test/fake_ip_dns_test.go:25-32 + public_names_test.go:80-84 — The skip is broader than the box-DNS case. fakeIPAnswer returns a hit if ANY answer is in 198.18.0.0/15, and the unit test locks that in with "any answer in the range counts". An answer set like [198.18.0.1, 203.0.113.5] or [198.18.0.1, 127.0.0.1] therefore skips, so a genuinely wrong (non-loopback) IP next to a fake one is hidden. A fake-IP resolver answers only from the range. Fix: skip only when every answer is in the range (allFakeIP). Flip the mixed-answer unit case so it expects no skip, and add a case for a mixed fake plus wrong IP.
[Minor] [non-testable] deployment/stacks/groundzero/service-test/public_names_test.go:80-84 — The skip has no tracking marker. Other markers in this suite carry an FG-n / issue id, and this one names neither msg-218, #1243 nor a gap entry. Fix: add a "// env-gap: … (#1243 / W-2026-0001 msg-218)" marker and put the id in the Skipf text.
[Minor] [testable] deployment/stacks/groundzero/service-test/fake_ip_dns_test.go:34-50 — Coverage gaps in the unit test. There is no native-IPv6 answer in a multi-answer set (for example ["::1", "198.18.0.1"]), and nothing documents that IPv6 fake-IP resolvers (for example the IPv6 benchmarking range 2001:2::/48 or fd-prefixed fake ranges) are deliberately not detected. Fix: add a multi-answer IPv6 case and a comment saying IPv4-only is intentional.
[Major] [non-testable] impl/msg-218/gates — The unit test is not shown to have run. test-f0c44aa2.log shows only "ok …/groundzero/service-test (cached)", with no -v output and no TestTheFakeIPRangeIsTheBenchmarkingRange line. There is no groundzero Floci service-test log and no evidence.md. Needed: (1) a go test -count=1 -v -run TestTheFakeIPRangeIsTheBenchmarkingRange ./deployment/stacks/groundzero/service-test log at f0c44aa2 showing PASS; (2) gates/test-service-f0c44aa2.log (-tags=e2e,floci -race -v, image a31d6e08) showing TestThePublicNamesResolveToThisMachine SKIP with the 198.18.0.1 reason and package rc=0.
[Info] Good:
- Resolution failures and empty answers still fail, because the require.NoError and require.NotEmpty checks run before the skip.
- Answers outside the range still go through the loopback check.
- The Skipf reason is clear and lists every answer.
- The boundaries 198.17.255.255 (false), 198.18.0.0 (true), 198.19.255.255 (true) and 198.20.0.0 (false) are all tested, plus IPv4-mapped, ::1, loopback, an invalid address and nil.
- The unit test is pure and deterministic, with no live DNS and no clock.
- It has no build tag, so it runs in the plain suite.
- The test names follow the suite's style.
- "Closes #1243" is present.

== Rationale ==
The mechanism is right, and the CIDR edges are tested well. The any-answer rule, though, can hide exactly what the test exists to catch (a public name pointing at a wrong host) whenever a fake IP appears in the answer set. Narrow it to all-answers-in-range and add a tracking marker. Static gates are green (summary-f0c44aa2.txt, all rc=0 at f0c44aa2), but the unit test run and the service-test skip are not yet evidenced.
CI at f0c44aa2: Build, Unit Tests, Static Analysis and Architecture were SKIPPED. Bugbot and the Security Reviewer were NEUTRAL. No CodeQL check is listed.
