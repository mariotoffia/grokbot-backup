# Minion prompt — TEOS 27.25: test(eventsvc): run the log subscription test on Floci

You are the golang-pro minion working in **Thiink-LLC/teos** on the shared computer. This prompt is self-contained; the packet's flow wins over anything here.

## Setup
- Worktree (already created by dev-lead): `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-25-log-subscription-delivery` on branch **`chore/W-2026-0001-t27-25-log-subscription-delivery`** from base `a3543337fecc19d11bcfe78157a9ef36731546c5`. Do not rebase onto newer main unless CI requires it.
- `.env` in the worktree is a symlink to the repo's gitignored `.env`. Never print, cat, copy, `git add` or commit it; never replace the symlink.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `SERVICE_TEST.md`, `SERVICE_TEST_WRITING.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`, and the local docs under `go-services/eventsvc`. They are authoritative. Then `/workspace/minions/CONVENTIONS.md` (§0, §1, §A, §I) and `/workspace/minions/TEOS_CONVENTIONS.md` (§0, §1, §A, §I).
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`.
- Floci image pin: `mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7`. Confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:9710d466`; otherwise stop with `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins.

## Goal
Run TestLogEventsInASubscribedLogGroupBecomeEvidence on the local Floci target. Floci now delivers CloudWatch Logs subscription-filter matches to the destination Lambda (task 41.1, floci-io/floci#5021, merged 2026-10-05, in the pinned image built from floci main 7c0d592b8+). Delete the local skip and its marker; the test then subscribes the event service's log subscriber (eventsvc-clwsubscriber) to a log group of its own and waits for the log line to become evidence on the local target too. This is link 1/3 of the critical eventsvc chain (27.25 -> 27.16.6 -> 27.16.1); 27.16.6 starts only after this PR is merged.

## Before you code
PRE-CHECK (dev-lead, a3543337): not done on main. Marker + skip still at go-services/eventsvc/deployment/service-test/subscriber_test.go:41-44 (`if harness.Target().IsLocal() { // floci: Missing Implementation for CloudWatch Logs subscription delivery. t.Skip(...) }`). Only one site for this marker in the repo. Other markers in the same package (monitor_datapath_test.go:21 EventBridge retries/DLQ, provision-config.local.yaml:8 async Lambda retries) belong to 27.16.6 and MUST NOT be touched. If the un-skipped test fails on the pinned image, do not weaken it: reply ESCALATION: verify-failed with the full error (likely Floci-side delivery).

## Files you may change
- `go-services/eventsvc/deployment/service-test/subscriber_test.go`
- `go-services/eventsvc/deployment/service-test/*_helpers_test.go or helpers used only by subscriber_test.go (only if the un-skipped test needs a local-target fix; say why)`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Service test (event-service, local Floci on the pinned digest): TestLogEventsInASubscribedLogGroupBecomeEvidence runs (not skipped) and passes: the subscription filter delivers the PutLogEvents line to eventsvc-clwsubscriber and the datapoint becomes a record of the location's stream, polled with require.Eventually (no fixed sleep).
2. The local skip and the marker `// floci: Missing Implementation for CloudWatch Logs subscription delivery.` (subscriber_test.go:42) are deleted; nothing else in the test's assertions changes (no weakened assertions, at-least-once tolerance kept).
3. Other markers in go-services/eventsvc/deployment/service-test (EventBridge retries/DLQ, async Lambda retries in provision-config.local.yaml) are unchanged (rg output before/after identical except this marker).
4. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=event-service make test-service`; evidence in impl/T-27.25/evidence.md.

## How to work
- Architecture: every TEOS project is **DDD + hexagonal (ports & adapters) + clean architecture**. Keep test helpers in the service-test package, reuse svctest/testutils, do not pull adapters or SDK types into domain/ports.
- **TDD**: start from the test-designer's test plan (impl/T-27.25/test-plan.md); see the test fail for the right reason, make the minimal change, then green.
- **Systematic debugging** on any failure: reproduce, read the full error, one hypothesis at a time, fix the root cause. No retries-until-green, no new skips, no weakened assertions, no fixed sleeps.
- Comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English (AGENTS.md banned-metaphor list applies).

## Gates — CONVENTIONS.md §1 / TEOS_CONVENTIONS.md §1 (all must pass; commands + pass/fail in evidence.md)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint; lint-arch is unavailable, backlog W-2026-0003: interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=event-service make test-service`
- Arch gate: `lint-arch` is unavailable (W-2026-0003). The arch gate is the standard linter plus hexagonal-reviewer and clean-arch-reviewer sign-off; the PR body must say so.
Marker check: `rg -n "floci: Missing Implementation for" go-services/eventsvc/deployment/service-test/`

## Commit / PR rules
- Conventional commit titled like `test(eventsvc): run the log subscription test on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets.
- Do NOT push and do NOT open the PR. dev-lead pushes and opens the draft PR (labels build, unit-test, lint) after the three internal reviews pass, then requests Copilot once per pushed commit. The PR body (dev-lead) records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest 9710d466); no real-AWS runs".

## Stop condition
Local commit(s) on `chore/W-2026-0001-t27-25-log-subscription-delivery`, all gates green, evidence in `/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.25/evidence.md`. Reply `done` to dev-lead in the ⟦MINION v1⟧ envelope.

## ESCALATION convention
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done. Details below that line. Do not work around the problem.
