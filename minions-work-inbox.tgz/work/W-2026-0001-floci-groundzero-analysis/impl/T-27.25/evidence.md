# T-27.25 evidence — golang-pro minion (P-2026-0001-24)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-25-log-subscription-delivery
Branch: chore/W-2026-0001-t27-25-log-subscription-delivery · Base a3543337
Commit: 3b13732a6dabf7354e3005fbfa4810e9209ac732 `test(eventsvc): run the log subscription test on Floci` (local only, no push, no PR, no co-author trailer)
Floci image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7. The `latest` tag is not present locally; only the digest is. It was pinned with TK_LOCAL_EMULATOR=<that digest>, and the harness banner confirms it.

## Gates (env: PATH=~/.local/bin:~/go/bin:$PATH, run under `sg docker`)
| Gate | Result |
|---|---|
| make fmt | PASS rc=0 |
| make lint | PASS rc=0 (lint-go/golangci-lint, plus web lint; the go-arch-lint passes in the chain also ran and passed) |
| make vet | PASS rc=0 |
| make test | PASS rc=0 |
| make tidy && git status | PASS, clean (no go.mod/go.sum changes) |
| CB_SERVICE_TEST=event-service make test-service | PASS rc=0 |
| Arch gate | lint-arch is formally unavailable (W-2026-0003), so the gate is the standard linter plus sign-off from hexagonal-reviewer and clean-arch-reviewer (pending). |

The first test-service attempt panicked in cdk bootstrap because `cdk` (~/.local/bin) was not on PATH. That was an environment problem, not a code one. The re-run with the fixed PATH passed.

## Service test (eventsvc, local): 18 PASS, 0 FAIL, 0 SKIP
- TestLogEventsInASubscribedLogGroupBecomeEvidence: PASS (33.52s). Not skipped: the real subscription delivery worked.
- TestTheSubscriberTurnsALogsDeliveryIntoEvidence: PASS (33.44s).
- The other service-test packages had no tests for this selector (ok in about 0.1s).

## AC2/AC3: markers
`rg -n "floci: Missing Implementation for" go-services/eventsvc/deployment/service-test/`
```
provision-config.local.yaml:8:#     floci: Missing Implementation for asynchronous Lambda retries.
monitor_datapath_test.go:21:// floci: Missing Implementation for EventBridge target retries and dead-letter queues.
```
The subscriber_test.go marker is gone. The other 2 markers are unchanged.

## git diff --stat a3543337..HEAD
```
 go-services/eventsvc/deployment/service-test/subscriber_test.go | 4 ----
 1 file changed, 4 deletions(-)
```
Only the owns-glob file changed. Assertions are untouched.

## Open
AC4: the AWS run (`CB_SERVICE_TEST=event-service make test-service-cloud`) by qa-lead via cto. Not run here because this minion holds no credentials.
