# T-27.25 — Test Plan (Mode B) — test-designer minion

Packet: P-2026-0001-23 (re msg-W-2026-0001-063; doorbell msg-W-2026-0001-064 + correction msg-W-2026-0001-067 — the correction text was not found on disk under /workspace/minions; plan follows the packet YAML + task.md).
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-25-log-subscription-delivery (base a3543337, branch chore/W-2026-0001-t27-25-log-subscription-delivery). Lock: registry/locks.json task 27.25 (holder golang-pro; test-designer works as flow step 1, owns globs only).
Floci image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (pinned per run with TK_LOCAL_EMULATOR; the `latest` tag is not present locally, only the digest).
Scope: Floci-only per msg-W-2026-0001-dev-lead-090 — nothing is tested against or deployed to real AWS (devlocal included); all evidence comes from Floci image 9710d466 (mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7).

== Test Plan ==

| # | AC | Case | Type / tags | Seam | Data | Assertion | Why it fails before the change | Determinism notes |
|---|----|------|-------------|------|------|-----------|--------------------------------|-------------------|
| 1 | AC1 | `TestLogEventsInASubscribedLogGroupBecomeEvidence` (package `servicetest`, `go-services/eventsvc/deployment/service-test/subscriber_test.go`) runs on local target | Service test, `//go:build e2e` + `floci` tag (local Floci target) | Deployed stack via `deployment/lib/svctest` harness; CloudWatch Logs `PutSubscriptionFilter` -> Lambda `eventsvc-clwsubscriber` -> evidence writer queue -> location stream | Unique location `svctest-logs-<UnixNano>`, own log group `/svctest/clwsubscriber/<location>`, one TEOS datapoint log line (`datapointLogLine`) | Test is reported RUN/PASS, not SKIP; `waitForLocationRecords(..., 5m)` sees >=1 record (polled, no fixed sleep) | On base the `IsLocal()` guard calls `t.Skip` — test never runs locally. Red edit removes the guard (uncommitted). | Location per run -> isolation; at-least-once tolerated (>=1, not ==1); subscription retry loop (1 min, 5 s steps) covers permission propagation; no wall-clock asserts. Needs docker + cdk + cbdeploy, pinned image. |
| 2 | AC2 | Skip + marker removed, assertions untouched | Static check | `git diff a3543337 -- subscriber_test.go` | — | Diff is exactly the 4 deleted lines 41-44 (guard, marker, `t.Skip`, `}`); `waitForLocationRecords` call and at-least-once comment unchanged | Marker present on base | Pure diff, deterministic |
| 3 | AC3 | Other markers unchanged | Static check | `rg -n "floci: Missing Implementation for" go-services/eventsvc/deployment/service-test/` | Before: 3 hits (subscriber_test.go:42, provision-config.local.yaml:8, monitor_datapath_test.go:21) | After: exactly 2 hits, provision-config.local.yaml:8 and monitor_datapath_test.go:21, byte-identical | 3 hits on base | Deterministic |
| 5 | regression | `TestTheSubscriberTurnsALogsDeliveryIntoEvidence` (same file) still passes | Service test | Direct Lambda Invoke with synthetic logs payload | gzip+base64 logs delivery | exactly 1 record | Already passing on base (flagged: not red) | Unique location |

== Error-injection strategy ==
- No new injection: the real delivery path is the subject. Failure modes to report (not mask): (a) PutSubscriptionFilter refused after 1 min -> require.NoError message names the group; (b) delivery never arrives -> `waitForLocationRecords` timeout after 5 min. Either one on the pinned image = ESCALATION verify-failed (Floci-side), never weaken or re-skip.
- Evidence to capture on failure: Floci container logs for `logs`/`lambda` around PutLogEvents, and the Lambda's CloudWatch log group `/aws/lambda/eventsvc-clwsubscriber`.

== Concurrency strategy ==
- Test runs serially in its package (`-p 1` via harness); parallel collector-service run uses a separate local environment (own network/containers), so no shared state. Per-test location + statement id avoid collisions with retries/reruns. The 27.16.6 tests in the same package must not run until this merges (R12).

== Red run ==
See "Red run evidence" below (appended after the run).

== Red run evidence (2026-10-21 ~18:20 CEST, image 9710d466) ==
Red edit (uncommitted, owns glob only): subscriber_test.go lines 41-44 deleted (IsLocal guard, marker, t.Skip). Nothing else changed.
Command (from the service-test dir, docker group shell):
```
PATH=$HOME/go/bin:$(npm prefix -g)/bin:$PATH \
TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 \
CB_SERVICE_TEST=event-service go test -tags=e2e,floci -count=1 -v -timeout 45m \
  -run '^TestLogEventsInASubscribedLogGroupBecomeEvidence$' ./...
```
Output (tail):
```
[svctest] target=local: Floci mariotoffia/floci@sha256:9710d466... This run is not credentialed evidence.
=== RUN   TestLogEventsInASubscribedLogGroupBecomeEvidence
    subscriber_test.go:57: === Phase 2: one TEOS log line that reports a datapoint becomes a record of the location's stream ===
    subscriber_test.go:72: The stream holds 1 record(s); watermark published at its tail
--- PASS: TestLogEventsInASubscribedLogGroupBecomeEvidence (36.56s)
ok  github.com/Thiink-LLC/teos/go-services/eventsvc/deployment/service-test 109.974s
```
Result: PASS (not red). FLAG: on base the test is SKIPPED locally (guard at :41-44), so the "red" state is skip, not fail; once un-skipped it passes on the pinned image — Floci delivery works. This is a skip-removal task; the remaining gate is the AC3 marker grep. Full log: /workspace/redruns/t27-25.log.
First attempt (17:5x) died mid-deploy with no test output (process vanished, orphan containers removed by me); rerun above is the valid one.
