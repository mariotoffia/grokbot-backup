# Clean Architecture review: P-2026-0001-27 (T-27.25, PR #1214)
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-25-log-subscription-delivery · Diff: a3543337..HEAD · HEAD = 3b13732a (matches; single commit) · Tree clean.

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] go-services/eventsvc/deployment/service-test — no `.go-arch-lint.yml` covers deployment/service-test (only the evidencemonitor and evidencecollector maps exist), and `make lint-arch` is unavailable (W-2026-0003). I checked the arch gate by hand against the direct-import map below. Fix: none in this change.
- Out of scope: port and adapter shape (hexagonal-reviewer minion) and aggregates (ddd-reviewer minion). The diff has neither.

Test-only claim: confirmed. The diff is one file, `deployment/service-test/subscriber_test.go` (`//go:build e2e`, package servicetest), with 4 lines removed: the local-target `t.Skip` and its floci marker. No production code changed.

Arch map (`go list -tags e2e,floci -f '{{.TestImports}}'` plus the diff): the change adds no import and removes none. The package's existing edges (deployment/lib/svctest, go-core cbevent/cbanalytics/ctx/ifcore, evidencemonitor/infrastructure and its test utilities) were already there at a3543337 and are untouched. `go vet -tags e2e,floci` is clean. The change makes no `.go-arch-lint.yml`, ADR or go.mod change, and stays inside the owns glob (subscriber_test.go only).

== Rationale ==
Removing a skip guard from a service test cannot invert a dependency or contaminate a domain. The change adds no import, logic or layer. It touches only the owned file. Whether Floci really delivers subscription events (the marker rule) is a question of evidence for code-reviewer and qa-lead, not of architecture.

## Addendum (2026-10-22 13:06 Europe/Stockholm): real `make lint-arch`
- Root cause of "unavailable": go-arch-lint v1.17.0 is installed at ~/go/bin/go-arch-lint, but ~/go/bin is not on PATH in agent shells (login shells too), so `make lint-arch` fails with "make: go-arch-lint: No such file or directory" (Error 127). W-2026-0003 itself is a separate thing: no map covers go-core/* outside cbanalytics or devicesvc, and that is still true.
- Ran (PATH=$HOME/go/bin:$PATH): make install (rc=2: apt mirror deb.debian.org 500), make dep (rc=2: corepack cannot write /usr/local/share/corepack), make generate (rc=2: docker.sock permission denied, plus corepack; it deleted 45 tracked generated files under go-services/model/*api, which I restored with git checkout, tree clean). None of these failures affect lint-arch.
- `make lint-arch` at worktree HEAD 3b13732a: rc=0, "Architecture maps checked: 9" (9 Makefiles, 10 maps, every one "OK - No warnings found").
- Coverage: none of the 10 maps covers the package this change touches (go-services/eventsvc/deployment/service-test), so the pass confirms the repo-wide maps are not broken but does not check this diff. The hand-built import map stays the arch evidence. Verdict unchanged: APPROVED.
