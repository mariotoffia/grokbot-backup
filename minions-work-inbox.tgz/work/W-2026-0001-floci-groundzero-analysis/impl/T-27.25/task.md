> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.25 — test(eventsvc): run the log subscription test on Floci

Work item: W-2026-0001 · Packets: see waves.json (pulled into W1 by CTO decision msg-W-2026-0001-063, start immediately) · Implementer: golang-pro (minion, shared computer) · Tests: test-designer · Reviews: code-reviewer + hexagonal-reviewer + clean-arch-reviewer
Repo: Thiink-LLC/teos · Base: `a3543337fecc19d11bcfe78157a9ef36731546c5` (origin/main) · Branch: `chore/W-2026-0001-t27-25-log-subscription-delivery` · Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-25-log-subscription-delivery`
Floci image: `mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7`

## Goal
Run TestLogEventsInASubscribedLogGroupBecomeEvidence on the local Floci target. Floci now delivers CloudWatch Logs subscription-filter matches to the destination Lambda (task 41.1, floci-io/floci#5021, merged 2026-10-05, in the pinned image built from floci main 7c0d592b8+). Delete the local skip and its marker; the test then subscribes the event service's log subscriber (eventsvc-clwsubscriber) to a log group of its own and waits for the log line to become evidence on the local target too. This is link 1/3 of the critical eventsvc chain (27.25 -> 27.16.6 -> 27.16.1); 27.16.6 starts only after this PR is merged.

## Pre-check note
PRE-CHECK (dev-lead, a3543337): not done on main. Marker + skip still at go-services/eventsvc/deployment/service-test/subscriber_test.go:41-44 (`if harness.Target().IsLocal() { // floci: Missing Implementation for CloudWatch Logs subscription delivery. t.Skip(...) }`). Only one site for this marker in the repo. Other markers in the same package (monitor_datapath_test.go:21 EventBridge retries/DLQ, provision-config.local.yaml:8 async Lambda retries) belong to 27.16.6 and MUST NOT be touched. If the un-skipped test fails on the pinned image, do not weaken it: reply ESCALATION: verify-failed with the full error (likely Floci-side delivery).

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-services/eventsvc/deployment/service-test/subscriber_test.go`
- `go-services/eventsvc/deployment/service-test/*_helpers_test.go or helpers used only by subscriber_test.go (only if the un-skipped test needs a local-target fix; say why)`

## Acceptance criteria (as regression-test behaviour)
1. Service test (event-service, local Floci on the pinned digest): TestLogEventsInASubscribedLogGroupBecomeEvidence runs (not skipped) and passes: the subscription filter delivers the PutLogEvents line to eventsvc-clwsubscriber and the datapoint becomes a record of the location's stream, polled with require.Eventually (no fixed sleep).
2. The local skip and the marker `// floci: Missing Implementation for CloudWatch Logs subscription delivery.` (subscriber_test.go:42) are deleted; nothing else in the test's assertions changes (no weakened assertions, at-least-once tolerance kept).
3. Other markers in go-services/eventsvc/deployment/service-test (EventBridge retries/DLQ, async Lambda retries in provision-config.local.yaml) are unchanged (rg output before/after identical except this marker).
4. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=event-service make test-service`; evidence in impl/T-27.25/evidence.md.

## TEOS_CONVENTIONS checklist: §A (existing uService go-services/eventsvc; service-test change only, no new service) + §I
- CONVENTIONS.md §0/§1: DDD + hexagonal (ports & adapters) + clean architecture; dependencies point inward; no adapter/SDK leaks into domain or ports. Test-only change, but reviewers check the boundaries anyway.
- TEOS §0: `make dep` + `make generate` first in a fresh worktree; per-module make targets (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil + deployment/lib/svctest; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change; never hand-edit go.mod.
- §I: service tests live in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:9710d466). A local skip is not evidence.
- Secrets: `.env` in the worktree is a symlink to /workspace/repos/teos/.env (gitignored). Never print, cat, copy, `git add` or commit it; do not replace the symlink. No secrets in code, logs, commits or chat.
- Commits: conventional commits, **no byline / Co-Authored-By / AI co-author trailer**, no GitHub closing keywords.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint; lint-arch is unavailable, backlog W-2026-0003: interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=event-service make test-service`
- Arch gate: `lint-arch` is unavailable (backlog W-2026-0003). Interim arch gate = the standard linter above **plus** hexagonal-reviewer and clean-arch-reviewer sign-off. The PR body must state this.

## Evidence a done reply needs
- Floci image digest used (`docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:9710d466`).
- Tests run vs skipped, per package (skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-services/eventsvc/deployment/service-test/` (expected: no hit for this task's marker; other markers unchanged).
- `git diff --stat a3543337..HEAD` (owns-glob files only).
- Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `CB_SERVICE_TEST=event-service make test-service`; evidence in impl/T-27.25/evidence.md.

## Scheduling
Chain hint: 27.16.6 (retry/DLQ, same eventsvc service-test package) and then 27.16.1 are SERIAL after this PR merges; merge this one first from the daily ready-to-merge list (risk R12).
