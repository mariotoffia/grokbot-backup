Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.16.6 — test(eventsvc): run the retry and DLQ tests on Floci

Work item: W-2026-0001 · Packet: P-2026-0001-36 · Implementer: golang-pro (minion, shared computer) · Tests: test-designer · Reviews: code-reviewer + hexagonal-reviewer + clean-arch-reviewer
Repo: Thiink-LLC/teos · Base: current origin/main after the M1 merges (#1212-#1215); run `git fetch` first. The box's local origin/main ref (863b6019) predates those merges · Branch: `chore/W-2026-0001-t27-16-6-eventsvc-retry-dlq` · Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-6-eventsvc-retry-dlq`
Floci image: `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1`

## Goal
Run the event service monitor datapath retry/DLQ test on the local Floci target and remove the local provision override. Floci 21 (floci-io/floci#4733, Lambda async retries / Invoke Qualifier, merged 2026-10-01) and 29.6 (#4736, EventBridge target retry + DLQ, merged 2026-10-01) are in the pinned image. Delete the marker and skip at monitor_datapath_test.go:21 (EventBridge retries/DLQ) and the marker/override at provision-config.local.yaml:8 (async Lambda retries). Keep W-6 until the slow-turn retry runs with no synthetic invocation. Link 2/3 of the eventsvc chain (27.25 -> 27.16.6 -> 27.16.1); 27.25 is merged (#1214), 27.16.1 starts only after this PR merges.

## Pre-check note
Not re-checked by dev-lead on current main. Known from the sources: markers at go-services/eventsvc/deployment/service-test/monitor_datapath_test.go:21 and provision-config.local.yaml:8; 27.25's marker in subscriber_test.go is already gone (#1214). Re-read on fresh main; if gone, ESCALATION: already-done.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-services/eventsvc/deployment/service-test/monitor_datapath_test.go`
- `go-services/eventsvc/deployment/service-test/provision-config.local.yaml`

## Acceptance criteria (as regression-test behaviour)
1. **N/A (dev-lead msg-128: comment-only scope).** Service test (event-service, local Floci on the pinned digest): the test behind the skip at monitor_datapath_test.go:21 runs (not skipped) and passes: EventBridge target retry and DLQ, and async Lambda retries, happen in Floci, polled with require.Eventually (no fixed sleep).
2. **Amended (dev-lead msg-128):** the two markers are reworded to say no retry/DLQ test exists yet; the provision-config.local.yaml override is kept because the monitor tests still use it. Original text: The marker and skip at monitor_datapath_test.go:21 and the marker/local override at provision-config.local.yaml:8 are deleted; no assertion is weakened.
3. W-6 is kept until the slow-turn retry runs with no synthetic invocation; evidence states whether that is now the case.
4. **N/A (dev-lead msg-128: comment-only scope, no un-skipped test).** Floci-local gate: the un-skipped test passes locally on mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `CB_SERVICE_TEST=event-service make test-service`; evidence in impl/T-27.16.6/evidence.md.

## OPEN items (scope not settled in the sources)
- OPEN: 'W-6' is named in ANALYSIS.md without a definition in the sources; identify it in the package and record what it is in evidence.md. Removing it is out of scope unless the slow-turn retry provably runs with no synthetic invocation; then ESCALATION: need-input before removing.
- OPEN: what the provision-config.local.yaml:8 override sets is not stated; removing it may need the whole file gone or only the entry. Change the minimum and say why.
- OPEN: retry timing makes the test slow (delivery-plan W-RUN ≈ 70 min); do not shorten waits by weakening assertions.

## TEOS_CONVENTIONS checklist: §A (existing uService go-services/eventsvc; service-test change only, no new service) + §I
- CONVENTIONS.md §0/§1: DDD + hexagonal (ports & adapters) + clean architecture; dependencies point inward; no adapter/SDK leaks into domain or ports. Test-only change, but reviewers check the boundaries anyway.
- TEOS §0: `make dep` + `make generate` first in a fresh worktree; per-module make targets (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil + deployment/lib/svctest; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change; never hand-edit go.mod.
- §I: integration tests tagged integration (+floci); service tests live in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:a31d6e08). A local skip is not evidence. No real-AWS run.
- No §B, §D or §E: no third-party adapter, web app or CLI is touched.
- Secrets: `.env` in the worktree is a symlink to /workspace/repos/teos/.env (gitignored). Never print, cat, copy, `git add` or commit it; do not replace the symlink. No secrets in code, logs, commits or chat.
- Commits: conventional commits, **no byline / Co-Authored-By / AI co-author trailer**, no GitHub closing keywords.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint and lint-arch; lint-arch is unavailable for this package (backlog W-2026-0003; no lint-arch map covers it): interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=event-service make test-service`
- Arch gate: where no lint-arch map covers the package (backlog W-2026-0003), the interim arch gate is the standard linter **plus** hexagonal-reviewer and clean-arch-reviewer sign-off. The PR body must state this.

## Evidence a done reply needs
- Floci image digest used (`docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:a31d6e08`).
- Tests run vs skipped, per package (skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-services/eventsvc/deployment/service-test/`.
- `git diff --stat origin/main..HEAD` (owns-glob files only).
- Draft PR URL.

## Commit / PR rules
- Conventional commit titled like `test(eventsvc): run the retry and DLQ tests on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets, never print `.env`.
- At the **first commit**, golang-pro pushes the branch and opens a **draft** PR to main (title prefixed W-2026-0001, labels build, unit-test, lint; body links this task and STATUS.md, records the image digest). Keep pushing as work progresses. **No force-push, never merge, never push to main.**
- PR body records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable for this package (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest a31d6e08); no real-AWS runs".
- Mark ready only after the internal reviews pass; then Copilot review and green workflows. Mario merges.
