# T-27.16.6 test review: test-reviewer minion (msg-W-2026-0001-dev-lead-131)
PR: https://github.com/Thiink-LLC/teos/pull/1228. Head ba4a1f2ab33c7d351f74e38f667e7860ab8ad528 matches the given SHA ba4a1f2a. Draft. CI: CodeQL passed, and Build/Unit/Static/Architecture were SKIPPED.
Diff: comments only. monitor_datapath_test.go:21-22 and provision-config.local.yaml:8 were reworded. No test code changed.

## AC mapping
| AC | Mapped to | Status |
|---|---|---|
| 1 Retry/DLQ and async Lambda retry test runs and passes on Floci | none (no such test exists, per evidence facts 1-3) | MISSING |
| 2 Marker/skip and override deleted, no weakened assertion | Markers reworded, not deleted. There was no skip. The yaml "override" is live config and was rightly kept | PARTIAL (justified) |
| 3 W-6 kept, evidence says whether slow-turn retry runs without a synthetic invocation | evidence.md fact 4 (invokeProcessor, monitor_helpers_test.go:300-313) | MET |
| 4 Floci-local gate via CB_SERVICE_TEST=event-service make test-service | not run. `make test` was "running", and /tmp/t27166-test.log does not exist | MISSING |

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [High] [testable] go-services/eventsvc/deployment/service-test/monitor_datapath_test.go:21 — AC1 and AC4 map to no test. The brief (task.md) still requires a passing retry/DLQ test, and dev-lead's comment-only decision (msg-128) is recorded only in evidence.md. Fix: dev-lead amends task.md ACs to the comment-only scope (or rescopes the PR) and opens a follow-up task with a test-designer plan for an EventBridge target retry + DLQ + async Lambda retry service test, polled with require.Eventually. Re-review once that is done.
- [Medium] [non-testable] impl/T-27.16.6/evidence.md — evidence does not match HEAD for the gates: `make test` was still running, its log is missing, and CI skipped Build/Unit Tests. Fix: record `make test` rc and the event-service service-test result (or a statement that it was not run) for ba4a1f2a.
- [Low] [non-testable] monitor_datapath_test.go:18-22 — the new sentence repeats line 18 ("What a local run does not prove: EventBridge retry and dead-letter behaviour"). Fix: optionally merge the two into one statement.

== Rationale ==
The change is behaviour-neutral and accurate: no retry/DLQ test exists, and the yaml entry is live config, so rewording beats deleting under the marker rule. The gap itself is acceptable as an interim state, because it is now stated honestly and does not claim parity. It is not acceptable against the brief as written, because AC1 and AC4 have no test, so the rules force CHANGES_REQUESTED until the ACs are formally amended. No flakiness risk is introduced, because no test code changed. Gate evidence for HEAD is incomplete.
