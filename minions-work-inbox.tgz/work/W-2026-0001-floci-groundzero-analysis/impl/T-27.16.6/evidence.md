# T-27.16.6 evidence: golang-pro minion (P-2026-0001-36). BLOCKED (unclear-brief, scope change)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-6-eventsvc-retry-dlq
Branch: chore/W-2026-0001-t27-16-6-eventsvc-retry-dlq, on fresh origin/main db06a87b, which includes #1212-#1215. There are no commits and no PR.
Floci digest for the task: mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1. It was not run, because the task is blocked before any run.

## Facts read from the code on fresh main (go-services/eventsvc/deployment/service-test)
1. monitor_datapath_test.go:21 is a package-doc comment, `// floci: Missing Implementation for EventBridge target retries and dead-letter queues.`. Line 18 next to it says "What a local run does not prove: EventBridge retry and dead-letter behaviour, ...". There is **no t.Skip** behind this marker. TestMonitorRaisesAnAlarmFromOneEvidenceMessage already runs locally (newScenario skips only on AWS).
2. provision-config.local.yaml:8 is a **comment only**, under the bullet about `activationReady: true`. That bullet says a scheduled fire before activation fails and the emulator drops it. It is **not an override**: no key in the file sets retries. activationReady, sqsQueueUrl and the rest are needed by the monitor tests and must stay.
3. **No test in the package exercises EventBridge target retry, a DLQ, or async Lambda retries.** `rg -i "retr|dead.letter|DLQ"` over the package's *.go finds only the doc comment and runner_metrics_test.go:108 ("The processor answers a busy turn with success, so Lambda does not retry").
4. W-6, best match in the code: the tests drive the processor through a direct synchronous `Invoke` (monitor_helpers_test.go:300-313, invokeProcessor). That is the "synthetic invocation". Nothing triggers a slow-turn retry through EventBridge or async Lambda. **So W-6 still applies, and I kept it.**

## Why this is blocked
The acceptance needs "the test behind the skip ... runs and passes: EventBridge target retry and DLQ, and async Lambda retries, happen in Floci". No such test exists, and there is no skip to remove. Deleting only the two comments would claim the emulator matches AWS with no test that proves it, which breaks the marker rule ("a marker goes only when the un-skipped test passes"). Meeting the acceptance needs a **new** retry/DLQ service test. That is new scope: a failing EventBridge target, a DLQ assertion and an async-retry assertion. It probably also needs helpers outside the owns globs and a test plan from the test-designer minion. I did not start the 70-minute run.

## What it would take
Either of these options from dev-lead/test-designer:
- (a) A new test plan and packet for a retry/DLQ service test, with owns widened to the needed helper files.
- (b) A decision to reword the two comments only. That needs an explicit decision, because it changes no behaviour.

The lock in registry/locks.json is set to blocked. The worktree is kept and clean.

## Update 2026-10-22 12:55 CEST: dev-lead msg-128 picked option (b), comment-only
- monitor_datapath_test.go:21 marker reworded to: "No test covers EventBridge target retries or dead-letter queues yet, on either target."
- provision-config.local.yaml:8 marker reworded to: "No test covers asynchronous Lambda retries yet." The override is NOT dead (the monitor tests use activationReady, sqsQueueUrl and the rest), so it is kept.
- No retry or DLQ run and no new test. The 70-minute run was never started.
- Commit ba4a1f2a on chore/W-2026-0001-t27-16-6-eventsvc-retry-dlq. Draft PR https://github.com/Thiink-LLC/teos/pull/1228
- Gates: make fmt rc=0, make lint-go rc=0, make vet rc=0, make tidy rc=0 with a clean diff, `go vet -tags=e2e,floci` on the service-test module OK. `make test` is running (/tmp/t27166-test.log). lint-arch has no map for this package (W-2026-0003), so the interim arch gate is the reviewers.
