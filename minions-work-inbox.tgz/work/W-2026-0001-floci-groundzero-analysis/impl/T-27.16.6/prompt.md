Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# Minion prompt — TEOS 27.16.6: test(eventsvc): run the retry and DLQ tests on Floci

You are the golang-pro minion working in **Thiink-LLC/teos** on the shared computer. This prompt is self-contained; the packet (P-2026-0001-36) wins over anything here.

## Setup
- Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-6-eventsvc-retry-dlq` on branch **`chore/W-2026-0001-t27-16-6-eventsvc-retry-dlq`**, based on current origin/main after the M1 merges (#1212-#1215); run `git fetch` first. The box's local origin/main ref (863b6019) predates those merges. Not created yet: create it yourself under the go-approved start gate (packet start_gate), reserve the lock in registry/locks.json first.
- Symlink `.env` to the repo's gitignored `.env` as in the other W-2026-0001 worktrees. Never print, cat, copy, `git add` or commit it; never replace the symlink.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `SERVICE_TEST.md`, `SERVICE_TEST_WRITING.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`, and the local docs of the touched module. They are authoritative. Then `/workspace/minions/CONVENTIONS.md` (§0, §1, §A/§C, §I) and `/workspace/minions/TEOS_CONVENTIONS.md`.
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`.
- Floci image pin: `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1` (new mariotoffia/floci:latest with the Floci Task 48 fix). Confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:a31d6e08`; otherwise stop with `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins (they stay `:latest`).

## Goal
Run the event service monitor datapath retry/DLQ test on the local Floci target and remove the local provision override. Floci 21 (floci-io/floci#4733, Lambda async retries / Invoke Qualifier, merged 2026-10-01) and 29.6 (#4736, EventBridge target retry + DLQ, merged 2026-10-01) are in the pinned image. Delete the marker and skip at monitor_datapath_test.go:21 (EventBridge retries/DLQ) and the marker/override at provision-config.local.yaml:8 (async Lambda retries). Keep W-6 until the slow-turn retry runs with no synthetic invocation. Link 2/3 of the eventsvc chain (27.25 -> 27.16.6 -> 27.16.1); 27.25 is merged (#1214), 27.16.1 starts only after this PR merges.

## Before you code
Not re-checked by dev-lead on current main. Known from the sources: markers at go-services/eventsvc/deployment/service-test/monitor_datapath_test.go:21 and provision-config.local.yaml:8; 27.25's marker in subscriber_test.go is already gone (#1214). Re-read on fresh main; if gone, ESCALATION: already-done.

## Files you may change
- `go-services/eventsvc/deployment/service-test/monitor_datapath_test.go`
- `go-services/eventsvc/deployment/service-test/provision-config.local.yaml`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Service test (event-service, local Floci on the pinned digest): the test behind the skip at monitor_datapath_test.go:21 runs (not skipped) and passes: EventBridge target retry and DLQ, and async Lambda retries, happen in Floci, polled with require.Eventually (no fixed sleep).
2. The marker and skip at monitor_datapath_test.go:21 and the marker/local override at provision-config.local.yaml:8 are deleted; no assertion is weakened.
3. W-6 is kept until the slow-turn retry runs with no synthetic invocation; evidence states whether that is now the case.
4. Floci-local gate: the un-skipped test passes locally on mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `CB_SERVICE_TEST=event-service make test-service`; evidence in impl/T-27.16.6/evidence.md.

## OPEN items
- OPEN: 'W-6' is named in ANALYSIS.md without a definition in the sources; identify it in the package and record what it is in evidence.md. Removing it is out of scope unless the slow-turn retry provably runs with no synthetic invocation; then ESCALATION: need-input before removing.
- OPEN: what the provision-config.local.yaml:8 override sets is not stated; removing it may need the whole file gone or only the entry. Change the minimum and say why.
- OPEN: retry timing makes the test slow (delivery-plan W-RUN ≈ 70 min); do not shorten waits by weakening assertions.

## How to work
- Architecture: every TEOS project is **DDD + hexagonal (ports & adapters) + clean architecture**. Keep test helpers in the test package, reuse testutils/svctest, do not pull adapters or SDK types into domain/ports.
- **TDD**: start from the test-designer's test plan (impl/T-27.16.6/test-plan.md) when present; see the test fail for the right reason, make the minimal change, then green.
- **Systematic debugging** on any failure: reproduce, read the full error, one hypothesis at a time, fix the root cause. No retries-until-green, no new skips, no weakened assertions, no fixed sleeps. If the un-skipped test fails on the pinned image, reply `ESCALATION: verify-failed` with the full error.
- Comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English.

## Gates — CONVENTIONS.md §1 / TEOS_CONVENTIONS.md §1 (all must pass; commands + pass/fail in evidence.md)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint and lint-arch; lint-arch is unavailable for this package (backlog W-2026-0003; no lint-arch map covers it): interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=event-service make test-service`
Marker check: `rg -n "floci: Missing Implementation for" go-services/eventsvc/deployment/service-test/`

## Commit / PR rules
- Conventional commit titled like `test(eventsvc): run the retry and DLQ tests on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets, never print `.env`.
- At the **first commit**, golang-pro pushes the branch and opens a **draft** PR to main (title prefixed W-2026-0001, labels build, unit-test, lint; body links this task and STATUS.md, records the image digest). Keep pushing as work progresses. **No force-push, never merge, never push to main.**
- PR body records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable for this package (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest a31d6e08); no real-AWS runs".
- Mark ready only after the internal reviews pass; then Copilot review and green workflows. Mario merges.

## Stop condition
Commit(s) pushed to `chore/W-2026-0001-t27-16-6-eventsvc-retry-dlq`, draft PR open, all gates green, evidence in `/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.6/evidence.md`. Reply `done` to dev-lead in the ⟦MINION v1⟧ envelope.

## ESCALATION convention
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done. Details below that line. Do not work around the problem.
