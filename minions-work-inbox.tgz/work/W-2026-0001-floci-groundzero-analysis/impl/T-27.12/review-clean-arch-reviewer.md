# Clean Architecture review: P-2026-0001-12 (T-27.12)
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-12-ecr-port-range · Diff: a3543337..HEAD · HEAD = 3bcced77 (matches the packet; commits 70e02e85, 3bcced77) · Tree clean.

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] go-core/utils/testutils/flocilocal (whole package) — no `.go-arch-lint.yml` covers go-core/utils/testutils (LINT.md §go-arch-lint lists 10 maps, and this is not one of them), and `make lint-arch` is unavailable (W-2026-0003), so I checked the arch gate by hand against a direct-import map (below) and did not rely on tooling. Fix: none in this change. If go-core/utils/testutils should be enforced, add a map with an ADR as a separate item.
- Out of scope: the shape of the emulator driver and its options as a port or adapter goes to the hexagonal-reviewer minion. There are no aggregates or domain types (ddd-reviewer minion: n/a).

Arch map (direct imports, `go list -f '{{.ImportPath}} {{.Imports}}'` + the diff):
- flocilocal (non-test): this change adds no import edge. It drops `strconv` from container_args.go. flocilocal.go keeps ifcore, httputil, testutils, dockerexec (dockerexec still in use) and adds no new edge.
- flocilocal_test (new integration_ecr_registry_test.go): flocilocal, testenv, aws-sdk-go-v2/aws/signer/v4 and testify. These are all test-only, inside go-core, and the signer is already in go-core/go.mod (no go.mod or go.sum change).
- options_internal_test.go: no new imports.
- Checks: the change touches no domain, application or adapter layer (this is a test-utility library, so having the AWS SDK here is fine and none of it reaches a domain). It adds no cross-module coupling, makes no `.go-arch-lint.yml`, ADR, go.mod or consts.go change, and stays inside the owns globs (container_args.go, flocilocal.go, options_internal_test.go, integration_ecr_registry_test.go).

== Rationale ==
The change takes logic out (the driver-side registry port pinning and the RegistryPort field) and leaves port choice to Floci. That keeps the emulator's own behaviour inside the emulator, not in the driver. No dependency goes the wrong way and no layer is contaminated: the package is a test utility with no domain, and this change adds no import edge in production code. The new test imports only same-module test helpers and an SDK signer that the module already depends on. The files touched match the packet's owns list exactly. I built and checked the import map by hand in place of lint-arch, and found no violations.

## Addendum (2026-10-22 13:06 Europe/Stockholm): real `make lint-arch`
- Root cause of "unavailable": go-arch-lint v1.17.0 is installed at ~/go/bin/go-arch-lint, but ~/go/bin is not on PATH in agent shells (login shells too), so `make lint-arch` fails with "make: go-arch-lint: No such file or directory" (Error 127). W-2026-0003 itself is a separate thing: no map covers go-core/* outside cbanalytics or devicesvc, and that is still true.
- Ran (PATH=$HOME/go/bin:$PATH): make install (rc=2: apt mirror deb.debian.org 500), make dep (rc=2: corepack cannot write /usr/local/share/corepack), make generate (rc=2: docker.sock permission denied, plus corepack; it deleted 45 tracked generated files under go-services/model/*api, which I restored with git checkout, tree clean). None of these failures affect lint-arch.
- `make lint-arch` at worktree HEAD 548dd964 (now 2 commits past the reviewed 3bcced77; I did not re-review those commits): rc=0, "Architecture maps checked: 9" (9 Makefiles, 10 maps, every one "OK - No warnings found").
- Coverage: none of the 10 maps covers the package this change touches (go-core/utils/testutils/flocilocal), so the pass confirms the repo-wide maps are not broken but does not check this diff. The hand-built import map stays the arch evidence. Verdict unchanged: APPROVED.
