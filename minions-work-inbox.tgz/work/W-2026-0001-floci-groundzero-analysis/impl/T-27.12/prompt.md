# Cloud-agent prompt — TEOS 27.12: fix(local): use the qualified ECR port range

You are a Go engineer working in the GitHub repository **Thiink-LLC/teos**. This prompt is self-contained.

## Setup
- Base commit: `a3543337fecc19d11bcfe78157a9ef36731546c5` (main). Create branch **`fix/W-2026-0001-t27-12-ecr-port-range`** from it. Do not rebase onto newer main unless CI requires it.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`. They are authoritative.
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`. Errors before these finish mean "not bootstrapped", not "broken code". Build/test per module via make targets; `./...` does not work at the repo root.
- Floci image pin: test against `mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7` (index digest; amd64 sha256:5d596cb6e4fab671ae69426cfee0c6fc5241de907774db5759ff1d39e75b5561, arm64 sha256:356ab7fdb21f0dca9146d37e124064e9a3c55ecc996edac1e6865170d5ea98a3; pull it, then confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:9710d466`). If the digest differs, stop and write `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins.

## Goal
Remove the ECR single-port-range workaround in the Floci local driver (each run pins FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT == MAX_PORT to one pre-allocated host port). Floci now retries registry port binds on conflict (floci-io/floci#4857, task 18, in the pinned image). Prove that two scoped emulators started concurrently both start their ECR registries, are reachable and clean up, without the override.

## Before you code
DefaultImage pin in consts.go must stay mariotoffia/floci:latest (do not edit consts.go). Run the integration test against the image pinned by digest.

## Files you may change
- `go-core/utils/testutils/flocilocal/flocilocal.go`
- `go-core/utils/testutils/flocilocal/container_args.go`
- `go-core/utils/testutils/flocilocal/options.go`
- `go-core/utils/testutils/flocilocal/options_internal_test.go`
- `go-core/utils/testutils/flocilocal/integration_*_test.go (new or edited ECR/registry concurrency test only)`
- `go-core/utils/testutils/flocilocal/doc.go (only if it documents the override)`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Integration test (tags integration,floci): two flocilocal instances with Docker socket mounted start concurrently; both ECR registries come up, an image push/pull or registry health call succeeds on each, and both shut down with no leftover containers.
2. Unit test: containerEnv() no longer sets FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT/MAX_PORT to a single port (TestAssignPortsGivesEachRunItsOwnRegistryPortWhenFlociMayLaunchContainers updated or replaced to assert the new behaviour).
3. The marker `// floci: Missing Implementation for ECR registry port retry on a bind conflict.` (flocilocal.go:246) and the code under it are deleted; nothing else.
4. RegistryPort field: removed only if no caller outside the package uses it (grep the whole repo); otherwise keep it and say why in the PR.

## How to work
- **TDD**: write the failing test first, run it, see it fail for the right reason, then the minimal change, then green. Tests in `<package>_test` packages; reuse `go-core/utils/testutils`, `awstestutil`, `go-core/managers/**`.
- **Systematic debugging** on any failure: reproduce, read the full error, form one hypothesis, test it, fix root cause. No retries-until-green, no new skips, no weakened assertions.
- Code comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English everywhere (AGENTS.md banned-metaphor list applies).

## Gates (all must pass; paste commands + pass/fail into the PR description)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `make test-integration`
Marker check: `rg -n "floci: Missing Implementation for" go-core/utils/testutils/flocilocal/flocilocal.go go-core/utils/testutils/flocilocal/container_args.go go-core/utils/testutils/flocilocal/options.go go-core/utils/testutils/flocilocal/options_internal_test.go go-core/utils/testutils/flocilocal/integration_*_test.go go-core/utils/testutils/flocilocal/doc.go`

## PR rules (GITHUB.md + DEVELOPMENT.md)
- Conventional commits, e.g. `fix(local): use the qualified ECR port range`. **No byline / Co-Authored-By.** **No GitHub closing keywords** (fixes/closes/resolves #N) anywhere in commits or PR body.
- One PR for this task only, to `main`. Never push to main, never merge, never force-push a shared branch.
- CI is label-gated: add labels `build`, `unit-test`, `lint` (`gh pr create --label ...` or `cbtest pr set lint unit build`); an unlabeled PR runs nothing.
- PR body, written for an engineer who never opened the repo: what changed, why, what you did NOT do and why, image digest used, tests run vs skipped, marker grep output, gate results.
- GitHub API discipline: poll at most once per 5 minutes, never during coding/tests; serialize requests; on rate limit stop and wait for Retry-After/X-RateLimit-Reset. After each push request a Copilot review once (unless that commit already has one); later fix confirmed findings and give every finding a reasoned reply.
- No real-AWS runs (Floci-only scope). Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `make test-integration`; evidence in impl/T-27.12/evidence.md.

## Stop condition
Stop when the PR is open, all gates above are green locally, CI labels are set and the CI workflows you triggered are green (or still running — say which). Then reply with: PR URL, branch, head SHA, gate table, tests run vs skipped, image digest, marker grep.

## ESCALATION convention
If you cannot proceed, put one line at the top of the PR description (or your final reply if no PR) and stop:
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done.
Give details below that line. Do not work around the problem.
