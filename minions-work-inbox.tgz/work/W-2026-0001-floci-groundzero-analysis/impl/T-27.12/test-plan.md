# T-27.12 test plan (test-designer minion, packet P-2026-0001-08)
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-12-ecr-port-range (base a3543337, uncommitted). Image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (TK_LOCAL_EMULATOR).

== Test Plan ==
| AC | Case | Type / tags | Package, file | Seam | Assertion | Why red before the change |
|---|---|---|---|---|---|---|
| 1 | TestTwoEmulatorsStartedTogetherEachGetAWorkingECRRegistry | integration (untagged file, skips under -short like the rest of the package) | flocilocal_test, integration_ecr_registry_test.go (new) | two flocilocal.Local with WithDockerSocket + distinct WithResourceNamespace, started concurrently; ECR CreateRepository via SigV4-signed JSON call (no ECR SDK in go-core, so no go.mod change); docker port of floci-aws-<ns>-ecr-registry | container env has no FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT/MAX_PORT; each registry GET /v2/ = 200; the two host ports differ; after RemoveLaunchedContainers + Close no registry/emulator container is left | the driver still pins BASE_PORT == MAX_PORT |
| 2 | TestTheEmulatorChoosesItsOwnRegistryPortWhenFlociMayLaunchContainers (replaces TestAssignPortsGivesEachRunItsOwnRegistryPortWhenFlociMayLaunchContainers) | unit | flocilocal (internal), options_internal_test.go | assignPorts + containerEnv | with services network: no BASE/MAX port env; KEEP_RUNNING_ON_SHUTDOWN stays "false"; without socket: none of them | containerEnv sets BASE/MAX to RegistryPort |
| 3 | marker grep (gate, not a Go test) | - | flocilocal.go | rg "floci: Missing Implementation for" | no hit | marker at flocilocal.go:246 |
| 4 | RegistryPort usage | grep | whole repo | git grep "RegistryPort" -- '*.go' outside flocilocal | 0 hits on base, so the field may be removed | - |

Notes for golang-pro:
- KEEP_RUNNING_ON_SHUTDOWN=false is currently set only inside "if l.RegistryPort > 0". Keep it whenever shouldMountDockerSocket() is true, or the unit test fails.
- Cleanup contract: Close() alone does not remove Floci's registry container (seen on base: "network ... has active endpoints"). The test calls RemoveLaunchedContainers(namespace) first, as the harness does. Changing Close is out of scope.
- Determinism: free ports from the driver, unique names via uniqueName, polling with require.Eventually (60 s cap), no fixed sleeps.

== Red run (2026-10-21, Europe/Stockholm) ==
Unit: `cd go-core/utils/testutils/flocilocal && go test -short -count=1 -run TestTheEmulatorChoosesItsOwnRegistryPort ./`
```
--- FAIL: TestTheEmulatorChoosesItsOwnRegistryPortWhenFlociMayLaunchContainers
options_internal_test.go:340: map[... "FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT":"35675", "FLOCI_SERVICES_ECR_REGISTRY_MAX_PORT":"35675"] should not contain "FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT"
options_internal_test.go:341: ... should not contain "FLOCI_SERVICES_ECR_REGISTRY_MAX_PORT"
```
Integration: `sg docker -c 'TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 go test -count=1 -v -run TestTwoEmulatorsStartedTogetherEachGetAWorkingECRRegistry ./'`
```
integration_ecr_registry_test.go:66: "...FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT=46181\nFLOCI_SERVICES_ECR_REGISTRY_MAX_PORT=46181..." should not contain "FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT"
integration_ecr_registry_test.go:68: ... should not contain "FLOCI_SERVICES_ECR_REGISTRY_MAX_PORT"   (same for the second emulator)
--- FAIL: TestTwoEmulatorsStartedTogetherEachGetAWorkingECRRegistry (6.58s)
```
Only the env assertions fail; registry health, distinct ports and cleanup already pass on base. No leftover containers after the run.
Lint: golangci-lint (no tags, and LINT_TAGS) on ./go-core/utils/testutils/flocilocal/... -> 0 issues. gofmt clean, go vet clean. go-core has no lint-arch target (arch maps exist only for some modules), so arch-lint is n/a here.
