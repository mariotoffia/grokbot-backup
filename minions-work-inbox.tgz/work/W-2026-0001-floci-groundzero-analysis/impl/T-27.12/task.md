> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.12 — fix(local): use the qualified ECR port range

Work item: W-2026-0001 · Packet: P-2026-0001-07 (split) · Wave: W1 · Implementer: golang-pro (Cursor cloud agent) · Reviews: code-reviewer + test-designer
Repo: Thiink-LLC/teos · Base: `a3543337fecc19d11bcfe78157a9ef36731546c5` (origin/main, 2026-10-21 14:04 CEST) · Branch: `fix/W-2026-0001-t27-12-ecr-port-range`
Floci image: `mariotoffia/floci:latest` @ sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7

## Goal
Remove the ECR single-port-range workaround in the Floci local driver (each run pins FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT == MAX_PORT to one pre-allocated host port). Floci now retries registry port binds on conflict (floci-io/floci#4857, task 18, in the pinned image). Prove that two scoped emulators started concurrently both start their ECR registries, are reachable and clean up, without the override.

## Pre-check note
DefaultImage pin in consts.go must stay mariotoffia/floci:latest (do not edit consts.go). Run the integration test against the image pinned by digest.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-core/utils/testutils/flocilocal/flocilocal.go`
- `go-core/utils/testutils/flocilocal/container_args.go`
- `go-core/utils/testutils/flocilocal/options.go`
- `go-core/utils/testutils/flocilocal/options_internal_test.go`
- `go-core/utils/testutils/flocilocal/integration_*_test.go (new or edited ECR/registry concurrency test only)`
- `go-core/utils/testutils/flocilocal/doc.go (only if it documents the override)`

## Acceptance criteria (as regression-test behaviour)
1. Integration test (tags integration,floci): two flocilocal instances with Docker socket mounted start concurrently; both ECR registries come up, an image push/pull or registry health call succeeds on each, and both shut down with no leftover containers.
2. Unit test: containerEnv() no longer sets FLOCI_SERVICES_ECR_REGISTRY_BASE_PORT/MAX_PORT to a single port (TestAssignPortsGivesEachRunItsOwnRegistryPortWhenFlociMayLaunchContainers updated or replaced to assert the new behaviour).
3. The marker `// floci: Missing Implementation for ECR registry port retry on a bind conflict.` (flocilocal.go:246) and the code under it are deleted; nothing else.
4. RegistryPort field: removed only if no caller outside the package uses it (grep the whole repo); otherwise keep it and say why in the PR.

## TEOS_CONVENTIONS checklist: §C (go-core test-utility library go-core/utils/testutils/flocilocal)
- §0: `make dep` + `make generate` first in a fresh checkout; per-module builds (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English in PR and commits; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change.
- §I: integration tests use `integration` (+ `floci` for Floci-specific) build tags; service tests in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:9710d466). A local skip is not evidence.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `make test-integration`

## Evidence a done reply needs
- Floci image digest used (`docker image inspect` / pull by digest) = sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7.
- Tests run vs skipped, per package (go test -v -count=1 output summary; skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-core/utils/testutils/flocilocal/flocilocal.go go-core/utils/testutils/flocilocal/container_args.go go-core/utils/testutils/flocilocal/options.go go-core/utils/testutils/flocilocal/options_internal_test.go go-core/utils/testutils/flocilocal/integration_*_test.go go-core/utils/testutils/flocilocal/doc.go` (expected: no hit for this task's marker).
- PR URL, head commit, internal reviews (code-reviewer, test-designer) passed, Copilot review requested on the latest commit, CI labels set and workflows green.
- Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 via `make test-integration`; evidence in impl/T-27.12/evidence.md.
