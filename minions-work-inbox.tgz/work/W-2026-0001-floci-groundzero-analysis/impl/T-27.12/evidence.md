# T-27.12 evidence (golang-pro minion, packet P-2026-0001-09)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-12-ecr-port-range
Branch: fix/W-2026-0001-t27-12-ecr-port-range (local only, not pushed). Base a3543337.
Commits:
- 70e02e85 fix(local): use the qualified ECR port range
- 3bcced77 test(local): build each emulator context on the test goroutine (fixes a data race in the new test that showed up under -race)

Floci image: `docker image inspect` -> Id sha256:3e16af2e77b2..., RepoDigests mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (TK_LOCAL_EMULATOR set to it for every run).

## Change
- Removed the BASE_PORT == MAX_PORT override from containerEnv and removed the marker and the RegistryPort pre-allocation from assignPorts.
- Removed the RegistryPort field. `git grep RegistryPort -- '*.go'` finds no callers; the only hit left is a test name.
- FLOCI_SERVICES_ECR_KEEP_RUNNING_ON_SHUTDOWN=false is now set whenever the Docker socket is mounted (shouldMountDockerSocket).
- The test-designer's tests are unchanged, except that each emulator's context is now built on the test goroutine (testenv.DefaultContext calls t.Setenv). No assertion was weakened and no skip was added.

## AC map
| AC | Result |
|---|---|
| 1 TestTwoEmulatorsStartedTogetherEachGetAWorkingECRRegistry | PASS (with -race, -count=2, and in the full package run). No ecr-registry or flocilocal containers are left over. |
| 2 TestTheEmulatorChoosesItsOwnRegistryPortWhenFlociMayLaunchContainers | PASS |
| 3 marker grep `rg -n "floci: Missing Implementation for" go-core/utils/testutils/flocilocal/` | no hit (rc=1) |
| 4 RegistryPort | removed (no outside callers) |

## Gates (repo root, Makefile targets; run 2026-10-21, Europe/Stockholm)
| Gate | Result |
|---|---|
| make dep | rc=0 on the first bootstrap run. A later rerun failed with rc=2 because the deb.debian.org mirror returned 500 during apt (infra, not code). |
| make generate | rc=0 |
| make fmt | PASS |
| make lint (lint-examples, lint-go = golangci-lint 0 issues on every pass, lint-arch = go-arch-lint over every map) | PASS (rc=0) |
| make vet | PASS |
| make test | PASS (rc=0) |
| make tidy && git diff --exit-code | PASS / clean |
| make test-integration (whole repo, integration,floci, -race) | rc!=0, but no failure is caused by this change (details below). 560 packages ok, 16524 tests passed, 163 skipped (existing skips). |
| flocilocal package rerun with the make flags (-tags=integration,floci -race -p 1 -count=1) at 3bcced77 | PASS: 132 passed, 0 skipped, 0 failed, 0 data races |
| package golangci-lint (with and without integration,floci tags) + go vet on flocilocal at 3bcced77 | 0 issues / clean |

### Failures in the full make test-integration run
- go-core/utils/testutils/flocilocal: data race in the new test at 70e02e85. Fixed in 3bcced77; the rerun is green (above).
- cmd/cblicense (TestCreateCommand...IssuedLicense x2): fails with "TEOS_DEPLOYMENT is local but AWS_ENDPOINT_URL is not set". The package does not import flocilocal (`go list -deps`) and this diff does not touch it, so it fails the same way on base. This is an existing environment problem.
- go-services/appstore/cmd/cbdeploy/internal/auth TestSSOLoginAgainstTheLocalEmulator: the test browser could not sign in at *.localhost.floci.io. A/B run: it fails with HEAD flocilocal and with base a3543337 flocilocal (both rc=1), so the failure predates this change.
- go-services/core/brokers/gobridge/tests/integration: setup fails because `gobridge-aws@v0.9.0` does not contain the package it installs (external module). Not related to this change.
- The cbanalytics bench "FAIL" lines are nested output; that package reported ok.

## git diff --stat a3543337..HEAD
```
 .../utils/testutils/flocilocal/container_args.go   |  17 +-
 go-core/utils/testutils/flocilocal/flocilocal.go   |  26 +---
 .../flocilocal/integration_ecr_registry_test.go    | 172 +++++++++++++++++++++
 .../testutils/flocilocal/options_internal_test.go  |  18 +--
 4 files changed, 188 insertions(+), 45 deletions(-)
```
Only files in the owns globs changed. .env was not touched. Nothing was pushed.

## Review round 1 (code-reviewer findings)
- [High] evidence: this file. Tool versions: golangci-lint 2.14.0 and go-arch-lint 1.17.0, both in ~/go/bin (installed by `make dep`/`make install`). They were already installed; the gate runs put ~/go/bin on PATH. arch-lint was available and ran (make lint-arch inside make lint, rc=0).
- [Low] the port parse now uses net.SplitHostPort plus strconv.Atoi (handles `0.0.0.0:N` and `[::]:N`), and /v2/ accepts 200 or 401.
- New commit: test(local): parse the registry port strictly and accept 401 from /v2/. After it: golangci-lint (integration,floci) 0 issues, go vet clean, and both AC tests PASS under -race on the pinned image. This commit changes only the test file, so the repo-wide gate results above still apply.

## Review round 2 (Copilot, dev-lead msg-096), Floci only
- New commit 548dd964 test(local): register both emulator cleanups before checking start errors. Both t.Cleanup calls are now registered in one loop and the start errors are checked in a second loop, so a failed start never leaks the other emulator.
- Gates at 548dd964 (PATH includes ~/go/bin and ~/.local/bin; TK_LOCAL_EMULATOR pinned to sha256:9710d466...):
  make fmt PASS; make lint (golangci-lint 0 issues + lint-arch over 9 maps) PASS; make vet PASS; make test PASS; make tidy PASS and git diff --exit-code clean;
  flocilocal integration with the make test-integration flags (-tags=integration,floci -race -p 1 -count=1): PASS, 132 passed, 0 failed, 0 skipped, 0 data races.
- No real AWS and no devlocal profile were used.
