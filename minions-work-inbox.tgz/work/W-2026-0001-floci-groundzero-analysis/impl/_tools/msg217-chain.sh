#!/usr/bin/env bash
T=/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools; A=/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-1-apigw-contract-cases; B=/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime
$T/gates.sh $A /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.1/gates ./deployment/stacks/groundzero/service-test/... > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.1/gates/gates-run-87ab8715.out 2>&1
$T/gates.sh $B /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/gates ./go-services/eventsvc/deployment/service-test/... > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/gates/gates-run-0271ba55.out 2>&1
echo STATIC_DONE > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg217-static.flag
