#!/usr/bin/env bash
# Package-scoped substitute for the make targets (make missing on replaced box). usage: <wt> <gatesdir> <pkgdir>
WT=$1; GD=$2; D=$3; cd $WT/$D; export PATH=$HOME/go/bin:$PATH
H=$(git rev-parse HEAD); S=$GD/summary-nomake-${H:0:8}.txt; echo "HEAD $H pkg $D (make unavailable: package-scoped go equivalents)" > $S
run(){ n=$1; shift; { echo "HEAD $H"; echo "CMD (cwd $D): $*"; bash -c "$*" 2>&1; rc=$?; echo "rc=$rc"; } > $GD/$n-nomake-${H:0:8}.log; echo "$n rc=$(tail -1 $GD/$n-nomake-${H:0:8}.log|cut -d= -f2)" >> $S; }
run fmt 'test -z "$(gofmt -l .)"'
run vet 'go vet -tags e2e,floci ./... && { go list ./... 2>/dev/null | grep -q . && go vet ./... || true; }'
run lint 'golangci-lint run --build-tags e2e,floci ./...'
run test 'go test -tags e2e,floci -race -c -o /dev/null . && { go list ./... 2>/dev/null | grep -q . && go test -count=1 -race ./... || echo "untagged: no packages (tagged-only; compiled above)"; }'
run tidy 'go mod tidy && test -z "$(git status --porcelain)"'
grep -q "lint-arch rc=0" $GD/summary-${H:0:8}.txt && echo "lint-arch rc=0 (gates.sh, go-arch-lint direct)" >> $S
cat $S
