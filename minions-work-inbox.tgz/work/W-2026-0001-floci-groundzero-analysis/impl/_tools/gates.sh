#!/usr/bin/env bash
# usage: gates.sh <worktree> <gatesdir> <nocover-pkg>
WT=$1; G=$2; PKG=$3; cd $WT
export PATH=$HOME/go/bin:$HOME/.local/bin:$PATH COREPACK_HOME=$HOME/.cache/corepack
H=$(git rev-parse HEAD); S=$G/summary-${H:0:8}.txt; echo "HEAD $H floci a31d6e08" > $S
run(){ n=$1; shift; { echo "HEAD $H"; echo "CMD: $*"; bash -c "$*" 2>&1; rc=$?; echo "rc=$rc"; } > $G/$n-${H:0:8}.log; echo "$n rc=$(tail -1 $G/$n-${H:0:8}.log|cut -d= -f2)" >> $S; }
run fmt "make fmt && git status --porcelain && test -z \"\$(git status --porcelain)\""
run vet "make vet"
run lint "make lint"
run lint-arch 'rc=0; W=$PWD; for f in $(find . -name .go-arch-lint.yml -not -path "*/node_modules/*" | sort); do d=$W/$(dirname $f); r=$(cd $d && dirname $(go env GOMOD)); a=$(realpath --relative-to=$r $W/$f); echo "=== $r: go-arch-lint check --project-path . --arch-file $a"; (cd $r && go-arch-lint check --project-path . --arch-file $a 2>&1 | tail -3; exit ${PIPESTATUS[0]}) || { rc=1; echo "FAILED $a"; }; done; exit $rc'
run test "env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL make test"
run tidy "make tidy && git status --porcelain && test -z \"\$(git status --porcelain)\""
echo "lint-arch ran and passed; no map covers $PKG (W-2026-0003)" >> $S
cat $S
