#!/usr/bin/env bash
# usage: mkissue.sh "<title>" "<body>" "<labels>" <outfile>
set -euo pipefail
R=Thiink-LLC/teos
URL=$(gh issue create -R $R -t "$1" -b "$2" -a mariotoffia -l "$3")
N=${URL##*/}
ID=$(gh issue view $N -R $R --json id -q .id)
gh api graphql -f query='mutation($i:ID!,$p:ID!,$s:ID!){setIssueFieldValue(input:{issueId:$i,issueFields:[{fieldId:"IFSS_kgDOAVq1qQ",singleSelectOptionId:$p},{fieldId:"IFSS_kgDOAsLCxw",singleSelectOptionId:$s}]}){clientMutationId}}' -f i=$ID -f p=IFSSO_kgDOAl6mDg -f s=IFSSO_kgDOBNUasQ >/dev/null
ITEM=$(gh project item-add 2 --owner Thiink-LLC --url $URL --format json -q .id)
gh project item-edit --project-id PVT_kwDOBoJzxs4BKY5X --id $ITEM --field-id PVTSSF_lADOBoJzxs4BKY5Xzg6RWQI --single-select-option-id 1f493ca5 >/dev/null
{ echo "issue $URL"; gh issue view $N -R $R --json projectItems,assignees,labels -q '{projectItems,assignees:[.assignees[].login],labels:[.labels[].name]}';
gh api graphql -f query="{repository(owner:\"Thiink-LLC\",name:\"teos\"){issue(number:$N){issueFieldValues(first:10){nodes{... on IssueFieldSingleSelectValue{name field{... on IssueFieldSingleSelect{name}}}}}}}}"; } | tee $4
