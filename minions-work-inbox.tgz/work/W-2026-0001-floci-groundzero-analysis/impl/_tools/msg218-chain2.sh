#!/usr/bin/env bash
cd /workspace/repos/teos/work/git-worktree/W-2026-0001-msg218-public-names-fake-ip-skip
sg docker -c "export PATH=$HOME/go/bin:$HOME/.local/bin:$PATH COREPACK_HOME=$HOME/.cache/corepack; make generate; echo rc=\$?" > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates/generate.log 2>&1
git status --porcelain >> /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates/generate.log
/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/gates.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-msg218-public-names-fake-ip-skip /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates ./deployment/stacks/groundzero/service-test/... > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates/gates-run.out 2>&1
echo DONE > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg218-static.flag
