#!/usr/bin/env bash
while [ ! -f /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg217-static.flag ]; do sleep 15; done
cd /workspace/repos/teos/work/git-worktree/W-2026-0001-msg218-public-names-fake-ip-skip && export PATH=$HOME/go/bin:$HOME/.local/bin:$PATH COREPACK_HOME=$HOME/.cache/corepack
{ make dep && make generate; echo rc=$?; } > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates/dep-generate.log 2>&1
git status --porcelain >> /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates/dep-generate.log
/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/gates.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-msg218-public-names-fake-ip-skip /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates ./deployment/stacks/groundzero/service-test/... > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates/gates-run.out 2>&1
echo DONE > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg218-static.flag
