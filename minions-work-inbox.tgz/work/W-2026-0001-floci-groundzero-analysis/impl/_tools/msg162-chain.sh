#!/usr/bin/env bash
# msg-162: under one floci-harness-run hold: 27.1 make test-service (groundzero) + make test-integration @f3fbd052, then 39.11 make test-integration @028f6a4b. Root per GROKBOT.md.
I=/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl
WT1=/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-1-apigw-contract-cases
WT2=/workspace/repos/teos/work/git-worktree/W-2026-0001-t39-11-gobridge-observability-skips
HOLDER="golang-pro msg-162 (27.1 f3fbd052 svc+integ, 39.11 028f6a4b integ)"
lk(){ python3 - "$1" "$HOLDER" <<'P'
import json,sys,datetime,fcntl
p='/workspace/minions/registry/locks.json'
with open(p,'r+') as f:
  fcntl.flock(f,fcntl.LOCK_EX); d=json.load(f); now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
  if sys.argv[1]=='take':
    if any(e['task']=='floci-harness-run' and e.get('status')!='released' for e in d['locks']): sys.exit(1)
    d['locks'].append({'work_id':'W-2026-0001','task':'floci-harness-run','globs':['<exclusive Floci service/integration harness run>'],'holder':sys.argv[2],'since':now,'state':'active','status':'active'})
  else:
    for e in d['locks']:
      if e['task']=='floci-harness-run' and e.get('holder')==sys.argv[2] and e.get('status')=='active':
        e['status']=e['state']='released';e['released']=now
  f.seek(0);json.dump(d,f,indent=2);f.truncate()
P
}
until lk take; do sleep 30; done
trap 'lk rel; sudo chown -R box: $WT1 $WT2; echo released >> $I/msg162.state' EXIT
echo "taken $(date '+%F %T %Z')" > $I/msg162.state
run(){ WT=$1; LOG=$2; shift 2; cd $WT; {
 echo "HEAD $(git rev-parse HEAD)"; echo "image $(sudo docker image inspect mariotoffia/floci:latest --format '{{index .RepoDigests 0}}')"
 echo "CMD (root, env -i => no TEOS_DEPLOYMENT/AWS_ENDPOINT_URL/TEOS_LOCAL_KEEP): make $*"; echo "start $(date '+%F %T %Z')"
 sudo env -i HOME=/root PATH=/usr/local/go/bin:/home/box/.local/bin:/home/box/go/bin:/usr/local/bin:/usr/bin:/bin \
  GOCACHE=/root/.cache/go-build GOMODCACHE=/root/go/pkg/mod COREPACK_HOME=/home/box/.cache/corepack \
  AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE=/dev/null GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="*" make "$@" 2>&1
 echo "rc=$?"; echo "end $(date '+%F %T %Z')"; } > $LOG 2>&1; echo "$(basename $LOG) $(grep ^rc= $LOG)" >> $I/msg162.state; }
run $WT1 $I/T-27.1/gates/test-service-f3fbd052.log test-service CB_SERVICE_TEST=groundzero
run $WT1 $I/T-27.1/gates/test-integration-f3fbd052.log test-integration
run $WT2 $I/T-39.11/gates/test-integration-028f6a4b-attempt3.log test-integration
