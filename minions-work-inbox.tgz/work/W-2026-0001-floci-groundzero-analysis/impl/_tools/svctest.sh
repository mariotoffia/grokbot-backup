#!/usr/bin/env bash
# usage: svctest.sh <worktree> <service-test-dir-rel> <CB_SERVICE_TEST> <logfile> [extra go test args]
WT=$1; D=$2; SVC=$3; LOG=$4; shift 4
cd $WT/$D
export PATH=$HOME/go/bin:$HOME/.local/bin:$PATH COREPACK_HOME=$HOME/.cache/corepack
IMG=mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1
CMD="env -u AWS_PROFILE -u AWS_ENDPOINT_URL AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE=/dev/null TK_LOCAL_EMULATOR=$IMG TEOS_DEPLOYMENT=local CB_SERVICE_TEST=$SVC go test -tags=e2e,floci -count=1 -v -race -timeout ${GOTEST_TIMEOUT:-45m} $* ./..."
{
echo "HEAD $(git rev-parse HEAD)"
echo "git status --porcelain: $(git status --porcelain | wc -l) lines"
echo "CMD (cwd $D, via sg docker): $CMD"
echo "start $(date '+%F %T %Z')"
sg docker -c "$CMD" 2>&1
echo "rc=$?"
echo "end $(date '+%F %T %Z')"
} > $LOG 2>&1
