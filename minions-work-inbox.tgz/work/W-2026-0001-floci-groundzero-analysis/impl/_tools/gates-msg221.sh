#!/usr/bin/env bash
/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/gates.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-msg218-public-names-fake-ip-skip /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/msg-218/gates ./deployment/stacks/groundzero/service-test
/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/gates.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-1-apigw-contract-cases /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.1/gates ./deployment/stacks/groundzero/service-test
/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/gates.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/gates ./go-services/eventsvc/deployment/service-test
echo DONE
