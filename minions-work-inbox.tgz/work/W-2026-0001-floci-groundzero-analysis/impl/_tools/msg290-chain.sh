#!/usr/bin/env bash
# msg-290/293: #1242 46146cee static gates (user) then svc(-race)+integration (root, env -i) under floci-harness-run.
export PATH=/home/box/.local/bin:/home/box/go/bin:/usr/local/go/bin:$PATH
G=/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.1/gates
WT=/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-1-apigw-contract-cases
ST=$G/msg290.state; cd $WT; H=$(git rev-parse HEAD); S=${H:0:8}
hdr(){ echo "HEAD $H"; echo "DIR $PWD"; echo "CMD $1"; echo "start $(TZ=Europe/Stockholm date '+%F %T %Z')"; }
g(){ n=$1; shift; { hdr "env -u TEOS_LOCAL_KEEP -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL $*"; env -u TEOS_LOCAL_KEEP -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL "$@" 2>&1; echo "rc=$?"; } > $G/$n-$S.log; echo "$n $(tail -1 $G/$n-$S.log)" >> $ST; }
: > $ST
g gofmt make fmt-check-go; g vet make vet; g vet-direct-groundzero bash -c "cd deployment/stacks/groundzero/service-test && go vet -tags e2e,floci ./... && cd .. && go vet ./..."; g golangci-lint make lint-go; g lint-arch make lint-arch
g tidy bash -c 'make tidy && git diff --exit-code -- "*go.mod" "*go.sum"'
HOLDER="golang-pro msg-290 #1242 $S svc+integ"
lk(){ python3 - "$1" "$HOLDER" <<'P'
import json,sys,datetime,fcntl
p='/workspace/minions/registry/locks.json'
with open(p,'r+') as f:
  fcntl.flock(f,fcntl.LOCK_EX); d=json.load(f); now=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
  if sys.argv[1]=='take':
    if any(e['task']=='floci-harness-run' and e.get('status')!='released' for e in d['locks']): sys.exit(1)
    d['locks'].append({'work_id':'W-2026-0001','task':'floci-harness-run','globs':['<exclusive Floci service/integration harness run>'],'holder':sys.argv[2],'since':now,'state':'active','status':'active'})
  else:
    for e in d['locks']:
      if e['task']=='floci-harness-run' and e.get('holder')==sys.argv[2] and e.get('status')=='active':
        e['status']=e['state']='released';e['released']=now
  f.seek(0);json.dump(d,f,indent=2);f.truncate()
P
}
until lk take; do sleep 30; done
trap 'lk rel; sudo chown -R box: $WT; echo released >> $ST' EXIT
echo "lock taken $(TZ=Europe/Stockholm date '+%F %T %Z')" >> $ST
r(){ n=$1; shift; { hdr "sudo env -i (no TEOS_LOCAL_KEEP/TEOS_DEPLOYMENT/AWS_ENDPOINT_URL) $*"; echo "image $(sudo docker image inspect mariotoffia/floci:latest --format '{{index .RepoDigests 0}}')"
 sudo env -i HOME=/root PATH=/usr/local/go/bin:/home/box/.local/bin:/home/box/go/bin:/usr/local/bin:/usr/bin:/bin \
  GOCACHE=/root/.cache/go-build GOMODCACHE=/root/go/pkg/mod COREPACK_HOME=/home/box/.cache/corepack \
  AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE=/dev/null GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="*" "$@" 2>&1
 echo "rc=$?"; echo "end $(TZ=Europe/Stockholm date '+%F %T %Z')"; } > $G/$n-$S.log 2>&1; echo "$n $(grep ^rc= $G/$n-$S.log)" >> $ST; }
r test-service GOFLAGS=-race make test-service CB_SERVICE_TEST=groundzero
r test-integration make test-integration
