#!/usr/bin/env bash
# msg-221/222: waits for docker + free harness lock, then runs the three service tests serially (-tags=e2e,floci -count=1 -v -race, image a31d6e08).
L=/workspace/minions/registry/locks.json
busy(){ python3 -c "
import json;d=json.load(open('$L'));print(sum(1 for e in d['locks'] if e['task']=='floci-harness-run' and e.get('status')!='released'))"; }
while :; do command -v docker >/dev/null && getent group docker >/dev/null && [ "$(busy)" = 0 ] && [ "$(pgrep -f 'go test -tags' | wc -l)" = 0 ] && break; sleep 30; done
python3 - <<P
import json,datetime;p='$L';d=json.load(open(p))
d['locks'].append({'work_id':'W-2026-0001','task':'floci-harness-run','globs':['<exclusive Floci service/integration harness run>'],'holder':'golang-pro stream 1 (final svc tests 27.1 4b08764e, 27.16.1 b049c8ae)','since':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'state':'active','status':'active'})
json.dump(d,open(p,'w'),indent=2)
P
echo "taken $(date)" > /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/svc-final.state
GOTEST_TIMEOUT=100m /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/svctest.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime go-services/eventsvc/deployment/service-test event-service /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/gates/test-service-b049c8ae.log; echo "27.16.1 $(grep -E '^rc=' /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.1/gates/test-service-b049c8ae.log)" >> /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/svc-final.state
GOTEST_TIMEOUT=100m /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/_tools/svctest.sh /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-1-apigw-contract-cases deployment/stacks/groundzero/service-test groundzero /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.1/gates/test-service-4b08764e.log; echo "27.1 $(grep -E '^rc=' /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.1/gates/test-service-4b08764e.log)" >> /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/svc-final.state
python3 - <<P
import json,datetime;p='$L';d=json.load(open(p))
for e in d['locks']:
  if e['task']=='floci-harness-run' and e.get('status')=='active' and 'final svc' in e.get('holder',''):
    e['status']='released';e['state']='released';e['released']=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
json.dump(d,open(p,'w'),indent=2)
P
echo "released $(date)" >> /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/svc-final.state
