# W1 file-ownership matrix (W-2026-0001, base a3543337)

| Task | Owns | Module |
|---|---|---|
| 27.13 | go-core/managers/mgriot/awsmgriot/devicemanager_aws{,_test}.go | go-core |
| 27.12 | go-core/utils/testutils/flocilocal/{flocilocal,container_args,options,doc}.go, options_internal_test.go, integration_*_test.go | go-core |
| 27.14 | go-services/devicesvc/scripts/created/enable-fleet-indexing/**, devicesvc/deployment/stack_fleet_indexing.go, devicesvc/deployment/service-test/** | devicesvc (separate modules) |
| 27.21 | go-core/cbtarget/awsdstarget/target_integration_test.go, go-core/cbtarget/awsdstarget_integration_test.go | go-core |

| Pair | Overlapping files | Verdict |
|---|---|---|
| 27.13 × 27.12 | none (same go-core module; go.mod/go.sum only if imports change — not expected) | PARALLEL-OK |
| 27.13 × 27.14 | none (both "devices" domain, disjoint paths/modules) | PARALLEL-OK |
| 27.13 × 27.21 | none | PARALLEL-OK |
| 27.12 × 27.14 | none in files. Runtime: device-service service test starts Floci through flocilocal; a 27.12 regression would show up there after merge | PARALLEL-OK |
| 27.12 × 27.21 | none in files. Runtime: 27.21's integration tests run on flocilocal, which 27.12 changes | PARALLEL-OK (merge 27.12 first or rebase 27.21 and rerun integration if 27.12 merges first) |
| 27.14 × 27.21 | none | PARALLEL-OK |

Shared-risk files (no task owns them; edit = ESCALATION: conflict): go-core/go.mod, go-core/go.sum, go-core/PACKAGES.md, CHANGELOG.md, deployment/lib/svctest/**, consts.go / provision-config.yaml pins.
No MERGE-CANDIDATE and no SERIAL pair. **Verdict: all 4 can run in parallel.** Later dependency outside W1: 27.20 (devicesearcher_aws_integration_test.go, same awsmgriot package as 27.13, different file) must land after 27.14.

## Update 2026-10-21 17:45 CEST (dev-lead, CTO decision msg-W-2026-0001-063): 27.25 and 27.10 pulled into W1, start Thu 2026-10-22. Target end of W-2026-0001: **Mon 2026-11-09**.

| Task | Owns | Module |
|---|---|---|
| 27.25 | go-services/eventsvc/deployment/service-test/subscriber_test.go (+ helpers used only by it, if needed) | eventsvc |
| 27.10 | go-services/collectorsvc/deployment/service-test/{helpers_test,e2e_collection_test,main_test}.go | collectorsvc |

| Pair | Overlapping files | Verdict |
|---|---|---|
| 27.25 × 27.12 / 27.14 / 27.21 / 27.10 | none (separate module) | PARALLEL-OK |
| 27.10 × 27.12 / 27.14 / 27.21 / 27.25 | none (separate module) | PARALLEL-OK |
| 27.25 × 27.16.6 / 27.16.1 (W3/W4) | same eventsvc service-test package | SERIAL: 27.16.6 starts only after 27.25 is merged (critical path) |

Active W1 slots: 27.12, 27.14, 27.25, 27.10 = 4 of 4 (27.13 closes in the 27.14 PR, 27.21 parked). Shared-risk files unchanged (go.mod/go.sum, deployment/lib/svctest/**, pins).
