# Code review — PR #1230 (T-27.16.3) @ bc3906d5, Floci a31d6e08
Reviewer: the Code Reviewer minion (code-reviewer), read-only. Base: merge-base with origin/main (fresh fetch); 1 commit, 2 files (+10/-14).

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] gates/test-service.log (finished 15:06:03) ran on the pre-commit tree; commit bc3906d5 is 15:06:11 (Europe/Stockholm). summary.txt says "pre-commit tree == HEAD". The diff is test-only, so this is fine. All other gates (fmt/vet/lint/lint-arch/test/tidy/test-integration) ran after the commit. Fix: none needed; for later tasks, stamp `git rev-parse HEAD` into each gate log.
- [Low] [non-testable] docs SERVICE_TEST_WRITING.md:122 still uses the old "HTTP shadow updates reaching topic rules" Floci gap as its example (gates/marker-rg.log). The gap no longer exists. Fix: follow-up doc touch (outside this task's owns globs).
- [Low] [non-testable] go-services/corerouter/deployment/service-test/helpers_test.go:37: the doc comment still says the pdisp role carries env=devlocal, and only the new tags are described. Fine as is; noted for accuracy only.
- [Info] Arch-lint: `make lint-arch` passed (gates/lint-arch.log, 9 maps), but no map covers go-services/corerouter. Per W-2026-0003 the interim arch gate is reviewer sign-off: no production code changed (only _test.go), no layering impact. Signed off here; the hexagonal/clean-arch reviewer is optional.
- [Info] -race with `GOFLAGS=-race make test-service` aborts in third-party jsii init in the gobridge harness (gates/test-service-make-goflags-race.log). The direct go test -race run is accepted. Not caused by this PR.

== Checks ==
- Skips gone: both `harness.Target().IsLocal()` t.Skip blocks were removed (mirror_test.go:43, :212). No corerouter marker hits (gates/marker-rg.log). Test logs show 0 SKIP.
- Correctness: the root cause is that the queue resolver filters on pt. Tagging pt=esv plus allow-send-providerdispatcher=true matches the actuationsvc helper. Red log: gates/test-service-red.log. Green log: gates/test-service.log (2/2 PASS, rc=0).
- Gates rc=0 (gates/summary.txt): fmt, vet, golangci-lint (lint.log), lint-arch, make test (run with TEOS_DEPLOYMENT/AWS_ENDPOINT_URL unset, so there is no PR-1227-style env leakage; test.log has no FAIL), tidy plus clean diff, and test-integration with tags integration,floci, -race (handlers/corerouter, routercore, deployment ok).
- Security/perf: test-only change. Tags are scoped to ephemeral svctest queues, which are cleaned up. No secrets.
- Specialists: test-reviewer (already running) for test-quality depth. No others needed.

== Rationale ==
This is a minimal, correct test-only change that fixes a real helper bug instead of hiding it. Floci evidence is complete for this HEAD. All required Go gates passed, and the arch gap is covered by this sign-off under W-2026-0003. No High or Medium findings.
