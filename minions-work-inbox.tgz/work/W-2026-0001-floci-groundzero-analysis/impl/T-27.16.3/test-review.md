# T-27.16.3 test review: test-reviewer minion (msg-W-2026-0001-dev-lead-159)
PR: https://github.com/Thiink-LLC/teos/pull/1230. Head bc3906d5211029d976361063c8909e45b51c4f71 matches the given SHA bc3906d5. The PR is marked ready. CI at review time: Architecture, CodeQL and Analyze passed. Build, Static Analysis and Unit Tests were IN_PROGRESS (earlier runs were cancelled).
Diff: corerouter/deployment/service-test/helpers_test.go (+10/-4: tags pt=esv and allow-send-providerdispatcher=true) and mirror_test.go (-10: two local skips and their markers). Build tag: `//go:build e2e` at mirror_test.go:1, which is correct for service tests per TESTS.md.

## AC mapping
| AC | Mapped to | Status |
|---|---|---|
| 1 Skips and markers removed, no assertion weakened | diff mirror_test.go:43-46, :217-220. No assertion changed | MET |
| 2 TestMirrorIngestFlow + TestMirrorIdtFlow pass on Floci a31d6e08 via make test-service with -race | gates/test-service.log: both PASS, ok 107s, 0 DATA RACE, digest a31d6e08. It ran the go test line directly, not through `make test-service` | MET with deviation (see findings) |
| 3 No new skips | diff adds no skip | MET |
| 4 rg shows no corerouter marker | gates/marker-rg.log, and I confirmed it at HEAD. ingestionsvc :44 (T-27.16.4) and SERVICE_TEST_WRITING.md:122 remain | MET |

## Is the tag fix the right fix?
Yes, it fixes the test and does not hide a product bug. The product resolver filters on `pt` (actuationsvc/actuationcore/queue-resolver-impl.go:100, :168). The pdisp identity policy keys on `allow-send-providerdispatcher=true` (actuationsvc/deployment/stack_part2.go:135, :264, and _design/overview.adoc:293). Real provider ESV queues carry `pt=esv` (manifest.json:16-17). The fake queue was simply out of date with the product contract, and the actuationsvc helper already tags it this way. The red run plus the container log (`queue not found for provider svctest-mirror with fd=egress pt=esv`) is sound TDD for this. Side note: the same stale helper would also have failed on AWS, so these tests were broken on both targets until now, not only on Floci.

## Is bypassing the harness for -race acceptable?
Acceptable, with sign-off. The 4 races in gates/test-service-make-goflags-race.log are all in jsii-runtime-go v1.139.0 process.go:182 (os/exec Wait/awaitGoroutines). They show up in the gobridge service-test, which `make test-service` runs regardless of CB_SERVICE_TEST, and this PR touches no gobridge or jsii code, so the PR cannot have caused them. They are not *proven* to exist on main, though: there is no run on main. The direct run is the Makefile's own go test line for the corerouter dir, and it still deploys through svctest on the pinned digest. It is a fair substitute for the -race part. The summary also says test-service ran on the "pre-commit tree == HEAD" rather than a checkout of bc3906d5. That is acceptable if the tree hash was compared, but it is not shown.

## Flakiness (code that now runs on the local target)
- mirror_test.go:73-74 and :238-239: `time.Sleep(10 * time.Second)` for tag propagation. That propagation is exactly the step that was broken here, so a slow tagging index would flake.
- helpers_test.go:212-230 pollSQSMessages: a real-clock deadline loop with time.Sleep(5s), not require.Eventually.
- mirror_test.go:174-190 and :331-346: payload asserts are conditional on State.Desired != nil and on the sensor being present, so the test can pass while only logging.
- These were all on main before this PR, and the brief here does not demand Eventually. They are the same pattern fixed in #1227 (waitForProviderQueueResolvable, receiveEventually, unconditional requires), and before this PR none of it ran locally.
- No shared mutable globals, no ordered-map assertions, and no live net beyond the emulator. Each test uses its own uniquely named queue, cleaned up with t.Cleanup.

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [Medium] [testable] go-services/corerouter/deployment/service-test/mirror_test.go:74, :239 — a fixed 10 s sleep for Tagging API propagation now gates the local run. Fix: replace it with a require.Eventually over the resolver's GetResources lookup (fd=egress, pn, pt=esv), as #1227 does with waitForProviderQueueResolvable.
- [Medium] [testable] go-services/corerouter/deployment/service-test/mirror_test.go:174-190, :331-346 — the rule-output payload checks are conditional and pass silently, so "no assertion weakened" holds only because they were weak already. Fix: require.NotNil State/Desired, require that the sensor key is present and is a float64, then InDelta (as in #1227).
- [Low] [testable] go-services/corerouter/deployment/service-test/helpers_test.go:212-230 — pollSQSMessages is a sleep loop on the real clock. Fix: require.Eventually (receiveEventually pattern). It sits in an owns file, so this is in scope.
- [Low] [non-testable] impl/T-27.16.3/evidence.md — AC2 asks for `make test-service` with -race, and the evidence used the go test line directly. jsii races are attributed to main without a run on main. Fix: dev-lead records the accepted deviation. Optionally attach `GOFLAGS=-race make test-service` output on origin/main b45acb61 showing the same jsii races, and file a backlog item for the gobridge harness under -race.
- [Low] [non-testable] impl/T-27.16.3/gates/summary.txt:2 — the service test ran on the "pre-commit tree == HEAD". Fix: record the tree-hash comparison (or rerun on a bc3906d5 checkout), and wait for CI Build and Unit Tests to go green.

== Rationale ==
Root cause and fix are correct: the fake queue now matches the product's tag contract (pt=esv plus the allow-send opt-in), and both tests pass under -race on a31d6e08 with 0 races. The harness bypass is acceptable evidence, because the jsii races come from untouched third-party code in gobridge, provided dev-lead records the deviation. The blockers are flakiness: fixed sleeps and silent conditional asserts from main now run on Floci for the first time. Holding this PR to the bar #1227 just cleared is consistent and needs only in-owns test edits. After those fixes and green CI, this moves to APPROVED.

---
## Re-review @7ab64868 (msg-W-2026-0001-dev-lead-174)
Head 7ab64868a3d3035685132f8dddd08116e69c3ceb matches the given SHA 7ab64868. Diff since bc3906d5: helpers_test.go (+86 incl. removed lines) and mirror_test.go only. No go.mod change. CI at review time (15:47 CEST): Architecture, CodeQL and Analyze passed. **Build, Static Analysis and Unit Tests were IN_PROGRESS.**

### Earlier findings
| Earlier finding | Status |
|---|---|
| 10 s sleeps at mirror_test.go:74/:239 | RESOLVED. waitForProviderQueueResolvable is a require.Eventually (60 s / 2 s) over the resolver's Tagging lookup (Queue, fd=egress, pn, pt=esv) that matches the ARN. No time.Sleep is left in the package. |
| Conditional payload asserts | RESOLVED in both tests: State/Desired require.NotNil, sensor key and float64 are require.True, then InDelta. |
| pollSQSMessages sleep loop | RESOLVED. It is replaced by receiveEventually (require.Eventually, 2 s tick, 1 s long-poll), and no caller of the old name is left. queueARNFromURL exists at helpers_test.go:123. |
| -race deviation note | RESOLVED. The evidence.md section "Accepted deviation" records the jsii-runtime-go reason, that the races are not shown on main, and a suggested backlog item. |
| Service-test log at the commit | RESOLVED. gates/test-service-7ab64868.log has HEAD 7ab64868, a clean tree (porcelain 0 lines) and the pinned digest. Both tests PASS, ok 90 s, 0 DATA RACE. |

### New flakiness check
- Each tick builds a new paginator, errors return false so the poll retries, and the timeouts are bounded. Captured `messages` is read only after Eventually returns true, so there is no race on success.
- No sleeps, no shared globals, and no map-order assertions. mapKeys is used only in failure messages.
- Each test still uses its own queue, cleaned up with t.Cleanup.
- No new risk found.

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [Medium] [non-testable] impl/T-27.16.3/gates/summary-7ab64868.txt — `make test` and `make tidy` + clean diff at 7ab64868 are not recorded yet. The summary stops at lint-arch, and test-7ab64868.log and tidy-7ab64868.log were still being written at 15:47 CEST. The tidy result matters here: the new awsmgrres import added an indirect resourcegroupstaggingapi entry to go.mod in #1227, and this module's go.mod has no such entry. Fix: record test rc and tidy rc plus `git diff --exit-code` for 7ab64868 (if tidy changes go.mod/go.sum, commit that), and wait for CI Build, Static Analysis and Unit Tests to go green.
- [Low] [non-testable] PR #1230 body — "Closes #1231" is a GitHub closing keyword. The minion pack allows those only on the ship PR. Fix: dev-lead confirms that the repo's flow (GITHUB.md) wants it, or changes it to "Refs #1231". This is a process note, not a test finding.

== Rationale ==
All five test findings are fixed exactly as asked, matching the #1227 pattern, and the fixes add no new flakiness. The service test at the committed HEAD passes under -race on a31d6e08 with 0 races and a clean tree. What remains is evidence only: the unit-test and tidy gates at HEAD are not recorded yet (tidy may change go.mod for the new import), and CI is still running. Once those land green, this is APPROVED with no further test-code change.

---
## Final check @4888308b (msg-W-2026-0001-dev-lead-177)
Head 4888308b05ca1191275f0757b3b88ef79c7d8cb9 matches the given SHA 4888308b. The 7ab64868..4888308b diff touches only go-services/corerouter/deployment/service-test/go.mod (+1, indirect resourcegroupstaggingapi v1.31.12) and go.sum (+2). This is exactly the tidy change flagged in the re-review, and no test code changed.

### Gate evidence
- **Tidy:** gates/tidy-test-7ab64868.txt records `make tidy` at 4888308b with rc=0 and porcelain-lines=0 (clean diff). The log is gates/tidy-4888308b.log.
- **make test:** rc=0 at 7ab64868 (test-7ab64868.log, run with env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL). It was not rerun at 4888308b. I accept carrying it over, because the only delta is an indirect go.mod/go.sum entry that tidy adds, and no source changed.
- **At 7ab64868:** fmt, vet, lint, lint-arch, test-integration and test-service -race were all rc=0 (summary-7ab64868.txt).
- **Closing keyword:** the earlier Low finding about "Closes #1231" is dropped, accepted per dev-lead (Mario's rule: every PR closes its issue).

### CI at review time (16:11 CEST)
Architecture, CodeQL and Analyze (actions, javascript-typescript) passed. Cursor Bugbot and Security Reviewer were NEUTRAL. **Build, Static Analysis and Unit Tests were IN_PROGRESS.**

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] PR #1230 CI — Build, Static Analysis and Unit Tests had not finished at 4888308b. Fix: none for the tests. The merge gate stays "all workflows green" before Mario merges. Dev-lead re-pings test-reviewer only if one of them fails.
- [Low] [non-testable] impl/T-27.16.3/gates/ — no summary-4888308b.txt exists, and the 4888308b results sit inside tidy-test-7ab64868.txt. Fix: optionally add a one-line summary-4888308b.txt for traceability. This does not block.

== Rationale ==
The final delta is only the expected tidy change to go.mod and go.sum, and tidy at 4888308b is now clean. All test-quality findings were resolved at 7ab64868: Eventually-based waits, unconditional payload asserts, receiveEventually, and a recorded -race deviation. The service test passed under -race on Floci a31d6e08 at a clean committed tree. Local evidence is green, and the test review approves. Green CI remains the separate merge gate.
