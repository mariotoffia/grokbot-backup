# T-27.16.3 evidence: corerouter shadow mirror service tests on Floci

- Image: mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 (resolved from mariotoffia/floci:latest at run time). Floci only; AWS_CONFIG_FILE/AWS_SHARED_CREDENTIALS_FILE=/dev/null, AWS_PROFILE unset. No real AWS, no devlocal.
- Branch chore/W-2026-0001-t27-16-3-corerouter-shadow-skips, base origin/main b45acb61 (has #1226-#1229). Worktree /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-3-corerouter-shadow-skips
- HEAD bc3906d5 test(corerouter): run the shadow mirror service tests on Floci (author Mario Toffia, no trailer)
- PR https://github.com/Thiink-LLC/teos/pull/1230 — opened draft, marked ready at once (flow change 13:03, dev-lead msg-155), Copilot review requested 15:06 (Europe/Stockholm).
- diff --stat: helpers_test.go +10/-4, mirror_test.go -10 (2 files).

## Skips found (rg on base)
Only go-services/corerouter/deployment/service-test/mirror_test.go:44 (TestMirrorIngestFlow) and :218 (TestMirrorIdtFlow), marker "floci: Missing Implementation for HTTP shadow updates reaching topic rules". The testing.Short() skips in handlers/corerouter are not shadow skips and stay. #1226 evidence called these an MQTT gap; wrong — they gated HTTP shadow update -> IoT topic rule.

## TDD
1. Red (skips removed, gates/test-service-red.log): both FAIL after 2m polling, no message on the fake provider queue.
2. Diagnosis (kept env, gates/debug-keep.log + container logs): Floci ran corerouter_shadow_rule and invoked the corerouter Lambda, which sent to pdisp-eb. pdisp-eb failed: `queue not found for provider svctest-mirror with fd=egress pt=esv` (actuationcore queue resolver now filters on pt). Cause is our test helper, not Floci.
3. Fix: corerouter helpers_test.go createTaggedProviderQueue now tags pt=esv and allow-send-providerdispatcher=true, same as the actuationsvc helper.
4. Green (gates/test-service.log): 2 pass / 0 fail / 0 skip, -race, 0 data races, rc=0.

## Gates (logs in gates/, summary.txt)
- dep 0, generate 0 (under sg docker after docker info worked; sur models regenerated, git clean)
- fmt 0, vet 0, lint 0
- lint-arch ran and passed; no map covers go-services/corerouter (W-2026-0003). go-arch-lint called directly (PATH=$HOME/go/bin), 9 maps, rc=0. Arch gate for corerouter = standard linter + hexagonal/clean-arch reviewer sign-off.
- make test (env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL) 0
- make tidy 0, git diff clean
- corerouter test-integration (cbtest local exec --resources-only, tags integration,floci, -race, -p 1): handlers/corerouter, routercore, deployment ok, 0 skip, 0 races, rc=0
- CB_SERVICE_TEST=corerouter-service test-service -race: rc=0 (run sequentially, nothing else running)

## Marker rg (gates/marker-rg.log)
No corerouter hits. Remaining repo hits: go-services/ingestionsvc/.../ingestion_test.go:44 (T-27.16.4, out of scope) and SERVICE_TEST_WRITING.md:122 (doc example using this now-obsolete gap; not changed, out of owns globs).

## Surprises
- `GOFLAGS=-race make test-service` aborts in the gobridge harness (runs first via its own Makefile target even when CB_SERVICE_TEST=corerouter-service) on 4 data races inside jsii-runtime-go init (third-party), log gates/test-service-make-goflags-race.log. So -race was run as the Makefile's go test line directly in the corerouter service-test dir.
- This shell lacked the docker group (use sg docker), cdk lives in ~/.local/bin, and make dep needs COREPACK_HOME=$HOME/.cache/corepack.

## Accepted deviation: -race service test run outside `make test-service`
`GOFLAGS=-race make test-service` always runs the gobridge harness first (its own Makefile target ignores CB_SERVICE_TEST), and that harness aborts on 4 data races inside jsii-runtime-go v1.139.0 init (process.go:182, third-party; no gobridge or jsii code touched here). Log: gates/test-service-make-goflags-race.log. Accepted deviation (test-reviewer and code-reviewer on #1230): the -race service test runs the Makefile's own go test line directly in go-services/corerouter/deployment/service-test, still deploying through svctest on the pinned digest. Not shown to exist on main (no main run); backlog item suggested for the gobridge harness under -race.

## Review fixes (msg-162), HEAD 7ab64868
- mirror_test.go: the two 10 s sleeps are replaced by waitForProviderQueueResolvable (require.Eventually over the resolver's Tagging lookup fd=egress, pn, pt=esv, 60 s / 2 s), as in #1227.
- mirror_test.go: payload checks are now required (State and Desired NotNil, sensor key present, float64, InDelta) in both tests.
- helpers_test.go: pollSQSMessages replaced by receiveEventually (require.Eventually); doc comment at :37 corrected (resource policy conditions and the identity-policy opt-in tag).
- Service test at HEAD 7ab64868 (HEAD and command at the top of gates/test-service-7ab64868.log, clean tree): 2 pass / 0 fail / 0 skip, -race, 0 data races, rc=0.
- Gates at 7ab64868: gates/summary-7ab64868.txt.
- Issue #1231 (Closes #1231 in the PR body): assignee mariotoffia, labels unit-test, core, e2e; org issue fields Priority=Medium, Size=Hours (read back); Roadmap unset. Project "R&D Sprint Board" not added: gh token lacks read:project (exact error in the report).
