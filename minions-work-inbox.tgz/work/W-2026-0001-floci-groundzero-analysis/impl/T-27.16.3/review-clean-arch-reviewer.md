# Clean Architecture review: T-27.16.3, PR #1230
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-3-corerouter-shadow-skips · HEAD bc3906d5 (matches the request and FETCH_HEAD of pull/1230). Base: b45acb61. Floci only; no GitHub posts.

== Verdict ==
APPROVED with notes

== Findings ==
- [Low] [known gap W-2026-0003] go-services/corerouter: no .go-arch-lint.yml covers corerouter. `PATH=$HOME/go/bin:$PATH make lint-arch`: rc=0, 9 maps checked, "OK - No warnings found", but none of them covers this diff. The hand-built import map below is the evidence. Fix: none here (tracked in W-2026-0003).
- [Info] `go vet -tags e2e ./deployment/service-test/` rc=0. The tree is clean after the run, and make generate was not run.
- Out of scope: port and adapter shape (hexagonal-reviewer) and test quality (test-reviewer).

Test-only claim: confirmed. b45acb61..bc3906d5: 2 files, both in go-services/corerouter/deployment/service-test/ (`//go:build e2e`), +10/-14. mirror_test.go drops the two Floci skip guards. helpers_test.go adds the `pt=esv` and `allow-send-providerdispatcher=true` tags to the fake provider queue and updates the comments and log line. No production, domain, handler or adapter code changed.

Arch map (go list -tags e2e -test): the servicetest package imports deployment/lib/svctest, deployment/lib/core/{iam,domain/wellknown}, go-core (cbenv, cbevent, ctx, ifcore, awsmgrqueue, dsmodel, awstestutil), aws-sdk-go-v2 (aws, iot, iotdataplane, s3, sqs, sqs/types) and testify. It imports no corerouter domain, application or handler package. The AWS SDK is used only in the e2e test layer, which is correct. The diff adds or removes no import. No .go-arch-lint.yml, ADR or go.mod change.

== Rationale ==
The change edits map literals and removes skips in an e2e service test. It cannot invert a dependency, leak infrastructure into the domain or move business logic. The tag values match what the eastbound dispatcher's resolver needs at runtime. They are test fixture data, not a layering concern.
