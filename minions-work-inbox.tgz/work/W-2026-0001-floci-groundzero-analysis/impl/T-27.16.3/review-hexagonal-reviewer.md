# Hexagonal review — T-27.16.3 · PR Thiink-LLC/teos#1230 @ bc3906d5
Reviewer: hexagonal-reviewer (minion) · read-only · Floci-only (no real AWS, no devlocal)
Diff: merge-base b45acb61..bc3906d5 — 2 files, test-only (go-services/corerouter/deployment/service-test/{helpers_test.go,mirror_test.go}).

== Verdict ==
APPROVED_DEGRADED

== Findings ==
- [Medium] [non-testable] go-services/corerouter/ (no .go-arch-lint.yml) — no arch-lint map covers corerouter (W-2026-0003); lint-arch rc=0 is vacuous for this service, manual review is the interim gate. Fix: add corerouter map via ADR + lead-architect approval (W-2026-0003).
- [Medium] [non-testable] go-services/corerouter/ — service-local DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md, adr/, plans/ absent (pre-existing; not introduced by this PR). Fix: scaffold per CONVENTIONS §A/§3 in a follow-up.
- [Low] [testable] gates/test-service.log:1 — log has no explicit commit / command header; commit binding comes only from summary.txt ("pre-commit tree == HEAD") and evidence.md, and -race run was the Makefile's go test line directly (GOFLAGS=-race make aborts on third-party jsii races in gobridge). Fix: record `git rev-parse HEAD` and exact command in the gate log.
- [Info] helpers_test.go:59-69 — adds pt=esv and allow-send-providerdispatcher tags; test fixture now matches the production queue-resolver contract (actuationcore). No port/adapter change, no domain logic in adapters.
- [Info] mirror_test.go:43,212 — Floci skips removed, no assertions weakened.

Ports & adapters: no production code changed; no port defined in an adapter, no domain leak into adapters, no new wiring outside composition root. Tests are black-box service tests via deployed infrastructure (no port substitution needed at this layer). No ESCALATE.

Gates (evidence + gates/): test-service on Floci a31d6e08 @ bc3906d5 rc=0, TestMirrorIngestFlow PASS, TestMirrorIdtFlow PASS, 0 skip, -race; make test rc=0; tidy rc=0 clean diff; lint-arch rc=0 (9 maps, none for corerouter); fmt/vet/lint rc=0; test-integration rc=0. Reviewer re-ran `go vet -tags integration,floci,e2e ./corerouter/...` in worktree @bc3906d5: rc=0.

== Rationale ==
Test-only change with no hexagonal impact; all required gates passed on Floci at HEAD. Verdict capped at APPROVED_DEGRADED because the arch-lint gate does not cover corerouter (missing map), so the arch check is manual. Missing service-local docs are pre-existing Medium findings for follow-up, not blockers for this PR.
