Scope: Floci-only; no real-AWS runs (devlocal included).

# T-27.16.3 — test(corerouter): run the shadow mirror service tests on Floci

Work item: W-2026-0001 · Packet: P-2026-0001-38 · Implementer: golang-pro · start_gate: Mario's go relayed by dev-lead 2026-10-22 14:42 (STATUS.md go-approved)
Repo: Thiink-LLC/teos · Base: origin/main b45acb61 (includes #1226-#1229) · Branch: chore/W-2026-0001-t27-16-3-corerouter-shadow-skips
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-3-corerouter-shadow-skips
Floci image: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 (contains Floci Task 48, shadow deep merge, and 19.1, HTTP shadow updates reaching topic rules)

## Scope
Remove every corerouter integration/service-test skip for shadow topics. `rg` on base finds two sites, both in go-services/corerouter/deployment/service-test/mirror_test.go:
- :44-45 TestMirrorIngestFlow — `floci: Missing Implementation for HTTP shadow updates reaching topic rules` + t.Skip
- :218-219 TestMirrorIdtFlow — same marker + t.Skip
The `testing.Short()` skips in handlers/corerouter are not shadow skips and stay.
Note: #1226 (T-27.21) evidence wrongly called these skips MQTT-related; they gate HTTP shadow updates reaching IoT topic rules.

## Acceptance criteria
1. Both skips and their markers are removed; no assertion weakened.
2. TestMirrorIngestFlow and TestMirrorIdtFlow run and pass on Floci (resolved digest) via `CB_SERVICE_TEST=corerouter-service make test-service` with -race.
3. No new skips.
4. Repo-wide `rg "HTTP shadow updates reaching topic rules"` shows no stale marker remaining for corerouter (ingestionsvc 27.16.4 out of scope, listed).

## Checklist: CONVENTIONS §A (existing service, test-only) + §I. No §B/§D/§E. Floci only. No .go-arch-lint.yml change.
## Gates: make fmt/lint/vet, go-arch-lint direct, make test (env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL), go mod tidy clean, corerouter test-integration then test-service (sequential, -race).
