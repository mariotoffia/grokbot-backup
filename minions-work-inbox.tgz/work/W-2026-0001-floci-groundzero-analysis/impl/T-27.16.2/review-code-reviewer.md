# T-27.16.2 code review: code-reviewer minion (msg-W-2026-0001-dev-lead-145)

PR: https://github.com/Thiink-LLC/teos/pull/1227. HEAD 013238ac, merge-base db06a87b. Commits: dd76a37f, 1624a935, 2b092f96, 013238ac. Floci-only, image a31d6e08.
Reviewer checks (read-only): golangci-lint (e2e,floci) on the service-test module found 0 issues; go vet OK; `go mod tidy -diff` is clean; make lint-arch checked 9 maps and found nothing. No map covers go-services/actuationsvc/deployment/service-test, so the arch gate is reviewer sign-off (W-2026-0003). The worktree is clean and the pandoc .deb files are gone (none tracked).

Note on the change requests: the sleep and payload-assert items came from the test-reviewer (test-review.md, msg-135), not from code-reviewer 005. 005 asked for evidence.md, the service-test result, and AC1/AC3 evidence, plus a Low about the .deb files.

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [High] [testable] gates/summary.txt and evidence.md: no service-test run at 013238ac. The only actuation-service pass (/tmp/t27162-svc.log and _dist/_output/reports/test-service-local.log, 12:59) ran the old code: it logs "eastbound_test.go:69: Waiting 10s for Resource Groups Tagging API propagation...", which is the sleep path. So waitForProviderQueueResolvable (eastbound_test.go:346), receiveEventually (:390) and the new unconditional payload asserts (:176-187) have never run on Floci. Fix: run `CB_SERVICE_TEST=actuation-service make test-service` at HEAD 013238ac on a31d6e08 and record pass/fail/skip per test in evidence.md.
- [High] [testable] gates/summary.txt: `test rc=2`, and evidence.md does not mention it. gates/test.log has 110 failing packages and 3044 "TEOS_DEPLOYMENT is \"local\" but AWS_ENDPOINT_URL is not set" errors. TEOS_DEPLOYMENT=local leaked into the unit-test run, so this looks like an environment problem, not this diff, but the gate is not shown green. Fix: rerun make test without TEOS_DEPLOYMENT set, and record rc=0, or the failures with a base comparison.
- [Medium] [non-testable] evidence.md: make test-integration (packet gate) is not recorded.
- [Medium] [non-testable] evidence.md, Marker search: the grep covers only the actuationsvc service-test folder. AC3 asks for a repo-wide rg before/after showing that the corerouter (27.16.3) and ingestionsvc (27.16.4) markers are untouched.
- [Medium] [non-testable] evidence.md: the AC1 OPEN items are not answered: which assertion depends on 17.x (#4563, find resources by tags; most likely the tagging lookup in waitForProviderQueueResolvable and the dispatcher's resolver), and confirmation that the tests use HTTP shadow updates, not MQTT.
- [Low] [non-testable] go-services/actuationsvc/deployment/service-test/go.mod:48 and go.sum: the indirect resourcegroupstaggingapi requirement comes from go mod tidy (tidy -diff is clean) but is outside the owns glob (eastbound_test.go only). Dev-lead should record that it accepts this; the change itself is correct.
- [Low] [non-testable] evidence.md: the "Test-review changes" section still describes waitForProviderQueueTags (ListQueueTags) and says the tagging SDK is "not in go.mod". 013238ac replaced both. Update the text.

Code itself (no change needed):
- eastbound_test.go:72, :250-251: the fixed sleeps are replaced by require.Eventually (60s, polling every 2s), which polls the resolver's own lookup (Queue, fd=egress, pn, pt=esv) and matches the queue ARN. It returns false on an error and logs it. Correct.
- eastbound_test.go:148, :307-308: receiveEventually is a require.Eventually around ReceiveMessages and fails with a message on timeout. The NotEmpty checks it replaces are now implicit, so nothing is weaker.
- eastbound_test.go:176-187: State, Desired, sensor presence, the float64 type and InDelta are now unconditional require/assert calls. Stronger than before.
- Leftover sleeps exist in westbound_test.go:63, eastbound_dispatcher_test.go:85 and helpers_test.go:237/:369, but those files are outside owns and outside this AC.

== Rationale ==
The code changes are right and make the tests stronger. The packet's gates are not shown for HEAD: the service test that proves AC1/AC4 last ran on pre-change code, make test failed (rc=2) with no explanation, and test-integration, the repo-wide AC3 rg and the AC1 17.x/HTTP note are missing. These need runs and evidence only, not code changes.
