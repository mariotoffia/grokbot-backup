# Hexagonal review: PR #1227 (T-27.16.2) @013238ac
Reviewer: hexagonal-reviewer minion (read-only) · 2026-10-22 (Europe/Stockholm)
Diff vs merge-base: 3 files: eastbound_test.go (+98/-42), service-test go.mod (+1), go.sum (+2). Test-only change, no production code.

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [High] [testable] impl/T-27.16.2/evidence.md:8, gates/summary.txt:6 — evidence.md now exists, but it only names the command `CB_SERVICE_TEST=actuation-service make test-service` and records no run or result. The gates/ directory has no test-service log. gates/test.log is the repo-wide `make test` (unit tests across go.work), and summary.txt shows `test rc=2` at HEAD 013238ac (failures in cmd/cbmonitor, providers/eastbound/*, tklocal/runner). The required Floci test-service gate is still unproven, and the recorded test gate failed. Fix: run `CB_SERVICE_TEST=actuation-service make test-service` on Floci a31d6e08 at 013238ac and record the commit, command, rc and PASS lines for the eastbound tests. Also explain or fix the rc=2 of `make test`, or show that it fails the same way on main.
- [Medium] [non-testable] .go-arch-lint.yml — there is still no map that covers actuationsvc (W-2026-0003). evidence.md says this openly, and manual review is the interim gate. Best possible verdict stays APPROVED_DEGRADED.
- [Low] [testable] go-services/actuationsvc/deployment/service-test/go.mod — the indirect resourcegroupstaggingapi dependency is outside the original owns. It is justified by tidy and has no architectural impact.
- [Info] eastbound_test.go:18,346-361 — the test imports go-core awsmgrres (the resolver's adapter-side paginator) to wait for the queue to become resolvable. That is acceptable for a black-box service test because it observes the infrastructure, not the domain internals.

== Status of earlier findings (from 1624a935) ==
1. Missing evidence / test-service unproven: PARTIALLY ADDRESSED. The file exists, but the gate result is missing and the test gate shows rc=2 (still High).
2. No lint-arch map for actuationsvc: OPEN (tracked under W-2026-0003, Medium, degraded).
3. Low: fixed 10s sleeps (eastbound_test.go:70,257): RESOLVED. There is no time.Sleep left. They are replaced by require.Eventually in waitForProviderQueueResolvable (:346) and receiveEventually (:400).
4. Low: no connectivity search test: OPEN (not addressed, still Low).

== Hexagonal checks ==
No production code changed, so port ownership and adapter thinness are unchanged from the earlier review. There is no domain leak and no new wiring. The tests drive the service through its external edges (HTTP/SQS/IoT on Floci).
go vet -tags integration,floci,e2e ./... in the service-test module at 013238ac: rc=0.

== Rationale ==
The architecture is clean. But a change cannot be approved while a required gate is unproven or failed. When the test-service run is shown to pass on Floci at this HEAD, the verdict becomes APPROVED_DEGRADED (because the lint-arch map is still missing).
