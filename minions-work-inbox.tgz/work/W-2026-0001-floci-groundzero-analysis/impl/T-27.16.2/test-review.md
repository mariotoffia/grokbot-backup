# T-27.16.2 test review: test-reviewer minion (msg-W-2026-0001-dev-lead-131)
PR: https://github.com/Thiink-LLC/teos/pull/1227. Head 1624a93503a05273eb863d2638c983e361442d4a matches the given SHA 1624a935 (commit 2026-10-22 12:51 CEST). Draft. CI: Architecture/CodeQL passed. Build, Static Analysis and Unit Tests were pending at review time.
File: go-services/actuationsvc/deployment/service-test/eastbound_test.go. `//go:build e2e` is present in eastbound_test.go:1 and main_test.go, per TESTS.md service tests.

## AC mapping
| AC | Mapped to | Status |
|---|---|---|
| 1 Both tests run and pass, rule output (queue) asserted with require.Eventually, no fixed sleep | TestEastboundClimateControlFlow, TestEastboundSSMFolderMapping (PR body: 4 ran / 4 passed / 0 skipped) | PARTIAL: fixed sleeps + hand-rolled poll, conditional asserts |
| 2 Both skips + markers deleted, no weakened assertion | diff :43 and :219 | MET |
| 3 corerouter/ingestionsvc marker untouched, with rg before/after in evidence | diff touches one file only, but no rg output was recorded | evidence MISSING |
| 4 Gate via CB_SERVICE_TEST=actuation-service make test-service, evidence in impl/T-27.16.2/evidence.md | PR body only. impl/T-27.16.2/evidence.md does not exist | evidence MISSING |

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [High] [testable] eastbound_test.go:70 and :257 — `time.Sleep(10 * time.Second)` for Tagging API propagation now runs on the local path, which contradicts AC1 "no fixed sleep". It is a flakiness risk, because tag indexing can be slower than 10 s. Fix: replace it with require.Eventually polling resourcegroupstaggingapi GetResources for the queue's tags (or the resolver's lookup).
- [Medium] [testable] helpers_test.go:232-237 (pollSQSMessages, used at :146, :313, :317) — a deadline loop with time.Sleep(5s) and the real clock, not require.Eventually as AC1 specifies. The 30 s window for the SSM queue at :317 is tight after a 120 s chain. Fix: switch to require.Eventually (or an ESCALATION: conflict if the helper is outside the owns glob), and size the :317 window like :313.
- [Medium] [testable] eastbound_test.go:176-192 — the rule-output payload checks are conditional. If State.Desired is nil, or the sensor is missing or of the wrong type, the test only logs and passes, so "the real rule output is asserted" is weaker than it reads. Fix: require.NotNil State.Desired and require that the sensor key is present, then InDelta. If that reveals an emulator difference, record it.
- [Medium] [non-testable] impl/T-27.16.2/evidence.md — missing. AC3's repo-wide `rg "HTTP shadow updates reaching topic rules" go-services/` before/after, the digest inspect output, and the gates (fmt/lint/vet/test/tidy) are not recorded, and CI Build/Unit were still pending for 1624a935. Fix: write evidence.md for HEAD 1624a935 with those outputs.
- [Low] [non-testable] eastbound_test.go:127, :298 — time.Now() in event payloads. It is only data, and nothing is asserted on it. No action.

== Rationale ==
The un-skip is correct and narrow, uses the right e2e tag and naming, and the PR body reports both target tests passing on digest a31d6e08. AC1 is only partly met: fixed 10 s sleeps and a sleep-loop poller now gate the local run, and the payload assertions can pass without checking anything. AC3 and AC4 require evidence in impl/T-27.16.2/evidence.md, and that file does not exist. The fixes are small, but the brief names them explicitly.

---
## Re-review @013238ac (msg-W-2026-0001-dev-lead-146)
Head 013238acf414ab26f5f16552a063fd5a0987a374 matches the given SHA 013238ac. Diff since 1624a935: eastbound_test.go (+98/-32), plus go.mod and go.sum (indirect resourcegroupstaggingapi v1.31.12, through tidy, outside the original owns; dev-lead to note it). CI at review time: Build, Architecture and CodeQL passed. **Unit Tests and Static Analysis were IN_PROGRESS.**

### Earlier findings
| Earlier finding | Status |
|---|---|
| time.Sleep(10s) at :70/:257 | RESOLVED. Replaced by waitForProviderQueueResolvable: require.Eventually (60 s / 2 s) over the Tagging GetResources paginator with the resolver's filters (Queue, fd=egress, pn, pt=esv), matching the ARN. This is better than a sleep, because it waits on the dispatcher's real lookup. |
| pollSQSMessages sleep loop | RESOLVED for the eastbound tests: receiveEventually is require.Eventually (2 s tick, 1 s long-poll). The shared helper is unchanged and outside owns. |
| Tight 30 s SSM window (:308) | OPEN (Low). Still 30 s, but it starts after the bundled message has arrived, which is the same dispatch, so the risk is low. |
| Conditional payload asserts :176-192 | RESOLVED. State, Desired, sensor-present and float64 are require calls, and InDelta is an assert. |
| evidence.md + AC3 rg before/after | RESOLVED. Before/after are in evidence.md, and I confirmed: no "HTTP shadow updates reaching topic rules" marker is left in actuationsvc, and corerouter mirror_test.go:44/:218 and ingestionsvc ingestion_test.go:44 are untouched. |
| Gate results | **NOT GREEN.** gates/summary.txt for HEAD 013238ac reports `test rc=2`. test.log shows cmd/cbmonitor and tklocal tests failing with "TEOS_DEPLOYMENT is local but AWS_ENDPOINT_URL is not set", which looks like environment leaking into the gate shell rather than this diff. Also, no `CB_SERVICE_TEST=actuation-service make test-service` result is recorded at 013238ac. The 4/4 pass in the PR body was on an earlier commit, before the new helpers. |

### New flakiness check
- receiveEventually: the condition writes the captured `messages` from testify's goroutine, and the value is read only after Eventually returns true, so there is no race on success. Each ReceiveMessages call leaves received messages invisible (no delete). That is fine, because the call returns as soon as it gets any.
- The tagging wait builds a new paginator on every tick, and a page error returns false, so it retries. It has a bounded 60 s timeout. No shared globals. queueARNFromURL exists in helpers_test.go:113.
- No sleeps, no real-clock assertions, and no assertions on map order (mapKeys is used only in a message).

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [High] [non-testable] impl/T-27.16.2/gates/summary.txt — `make test` rc=2 at HEAD 013238ac. Failures are in cmd/cbmonitor/bundle_test.go:54/:79/:115 and tklocal packages, because TEOS_DEPLOYMENT=local leaked into the shell without AWS_ENDPOINT_URL. Fix: rerun `make test` in a clean env (unset TEOS_DEPLOYMENT/AWS_ENDPOINT_URL), record rc=0, and wait for the CI Unit Tests check to go green.
- [High] [non-testable] impl/T-27.16.2/evidence.md — AC4 has no evidence at HEAD. `CB_SERVICE_TEST=actuation-service make test-service` was not rerun after the new helpers (013238ac adds a 60 s tagging wait that has never run on Floci). Fix: rerun on digest a31d6e08 and record run/pass/skip per test for 013238ac.
- [Low] [hard-to-test] go-services/actuationsvc/deployment/service-test/eastbound_test.go:308 — the SSM queue window is still 30 s. Fix: optionally make it 60 s. Not blocking.
- [Low] [non-testable] go-services/actuationsvc/deployment/service-test/go.mod:48 — an indirect dependency was added outside the original owns. It is tidy-driven, so the code is fine. Fix: dev-lead acknowledges the owns widening in the packet or STATUS.

== Rationale ==
All test-quality findings from the first review are fixed. Both waits are now bounded require.Eventually polls on the real conditions, and the payload assertions are unconditional. I found no new flakiness in the fixes. The remaining blockers are evidence only: the unit-test gate is red at HEAD (most likely an env leak, not this diff), and the Floci service-test gate was not rerun on the commit that changed the waits. Once both are green and recorded for 013238ac, this moves to APPROVED with no code change.
