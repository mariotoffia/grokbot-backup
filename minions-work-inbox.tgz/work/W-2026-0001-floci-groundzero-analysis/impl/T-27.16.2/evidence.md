# T-27.16.2 evidence: golang-pro (P-2026-0001-35)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-2-shadow-topic-rules-actuation
Branch: chore/W-2026-0001-t27-16-2-shadow-topic-rules-actuation (base origin/main db06a87b)
Draft PR: https://github.com/Thiink-LLC/teos/pull/1227
Commits: dd76a37f (remove the skips and markers), 1624a935 (remove the blank lines), 2b092f96 (require.Eventually instead of sleeps, unconditional payload asserts, per test-review msg-135)
Floci: TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1. AWS_CONFIG_FILE and AWS_SHARED_CREDENTIALS_FILE were /dev/null. No real-AWS runs.
Service test name: actuation-service (`CB_SERVICE_TEST=actuation-service make test-service`)

## AC3 marker search (repo-wide)
`rg -n "floci: Missing Implementation for HTTP shadow" .` at the repo root, worktree HEAD 013238ac:
- before (db06a87b): the actuationsvc hits were eastbound_test.go:43 and :219
- after: **no actuationsvc hits**. The remaining hits are out of scope (27.16.3 corerouter, 27.16.4 ingestionsvc, and a doc example): SERVICE_TEST_WRITING.md:122, go-services/ingestionsvc/deployment/service-test/ingestion_test.go:44, go-services/corerouter/deployment/service-test/mirror_test.go:44 and :218.

## AC1 notes (OPEN items)
- 17.x (#4563, find resources by their own tags): the eastbound dispatcher's queue resolver (actuationcore/queue-resolver-impl.go lookupProvider, Resource Groups Tagging GetResources with fd/pn/pt) depends on it, and so does the test's readiness check `waitForProviderQueueResolvable`, which makes the same lookup. The "message arrives on the fake provider queue" assertions in both tests depend on it.
- HTTP vs MQTT: the shadow update is made over HTTP. The climate-control Lambda updates the shadow through the IoT data plane HTTP API (iotdataplane, go-core/managers/mgriot/awsmgriot dsmanager). `rg -il mqtt go-services/actuationsvc` finds nothing. No MQTT scope.

## Test-review changes (msg-135, P-2026-0001-37)
- The fixed `time.Sleep(10s)` calls are replaced by `waitForProviderQueueResolvable` (commit 013238ac). It runs require.Eventually (60s, polling every 2s) over go-core's awsmgrres resource paginator (Resource Groups Tagging GetResources) with the resolver's filters: resource type Queue, fd=egress, pn=<provider>, pt=esv. It waits until the queue's ARN is returned, and the event is published only after that. The intermediate ListQueueTags helper from 2b092f96 is gone (Copilot r4347573850, replied and resolved).
- The eastbound tests use `receiveEventually` (require.Eventually) instead of `pollSQSMessages`. The shared helper in helpers_test.go is unchanged, because it is outside owns.
- The DsFullBuilding State, Desired, sensor-present, float64 and InDelta checks are now unconditional.
- **Accepted out-of-owns change:** service-test go.mod and go.sum gain the indirect `github.com/aws/aws-sdk-go-v2/service/resourcegroupstaggingapi v1.31.12`, which comes from go-core through go mod tidy and is required for the tidy gate. It is stated in the PR body.

## Gates
lint-arch ran and passed; no map covers go-services/actuationsvc/deployment/service-test (W-2026-0003). Interim arch gate: hexagonal-reviewer and clean-arch-reviewer (clean-arch APPROVED, msg-138).
Results are in impl/T-27.16.2/gates/summary.txt, with one log per gate in the same directory (see the final section below).
Note: the first gate runs (12:59) were invalid, because /workspace/lintarch/run.sh had deleted the gitignored sur model files (msg-142). Those files were regenerated at 13:20, and all gates were rerun one after another.

