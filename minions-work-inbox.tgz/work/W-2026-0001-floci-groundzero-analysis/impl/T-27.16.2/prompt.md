Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# Minion prompt — TEOS 27.16.2: test(actuation): run the shadow topic rule tests on Floci

You are the golang-pro minion working in **Thiink-LLC/teos** on the shared computer. This prompt is self-contained; the packet (P-2026-0001-35) wins over anything here.

## Setup
- Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-2-shadow-topic-rules-actuation` on branch **`chore/W-2026-0001-t27-16-2-shadow-topic-rules-actuation`**, based on current origin/main after the M1 merges (#1212-#1215); run `git fetch` first. The box's local origin/main ref (863b6019) predates those merges. Not created yet: create it yourself under the go-approved start gate (packet start_gate), reserve the lock in registry/locks.json first.
- Symlink `.env` to the repo's gitignored `.env` as in the other W-2026-0001 worktrees. Never print, cat, copy, `git add` or commit it; never replace the symlink.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `SERVICE_TEST.md`, `SERVICE_TEST_WRITING.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`, and the local docs of the touched module. They are authoritative. Then `/workspace/minions/CONVENTIONS.md` (§0, §1, §A/§C, §I) and `/workspace/minions/TEOS_CONVENTIONS.md`.
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`.
- Floci image pin: `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1` (new mariotoffia/floci:latest with the Floci Task 48 fix). Confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:a31d6e08`; otherwise stop with `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins (they stay `:latest`).

## Goal
Run the actuation service eastbound tests on the local Floci target. Floci 19.1 (floci-io/floci#5260, IoT shadow events through topic rules, merged 2026-10-17) and 17.x (#4563, tagging: find resources by their own tags, merged 2026-09-30) are in the pinned image. Remove the `HTTP shadow updates reaching topic rules` skips and their markers at eastbound_test.go:43 and :219, and assert the real rule output (queue). The 19.1 marker text is shared with 27.16.3 (corerouter) and 27.16.4 (ingestionsvc); this task removes only the actuationsvc sites.

## Before you code
Not re-checked by dev-lead on current main. Known from the sources: markers at go-services/actuationsvc/deployment/service-test/eastbound_test.go:43 and :219. Re-read on fresh main; if gone, ESCALATION: already-done.

## Files you may change
- `go-services/actuationsvc/deployment/service-test/eastbound_test.go`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Service test (actuationsvc, local Floci on the pinned digest): the tests behind the skips at eastbound_test.go:43 and :219 run (not skipped) and pass; an HTTP shadow update reaches the topic rule and the real rule output (queue) is asserted with require.Eventually (no fixed sleep).
2. Both local skips and their `floci: Missing Implementation for` markers in eastbound_test.go are deleted; no assertion is weakened.
3. The same 19.1 marker in corerouter (27.16.3) and ingestionsvc (27.16.4) is untouched; evidence shows a repo-wide rg before/after.
4. Floci-local gate: the un-skipped tests pass locally on mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `CB_SERVICE_TEST=<actuationsvc> make test-service`; evidence in impl/T-27.16.2/evidence.md.

## OPEN items
- OPEN: the CB_SERVICE_TEST value for actuationsvc is not in the sources (event-service, collector-service, device-service are); take it from SERVICE_TEST.md and record it in evidence.md.
- OPEN: what exactly 17.x (#4563) is needed for in these tests is not stated in the sources; note which assertion depends on it.
- OPEN: ANALYSIS.md notes a shadow update over MQTT may still not reach rules; the tests only need HTTP. Do not add MQTT scope; if a test turns out to use MQTT, ESCALATION: verify-failed with the error.
- OPEN: owns lists only eastbound_test.go; if a helper in the package must change, ESCALATION: conflict first.

## How to work
- Architecture: every TEOS project is **DDD + hexagonal (ports & adapters) + clean architecture**. Keep test helpers in the test package, reuse testutils/svctest, do not pull adapters or SDK types into domain/ports.
- **TDD**: start from the test-designer's test plan (impl/T-27.16.2/test-plan.md) when present; see the test fail for the right reason, make the minimal change, then green.
- **Systematic debugging** on any failure: reproduce, read the full error, one hypothesis at a time, fix the root cause. No retries-until-green, no new skips, no weakened assertions, no fixed sleeps. If the un-skipped test fails on the pinned image, reply `ESCALATION: verify-failed` with the full error.
- Comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English.

## Gates — CONVENTIONS.md §1 / TEOS_CONVENTIONS.md §1 (all must pass; commands + pass/fail in evidence.md)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint and lint-arch; lint-arch is unavailable for this package (backlog W-2026-0003; no lint-arch map covers it): interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=<actuationsvc service-test name> make test-service`
Marker check: `rg -n "floci: Missing Implementation for" go-services/actuationsvc/deployment/service-test/ ; rg -n "HTTP shadow updates reaching topic rules" go-services/`

## Commit / PR rules
- Conventional commit titled like `test(actuation): run the shadow topic rule tests on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets, never print `.env`.
- At the **first commit**, golang-pro pushes the branch and opens a **draft** PR to main (title prefixed W-2026-0001, labels build, unit-test, lint; body links this task and STATUS.md, records the image digest). Keep pushing as work progresses. **No force-push, never merge, never push to main.**
- PR body records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable for this package (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest a31d6e08); no real-AWS runs".
- Mark ready only after the internal reviews pass; then Copilot review and green workflows. Mario merges.

## Stop condition
Commit(s) pushed to `chore/W-2026-0001-t27-16-2-shadow-topic-rules-actuation`, draft PR open, all gates green, evidence in `/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.16.2/evidence.md`. Reply `done` to dev-lead in the ⟦MINION v1⟧ envelope.

## ESCALATION convention
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done. Details below that line. Do not work around the problem.
