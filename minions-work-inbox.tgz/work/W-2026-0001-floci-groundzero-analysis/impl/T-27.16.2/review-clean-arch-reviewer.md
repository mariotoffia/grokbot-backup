# Clean Architecture review (interim arch gate): T-27.16.2, PR #1227
Reviewer: clean-arch-reviewer minion · Request: msg-W-2026-0001-dev-lead-133 · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-2-shadow-topic-rules-actuation · Requested HEAD 1624a935 (commits dd76a37f, 1624a935). Real base: db06a87b (fresh origin/main after M1, not a3543337). Floci only; no GitHub posts.

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] go-services/actuationsvc — no .go-arch-lint.yml covers actuationsvc. `make lint-arch` (PATH=$HOME/go/bin:$PATH, after make install/dep/generate, which failed for environment reasons: apt 500, corepack permission, docker.sock permission; 45 tracked generated files deleted by generate were restored, tree clean): rc=0, 9 Makefiles / 10 maps OK, but none covers this diff. The hand-built import map is the evidence. Fix: none here.
- [Low] [non-testable] impl/T-27.16.2/ — the brief folder has no evidence.md yet. Fix: golang-pro adds it before the PR leaves draft.
- [Info] HEAD moved to 2b092f96 after the request (+71/-33, same file). I read it: test-only, it adds sqs, sqstypes and ifcore imports inside the service-test package (an e2e test calling AWS APIs, correct layer), replaces a fixed 10s sleep with polling, and tightens the shadow assertion. No arch concern. The code-reviewer minion should review it in full.
- Out of scope: port and adapter shape (hexagonal-reviewer) and aggregates (ddd-reviewer); the diff has neither.

Test-only claim: confirmed. db06a87b..1624a935: 1 file, go-services/actuationsvc/deployment/service-test/eastbound_test.go (`//go:build e2e`, inside the owns glob), 10 deletions: the two local skips and their markers at :43 and :219. No production code changed, and the corerouter/ingestionsvc markers were not touched.

Arch map: the change adds or removes no import at 1624a935. The service test imports only the svctest harness, go-core ctx/cbenv and the AWS SDK. It imports no actuationsvc domain, application or handler package. No .go-arch-lint.yml, ADR or go.mod change.

== Rationale ==
Removing two skip guards from an e2e service test cannot invert a dependency or contaminate a domain. The follow-up commit stays inside the test layer. Whether Floci really delivers HTTP shadow updates to topic rules is a question of marker evidence for code-reviewer and qa-lead.
