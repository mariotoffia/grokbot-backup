Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.16.2 — test(actuation): run the shadow topic rule tests on Floci

Work item: W-2026-0001 · Packet: P-2026-0001-35 · Implementer: golang-pro (minion, shared computer) · Tests: test-designer · Reviews: code-reviewer + hexagonal-reviewer + clean-arch-reviewer
Repo: Thiink-LLC/teos · Base: current origin/main after the M1 merges (#1212-#1215); run `git fetch` first. The box's local origin/main ref (863b6019) predates those merges · Branch: `chore/W-2026-0001-t27-16-2-shadow-topic-rules-actuation` · Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-2-shadow-topic-rules-actuation`
Floci image: `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1`

## Goal
Run the actuation service eastbound tests on the local Floci target. Floci 19.1 (floci-io/floci#5260, IoT shadow events through topic rules, merged 2026-10-17) and 17.x (#4563, tagging: find resources by their own tags, merged 2026-09-30) are in the pinned image. Remove the `HTTP shadow updates reaching topic rules` skips and their markers at eastbound_test.go:43 and :219, and assert the real rule output (queue). The 19.1 marker text is shared with 27.16.3 (corerouter) and 27.16.4 (ingestionsvc); this task removes only the actuationsvc sites.

## Pre-check note
Not re-checked by dev-lead on current main. Known from the sources: markers at go-services/actuationsvc/deployment/service-test/eastbound_test.go:43 and :219. Re-read on fresh main; if gone, ESCALATION: already-done.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-services/actuationsvc/deployment/service-test/eastbound_test.go`

## Acceptance criteria (as regression-test behaviour)
1. Service test (actuationsvc, local Floci on the pinned digest): the tests behind the skips at eastbound_test.go:43 and :219 run (not skipped) and pass; an HTTP shadow update reaches the topic rule and the real rule output (queue) is asserted with require.Eventually (no fixed sleep).
2. Both local skips and their `floci: Missing Implementation for` markers in eastbound_test.go are deleted; no assertion is weakened.
3. The same 19.1 marker in corerouter (27.16.3) and ingestionsvc (27.16.4) is untouched; evidence shows a repo-wide rg before/after.
4. Floci-local gate: the un-skipped tests pass locally on mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `CB_SERVICE_TEST=<actuationsvc> make test-service`; evidence in impl/T-27.16.2/evidence.md.

## OPEN items (scope not settled in the sources)
- OPEN: the CB_SERVICE_TEST value for actuationsvc is not in the sources (event-service, collector-service, device-service are); take it from SERVICE_TEST.md and record it in evidence.md.
- OPEN: what exactly 17.x (#4563) is needed for in these tests is not stated in the sources; note which assertion depends on it.
- OPEN: ANALYSIS.md notes a shadow update over MQTT may still not reach rules; the tests only need HTTP. Do not add MQTT scope; if a test turns out to use MQTT, ESCALATION: verify-failed with the error.
- OPEN: owns lists only eastbound_test.go; if a helper in the package must change, ESCALATION: conflict first.

## TEOS_CONVENTIONS checklist: §A (existing uService go-services/actuationsvc; service-test change only, no new service) + §I
- CONVENTIONS.md §0/§1: DDD + hexagonal (ports & adapters) + clean architecture; dependencies point inward; no adapter/SDK leaks into domain or ports. Test-only change, but reviewers check the boundaries anyway.
- TEOS §0: `make dep` + `make generate` first in a fresh worktree; per-module make targets (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil + deployment/lib/svctest; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change; never hand-edit go.mod.
- §I: integration tests tagged integration (+floci); service tests live in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:a31d6e08). A local skip is not evidence. No real-AWS run.
- No §B, §D or §E: no third-party adapter, web app or CLI is touched.
- Secrets: `.env` in the worktree is a symlink to /workspace/repos/teos/.env (gitignored). Never print, cat, copy, `git add` or commit it; do not replace the symlink. No secrets in code, logs, commits or chat.
- Commits: conventional commits, **no byline / Co-Authored-By / AI co-author trailer**, no GitHub closing keywords.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint and lint-arch; lint-arch is unavailable for this package (backlog W-2026-0003; no lint-arch map covers it): interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `CB_SERVICE_TEST=<actuationsvc service-test name> make test-service`
- Arch gate: where no lint-arch map covers the package (backlog W-2026-0003), the interim arch gate is the standard linter **plus** hexagonal-reviewer and clean-arch-reviewer sign-off. The PR body must state this.

## Evidence a done reply needs
- Floci image digest used (`docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:a31d6e08`).
- Tests run vs skipped, per package (skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-services/actuationsvc/deployment/service-test/ ; rg -n "HTTP shadow updates reaching topic rules" go-services/`.
- `git diff --stat origin/main..HEAD` (owns-glob files only).
- Draft PR URL.

## Commit / PR rules
- Conventional commit titled like `test(actuation): run the shadow topic rule tests on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets, never print `.env`.
- At the **first commit**, golang-pro pushes the branch and opens a **draft** PR to main (title prefixed W-2026-0001, labels build, unit-test, lint; body links this task and STATUS.md, records the image digest). Keep pushing as work progresses. **No force-push, never merge, never push to main.**
- PR body records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable for this package (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest a31d6e08); no real-AWS runs".
- Mark ready only after the internal reviews pass; then Copilot review and green workflows. Mario merges.
