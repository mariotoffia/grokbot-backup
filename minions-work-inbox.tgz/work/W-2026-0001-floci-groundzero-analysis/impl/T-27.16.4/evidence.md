# T-27.16.4 evidence — BLOCKED (Floci gap)

- Issue: https://github.com/Thiink-LLC/teos/issues/1232 (assignee mariotoffia; labels unit-test, e2e, core; Priority=Medium, Size=Hours; R&D Sprint Board Status=Incoming — gates/issue-verify.log)
- Worktree /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-4-ingestion-firehose-logs, branch chore/W-2026-0001-t27-16-4-ingestion-firehose-logs, base origin/main dc86df55.
- Local commit f7acb910 (author Mario Toffia, no trailer). NOT pushed, no PR: the task stopped on a Floci gap per the brief.
- Image: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1, Floci only (AWS config/credentials files /dev/null).
- make dep rc=0, make generate rc=0 (gates/generate.log; attempt 1 failed at tklocal react-build before make dep, gates/generate-attempt1.log).

## TDD red (gates/test-service-run1.log, rc=1, 17:12-17:15 CEST)
Skip removed. The HTTP shadow update now reaches the IoT rule and Firehose (Floci 19.1 works): an S3 object
ingestion/.../ingestionsvc-delivery-stream-1-...gz (225 bytes) and its SNS notification arrive. But:
1. The object holds the raw shadow document, not transformed CbSensorReportItem NDJSON: storeloader parses 1 item with every field empty (bn="" sn="" v=nil). The original assertion "expected at least one CbSensorReportItem for thing ..." fails (ingestion_test.go:294).
2. DescribeDeliveryStream: ExtendedS3DestinationDescription.ProcessingConfiguration is nil (new assertion sinks_helpers_test.go:52 "Lambda processing must be configured").

## Cause: Floci gap, not our code (gates/floci-gap-source.log)
Floci's CloudFormation provisioner for AWS::KinesisFirehose::DeliveryStream (FirehoseCfnProvisioner.java:39-59, unchanged since 2026-10-02; same on floci main 5beb8d47b, 2026-10-22 05:09 CEST) reads only CompressionFormat, BucketARN, Prefix and BufferingHints from ExtendedS3DestinationConfiguration. It drops ProcessingConfiguration (the Lambda transform), CloudWatchLoggingOptions, ErrorOutputPrefix and RoleARN. The Firehose API path supports the Lambda transform (FirehoseLambdaTransformer, floci #3393), so a stream created by CreateDeliveryStream would transform; a CDK/CFN-created one never does. The transform Lambda is never invoked, so there is no Lambda Logs output either.

Proposed Floci task: FirehoseCfnProvisioner must forward ProcessingConfiguration (Processors/Parameters incl. LambdaArn with intrinsics), CloudWatchLoggingOptions, ErrorOutputPrefix and RoleARN on create and update. When it lands and the image is rebuilt, rerun gates on f7acb910 (no test change expected).

## Gates
Not run past the red service test (task stopped on the gap). Lock 27.16.4 released as blocked.

## Resume (msg-293, 2026-10-23 CEST) — DONE
- floci:latest sha256:07ced9c6d987de7ca432fa35d0f1856ad1c8c87a4fdb96ac3b00b6e68bba2ba1; FG-1 fixed (ProcessingConfiguration honoured, transform Lambda logs 2 events).
- gates/test-service-f7acb910-07ced9c6-run3.log rc=0 (11:09-11:17); gates/test-service-ce280894-07ced9c6.log rc=0 (-race, 0 DATA RACE).
- gates/static-f7acb910.log: gofmt/vet/tidy rc=0; golangci-lint found 2 forbidigo (context.Context) -> fixed in ce280894, 0 issues; root make lint-arch rc=0 (9 maps). No integration package in this module.
- Draft PR https://github.com/Thiink-LLC/teos/pull/1255 (Closes #1232), HEAD ce280894.
