Scope: Floci-only; no real-AWS runs (devlocal included).

# T-27.16.4 — test(ingestionsvc): run the ingestion pipeline service test on Floci and assert Firehose/Logs output

Work item: W-2026-0001 · Packet set: P-2026-0001-39..44 (stream 1; packet files not present in packets/, scope taken from the dev-lead brief + w3-w4-plan.md) · Implementer: golang-pro · start_gate: Mario's go relayed by dev-lead 2026-10-22 16:44 (STATUS.md go-approved)
Repo: Thiink-LLC/teos · Base: origin/main dc86df55 · Branch: chore/W-2026-0001-t27-16-4-ingestion-firehose-logs
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-4-ingestion-firehose-logs
Floci image: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1

## Scope
- Remove the local skip at go-services/ingestionsvc/deployment/service-test/ingestion_test.go:44 (marker "floci: Missing Implementation for HTTP shadow updates reaching topic rules").
- Add assertions on real sink output: Firehose delivery stream (ACTIVE, Lambda processor + GZIP S3 delivery, CloudWatch logging wired to /aws/firehose/ingestionsvc-delivery-stream) and CloudWatch Logs (transform Lambda log group has events from the run; Firehose delivery-errors and IoT rule error log groups have no error events for the run).

## Acceptance criteria
1. Skip and marker removed; no existing assertion weakened.
2. TestIngestionServiceFlow passes on Floci (resolved digest) with -race, CB_SERVICE_TEST=ingestionsvc service test.
3. New Firehose + Logs assertions fail (red) without real output and pass (green).
4. No new skips. Gates: fmt/lint/vet, go-arch-lint direct, make test (clean env), tidy clean, service test -race.
