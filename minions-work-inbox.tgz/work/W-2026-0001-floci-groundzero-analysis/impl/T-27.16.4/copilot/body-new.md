Closes #1232

**Depends on #1257** for the ingestionsvc go-arch-lint map (service-level lint-arch is n/a until #1257 merges).

Removes the Floci skip from the ingestionsvc service test. The test now checks the Firehose transform Lambda and the CloudWatch Logs output on Floci (`mariotoffia/floci:latest`, fresh pull, digest 07ced9c6 is recorded in the evidence, not in code). FG-1 is fixed on that image.

Review fixes: L1 removes the unused DescribeLogGroups call. L2 adds the named constant `runStartClockSkew`.

Gates at HEAD 849de752 (log headers hold the sha, dir and command):

| Gate | rc | Log |
|---|---|---|
| gofmt | 0 | impl/T-27.16.4/gates/gofmt-849de752.log |
| go vet | 0 | impl/T-27.16.4/gates/vet-849de752.log |
| golangci-lint | 0 (0 issues) | impl/T-27.16.4/gates/golangci-849de752.log |
| make lint (repo) | 0 | impl/T-27.16.4/gates/make-lint-849de752.log |
| lint-arch (root) | 0 | impl/T-27.16.4/gates/lint-arch-root-849de752.log |
| lint-arch (service) | n/a: ingestionsvc has no map yet, see #1256 / #1257 | impl/T-27.16.4/gates/lint-arch-service-849de752.log |
| make test | 0 | impl/T-27.16.4/gates/make-test-849de752.log |
| go mod tidy | 0 | impl/T-27.16.4/gates/tidy-849de752.log |
| test-service -race (Floci) | 0 (TestIngestionServiceFlow PASS, 0 data races) | impl/T-27.16.4/gates/test-service-849de752-07ced9c6.log |
| test-integration | none: ingestionsvc has no integration-tagged package | impl/T-27.16.4/gates/test-integration-849de752.log |


