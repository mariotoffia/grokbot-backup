#!/usr/bin/env bash
# usage: svcroot.sh <worktree> <service-test-dir-rel> <CB_SERVICE_TEST> <logfile> [extra go test args]
# Runs one Floci service test as root (GROKBOT.md recipe) under the exclusive floci-harness-run lock.
WT=$1; D=$2; SVC=$3; LOG=$4; shift 4
L=/workspace/minions/registry/locks.json; HOLDER="core-svc-dev T-27.16.4 #1255 copilot-r3 $SVC"
take(){ python3 - "$HOLDER" <<'P'
import json,sys,datetime,fcntl
p='/workspace/minions/registry/locks.json'
with open(p,'r+') as f:
  fcntl.flock(f,fcntl.LOCK_EX); d=json.load(f)
  if any(e['task']=='floci-harness-run' and e.get('status')!='released' for e in d['locks']): sys.exit(1)
  d['locks'].append({'work_id':'W-2026-0001','task':'floci-harness-run','globs':['<exclusive Floci service/integration harness run>'],'holder':sys.argv[1],'since':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'state':'active','status':'active'})
  f.seek(0);json.dump(d,f,indent=2);f.truncate()
P
}
rel(){ python3 - "$HOLDER" <<'P'
import json,sys,datetime,fcntl
p='/workspace/minions/registry/locks.json'
with open(p,'r+') as f:
  fcntl.flock(f,fcntl.LOCK_EX); d=json.load(f)
  for e in d['locks']:
    if e['task']=='floci-harness-run' and e.get('holder')==sys.argv[1] and e.get('status')=='active':
      e['status']=e['state']='released';e['released']=datetime.datetime.now().astimezone().isoformat(timespec='seconds')
  f.seek(0);json.dump(d,f,indent=2);f.truncate()
P
}
echo "wrapper start $(date '+%F %T %Z')"
echo "dir $WT/$D"
echo "cmd $0 $WT $D $SVC $LOG $*"
echo "holder $HOLDER"
until take; do sleep 30; done
echo "registry lock taken $(date '+%F %T %Z')"
trap rel EXIT
cd $WT/$D
{
echo "HEAD $(git rev-parse HEAD)"
echo "image $(sudo docker image inspect mariotoffia/floci:latest --format '{{index .RepoDigests 0}}')"
echo "start $(date '+%F %T %Z')"
echo "dir $PWD"
echo "cmd sudo env -i HOME=/root PATH=/usr/local/go/bin:/home/box/.local/bin:/home/box/go/bin:/usr/local/bin:/usr/bin:/bin GOCACHE=/root/.cache/go-build GOMODCACHE=/root/go/pkg/mod COREPACK_HOME=/home/box/.cache/corepack GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=* AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE=/dev/null CB_SERVICE_TEST=$SVC go test -tags=e2e,floci -count=1 -v -race -timeout ${GOTEST_TIMEOUT:-60m} $* ./..."
sudo env -i HOME=/root PATH=/usr/local/go/bin:/home/box/.local/bin:/home/box/go/bin:/usr/local/bin:/usr/bin:/bin \
  GOCACHE=/root/.cache/go-build GOMODCACHE=/root/go/pkg/mod COREPACK_HOME=/home/box/.cache/corepack \
  GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="*" AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE=/dev/null CB_SERVICE_TEST=$SVC \
  go test -tags=e2e,floci -count=1 -v -race -timeout ${GOTEST_TIMEOUT:-60m} "$@" ./... 2>&1
echo "rc=$?"
echo "end $(date '+%F %T %Z')"
} > $LOG 2>&1
sudo chown -R box: $WT
echo "test log $LOG"
echo "$(grep -E '^rc=' $LOG | tail -n 1)"
echo "wrapper end $(date '+%F %T %Z') (registry lock released on exit)"
