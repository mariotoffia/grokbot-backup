# T-39.11 task (golang-pro, stream 2)

Issue: https://github.com/Thiink-LLC/teos/issues/1233
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t39-11-gobridge-observability-skips (branch chore/W-2026-0001-t39-11-gobridge-observability-skips)
start_gate: Mario go relayed by dev-lead 16:44 (STATUS.md go-approved line).

## Scope
Delete the two local skips in `go-services/core/brokers/gobridge/deployment/service-test/recovery_observability_test.go`:
- TestDeployed_ControlAbsenceAlarmReachesAlarmAndClears (marker `floci: Missing Implementation for ECS Container Insights metrics`)
- TestDeployed_RejectedReloadIsCountedByTheLogMetricFilter (marker `floci: Missing Implementation for the ECS awslogs log group`)

## Acceptance criteria
1. Both skips and markers are removed; no assertion is weakened.
2. Both tests run and pass in the gobridge-service service test on Floci `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1` (about 60 minutes).
3. No new skips. If Floci still lacks either feature, the task reports blocked with evidence instead.
