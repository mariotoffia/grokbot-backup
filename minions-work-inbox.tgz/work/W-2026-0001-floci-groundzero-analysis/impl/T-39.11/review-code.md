# Code review — PR #1234 (T-39.11) @ 028f6a4b, Floci a31d6e08
Reviewer: the Code Reviewer minion (code-reviewer), read-only. df -h /: 42% used at 19:06 (Europe/Stockholm).
Base: fresh merge-base with origin/main; 1 commit, 1 file (-8). PR head = 028f6a4b (gh).

== Verdict ==
APPROVED

== Findings ==
- [Medium] [non-testable] impl/T-39.11/evidence.md is missing, but the PR body links to it. Fix: golang-pro writes evidence.md (gates, service-test result, attempt history).
- [Low] [non-testable] gates/summary-028f6a4b.txt still says "test rc=2", which is stale. test-028f6a4b-rerun.log (19:03, HEAD 028f6a4b) is rc=0, "All checks passed". The first run's rc=2 was package-load "[setup failed]" (environment, not code). Fix: update the summary.
- [Low] [non-testable] PR #1234 body says the 60-minute Floci run "is in progress". It has finished (PASS). Fix: update the body (author action).
- [Low] [hard-to-test] recovery_observability_test.go:174, 273 — ControlAbsence (331s) and the log metric filter test (47s) are now on the Floci path, which makes the suite about 21 min. No action; note it for serial scheduling.
- [Info] Arch: gobridge map covers the module (lint-arch-028f6a4b.log OK). The service-test runs through `make test-service` without -race (the known jsii-runtime race in the gobridge harness). This is accepted.
- [Info] Specialist: resilience-auditor, optional, for the alarm/recovery semantics. Not needed for this skip removal.

== Issue link ==
Body has "Closes #1233", and closingIssuesReferences=[1233]. Issue #1233 "W-2026-0001 T-39.11: gobridge observability tests on Floci (remove 2 skips)" is OPEN and correct.

== Gates (impl/T-39.11/gates/, stamped HEAD 028f6a4b) ==
fmt 0 · vet 0 (e2e and e2e,floci) · golangci-lint 0 · lint-arch 0 · make test 0 (rerun log; env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL) · tidy 0, clean ·
Floci service test (test-service-028f6a4b.log, 17:53, git clean, TEOS_DEPLOYMENT/AWS_ENDPOINT_URL unset): 9/9 PASS including TestDeployed_ControlAbsenceAlarmReachesAlarmAndClears and TestDeployed_RejectedReloadIsCountedByTheLogMetricFilter, 0 SKIP, ok. Attempts 1-6 failed on environment issues (cdk, iam dist, ECR login, ENOSPC) and are superseded.

== Copilot ==
0 review threads (GraphQL reviewThreads=[]). There is 1 Copilot review, COMMENTED, on 028f6a4b.

== Rationale ==
This is a pure skip removal: both IsLocal skips and markers are gone, and no assertion changed. Both tests pass on Floci at HEAD, so AC1-3 are met. Every required gate has passing evidence at HEAD. The open item is the missing evidence doc (Medium), which does not block.
