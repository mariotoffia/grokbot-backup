# Clean Architecture review: T-39.11, PR #1234
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t39-11-gobridge-observability-skips · HEAD 028f6a4b (matches the request and `git ls-remote refs/pull/1234/head`). Merge base: dc86df55. Floci only; no GitHub posts. Counts as the interim arch gate (W-2026-0003).

== Verdict ==
APPROVED with notes

== Findings ==
- [Medium] [non-testable] go-services/core/brokers/gobridge/ — LINT.md and adr/ are missing. ARCHITECTURE.md, DDD.md, UBIQUITOUS.md and .go-arch-lint.yml are present. This gap existed before the PR. Fix: add them via the technical-writer minion. Not blocking here.
- [Low] [known gap W-2026-0003] The gobridge .go-arch-lint.yml excludes `deployment`, so it does not cover the changed package. `PATH=$HOME/go/bin:$PATH make lint-arch`: rc=0, 9 maps checked (gobridge among them), "OK - No warnings found". The hand-built import map below is the evidence.
- [Info] `go vet -tags e2e` rc=0 and `go vet -tags 'e2e floci'` rc=0. The package has `e2e`, `e2e && floci` and `e2e && !floci` files. `-tags integration` builds no files. The tree is clean, and make generate was not run.
- Out of scope: port and adapter shape (hexagonal-reviewer) and test quality (test-reviewer).

Test-only claim: confirmed. dc86df55..028f6a4b changes 1 file, gobridge/deployment/service-test/recovery_observability_test.go (`//go:build e2e`), -8 lines. It removes the two `harness.Target().IsLocal()` skips in TestDeployed_ControlAbsenceAlarmReachesAlarmAndClears and TestDeployed_RejectedReloadIsCountedByTheLogMetricFilter. No import, production, domain, handler or adapter code changed.

Arch map (go list -tags e2e -test, direct imports): gobridge/deployment/service-test imports deployment/lib/{adapters/cdk/*, core/domain/*, svctest}, deployment/models/services/gobridge, deployment/stacks/groundzero, go-core (ifcore, awsmgrsecstore, credutils, testutils), gobridge/internal/testkit, aws-cdk-go and aws-sdk-go-v2 (cloudformation, cloudwatch, cognitoidentityprovider, ec2, ecs, route53), gobridge/testutil/tlsgen and testify. It does not import gobridge internal/domain, ports, application, adapters or handlers. In ARCHITECTURE.md terms ("Code boundaries"), only the test harness changed, and it uses only the allowed testkit component. The import delta is zero.

== Rationale ==
The diff only deletes two skip guards in an e2e deployed-stack test. It cannot change the dependency direction, leak infrastructure into the domain or move business logic. The cloud SDK and CDK stay in the e2e layer. The only open item is missing governance docs that predate this PR.
