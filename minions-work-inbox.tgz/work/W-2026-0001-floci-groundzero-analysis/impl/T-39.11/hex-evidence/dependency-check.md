# T-39.11 / PR #1234 — manual port/adapter dependency check
HEAD 028f6a4b027fc0f1b653b9133cb674003b6973d2 (origin branch unchanged, fetched 2026-10-23). Raw graph: import-graph.txt.

## Touched file
go-services/core/brokers/gobridge/deployment/service-test/recovery_observability_test.go (-8 lines: two t.Skip removed). E2E on Floci; imports gobridge/internal/testkit, deployment/lib/svctest, aws-sdk clients. No production code touched.

## gobridge (production, own module)
| Layer | Packages |
|---|---|
| domain | internal/domain |
| ports | internal/ports |
| application | internal/application |
| adapters | internal/adapters/{awsident,cloudformation,deadletter,dynamodb,gobridgeconfig,metrics,observability} |
| cmd/wiring | cmd/gobridgectl, handlers/linkcontroller, handlers/runtime-api{,/proxy} |
| test support | internal/testkit, internal/testfixture, internal/architecture, contracts |
Checks:
- domain/application/ports import no aws-sdk / http / db driver (only go-core ifcore/log): PASS.
- Ports live in internal/ports; adapters import domain+ports only: PASS.
- No adapter->adapter import (checked every adapters/* import list): PASS.
- AWS SDK only in adapters, cmd, handlers, testkit/testfixture: PASS.
## Violations
None.
