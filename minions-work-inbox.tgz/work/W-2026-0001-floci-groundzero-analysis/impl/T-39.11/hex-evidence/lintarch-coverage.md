# T-39.11 lint-arch coverage (HEAD 028f6a4b)
| Package | Map | Result |
|---|---|---|
| gobridge production | go-services/core/brokers/gobridge/.go-arch-lint.yml | `go-arch-lint check` (v1.17.0) run directly in the module: "OK - No warnings found", rc=0 (matches gates/lint-arch-028f6a4b.log rc=0) |
| gobridge deployment/service-test (touched) | excluded test/deployment | not covered by design (test-only change) |
No missing map. run.sh not used.
