# T-39.11 evidence
- Issue: https://github.com/Thiink-LLC/teos/issues/1233 (Priority=Medium, Size=Hours, Board Status=Incoming, assignee mariotoffia)
- PR: https://github.com/Thiink-LLC/teos/pull/1234 (ready, Closes #1233, Copilot reviewer requested). HEAD 028f6a4b027fc0f1b653b9133cb674003b6973d2 (no commits since)
- Change: removed both IsLocal skip blocks in gobridge recovery_observability_test.go (:176 and :279).
- Gates (gates/summary-028f6a4b.txt): fmt=0 vet=0 lint=0 lint-arch=0 tidy=0 (clean go.mod/go.sum diff).
  - make test: first run rc=2 at 18:41 CEST (test-028f6a4b.log). Packages in ./cmd, iam/api/client, eventsvc... failed to load because this worktree had only a partial make generate (generate-partial-web-fail.log, 17:01).
  - Fix, local to this worktree: docker info OK, then pnpm install --frozen-lockfile + make generate (generate.log, generate=0, git status clean). make test rerun rc=0, finished 19:03 CEST (test-028f6a4b-rerun.log).
- Service test on Floci mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 (test-service-028f6a4b.log): rc=0, 9 PASS / 0 FAIL / 0 SKIP, 1279s, including ControlAbsence (331s) and RejectedReload (47s). gobridge's Makefile runs without -race (jsii), so this run has no -race.
- make test-integration: see the section below once the queued run finishes.

## 18:16 vs 18:26
Both times are box-local CEST (UTC+2). There is no timezone mismatch. The log's mtime and its last line "EXIT_RC=0 end 2026-10-22 18:16:20 CEST" give the moment the run ended. 18:26 is when I wrote the STATUS milestone line and released floci-harness-run. That release came about 10 minutes after the run ended, which goes against "release right after each run": a deviation.

## Deviations
- Six failed attempts before the green run, all kept in gates/: attempt1 died with its launching shell; attempt2 had no cdk on PATH; attempt3 lacked iam _dist; attempts 4 and 5 hit the ECR docker login timeout (box DNS); attempt6 hit ENOSPC on inodes. After stream 1's dev-lead-approved go clean (df -i checked), the run was restarted under the lock.
- /etc/hosts: added "127.0.0.1 000000000000.dkr.ecr.eu-west-1.localhost" (backup /etc/hosts.bak-W-2026-0001-t39-11). This happened before the no-box-changes rule. It is left in place on dev-lead's instruction (msg-206); platform-lead reverts it after #1234 merges.
- Stream 1's harness runs overlapped attempt-era runs at 17:24. The green 18:16 run is after that.
- Red evidence is static: the skips are present on main, and no runtime red run was made.
- Status: done

## make test-integration @028f6a4b
- Command: /workspace/integ.sh, i.e. `env -i ... TK_LOCAL_EMULATOR=<pinned floci> sg docker -c 'make test-integration'`, run serially under floci-harness-run (taken 19:28 CEST).
- Attempt 1 (gates/test-integration-028f6a4b-attempt1-box-replaced.log) started after the 27.27 run ended at 21:06 CEST. It died at about 21:43 CEST, when the box was replaced. It has no rc. Up to the go-core modules it showed only the `cmd/cblicense` FAIL, which also fails on #1236 and lies outside this PR.
- The lock was released at about 21:45 CEST for the queued waiter. The replaced box has no docker (no docker binary or group), so a rerun is not possible until docker is back. It is still owed.
