# Hexagonal review — T-39.11 (PR #1234 @ 028f6a4b)
Reviewer: hexagonal-reviewer minion (read-only, interim arch gate per W-2026-0003). 2026-10-22 19:07 CEST.
Scope (diff vs merge-base origin/main): go-services/core/brokers/gobridge/deployment/service-test/recovery_observability_test.go, 8 deletions (two Floci t.Skip guards removed). No production code.

== Verdict ==
CHANGES_REQUESTED (evidence-only; no code changes needed. Becomes APPROVED once evidence below is completed — gobridge has full docs and a lint-arch map.)

== Findings ==
- [High] [testable] impl/T-39.11/gates/ — no `make test-integration` run/rc recorded at 028f6a4b. Fix: run at 028f6a4b on Floci and log commit/command/rc.
- [Medium] [non-testable] impl/T-39.11/ — evidence.md missing (only task.md + gates/). Fix: write evidence.md summarizing commit, commands, rc, PASS lines.
- [Medium] [non-testable] impl/T-39.11/gates/summary-028f6a4b.txt — states `test rc=2` and has no test-service line; actual test-028f6a4b-rerun.log rc=0 and test-service-028f6a4b.log rc=0. Fix: update summary.
- [Low] recovery_observability_test.go:174,273 — skips removed; both tests PASS on Floci (331s, 47s). Fine.

== Gates (evidence at 028f6a4b) ==
fmt 0, vet 0, lint 0, lint-arch 0 (gobridge .go-arch-lint.yml covers the module), make test rc=2 first run (package load failures, setup) -> rerun rc=0, tidy 0, test-integration NOT EVIDENCED.
test-service on Floci (attempt 7 after env issues): rc=0, 9/9 PASS incl. ControlAbsenceAlarmReachesAlarmAndClears and RejectedReloadIsCountedByTheLogMetricFilter.
Own check: go vet -tags integration,floci,e2e on gobridge service-test rc=0.
Docs: gobridge has DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, TESTING.md (no LINT.md — Low, informational).

== Rationale ==
Pure test-harness change; no ports, adapters or domain touched. No port-in-adapter or domain leak. Escalation: none.

# Provisional verdict — PR #1234 @ 028f6a4b (2026-10-22 21:48 CEST)
Reviewer: hexagonal-reviewer minion (read-only). HEAD unchanged: origin branch is 028f6a4b027f (ls-remote), with no new commits, so the code verdict is unchanged.

== Verdict ==
APPROVED pending test-integration (PROVISIONAL). Final APPROVED requires a recorded make test-integration run at the HEAD with rc=0, or with failures limited to untouched pre-existing packages (cmd/cblicense, cbdeploy/internal/auth SSO).

== Checks ==
- evidence.md now exists and matches the gates. HEAD is 028f6a4b. fmt/vet/lint/lint-arch/tidy rc=0. make test rc=2, then rerun rc=0 after generate. Service test on pinned Floci a31d6e08: rc=0, 9 PASS / 0 FAIL / 0 SKIP (I counted the 9 --- PASS lines myself), EXIT_RC=0 at 18:16:20 CEST.
- summary-028f6a4b.txt is corrected: it now records the test rc=2 then rerun rc=0 and the service test. The prior Medium is resolved.
- The test-integration attempt1 died when the box was replaced (no rc). Up to that point it showed only the cmd/cblicense FAILs, which are outside the PR. evidence.md records this honestly.

== Findings ==
- [High] [testable] test-integration at 028f6a4b still not evidenced (rerun owed once docker is back). This is the only blocker.
- Resolved: [Medium] evidence.md missing. Resolved: [Medium] stale summary.

# Final evidence-backed verdict — PR #1234 @ 028f6a4b (2026-10-23 07:35 CEST)
Reviewer: hexagonal-reviewer minion (read-only). Evidence: impl/T-39.11/hex-evidence/. HEAD unchanged on origin.
== Verdict ==
APPROVED pending test-integration (still PROVISIONAL). The hexagonal code verdict is clean. No escalation.
== Evidence ==
- Dependency check: gobridge domain, application and ports import no AWS SDK, HTTP or DB code. Ports are in internal/ports. Adapters import only domain and ports, with no adapter-to-adapter import. AWS stays in adapters, cmd, handlers and testkit. No violations.
- lint-arch: the gobridge map passes when go-arch-lint check is run directly (OK, rc=0) and matches gates/lint-arch-028f6a4b.log.
- [High] There is still no completed test-integration at 028f6a4b. gates/ has only attempt1 (the box was replaced, no rc) and attempt2-no-make (EXIT_RC=127, make not found, 2026-10-22 21:50 CEST). No new log exists.
== To reach APPROVED ==
Record a make test-integration run at 028f6a4b on Floci with rc=0, or with failures only in the pre-existing cblicense and cbdeploy SSO packages.
