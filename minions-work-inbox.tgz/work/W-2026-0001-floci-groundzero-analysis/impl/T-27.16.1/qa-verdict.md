# QA verdict notes, T-27.16.1 (PR 1240)
- 2026-10-22 17:55 CEST: the queue-metric alarm subtest is MANUAL_VERIFY. Floci publishes no AWS/SQS metrics, so it is deferred to the Floci gap task in TEOS_GROUNDZERO_TASKS.md (recorded by dev-lead), per cto-122. Not NO-GO.
- Still blocking: test-reviewer CHANGES_REQUESTED (run evidence, missing assertions). Owner: dev-lead.
- 2026-10-22 20:50 CEST (golang-pro, msg-214): the MANUAL_VERIFY item for 27.16.1 now covers both checks that do not run on Floci, for the real-AWS run:
  (a) real metric: the monitor quarantine alarm goes to ALARM from the DLQ's own AWS/SQS ApproximateNumberOfMessagesVisible after a message is sent, then back to OK after a purge, with no datapoints supplied by the test (Floci gap FG-2; subtest "raised by the queue's own metric");
  (b) alarm history: DescribeAlarmHistory (StateUpdate) for the alarm records the automatic change to ALARM (Floci gap FG-6; mapping_alarm_runtime_test.go:166-170 gate at 0271ba55).
  Clearing on missing data (FG-5) is also unproven on Floci; the real-AWS run should see OK return with no further data.
