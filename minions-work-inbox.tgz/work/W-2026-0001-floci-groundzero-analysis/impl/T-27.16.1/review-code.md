# Code review — PR #1240 (T-27.16.1) @ 670aeac7, Floci a31d6e08
Reviewer: the Code Reviewer minion (code-reviewer), read-only. df -h: / 69% used (41G free) at 17:53 (Europe/Stockholm); no heavy runs done.
Base: fresh merge-base with origin/main; 2 commits (e0aff39a, 670aeac7), 1 file, +196.

== Verdict ==
CHANGES_REQUESTED (code findings + gates pending)

== Findings ==
- [High] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:103-106 — adds a Floci t.Skip ("floci: Missing Implementation for AWS/SQS queue metrics"). task.md says "no skips added", and W-2026-0001 is Floci-only, so this subtest never runs in scope. Fix: remove the subtest (the datapoint subtest is the Floci path) or get a Floci fix/marker approved by dev-lead. Specialist: test-reviewer.
- [High] [testable] gates pending — no valid gate evidence at 670aeac7 (see Gates below). Blocks APPROVED.
- [Medium] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:8-11 — the doc says the ESM "delivers: a message on its queue is consumed", but TestTheEvidenceWriterMapping...:48-71 only reads the config back. Fix: send a message and assert it is consumed, or drop the claim (task.md AC1 is config only).
- [Medium] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:187-195 — the "last %s" failure message is evaluated before require.Eventually runs, so it is always empty (proven in gates/test-service-run1.log: "(last )"). Fix: poll manually and call t.Fatalf with last, or use assert.EventuallyWithT.
- [Low] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:166-169 — skips nodejs/python functions silently, so a misconfigured event function on those runtimes would pass. Fix: match by logical-ID allow-list or log the skipped ones.
- [Low] [hard-to-test] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:45,77 — worst case is about 38 min under a 45m go test timeout. Tight but OK; note it for serial runs with 27.16.6/27.25.
- [Low] [non-testable] impl/T-27.16.1/evidence.md is missing (red/green TDD record).
- [Info] Arch: no map covers go-services/eventsvc/deployment/service-test (test-only, no prod code). The W-2026-0003 interim sign-off is given for the code shape, but the lint-arch rerun itself must still pass (it was rc=1 because of the disk).

== Gates (impl/T-27.16.1/gates/, HEAD 670aeac7) ==
Present and valid at HEAD: fmt (fmt-670aeac7.log, rc=0).
Present but VOID (disk full, 'no space left on device'; summary-670aeac7.txt / gates-runner.log): vet rc=2, golangci-lint rc=2, lint-arch rc=1, make test rc=2. tidy rc=0 is also void per gates-runner.log.
Missing: integration,floci service test at 670aeac7. The only run is test-service-run1.log (17:36), which is before HEAD (committed 17:49) on e0aff39a and FAILED (alarm never reached ALARM, rc=1).
=> Required reruns: vet, golangci-lint, lint-arch, make test, tidy, plus the -race Floci service test (CB_SERVICE_TEST=event-service) at 670aeac7.
Env leakage: OK. make test ran with `env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL`. TEOS_DEPLOYMENT=local is set only on the service-test go test command line, which is intended.

== Rationale ==
The test-only change mostly matches the stack definitions (writer.go settings, alarm shape, runtime), but it adds a Floci skip, which goes against the AC. Two assertions/messages are misleading. No gate besides fmt is valid at HEAD, and the integration test has never passed at HEAD.

---
# Re-review — PR #1240 @ d3e75aa1 (2026-10-22 20:35 Europe/Stockholm)
df -h /: 53% used (61G free). Fresh merge-base with origin/main; 6 commits, 1 file (+244). gh head = d3e75aa1. Closes #1239 (closingIssuesReferences=[1239]).

== Verdict ==
APPROVED

== Earlier findings ==
| # | Earlier finding | Status at d3e75aa1 |
|---|---|---|
| H1 | Floci skip L103 | RESOLVED under the dev-lead conditions. go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:118-121 skip message is "Floci gap: AWS/SQS metrics are not published (no ApproximateNumberOfMessagesVisible)…" (names the gap, keeps the marker). The PutMetricData subtest PASSES at HEAD: test-service-d3e75aa1.log:25 "reached ALARM", :26 "reached OK". |
| H2 | gates pending | RESOLVED. All §1 gates are stamped d3e75aa1, rc=0 (below). |
| M1 | ESM "delivers" claim | RESOLVED in the doc (go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:8-11, configuration only). The test name still ends "AndDelivers" (new Low L1). |
| M2 | blank "last" in the message | RESOLVED. go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:220-237 polls manually and t.Fatalf reports the last state. |
| L1 | silent runtime filter | RESOLVED. go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:193-201 selects by eventsvc- name and logs the others; the wrong runtime now fails. |
| L2 | timeout margin | RESOLVED. 8m×3+2 = 26m context (go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:47,79). The test took 572s. |
| L3 | evidence.md missing | RESOLVED. impl/T-27.16.1/evidence.md (red/green 0ab00e78 → d3e75aa1). |

== Accepted deviations (verified) ==
- The 0-datapoint clear runs only on Floci: go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:135-161. It is inside the `!onFloci()` skip subtest, carries a floci marker and a reason, and PASS reached OK at HEAD. Correct.
- The history check runs only off Floci: go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:164-168 returns early on Floci with a marker plus a "Floci gap: DescribeAlarmHistory…" log line (log line present). Correct.

== New findings ==
- [Low] [non-testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:50 — the test name TestTheEvidenceWriterMappingHasTheStackSettingsAndDelivers still says "AndDelivers" after the delivery claim was dropped. Fix: rename (…HasTheStackSettings).
- [Low] [non-testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:1 plus 122-133, 169-181 — the file is now `e2e && floci`, so the off-Floci branches (the real-metric path and alarm history) never compile into an AWS run and are dead under this tag. This is acceptable because W-2026-0001 is Floci-only. Fix: optional follow-up to re-enable them on AWS.
- [Low] [non-testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:14 — "nothing sets its state by hand", while the cleanup at :103-112 calls SetAlarmState OK. That is fine (cleanup only), but the comment could say so. The comment at :46 also says a "45-minute go test timeout", while the gate ran with -timeout 100m.
- [Info] Arch: no map covers eventsvc/deployment/service-test. The W-2026-0003 interim sign-off is given (test-only).

== Gates (gates/*-d3e75aa1.*, summary-d3e75aa1.txt, all stamped d3e75aa1) ==
make fmt 0 (clean) · make vet 0 · make lint 0 · lint-arch 0 (all .go-arch-lint.yml maps) · make test 0 (env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL) · make tidy 0 (clean) ·
Floci service test with tags e2e,floci, -race, full event-service package: rc=0, 25 PASS, 1 SKIP (the approved gap), no DATA RACE, and git was clean at the start. TEOS_DEPLOYMENT=local is set only on the service-test command, so there is no leakage.
Copilot: 2 threads, both resolved and outdated. 0 open.

# Lows check — PR #1240 @ 0271ba55 (2026-10-22 21:45 Europe/Stockholm)
df -h /: 20%. The GitHub head is 0271ba55 and matches. Fresh merge-base 18852fbf; 1 file (+241). New commits: 55d17601 (FG ids) and 0271ba55.
== Verdict ==
CHANGES_REQUESTED, for a missing gate only.
== Lows ==
- 'AndDelivers' name (:50): RESOLVED. Renamed to TestTheEvidenceWriterMappingHasTheStackSettings.
- Dead AWS branches under e2e&&floci: RESOLVED by documentation. The onFloci() doc states the !onFloci() branches are kept for MANUAL_VERIFY. Accepted.
- Stale comment "nothing sets state by hand": PARTIAL. The header is rewritten with FG-2/FG-5/FG-6, but :14 still says "nothing sets its state by hand" next to the SetAlarmState cleanup (:107-112). Acceptable if read as test-only teardown; [Low] [non-testable]. Fix: add "(except cleanup)".
- Stale "45-minute go test timeout" (:47-48) versus -timeout 100m: NOT RESOLVED. [Low] [non-testable]. Fix: update the comment.
== Scope of the new commits ==
They are NOT comment-only. waitForAlarmState is rewritten from a manual poll loop to require.EventuallyWithT (go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:222-234). That is a behaviour change on the 8-minute state waits and needs a service run. The rest is markers and log text.
== Gates ==
The static gates were rerun and are stamped 0271ba55: fmt, vet, lint, lint-arch (no map, W-2026-0003 interim sign-off), make test with env -u, and tidy, all rc=0.
- [High] [testable] No e2e,floci service-test log exists at 0271ba55. The rewritten wait cannot reuse the d3e75aa1 run. Fix: run the eventsvc service test at 0271ba55 and require 25 PASS / 1 SKIP and no races.
The code itself is correct: EventuallyWithT with a 10s tick, the last-tick failure shows the state, and there is no require inside the closure.
Copilot: 2 threads, 0 open. Closes #1239.
