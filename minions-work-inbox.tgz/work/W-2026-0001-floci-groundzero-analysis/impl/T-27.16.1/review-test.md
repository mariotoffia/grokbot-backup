# Test review — T-27.16.1 (W-2026-0001), PR #1240

== Verdict == APPROVED_DEGRADED

== Findings ==
[Minor] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:220-237 — waitForAlarmState swapped require.Eventually for a hand-written loop with time.Sleep(10*time.Second). It still behaves correctly (deadline, Fatalf with the last state seen), but it goes against the "no time.Sleep for synchronization" rule. Fix: use require.EventuallyWithT(t, func(c *assert.CollectT){...}, timeout, 10*time.Second), which reports the last state through CollectT.
[Minor] [non-testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:1 — With //go:build e2e && floci the file never compiles on a real-AWS e2e run, so onFloci() is always true. That leaves the "queue's own metric" subtest and the DescribeAlarmHistory block (lines ~165-180) as dead code. The CTO has made the real-metric path MANUAL_VERIFY, so this is not an ec-gap, but the history assertion is now unexercised as well. Fix: add "alarm history records the change to ALARM" to the MANUAL_VERIFY / Floci gap task, or drop the dead block.
[Minor] [non-testable] PR #1240 body — The body still says "alarm history checked" and "Gate and service-test evidence will follow". At d3e75aa1 history is not checked on Floci, and the evidence is in the work dir. Fix: update the body to name the two Floci gaps and link the evidence.
[Info] [hard-to-test] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:~150-161 — The reset with a 0 datapoint is sound. It uses the same namespace, metric, dimension and Maximum statistic. Once the period holding the breaching datapoint rolls over, the period maximum is 0, which is below the threshold of 1, so the alarm goes to OK because of an explicit value. That is deterministic up to period alignment and bounded by the 8-minute wait (one 5-minute period plus the evaluation tick). The datapoint subtest took 572s in the log for both waits, so the margin is real but not large. The weakening (the notBreaching clear is no longer exercised on Floci) is named in the code and filed as a Task 50 gap, so it is not silent.
[Info] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:~103-112 — The cleanup uses SetAlarmState OK for teardown only, not to drive any assertion. That is acceptable. It is registered after cancel, so it runs first, while ctx is still live.
[Info] [non-testable] /workspace/minions/work/W-2026-0001-floci-groundzero-analysis/image-digest.txt — The work-dir record lists the latest index as sha256:9710d4…, while the test-service log and evidence.md use the pinned a31d6e08f9a8…dd5c1. The pin is consistent, but image-digest.txt does not list a31d6e08. Fix: record the a31d6e08 pin in image-digest.txt.

== Rationale ==
Earlier findings at 670aeac7 and where they stand now:
- No run evidence: RESOLVED. gates/test-service-d3e75aa1.log has the header HEAD d3e75aa192d2…, TK_LOCAL_EMULATOR=mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1, and was run with go test -tags=e2e,floci -race -v. It ends "ok … 2132.640s". TestTheMonitorQuarantineAlarmChangesStateByItself PASSes, the real-metric subtest SKIPs with the Floci-gap reason, the datapoint subtest reaches ALARM and then OK, and the log carries the history-gap line. evidence.md also names d3e75aa1 and a31d6e08.
- Period and Statistic not asserted: RESOLVED. Period 300 and StatisticMaximum are now asserted.
- Skip narrowing: RESOLVED. The build tag e2e && floci plus onFloci() narrow it, and the skip reason is explicit and Floci-named.
- Empty last state in the timeout message: RESOLVED. The Fatalf prints the last state seen, but the fix introduced the time.Sleep loop flagged above.
- Cleanup: RESOLVED. A t.Cleanup puts the alarm back to OK.
- ESM delivery claim: RESOLVED. The claim was dropped from the header.
- Runtime selection: IMPROVED. Functions are now picked by the eventsvc- name, not by runtime, so a service function on the wrong runtime fails instead of being filtered out.

The Dev Lead's accepted markers are sound. The 0-datapoint reset is deterministic and documented. The history check is gated by onFloci() and, because of the build tag, effectively never runs; that is noted above, not hidden. Real-AWS coverage is MANUAL_VERIFY per the CTO and is not raised as an ec-gap.

The verdict is APPROVED_DEGRADED, not APPROVED: Floci gaps reduce what is proven (notBreaching behaviour and alarm history), CI does not run e2e, and there is one minor rule deviation (the sleep loop).

CI at d3e75aa1: CodeQL SUCCESS, Analyze (actions) SUCCESS, Analyze (js-ts) SUCCESS. Build, Unit Tests, Static Analysis and Architecture were SKIPPED. Bugbot and the Security Reviewer were NEUTRAL.

---
# Re-review 2 — PR #1240 @ 0271ba55 (2026-10-22 21:4x CEST)

== Verdict == APPROVED_DEGRADED (PROVISIONAL: conditional on the final Floci service-test rc)

== Findings ==
[Major] [non-testable] impl/T-27.16.1/evidence.md — There is no Floci service-test run at 0271ba55. The gates dir has only static gates (summary-0271ba55.txt: fmt, vet, lint, lint-arch, test and tidy all rc=0). The last service-test log is test-service-d3e75aa1.log, and since then waitForAlarmState, test names and markers have changed. Needed: gates/test-service-0271ba55.log, with the header HEAD 0271ba555cde… and TK_LOCAL_EMULATOR …@sha256:a31d6e08f9a8…dd5c1, run with -tags=e2e,floci -race -v, rc=0. It must show TestTheMonitorQuarantineAlarmChangesStateByItself PASS, the "queue's own metric" subtest SKIP with FG-2, the datapoint subtest PASS with ALARM then OK, the FG-6 log line, and TestTheEvidenceWriterMappingHasTheStackSettings PASS under its new name. evidence.md should record that rc.
[Info] [testable] go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go (waitForAlarmState) — RESOLVED. It now uses require.EventuallyWithT with a 10s tick, has no sleep loop, and reports the last state through CollectT. Returning early on a describe error inside the tick is correct.
[Info] [non-testable] impl/T-27.16.1/qa-verdict.md:4 — RESOLVED. The MANUAL_VERIFY item now covers both the real-metric path and the alarm-history check. Markers name FG-2, FG-5 and FG-6.
[Info] [non-testable] PR #1240 body — RESOLVED. History is listed as not checked on Floci (FG-6, MANUAL_VERIFY), there is no "evidence will follow", and the body points to evidence.md.
[Info] [non-testable] image-digest.txt — RESOLVED. The index is sha256:a31d6e08f9a8…dd5c1, and 9710d4… is marked superseded.

== Rationale ==
All four open findings are closed, and the diff since d3e75aa1 introduces no new test-quality problem. The verdict stays DEGRADED because of the Floci gaps (FG-2, FG-5, FG-6) and because CI does not run e2e. It is PROVISIONAL until test-service-0271ba55.log lands with rc=0 as described above. If that run is red, the verdict becomes CHANGES_REQUESTED.
CI at 0271ba55: CodeQL SUCCESS, Analyze (actions) SUCCESS, Analyze (js-ts) SUCCESS. Build, Unit Tests, Static Analysis and Architecture were SKIPPED. Bugbot and the Security Reviewer were NEUTRAL.
