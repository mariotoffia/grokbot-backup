# T-27.16.1 evidence: eventsvc ESM, quarantine alarm and runtime (issue #1239, PR #1240)

HEAD d3e75aa192d28a2b41ee265661243447b50fecc6, branch chore/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime. Floci pinned to mariotoffia/floci:latest@sha256:a31d6e08...c1.

## Red/green
- e0aff39a: the real-metric alarm path is red on Floci because AWS/SQS metrics are not published (gap 50.2). The 17:23 run overlapped stream 2, so it is void.
- 0ab00e78, gates/test-service-0ab00e78.log, rc=1, run under the lock: the datapoint raised the alarm to ALARM, but Floci kept it in ALARM for 8 minutes after the data stopped. DescribeAlarmHistory returned UnsupportedOperation. Every other test passed.
- 23d83151: on Floci the alarm is now cleared with a 0 datapoint, and the history check runs only off Floci. Both Floci gaps are named in the code.
- 74d65f7a: Copilot fixes. The file is built only with `e2e && floci`, and runtime checks pick functions by the eventsvc- name, not by runtime.
- d3e75aa1: the floci tag files were removed because the constant became unused under lint.
- **d3e75aa1, gates/test-service-d3e75aa1.log, rc=0** (full event-service package, -race, under floci-harness-run). It shows TestTheMonitorQuarantineAlarmChangesStateByItself PASS. The real-metric subtest SKIPs with "Floci gap: AWS/SQS metrics are not published...". The datapoint subtest reaches ALARM and then OK. The alarm history log says "Floci gap: DescribeAlarmHistory is not supported", so there are no history lines on Floci.

## Review items (msg-194/196)
- The SQS skip is approved because the PutMetricData subtest reaches ALARM at HEAD. The decision is recorded in task.md.
- The ESM delivery claim was dropped from the header. The read-back asserts BatchSize 100, window 30, ReportBatchItemFailures and Enabled.
- The last-state message comes from the final poll. The alarm shape asserts Period 300 and Statistic Maximum.
- A cleanup resets the alarm to OK. Skips are narrowed to Floci, and the timeout budget is 8m per state within a 26m context.

## New Floci gaps for TEOS_GROUNDZERO_TASKS Task 50
- Alarm not cleared on missing data (TreatMissingData notBreaching is not honoured).
- DescribeAlarmHistory is unsupported.

## Gates
See gates/summary-d3e75aa1.txt. lint-arch ran and passed; no map covers go-services/eventsvc/deployment/service-test (W-2026-0003).


## Box inode cleanup (dev-lead msg-190), 2026-10-22 ~17:55 CEST
BEFORE `df -i /`:
    Filesystem      Inodes   IUsed IFree IUse% Mounted on
    /dev/vdb       2080768 2080768     0  100% /
Action: `go clean -cache` (succeeded; no rm fallback needed).
AFTER `df -i /`:
    Filesystem      Inodes   IUsed  IFree IUse% Mounted on
    /dev/vdb       2080768 1358389 722379   66% /
(df -h after: 128G size, 43G used, 85G avail.)
Worktrees removed (PR MERGED + clean, branches kept): t27-14 (#1213), t27-16-3 (#1230). Skipped (not clean: untracked pandoc-3.11-1-amd64.deb* from make dep): t27-10 (#1215), t27-12 (#1212), t27-25 (#1214).
/tmp: nothing deleted. All /tmp files are owned by the shared `box` user, so files from before today can't be attributed to me; my own files there are from today's runs.

## 2026-10-22 msg-210 / msg-214 / msg-217 (golang-pro stream 1)
- HEAD 0271ba55 (pushed, no force), on top of 55d17601 (FG ids).
- Floci-only gap markers, each gated by onFloci() so the real-AWS path stays intact:
  - FG-2 (no AWS/SQS metrics): skips the "raised by the queue's own metric" subtest.
  - FG-5 (alarm does not clear on missing data, plans/FG-5.md): putDatapoint(0) at mapping_alarm_runtime_test.go:157-162.
  - FG-6 (DescribeAlarmHistory unsupported, plans/FG-6.md): early return at :166-170.
- msg-214: waitForAlarmState now uses require.EventuallyWithT (no sleep loop). The MANUAL_VERIFY item now names the real-metric and alarm-history checks (qa-verdict.md). The PR body no longer claims history was checked or that evidence would follow. image-digest.txt was corrected to a31d6e08.
- msg-217 lows: renamed TestTheEvidenceWriterMappingHasTheStackSettings (no "AndDelivers"); fixed the stale header and onFloci comments.
- Static gates at 0271ba55: gates/summary-0271ba55.txt, fmt/vet/lint/lint-arch/test/tidy all rc=0. lint-arch ran and passed; no map covers ./go-services/eventsvc/deployment/service-test/... (W-2026-0003).

## msg-221/222 (21:55 CEST)
- b049c8ae (local, NOT pushed): header "(except cleanup)" and the 100-minute timeout comment. FG markers moved: FG-2 :122, FG-5 :158, FG-6 :168-169.
- Package-scoped gates, needed because make is missing on the restored box (gates/summary-nomake-b049c8ae.txt): fmt, vet, lint (golangci-lint with tags e2e,floci), test-compile (-race), tidy and lint-arch all rc=0. The make-based §1 gates (summary-b049c8ae.txt) gave rc=127 because make was not found.
- Service run gates/test-service-b049c8ae.log: rc=1. TestMain could not start: Floci's DynamoDbLocal sidecar hit an HTTP connect timeout on the freshly restored docker. That is an environment failure, not a test result. The run was aborted, the lock released, and the containers removed. Still needed at the final HEAD: 25 PASS, 1 SKIP, no races.
