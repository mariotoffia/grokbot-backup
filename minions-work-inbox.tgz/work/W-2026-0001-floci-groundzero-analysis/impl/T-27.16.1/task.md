Scope: Floci-only; no real-AWS runs (devlocal included).

# T-27.16.1 — test(eventsvc): qualify event source mapping, automatic alarm and runtime on Floci

Work item: W-2026-0001 · Packet set P-2026-0001-39..44 stream 1 (packet files absent from packets/; scope from brief, TEOS_GROUNDZERO_TASKS.md 27.16.1, ANALYSIS.md) · Implementer: golang-pro · start_gate: Mario's go relayed by dev-lead 2026-10-22 16:44 (STATUS.md)
Repo Thiink-LLC/teos · Branch chore/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime · Worktree /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-16-1-eventsvc-esm-alarm-runtime
Floci image: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 (has 23.1 floci#4316 CFN ESM options)

## Scope (new coverage, no marker)
New file go-services/eventsvc/deployment/service-test/mapping_alarm_runtime_test.go:
1. ESM: the evidence writer's CDK-created SQS mapping, read back through the Lambda API, carries BatchSize 100, MaximumBatchingWindowInSeconds 30, FunctionResponseTypes ReportBatchItemFailures, State Enabled (writer.go).
2. Automatic alarm: <env>-eventsvc-monitor-dlq-alarm exists with the stack's metric/threshold/dimension; it goes OK -> ALARM by itself when the quarantine queue holds a message and back to OK once purged; alarm history records it.
3. Runtime: every event-service Lambda is provided.al2023 / arm64, Active, LastUpdateStatus Successful.

## Acceptance criteria
- Tests pass on Floci with -race (CB_SERVICE_TEST=event-service), run serially (eventsvc package shared with 27.16.6/27.25).
- No production code change; no skips added. Gates fmt/lint/vet, go-arch-lint direct, make test clean env, tidy clean.

## Decision (dev-lead msg-194 / msg-196, 2026-10-22 17:54 CEST)
The "no skips added" AC is amended: the queue-metric subtest may skip on Floci only, as a Floci-gap marker ("AWS/SQS metrics are not published", raised to CTO msg-191), and only if the PutMetricData subtest drives the deployed alarm to ALARM at HEAD. The ESM delivery claim is dropped (configuration read-back only). New helper files floci_tag_on_test.go / floci_tag_off_test.go narrow the gap skips to Floci builds.
