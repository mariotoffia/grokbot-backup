# Clean Architecture review (interim arch gate): T-27.20, PR #1229
Reviewer: clean-arch-reviewer minion · Request: msg-W-2026-0001-dev-lead-133 · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-20-fleet-search-connectivity · Requested HEAD 220cefed. Real base: db06a87b (origin/main after the M1 merges; the branch is on fresh main, so a3543337 is not the base). Floci only; no GitHub posts.

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] go-core/managers/mgriot/awsmgriot — no .go-arch-lint.yml covers this package. `make lint-arch` (PATH=$HOME/go/bin:$PATH, after make install/dep/generate, which failed for environment reasons: apt 500, corepack permission, docker.sock permission; 45 tracked generated files deleted by generate were restored, tree clean): rc=0, 9 Makefiles / 10 maps OK, but none covers this diff. The hand-built import map below is the evidence. Fix: none here (W-2026-0003).
- [Low] [testable] go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go:52-59 — at 220cefed the local branch turns thing indexing on and never restores it, which leaks state across tests in the same emulator run. de702c57 (committed after the requested HEAD, which I also read) restores it in t.Cleanup, which addresses this. Fix: ship de702c57 with the PR.
- [Low] [non-testable] impl/T-27.20/evidence.md — says "no commits and no PR" and "lint-arch is not available", both stale now. Fix: dev-lead/golang-pro update evidence.md.
- Out of scope: port and adapter shape (hexagonal-reviewer) and aggregates (ddd-reviewer); the diff has neither.

Test-only claim: confirmed. db06a87b..220cefed: 1 file (`//go:build integration`, inside the owns glob), +13/-7. It removes the floci marker and local skip, adds a local-only UpdateIndexingConfiguration before the existing account-indexing-off check (kept, as the brief requires). 220cefed..de702c57 (+27/-5) is the same file and also test-only. No production code changed.

Arch map (go list -tags integration test imports + the diff): the change adds no import (iot and iottypes were already imported). The package's test edges (awsmgriot, ifiot, iotmodel, coremodel, cbenv, ctx, ifcore, testenv, utils/awsutils, httputil) are all inside go-core. An AWS SDK use in an outbound adapter's integration test is the correct layer. go vet -tags integration is clean. No .go-arch-lint.yml, ADR or go.mod change.

== Rationale ==
This is a test in the AWS adapter package that drives the AWS API directly, so the adapter layer is the right place for it. It adds no dependency, inversion or domain contact. The only notes are test hygiene (state restore, already fixed in de702c57) and stale evidence.
