# T-27.20 evidence: golang-pro minion (P-2026-0001-34). BLOCKED (verify-failed / scope)

Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-20-fleet-search-connectivity
Branch: chore/W-2026-0001-t27-20-fleet-search-connectivity, on fresh origin/main db06a87b. There are no commits and no PR, so nothing is pushed.
Floci image: mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1. `docker image inspect` on mariotoffia/floci:latest confirms it, and the run pinned it with TK_LOCAL_EMULATOR. AWS_CONFIG_FILE and AWS_SHARED_CREDENTIALS_FILE were both /dev/null.

## Test behind the skip (OPEN item settled)
There is only one: `TestITSearchThingsFindsCreatedThing` in go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go. The marker and skip were at :43-46 on fresh main. The test searches by thing name only. **No test searches by connectivity (#6025).**

## Uncommitted change in the worktree (not committed)
- The local skip and its `floci: Missing Implementation for IoT fleet search.` marker are deleted.
- The `testenv` import is removed, because nothing used it after that.
- The skip for "account indexing turned off" is kept.

## Result: `make test-integration` on the pinned digest
```
=== RUN   TestITSearchThingsFindsCreatedThing
    devicesearcher_aws_integration_test.go:54: fleet indexing for things is turned off in this account
--- SKIP: TestITSearchThingsFindsCreatedThing (0.01s)
```
The test still does not run, because Floci starts with thing indexing OFF. Nothing in this integration environment turns it on:
- `make test-integration` runs `cbtest local exec --resources-only`, which deploys no stacks.
- The device service's indexing setup from #1213 is not deployed here.

So acceptance A1 ("runs, not skipped") cannot be met inside the owns file without changing what the test does.

## Why this is blocked, and the proposed fix
The test's doc says fleet indexing "is an account-wide setting the test must not change". Meeting A1 needs one of these:
- (a) On the local target only, the test turns on thing indexing, and thing connectivity indexing for a connectivity search, with UpdateIndexingConfiguration. The emulator account belongs to the run. It then waits for the index with require.Eventually. Optionally it adds a connectivity query assertion for #6025. The change fits inside the owns file, but it reverses the documented rule for the local target and adds test scope (connectivity). It needs a dev-lead or test-designer decision.
- (b) The integration environment turns on fleet indexing for the emulator, through cbtest or flocilocal. That is outside owns, so it is an ESCALATION: conflict.

The other gates (fmt, lint, vet, test, tidy) were not run for this task, because there is nothing to commit yet.

## Update 2026-10-22 12:55 CEST: dev-lead msg-128 picked option (a)
- Only when testenv.Target()==DeploymentTargetLocal does the test call UpdateIndexingConfiguration(ThingIndexingMode=REGISTRY). On AWS it never changes the account setting, and the indexing-off skip stays (A3). The change stays inside the owns file.
- TDD: before the change the test SKIPped ("fleet indexing for things is turned off"). After it: `cbtest local exec --resources-only ... go test -tags=integration,floci -run TestITSearchThingsFindsCreatedThing ./managers/mgriot/awsmgriot/`. On Floci sha256:a31d6e08 the result is `--- PASS: TestITSearchThingsFindsCreatedThing`.
- No connectivity (#6025) test exists, and none was added, per dev-lead.
- Commit 220cefed. Draft PR https://github.com/Thiink-LLC/teos/pull/1229
- Gates: make fmt, make lint-go, make vet and make tidy all rc=0, with a clean diff. Full `make test-integration` is running (/tmp/t2720-ti.log). lint-arch is not available (W-2026-0003).
