Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# Minion prompt — TEOS 27.20: test(devices): run the fleet index search tests on Floci

You are the golang-pro minion working in **Thiink-LLC/teos** on the shared computer. This prompt is self-contained; the packet (P-2026-0001-34) wins over anything here.

## Setup
- Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-20-fleet-search-connectivity` on branch **`chore/W-2026-0001-t27-20-fleet-search-connectivity`**, based on current origin/main after the M1 merges (#1212-#1215); run `git fetch` first. The box's local origin/main ref (863b6019) predates those merges. Not created yet: create it yourself under the go-approved start gate (packet start_gate), reserve the lock in registry/locks.json first.
- Symlink `.env` to the repo's gitignored `.env` as in the other W-2026-0001 worktrees. Never print, cat, copy, `git add` or commit it; never replace the symlink.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `SERVICE_TEST.md`, `SERVICE_TEST_WRITING.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`, and the local docs of the touched module. They are authoritative. Then `/workspace/minions/CONVENTIONS.md` (§0, §1, §A/§C, §I) and `/workspace/minions/TEOS_CONVENTIONS.md`.
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`.
- Floci image pin: `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1` (new mariotoffia/floci:latest with the Floci Task 48 fix). Confirm `docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:a31d6e08`; otherwise stop with `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins (they stay `:latest`).

## Goal
Run the fleet index search integration test on the local Floci target. Floci 30.1 (floci-io/floci#4913 fleet index search subset, merged 2026-10-10; #6025 fleet search by connectivity, merged 2026-10-20) is in floci main and needs 9.4 (#4896, indexing configuration), all in the pinned image. Delete the local marker and skip at devicesearcher_aws_integration_test.go:43 (ANALYSIS.md lists :43; the 27.14 pre-check saw the skip at :43-46). Keep the account-indexing-off skip: that is real AWS behaviour. Ordered after 27.14 (merged as #1213).

## Before you code
Not re-checked by dev-lead on current main. Known from the sources: marker at go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go:43 (skip :43-46); same awsmgriot package as 27.13 but a different file. Re-read the file on fresh main before editing; if the marker is gone already, reply ESCALATION: already-done.

## Files you may change
- `go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. Integration test (go-core, local Floci on the pinned digest): the device search integration test(s) behind the skip at devicesearcher_aws_integration_test.go:43 run (not skipped) and pass, including search by connectivity (#6025).
2. The local skip and its `floci: Missing Implementation for` marker at devicesearcher_aws_integration_test.go:43 are deleted; no assertion is weakened.
3. The account-indexing-off skip stays (real AWS behaviour).
4. Floci-local gate: the un-skipped test passes locally on mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `make test-integration` (go-core); evidence in impl/T-27.20/evidence.md.

## OPEN items
- OPEN: exact test names behind the skip are not in the sources; golang-pro lists them in evidence.md.
- OPEN: delivery-plan.md names reviewers code-reviewer + test-reviewer; this packet also asks hexagonal + clean-arch for the interim arch gate. Coordinator to confirm the reviewer set.
- OPEN: risk from ANALYSIS.md: fleet index readiness timing may flake; poll with require.Eventually, never a fixed sleep. If readiness needs a helper change outside owns, ESCALATION: conflict.

## How to work
- Architecture: every TEOS project is **DDD + hexagonal (ports & adapters) + clean architecture**. Keep test helpers in the test package, reuse testutils/svctest, do not pull adapters or SDK types into domain/ports.
- **TDD**: start from the test-designer's test plan (impl/T-27.20/test-plan.md) when present; see the test fail for the right reason, make the minimal change, then green.
- **Systematic debugging** on any failure: reproduce, read the full error, one hypothesis at a time, fix the root cause. No retries-until-green, no new skips, no weakened assertions, no fixed sleeps. If the un-skipped test fails on the pinned image, reply `ESCALATION: verify-failed` with the full error.
- Comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English.

## Gates — CONVENTIONS.md §1 / TEOS_CONVENTIONS.md §1 (all must pass; commands + pass/fail in evidence.md)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint and lint-arch; lint-arch is unavailable for this package (backlog W-2026-0003; no lint-arch map covers it): interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `make test-integration`
Marker check: `rg -n "floci: Missing Implementation for" go-core/managers/mgriot/awsmgriot/`

## Commit / PR rules
- Conventional commit titled like `test(devices): run the fleet index search tests on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets, never print `.env`.
- At the **first commit**, golang-pro pushes the branch and opens a **draft** PR to main (title prefixed W-2026-0001, labels build, unit-test, lint; body links this task and STATUS.md, records the image digest). Keep pushing as work progresses. **No force-push, never merge, never push to main.**
- PR body records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable for this package (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest a31d6e08); no real-AWS runs".
- Mark ready only after the internal reviews pass; then Copilot review and green workflows. Mario merges.

## Stop condition
Commit(s) pushed to `chore/W-2026-0001-t27-20-fleet-search-connectivity`, draft PR open, all gates green, evidence in `/workspace/minions/work/W-2026-0001-floci-groundzero-analysis/impl/T-27.20/evidence.md`. Reply `done` to dev-lead in the ⟦MINION v1⟧ envelope.

## ESCALATION convention
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done. Details below that line. Do not work around the problem.
