Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.20 — test(devices): run the fleet index search tests on Floci

Work item: W-2026-0001 · Packet: P-2026-0001-34 · Implementer: golang-pro (minion, shared computer) · Tests: test-designer · Reviews: code-reviewer + hexagonal-reviewer + clean-arch-reviewer
Repo: Thiink-LLC/teos · Base: current origin/main after the M1 merges (#1212-#1215); run `git fetch` first. The box's local origin/main ref (863b6019) predates those merges · Branch: `chore/W-2026-0001-t27-20-fleet-search-connectivity` · Worktree: `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-20-fleet-search-connectivity`
Floci image: `mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1`

## Goal
Run the fleet index search integration test on the local Floci target. Floci 30.1 (floci-io/floci#4913 fleet index search subset, merged 2026-10-10; #6025 fleet search by connectivity, merged 2026-10-20) is in floci main and needs 9.4 (#4896, indexing configuration), all in the pinned image. Delete the local marker and skip at devicesearcher_aws_integration_test.go:43 (ANALYSIS.md lists :43; the 27.14 pre-check saw the skip at :43-46). Keep the account-indexing-off skip: that is real AWS behaviour. Ordered after 27.14 (merged as #1213).

## Pre-check note
Not re-checked by dev-lead on current main. Known from the sources: marker at go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go:43 (skip :43-46); same awsmgriot package as 27.13 but a different file. Re-read the file on fresh main before editing; if the marker is gone already, reply ESCALATION: already-done.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go`

## Acceptance criteria (as regression-test behaviour)
1. Integration test (go-core, local Floci on the pinned digest): the device search integration test(s) behind the skip at devicesearcher_aws_integration_test.go:43 run (not skipped) and pass. **The connectivity part is N/A (dev-lead msg-128/msg-135): no connectivity search test exists, and none is added.** (Original text: including search by connectivity (#6025).)
2. The local skip and its `floci: Missing Implementation for` marker at devicesearcher_aws_integration_test.go:43 are deleted; no assertion is weakened.
3. The account-indexing-off skip stays (real AWS behaviour).
4. Floci-local gate: the un-skipped test passes locally on mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `make test-integration` (go-core); evidence in impl/T-27.20/evidence.md.

## OPEN items (scope not settled in the sources)
- OPEN: exact test names behind the skip are not in the sources; golang-pro lists them in evidence.md.
- OPEN: delivery-plan.md names reviewers code-reviewer + test-reviewer; this packet also asks hexagonal + clean-arch for the interim arch gate. Coordinator to confirm the reviewer set.
- OPEN: risk from ANALYSIS.md: fleet index readiness timing may flake; poll with require.Eventually, never a fixed sleep. If readiness needs a helper change outside owns, ESCALATION: conflict.

## TEOS_CONVENTIONS checklist: §C (shared library go-core/managers/mgriot/awsmgriot; existing package, no new library) + §I
- CONVENTIONS.md §0/§1: DDD + hexagonal (ports & adapters) + clean architecture; dependencies point inward; no adapter/SDK leaks into domain or ports. Test-only change, but reviewers check the boundaries anyway.
- TEOS §0: `make dep` + `make generate` first in a fresh worktree; per-module make targets (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil + deployment/lib/svctest; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change; never hand-edit go.mod.
- §I: integration tests tagged integration (+floci); service tests live in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:a31d6e08). A local skip is not evidence. No real-AWS run.
- No §B, §D or §E: no third-party adapter, web app or CLI is touched.
- Secrets: `.env` in the worktree is a symlink to /workspace/repos/teos/.env (gitignored). Never print, cat, copy, `git add` or commit it; do not replace the symlink. No secrets in code, logs, commits or chat.
- Commits: conventional commits, **no byline / Co-Authored-By / AI co-author trailer**, no GitHub closing keywords.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint (standard linter lint-go/golangci-lint and lint-arch; lint-arch is unavailable for this package (backlog W-2026-0003; no lint-arch map covers it): interim arch gate = standard linter + hexagonal-reviewer and clean-arch-reviewer sign-off, and the PR body must say so)`
- `make vet`
- `make test`
- `make tidy && git diff --exit-code (clean)`
- `make test-integration`
- Arch gate: where no lint-arch map covers the package (backlog W-2026-0003), the interim arch gate is the standard linter **plus** hexagonal-reviewer and clean-arch-reviewer sign-off. The PR body must state this.

## Evidence a done reply needs
- Floci image digest used (`docker image inspect --format '{{index .RepoDigests 0}}' mariotoffia/floci:latest` starts with `mariotoffia/floci@sha256:a31d6e08`).
- Tests run vs skipped, per package (skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-core/managers/mgriot/awsmgriot/`.
- `git diff --stat origin/main..HEAD` (owns-glob files only).
- Draft PR URL.

## Commit / PR rules
- Conventional commit titled like `test(devices): run the fleet index search tests on Floci`. **No byline, no Co-Authored-By, no AI co-author trailer.** No GitHub closing keywords. No secrets, never print `.env`.
- At the **first commit**, golang-pro pushes the branch and opens a **draft** PR to main (title prefixed W-2026-0001, labels build, unit-test, lint; body links this task and STATUS.md, records the image digest). Keep pushing as work progresses. **No force-push, never merge, never push to main.**
- PR body records: image digest, tests run vs skipped, marker grep, gate results, "lint-arch unavailable for this package (W-2026-0003); arch gate = standard linter + hexagonal and clean-arch reviewer sign-off", and "Floci-local gate passed (digest a31d6e08); no real-AWS runs".
- Mark ready only after the internal reviews pass; then Copilot review and green workflows. Mario merges.
