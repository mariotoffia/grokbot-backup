# T-27.20 test review: test-reviewer minion (msg-W-2026-0001-dev-lead-131)
PR: https://github.com/Thiink-LLC/teos/pull/1229. Head 220cefedb3a334abd6beaf99ca22a62781ea9db8 matches the given SHA 220cefed. Draft. CI: CodeQL passed, and Build/Unit/Static/Architecture were SKIPPED.
File: go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go. Build tag `//go:build integration` is present (line 1).

## AC mapping
| AC | Mapped to | Status |
|---|---|---|
| 1 Search test runs and passes on Floci, including search by connectivity (#6025) | TestITSearchThingsFindsCreatedThing (name only). No connectivity test | PARTIAL: connectivity MISSING |
| 2 Local skip + marker deleted, no weakened assertion | diff removes :43-46. Assertions unchanged | MET |
| 3 Account-indexing-off skip stays | :64-67 | MET (but see the local-masking finding) |
| 4 Gate via `make test-integration` (go-core) | Only a targeted `go test -run` PASS is recorded. The full run's log /tmp/t2720-ti.log is 0 bytes | MISSING for full suite |

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [High] [testable] devicesearcher_aws_integration_test.go:52-59 — the test changes emulator-wide state (thing indexing OFF→REGISTRY) and never restores it. In `make test-integration` one Floci instance serves every package (`cbtest local exec --resources-only`), so the result depends on test order: any later test that expects the default (OFF) or REGISTRY_AND_SHADOW sees different state, and re-runs against a kept emulator differ from fresh ones. Fix: read the prior config with GetIndexingConfiguration first, then t.Cleanup to restore it (local only). Or document and assert that no other test in the run depends on the indexing mode.
- [High] [testable] devicesearcher_aws_integration_test.go:64-67 — on the local target, if UpdateIndexingConfiguration silently has no effect, the test SKIPs instead of failing. That is the "a local skip is not evidence" trap, and it is how the test regresses to green-by-skip. Fix: on local, require.NotEqual(ThingIndexingModeOff) (or require.Eventually that the mode is REGISTRY). Keep t.Skip only for the AWS target.
- [High] [testable] devicesearcher_aws_integration_test.go:96 — AC1 "including search by connectivity (#6025)" has no test or `// covers:`. Dropping it was a dev-lead decision (msg-128), but task.md was not amended. Fix: amend the AC and open a follow-up task, or add a connectivity query (ThingConnectivityIndexingMode=STATUS, query `connectivity.connected:false` plus the thing name) with require.Eventually.
- [Medium] [non-testable] impl/T-27.20/evidence.md — AC4 evidence is a single-test `-run`. The full `make test-integration` result for 220cefed is absent (empty log), and that full-suite run is exactly where the shared-state leak would show. Fix: attach the full go-core make test-integration rc and pass/skip counts, run twice on the same kept emulator to show it is order- and rerun-stable.
- [Low] [hard-to-test] devicesearcher_aws_integration_test.go:87-95 — the 2 min / 2 s Eventually is fine. Index readiness after enabling indexing is also covered by this same poll, so the timing is not flaky as written. No action.
- [Low] [non-testable] devicesearcher_aws_integration_test.go:3 — the file is `package awsmgriot`, not `awsmgriot_test` (AGENTS.md: <package>_test for exported functionality). This predates the PR. Fix: optional follow-up, since NewDeviceSearcherAWS is exported.

== Rationale ==
Removing the skip is correct, the polling uses require.Eventually with no sleep, and the build tag is right. Isolation is the main problem: an unrestored, emulator-global indexing change can make other tests in the same Floci run order-dependent. The leftover OFF skip can also hide a local failure as a SKIP. AC1's connectivity part is unmapped and the brief is not amended. Full-suite evidence for HEAD is missing. All of these are small, in-file fixes.
