# Code review — PR #1242 (T-27.1) @ 4ac29c54, Floci a31d6e08
Reviewer: the Code Reviewer minion (code-reviewer), read-only. df -h /: 53% used (61G free) at 20:33 (Europe/Stockholm).
Base: fresh merge-base with origin/main (18852fbf); 3 commits, 2 files (+390): deployment/stacks/groundzero/service-test/apigw_contract_test.go (+389), service-test/go.mod (+1 cloudwatchlogs).

== Verdict ==
CHANGES_REQUESTED. The only blocker is gate evidence for the current PR head. The code at 4ac29c54 is otherwise approvable.

== Findings ==
- [High] [non-testable] PR head moved. GitHub headRefOid = 952d639a ("test: name the Floci gap ids on the Floci-only markers", pushed 20:34:42 (Europe/Stockholm), after the gates). All gates in gates/*-4ac29c54.* are stamped 4ac29c54. The delta is comment plus t.Log text only (deployment/stacks/groundzero/service-test/apigw_contract_test.go:291,293, "FG-7"), but no gate evidence exists for the head that would merge. Fix: rerun the §1 gates (and the groundzero service test) at 952d639a, or confirm 952d639a is not the merge candidate. Also, the worktree carries that same edit uncommitted.
- [Medium] [non-testable] A5 doc is incomplete. The Logs-cap doc is only in the file header (deployment/stacks/groundzero/service-test/apigw_contract_test.go:37-44). There is no groundzero service-test README/LINT-adjacent doc. "Oldest-first eviction" is cited from the Floci 2.1.0 release notes, not confirmed in source. The container-log "no eviction diagnostic" assertion is absent (the test only checks that 10 events read back). Fix: add the doc, cite the source, add the diagnostic check, or record a dev-lead waiver.
- [Low] [testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:171-181 — the require.Eventually message's "got %d" is evaluated before polling, so it always prints 0. This is the same pattern as the T-27.16.1 M2 finding. Fix: poll manually or use EventuallyWithT.
- [Low] [non-testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:290-294 — the Floci soft-assert for x-amzn-ErrorType has no Floci issue link (A3 asks for one). 952d639a adds the "FG-7" id but still no link. Fix: link the Task-50/Floci issue.
- [Low] [non-testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:1 — the file is `e2e && floci`, so the off-Floci branches (contractHTTP AWS URL :246-249, the strict ErrorType path) are dead under this tag. Acceptable for Floci-only scope.
- [Info] Arch: no map covers deployment/stacks/groundzero/service-test. The W-2026-0003 interim sign-off is given: test-only, local helpers, no product adapters imported.

== A1–A6 (consult-api-designer.md) ==
| Item | Status | Evidence |
|---|---|---|
| A1 self-contained home | MET | deployment/stacks/groundzero/service-test/apigw_contract_test.go:185-239: own REST API with a MOCK integration, UnixNano suffix, no product stacks or testutils |
| A2 v1 only plus note | MET | deployment/stacks/groundzero/service-test/apigw_contract_test.go:25-27 |
| A3 403 contract (status, message, ErrorType prefix) | MET with a named Floci gap | deployment/stacks/groundzero/service-test/apigw_contract_test.go:98-105, 278-297. JSON message only. The ForbiddenException header is soft on Floci and has no issue link (Low) |
| A4 direct binding, no read-back, negative subtest | MET | deployment/stacks/groundzero/service-test/apigw_contract_test.go:107-112, 130-141 (subtest named key_in_unlinked_plan_rejected, 44.1 skip did not fire: real 403), 326-367. No sleeps |
| A5 logs-cap doc plus assertion | PARTIAL | header doc plus the TestLogsCap 10/10 check. README doc, source confirmation and the diagnostic-string check are missing (Medium) |
| A6 x-api-key / HEADER | MET | deployment/stacks/groundzero/service-test/apigw_contract_test.go:191 ApiKeySource HEADER explicit; :268 x-api-key only |

== SEC (review-security.md; security-auditor re-review review-security-2.md = approve) ==
| Item | Status | Evidence |
|---|---|---|
| SEC-1 negatives | MET | disabled deployment/stacks/groundzero/service-test/apigw_contract_test.go:114-117, revoked deployment/stacks/groundzero/service-test/apigw_contract_test.go:119-128, unlinked plan deployment/stacks/groundzero/service-test/apigw_contract_test.go:130-141; all PASS on Floci |
| SEC-2 local bypass in product helpers | DEFERRED (accepted) | documented deployment/stacks/groundzero/service-test/apigw_contract_test.go:33-35; tracked under 27.28/44.1 |
| SEC-3 key value never logged | MET | crypto/rand deployment/stacks/groundzero/service-test/apigw_contract_test.go:369-376; only ids are logged deployment/stacks/groundzero/service-test/apigw_contract_test.go:338,351,364; redaction deployment/stacks/groundzero/service-test/apigw_contract_test.go:303-313 |
| (SEC-6 cleanup order) | MET | LIFO plan key → plan → key → API, deployment/stacks/groundzero/service-test/apigw_contract_test.go:197,336,349,359 |

== Issue link ==
Body "Closes #1241". closingIssuesReferences=[1241]. Issue #1241 "W-2026-0001 T-27.1: API Gateway v1 contract cases on Floci…" is OPEN and correct.

== Gates (gates/*-4ac29c54.*, summary-4ac29c54.txt; all stamped 4ac29c54) ==
make fmt 0 (clean) · make vet 0 · make lint 0 · lint-arch 0 (all maps) · make test 0 (env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL) · make tidy 0 (clean) ·
Floci groundzero service test with tags e2e,floci, -race (test-service-4ac29c54.log, git clean): TestRestAPIContract 7/7 PASS, TestLogsCap PASS. The package rc=1 comes only from TestThePublicNamesResolveToThisMachine (out of scope, per the brief). TEOS_DEPLOYMENT=local is set only on the service-test command, so there is no leakage. The test reads AWS_ENDPOINT_URL, which the harness sets.
NOT present for PR head 952d639a (see the High finding).

== Copilot ==
5 threads, all resolved (4 outdated). 0 open.

== Rationale ==
The test is well scoped, follows the A1–A6 and SEC conditions, and handles key material carefully. Performance is negligible (0.1s). The gates are green at 4ac29c54, but the PR now points at 952d639a, which has no evidence, and that blocks APPROVED. The A5 doc gap is Medium.

# Re-review — PR #1242 @ 87ab8715 (2026-10-22 21:45 Europe/Stockholm)
df -h /: 20% used. The GitHub head is 87ab8715 and matches the brief. Fresh merge-base 18852fbf; 2 files (+428). New since the last review: 952d639a (FG ids) and 87ab8715.
== Verdict ==
PROVISIONAL APPROVED, based on the static gates. It becomes final once the e2e,floci service test passes at 87ab8715. No test-service-87ab8715.log exists yet.
== Earlier findings ==
- High (no gates at the PR head): RESOLVED for the static gates. summary-87ab8715.txt shows fmt, vet, lint, lint-arch, make test (env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL) and tidy all rc=0, stamped 87ab8715. The service test is still PENDING.
- Medium A5: MOSTLY RESOLVED.
  - The Floci source is now cited (EmulatorConfig.java:1953, CloudWatchLogsService.java:791-800, LogEventIndex.java:14-31 @ floci 5beb8d47b), with the correct nuance that "oldest" means the earliest event timestamp.
  - The eviction diagnostic is added (missing-prefix detection, deployment/stacks/groundzero/service-test/apigw_contract_test.go ~:196-219).
  - The override is documented as WithEnv only.
  - STILL MISSING: the groundzero service-test README/LINT-adjacent doc that A5 requires. Remains [Medium] [non-testable]. Fix: add a short README pointer or record a dev-lead waiver.
- Low (Eventually message): RESOLVED. It now uses EventuallyWithT with a per-tick missing list.
- Low (A3 issue link): RESOLVED. The marker names "Floci gap FG-7" (deployment/stacks/groundzero/service-test/apigw_contract_test.go:329-331), tracked in floci-gaps/plans/FG-7.md. FG-4 is cited with its plan path.
- Low (dead AWS branches): unchanged. Accepted.
== New ==
- [Low] [testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:121-136: the new EventuallyWithT for the unbound key is good (AWS unbinds eventually). It re-implements the request inline and the comment explains why. Fine.
- [Info] Subtests are renamed to sentences with spaces, so -run patterns need underscores. No issue.
Copilot: 5 threads, 0 open. Closes #1241, which is OPEN and correct.
