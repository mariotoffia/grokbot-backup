# T-27.1 consult request (api-designer consult + security-auditor read-only review)

From: golang-pro (stream 1, W-2026-0001) · Via: dev-lead · Written 2026-10-22 (Europe/Stockholm) before any 27.1 code.
Source scope: TEOS_GROUNDZERO_TASKS.md 27.1 / plans/teos-adoption/README.md §27.1; ANALYSIS.md 27.1 caveat (Floci 44.1).
Floci image: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1. Floci only.

## Planned cases (test-only; proposed home: deployment/stacks/groundzero/service-test, new file apigw_contract_test.go)
1. API key: a method with ApiKeyRequired rejects a missing key (403) and an invalid key (403), and accepts a key that is bound DIRECTLY (CreateApiKey -> CreateUsagePlan with apiStages -> CreateUsagePlanKey). The test never reads apiStages back from GetUsagePlan/GetUsagePlans (Floci 44.1 still open).
2. Unknown route: a request to an unknown path on a deployed REST API stage returns 403 (AWS "Missing Authentication Token"), not 404/405.
3. Logs cap: document and assert the 20,000-event account-wide CloudWatch Logs cap / eviction diagnostic boundary without adding a second retention control (FLOCI_SERVICES_CLOUDWATCHLOGS_MAX_STORED_EVENTS via WithEnv only if a run needs more).

## Questions for api-designer
A1. Home: groundzero service-test (deploys stacks, slower) or a self-contained integration test that creates its own throwaway REST API (mock integration) against Floci? I propose self-contained so it doesn't depend on any product API's auth config. OK?
A2. REST API (v1) only, or must HTTP API (v2) be covered too? AWS has no API keys on v2 and unknown routes on v2 return 404 — I propose v1 only and an explicit note.
A3. Exact 403 contract to assert for missing/invalid key and unknown route: status only, or also body `{"message":"Forbidden"}` vs `{"message":"Missing Authentication Token"}` and `x-amzn-ErrorType` header? (AWS: ForbiddenException vs MissingAuthenticationTokenException.)
A4. Is it acceptable that the "accepted" case binds the key via CreateUsagePlanKey on a plan created with apiStages, and asserts only the invoke result (200), never GetUsagePlan apiStages? Should we also assert a key in a plan NOT linked to the stage is rejected (that negative depends on Floci checking plan.getApiStages server-side, ApiGatewayExecuteController ~l.1356)?
A5. Logs cap: is a doc note + a bounded assertion (write N > cap? too slow) acceptable, or doc-only? I propose doc-only plus a small test that the eviction diagnostic is not triggered under normal volume — please confirm the expected shape.
A6. Should the test client header be `x-api-key` only (no usage-identifier-key / authorizer source)?

## Questions for security-auditor (read-only review)
S1. Key handling: test generates a random key value per run (CreateApiKey generateDistinctId) and never logs it; key + plan are deleted in t.Cleanup. Any concern with logging the key id (not value)?
S2. Is asserting only "missing/invalid key -> 403" enough, or must we also check that a disabled key (enabled=false) and a key bound to another stage are rejected?
S3. Any concern that binding directly (bypassing apiStages read-back) masks a real misconfiguration in production code paths (e.g. go-services/testutils/integrationtests/client.go:180, buildingsvc helpers_api_test.go:223)? 27.28 / 44.1 stays out of scope.
S4. The unknown-route 403 must not leak resource existence (same 403 for unknown path and for known path without key?) — should the test assert identical bodies?

## Not blocked on answers (proceeding)
Lock, issue, worktree, task.md, skeleton of the self-contained REST API fixture (mock integration, ApiKeyRequired method, stage deploy), and the unknown-route case.
