# T-27.1 security re-review: PR Thiink-LLC/teos#1242 @ 4ac29c54
Reviewer: security-auditor · Packet msg-W-2026-0001-dev-lead-213 · 2026-10-22 (Europe/Stockholm)
Method: read-only git show/diff of 18852fbf..4ac29c54 in the local repo. Diff: deployment/stacks/groundzero/service-test/apigw_contract_test.go (+389), go.mod (+1). I checked evidence.md against the code. No AWS calls. No secret files read.
PR: https://github.com/Thiink-LLC/teos/pull/1242

## Verdict: **approve**
I checked against the code, not only evidence.md.

## Per-finding status
| id | status | evidence (file:line @4ac29c54) |
|---|---|---|
| SEC-1 | **resolved** | deployment/stacks/groundzero/service-test/apigw_contract_test.go:114-117 disabled key → 403. deployment/stacks/groundzero/service-test/apigw_contract_test.go:119-128 key works while bound (200), then DeleteUsagePlanKey, then 403 (revocation). deployment/stacks/groundzero/service-test/apigw_contract_test.go:130-141 key in a plan not linked to the stage → 403, with a named Floci 44.1 skip only when Floci returns 200 on local. Missing/unknown key: deployment/stacks/groundzero/service-test/apigw_contract_test.go:89-96. evidence.md:6 says the unlinked case got a real 403, so the skip did not fire. |
| SEC-2 | **partial (accepted, out of scope)** | The new test is self-contained and doesn't use the helpers. The gap is documented at deployment/stacks/groundzero/service-test/apigw_contract_test.go:33-35. The local-target `IsLocal()` skip in go-services/testutils/integrationtests/client.go:180-195 and buildingsvc helpers_api_test.go:222-233 is unchanged and stays with 27.28/44.1. Not a blocker for this PR. |
| SEC-3 | **resolved** | Key values are generated with crypto/rand ($F:47, 369-376, 256-bit) and sent only in the x-api-key header ($F:267-269). Only ids are logged ($F:364, 338, 351). Failure messages carry ids, never values ($F:126, 332, 358). assertNothingEchoed ($F:303-313) checks with booleans and fixed messages and redacts the key before any assertion that could print the body. The request is never logged ($F:260-276). The test doesn't use the mgrapigwv1 ApiKey struct, so it can't log the struct. |

## New issues
| id | sev | location | issue | recommendation |
|---|---|---|---|---|
| SEC-8 | Info | deployment/stacks/groundzero/service-test/apigw_contract_test.go:290-294 | On Floci the x-amzn-ErrorType check on the ApiKeyRequired 403 is softened to a t.Log. It is still enforced off Floci, and status plus message are still asserted. | None. Track the gap with the Floci issue (#1241). |
| SEC-9 | Info | deployment/stacks/groundzero/service-test/apigw_contract_test.go:110-111 | On a 200 mismatch, assert.JSONEq prints the body. That body is the fixed mock response with no key in it, so no leak. | None. |

No new Medium or higher issues. Cleanup is registered right after each create and runs LIFO ($F:195-197, 334-362), which matches SEC-6.

## Escalation flags
None. No authz-bypass, secret-leak, tenant-bleed or iam-loosening.
