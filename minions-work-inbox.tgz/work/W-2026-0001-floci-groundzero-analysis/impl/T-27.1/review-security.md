# T-27.1 security review: API-key binding approach (read-only)
Reviewer: security-auditor · Work W-2026-0001 · Packet T-27.1 · 2026-10-22 (Europe/Stockholm)
Scope: consult-request.md (S1–S4), go-core/managers/mgrapi/mgrapigwv1/{keys.go,plans.go}, go-services/testutils/integrationtests/client.go, go-services/buildingsvc/deployment/service-test/helpers_api_test.go. Floci only. No code changes, no AWS calls, no secret file read.

## Verdict: **approve-with-changes**
The plan is test-only and lowers no production control. The direct binding (CreateApiKey → CreateUsagePlan(apiStages) → CreateUsagePlanKey) is fine for a self-contained fixture. To count as evidence that keys are enforced, it needs the negative cases listed below. Fix the existing local-target bypass in follow-up 27.28/44.1.

## Findings
| id | sev | location | issue | recommendation |
|---|---|---|---|---|
| SEC-1 | High (test-coverage / authz) | consult-request.md S2/A4 | If the test only checks "missing/invalid → 403" and "bound key → 200", it cannot catch a gateway that accepts **any existing** key. That is the main API-key authz risk: a key from another plan, stage or tenant passes. | Add negatives: (a) a valid key in a plan **not** linked to the stage → 403; (b) a key with `enabled=false` → 403; (c) a key that was bound and then unbound (DeleteUsagePlanKey) → 403, which also proves revocation. If Floci fails (a) (ApiGatewayExecuteController ~l.1356), mark it a known Floci gap with a skip that names 44.1. Do not silently drop it. |
| SEC-2 | Medium (tenant-bleed risk, existing code) | go-services/testutils/integrationtests/client.go:180-195; go-services/buildingsvc/deployment/service-test/helpers_api_test.go:222-233 | On local targets the key is created but **never bound**, and the comment says Floci does not check keys. As a result, local suites cannot see key/plan/stage authz at all, and a binding regression in BindApiKeyToApiNameAndUsagePlans would pass locally. This answers S3: the new direct-binding test does not mask production paths, but it does not cover them either. | Keep the new test separate from these helpers (A1 self-contained is good). In 27.28/44.1, remove the `IsLocal()` skip once Floci keeps apiStages. Until then, record the gap in the test doc. |
| SEC-3 | Medium (secret handling) | go-core/managers/mgrapi/mgrapigwv1/keys.go:225-250, 293, 412 | The key `Value` is returned on `ApiKey` and fetched with IncludeValue/IncludeValues=true. Logging `%+v` of the struct, an error wrap or a t.Log dump of apiKey would leak the value. | Log only the key **id** and name (S1: logging the id is fine). Never log the struct, response bodies or request headers. Pass the value only in the `x-api-key` header. On failure, assert with a redacted message. |
| SEC-4 | Low (entropy / generation) | keys.go:211; go-core utils RandomKey:71-83 | S1 says "CreateApiKey generateDistinctId", but the prod manager sends its own value: 256-bit crypto/rand, base64. Entropy is strong. Either path is acceptable. | Use the manager with value="" (256-bit) or GenerateDistinctId. Don't hard-code a key literal in the test. |
| SEC-5 | Low (info disclosure) | consult-request.md S4/A3 | Unknown path and known path without key should not let a caller enumerate resources. On AWS, unknown route gives MissingAuthenticationToken and missing key gives Forbidden, so the bodies differ by design and that is AWS behavior. | Don't assert identical bodies. Assert status 403 plus the exact AWS body/x-amzn-ErrorType for each case. Also assert that the body has no path, stage, API id or key material echoed back. |
| SEC-6 | Low (hygiene / defense-in-depth) | consult-request.md S1 | Cleanup order and leftover resources: a key that is not deleted after a failed run stays valid. | In t.Cleanup, delete the usage-plan key, then the plan, then the key, then the REST API. Use unique per-run names. Log cleanup errors by id only. |
| SEC-7 | Info | n/a | Hashing at rest, constant-time comparison and rotation are owned by API Gateway, not by TEOS code. API keys are not an authN mechanism. Tenant/principal binding comes from the Cognito/JWT scopes the helpers also obtain (waitForScopes). | State in the test doc that API keys are a throttling/identification control, not tenant authZ. No IAM change is needed. The test uses Floci creds only. |

Counts: High 1 · Medium 2 · Low 3 · Info 1.

## Answers to the security questions
- S1: Logging the id is OK. Never log the value or the struct (SEC-3, SEC-6).
- S2: Not enough. Add disabled-key, other-plan/stage and revoked-key negatives (SEC-1).
- S3: Nothing is masked in prod. The existing local skip is a real coverage gap (SEC-2), tracked with 27.28/44.1.
- S4: Don't require identical bodies. Assert the AWS contract and that nothing is echoed back (SEC-5).

## Escalation flags
None. No authz-bypass, secret-leak, tenant-bleed or iam-loosening is introduced. SEC-2 is an existing *test-environment* authz blind spot. Treat it as tenant-bleed **watch**, not an escalation.
