# T-27.1 consult answer from api-designer (A1–A6)

From: api-designer minion · To: golang-pro via dev-lead · 2026-10-22 (Europe/Stockholm)
Scope: test-only compatibility contract for Floci API Gateway v1. Floci only, no real AWS. Hard constraints applied: bind the key directly; never read `apiStages` back (Floci 44.1).
Framing: these tests check Floci against the **AWS API Gateway edge contract**. They are not a TEOS product API. So TEOS rules (problem+json, pagination, versioning) do **not** apply to the asserted bodies. Assert AWS's wire shape, not ours.

## A1. Home
**Recommendation:** Self-contained. The test creates its own throwaway REST API (MOCK integration, one `ApiKeyRequired` GET method, deploy to stage `test`). Put it next to the groundzero service tests as you planned (`deployment/stacks/groundzero/service-test/apigw_contract_test.go`), but it must deploy **no** product stacks. Use the existing Floci harness, and use a run-unique name prefix so parallel runs don't collide.
**Why:** It tests Floci's edge behaviour, so it should not depend on any product API's auth config (buildingsvc/SUR authorizers, 27.28 hazard). It runs faster and fails for one clear reason.
**Hexagonal note:** The fixture is test-infrastructure only. Don't import product adapters or domain packages. If you need a helper, keep it local to the test package; don't add it to `go-services/testutils` (that would be a new shared contract).
**Risk:** A self-contained API won't catch drift in the real product API wiring. That is 27.28's job and out of scope here.

## A2. v1 only?
**Recommendation:** v1 (REST API) only. Add an explicit doc comment and a test-file note: "HTTP API (v2) not covered: v2 has no API keys/usage plans, and unknown routes return 404 `{"message":"Not Found"}`."
**Why:** The 27.1 scope is API keys plus "Missing Authentication Token". Both exist only on v1.
**Risk:** None for this task. If a product later moves to v2, that's a separate item.

## A3. Exact 403 contract
**Recommendation:** Assert status **and** body `message` **and** `x-amzn-ErrorType` (prefix match), all three:
| Case | Status | body.message | x-amzn-ErrorType starts with |
|---|---|---|---|
| Missing key on ApiKeyRequired method | 403 | `Forbidden` | `ForbiddenException` |
| Invalid/unknown key value | 403 | `Forbidden` | `ForbiddenException` |
| Unknown path on deployed stage | 403 | `Missing Authentication Token` | `MissingAuthenticationTokenException` |
- Parse the body as JSON and compare the `message` field only. Don't compare the raw string, because AWS/Floci may add fields or whitespace.
- Match the header by prefix (AWS sometimes appends `:http://internal.amazon.com/...`). If Floci doesn't send the header today, fall back to `t.Skip`/soft-assert with a TODO that links the Floci issue. Don't drop the check silently.
- Don't assert `Content-Type` beyond `application/json` prefix.
**Why:** Status alone can't tell "missing key" apart from "unknown route" (both 403). The message/type pair is the real contract that SDKs and clients branch on.
**Note:** AWS's own `{"message":...}` shape is intentionally **not** problem+json. Don't "fix" it. That is correct AWS fidelity.

## A4. Direct binding and the negative case
**Recommendation (positive):** Yes. Call `CreateApiKey(enabled=true, generateDistinctId)` → `CreateUsagePlan(apiStages=[{apiId, stage}])` → `CreateUsagePlanKey(keyType=API_KEY)` → invoke with `x-api-key` → assert 200 plus the mock body. **Never** call `GetUsagePlan`/`GetUsagePlans` to verify `apiStages`. Add a comment that names Floci 44.1 as the reason.
**Recommendation (negative "plan not linked to stage"):** Include it, but as a **separate, skippable subtest** (`t.Run("key_in_unlinked_plan_rejected")`). It creates a second plan with no `apiStages` (or one linked to a different stage), binds a fresh key, and expects 403 `Forbidden`. It only checks the invoke result, so it does not read `apiStages` back and the hard constraint still holds. If Floci doesn't enforce it server-side (ApiGatewayExecuteController ~l.1356), mark it `t.Skip("floci: unlinked-plan enforcement, see <issue>")` rather than block 27.1.
**Why:** Without the negative, the positive test passes even if Floci accepts *any* existing key. That would be a false-green on the security property.
**Propagation delay:** AWS needs propagation time, Floci doesn't. Don't add sleeps. If a retry is ever needed, use a bounded poll (≤5 s) on the invoke, not on a read-back.

## A5. Logs cap
**Recommendation:** Doc-only, plus one cheap assertion. Don't write more than 20,000 events.
- Doc: in the test-file header and the groundzero service-test README/LINT-adjacent doc, record that the CloudWatch Logs cap is 20,000 stored events account-wide, the eviction is oldest-first (confirm against Floci source and record what you find), the diagnostic text/log line, and that the override is `FLOCI_SERVICES_CLOUDWATCHLOGS_MAX_STORED_EVENTS` via `WithEnv` only. Don't add a second retention control.
- Assertion shape: after the API-key cases run, `FilterLogEvents`/`GetLogEvents` on the test's own log group returns the events you wrote (count equals the number written, small N such as 10), **and** the Floci container log does not contain the eviction diagnostic string. Name it `TestLogsCap_NoEvictionUnderNormalVolume`.
**Why:** Writing more than 20k events is slow and checks Floci internals rather than the 27.1 contract. Writing a few and checking for no eviction covers the regression we care about.
**Risk:** The container-log grep is coupled to the diagnostic string. Keep that string in one constant with a source reference.

## A6. Header
**Recommendation:** `x-api-key` only. API key source = `HEADER` (the default; set it explicitly on CreateRestApi so the test documents it). No `AUTHORIZER` key source and no usage-identifier-key. Use the exact lowercase header name. Optionally, add one case-insensitivity subtest (`X-API-Key`) only if you want HTTP fidelity, but that's not required.
**Why:** It covers the only product-relevant path. The authorizer key source is an auth-model variant and would widen scope.

## Escalations to lead-architect
- **None required for T-27.1.** It's test-only, adds no public/product API, makes no breaking change, and doesn't change the auth model.
- **Watch item (not an escalation now):** If anyone proposes moving the API-key fixture into shared `go-services/testutils`, or changing the product clients (`testutils/integrationtests/client.go:180`, buildingsvc `helpers_api_test.go:223`) to bind directly instead of the apiStages path, that changes a shared test contract and how products model API-key binding. Route it through lead-architect (possible ADR) together with 27.28/44.1.
- **Possible Floci follow-ups (to dev-lead, not blockers):** a missing `x-amzn-ErrorType` header, or no server-side enforcement of unlinked plans. Each one becomes a skip with an issue link.

## Open blockers
None. golang-pro can proceed with the positive, missing, invalid and unknown-route cases now. The negative-plan subtest and the header assert can be skipped if Floci doesn't support them yet.
