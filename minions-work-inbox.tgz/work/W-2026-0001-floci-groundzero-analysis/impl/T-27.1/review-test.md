# Test review — T-27.1 (W-2026-0001), PR #1242 @ 4ac29c54

== Verdict == APPROVED_DEGRADED

== Findings ==
[Minor] [hard-to-test] deployment/stacks/groundzero/service-test/apigw_contract_test.go:288-297 — assertForbiddenErrorType is a conditional assert. When the target is local and the header is empty, it logs and returns, and the log shows this happens on all five 403 Forbidden cases. Status and message are still asserted, and the gap is named and filed for Task 50, so it is not silent. Because the file is built only with floci, though, the ForbiddenException header check never runs anywhere. Fix: add it to the Floci gap task so the relaxation is removed when Floci sets the header.
[Minor] [testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:130-141 — key_in_unlinked_plan_rejected has a conditional skip, but it is narrow: it needs status 200 AND IsLocal, and it carries a Floci 44.1 marker. It did not fire at 4ac29c54, where a real 403 was asserted. Acceptable, and it meets SEC-1's "do not silently drop" requirement.
[Minor] [non-testable] gates/test-service-4ac29c54.log:75-109 — The package result is FAIL (rc=1) because of TestThePublicNamesResolveToThisMachine: the box's sandbox DNS answers 198.18.0.1, which is live-DNS dependent. The test is not touched by this PR and also failed at 591db968. The claim "TestRestAPIContract 7/7 plus the 403 cases pass" is true at test level, but the run is not green at package level. Fix: rerun on a box with working local DNS, or record the environmental failure in the gate summary as accepted.
[Info] [testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go:89,130,144 — Naming is mixed. Most subtests are sentences ("missing key is forbidden"), but one is snake_case (key_in_unlinked_plan_rejected), and TestLogsCap_NoEvictionUnderNormalVolume does not match the suite's TestThe… style. This is cosmetic.
[Info] [hard-to-test] deployment/stacks/groundzero/service-test/apigw_contract_test.go:119-128 — The revocation case asserts 403 straight after DeleteUsagePlanKey, with no polling. That is fine on Floci, which is synchronous, but it would flake on real AWS, where propagation takes minutes. The file is Floci-only, so this is noted for any future real-AWS port, where require.Eventually would be needed.
[Info] PR body has "Closes #1241". Build tag is //go:build e2e && floci. Resource names are unique per run (UnixNano suffix). Each delete is registered in t.Cleanup right after its create, in SEC-6 order. There is no time.Sleep. The only require.Eventually is in the logs test. Key values come from crypto/rand and are never logged (SEC-3/4). Bodies are checked so they do not echo the key, path, stage or API id (SEC-5).

== Rationale ==
SEC-1 negative cases, from impl/T-27.1/review-security.md, mapped to tests:
- (a) A valid key in a plan not linked to the stage gets 403: TestRestAPIContract/key_in_unlinked_plan_rejected (deployment/stacks/groundzero/service-test/apigw_contract_test.go:130). It PASSed with a real 403, and the 44.1 skip was not used.
- (b) A key with enabled=false gets 403: TestRestAPIContract/disabled_key_is_forbidden (deployment/stacks/groundzero/service-test/apigw_contract_test.go:114). PASS.
- (c) A key that was bound and then unbound gets 403: TestRestAPIContract/key_bound_and_then_unbound_is_forbidden (deployment/stacks/groundzero/service-test/apigw_contract_test.go:119). It first proves the key is accepted with 200 while bound, then deletes the binding and asserts 403. PASS.

The baselines are missing key → 403 (deployment/stacks/groundzero/service-test/apigw_contract_test.go:89), unknown key → 403 (deployment/stacks/groundzero/service-test/apigw_contract_test.go:93) and unknown path → 403 MissingAuthenticationToken (deployment/stacks/groundzero/service-test/apigw_contract_test.go:98). The positive control, a bound key → 200 (deployment/stacks/groundzero/service-test/apigw_contract_test.go:107), shows the negatives are not trivially passing. No SEC-1 ec-gap. SEC-2 is out of scope and tracked under 27.28 / Floci 44.1.

Evidence: gates/test-service-4ac29c54.log has the header HEAD 4ac29c54ae7f…, Floci a31d6e08f9a8…dd5c1, and was run with go test -tags=e2e,floci -count=1 -v -race. All 7 TestRestAPIContract subtests and TestLogsCap pass.

The verdict is DEGRADED for three reasons: the package run is red because of the unrelated DNS test, the ForbiddenException header is relaxed on Floci, and CI does not run e2e.

CI at 4ac29c54: CodeQL SUCCESS, Analyze (actions) SUCCESS, Analyze (js-ts) SUCCESS. Build, Unit Tests, Static Analysis and Architecture were SKIPPED. Bugbot (usage limit) and the Security Reviewer were NEUTRAL.

---
# Re-review — PR #1242 @ 87ab8715 (2026-10-22 21:4x CEST)

== Verdict == APPROVED_DEGRADED (PROVISIONAL: conditional on the final Floci service-test rc)

== Findings ==
[Major] [non-testable] impl/T-27.1/evidence.md — There is no Floci service-test run at 87ab8715. There are only static gates (summary-87ab8715.txt, all rc=0). Since 4ac29c54 the revocation polling, the subtest and test renames and the logs assertion have changed. Needed: gates/test-service-87ab8715.log, with the header HEAD 87ab871560a0… and image a31d6e08f9a8…dd5c1, run with -tags=e2e,floci -count=1 -race -v. It must show all 7 TestRestAPIContract subtests PASS, including "key in a plan not linked to the stage is forbidden" with a real 403 or else an FG-4 SKIP, plus TestTheLogsCapEvictsNothingUnderNormalVolume PASS. The package rc must be 0, or the only failure must be TestThePublicNamesResolveToThisMachine; that test becomes a SKIP once #1244 is in the base.
[Minor] [non-testable] PR #1242 body — The body is stale. It still names TestLogsCap_NoEvictionUnderNormalVolume, which is now TestTheLogsCapEvictsNothingUnderNormalVolume. It says "Gate and service-test evidence will follow" and cites only Floci 44.1, not FG-4/FG-7. Fix: update the body the way #1240's was.
[Info] [testable] deployment/stacks/groundzero/service-test/apigw_contract_test.go — RESOLVED. The revocation case now polls for the 403 with require.EventuallyWithT (60s, 2s tick), using its own request so it doesn't call require from inside the closure. The earlier note about real-AWS propagation is addressed.
[Info] [testable] — RESOLVED. Naming is consistent: the "key in a plan not linked to the stage is forbidden" subtest and TestTheLogsCapEvictsNothingUnderNormalVolume. The logs test now checks which events are missing and reports whether the gap looks like eviction, not just a count.
[Info] [hard-to-test] — The Floci-gap markers now carry tracking ids: FG-4 (unlinked-plan skip, linked to floci-gaps/plans/FG-4.md) and FG-7 (missing x-amzn-ErrorType). This closes the "never runs anywhere" concern through tracking. The relaxation itself remains, as accepted.

== Rationale ==
The open findings are closed: the error-type relaxation is now tracked as FG-7, the skip as FG-4, naming is consistent, and revocation polling is in. The package-red DNS failure is being addressed by #1244. SEC-1 (a), (b) and (c) are still covered by the same subtests, one of them renamed. The verdict is PROVISIONAL on test-service-87ab8715.log as described above, and the PR body still needs updating.
CI at 87ab8715: CodeQL SUCCESS, Analyze (actions) SUCCESS, Analyze (js-ts) SUCCESS. Build, Unit Tests, Static Analysis and Architecture were SKIPPED. Bugbot and the Security Reviewer were NEUTRAL.
