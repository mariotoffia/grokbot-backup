Scope: Floci-only; no real-AWS runs (devlocal included).

# T-27.1 — test(local): API Gateway v1 contract cases on Floci (API key, unknown-route 403, Logs cap)

Work item W-2026-0001 · stream 1 (P-2026-0001-39..44) · golang-pro · start_gate: Mario's go relayed by dev-lead 2026-10-22 16:44
Branch chore/W-2026-0001-t27-1-apigw-contract-cases · base origin/main 18852fbf · Worktree /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-1-apigw-contract-cases
Inputs: consult-request.md, consult-api-designer.md (A1-A6, dev-lead msg-188), review-security.md (approve-with-changes, dev-lead msg-189).

## Scope
New deployment/stacks/groundzero/service-test/apigw_contract_test.go, self-contained throwaway REST API (v1, MOCK integration, ApiKeySource HEADER, one ApiKeyRequired GET, stage "test"); no product stacks; fixture stays local (no shared testutils).
- 403 missing key / invalid key: status, body.message "Forbidden", x-amzn-ErrorType prefix ForbiddenException; no path/stage/api id/key echoed.
- 403 unknown path: "Missing Authentication Token", MissingAuthenticationTokenException.
- 200 for a key bound directly (CreateApiKey -> CreateUsagePlan(apiStages) -> CreateUsagePlanKey); never read apiStages back (Floci 44.1).
- Negatives (SEC-1), each 403: key in a plan not linked to the stage (own skippable subtest citing 44.1 if Floci fails), disabled key, bound-then-unbound key.
- Logs cap: doc in the file header (20,000-event account-wide cap, FLOCI_SERVICES_CLOUDWATCHLOGS_MAX_STORED_EVENTS via WithEnv only) + TestLogsCap_NoEvictionUnderNormalVolume (write 10, read 10).
- SEC-3: log only key ids. SEC-6: cleanup order plan key -> plan -> key -> API. SEC-7 doc note.

## Acceptance
All cases pass on Floci (pinned digest) with -race under the floci-harness-run lock; gates fmt/lint/vet, go-arch-lint direct, make test clean env, tidy clean.
