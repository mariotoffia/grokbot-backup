# T-27.1 evidence: API Gateway REST contract and CloudWatch Logs cap (issue #1241, PR #1242)

HEAD 4ac29c54ae7f3b3c07ea2aada1c117b58459bfa6. Floci image mariotoffia/floci:latest, which resolved to sha256:a31d6e08f9a8… for these runs (recorded digest, not a pin). For the current HEAD see the f9497460 section below.

## Service test: gates/test-service-4ac29c54.log (groundzero, -race, under floci-harness-run)
- TestRestAPIContract PASS on all 7 subtests. key_in_unlinked_plan_rejected got a real 403, so the 44.1 skip was not needed. TestLogsCap_NoEvictionUnderNormalVolume PASS.
- Floci gap (new, for Task 50): the ApiKeyRequired 403 Forbidden has no x-amzn-ErrorType header. MissingAuthenticationTokenException does have it. The status and message are still asserted, and the header is still required off Floci.
- Package rc=1 only because of TestThePublicNamesResolveToThisMachine, which is not touched by this PR. On this box, *.devlocal02.localhost.floci.io resolves to 198.18.0.1, the sandbox DNS, which is environmental. It also failed at 591db968.
- The earlier 591db968 run (gates/test-service-591db968.log) was red on the missing header, which led to 4ac29c54.

## msg-204
- fmt, vet and lint were rc=2 at 04a70181 because of the worktree environment, not this change: there were no node_modules (prettier) and no generated sur code. Fixed with `make dep && make generate` in this worktree (gates/dep-generate.log; the first try hit an apt 500).
- All 5 Copilot threads were fixed in 591db968, then replied to and resolved: e2e && floci tag, boolean key and detail checks with redaction, disclosure checks in the unlinked case, bare stage name, cleanup right after each create.

## Security
- SEC-1: done (three negative cases). SEC-3: only key ids are logged.
- SEC-2: tracked under 27.28 / Floci 44.1. The product test clients do not bind keys on the local target, and that is not changed here.

## Gates
See gates/summary-4ac29c54.txt. lint-arch ran and passed; no map covers deployment/stacks/groundzero/service-test (W-2026-0003).


## Box inode cleanup (dev-lead msg-190), 2026-10-22 ~17:55 CEST
BEFORE `df -i /`:
    Filesystem      Inodes   IUsed IFree IUse% Mounted on
    /dev/vdb       2080768 2080768     0  100% /
Action: `go clean -cache` (succeeded; no rm fallback needed).
AFTER `df -i /`:
    Filesystem      Inodes   IUsed  IFree IUse% Mounted on
    /dev/vdb       2080768 1358389 722379   66% /
(df -h after: 128G size, 43G used, 85G avail.)
Worktrees removed (PR MERGED + clean, branches kept): t27-14 (#1213), t27-16-3 (#1230). Skipped (not clean: untracked pandoc-3.11-1-amd64.deb* from make dep): t27-10 (#1215), t27-12 (#1212), t27-25 (#1214).
/tmp: nothing deleted. All /tmp files are owned by the shared `box` user, so files from before today can't be attributed to me; my own files there are from today's runs.

## 2026-10-22 msg-210 / msg-214 / msg-217 (golang-pro stream 1)
- HEAD 87ab8715 (pushed, no force), on top of 952d639a (FG-7 id).
- FG-7 (the API-key 403 has no x-amzn-ErrorType, plans/FG-7.md): Floci-only soft-assert at apigw_contract_test.go:328-333. The A3 unlinked-plan skip now names FG-4 (Floci 44.1).
- msg-214: subtest renamed "key in a plan not linked to the stage is forbidden"; test renamed TestTheLogsCapEvictsNothingUnderNormalVolume; the revocation 403 is awaited with EventuallyWithT.
- msg-217:
  - The worktree was clean (no uncommitted edit found at 20:38 CEST).
  - A5: the logs cap is now documented on its test rather than the file header. It cites Floci source at 5beb8d47b: EmulatorConfig.java:1953 (default 20000), CloudWatchLogsService.java:791-800 (evictEventsBeyondCapacity), and LogEventIndex.java:14-31 (oldest = earliest timestamp, then sequence, then id). The test now has an eviction diagnostic (missing oldest-first prefix = cap eviction).
  - The always-0 Eventually message was replaced by EventuallyWithT with the count in the assertion.
- Static gates at 87ab8715: gates/summary-87ab8715.txt, all rc=0. lint-arch ran and passed; no map covers ./deployment/stacks/groundzero/service-test/... (W-2026-0003).
- TestThePublicNamesResolveToThisMachine fails outside this PR's scope: the box DNS resolves every name to 198.18.0.1 (dns-198-18.md). It is left alone here and fixed separately in #1243.

## msg-221/222 (21:55 CEST)
- 4b08764e (local, NOT pushed): adds deployment/stacks/groundzero/service-test/README.md, the logs-cap pointer for A5.
- PR #1242 body updated: TestTheLogsCapEvictsNothingUnderNormalVolume, FG-4/FG-7 in place of 44.1, and "evidence will follow" removed.
- Package-scoped gates (make missing) in gates/summary-nomake-4b08764e.txt: all rc=0. The make §1 gates gave rc=127.
- Service run test-service-4b08764e.log was aborted right after it started (parent: no service runs while make is missing). No rc.
- #1244 is on hold (msg-232). The PublicNames DNS failure is environmental and is not being worked around.

## f9497460 (2026-10-23, msg-290)
- Image: mariotoffia/floci:latest. The f9497460 runs resolved :latest to sha256:07ced9c6d987de7ca432fa35d0f1856ad1c8c87a4fdb96ac3b00b6e68bba2ba1 after a fresh pull (~11:12 CEST). This is a recorded digest, not a pin. Earlier runs resolved :latest to a31d6e08; that was never a pin either.
- gates/test-service-race-f9497460.log: groundzero `go test -tags=e2e,floci -count=1 -v -race` under floci-harness-run, rc=0. TestRestAPIContract PASS 7/7, including the strict FG-4 case.
- gates/test-service-f9497460.log: `make test-service CB_SERVICE_TEST=groundzero`, rc=0.
- Test change: the x-amzn-ErrorType header checks are dropped. FG-4 (unlinked-plan key) is strict, with no IsLocal skip. The 403 status, exact body message and no-echo checks remain.
- The MissingAuthenticationTokenException check on the unknown-path case was dropped on purpose. It is an x-amzn-ErrorType value, so Mario's 10:41 decision to drop all x-amzn-ErrorType assertions covers it. The unknown path is still asserted as 403 + exact "Missing Authentication Token". FG-7 (Floci list 50.5) no longer has a test hook.
- gates/test-integration-rerun-f9497460.log: make test-integration (-race), rc=2, caused only by the existing cmd/cblicense failure (TEOS_DEPLOYMENT "local" but AWS_ENDPOINT_URL not set). That failure is outside this diff and tracked in #1245.
- gates/test-service-f9497460-goflags-race-cgo-fail.log is void ("-race requires cgo" from GOFLAGS=-race on the CGO_ENABLED=0 Lambda builds). It is superseded by test-service-race-f9497460.log.
- Static gates: vet-f9497460-rerun.log rc=0 and lint-go-f9497460-rerun.log rc=0, after restoring the noda webui/dist and building the tklocal webui/dist (tklocal-webui-build-f9497460.log). gofmt, lint-arch and tidy rc=0.
- 75c3be6b: comment-only follow-up (plan ids out of the header, rejection checks described as status 403 + exact body + no echo). gofmt/vet/golangci-lint e2e,floci rc=0 (gates/*-comment-precommit.log); the f9497460 test runs still apply since no code changed.
