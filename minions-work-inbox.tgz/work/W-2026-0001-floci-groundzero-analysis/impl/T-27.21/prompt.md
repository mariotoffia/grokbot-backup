# Cloud-agent prompt — TEOS 27.21: test(cbtarget): compare shadow metadata timestamps on Floci

You are a Go engineer working in the GitHub repository **Thiink-LLC/teos**. This prompt is self-contained.

## Setup
- Base commit: `863b6019` (main). Create branch **`chore/W-2026-0001-t27-21-shadow-metadata-timestamps`** from it. Do not rebase onto newer main unless CI requires it.
- First read `AGENTS.md`, `GITHUB.md`, `TESTS.md`, `DEVELOPMENT.md`, `BUILD_TAGS.md`, `LINT.md`, `go-core/PACKAGES.md`. They are authoritative.
- Bootstrap: `make install` (if tools missing), `make dep`, `make generate`. Errors before these finish mean "not bootstrapped", not "broken code". Build/test per module via make targets; `./...` does not work at the repo root.
- Floci image pin: test against `mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1` (index digest; re-pinned by dev-lead 2026-10-22 11:47, see STATUS.md). If the digest differs, stop and write `ESCALATION: dependency — floci digest mismatch <digest>`. Do NOT edit `go-core/utils/testutils/flocilocal/consts.go` or `deployment/provision-config.yaml` pins.

## Goal
Remove the `device shadow metadata` marker and the skip under it at both sites, so the two tests compare per-sensor timestamps from GetThingShadow `metadata` on Floci. Floci 9.6 (in floci-io/floci#5260) is in the pinned image. Nothing else changes.

## Before you code
If metadata timestamps differ in shape from AWS (e.g. seconds vs ms), report it as a Floci follow-up via ESCALATION, do not adapt the test to Floci.

## Files you may change
- `go-core/cbtarget/awsdstarget/target_integration_test.go`
- `go-core/cbtarget/awsdstarget_integration_test.go`
Anything else needs `ESCALATION: conflict — <path> <why>` first.

## Acceptance criteria (each is a regression test)
1. TestProcessedPayloadFormatTypeSensorsFiltered (awsdstarget/target_integration_test.go:214) runs (not skipped) and passes on the pinned image.
2. TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered (awsdstarget_integration_test.go:46) runs and passes on the pinned image.
3. Both markers and their skips are deleted; nothing else in the files changes.
4. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `make test-integration`; evidence in impl/T-27.21/evidence.md. If either fails on Floci, do NOT re-add a skip: systematic-debugging, then `ESCALATION: verify-failed` with the diff of expected vs actual metadata.

## How to work
- **TDD**: write the failing test first, run it, see it fail for the right reason, then the minimal change, then green. Tests in `<package>_test` packages; reuse `go-core/utils/testutils`, `awstestutil`, `go-core/managers/**`.
- **Systematic debugging** on any failure: reproduce, read the full error, form one hypothesis, test it, fix root cause. No retries-until-green, no new skips, no weakened assertions.
- Code comments describe what the code is: no task IDs, plan IDs, commit hashes or "used to" stories. Plain, simple English everywhere (AGENTS.md banned-metaphor list applies).

## Gates (all must pass; paste commands + pass/fail into the PR description)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `make test-integration`
Marker check: `rg -n "floci: Missing Implementation for" go-core/cbtarget/awsdstarget/target_integration_test.go go-core/cbtarget/awsdstarget_integration_test.go`

## PR rules (GITHUB.md + DEVELOPMENT.md)
- Conventional commits, e.g. `test(cbtarget): compare shadow metadata timestamps on Floci`. **No byline / Co-Authored-By.** **No GitHub closing keywords** (fixes/closes/resolves #N) anywhere in commits or PR body.
- One PR for this task only, to `main`. Never push to main, never merge, never force-push a shared branch.
- CI is label-gated: add labels `build`, `unit-test`, `lint` (`gh pr create --label ...` or `cbtest pr set lint unit build`); an unlabeled PR runs nothing.
- PR body, written for an engineer who never opened the repo: what changed, why, what you did NOT do and why, image digest used, tests run vs skipped, marker grep output, gate results.
- GitHub API discipline: poll at most once per 5 minutes, never during coding/tests; serialize requests; on rate limit stop and wait for Retry-After/X-RateLimit-Reset. After each push request a Copilot review once (unless that commit already has one); later fix confirmed findings and give every finding a reasoned reply.
- No real-AWS runs (Floci-only scope). Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `make test-integration`; evidence in impl/T-27.21/evidence.md.

## Stop condition
Stop when the PR is open, all gates above are green locally, CI labels are set and the CI workflows you triggered are green (or still running — say which). Then reply with: PR URL, branch, head SHA, gate table, tests run vs skipped, image digest, marker grep.

## ESCALATION convention
If you cannot proceed, put one line at the top of the PR description (or your final reply if no PR) and stop:
`ESCALATION: <code> — <one-line reason>` where code ∈ need-input | need-approval | dependency | conflict | verify-failed | ceiling-exceeded | unclear-brief | already-done.
Give details below that line. Do not work around the problem.
