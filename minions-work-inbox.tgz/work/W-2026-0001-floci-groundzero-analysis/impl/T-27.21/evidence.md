# T-27.21 evidence: shadow metadata timestamps on Floci

- Image: mariotoffia/floci@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 (created 2026-10-22 10:45 Europe/Stockholm); DefaultImage `mariotoffia/floci:latest` unchanged.
- Probe (two nested updates): state `{"reported":{"sensors":{"IDT_O1":26.3,"ODT":-14.1},"tz":"Europe/Stockholm"}}`, per-leaf metadata, version 2 -> deep merge present.
- Branch: chore/W-2026-0001-t27-21-shadow-metadata-timestamps (base origin/main 863b6019)
- Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-21-shadow-metadata-timestamps
- Commit/HEAD: 2cfc189e test(cbtarget): compare shadow metadata timestamps on Floci (pushed)
- Draft PR: https://github.com/Thiink-LLC/teos/pull/1226
- Red (old image 9710d466): `expected -14.1 actual nil`. Green (a31d6e08): both sensor filter tests pass under -race.
- Marker grep in go-core/cbtarget: no hit.
- diff --stat 863b6019..HEAD: 2 files changed, 13 deletions(-)

## Gates (image a31d6e08, HEAD 2cfc189e, base 863b6019)
deps 0, generate 0, fmt 0, vet 0, test 0, tidy 0, git diff clean.
lint 0: golangci-lint is clean and lint-arch passes on its 9 maps. None of those maps covers go-core/cbtarget, so cbtarget was NOT arch-linted. The arch gate for cbtarget is reviewer sign-off, tracked in W-2026-0003. Reviews: hexagonal APPROVED_DEGRADED, clean-arch APPROVED.
cbtarget -race: 24 pass / 0 fail / 0 skip, 0 data races. AC1 and AC2 both run unskipped and pass.

### make test-integration (final)
1. First full run (`cbtest local exec --resources-only ... make run-integration-tests TEST_TAGS=integration,floci`), log logs/test-integration.log. Modules ./cmd through ./go-services/collectorsvc: 458 ok packages, 0 data races; FAIL cmd/cblicense and appstore/cmd/cbdeploy/internal/auth (both pre-existing, see below).
   About 12:18 the corerouter service-test teardown, which I had started in parallel, deleted cbtest's AWS_CA_BUNDLE temp file. From then on every package failed with "read the certificate file ... named by AWS_CA_BUNDLE: no such file". That covers gobridge onward and also the SSO TLS error. I stopped the run because those results were invalid. The process error was mine, and nothing in the code changed.
2. Rerun of the 48 modules from ./go-services/core/brokers/gobridge onward, in a fresh `cbtest local exec --resources-only` with the same per-module `go test -tags=integration,floci -count=1 -p 1 -race` loop, log logs/test-integration-rerun.log: 143 ok, 0 data races. gobridge is fully green. The only failures were `[build failed]` in providers/eastbound/sur, because model/surmodel/model_*.go had been deleted from the worktree at 12:53. That was an outside clean of the generated models, not this diff.
3. Ran `make -C go-services/providers/eastbound/sur generate-code` (git status clean afterwards) and re-tested the sur module under cbtest, log logs/test-integration-sur.log: 11 ok, 0 fail, 0 races.
4. Re-tested appstore/cmd/cbdeploy under cbtest, log logs/test-integration-cbdeploy.log: 15 ok; only TestSSOLoginAgainstTheLocalEmulator FAILs.
Result: across all 69 modules the only failures are cmd/cblicense (2 tests) and cbdeploy TestSSOLoginAgainstTheLocalEmulator. Both reproduce on clean origin/main 863b6019 (below), so neither comes from this change. No data races.

### Pre-existing on origin/main 863b6019 (detached worktree /workspace/t2721-base, removed afterwards; Floci only, AWS config /dev/null)
- `cd cmd/cblicense && TEOS_DEPLOYMENT=local AWS_ENDPOINT_URL=http://localhost:14566 AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test AWS_REGION=eu-north-1 go test -tags=integration,floci -count=1 -race -run TestCreateCommand ./...`
  The result is identical on base and on HEAD: FAIL TestCreateCommandRefusesAnotherAccountDomainForAnIssuedLicense and TestCreateCommandWritesAnIssuedLicenseGivenItsOwnAccountDomain, each with 6x "TEOS_DEPLOYMENT is \"local\" but AWS_ENDPOINT_URL is not set" (the CLI's child environment drops the endpoint). Logs: logs/cblicense-t2721-base.log, logs/cblicense-W-2026-0001-t27-21-...log. Without TEOS_DEPLOYMENT both trees pass.
- `cbtest local exec --resources-only ... -- go test -tags=integration,floci -count=1 -race -run TestSSOLoginAgainstTheLocalEmulator ./internal/auth/` (base go-services/appstore/cmd/cbdeploy): FAIL on base too, log logs/sso-base.log.
- The real-clock tests (time.Now() ±10 min) are out of scope, per test-review.

### corerouter-service service test (-race)
`TEOS_DEPLOYMENT=local CB_SERVICE_TEST=corerouter-service go test -race -tags=e2e,floci -count=1 ./...`: rc=0 in 138s. Deploy and undeploy on Floci both succeed. 0 pass / 0 fail / 2 skip: TestMirrorIngestFlow and TestMirrorIdtFlow are skipped by the existing Floci gap marker (the emulator does not publish shadow update/accepted over MQTT). That gap is not in this diff. 0 data races. Log: logs/corerouter-svc.log.

All logs are copied under impl/T-27.21/logs/.
