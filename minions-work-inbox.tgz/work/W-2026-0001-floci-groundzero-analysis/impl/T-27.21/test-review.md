# T-27.21 test review (test-reviewer minion, re msg-W-2026-0001-dev-lead-121)
PR: https://github.com/Thiink-LLC/teos/pull/1226 (draft, open) · HEAD 2cfc189e (local worktree = PR head) · Image mariotoffia/floci@sha256:a31d6e08… · Floci-only, read-only review, no tests re-run (I read the existing make test-integration log).

== Verdict ==
CHANGES_REQUESTED

== Findings ==
- [Medium] [testable] impl/T-27.21/evidence.md:15 — AC4 needs `make test-integration` green, but the evidence says the run is "in progress" (still running at 12:13 Europe/Stockholm, log /workspace/t2721/test-integration.log) and lists known cmd/cblicense FAILs (`AWS_ENDPOINT_URL is not set`). The gate is not yet shown green. Fix: let the run finish, then record the final per-module pass/fail/skip counts. Show that the cmd/cblicense failures also happen on origin/main 863b6019 (pre-existing) or get them waived. Add the corerouter service-test result.
- [Low] [non-testable] impl/T-27.21/task.md:22 — AC4 and the image line still pin sha256:9710d466. The evidence and the packet use a31d6e08, the image with the nested-shadow deep-merge fix. Fix: dev-lead updates the brief, or notes the re-pin in STATUS.md, so AC4 matches the evidence.
- [Low] [hard-to-test] go-core/cbtarget/awsdstarget_integration_test.go:120 and awsdstarget/target_integration_test.go:278 — these use the real clock (`time.Now()` ±10 min) against shadow metadata timestamps from the emulator. The ±10 min margin makes flakes unlikely, and the code was already there (not in this diff). Fix (optional, follow-up): derive the times from the shadow's own metadata timestamp or an injected clock.
- [Info] Coverage: AC1 → TestProcessedPayloadFormatTypeSensorsFiltered PASS (log l.39125). AC2 → TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered PASS (l.39109). Both ran unskipped under integration,floci on a31d6e08. AC3: the diff is only 2 marker+skip blocks plus the now-unused imports (13 deletions), and there is no marker hit. Build tags (`//go:build integration`) and the `<pkg>` integration test layout follow TESTS.md. The red-to-green story is consistent: 9710d466 gave expected -14.1 actual nil (no shadow deep merge), and a31d6e08 passes.
- [Info] The TestScenarios/AGG FAIL lines in the log are nested subprocess fixtures inside cbanalytics/bench report_test, and that package reports `ok`. They are not real failures.

== Rationale ==
The test change itself is correct and minimal, and both named tests map to AC1/AC2 and pass on the Floci image. There are no new flakiness risks; the real-clock use was already there and has a wide margin. AC4's full `make test-integration` gate is not yet proven green at HEAD 2cfc189e, because the run is still in progress and it has cmd/cblicense failures that have not been shown as pre-existing. The brief and the evidence also disagree on the pinned image digest. Once the evidence is completed and the cblicense failures are shown as pre-existing or waived, this can be APPROVED without any code change.

## Re-check (test-reviewer minion, re msg-W-2026-0001-dev-lead-141, 2026-10-22 13:1x Europe/Stockholm)
I checked the evidence.md and logs/ in this folder and re-ran no tests. HEAD is still 2cfc189e (PR head); image a31d6e08 is in every log that prints an image.

== Verdict ==
APPROVED

== Findings ==
- [Info] AC4 per-module counts (I counted the `^ok`/`^FAIL` lines myself):
  - First run test-integration.log: 479 ok / 27 FAIL, rc=2. The 25 gobridge and iam FAILs are the AWS_CA_BUNDLE temp file that was deleted mid-run (the run broke, the code did not).
  - Rerun test-integration-rerun.log, gobridge onward: 143 ok / 11 FAIL. All 11 are sur `[build failed]` from the deleted generated models. iam and gobridge are all ok (57 ok lines).
  - sur after `generate-code`: 11 ok / 0 FAIL. cbdeploy: 15 ok / 1 FAIL (TestSSOLoginAgainstTheLocalEmulator).
  - The only failures left are cmd/cblicense and the cbdeploy SSO test.
- [Info] cblicense is pre-existing: the same 2 tests fail on 863b6019 and on HEAD (TestCreateCommandRefusesAnotherAccountDomainForAnIssuedLicense, TestCreateCommandWritesAnIssuedLicenseGivenItsOwnAccountDomain), with the same "TEOS_DEPLOYMENT is local but AWS_ENDPOINT_URL is not set" error and the same number of hits in both logs.
- [Low] [hard-to-test] logs/sso-base.log vs logs/test-integration-cbdeploy.log — the same test fails the same way on base and HEAD: "the test browser could not sign in", Client.Timeout on the *.localhost.floci.io authorize URL. The inner text differs: base says "context deadline exceeded", HEAD says "dial tcp 198.18.0.1 i/o timeout". The DNS for that hostname answers with a 198.18.x address, so this is the box's network/DNS and not this diff. The test depends on live wildcard DNS, which is a flakiness risk, but that is pre-existing and outside this PR. Fix (follow-up, not for this PR): resolve the floci.io host to the emulator container in the test, or skip with a reason when it does not resolve.
- [Low] [non-testable] logs/summary.txt — AC4 is a stitched result (first run, scoped rerun, sur and cbdeploy re-tests), not one clean `make test-integration` run. The rerun loop also reported rc=0 even though it had 11 build failures. I accept it because every failure has its cause shown in the logs and the change only deletes code in 2 test files. Fix (optional): one clean full run before merge, which CI will cover anyway.
- [Info] corerouter service test: rc=0, ok, 2 SKIP (TestMirrorIngestFlow, TestMirrorIdtFlow) behind the existing Floci update/accepted MQTT gap marker. That marker is not in this diff.
- [Info] The image is now named: task.md lines 7, 23, 28, 39 and 43 use a31d6e08, with a re-pin note (line 45), and STATUS.md records the re-pin at 11:47. My earlier Low finding is resolved.
- [Info] Outside test scope: evidence notes that lint-arch does not cover go-core/cbtarget (tracked in W-2026-0003; hexagonal review APPROVED_DEGRADED). That gate belongs to the coordinator.

== Rationale ==
AC1 to AC4 now all map to passing named tests and complete Floci evidence at HEAD 2cfc189e on image a31d6e08. Every remaining failure is pre-existing (it reproduces on 863b6019 with the same tests and the same error) or comes from the environment, with its cause shown in the logs. The brief and STATUS.md now name a31d6e08. The test diff adds no flakiness risk; the real-clock and live-DNS risks are pre-existing and noted as follow-ups. The verdict moves from CHANGES_REQUESTED to APPROVED.
