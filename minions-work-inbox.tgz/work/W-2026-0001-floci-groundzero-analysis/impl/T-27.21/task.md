> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.21 — test(cbtarget): compare shadow metadata timestamps on Floci

Work item: W-2026-0001 · Packet: P-2026-0001-07 (split) · Wave: W1 · Implementer: golang-pro (Cursor cloud agent) · Reviews: code-reviewer + test-designer
Repo: Thiink-LLC/teos · Base: `863b6019` (origin/main; re-based per dev-lead msg-106) · Branch: `chore/W-2026-0001-t27-21-shadow-metadata-timestamps`
Floci image: `mariotoffia/floci:latest` @ sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1

## Goal
Remove the `device shadow metadata` marker and the skip under it at both sites, so the two tests compare per-sensor timestamps from GetThingShadow `metadata` on Floci. Floci 9.6 (in floci-io/floci#5260) is in the pinned image. Nothing else changes.

## Pre-check note
If metadata timestamps differ in shape from AWS (e.g. seconds vs ms), report it as a Floci follow-up via ESCALATION, do not adapt the test to Floci.

## Files (Owns globs — edit nothing outside these without an ESCALATION)
- `go-core/cbtarget/awsdstarget/target_integration_test.go`
- `go-core/cbtarget/awsdstarget_integration_test.go`

## Acceptance criteria (as regression-test behaviour)
1. TestProcessedPayloadFormatTypeSensorsFiltered (awsdstarget/target_integration_test.go:214) runs (not skipped) and passes on the pinned image.
2. TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered (awsdstarget_integration_test.go:46) runs and passes on the pinned image.
3. Both markers and their skips are deleted; nothing else in the files changes.
4. Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `make test-integration`; evidence in impl/T-27.21/evidence.md. If either fails on Floci, do NOT re-add a skip: systematic-debugging, then `ESCALATION: verify-failed` with the diff of expected vs actual metadata.

## TEOS_CONVENTIONS checklist: §C (go-core library tests, go-core/cbtarget)
- §0: `make dep` + `make generate` first in a fresh checkout; per-module builds (no `./...` at root); `<package>_test` packages; reuse go-core/utils/testutils + awstestutil; ifcore.CbContext + go-core/logger/log in non-test code; no plan/task IDs or commit hashes in code comments; plain English in PR and commits; respect .cbrepo-locks.json; no `.go-arch-lint.yml` change.
- §I: integration tests use `integration` (+ `floci` for Floci-specific) build tags; service tests in `<svc>/deployment/service-test/`.
- Marker rule: a marker goes only when the un-skipped test passes locally on the pinned Floci image (sha256:a31d6e08). A local skip is not evidence.

## Required gates (all green, commands + pass/fail in the done reply)
- `make fmt`
- `make lint  (full chain incl. lint-arch)`
- `make vet`
- `make test`
- `make tidy, then `git diff --exit-code` must be clean`
- `make test-integration`

## Evidence a done reply needs
- Floci image digest used (`docker image inspect` / pull by digest) = sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1.
- Tests run vs skipped, per package (go test -v -count=1 output summary; skips listed with reason).
- Marker grep after the change: `rg -n "floci: Missing Implementation for" go-core/cbtarget/awsdstarget/target_integration_test.go go-core/cbtarget/awsdstarget_integration_test.go` (expected: no hit for this task's marker).
- PR URL, head commit, internal reviews (code-reviewer, test-designer) passed, Copilot review requested on the latest commit, CI labels set and workflows green.
- Floci-local gate: the un-skipped/real-path test passes locally against Floci image mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 via `make test-integration`; evidence in impl/T-27.21/evidence.md.

> Re-pin note (2026-10-22): dev-lead pinned Floci to sha256:a31d6e08 (Task 48 shadow deep-merge fix) and the base to origin/main 863b6019, recorded in STATUS.md 11:47. AC4 now references that image.
