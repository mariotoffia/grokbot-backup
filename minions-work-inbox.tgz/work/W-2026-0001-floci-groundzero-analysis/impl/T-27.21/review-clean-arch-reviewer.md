# Clean Architecture review (interim arch gate): T-27.21, PR #1226
Reviewer: clean-arch-reviewer minion · Request: msg-W-2026-0001-dev-lead-123 · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-21-shadow-metadata-timestamps · Branch: chore/W-2026-0001-t27-21-shadow-metadata-timestamps · HEAD = 2cfc189e (matches; single task commit) · Tree clean. Floci only: I ran no AWS and made no GitHub post or comment.

Diff base: task.md names a3543337, but evidence.md and git show the branch was rebased onto origin/main 863b6019. a3543337..HEAD therefore also contains bc189350 and 863b6019, which are already on main and are docs and a Python cost script only (go-core/cbanalytics/*.md, compact_storage_cost.py, evidencewriter/COST.md), not Go code and not part of this task. I reviewed the task diff 863b6019..HEAD: 2 files, 13 deletions.

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] impl/T-27.21/task.md:5 — the brief still names base a3543337, but the branch sits on 863b6019, so `git diff a3543337..HEAD` shows unrelated docs from main. Fix: dev-lead updates the brief, or the PR body states the base, so other reviewers diff 863b6019..HEAD.
- [Low] [non-testable] go-core/cbtarget — no `.go-arch-lint.yml` covers go-core/cbtarget (go-core/cbanalytics is the only go-core map), and `make lint-arch` is unavailable (W-2026-0003). I checked the arch gate by hand against the direct-import map below. This gap predates the change. Fix: none in this change.
- Out of scope (not architecture, noted for dev-lead and code-reviewer): evidence.md says the green run used image sha256:a31d6e08…, while task.md and the packet pin sha256:9710d466… (red on that image). Also, evidence.md reports "lint 0 (incl. lint-arch)" while W-2026-0003 says lint-arch is unavailable. Both are evidence and pin questions for code-reviewer and release-config-mgr, not for this gate.
- Out of scope: port and adapter shape (hexagonal-reviewer minion) and aggregates (ddd-reviewer minion). The diff has neither.

Test-only claim: confirmed. The diff touches only go-core/cbtarget/awsdstarget/target_integration_test.go (removes the marker and local skip at :214, plus the now-unused cbenv and testenv imports) and go-core/cbtarget/awsdstarget_integration_test.go (removes the marker and skip at :46, plus the testenv import). Both files are `//go:build integration`. No production code changed, and both files are inside the owns globs.

Arch map (`go list -tags integration -f '{{.TestImports}} {{.XTestImports}}'` for ./cbtarget and ./cbtarget/awsdstarget, plus the diff): the only edge changes are removals (cbenv and testenv in those files; other test files in the package still use them). The change adds no edge. The remaining edges (cbtarget, awsdstarget, sqstarget, mgriot/awsmgriot, model/*, ifcore, iftarget, ctx, cberror, utils) were already there. `go vet -tags integration` on both packages is clean. The change makes no `.go-arch-lint.yml`, ADR or go.mod change.

== Rationale ==
Deleting a target-specific skip and its imports from two integration tests cannot invert a dependency or contaminate a domain, and it removes a test-environment branch from the tests. No logic moves between layers and the change adds no import. The only issues are bookkeeping: a stale diff base in the brief and an image-pin and evidence mismatch, which belong to other minions. On architecture, this passes.

## Addendum (2026-10-22 13:06 Europe/Stockholm): real `make lint-arch`
- Root cause of "unavailable": go-arch-lint v1.17.0 is installed at ~/go/bin/go-arch-lint, but ~/go/bin is not on PATH in agent shells (login shells too), so `make lint-arch` fails with "make: go-arch-lint: No such file or directory" (Error 127). W-2026-0003 itself is a separate thing: no map covers go-core/* outside cbanalytics or devicesvc, and that is still true.
- Ran (PATH=$HOME/go/bin:$PATH): make install (rc=2: apt mirror deb.debian.org 500), make dep (rc=2: corepack cannot write /usr/local/share/corepack), make generate (rc=2: docker.sock permission denied, plus corepack; it deleted 45 tracked generated files under go-services/model/*api, which I restored with git checkout, tree clean). None of these failures affect lint-arch.
- `make lint-arch` at worktree HEAD 2cfc189e: rc=0, "Architecture maps checked: 9" (9 Makefiles, 10 maps, every one "OK - No warnings found").
- Coverage: none of the 10 maps covers the package this change touches (go-core/cbtarget), so the pass confirms the repo-wide maps are not broken but does not check this diff. The hand-built import map stays the arch evidence. Verdict unchanged: APPROVED.
