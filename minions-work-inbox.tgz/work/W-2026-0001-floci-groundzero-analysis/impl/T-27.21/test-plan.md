> Scope: Floci-only (Mario 2026-10-21); no real-AWS runs.

# T-27.21 test plan (test-designer minion, packet P-2026-0001-18)
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-21-shadow-metadata-timestamps (base a3543337, uncommitted). Image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7.

== Test Plan ==
| AC | Case | Type / tags | Package, file | Assertion | Why red before the change |
|---|---|---|---|---|---|
| 1 | TestProcessedPayloadFormatTypeSensorsFiltered | integration,floci | awsdstarget, awsdstarget/target_integration_test.go | IDT_O1=26.3 (newer, accepted); ODT=-14.1 (older, filtered, kept) | skipped on local target |
| 2 | TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered | integration,floci | cbtarget, awsdstarget_integration_test.go | same | skipped on local target |
| 3 | marker grep | - | both files | no "floci: Missing Implementation for" hit; only marker+skip and the now-unused cbenv/testenv imports removed | markers present |
| 4 | Floci-local gate | integration | same | `make test-integration` against mariotoffia/floci:latest@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 | un-skipped test passes locally; evidence in impl/T-27.21/evidence.md | - |

Red edit made (uncommitted): both marker+skip blocks deleted; unused imports removed (cbenv+testenv in target_integration_test.go, testenv in awsdstarget_integration_test.go). This edit IS the whole task change.

== Red run (2026-10-21, Europe/Stockholm) ==
`sg docker -c 'TK_LOCAL_EMULATOR=mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 _dist/_output/bin/cbtest local exec --resources-only --provision-config deployment/provision-config.yaml -- bash -c "cd go-core && go test -tags=integration,floci -count=1 -v -run ^(TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered|TestProcessedPayloadFormatTypeSensorsFiltered)$ ./cbtarget/ ./cbtarget/awsdstarget/"'`
```
awsdstarget_integration_test.go:158: Not equal: expected: float64(-14.1) actual: <nil>(<nil>)
--- FAIL: TestAWSDsTargetProcessedPayloadFormatTypeSensorsFiltered
target_integration_test.go:316: Not equal: expected: float64(-14.1) actual: <nil>(<nil>)
--- FAIL: TestProcessedPayloadFormatTypeSensorsFiltered
```
Diagnosis (one debug run with temporary t.Logf, reverted):
```
before: {"state":{"reported":{"sensors":{"IDT_O1":22.3,"ODT":-14.1}}},"metadata":{"reported":{"sensors":{"IDT_O1":{"timestamp":1792591167},"ODT":{"timestamp":1792591167}}}},"version":1,...}
after:  {"state":{"reported":{"sensors":{"IDT_O1":26.3},"tz":"Europe/Stockholm"}},"metadata":{"reported":{"sensors":{"IDT_O1":{"timestamp":1792591167}},"tz":{...}}},"version":2,...}
```
- Metadata timestamps now exist and match AWS (epoch seconds per leaf). That part of the Floci fix works.
- The new failure is not a metadata problem. Floci's UpdateThingShadow replaces the nested "sensors" object instead of merging it. AWS merges nested reported objects key by key, so the ODT that the time filter dropped would stay at -14.1.
- AC4 says not to adapt the test and not to re-add a skip. This is a Floci follow-up: shadow update must deep-merge nested objects. ESCALATION: verify-failed to dev-lead. golang-pro cannot make this green from the owned files.
Lint: golangci-lint with LINT_TAGS, and with LINT_TAGS+floci, on ./go-core/cbtarget/... gives 0 issues. go vet for integration and for integration,floci is clean. Marker grep: no hit.
