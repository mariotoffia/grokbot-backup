# Hex review: PR #1250 (HEAD 812bec95, Closes #1249)

Reviewer: hexagonal-reviewer (read-only), 2026-10-23 07:39 Europe/Stockholm

## Verdict: APPROVED

## Scope
Diff vs merge-base with origin/main: only go-services/buildingsvc/.go-arch-lint.yml (+68) and go-services/buildingsvc/Makefile (+7/-1). No other files.

## Map vs proposal
Semantically identical: components (11), deps, workdir, allow (deepScan false, depOnAnyVendor true), exclude, excludeFiles. The only differences are in comments: the header was reworded (the PROPOSED note was removed, and it now explains the direct-imports rule and that unused rules are not reported), and the adapters comment says 'ports and shared types' / 'No adapter to adapter edge'. None of this weakens a check.

Makefile: lint-arch added to .PHONY; recipe `go-arch-lint check --project-path .. --arch-file buildingsvc/.go-arch-lint.yml`. This matches the proposal and the eventsvc precedent.

## Target run (cd go-services/buildingsvc && make lint-arch)
```
go-arch-lint check --project-path .. --arch-file buildingsvc/.go-arch-lint.yml
module: github.com/Thiink-LLC/teos/go-services
linters:
   On | Base: component imports # always on
  Off | Advanced: vendor imports # switch 'allow.depOnAnyVendor = false' (or delete) to on
  Off | Advanced: method calls and dependency injections # switch 'allow.deepScan = true' (or delete) to on

OK - No warnings found
rc=0
```

## Root make lint-arch (the scanner; does not use run.sh)
```
=== go-arch-lint in ./go-core/cbanalytics ===
=== go-arch-lint in ./go-services/appstore ===
=== go-arch-lint in ./go-services/buildingsvc ===
=== go-arch-lint in ./go-services/core/brokers/gobridge ===
=== go-arch-lint in ./go-services/core/management/alarm-service ===
=== go-arch-lint in ./go-services/core/management/iam ===
=== go-arch-lint in ./go-services/eventsvc ===
=== go-arch-lint in ./go-services/providers/eastbound/mqtt ===
=== go-arch-lint in ./go-services/providers/eastbound/sur ===
=== go-arch-lint in ./go-services/realestatecore ===
Architecture maps checked: 10
rc=0
```

## Negative tests (copies of the map, removed after use; no code changed)
1. adapters: [ports,types] changed to [types]:
```
Component adapters shouldn't depend on github.com/Thiink-LLC/teos/go-services/buildingsvc/buildsvccore/ports in /tmp/pr1250/go-services/buildingsvc/adapters/ssmconfig/provider.go:20


--
total notices: 2


rc=1
```
2. core: events removed:
```
Component core shouldn't depend on github.com/Thiink-LLC/teos/go-services/buildingsvc/buildingsvcevents in /tmp/pr1250/go-services/buildingsvc/buildsvccore/bulkupsert.go:8
Component core shouldn't depend on github.com/Thiink-LLC/teos/go-services/buildingsvc/buildingsvcevents in /tmp/pr1250/go-services/buildingsvc/buildsvccore/delete.go:19
total notices: 2
rc=1
```

## Gate logs (gates/)
go-arch-lint.log reports OK, rc=0, with the same linter flags (vendor off, deepScan off). This matches HEAD. NOTE.txt says make was missing when the gates ran; make is installed now, and the make target was confirmed above.

## Tech debt (Medium, does not block)
buildsvccore imports AWS SDK and dynamodbcmdb directly, so depOnAnyVendor=true for now.
