# Code review: PR #1250 (draft) @ 812bec95, Closes #1249
Reviewer: code-reviewer (read-only), 2026-10-23 07:41 Europe/Stockholm. Disk: / 23% used (100G free).
GitHub head = 812bec95a818218fc7ac3d64d918b23eb3bd52a8 and matches the brief. Branch chore/W-2026-0001-buildingsvc-arch-lint. Reviewed sha: 812bec95.
Fresh merge-base = 41409305 (= origin/main tip).

## Verdict: CHANGES_REQUESTED
Blocking: H1 (gate evidence is not stamped and has no command lines) and M1 (LINT.md map inventory not updated).
The map itself is accurate and tight; I would approve it as-is.

## Scope
OK. The diff touches only go-services/buildingsvc/.go-arch-lint.yml (+68) and go-services/buildingsvc/Makefile (+7/-1). No production code and no docs changed; see M1 for the missing doc.

## 1. Map, template and wiring
- There is no CONVENTIONS.md §1. The governing text is LINT.md §go-arch-lint ("Adding a map").
- Layout follows the package-inside-a-larger-module case, the same as cbanalytics and eventsvc/evidencecollector:
  - workdir: buildingsvc
  - --project-path .. --arch-file buildingsvc/.go-arch-lint.yml
- version 3, deepScan false, excludeFiles _test, and a header comment are the same as the peers.
- The nested go.mod in deployment (and deployment/service-test) is excluded, as LINT.md requires.
- Components against the real direct imports (go list .Imports at 812bec95):
  - Every allowed edge is used: events→types; ports→types; core→events,types,errorcodes; cfin→cfin,core; configchange→configchange,core,types; adapters→ports,types; handlers→all 8 listed.
  - Exception: client→client is unused (see L1).
  - No missing edges: go-arch-lint reports OK, so every package belongs to a component.
- No anyProjectDeps and no wildcard deps.
- depOnAnyVendor: true leaves go-core and AWS edges unconstrained (buildsvccore imports go-core/cmdbsvc/dynamodbcmdb and the AWS SDK). This is documented in the map, matches appstore/iam/realestatecore, and is approved in the issue. Info.
- Layering reflects the code as it is: core mixes domain and app, and ports are consumed only by adapters and handlers. Adapters point inward and there are no adapter→adapter edges. The gate has teeth: core→adapters, core→handlers, adapters→core and ports→core are all denied.
- Wiring: the root lint-arch finds Makefiles matching '^lint-arch:'. At 812bec95 it finds 10 such Makefiles, which is 9 before plus buildingsvc. The target text and .PHONY match the peers.

## 2. Gates
gates/ was written 07:36:54–07:37:16 Europe/Stockholm. Every log ends rc=0. go-arch-lint.log shows "OK - No warnings found" with the vendor and deepScan linters off, matching HEAD.
- The direct go-arch-lint command is identical to the recipe. `make -n lint-arch` in go-services/buildingsvc prints exactly: go-arch-lint check --project-path .. --arch-file buildingsvc/.go-arch-lint.yml. So with make -C, cwd is the same and the commands are equivalent.
- make is now installed on the box (/usr/bin/make). I ran `make lint-arch` read-only in a detached worktree at 812bec95: rc=0, OK.
- I re-ran the other gates at 812bec95:
  - gofmt -l buildingsvc: empty
  - go vet ./buildingsvc/...: rc 0
  - golangci-lint run ./go-services/buildingsvc/... (from the repo root, as lint-go does): 0 issues
- The original "make target unexercised" concern is therefore resolved by my run and by hex's run (review-hex.md). Info only.

## 3. Issue-first (/workspace/minions/CONVENTIONS.md §GitHub issues and PRs)
- #1249 is OPEN, assigned to mariotoffia, with labels go and lint, Priority Medium and Size Hours. It is on the R&D Sprint Board with Status Progress.
- Its body is effectively the acceptance criteria: two deliverables and "check must pass on current code".
- PR: title starts with W-2026-0001, assignee is mariotoffia, closingIssuesReferences=[1249], draft.
- Copilot review threads: 0 (expected while the PR is draft).
- Gaps are listed under L2 and L3.

## Findings
- H1 [High] [testable] impl/buildingsvc-arch-lint/gates/*.log — gate evidence is not stamped with a sha and records no command or cwd. Each log is only output plus rc (gofmt/govet/tidy logs are just "rc=0", with a duplicated rc line), so nothing ties them to 812bec95 or to the exact invocation. This violates the evidence rule, and an unverifiable gate counts as a missing gate. My own re-runs at 812bec95 all pass, so this is evidence hygiene, not a code defect. Fix: re-run each gate (make is available now: `make -C go-services/buildingsvc lint-arch`, plus gofmt, vet, golangci-lint and tidy) with a "# sha 812bec95" header, the command and the cwd in each log.
- M1 [Medium] [non-testable] LINT.md:§go-arch-lint "Maps in place today (10)" — buildingsvc is not added, and the count should become 11. The "package inside a larger module" row of the recipe table should list buildingsvc too. The PR summary implies docs, but none changed. Fix: update the list, the count and the table row.
- L1 [Low] [testable] go-services/buildingsvc/.go-arch-lint.yml:client — `client: { mayDependOn: [client, events] }`, but no export/client package imports another export/client package. The self edge is an unused allow, the decay that LINT.md "Two things the tool cannot see" #1 warns about. Fix: drop `client` from the list.
- L2 [Low] [non-testable] issue #1249 title — the convention is "<W-id> T-<x>: <title>", and this title has no T-id. Fix: add the task id (e.g. T-27.x).
- L3 [Low] [non-testable] PR #1250 body / #1249 board — the PR body does not link the task or STATUS.md (CONVENTIONS step 1). The Sprint lookup (`gh project item-list … .sprint`) returned empty for #1249. Fix: link the task and STATUS.md in the body, and set the Sprint iteration.
- I1 [Info] — LINT.md step 2 says "make the local lint (or check) depend on it". buildingsvc's Makefile has neither target, so nothing to wire; consider adding `lint: lint-arch`.
- I2 [Info] — tests/ is excluded rather than mapped as a component (realestatecore maps tests/**). Acceptable for a first landing.
No secrets seen. Nothing posted to GitHub.
