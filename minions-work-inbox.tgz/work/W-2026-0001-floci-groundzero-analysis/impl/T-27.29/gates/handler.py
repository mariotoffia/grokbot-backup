import base64, hashlib, json
def handler(event, context):
    body = event.get("body") or ""
    b64 = bool(event.get("isBase64Encoded"))
    raw = base64.b64decode(body) if b64 else body.encode("utf-8", "surrogateescape")
    return {"statusCode": 200, "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"isBase64Encoded": b64, "len": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                                "gzipMagic": raw[:2].hex(), "contentType": (event.get("headers") or {}).get("Content-Type") or (event.get("headers") or {}).get("content-type")})}
