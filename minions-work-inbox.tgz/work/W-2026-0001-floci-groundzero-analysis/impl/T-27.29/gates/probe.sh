#!/bin/bash
set -u
export AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test AWS_DEFAULT_REGION=eu-west-1 AWS_CONFIG_FILE=/dev/null AWS_SHARED_CREDENTIALS_FILE=/dev/null; unset AWS_PROFILE
a(){ aws --endpoint-url http://127.0.0.1:47566 "$@"; }
echo "# floci image: mariotoffia/floci:latest@sha256:a31d6e08f9a8848a80909838911f653487a361a49b37a395abf6fa65e37dd5c1 (standalone container gzprobe-floci, port 47566)"
a lambda create-function --function-name gzecho --runtime python3.12 --handler handler.handler --role arn:aws:iam::000000000000:role/x --zip-file fileb://fn.zip --query FunctionArn --output text
ARN=arn:aws:lambda:eu-west-1:000000000000:function:gzecho
cat > api.json <<EOF
{"openapi":"3.0.1","info":{"title":"gzprobe","version":"1"},
 "x-amazon-apigateway-binary-media-types":["application/octet-stream","application/gzip"],
 "paths":{"/logs":{"post":{"x-amazon-apigateway-integration":{"type":"aws_proxy","httpMethod":"POST","uri":"arn:aws:apigateway:eu-west-1:lambda:path/2015-03-31/functions/$ARN/invocations"},"responses":{"200":{"description":"ok"}}}}}}
EOF
API=$(a apigateway import-rest-api --body fileb://api.json --query id --output text); echo "API=$API"
echo "binaryMediaTypes after import:"; a apigateway get-rest-api --rest-api-id $API --query binaryMediaTypes
a apigateway create-deployment --rest-api-id $API --stage-name test --query id --output text
printf '{"level":"info","message":"svctest log import","traceId":"probe"}\n' | gzip -c > body.gz
echo "local body: len=$(stat -c%s body.gz) sha256=$(sha256sum body.gz | cut -d' ' -f1) magic=$(head -c2 body.gz | xxd -p)"
for ct in application/octet-stream application/gzip; do
 for url in "http://127.0.0.1:47566/restapis/$API/test/_user_request_/logs" "http://$API.execute-api.localhost.floci.io:47566/test/logs"; do
  echo "POST $ct $url"; curl -s -m 120 -X POST -H "Content-Type: $ct" --data-binary @body.gz "$url"; echo
 done
done
