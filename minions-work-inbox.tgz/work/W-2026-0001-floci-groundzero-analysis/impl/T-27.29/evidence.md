# T-27.29 evidence
- Issue: https://github.com/Thiink-LLC/teos/issues/1237. PR: https://github.com/Thiink-LLC/teos/pull/1238. HEAD 4a413e84 (base main 18852fbf)
- Change: removed the Floci skip. The soft WARNING became require.NoError + require.True(found).
- Gates: fmt/vet/lint/lint-arch/test/tidy rc=0. test was rerun after ENOSPC.
- gzip probe (gates/gzip-probe-output.txt): the body reaches the Lambda byte-identical (sha256 match, isBase64Encoded=true). The 44.3 / floci#5131 fix is effective.
- SUR service test (gates/test-service-sur-4a413e84.log): EXIT_RC=1 at 18:43 CEST. 5 PASS, TestSurApiLogImportAndVerify FAIL. ExportLogs returns 200 (traceId 06978d3d-...), but the test-side CloudWatch poll logs "LogStreamIterator error: Failed to enumerate log streams" for 60s and the assertion times out. The previous soft WARNING would have hidden this.
- Root cause not yet isolated. Candidates: (a) logimport Lambda's CreateLogGroup/PutLogEvents to /teos/rsid/log/svctest fails or goes elsewhere on Floci; (b) Floci DescribeLogStreams on that group errors. The next step is a diagnostic run under floci-harness-run that keeps the stack and queries logs describe-log-groups/streams plus the Lambda logs.
- Status: BLOCKED (hard assertion red on Floci; PR stays ready but must not merge until green)

## Diagnosis (msg-204, 19:09 CEST, under floci-harness-run, then released)
The failing call is DescribeLogStreams(group=/teos/rsid/log/svctest, orderBy=LastEventTime, descending, limit=10). Those params are AWS-valid and Floci serves them (gates/describe-log-streams-probe.txt). The error is ResourceNotFound because the group was never created. Floci's PutLogEvents on a missing group answers "The specified log stream does not exist: <stream>". AWS answers "The specified log group does not exist." clwlog put.go matches the exact AWS text, falls to its default branch, and never auto-creates the group.
Verdict: Floci gap, already recorded (Floci 9.2/9.3 + 49.1) -> floci-gaps/plans/FG-8.md. No new 50.3. Stays BLOCKED on those.

## Parked (dev-lead msg-225, 2026-10-22 21:46 CEST)
PR #1238 is parked at HEAD 4a413e84 and stays unmerged until Floci fixes 9.2/9.3 + 49.1 (FG-8 is a duplicate, so there is no new 50.x). No further pushes. No skip is re-added.
