# T-27.29 task (golang-pro, stream 2)

Issue: https://github.com/Thiink-LLC/teos/issues/1237
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-29-sur-gzip-log-import (branch chore/W-2026-0001-t27-29-sur-gzip-log-import)
start_gate: Mario go relayed by dev-lead 16:44. Dependency R1 clean. Gate: gzip body must reach the Lambda intact first (proved, gates/gzip-probe-output.txt).

## Scope
Un-skip `TestSurApiLogImportAndVerify` in `go-services/providers/eastbound/sur/deployment/service-test/e2e_logs_geo_test.go` (marker `floci: Missing Implementation for x-amazon-apigateway-binary-media-types in an imported OpenAPI document`). The test's soft "WARNING if not found" end becomes a hard assertion.

Pre-check done: on Floci `a31d6e08` an imported OpenAPI document keeps `x-amazon-apigateway-binary-media-types`, and a gzip body posted as application/octet-stream reaches the Lambda proxy base64-encoded and byte-identical (same sha256).

## Acceptance criteria
1. Skip and marker removed; the CloudWatch lookup must find the imported entry (no soft warning).
2. TestSurApiLogImportAndVerify passes in the SUR service test on Floci `a31d6e08`. No new skips.
