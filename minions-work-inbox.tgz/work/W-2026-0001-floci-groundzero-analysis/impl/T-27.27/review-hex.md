# Hexagonal review — T-27.27 (PR #1236 @ 1dff7476)
Reviewer: hexagonal-reviewer minion (read-only, interim arch gate per W-2026-0003). 2026-10-22 19:07 CEST.
Scope (diff vs merge-base origin/main): 4 test files, build tag e2e, in buildingsvc and sur deployment/service-test. No production code.

== Verdict ==
CHANGES_REQUESTED (evidence-only; no code changes needed. Becomes APPROVED_DEGRADED once test-integration evidence is recorded — capped by the missing buildingsvc lint-arch map.)

== Findings ==
- [High] [testable] impl/T-27.27/gates/ — no `make test-integration` run/rc recorded at 1dff7476 (summary-1dff7476.txt lists fmt/vet/lint/lint-arch/test/tidy only). Unevidenced required gate. Fix: run make test-integration at 1dff7476 (Floci only) and log commit/command/rc.
- [Medium] [non-testable] go-services/buildingsvc/ — no DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md (pre-existing). Fix: docs follow-up via technical-writer.
- [Medium] [non-testable] go-services/providers/eastbound/sur/ — no DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md (pre-existing). Fix: same.
- [Medium] [non-testable] lint-arch-1dff7476.log — no go-arch-lint map covers go-services/buildingsvc (W-2026-0003); caps verdict at APPROVED_DEGRADED. sur has .go-arch-lint.yml and passed.
- [Low] [testable] buildingsvc/deployment/service-test/helpers_api_test.go:51, sur/deployment/service-test/helpers_auth_test.go:49 — helper takes concrete *mgriamcognito.CognitoAppClientManager rather than a go-core port interface. Acceptable in an e2e harness (composition-like edge), not a port-in-adapter. Optional: accept a narrow interface { DiscoverAccountDomain(ctx) (string, error) }.
- [Low] [testable] buildingsvc/.../account_domain_test.go:1-40 and sur/.../account_domain_test.go:1-40 — byte-identical duplicates (blob 9aee6fbf). Optional: shared test helper.
- [Low] sur Floci run: TestSurApiLogImportAndVerify SKIP — out of scope (T-27.29 target), noted only.

== Gates (evidence at 1dff7476) ==
fmt 0, vet 0, lint 0, lint-arch 0 (sur map; buildingsvc unmapped), make test 0 (attempt1 rc=2 webui/dist missing; rerun after pnpm install+generate rc=0), tidy 0, test-integration NOT EVIDENCED.
test-service on Floci: buildingsvc rc=0 (6 PASS incl. TestAccountDomainFromCognito); sur rc=0 (6 PASS, 1 SKIP out of scope).
Own check: go vet -tags integration,floci,e2e on buildingsvc and sur service-test rc=0.

== Rationale ==
Test-only change; no ports, adapters or domain code touched. Tests read through the go-core Cognito manager (shared infra package) instead of the provision config, which is correct direction. No port defined in an adapter, no domain leak. Escalation: none.

# Re-verdict — PR #1236 @ 2ca718c9 (2026-10-22 21:48 CEST)
Reviewer: hexagonal-reviewer minion (read-only). Origin branch head = 2ca718c99a56 (git ls-remote).

== Verdict ==
APPROVED_DEGRADED (capped by the missing buildingsvc lint-arch map; unrelated pre-existing test-integration failures must be tracked)

== Delta 1dff7476..2ca718c9 ==
4 files, +10/-30, all *_test.go under buildingsvc and sur deployment/service-test. No non-test files changed. Context error now checked (require.NoError). The deployedAccountDomain wrapper is removed and the tests call mgr.DiscoverAccountDomain directly, so the earlier Low about a concrete-type helper is resolved. No ports, adapters or domain code touched; no hexagonal issues.
Own check: go vet -tags integration,floci,e2e on both service-test pkgs rc=0.

== test-integration-2ca718c9.log ==
Header: HEAD 2ca718c99a56578db52dee083aaf5416eae91a72, clean worktree, pinned Floci a31d6e08, env -i, no AWS config. 19:37:25 to 21:06:28 CEST, EXIT_RC=2.
FAILs (whole log and the final "FAILED tests/packages (2)" summary agree):
- cmd/cblicense: TestCreateCommandRefusesAnotherAccountDomainForAnIssuedLicense (2 subtests), TestCreateCommandWritesAnIssuedLicenseGivenItsOwnAccountDomain. Cause: TEOS_DEPLOYMENT=local but AWS_ENDPOINT_URL is not set.
- go-services/appstore/cmd/cbdeploy/internal/auth: TestSSOLoginAgainstTheLocalEmulator. Cause: browser open of http://api.auth.sso*.localhost.floci.io (*.localhost DNS).
Other "FAIL" strings are expected output of passing tests (Kroki svg checks). Both failing packages are outside the PR's 4 files. buildingsvc/sur packages are all ok.
Pre-existing: the same cblicense FAILs appear in T-39.11's test-integration attempt @028f6a4b, a different PR. STATUS.md 2026-10-21 18:25 (T-27.12) lists cblicense and cbdeploy SSO as existing test-integration failures. No main-branch run log was available.

== Findings ==
- [Medium] [testable] cmd/cblicense and cbdeploy/internal/auth fail make test-integration on Floci. Pre-existing and unrelated to this PR. Must be tracked as a follow-up issue.
- [Medium] buildingsvc and sur lack DDD/UBIQUITOUS/ARCHITECTURE/LINT docs (pre-existing).
- [Medium] No go-arch-lint map covers buildingsvc (caps the verdict at APPROVED_DEGRADED).
- [Low] Duplicate account_domain_test.go in both services (optional).
- [Low] sur TestSurApiLogImportAndVerify SKIP is out of scope (T-27.29).
- Resolved: [High] missing test-integration evidence. Resolved: [Low] concrete-type helper.

# Final evidence-backed verdict — PR #1236 @ 2ca718c9 (2026-10-23 07:35 CEST)
Reviewer: hexagonal-reviewer minion (read-only). Evidence: impl/T-27.27/hex-evidence/.
== Verdict ==
APPROVED_DEGRADED (capped: no lint-arch map covers buildingsvc). No escalation.
== Evidence ==
- Import graph (direct imports): buildingsvc, sur and both service-test packages -> import-graph.txt.
- Dependency check: the PR adds no violations. Ports are in core (buildsvccore/ports, sur internal/core/ports). Adapters depend inward only. No adapter-to-adapter import. Handlers do the wiring. The service tests are black-box E2E and import only exported clients and go-core.
- Pre-existing [Medium]: buildingsvc core imports infra: service.go:4,9 (dynamodb types, dynamodbcmdb); configchange/target.go:7-9 (sns); configchange/event.go:8 and processor.go:8 (lambda events); dynamodb expression in query.go:6, delete.go:8, syncdb/expression.go:7, provision/loader.go:8, configchange/provider/loader.go:8. This is an infra leak into core, not port-in-adapter, so it is not an escalation trigger. Track it as tech debt.
- Pre-existing [Low]: sur application/subscribe_service.go:7 imports aws (helpers).
- lint-arch: the sur map passes when go-arch-lint check is run directly (OK, rc=0). buildingsvc has no map. The proposed map at go-services/buildingsvc/.go-arch-lint.yml (workdir: buildingsvc, plus a Makefile lint-arch target) dry-runs OK at the HEAD, and a negative control fires. See proposed-map-buildingsvc.yml.txt.
- Gates: unchanged from the re-verdict. test-integration rc=2 comes only from pre-existing, untouched cblicense and cbdeploy SSO failures [Medium, follow-up].
== To reach APPROVED ==
Land the buildingsvc map, in this PR or as a tracked follow-up the lead accepts.

## Update 2026-10-23 07:39 Europe/Stockholm: #1236 (HEAD 2ca718c9) APPROVED_DEGRADED -> APPROVED (conditional)
The missing buildingsvc arch-lint gate is supplied by draft PR #1250 (HEAD 812bec95). That PR's map matches the proposal, make lint-arch returns rc=0 / OK, the root scanner picks it up (10 maps), and the negative tests fail as expected. Evidence: impl/buildingsvc-arch-lint/review-hex.md.
Status: APPROVED, conditional on #1250 merging. Until then this is an evidence dependency. Pre-existing Medium tech debt stays noted and does not block: buildingsvc core imports AWS directly.
