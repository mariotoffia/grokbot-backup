# T-27.27 task (golang-pro, stream 2)

Issue: https://github.com/Thiink-LLC/teos/issues/1235
Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-27-cognito-custom-domain (branch chore/W-2026-0001-t27-27-cognito-custom-domain)
start_gate: Mario go relayed by dev-lead 16:44. Dependency R1 clean (r1-check.md).

## Scope
Remove the Cognito CustomDomain workarounds (marker `floci: Missing Implementation for CustomDomain in DescribeUserPool`) that read the account domain from provision-config.yaml instead of Cognito:
- `go-services/buildingsvc/deployment/service-test/helpers_api_test.go` (deployedAccountDomain)
- `go-services/providers/eastbound/sur/deployment/service-test/helpers_auth_test.go` (deployedAccountDomain)

Both now read the account domain from the deployed user pool's custom domain (DiscoverAccountDomain). A new `TestAccountDomainFromCognito` in each service test checks that `GetAccountDomain` (CB_ACCOUNT_DOMAIN cleared) and `DiscoverAccountDomain` return the provision config's account domain on the local target.

## Acceptance criteria
1. Both workarounds and markers are removed; no assertion is weakened.
2. TestAccountDomainFromCognito passes in buildingsvc and SUR service tests on Floci `a31d6e08`.
3. The existing buildingsvc and SUR service tests still pass (R1 was clean, see r1-check.md). No new skips.
