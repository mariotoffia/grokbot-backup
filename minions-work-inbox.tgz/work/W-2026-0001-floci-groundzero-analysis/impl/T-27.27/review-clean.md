# Clean Architecture review: T-27.27, PR #1236
Reviewer: clean-arch-reviewer minion · Worktree: /workspace/repos/teos/work/git-worktree/W-2026-0001-t27-27-cognito-custom-domain · HEAD 1dff7476 (matches the request and `git ls-remote refs/pull/1236/head`). Merge base: dc86df55. Floci only; no GitHub posts. Counts as the interim arch gate (W-2026-0003).

== Verdict ==
APPROVED with notes

== Findings ==
- [Medium] [non-testable] go-services/buildingsvc/ — DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md and adr/ are all missing, and no .go-arch-lint.yml covers buildingsvc. This gap existed before the PR. Fix: add the docs and a map under W-2026-0003. Not blocking here.
- [Medium] [non-testable] go-services/providers/eastbound/sur/ — DDD.md, UBIQUITOUS.md, ARCHITECTURE.md, LINT.md and adr/ are missing. A .go-arch-lint.yml exists, but it excludes `deployment`, so it does not cover the changed package. This gap existed before the PR. Fix: add the docs (W-2026-0003 / technical-writer).
- [Low] [known gap W-2026-0003] No arch map covers either changed package. `PATH=$HOME/go/bin:$PATH make lint-arch`: rc=0, 9 maps checked, "OK - No warnings found". The hand-built import map below is the evidence.
- [Info] `go vet -tags e2e` rc=0 in both changed packages. Both packages are e2e-only, so `-tags integration` builds no files. The tree is clean after the run, and make generate was not run.
- Out of scope: port and adapter shape (hexagonal-reviewer) and test quality (test-reviewer).

Test-only claim: confirmed. dc86df55..1dff7476 changes 4 files, all `//go:build e2e` files in `*/deployment/service-test/`, +94/-24: buildingsvc account_domain_test.go (new) and helpers_api_test.go, and sur account_domain_test.go (new) and helpers_auth_test.go. `deployedAccountDomain` now reads the account domain from `mgriamcognito.CognitoAppClientManager.DiscoverAccountDomain` instead of `script.LoadProductDefinition`. The new tests compare GetAccountDomain/DiscoverAccountDomain with the provision config. No production, domain, handler or adapter code changed. No .go-arch-lint.yml, ADR or go.mod change.

Arch map (go list -tags e2e -test, direct imports):
- buildingsvc/deployment/service-test imports deployment/lib/{svctest,script,core/iam,core/domain/wellknown}, go-core (cbenv, cberror, cbevent, ctx, ifcore, ifiam, mgrapigwv1, mgriamcognito, mgrgojwt, model/*, cbhttp, utils/*, awstestutil), buildingsvc/{buildingsvcevents,export/client/apiclient}, aws-sdk-go-v2 (dynamodb, lambda, sqs, ssm) and testify.
- sur/deployment/service-test imports deployment/lib/{svctest,script}, go-core (managers mgriamcognito, mgrgojwt, clwlog, dynamodbqueue, mgrapigwv1, model/*, utils/*, testutils), sur/api/client, aws-sdk-go-v2 (s3, sqs), uuid and testify.
- Import delta: mgriamcognito, cbenv, testing and testify are added. In helpers, the script import moves into the new test file. Neither package imports the internal domain or core of buildingsvc or sur. The cloud SDK and the Cognito manager are used only in the e2e test layer, the outermost ring, so the dependency direction is correct.

== Rationale ==
Every change sits in the e2e service-test layer, which is allowed to depend on infrastructure. No domain, application or handler package changed or gained an import, so there is no dependency inversion, domain leak or business logic in adapters. The two Medium findings are governance docs that were already missing before this PR. They do not block it, but the Lead Architect minion should track them under W-2026-0003.
