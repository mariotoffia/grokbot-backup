# Code review — PR #1236 (T-27.27) @ 1dff7476, Floci a31d6e08
Reviewer: the Code Reviewer minion (code-reviewer), read-only. df -h /: 42% used (75G free) at 19:06 (Europe/Stockholm).
Base: fresh merge-base with origin/main; 1 commit, 4 files (+94/-24). PR head = 1dff7476 (gh).

== Verdict ==
APPROVED

== Findings ==
- [Low] [non-testable] go-services/{buildingsvc,providers/eastbound/sur}/deployment/service-test/account_domain_test.go:1-40 — the two files are byte-identical (same blob 9aee6fbf). Acceptable for separate e2e modules; a shared testkit helper would avoid drift. Fix: optional follow-up.
- [Low] [non-testable] helpers_api_test.go:51-58 / helpers_auth_test.go:49-56 — deployedAccountDomain is now a pass-through wrapper over mgr.DiscoverAccountDomain. Fix: optional inline.
- [Low] [non-testable] PR #1236 body still says "Floci service runs are queued behind the T-39.11 gobridge run". The runs have since finished. Fix: update the body (author action; I did not post).
- [Low] [non-testable] Service tests ran without -race (gates/test-service-*-1dff7476.log). The task's AC does not require -race, so this is not blocking.
- [Info] Process deviation from evidence.md: box /etc/hosts gained an ECR localhost entry (backup /etc/hosts.bak-W-2026-0001-t39-11), and it was not reverted. Dev-lead decides.
- [Info] Arch: sur covered by its map (lint-arch-1dff7476.log OK). No map covers buildingsvc/deployment/service-test, so the W-2026-0003 interim sign-off is given here: test-only, no layering impact.

== Issue link ==
Body has "Closes #1235", and closingIssuesReferences=[1235]. Issue #1235 "W-2026-0001 T-27.27: read the account domain from Cognito…" is OPEN and correct.

== Gates (impl/T-27.27/gates/, all stamped HEAD 1dff7476) ==
fmt 0 · vet 0 (e2e and e2e,floci) · golangci-lint 0 (0 issues, both tag sets, scoped to the changed modules) · lint-arch 0 · make test 0 (env -u TEOS_DEPLOYMENT -u AWS_ENDPOINT_URL; attempt1 rc=2 was a missing webui dist, fixed by rerun) · tidy 0, clean diff ·
Floci service tests: buildingsvc all PASS, 0 SKIP (TestAccountDomainFromCognito PASS). SUR 6 PASS, 1 SKIP (TestSurApiLogImportAndVerify = T-27.29, pre-existing and out of scope). Env: TEOS_DEPLOYMENT=local is set only on the service-test command (clean env -i shell); there is no leakage into make test.

== Copilot ==
0 review threads (GraphQL reviewThreads=[]). There is 1 Copilot review, COMMENTED, on 1dff7476.

== Rationale ==
The workaround and its marker are removed in both helpers. The domain now really comes from Cognito, and the new test pins GetAccountDomain/DiscoverAccountDomain to the provision config with CB_ACCOUNT_DOMAIN cleared. No assertion is weakened, and there are no security or performance concerns. All gates pass at HEAD.
