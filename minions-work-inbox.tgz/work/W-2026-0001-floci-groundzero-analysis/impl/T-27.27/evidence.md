# T-27.27 evidence
- Issue: https://github.com/Thiink-LLC/teos/issues/1235 (Priority=Medium, Size=Hours, Board Status=Incoming, assignee mariotoffia)
- PR: https://github.com/Thiink-LLC/teos/pull/1236 (ready, Closes #1235, Copilot reviewer requested). HEAD 1dff7476
- Change: deployedAccountDomain(ctx, mgr) reads the domain through mgr.DiscoverAccountDomain (Cognito) in buildingsvc helpers_api_test.go and sur helpers_auth_test.go. New TestAccountDomainFromCognito in each, with CB_ACCOUNT_DOMAIN cleared.
- Gates (gates/): fmt=0 vet=0 lint=0 lint-arch=0 (sur map; buildingsvc: "lint-arch ran and passed; no map covers buildingsvc (W-2026-0003)") test=0 (rerun after pnpm install + make generate in this worktree) tidy=0 with a clean diff
- Service tests on Floci (pinned sha256:a31d6e08...): buildingsvc rc=0, all PASS. sur rc=0: 6 PASS, 1 SKIP (TestSurApiLogImportAndVerify, the T-27.29 target).
- Red evidence: static. The skip/env dependency is present on main; no runtime red run.
- Deviation: box /etc/hosts gained "127.0.0.1 000000000000.dkr.ecr.eu-west-1.localhost" (backup /etc/hosts.bak-W-2026-0001-t39-11). It was added before the no-box-changes rule and was not reverted; dev-lead decides.
- Status: done

## Review round (msg-206/207/208), HEAD 2ca718c99a56578db52dee083aaf5416eae91a72
- account_domain_test.go:28: the context error is no longer discarded. It is now `ctx, cerr := cbctx.NewContextWithDefaultOptions(...)` + `require.NoError(t, cerr, "create the test context")`.
- deployedAccountDomain was a pass-through wrapper and is now inlined. createTeosClient calls `mgr.DiscoverAccountDomain(ctx)` directly in both helpers.
- The duplicated account_domain_test.go in buildingsvc and sur is kept on purpose. Each copy sits in its own Go module (buildingsvc/deployment/service-test and sur/deployment/service-test, each with its own go.mod) and its own `servicetest` package. Each uses that package's harness and its `userPoolName` constant, and runs inside that service's deployed harness. A _test.go file cannot be imported. A shared helper would need a new exported package in go-core/testutils for about 15 lines, which is more coupling than the copy costs.
- Gates @2ca718c9 (gates/summary-2ca718c9.txt): fmt/vet/lint/lint-arch/test/tidy all rc=0.
- -race: the earlier service runs at 1dff7476 had no -race. Both were rerun with -race under floci-harness-run at 2ca718c9: buildingsvc rc=0 and sur rc=0, no DATA RACE (gates/test-service-*-race-2ca718c9.log).
- make test-integration @2ca718c9: command `env -i ... TK_LOCAL_EMULATOR=<pinned floci> sg docker -c 'make test-integration'` (/workspace/integ.sh), run serially under floci-harness-run, rc=2 (gates/test-integration-2ca718c9.log). The failures are outside this PR's packages: cmd/cblicense (AWS_ENDPOINT_URL not propagated to its subprocess under cbtest local exec; it also fails at 028f6a4b) and cbdeploy/internal/auth TestSSOLoginAgainstTheLocalEmulator (box DNS: *.localhost resolves to 198.18.0.1, so the test browser cannot reach the Floci vhost). No earlier test-integration log existed for this PR.

## Tracking issues for the unrelated test-integration failures (msg-227/228)
- #1245 (https://github.com/Thiink-LLC/teos/issues/1245): the 3 cmd/cblicense cases need AWS_ENDPOINT_URL when TEOS_DEPLOYMENT=local.
- #1246 (https://github.com/Thiink-LLC/teos/issues/1246): cbdeploy TestSSOLoginAgainstTheLocalEmulator can't resolve *.localhost.floci.io behind fake-IP DNS (possibly the same cause as #1243).
