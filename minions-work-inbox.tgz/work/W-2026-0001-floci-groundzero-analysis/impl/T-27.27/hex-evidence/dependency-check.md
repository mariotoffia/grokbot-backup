# T-27.27 / PR #1236 — manual port/adapter dependency check
HEAD 2ca718c99a56578db52dee083aaf5416eae91a72 (origin branch, fetched 2026-10-23). Raw graph: import-graph.txt (direct imports, `go list -e -f`, read-only).

## Touched files (all test, //go:build e2e)
- go-services/buildingsvc/deployment/service-test/{account_domain_test.go,helpers_api_test.go}
- go-services/providers/eastbound/sur/deployment/service-test/{account_domain_test.go,helpers_auth_test.go}
Black-box E2E tests against the deployed stack on Floci; they import only go-core managers (mgriamcognito etc.), aws-sdk clients, the services' exported API clients (buildingsvc/export/client/apiclient, sur/api/client) and testutils. They do not import any internal/core or adapter package of the service. Port substitution (fakes) is not applicable to deployed-stack E2E; unit-level fakes live elsewhere. No hex issue in the delta.

## buildingsvc (production, folder of go-services module)
| Layer | Packages |
|---|---|
| domain/core | buildsvccore, buildsvccore/cfin/** (merge, provision, strategies, syncdb, types), buildsvccore/configchange/** , buildsvctypes, buildingsvcevents, errorcodes |
| ports | buildsvccore/ports |
| adapters | adapters/messaging (SNS), adapters/ssmconfig (SSM) |
| client SDK (outbound to callers) | export/client/{,apiclient,lambdaclient} |
| cmd/wiring | handlers/** (Lambda mains) |
| util | lcsvcutils (dynamodb helpers) |
Checks:
- Ports defined in core (buildsvccore/ports), not adapters: PASS.
- Adapters depend inward only (ports, buildsvctypes, go-core): PASS. No adapter->adapter coupling: PASS.
- Handlers wire adapters + core: PASS (handlers/configdispatcher/main imports adapters/ssmconfig + configchange + ports).
- Core imports no infra SDK: FAIL (pre-existing, not touched by PR):
  - buildsvccore/service.go:4 aws-sdk-go-v2/service/dynamodb/types; :9 go-core/cmdbsvc/dynamodbcmdb (concrete DynamoDB adapter in core)
  - buildsvccore/query.go:6, delete.go:8, cfin/syncdb/expression.go:7, cfin/provision/loader.go:8, configchange/provider/loader.go:8 aws-sdk-go-v2/feature/dynamodb/expression
  - buildsvccore/configchange/target.go:7-9 aws-sdk-go-v2/aws, service/sns, sns/types (SNS publish in core; adapters/messaging already exists as the proper place)
  - buildsvccore/configchange/event.go:8, processor.go:8 aws-lambda-go/events
  - configchange/identity.go:4 dynamodb/types
  - net/http in core (delete.go:5, upsert.go:5, validation.go:4) is used for status codes on cberror — Low.
  Classification: infra leak INTO core (Medium, pre-existing tech debt). Not port-in-adapter, not domain-leak-in-adapter => no escalation trigger.

## sur (production, own module)
| Layer | Packages |
|---|---|
| domain | internal/core/domain, model/surmodel |
| ports | internal/core/ports/{inbound,outbound} |
| application | internal/core/application |
| adapters | internal/adapters/outbound/dynamodbqueue |
| cmd/wiring | handlers/** (+ handlers/internal/surtest test helper) |
Checks: domain imports nothing; ports in core; adapter imports only ports/outbound + go-core queue mgr; no adapter->adapter; handlers wire adapter+application: PASS.
- Low: internal/core/application/subscribe_service.go:7 imports aws-sdk-go-v2/aws (pointer helpers) — pre-existing.

## Violations summary
None introduced by PR #1236. Pre-existing: buildingsvc core infra leak (Medium), sur application aws helper (Low).
