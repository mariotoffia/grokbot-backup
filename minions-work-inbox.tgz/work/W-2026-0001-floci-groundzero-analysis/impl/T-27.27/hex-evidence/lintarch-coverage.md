# T-27.27 lint-arch coverage (HEAD 2ca718c9)
Maps in repo (10): appstore, realestatecore, eventsvc/evidencemonitor, eventsvc/evidencecollector, core/brokers/gobridge, core/management/iam, core/management/alarm-service, providers/eastbound/sur, providers/eastbound/mqtt, go-core/cbanalytics.

| Touched/tested package | Map | Result |
|---|---|---|
| sur production | go-services/providers/eastbound/sur/.go-arch-lint.yml | `go-arch-lint check` (v1.17.0) run directly in the module: "OK - No warnings found", rc=0 |
| sur deployment/service-test | excluded (`exclude: deployment`, `_test.go`) | not covered by design |
| buildingsvc production | NONE | not covered |
| buildingsvc deployment/service-test | NONE | not covered |
run.sh not used. Note: depOnAnyVendor true and deepScan false in the sur map, so vendor and DI rules are not enforced.

## Missing map: buildingsvc
- Path: go-services/buildingsvc/.go-arch-lint.yml (buildingsvc has no go.mod; it is part of the go-services module — use `workdir: buildingsvc`, like eventsvc/evidencecollector).
- Makefile: add `lint-arch:` to go-services/buildingsvc/Makefile running `go-arch-lint check --project-path .. --arch-file buildingsvc/.go-arch-lint.yml` so the root `make lint-arch` scanner finds it.
- Spec: proposed-map-buildingsvc.yml.txt. Dry run against the HEAD with the map in /tmp (repo not modified): "OK - No warnings found", rc=0. Negative control (adapters may not depend on ports): 2 notices, so the map really checks the code.
- Follow-up: once buildsvccore's aws/dynamodbcmdb imports move behind ports, set depOnAnyVendor: false with vendor lists, like evidencecollector.
