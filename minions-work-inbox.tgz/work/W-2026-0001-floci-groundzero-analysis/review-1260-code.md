# PR #1260 code review (code-reviewer): umbrella ADR docs/adr/0001-go-arch-lint-map-per-service.md

- Head: 71ee7f5bb39c251101d146ebd1380f7ab12ac8b6 (unchanged, DRAFT, Closes #1259). Merge-base 89f62e5f..71ee7f5b: 1 commit, 1 new file (+65 lines).
- df -h: / 31% used, 89G free.

## Verdict: CHANGES_REQUESTED

## Accuracy
- #1250 @798b11c5: `depOnAnyVendor: true`, and the core imports the AWS SDK (DynamoDB, SNS) and go-core/cmdbsvc/dynamodbcmdb (yml:29-32). Correct.
- #1257 @7139f4b8: `depOnAnyVendor: false`, and the core uses only errorcodes plus pure go-core (the core-errors and core-pure groups). Correct.
- "The Lead Architect approved both": matches review-arch-lint-signoff.md. The AGENTS.md:18 paraphrase is correct.
- Toolchain consequence: matches sign-off item 21. The box binary (v1.17.0, go1.27.3) is built with x/tools v0.50.0, which is consistent with v0.37.0 failing.
- The ADR does not state map counts. That is good: it avoids the 10, 11, 12 merge-order churn, which lives in LINT.md:225 only. It does not describe the core-errors pattern or the lint-arch recipe either, so there is nothing inaccurate there. FYI: the recipes differ. #1250 runs `go-arch-lint check --project-path .. --arch-file buildingsvc/...` in place, while #1257 uses `cd .. && --project-path .`. Both work, and LINT.md:223 documents the `..` form.
- Cited paths and commands: AGENTS.md, `.go-arch-lint.yml` and `make lint-arch` all exist. The two GitHub PR links resolve.

## Findings
- [Medium] [non-testable] docs/adr/0001-go-arch-lint-map-per-service.md:39-47 (Decision) — The baseline-violation rule is missing. Item 26 of the Lead Architect sign-off adds "a baseline map may allow an existing violation only if it links a tracking issue to remove it", and STATUS 12:47 says the text was approved with exactly that one edit. #1250 (depOnAnyVendor=true) depends on it. Fix: add the rule to Decision and name #1250 as its first use, linking the tracking issue once it exists.
- [Medium] [non-testable] #1259 — The board status is "Progress", not "Incoming". Fix: set it to Incoming per the issue-first rule, or confirm that Progress is intended.
- [Low] [non-testable] docs/adr/0001…md:1-7 — There is no Date. The ADR says it "follows the <service>/docs/adr format used by appstore, realestatecore and go-core", but those differ: go-core uses `# ADR-NNNN: …` with a Status/Date table, and appstore uses `# NN. …` with a `Status:` line. Fix: pick one (the go-core table with a Date is the most complete), and add a root docs/adr/README.md index like the cbanalytics and evidencemonitor ones.
- [Low] [non-testable] docs/adr/0001…md (Context/Consequences) — No LINT.md cross-reference. LINT.md §go-arch-lint (:203-236) holds the recipes, the map list and count, and "Not yet mapped". Fix: link LINT.md#go-arch-lint from the ADR. Optionally link the ADR from LINT.md:207.
- [Low] [non-testable] docs/adr/0001…md:41 — "Every Go service has its own go-arch-lint map" reads as if it were already true, but LINT.md lists services that are not yet mapped. There is also nothing about the interim gate for unmapped code: W-2026-0003, standard linter plus hexagonal and clean-arch reviewer sign-off, with the PR body noting that lint-arch is unavailable. Fix: add a consequence that unmapped services keep the interim reviewer gate, and their hex verdicts stay APPROVED_DEGRADED, until a map lands.
- [Info] Numbering 0001: there was no root docs/adr before, so there is no clash. The service-local series (go-core 0001-0009, appstore 0001-0009, cbanalytics 0001-0017, …) are separate namespaces. Root placement for a cross-service decision follows the sign-off (CONVENTIONS §3).

## Docs gates
- CI (lint.yml, archlint.yml, build.yml) has no markdown, link or spell gate, so there is no repo docs gate. Ad hoc runs: `cspell` with the repo cspell.json gives 0 issues, and `markdownlint-cli2` gives 0 errors. Lines are ≤80 columns.

## Compliance
- #1259: assignee mariotoffia, labels documentation and lint, Priority Medium, Size Hours, Sprint 21 (allowed), Roadmap unset, Status Progress (see the Medium above).
- Titles: the PR title, the commit subject ("docs: ADR for a go-arch-lint map per service") and the #1259 title have no W-/T- prefix. OK.

## Round 2: 71ee7f5b..4899ec6b

- Shas: reviewed 71ee7f5bb39c251101d146ebd1380f7ab12ac8b6 (round 1), now 4899ec6b396b5c397dd386fd5fdc163991ab8191. 1 commit: "docs: baseline violations need a tracking issue; note stricter cberror scope". No W-/T- prefix, and the PR title is unchanged and prefix-free.
- Delta: a baseline-violation rule added to Decision, a #1257 core-errors note (cberror is core-only; handlers cannot use it), and `cberror` added to cspell words.
- Accuracy:
  - The rule text matches sign-off item 26.
  - The cberror note matches #1257 @7139f4b8 (`core-errors` granted to core only).
  - #1250's body links its tracking issue, #1261 (vendor calls behind ports, flip depOnAnyVendor to false), so #1250 satisfies the new rule.
- Docs gates (ad hoc; there is no CI docs gate): cspell 0 issues, markdownlint-cli2 0 errors, no lines over 80 columns.

### Findings
- Round 1 Medium (baseline-violation rule missing): FIXED.
- [Medium] [non-testable] #1259 — The board Status is still "Progress", not "Incoming". Fix: set it to Incoming, or confirm that Progress is intended.
- [Low] carried, still open: no Date, and the format claim is inconsistent (ADR:1-7). No LINT.md#go-arch-lint cross-reference. The present-tense "every Go service has a map" with no interim W-2026-0003 gate for unmapped services (ADR:41).
- [Info] ADR:28-29 — "This is stricter" has no comparison point. Say "stricter than the first draft of the map", or drop it. The ADR could also cite #1261 as the first tracking issue under the new rule.

### Verdict: CHANGES_REQUESTED at 4899ec6b (only the #1259 status Medium blocks; Lows are non-blocking polish)

## R3: 4899ec6b..105a4eff

- Head: 105a4eff25a9b7c5b700e7be0560b7a85f98a06c (as expected). 2 commits: e2c387c4 "docs: cite tracking issue for buildingsvc vendor exception" and 105a4eff "docs: ADR status table, unmapped services, LINT links". No W-/T- prefix. The PR title is unchanged and prefix-free.
- #1259 (checked read-only): board Status=Incoming. The blocker is cleared.
- Round 1 Lows:
  - Date/format: FIXED. Go-core style `# ADR-0001:` heading with a Status/Date table (Proposed, 2026-10-23). The format claim now says "the format of the go-core ADRs".
  - README index: FIXED. The new docs/adr/README.md links 0001-go-arch-lint-map-per-service.md, and the file exists.
  - LINT.md cross-reference: FIXED. `../../LINT.md#go-arch-lint` resolves to the heading `## §go-arch-lint` (GitHub slug drops §), and the permalink L203-L236 @89f62e5f matches the section.
  - Unmapped services and interim gate: FIXED. Decision now says "must have". The Consequences unmapped list matches main @89f62e5f exactly: checked every go-services dir with Go code against its .go-arch-lint.yml, including the eastbound realestatecore provider, which is distinct from the mapped go-services/realestatecore. The W-2026-0003 interim gate (standard linter plus hex and clean-arch sign-off, PR body notes lint-arch is unavailable, hex verdicts APPROVED_DEGRADED) is stated.
  - "Stricter": FIXED. It now compares against no map, and the listed handler grants match #1257 @7139f4b8 (core, core-pure, core-runtime, aws-lambda, zerolog).
- Accuracy: #1261 "buildingsvc: move AWS SDK and CMDB client calls behind outbound ports" (OPEN) matches the text and is linked from #1250. The multi-module reason in Alternatives matches LINT.md:207.
- Docs (ad hoc; there is no CI gate): cspell 0 issues across the 2 files, and markdownlint-cli2 0 errors. The only lines over 80 columns are a permalink and a table row.

### Findings
- [Info] ADR Consequences — The unmapped list omits the shared non-service packages under go-services (clients, httpmock, model, testutils). This is acceptable because the list is headed services and providers. It could say "services and providers" explicitly.
- [Info] Pre-existing, outside this PR: LINT.md:222 names `tklocal` as an example of a uService in its own module next to mapped ones, but tklocal has no map on main. It is worth a LINT.md wording fix in a later docs change.

### Verdict: APPROVED at 105a4eff

## R4: 105a4eff..3d8f6dea

- Head: 3d8f6deaa37e1c85bcc1507d5ec48cff4549f33c (as expected). Main is at 89f62e5f.
- Commits: 3bff4c79 "docs: list unmapped shared go-services packages", 0071fe8f "docs: interim gate in Decision, snapshot label, lint-arch count and tool install", 3d8f6dea "docs: fix spelling in lint-arch count line". None has a W-/T- prefix, and the PR title is unchanged and clean.
- #1259: Status=Incoming (read-only graphql).
- lint-arch count wording: ACCURATE. Root Makefile:631-642 loops over Makefiles with `^lint-arch:` and increments `checked` per Makefile.
  - Main has 9 such Makefiles (cbanalytics, appstore, gobridge, alarm-service, iam, eventsvc, mqtt, sur, realestatecore) but 10 maps, because go-services/eventsvc/Makefile runs evidencecollector and evidencemonitor. The ADR states this exactly.
  - Each of the #1250 and #1257 heads has 10 targets, so both merged makes 11. That matches "raises the count by one" in either merge order.
  - The ADR gives no absolute number, so the LINT.md 10/11/12 map-count caveat does not affect it.
- Toolchain line: ACCURATE.
  - The root `install` runs `cd tools && GOWORK=off go install tool` outside the OS ifeq blocks, so it runs on every OS.
  - tools/go.mod has the `tool github.com/fe3dback/go-arch-lint` directive (line 12), `go-arch-lint v1.17.0` (line 95) and `golang.org/x/tools v0.50.0` (line 268).
  - The old "toolchain must be pinned" wording is replaced. This resolves the earlier toolchain note.
- Other new text:
  - The interim gate has moved into Decision.
  - The snapshot is labelled with its sha and date and points to LINT.md "Not yet mapped" (LINT.md:227).
  - The shared packages (clients, httpmock, model, testutils) match main, which resolves my R3 Info.
- Copilot: the latest review on 3d8f6dea is "Approval recommended, No open issues", with 2 resolved. There are 0 unresolved review threads and 0 inline comments on 3d8f6dea. Clean.
- Docs (ad hoc): cspell 0 issues and markdownlint-cli2 0 errors across the 2 files.

### Findings
- [Info] [non-testable] ADR Consequences — The ADR counts `lint-arch` targets (main has 9), while LINT.md:225 counts maps (10). Both are correct, but readers may compare them. Optional fix: add "(LINT.md counts maps)".
- [Info] [non-testable] ADR Consequences — "Unmapped services keep their hexagonal verdicts at APPROVED_DEGRADED" repeats the Decision bullet. It is harmless.

### Verdict: APPROVED at 3d8f6dea

### R4 addendum: 3d8f6dea..392d8a7e (scope update; reviewed sha 392d8a7eecc8a25406d5e65dfc56a40ad3d5664e)
- Commit 392d8a7e "docs: shared packages are out of scope, not exempt". No W-/T- prefix. This is the PR head.
- The change rewrites the shared-packages bullet: "shared packages, not services. This ADR covers services only and does not decide whether they need maps."
- ACCURATE against main @89f62e5f. clients (3 .go), httpmock (4), model (47) and testutils (7) have no `package main` and no .go-arch-lint.yml, so they are libraries, not services. The new wording is also consistent with the Decision's per-service scope and avoids implying an exemption.
- cspell 0 issues and markdownlint-cli2 0 errors (re-run ad hoc).
- [Info] [non-testable] The latest Copilot review is on 3d8f6dea, and Copilot has not re-reviewed 392d8a7e. The one-sentence docs delta is low-risk.

### Verdict for the whole range 105a4eff..392d8a7e: APPROVED at 392d8a7e (supersedes the 3d8f6dea verdict above)
