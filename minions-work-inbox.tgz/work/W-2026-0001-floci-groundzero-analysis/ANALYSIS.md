# W-2026-0001 — Are the 16 "doable now" Floci groundzero tasks really doable?

Author: the Dev Lead minion (`dev-lead`). Analysis only: no start gate, no worktree, branch or code change.
Times are Europe/Stockholm (CEST, UTC+2). Upstream data was read on 2026-10-21 between 14:25 and 14:35 CEST.

Sources: `/workspace/minions/inbox/floci-groundzero/TEOS_GROUNDZERO_TASKS.md` (Task 27, Task 39, marker table),
`plans/teos-adoption/README.md`, and the local TEOS copy `/workspace/thiink/teos` (AGENTS.md, marker grep,
`go-core/utils/testutils/flocilocal/consts.go`, `deployment/provision-config.yaml`). Upstream repo: `floci-io/floci`
(public GitHub API and PR pages; `gh` was not logged in). `Thiink-LLC/teos` is private, so only the local copy was used.

Note: `/workspace/minions/TEOS_CONVENTIONS.md` is **missing** from the team folder. I read the copy at
`/tmp/minions_backup_1792581349/TEOS_CONVENTIONS.md` (same as `/tmp/thiink_minions_bak/`). Someone should restore it
(technical-writer, through the CTO). The §A–§E and §1 references below come from that copy.

## 0. Rule used (Mario's correction, 14:24)

A Floci fix counts as available when it is **merged on floci-io/floci `main`**, and therefore in
`mariotoffia/floci:latest` (a build of main plus Mario's PRs). Whether it is in a release does not matter.
TEOS pins that image in two places that must match: `flocilocal.DefaultImage` (`consts.go:34`, comment points at
Thiink-LLC/teos#902) and `common.local.emulator` in `deployment/provision-config.yaml:34`.

### Upstream state of every referenced PR

| PR | What | Floci task | Merged on main (CEST) | Release |
|---|---|---|---|---|
| #4857 | ECR registry port retry | 18 | 2026-10-08 21:31 | 2.3.0 |
| #4896 | IoT indexing configuration | 9.4 | 2026-10-09 22:52 | 2.3.0 |
| #4316 | CFN event source mapping options | 23.1 | 2026-09-25 03:05 | 2.2.0 |
| #4739 | Lambda ESM docs correction (docs only) | 23.2 | 2026-10-02 14:40 | 2.2.0 |
| #4563 | Tagging: find resources by their own tags | 17.x | 2026-09-30 12:10 | 2.2.0 |
| #5260 | IoT shadow events through topic rules (+ shadow metadata) | 19.1, 9.6 | 2026-10-17 02:47 | unreleased |
| #4733 | Lambda async retries / Invoke Qualifier | 21 | 2026-10-01 16:00 | 2.2.0 |
| #4736 | EventBridge target retry + DLQ | 29.6 | 2026-10-01 13:59 | 2.2.0 |
| #4913 | IoT fleet index search subset | 30.1 | 2026-10-10 19:56 | 2.3.0 |
| #6025 | IoT fleet search by connectivity | 30.1 | 2026-10-20 01:45 | unreleased |
| #5021 | Logs subscription filter delivery | 41.1 | 2026-10-05 03:43 | 2.2.0 |
| #5448 | Cognito domains in user pool responses | 29.10 | 2026-10-12 18:34 | 2.3.0 |
| #5131 | API Gateway OpenAPI export; import keeps binary media types (author vamsiak) | 44.3 | 2026-10-13 22:40 | 2.3.0 |
| #4808 | ECS awslogs group/stream | 39.2 | 2026-10-01 16:39 | 2.2.0 |
| #5261 | SSM parameter ARN normalisation (**colleague did not list it**) | 15.1 | 2026-10-19 15:46 | unreleased |
| #5262 | SSM Parameter Store Change events | 15.2 | **2026-10-21 13:07** | unreleased |
| #6054 | ECS Container Insights task counts | 39.3 | **2026-10-21 12:59** | unreleased |
| #3537 | API Gateway enforces ApiKeyRequired (for 27.1) | — | 2026-09-13 | 2.1.0 |

Release mapping is by merge time versus release time (2.2.0 = 2026-10-06 07:23, 2.3.0 = 2026-10-15 07:39, both cut from
`main`); #4857 and #5131 were confirmed by the "included in 2.3.0" bot comment.

**All 17 PRs are merged on main. Nothing in the 16 tasks waits on an open upstream PR.** The colleague's
"until #5262 and #6054 merge" is out of date: both merged today.

### Image rebuild needed

`mariotoffia/floci:latest` was pushed **2026-10-21 09:36 CEST** (Docker Hub, digest `sha256:6e4341f3…`). That is
before #6054 and #5262 merged. So today's image has main as of about 09:36 plus the **pre-merge branches** of those
two PRs. Every other fix above merged earlier, so it is in the image.

Recommendation: rebuild `mariotoffia/floci:latest` from current `main` (head `7c0d592b8`, 14:23 CEST) with no extra
PRs. Then the qualifying runs for 27.10 and the 39.11 follow-up test the code as merged, not the reviewed-away
branch. Record the new digest in each PR's evidence. After that the image is plain `main`; switching TEOS back to
`floci/floci` (teos#902) can happen once a release after 2.3.0 contains #5260, #6025, #5261, #5262 and #6054. That is a
separate task for release-config-mgr, not part of these 16.

## 1. Per-task verdict

Marker locations below are from the local TEOS copy (`rg "floci: Missing Implementation for"`).

| Task | Verdict | Floci dependency (state) | Reasoning, dependencies |
|---|---|---|---|
| 27.1 | **Agree, with a caveat** | None new. #3537 (2.1.0) | API-key, unknown-route 403 and Logs-cap cases. Caveat: "accepts a key whose usage plan is linked to the stage" must not depend on reading `apiStages` back from `GetUsagePlan`; that is 44.1, still not done. Build the case by binding the key directly, or it is blocked. |
| 27.10 | **Agree** (now unblocked on main) | 15.1 #5261 + 15.2 #5262, both merged | Colleague missed 15.1: the plan says "15.1/15.2". Delete `injectSSMParameterChangeEvent` and its markers in `collectorsvc/deployment/service-test/{helpers_test.go:73, main_test.go:20, e2e_collection_test.go:118}`. Qualify on the rebuilt image. |
| 27.12 | **Agree** | 18 #4857 | Marker `go-core/utils/testutils/flocilocal/flocilocal.go:246`. Must prove two scoped emulators start registries without the single-port override. |
| 27.13 | **Agree** | None | Pure TEOS fix in `go-core/managers/mgriot/awsmgriot/devicemanager_aws.go`; nil-safe thing-type metadata. Also a real-AWS bug. No marker. |
| 27.14 | **Agree** | 9.4 #4896 | devicesvc fleet-indexing readiness only; do not remove search/connectivity exclusions. |
| 27.16.1 | **Agree** | 23.1 #4316 (23.2 #4739 is docs only) | Event-service ESM, automatic alarm and runtime evidence. No marker; it is new coverage. Shares the eventsvc service-test package with 27.16.6 and 27.25: run SERIAL. |
| 27.16.2 | **Agree** | 17.x #4563, 19.1 #5260 | Markers `actuationsvc/deployment/service-test/eastbound_test.go:43,219`. |
| 27.16.3 | **Agree** | 19.1 #5260 | Markers `corerouter/deployment/service-test/mirror_test.go:44,218`. |
| 27.16.4 | **Agree** | 19.1 #5260 | Marker `ingestionsvc/deployment/service-test/ingestion_test.go:44`; also assert real Firehose/Logs sink output. |
| 27.16.6 | **Agree** | 21 #4733, 29.6 #4736 | Markers `eventsvc/deployment/service-test/monitor_datapath_test.go:21` and `provision-config.local.yaml:8`. Keep W-6 until the slow-turn retry runs with no synthetic invocation. |
| 27.20 | **Agree; after 27.14** | 30.1 #4913 + #6025, needs 9.4 #4896 | Marker `devicesearcher_aws_integration_test.go:43`. Keep the account-indexing-off skip, which is real AWS behaviour. |
| 27.21 | **Agree** | 9.6 in #5260 | Markers `go-core/cbtarget/awsdstarget/target_integration_test.go:214`, `go-core/cbtarget/awsdstarget_integration_test.go:46`. |
| 27.25 | **Agree** | 41.1 #5021 | Marker `eventsvc/deployment/service-test/subscriber_test.go:42`. |
| 27.27 | **Agree** | 29.10 #5448 | Markers `buildingsvc/.../helpers_api_test.go:52`, `sur/.../helpers_auth_test.go:50`. The helpers may keep reading the domain from the provision config; the gain is that production `mgriamcognito.GetAccountDomain` now works locally. Add a check of that. |
| 27.29 | **Agree, medium confidence** | 44.3 #5131 | Marker `sur/.../e2e_logs_geo_test.go:52`. #5131 is mainly an export feature; it keeps binary media types on import. Prove first that a gzip body now reaches the Lambda intact. If not, raise a Floci follow-up and drop the task. |
| 39.11 | **Agree, but re-scope** | 39.2 #4808, 39.3 #6054, both merged | 39.11 itself is already done (TEOS #901). The open work is the follow-up: delete the two skips in `gobridge/deployment/service-test/recovery_observability_test.go:176` (Container Insights) and `:279` (awslogs). Needs the rebuilt image for #6054. Long run (60 min). |

### What the colleague missed

1. **27.28 is now a hazard, not just a TODO.** 44.2 (API key enforcement) merged upstream as #5450, so it is in the
   image. The building and SUR helpers (`helpers_api_test.go:223`, `helpers_auth_test.go:209`) and
   `go-services/testutils/integrationtests/client.go:180` leave the test client's API key unbound on the local target.
   The plan says 27.28 must land "before or with 44.2". 27.28 still needs 44.1 (not done). Expect building/SUR local
   service tests to fail with 403 on the current image. Check this in Wave 0; if it fails, 44.1 becomes urgent
   upstream work, and 27.27 and 27.29 (same SUR/building packages) cannot be qualified until it is fixed.
2. **27.10 also needs 15.1 (#5261).** It is merged, so the verdict holds.
3. **39.11 is already ticked.** Only the marker removal is left.
4. **The 19.1 marker is shared.** 27.16.2, .3 and .4 each remove the same marker text in different services. After
   all three, grep must show it gone. The tasks file also says a shadow update over **MQTT** does not reach rules.
   Check whether #5260 covers MQTT as well as HTTP; the tests only need HTTP.
5. **Excluded tasks were right to exclude:** 27.9 (Task 16 not done), 27.18 (9.2 not started), 27.19 (9.3 not
   started), 27.26 (42.1 local branch only, no PR), 27.28 (44.1), 27.30 (44.4), 27.31 (44.5), 27.32 (44.6),
   27.33 (greedy path fix).
6. **Removal rule.** A marker goes only when the un-skipped test passes on the pinned image **and on AWS**
   (adoption plan, "27.18 to 27.21"). AWS runs need credentials, which only qa-lead and platform-lead hold. Every
   wave needs a qa-lead cloud run.
7. **TEOS_CONVENTIONS.md is missing** from `/workspace/minions/` (see top).

## 2. Approach per group, affected services, risks

| Group | Tasks | Approach | Affected modules | Risks |
|---|---|---|---|---|
| G1 go-core fixes and integration tests | 27.13, 27.12, 27.14, 27.20, 27.21 | 27.13: TDD unit tests for nil metadata/deprecation, then guard. Others: delete the marker and skip, run `make test-integration` on Floci, then the cloud run. 27.14 changes the devicesvc lifecycle script. | `go-core/managers/mgriot`, `go-core/utils/testutils/flocilocal`, `go-core/cbtarget`, devicesvc | 27.12 needs Docker-in-Docker port behaviour on CI. 27.20 is ordered after 27.14. Readiness timing flakes on fleet index. |
| G2 IoT shadow delivery service tests | 27.16.2, 27.16.3, 27.16.4 | Remove the `HTTP shadow updates reaching topic rules` skips; assert real rule output (queue, Firehose, Logs). | actuationsvc, corerouter, ingestionsvc | MQTT path may still differ; long deploys; shared marker. |
| G3 event service | 27.16.1, 27.16.6, 27.25 | One package, so SERIAL: 27.25 (simple skip), 27.16.6 (retry/DLQ, remove local provision override), 27.16.1 (new ESM/alarm evidence). | eventsvc | Retry timing makes tests slow; automatic alarm evaluation timing. |
| G4 collector SSM | 27.10 | Delete the injected event; rely on real `PutParameter` → EventBridge → queue → rule manager. | collectorsvc | Needs the rebuilt image. Event shape must match AWS (#5262 was checked against AWS). |
| G5 API Gateway / Cognito | 27.1, 27.27, 27.29 | 27.1 new compatibility cases; 27.27 marker removal plus a production `GetAccountDomain` check; 27.29 gzip log import. | groundzero/svctest, buildingsvc, sur | 27.28 / 44.2 hazard (403s). 27.29 may not be fixed by #5131. |
| G6 GoBridge | 39.11 follow-up | Delete two skips; a 60-minute service-test run. | gobridge | Needs the rebuilt image; long run; Container Insights alarm timing. |

General risks: image drift between the two pins (`consts.go` and `provision-config.yaml`); running many service
tests at once on one shared box (Docker, ports, memory); no source PR may stack across repos.

## 3. Waves, minions, checklists, gates

Caps: ≤4 parallel cloud agents per feature, ≤6 team-wide. Each task is one TEOS PR (adoption plan), on a
`chore/W-2026-0001-<task>` branch (or the repo's scheme) in a worktree **only after Mario's go**.

Checklist per task. No task scaffolds anything new. These are changes to existing modules, so the checklist
names the module kind and §1 gates apply in full:
- go-core library tasks → **§C** (shared library) + §I tests.
- service-test and service tasks → **§A** (existing uService; A.2 steps for tests and docs only) + §I.
- No §B, §D or §E tasks.

Gates for every task (TEOS_CONVENTIONS §1): `make fmt`, `make lint` (runs `lint-go` **and** `lint-arch`), `make vet`,
`make test`, `make tidy` with a clean diff, plus:
- go-core tasks: `make test-integration` on the pinned image, and `make test-integration-cloud` (qa-lead).
- service tasks: `CB_SERVICE_TEST=<svc> make test-service` on the pinned image, and `make test-service-cloud` (qa-lead).
- Evidence: the image digest, executed tests listed apart from skips, and `rg` proof that the marker is gone.

| Wave | Tasks (agents) | Implementer | Reviewers / others |
|---|---|---|---|
| W0 prep (no code) | Rebuild `mariotoffia/floci:latest` from main; record the digest; baseline run of building/SUR service tests to check the 27.28 / 44.2 hazard | qa-lead (credentials) with platform-lead / release-config-mgr for the image | dev-lead decides from the result whether G5 waits on 44.1 |
| W1 (4) | 27.13 (§C), 27.12 (§C), 27.14 (§A), 27.21 (§C) | golang-pro ×4 | code-reviewer each; test-designer for the 27.13 red test |
| W2 (4) | 27.20 (§C, after 27.14), 27.10 (§A), 27.25 (§A), 27.16.2 (§A) | golang-pro ×4 | code-reviewer; test-reviewer for evidence |
| W3 (4) | 27.16.3 (§A), 27.16.4 (§A), 27.16.6 (§A, after 27.25), 39.11 follow-up (§A) | golang-pro ×3 + golang-pro for gobridge | code-reviewer; observability-sre consult for the 39.3 alarm |
| W4 (≤3) | 27.16.1 (§A, after 27.16.6), 27.1 (§A), 27.27 (§A), 27.29 (§A) — the last two only if W0 shows no 44.2 failures | golang-pro | code-reviewer; api-designer consult for 27.1/27.29; security-auditor read-only look at 27.1 API-key case |

That is at most 4 agents per wave for this feature, which leaves 2 team-wide slots free. qa-lead runs the cloud
gates at the end of each wave. technical-writer updates TEOS_GROUNDZERO_TASKS.md and the marker table after each wave.
Escalation: any arch-lint failure that needs an ADR, or a marker that will not go away → dev-lead → CTO.

## 4. Recommendation: Project Lead

**Yes, send it to the Project Lead. minion** It spans 12 modules (go-core managers and testutils, devicesvc,
actuationsvc, corerouter, ingestionsvc, eventsvc, collectorsvc, buildingsvc, sur, gobridge, groundzero svctest)
over 5 waves. It has an image dependency in another repo, AWS qualification runs that need credentialed minions,
and one open risk (27.28 / 44.1) that can block a group. The Project Lead should own milestones, dependencies and the
risk register. Dev Lead does the split, the packets and the cloud agents after Mario's go.
Packet: `handoff-project-lead.md`.

## 2026-10-21 19:41 CEST — SCOPE RULE (Mario)
W-2026-0001 is Floci-only. No tests against or deploys to real AWS (including devlocal). All gates and evidence come from Floci. The qa-lead AWS run request (msg-084/087) is cancelled, and AWS ACs (27.10/27.25 AC4, 27.14 AC5, 27.12 cloud gate) are out of scope.
