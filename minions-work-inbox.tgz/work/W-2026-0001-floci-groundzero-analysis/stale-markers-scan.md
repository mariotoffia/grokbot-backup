# Stale `floci: Missing Implementation` marker scan — 2026-10-22

- teos origin/main: 863b6019ad0063b7e7c2b916750f6c61323089e7
- Floci upstream/main: 5beb8d47b (2026-10-22 05:09 Europe/Stockholm)
- Image: mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7 (built 2026-10-21 14:42 Europe/Stockholm). `docker pull` said "Image is up to date", so this is the same digest as before.
- Method: `git grep` on origin/main. I read the Floci source at upstream/main. I probed a throwaway container of the image on localhost:14566 with the aws CLI (Floci only). Nothing ran against real AWS. I didn't need a teos worktree because no candidate was promising enough to un-skip, so none was created.
- The doc and plan copies of markers (SERVICE_TEST_WRITING.md, svctest/doc.go, gobridge docs/plans/*, NOT_QUALIFIED_AGAINST_REAL_AWS.md, the iam plan) are excluded because they are not guards.
- The variant searches (case-insensitive "missing implementation", `t.Skip` citing Floci) turned up no extra guards. They found only `testing.Short()` skips and appstore comments that have nothing to do with Floci.

## Counts
STALE 0 · PARTIAL 0 · STILL MISSING 9 gaps (17 code sites) · ALREADY TRACKED 9 gaps (16 sites)

## Table
| file:line | service / op | guard | class | evidence |
|---|---|---|---|---|
| go-core/cbtarget/awsdstarget/target_integration_test.go:214 | IoT shadow metadata | skip | ALREADY TRACKED 27.21 (blocked, Floci Task 48) | |
| go-core/cbtarget/awsdstarget_integration_test.go:46 | IoT shadow metadata | skip | ALREADY TRACKED 27.21 | |
| go-core/managers/mgriot/awsmgriot/devicemanager_aws_integration_test.go:38 | IoT UpdateThing attribute merge | skip | STILL MISSING | IotService.updateThing (IotService.java:289) calls `thing.setAttributes(attributes)` and ignores `merge`. Probe: create {a=1}, update {b=2},merge=true, describe gives {"b":"2"} |
| go-core/managers/mgriot/awsmgriot/devicesearcher_aws_integration_test.go:43 | IoT fleet search | skip | ALREADY TRACKED 27.20 | |
| go-core/managers/mgrlog/clwlog/cloudwatch_integration_test.go:168,207,237 | Logs PutLogEvents missing group/stream message | skip | STILL MISSING | CloudWatchLogsService.java:322-494,533,690,725 append `": " + name`. TEOS put.go:248/253 matches the exact text "The specified log stream/group does not exist.". Probe: a missing stream gives "...does not exist: nope", and a missing *group* also gives the stream message |
| go-services/core/brokers/gobridge/internal/testkit/logs.go:34 | same (Logs message) | workaround: pre-create streams | STILL MISSING | same as above |
| go-services/providers/eastbound/tklocal/deployment/service-test/metrics_test.go:48 | same (Logs message) | workaround: pre-create streams | STILL MISSING | same as above |
| go-core/utils/testutils/flocilocal/flocilocal.go:246 | ECR registry port retry | workaround | ALREADY TRACKED 27.12 | |
| actuationsvc/.../eastbound_test.go:43,219 | IoT HTTP shadow update to topic rules | skip | ALREADY TRACKED 27.16.2 | |
| corerouter/.../mirror_test.go:44,218 | same | skip | ALREADY TRACKED 27.16.3 | |
| ingestionsvc/.../ingestion_test.go:44 | same | skip | ALREADY TRACKED 27.16.4 | |
| appstore/cmd/cbdeploy/internal/cfn/cloud_undeploy.go:328 | CloudFormation DeleteStack RetainResources | warning text | STILL MISSING | no `RetainResources` anywhere in Floci src/main |
| buildingsvc/.../helpers_api_test.go:52 | Cognito DescribeUserPool CustomDomain | workaround | ALREADY TRACKED 27.27 | |
| sur/.../helpers_auth_test.go:50 | same | workaround | ALREADY TRACKED 27.27 | |
| buildingsvc/.../helpers_api_test.go:223 | APIGW usage plan apiStages | skip key bind on local | STILL MISSING | The UsagePlan model holds apiStages (ApiGatewayService.java:1516, from #2631), but they are not returned. Probe: create-usage-plan --api-stages gives apiStages=null, and get-usage-plans gives []. This is Floci 44.1 (see the ANALYSIS 27.1 caveat) |
| sur/.../helpers_auth_test.go:209 | same | skip key bind | STILL MISSING | same |
| go-services/testutils/integrationtests/client.go:180 | same | skip key bind | STILL MISSING | same |
| sur/.../e2e_logs_geo_test.go:52 | APIGW binary media types on import | skip | ALREADY TRACKED 27.29 | |
| collectorsvc/.../e2e_collection_test.go:118, helpers_test.go:73, main_test.go:20 | SSM Parameter Store change events | fake event injection | ALREADY TRACKED 27.10 (Floci #5262 89317831b in image) | |
| gobridge/.../recovery_observability_test.go:176 | ECS Container Insights | skip | ALREADY TRACKED 39.11 (#6054 1b1529922) | |
| gobridge/.../recovery_observability_test.go:279 | ECS awslogs log group | skip | ALREADY TRACKED 39.11 | |
| iam/.../admin_function_test.go:72 | APIGW greedy {name+} below a {param} | workaround: invoke Lambda directly | STILL MISSING | ApiGatewayExecuteController.matchResources step 3 (~l.4238) uses `requestPath.startsWith(greedyParentPrefix)`, and that prefix is literal (`/v1/admin/catalog/{kind}/`), so a template segment never matches |
| iam/.../self_service_test.go:140 | APIGW Cognito authorizer scope refusal (401) | expects 403 locally | STILL MISSING | CognitoUserPoolAuthorizer.java:63-74 returns ACCESS_DENIED, and ApiGatewayExecuteController l.1026 maps that to 403 |
| tklocal/.../admin_api_test.go:78 | same | expects 403 | STILL MISSING | same |
| eventsvc/.../monitor_datapath_test.go:21 | EventBridge retry/DLQ | skip | ALREADY TRACKED 27.16.6 | |
| eventsvc/.../provision-config.local.yaml:8 | async Lambda retries | local override | ALREADY TRACKED 27.16.6 | |
| eventsvc/.../subscriber_test.go:42 | Logs subscription delivery | skip | ALREADY TRACKED 27.25 | |
| mqtt/.../outbound_test.go:42,145 | IoT data-plane Publish to MQTT subscribers | skip | STILL MISSING | IotService.publish (IotService.java:1147-1163) only runs handlePublish (rules). mqttBrokerService.publish is called only from publishShadowEvent (#5260 534571b2a, shadows only) |
| tklocal/.../esv_test.go:37 | same | skip | STILL MISSING | same |
| tklocal/.../status_test.go:21,74 | IoT GetRetainedMessage lastModifiedTime in epoch ms | skip/workaround | STILL MISSING | IotDataController.putEpoch (l.190) writes `toEpochMilli()/1000.0` (seconds). Probe: lastModifiedTime=1792650320 (seconds) |

## Conclusion
None of the untracked markers is stale against this image. Each STILL MISSING row is a Floci upstream gap, so the next step is to file or link a Floci ledger task. The smallest Floci fixes are:
- Logs message text: drop the `: name` suffix and use the group message for a missing group. Tiny.
- Retained-message epoch ms: tiny.
- UpdateThing `merge`: small.
- Usage plan apiStages serialization (Floci 44.1): small.
- Scope 401: tiny. Verify the AWS behaviour first.
- Greedy below a param: small to medium.
- Data-plane Publish fan-out to MQTT: small, because the broker hook already exists.
- RetainResources: medium.

---

# Verification, corrections and Floci fix specs (golang-pro minion, 2026-10-22, Europe/Stockholm)

Base: teos 863b6019. Floci image mariotoffia/floci@sha256:9710d4669e0fe7464641db04fc61424b4498f62881044f787900e9fedbe461a7. Its labels say floci/floci 9.8 at revision f9d3e906, created 2026-10-21 14:42. Floci source was read at upstream/main 5beb8d47b. Everything ran against Floci only: no real AWS, no devlocal profile, and AWS_CONFIG_FILE/AWS_SHARED_CREDENTIALS_FILE were set to /dev/null for every probe.

## 1. Classification check
`git grep -n "floci: Missing Implementation for" 863b6019 -- '*.go'` gives 39 lines. Two of them (deployment/lib/svctest/doc.go:162 and gobridge/deployment/service-test/main_test.go:13) describe the convention and are not guards. The other 37 sites match the table above row for row. The non-Go search adds only provision-config.local.yaml:8 (already tracked, 27.16.6) plus docs and plans.
Every classification above is confirmed. STALE: 0.

### Corrections
- **Gap count: there are 9 untracked gaps, not 8.** The Logs row hides two separate Floci defects (see the 9th gap below).
- **Site count: 18 untracked code sites, not 17**: UpdateThing 1, Logs 5 (cloudwatch_integration_test.go:168/207/237, gobridge testkit/logs.go:34, tklocal metrics_test.go:48), RetainResources 1, usage plan apiStages 3, greedy 1, scope 401 2, data-plane Publish 3 (mqtt outbound_test.go:42/145, tklocal esv_test.go:37), retained epoch 2 (status_test.go:21/74).
- Usage plan probe: `get-usage-plans` does return the plan (`{"items":[{"id":…,"name":"p"}]}`), just without `apiStages`. It does not return `[]`.
- Scope 401 (the "verify AWS first" note): the AWS docs confirm that a token whose scopes match none of the method's authorization scopes "fails with a 401 Unauthorized response" (API Gateway developer guide, "Integrate a REST API with an Amazon Cognito user pool"). The TEOS expectation is correct, so the gap is real.
- Method note: spot-checks were run in a throwaway worktree (section 2), so "no teos worktree created" no longer holds.
- Side note, not verified: the buildingsvc comment at helpers_api_test.go:223 says Floci "does not check API keys". Upstream ApiGatewayExecuteController.java:1356 now checks `plan.getApiStages()` for API key access, so that comment may be outdated once apiStages are returned.

### The missing 9th gap
**CloudWatch Logs PutLogEvents to a missing log group returns the log-stream error.** This is separate from the `": <name>"` suffix. `CloudWatchLogsService.putLogEventsForAccount` (CloudWatchLogsService.java:684-690) looks up only the stream key, so a missing group always produces "The specified log stream does not exist: <stream>". AWS answers "The specified log group does not exist." TEOS put.go switches on the exact message, so even without the suffix TestLogToGroupThatDoNotExistsShallGiveError would see LogStreamNotFound instead of LogGroupNotFound. Marker site: go-core/managers/mgrlog/clwlog/cloudwatch_integration_test.go:207 (it shares its marker text with gap 1). Probe: `put-log-events --log-group-name nogroup --log-stream-name nope` gives "The specified log stream does not exist: nope".

## 2. Spot-checks (throwaway worktree work/git-worktree/tmp-stalecheck-863b6019, detached at 863b6019, guards removed, removed afterwards)
go-core: `cbtest local exec --resources-only --provision-config deployment/provision-config.yaml -- bash -c "cd <pkg> && go test -tags integration,floci -count=1 -v -run '<test>' ."`
Service tests: `cd <svc>/deployment/service-test && TEOS_DEPLOYMENT=local CB_SERVICE_TEST=<svc> go test -tags=e2e,floci -count=1 -v -run '<test>' ./...`

| # | Gap | Size | Stale | Guard removed / narrowest test | Result on Floci 9710d466 |
|---|---|---|---|---|---|
| 1 | Logs message carries `": <name>"` suffix | tiny | no | clwlog TestLogToStreamThatDoNotExistsShallGiveError, TestLogToStreamThatDoNotExistsWithAutoCreateShallSucceed | FAIL: code 2000 (LogErrorWhileLogPut), want 2001. Auto-create: "a resource is missing while logging…", so the stream is never created |
| 9 | PutLogEvents missing group gives the stream error | tiny | no | clwlog TestLogToGroupThatDoNotExistsShallGiveError | FAIL: code 2000, want 2002 |
| 2 | GetRetainedMessage lastModifiedTime in seconds | tiny | no | tklocal TestPresenceReachesTheStatusTopic (skip removed, releaseStatus always waits) | FAIL: "GetRetainedMessage … deserialization failed, failed to decode response body". Probe: lastModifiedTime=1792653200 (seconds) |
| 3 | Cognito authorizer scope refusal gives 403, AWS gives 401 | tiny | no | tklocal TestAdminAPI/a_user_in_no_admin_group_is_refused (want 401 locally) | FAIL: expected 401, actual 403 `{"title":"Forbidden","status":403}` |
| 4 | UpdateThing ignores `merge` | small | no | awsmgriot TestCreateAndUpdateThing | FAIL: expected "unit-test", actual "" (the original attribute was dropped). Probe: {a=1} + merge {b=2} gives {"b":"2"} |
| 5 | Usage plan apiStages not returned | small | no | buildingsvc TestLCSAPIClient (bind always) | FAIL: "Could not find usage plan: 'system' for API: 'lcs'" |
| 6 | Data-plane Publish not delivered to MQTT subscribers | small | no | mqtt TestOutboundActuation | FAIL: "Timed out waiting for message on teos/actuate_v1/… after 2m0s" |
| 7 | Greedy `{name+}` below a `{param}` | small-medium | no | probe only (the IAM service test is heavier): REST API /v1/{kind}/{name+} MOCK GET | `/v1/foo/a/b` gives 403 (no route). Control /v1/lit/{name+} gives 200 |
| 8 | DeleteStack RetainResources | medium | no | probe only: `delete-stack --retain-resources A` | accepted silently; no RetainResources handling in src/main |
The marker is still needed at every site. No leftover containers (`docker ps` clean).

## 3. Floci fix specs (paths under src/main/java/io/github/hectorvent/floci/services/)
1. **Logs message suffix (tiny).** cloudwatch/logs/CloudWatchLogsService.java: every `"The specified log group does not exist: " + name` (l.322, 410, 420, …) and `"The specified log stream does not exist: " + name` (l.533, 690, 725). Expected: the exact AWS text "The specified log group does not exist." / "The specified log stream does not exist." with no name appended, ResourceNotFoundException, HTTP 400. Ref: https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_PutLogEvents.html (Errors: ResourceNotFoundException) and https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/CommonErrors.html
9. **PutLogEvents missing group (tiny).** CloudWatchLogsService.putLogEventsForAccount (l.684): look up the group first. Missing group: "The specified log group does not exist." Group present but stream missing: the stream message. Ref: API_PutLogEvents.html (same as above).
2. **Retained-message epoch ms (tiny).** iot/IotDataController.putEpoch (l.190), used at l.166 (GetRetainedMessage) and l.182 (ListRetainedMessages): write `instant.toEpochMilli()` as a whole-number long, not `toEpochMilli()/1000.0`. Ref: https://docs.aws.amazon.com/iot/latest/apireference/API_iotdata_GetRetainedMessage.html ("lastModifiedTime: The Epoch date and time, in milliseconds", Type Long) and API_iotdata_ListRetainedMessages.html
3. **Scope refusal 401 (tiny).** apigateway/CognitoUserPoolAuthorizer.authorize (l.63-74 returns Failure.ACCESS_DENIED when no method scope matches) and ApiGatewayExecuteController (l.1025-1026 maps it to ACCESS_DENIED/403). Expected: a valid access token with no matching scope gives gateway response UNAUTHORIZED, 401 `{"message":"Unauthorized"}`. Ref: https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-enable-cognito-user-pool.html ("Otherwise, the call fails with a 401 Unauthorized response") and https://docs.aws.amazon.com/apigateway/latest/developerguide/supported-gateway-response-types.html
4. **UpdateThing merge (small).** iot/IotController (l.116, parseAttributes ignores `attributePayload.merge`) and IotService.updateThing (l.294 `thing.setAttributes(attributes)`). Expected: with merge=true, merge into the existing attributes, where an empty-string value removes that attribute. With merge=false or absent, replace. Ref: https://docs.aws.amazon.com/iot/latest/apireference/API_UpdateThing.html and https://docs.aws.amazon.com/iot/latest/apireference/API_AttributePayload.html
5. **Usage plan apiStages (small).** apigateway/ApiGatewayController.toUsagePlanNode (l.2459) leaves out `apiStages`, which the model already stores (UsagePlan.java:17, ApiGatewayService.java:1516). Expected: CreateUsagePlan, GetUsagePlan and GetUsagePlans return `apiStages: [{apiId, stage, throttle?}]`, and GetUsagePlans honours `keyId`. Ref: https://docs.aws.amazon.com/apigateway/latest/api/API_UsagePlan.html and https://docs.aws.amazon.com/apigateway/latest/api/API_GetUsagePlans.html
6. **Data-plane Publish to MQTT (small).** iot/IotService.publish(topic, payload, retain, qos, region, clientId, ruleRunner) (l.1147-1163) only calls handlePublish (rules). Expected: also call `mqttBrokerService.publish(topic, payload)` the way publishShadowEvent (l.1119-1122) does, so subscribed MQTT clients receive HTTP-published messages, honouring qos and retain. Ref: https://docs.aws.amazon.com/iot/latest/apireference/API_iotdata_Publish.html and https://docs.aws.amazon.com/iot/latest/developerguide/http.html
7. **Greedy below a path parameter (small-medium).** apigateway/ApiGatewayExecuteController.matchResources (~l.4232-4260) and greedyParentPrefix (l.4312) compare a literal prefix that keeps `{kind}`. Expected: match the parent segments as a template (literal or `{param}`), bind `kind`, and give the rest to `name+`; the most specific match wins. Ref: https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-method-settings-method-request.html (greedy path variable `{proxy+}`)
8. **DeleteStack RetainResources (medium).** cloudformation/CloudFormationQueryHandler.deleteStack (l.182+) and the stack delete path. Expected: accept `RetainResources.member.N`. It applies only to a stack in DELETE_FAILED: the named logical resources are kept, the others are deleted, and the stack ends in DELETE_COMPLETE. On a stack in any other state the parameter is rejected or ignored, as AWS does. Ref: https://docs.aws.amazon.com/AWSCloudFormation/latest/APIReference/API_DeleteStack.html
