# Code review (delta): PR #1252 "build: machine-setup check-mode gap, arm64 binfmt, restore-script parity"

- Reviewer: code-reviewer (read-only). 2026-10-23 14:46 UTC+2. `df -h /`: 91G free (30%).
- Range: 901ae3ed..57708cedab36279b101010a98ab1d6a254dad01d. The head is unchanged.
- Commits: ba062a7a (merge of #1248@36292726), f053fc58, 6ee90a10, e2b9a5db, 4a0628b3, 57708ced. Logic reviewed as `git diff ba062a7a..57708ced`; the #1248 part was already reviewed in Delta 3.
- Titles: the PR title and all commit subjects use `build:`/`docs(grokbot):` with no W-/T- prefix.

## Gates (CONVENTIONS §1)
- Own runs: `shellcheck -x` rc=0 and `bash -n` rc=0 on the head script.
- `--check` on the real script (temp worktree, removed afterwards): rc=0, changes=0 would-change=0. No apply was run, and binfmt_misc was only read. No containers were stopped.
- Gate logs in machine-setup/1251/r5-*:
  - poll waited until IDLE (0 running containers).
  - check-before: would-change=1, the iptables-legacy IPv4+IPv6 step, so --check correctly reported pending.
  - run: changes=1, failed=0.
  - check-after: changes=0 would-change=0.
  - verify: arm64 alpine runs (aarch64), DNS resolves, true-rc=0, checkrc=0.
  - All green.

## Verification items
1. Delta-3 Low (chown before mv): FIXED. machine-setup.sh:276-279 now does mv, then `sudo chown -R root:root /usr/local/go.new`. In addition, `cleanup()` falls back to `sudo rm -rf "$WORK"`.
2. backup() sudo existence check: OK. Lines 122-129 use `sudo test -e` and `sudo cp -pL`, so files in root-only directories (/etc/docker) are detected and backed up. `cp -p` as root keeps the user's ownership for user files.
3. STAMP includes PID: OK. `STAMP=$(date +%Y%m%dT%H%M%S)-$$` (line 34). Names stay time-sortable for pruning.
4. EXIT trap restarts dockerd: OK.
   - `$WORK/dockerd-stopped` is written by apply_ipt_alt and apply_ipt_legacy when they stop dockerd. It is a file, so it works across the step subshells.
   - cleanup restarts dockerd only if the marker exists and dockerd is not running.
   - The marker is removed once dockerd is up or when the alt-switch rollback restarts it.
   - Subshells do not inherit the EXIT trap, so a step subshell cannot remove $WORK early.
5. IPv6 legacy per-family rollback: OK.
   - legacy_tools covers iptables-legacy and ip6tables-legacy.
   - There is one backup per family (`<tool>.$STAMP.rules`, mode 600) and one UNDO line per family.
   - The cleanup is per family, and on failure every saved family is restored with its own `-restore`.
   - Any backup failure aborts before anything is changed.
6. Fail-closed listing: OK.
   - docker_user_custom checks both families with `-w 10`. A missing chain counts as default, and any other listing error counts as custom.
   - legacy_docker_state reports `listing failed` as state, so check stays pending (exit 3) and apply exits 1 before any cleanup.
   - A stubbed harness confirmed it: lock error gives custom/pending, no chain gives default, default rules give default, custom rules give custom.
7. arm64 binfmt handler restored on undo: OK.
   - When a previous registration existed, the UNDO line unregisters, re-registers the old `binfmt_register_line` string, and re-disables it if it was disabled.
   - Round-trip harness: the real /proc entry was read only, and the UNDO was evaluated against a temp dir with sudo stubbed. The re-register string equals the original byte for byte, and it writes `0` when old_disabled=1.
   - The failure path still uses binfmt_restore.

Also reviewed and fine:
- dnsmasq identity is checked by `/proc/<pid>/exe` = /usr/sbin/dnsmasq and the owner uid (root/nobody/dnsmasq).
- The package dnsmasq restart uses a fixed command (init.d or `dnsmasq -x pidfile`), no longer a replayed cmdline. This also removes my Delta-3 mapfile Info.
- `.profile` gets a newline guard.
- start_dnsmasq logs diagnostics on timeout.
- check_ipt_legacy is pending in --check whenever the docker engine is not installed yet.
- Earlier fixes M1, L1, M2 and L2: no regressions. The SC2024 disable is kept on the per-family save.

## Findings
- [Info] [non-testable] machine-setup/1251/r5-*.log — the logs do not record the script sha they ran. The timestamps (14:43 UTC+2) fit 57708ced, but the evidence would be stronger with `git rev-parse HEAD` in the log.
- [Info] [hard-to-test] machine-setup.sh, apply_ipt_alt plus the legacy step — after a successful nft switch where check_ipt_legacy is already clean, dockerd stays stopped until the later dockerd step starts it. The EXIT trap covers an abort in between, so this is correct. It is noted only because dockerd is down for several steps.

## Verdict: APPROVED at 57708ced

---
## Delta 4: 57708ced..8cac9d1d

Head confirmed: 8cac9d1dfe8b839e4391feed6bc68decbcbf1526 (not moved). The diff is scripts/grokbot/machine-setup.sh only (+4/-3).

- soft_step --check WARN text changed: "run make build, then rerun this script to link it". The line still returns 0, so a missing optional step is still a warning, not pending, and does not change exit 3.
- soft_step apply-failure WARN text changed: it adds "rerun this script to link it into ~/.local/bin". restore_backups and the function's return status are unchanged.
- The comment above `soft_step cbdeploy` gained two lines.
- No control-flow, condition, exit-code or trap change. Only string literals and comments changed.
- bash -n: OK. shellcheck -x in a clean worktree at 8cac9d1d: rc=0, no warnings.
- I did not run the script, not even --check. It is not needed for a string-only change, and skipping it avoids touching docker, binfmt or the floci containers.
- New commit subject `build: tell users to rerun setup after make build to link cbdeploy` and the PR title `build: machine-setup check-mode gap, arm64 binfmt, restore-script parity`: no W-/T- prefix.

### Findings
- [Info] The wording says "link", but apply_cbdeploy runs `make install` into $GOBIN_DIR. That is accurate only if GOBIN_DIR is, or links to, ~/.local/bin. It is cosmetic and non-blocking.

## Verdict: APPROVED at 8cac9d1d

## Delta 5 (8cac9d1d..e4155eb0, merge of origin/main) — CHANGES_REQUESTED (CI pending; code is clean)

Head confirmed e4155eb0 (did not move). Merge parents: 8cac9d1d and 865f50cc. origin/main is 865f50cc and equals the merge base, so the branch is fully up to date. `df -h /` showed 33% used.

Verified
- `git diff 8cac9d1d e4155eb0 -- GROKBOT.md scripts/grokbot/` is empty. The `git ls-tree` blob lists (3 entries) are byte-identical.
- Three-dot `origin/main...e4155eb0` changes 2 files (GROKBOT.md +13; machine-setup.sh +341/-52 lines). This patch is byte-identical to #1252's own delta `36292726..8cac9d1d`.
- #1248's content is intact. The squash ec00bd89 is an ancestor. GROKBOT.md and scripts/grokbot/ on main are identical to #1248@36292726, so nothing was lost or reverted. The PR tree differs from main only in the 2 files, so nothing unrelated came in.
- Conflict markers: none. The only `=======` match is the AsciiDoc title underline at danfosslh.adoc:2, which is the same on main.
- The script passes `bash -n` and `shellcheck -x` (rc 0).
- Title "build: machine-setup check-mode gap, arm64 binfmt, restore-script parity" and merge subject "build: merge main into machine-setup check gaps" have no W-/T- prefix.

CI on e4155eb0 (checked last at 15:48 UTC+2)
- pass: CodeQL, Analyze (actions), Analyze (javascript-typescript)
- skipping: Cursor Bugbot, Cursor Security Agent, Architecture, Static Analysis, Unit Tests (path-filtered)
- pending: Build (run 39962830365). It started at 15:38 UTC+2 and was still in progress after about 10 minutes.

Findings
- [High] [testable] CI — the Build check is pending on e4155eb0, which blocks approval. Fix: wait for Build to go green. This becomes APPROVED with no code changes once it does, because the tree is identical to the approved 8cac9d1d.

### Delta 5 addendum (15:57 UTC+2) — APPROVED at e4155eb0

Build (run 39962830365) finished completed/success at about 15:57 UTC+2. The head is still e4155eb0. The High CI finding is resolved. No findings remain.

## Delta 6 (e4155eb0..c9f11a29) — APPROVED

Head confirmed c9f11a29 (re-fetched at 16:31 UTC+2; it did not move). One commit, "build: match dnsmasq after in-place upgrade", touching only machine-setup.sh (+5/-1). `df -h /` showed 32% used.

Verified
- machine-setup.sh:218 `is_dnsmasq_exe` uses `[ "$1" = ... ]` string equality with both values quoted. That is exact and anchored, with no glob or regex. A stub harness (functions extracted, sudo/readlink/stat stubbed) gives these results:
  - match: `/usr/sbin/dnsmasq` and `/usr/sbin/dnsmasq (deleted)`.
  - no match: trailing space, `dnsmasqX`, `(deleted)x`, `*`, `dnsmas?`, `/usr/bin/dnsmasq`, an empty string, readlink failure (vanished pid or EPERM, where stdout is empty and 2>/dev/null hides the error), a wrong pid, a non-numeric pid `42;x`, an empty pid, uid 1000, and a stat failure.
  - All of these fail closed.
- A real kernel check: a deleted running binary's /proc/PID/exe reads `<path> (deleted)`, the exact format matched.
- :221 reads the path with `sudo readlink "/proc/$1/exe"` after the `^[0-9]+$` guard. The owner check at :222-223 (uid root, nobody or dnsmasq) still applies after the exe match.
- Callers when the function returns false:
  - stop_our_dnsmasq (:820-827) and the package-pid kill (:854-856): no kill.
  - dnsmasq_running at :247 and :834: a restart is attempted and, if it fails, it is reported. It does not kill anything.
  - check_dnsmasq_run: the step is reported as pending and apply runs.
  - None of these kill a wrong PID. The new match removes the false negative where an upgraded, still-running server was treated as absent, which used to cause a second start and a bind conflict on :53.
- Distro paths: the box is Debian 13 (trixie) and only /usr/sbin/dnsmasq exists. The fixed path matches APT_PKGS on Debian/Ubuntu and is deliberate.
- `bash -n` OK and `shellcheck -x` rc 0 on the c9f11a29 script. The commit subject has no W-/T- prefix.

CI on c9f11a29 (16:31 UTC+2)
- pass: Build, CodeQL, Analyze (actions), Analyze (javascript-typescript)
- skipping: Architecture, Cursor Bugbot, Cursor Security Agent, Static Analysis, Unit Tests
- Build was pending from about 16:10 and passed at about 16:31.

Findings
- [Info] [non-testable] machine-setup.sh:218 — `(deleted)` matches any unlinked binary that once lived at /usr/sbin/dnsmasq, not only the upgraded package. Only root can write there, and the uid check still applies, so this is acceptable.
- [Info] [testable] machine-setup.sh:221 — `sudo readlink` has no `-n`. Without passwordless sudo it could prompt. This predates the PR, and on the box it fails closed anyway because stderr is hidden. Fix (optional): `sudo -n`.

## Delta 7+8 (c9f11a29..17c16b3c) — APPROVED

The scope moved mid-review: the head went from 09bef205 to 17c16b3c, and I reviewed both commits. I re-fetched at 17:10 UTC+2 and the head was unchanged.
- 09bef205 "build: keep dockerd recovery marker until restart succeeds" changes machine-setup.sh +2/-1.
- 17c16b3c "build: detect stale node link before install in check mode" changes machine-setup.sh +5/-3.

Neither subject has a W-/T- prefix. `df -h /` showed 21% used.

Delta 7: dockerd-stopped marker (machine-setup.sh:541)
- `{ start_dockerd && rm -f marker; } || true` removes the marker only when the start succeeds.
  - The `&&` list is exempt from errexit and `|| true` absorbs it. `return 1` always follows, so the step still fails and its backups are restored. The if does not mask anything.
  - The other marker writers and removers (:531, :601, :605, :626, :629) are unchanged.
- Trap (:141-146, :150): `cleanup` runs once on EXIT. Bash does not re-run an EXIT trap while it is already handling one, and cleanup does not call exit. `start_dockerd || log FAIL` cannot recurse.
  - The restart is bounded: 30 tries of `docker info` with 1s sleeps.
- Stub harness (sudo, pgrep and sleep stubbed, no real docker), counting dockerd starts:
  - rollback restart OK: marker removed, trap does nothing, 1 start in total.
  - rollback fails: marker kept, trap retries once, 2 starts.
  - rollback fails and the trap fails too: FAIL is logged, the run exits normally, 2 starts, no loop.
  - rollback fails but dockerd comes up later: the trap's `pgrep -x dockerd` skips it, 1 start (no double start).
  - The step rc is 1 in every rollback case.

Delta 8: link_points_to (:412) and check_links (:403-411)
- `[ "$(readlink "$LOCAL_BIN/name" 2>/dev/null)" = "target" ]`. It uses a raw readlink, not -f, and all expansions are quoted. The harness used a LOCAL_BIN and a target that both contain spaces.
- Harness (temp dir, step/check_links/apply_links extracted). Each scenario with the check result, then the apply result:

| Scenario | --check | apply |
|---|---|---|
| correct link | rc 0 | no change |
| missing link | pending, exit 3 | fixed |
| regular file | pending, exit 3 | replaced with the link |
| wrong target (previous Node) | pending, exit 3 | relinked |
| dangling link | pending, exit 3 | fixed |
| relative link to the right file | pending, exit 3 | rewritten absolute |

- After apply, --check gives rc 0.
- Target not installed yet: with PENDING=0 it is skipped (rc 0). With PENDING>0, a wrong or missing link is pending (the new behaviour). A link already pointing exactly at the future target is not counted.
- `bash -n` OK and `shellcheck -x` rc 0 on 17c16b3c.

CI on 17c16b3c (17:10 UTC+2)
- pass: Build (it passed at about 17:10 after about 20 minutes pending), CodeQL, Analyze (actions), Analyze (javascript-typescript)
- skipping: Architecture, Cursor Bugbot, Cursor Security Agent, Static Analysis, Unit Tests

Findings
- [Info] [testable] machine-setup.sh:412 — a relative link that resolves to the right file counts as pending, because the raw readlink compares strings. Apply rewrites it to an absolute path and then it is stable, so this is acceptable. Fix (optional): compare with `readlink -f` on both sides.
- [Info] [hard-to-test] machine-setup.sh:202 — `sudo docker info` has no per-call timeout. A hung daemon socket could stall the EXIT trap beyond 30s. This predates the PR. Fix (optional): `timeout 5 sudo docker info`.

## Delta 9 (17c16b3c..e1bc4ca7, static only) — CHANGES_REQUESTED (gate: Build skipped; code is clean)

Head confirmed e1bc4ca7 (did not move). Three commits, all machine-setup.sh:
- 0a27dcbd "build: skip missing optional binaries in link prediction"
- 1d81ffbc "build: set dockerd marker before stop"
- e1bc4ca7 "build: resolve relative node links, bound docker info wait"

No W-/T- prefixes. Per Mario's 17:10 rule this review is static only, plus `bash -n` (OK) and `shellcheck -x` (rc 0). No harness was run. `df -h /` showed 27% used.

0a27dcbd (check_links :403-411, OPTIONAL_LINKS :415)
- The skip applies only when the target is missing and the name is in `OPTIONAL_LINKS=" cbdeploy "`. The match is space-delimited and exact (`*" name "*`), so `cbdeploy` does not match `cbgenerate` or any other prefix.
- cbdeploy is the only soft_step (:356). Required binaries (cbgenerate, the go tools, node/pnpm) still predict pending.
- An optional binary whose target does exist is still link-checked. This does not hide a required binary.

1d81ffbc (apply_ipt_alt :533-541), reasoned against Delta 7
- The marker is written only inside `if pgrep -x dockerd`, after the running-containers guard. A dockerd the user stopped on purpose never gets a marker, so the exit trap never starts it.
- If stop_dockerd fails (dockerd still up after 30s), the step returns 1 with the marker present. The trap's `! pgrep -x dockerd` sees dockerd running and does nothing.
- If dockerd dies after the 30s window, the trap restarts it. That is correct, because this run sent the kill.
- On a stop failure step() exits the run, so the legacy step's `[ -e marker ] && was_running=1` (:605) cannot misread it.
- Delta 7's `start_dockerd && rm` is unchanged. No double start.

e1bc4ca7
- link_points_to (:418) is `[ -L link ] && [ "$(readlink -m link)" = "$(readlink -m target)" ]`.
  - Both sides are fully canonicalized: relative targets are resolved against the link's directory, `..` is collapsed, and symlinked dirs (including LOCAL_BIN itself) are followed. Quoting is complete.
  - `-L` excludes a regular file. A dangling link compares by its canonical path. A link to an intermediate symlink (such as a `current` dir) counts as correct only if it ends at the same file.
  - This resolves my Delta 7+8 Info.
- start_dockerd (:202) is `sudo timeout 5 docker info`. Exit 124 (or any nonzero) fails the `&&`, then `sleep 1` and the next try. There is no special 124 handling, and none is needed.

CI on e1bc4ca7 (17:14 UTC+2)
- pass: CodeQL, Analyze (actions), Analyze (javascript-typescript)
- skipped: Build, Unit Tests (run 39976359356), Architecture, Static Analysis
- neutral: Cursor Bugbot, Cursor Security Agent
- The Build job is gated on the `build` label (build.yml:56-58). Mario removed that label at 17:09:45 UTC+2, which fits the no-extra-runs rule, so Build did not run on this head. The last green Build was on 17c16b3c.

Findings
- [High] [testable] CI — Build was skipped on e1bc4ca7 (the `build` label was removed). A skipped gate blocks approval under the review rules. Fix: re-add the `build` label and get a green Build, or have Mario explicitly waive it. The code needs no changes. This becomes APPROVED once either happens.
- [Low] [testable] machine-setup.sh:202-203 — with `timeout 5` each try can take up to 6s, so the wait can last about 180s, but the message still says "did not answer in 30s". The timeout sits inside sudo, so it does not bound a sudo password prompt. Fix: count elapsed time (or 30 tries total) and correct the message. `timeout 5 sudo -n docker info` would also bound sudo.

## Delta 10 (e1bc4ca7..0a30f39f, static only) — FINAL: APPROVED at 0a30f39f

Head confirmed 0a30f39f (did not move). One commit, "build: restore iptables alternatives before dockerd on cleanup rollback", changing machine-setup.sh +12/-2. No W-/T- prefix. `bash -n` OK and `shellcheck -x` rc 0. No stub runs. `df -h /` showed 20% used.

Build gate WAIVED: Mario removed the `build` label himself and ruled no extra test runs. So the skipped Build and Unit Tests on 0a30f39f do not block, and the Delta 9 High is closed by this waiver.

Verified
- Capture (:532-533): `ORIG_IPT4/6=$(readlink /etc/alternatives/ip{,6}tables 2>/dev/null || true)`. It uses readlink, not `--query`. A missing alternative (for example no ip6tables) gives an empty value.
  - The capture runs once at script scope, after the apt and docker-engine installs (:267, :495), which may create the alternatives on a fresh box, and before the only step that switches them, apply_ipt_alt (:562).
  - In --check it is a read-only readlink, with no side effects.
- restore_ipt_alternatives (:534-537):
  - An empty value skips the restore.
  - If the alternative already points at the saved path it is a no-op. On a rerun where the box is already on nft, ORIG is nft, so nothing changes.
  - Otherwise it runs `sudo update-alternatives --set iptables "$ORIG_IPT4"` (quoted), with `|| log FAIL`. Each line is an `||` chain, so it cannot trip errexit in the ( set -e ) subshell and it returns 0.
  - The failure path still ends in `return 1`, so the original failure is not masked.
- Ordering in the apply_ipt_legacy failure path (:637-647): saved legacy rules are restored first, then the alternatives, then start_dockerd, then the marker is cleared only if dockerd is up. dockerd comes back on the backend its rules belong to.
- Other paths:
  - The apply_ipt_alt rollback already restores old4/old6, which are now initialised from ORIG and hold the same values, because nothing between the capture and the switch touches the alternatives.
  - The success path keeps nft by design. No other path needs the restore.
- Copilot thread PRRT_kwDOQ12eZc6vqOjE (comment 4361115403, :645, taken to be cto-165) covers this case: a legacy-cleanup failure after a successful switch restarted dockerd on nft with the restored legacy FORWARD DROP. The commit fixes it. The thread is resolved and Mario replied at 17:41 UTC+2. The older thread PRRT_kwDOQ12eZc6vjl8x (7b1de8c3) is resolved and outdated.

CI on 0a30f39f (about 17:44 UTC+2)
- pass: CodeQL, Analyze (actions), Analyze (javascript-typescript)
- skipped: Build (waived), Unit Tests, Architecture, Static Analysis
- neutral: Cursor Bugbot, Cursor Security Agent
- in progress: copilot-pull-request-reviewer (a reviewer bot, not a gate)
- None red.

Findings
- [Low] [testable] machine-setup.sh:202-203 — Delta 9 L1 is still open: the message says 30s but the wait can last about 180s, and `sudo timeout` does not bound a sudo prompt. Non-blocking. Fix: track elapsed time and use `timeout 5 sudo -n docker info`.
- [Info] [non-testable] machine-setup.sh:540 — if the iptables alternative did not exist at capture time, old4 is empty, so the UNDO log line and the `--set iptables ""` rollback are meaningless. The rollback is guarded by `|| true`, so this is harmless. Fix (optional): skip the restore when old4 is empty, as restore_ipt_alternatives already does.
- [Info] Copilot has not finished reviewing 0a30f39f.

## Delta 11 — 0a30f39f..f234681a (+6/-2) — 2026-10-23 17:50 UTC+2
**Head is f234681a, confirmed; it has not moved.** Commit: "build: restore iptables alternatives before exit-trap dockerd restart". It has no W-/T- prefix, and no plan IDs appear in the code. bash -n: OK. shellcheck -x: clean, exit 0. Static review only, per Mario's 17:10 rule.
CI on f234681a: Build skipped (waived). Architecture, Static Analysis and Unit Tests skipped (path-filtered, not red). Analyze (actions) success. Analyze (js-ts) success. CodeQL success. Bugbot neutral. Security Agent neutral. Copilot review in progress.

What I verified:
- The restore only runs when the marker is present AND dockerd is down. It runs before start_dockerd, as claimed.
- An intended nft switch on a successful run is never reverted. The marker can survive a successful run: if check_ipt_legacy passes, apply_ipt_legacy never runs, so :650/:653 never remove it. But the dockerd step (:670) guarantees dockerd is up, and the daemon-DNS step (:927-932) either restarts it or returns 1. A run that exits 0 therefore always has dockerd running, cleanup's condition is false, and no restore happens.
- An early exit before the capture at :536 is safe. The marker can't exist yet, and ${ORIG_IPT4:-} is empty, so the restore is skipped and there is no set -u abort.
- A double restore with the :637-653 failure path is idempotent. The equality check makes it a no-op, and the trap only re-tries if start_dockerd failed.
- A failing restore cannot abort the restart. Each line ends in `|| log FAIL`, so the function returns 0 and start_dockerd still runs.

Findings:
- [Low] [non-testable] scripts/grokbot/machine-setup.sh:141 — the new comment says the marker "only survives a failed run". That is wrong: after a successful nft switch, when the legacy check passes, the marker stays until rm -rf $WORK. This is harmless today only because dockerd is always up by exit. Fix: reword the comment, or rm -f the marker once the dockerd step succeeds.
- [Low] [hard-to-test] machine-setup.sh:145 with :927-932 — if the daemon-DNS restart fails after a successful switch, the trap puts the alternatives back to legacy and starts dockerd there. That undoes the earlier step's switch. It works, because the legacy tables were cleaned, and a rerun switches again. Fix: optional; clear the marker after the dockerd step.
- [Low] (carried over from Delta 9 L1) start_dockerd message says "30s" — still open.

**Verdict: APPROVED** (sha f234681a). Nothing blocks.
