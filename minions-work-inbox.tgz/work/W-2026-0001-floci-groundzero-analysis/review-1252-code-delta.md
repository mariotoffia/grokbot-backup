# Code review (delta): PR #1252 "build: machine-setup check-mode gap, arm64 binfmt, restore-script parity"

- Reviewer: code-reviewer (read-only). 2026-10-23 14:46 UTC+2. `df -h /`: 91G free (30%).
- Range: 901ae3ed..57708cedab36279b101010a98ab1d6a254dad01d. The head is unchanged.
- Commits: ba062a7a (merge of #1248@36292726), f053fc58, 6ee90a10, e2b9a5db, 4a0628b3, 57708ced. Logic reviewed as `git diff ba062a7a..57708ced`; the #1248 part was already reviewed in Delta 3.
- Titles: the PR title and all commit subjects use `build:`/`docs(grokbot):` with no W-/T- prefix.

## Gates (CONVENTIONS §1)
- Own runs: `shellcheck -x` rc=0 and `bash -n` rc=0 on the head script.
- `--check` on the real script (temp worktree, removed afterwards): rc=0, changes=0 would-change=0. No apply was run, and binfmt_misc was only read. No containers were stopped.
- Gate logs in machine-setup/1251/r5-*:
  - poll waited until IDLE (0 running containers).
  - check-before: would-change=1, the iptables-legacy IPv4+IPv6 step, so --check correctly reported pending.
  - run: changes=1, failed=0.
  - check-after: changes=0 would-change=0.
  - verify: arm64 alpine runs (aarch64), DNS resolves, true-rc=0, checkrc=0.
  - All green.

## Verification items
1. Delta-3 Low (chown before mv): FIXED. machine-setup.sh:276-279 now does mv, then `sudo chown -R root:root /usr/local/go.new`. In addition, `cleanup()` falls back to `sudo rm -rf "$WORK"`.
2. backup() sudo existence check: OK. Lines 122-129 use `sudo test -e` and `sudo cp -pL`, so files in root-only directories (/etc/docker) are detected and backed up. `cp -p` as root keeps the user's ownership for user files.
3. STAMP includes PID: OK. `STAMP=$(date +%Y%m%dT%H%M%S)-$$` (line 34). Names stay time-sortable for pruning.
4. EXIT trap restarts dockerd: OK.
   - `$WORK/dockerd-stopped` is written by apply_ipt_alt and apply_ipt_legacy when they stop dockerd. It is a file, so it works across the step subshells.
   - cleanup restarts dockerd only if the marker exists and dockerd is not running.
   - The marker is removed once dockerd is up or when the alt-switch rollback restarts it.
   - Subshells do not inherit the EXIT trap, so a step subshell cannot remove $WORK early.
5. IPv6 legacy per-family rollback: OK.
   - legacy_tools covers iptables-legacy and ip6tables-legacy.
   - There is one backup per family (`<tool>.$STAMP.rules`, mode 600) and one UNDO line per family.
   - The cleanup is per family, and on failure every saved family is restored with its own `-restore`.
   - Any backup failure aborts before anything is changed.
6. Fail-closed listing: OK.
   - docker_user_custom checks both families with `-w 10`. A missing chain counts as default, and any other listing error counts as custom.
   - legacy_docker_state reports `listing failed` as state, so check stays pending (exit 3) and apply exits 1 before any cleanup.
   - A stubbed harness confirmed it: lock error gives custom/pending, no chain gives default, default rules give default, custom rules give custom.
7. arm64 binfmt handler restored on undo: OK.
   - When a previous registration existed, the UNDO line unregisters, re-registers the old `binfmt_register_line` string, and re-disables it if it was disabled.
   - Round-trip harness: the real /proc entry was read only, and the UNDO was evaluated against a temp dir with sudo stubbed. The re-register string equals the original byte for byte, and it writes `0` when old_disabled=1.
   - The failure path still uses binfmt_restore.

Also reviewed and fine:
- dnsmasq identity is checked by `/proc/<pid>/exe` = /usr/sbin/dnsmasq and the owner uid (root/nobody/dnsmasq).
- The package dnsmasq restart uses a fixed command (init.d or `dnsmasq -x pidfile`), no longer a replayed cmdline. This also removes my Delta-3 mapfile Info.
- `.profile` gets a newline guard.
- start_dnsmasq logs diagnostics on timeout.
- check_ipt_legacy is pending in --check whenever the docker engine is not installed yet.
- Earlier fixes M1, L1, M2 and L2: no regressions. The SC2024 disable is kept on the per-family save.

## Findings
- [Info] [non-testable] machine-setup/1251/r5-*.log — the logs do not record the script sha they ran. The timestamps (14:43 UTC+2) fit 57708ced, but the evidence would be stronger with `git rev-parse HEAD` in the log.
- [Info] [hard-to-test] machine-setup.sh, apply_ipt_alt plus the legacy step — after a successful nft switch where check_ipt_legacy is already clean, dockerd stays stopped until the later dockerd step starts it. The EXIT trap covers an abort in between, so this is correct. It is noted only because dockerd is down for several steps.

## Verdict: APPROVED at 57708ced

---
## Delta 4: 57708ced..8cac9d1d

Head confirmed: 8cac9d1dfe8b839e4391feed6bc68decbcbf1526 (not moved). The diff is scripts/grokbot/machine-setup.sh only (+4/-3).

- soft_step --check WARN text changed: "run make build, then rerun this script to link it". The line still returns 0, so a missing optional step is still a warning, not pending, and does not change exit 3.
- soft_step apply-failure WARN text changed: it adds "rerun this script to link it into ~/.local/bin". restore_backups and the function's return status are unchanged.
- The comment above `soft_step cbdeploy` gained two lines.
- No control-flow, condition, exit-code or trap change. Only string literals and comments changed.
- bash -n: OK. shellcheck -x in a clean worktree at 8cac9d1d: rc=0, no warnings.
- I did not run the script, not even --check. It is not needed for a string-only change, and skipping it avoids touching docker, binfmt or the floci containers.
- New commit subject `build: tell users to rerun setup after make build to link cbdeploy` and the PR title `build: machine-setup check-mode gap, arm64 binfmt, restore-script parity`: no W-/T- prefix.

### Findings
- [Info] The wording says "link", but apply_cbdeploy runs `make install` into $GOBIN_DIR. That is accurate only if GOBIN_DIR is, or links to, ~/.local/bin. It is cosmetic and non-blocking.

## Verdict: APPROVED at 8cac9d1d
