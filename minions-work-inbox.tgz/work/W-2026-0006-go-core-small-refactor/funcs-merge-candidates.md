# W-2026-0006 go-core.small-refactor — funcs.merge candidates
Snapshot: origin/main (git archive). cbanalytics, devicesvc, go-services excluded. Call-site counts = non-test lines in go-core (repo-wide count in brackets, via `git grep origin/main`). Ranked easiest + most valuable first. No code changed.
Note: `go-core/utils/UPDATE_TASKS.md` already lists some stdlib swaps (e.g. SortCompare); check it before implementing to avoid double work.

| # | Functions | Why same | Minimal change | Call sites | Semantic diffs | Risk |
|---|---|---|---|---|---|---|
| 1 | `textutils.ParseDateTime` utils/textutils/datetime.go:19 vs `timeutils.ParseDateTime` utils/timeutils/parse.go:19 | Bodies byte-identical (diffed) | Keep timeutils; textutils becomes a one-line forwarder (or remove, switching cmdutils/mulitvalue.go:221) | 1 + 1 (repo: 2) | none | none |
| 2 | `httputil.HasHttpSchemePrefix`/`OnlyDNSName` utils/httputil/utils.go:6,11 vs `httpauth.*` utils/httputil/httpauth/utils.go:6,10 | Byte-identical; httpauth copy exists only so httpauth avoids importing its parent | Keep httpauth (leaf); httputil versions forward to it — no new cycle (httputil already imports httpauth) | go-core 2 (repo 6 + 4, 5 files outside go-core unaffected by forwarders) | none | none |
| 3 | `utils.RandomStringAZ/RandomString/RandomInt/RandomPostfix/GenerateSimpleID` utils/idutil.go:14-87 vs same names in `idutils` utils/idutils/id.go:14-51 | Byte-identical | Keep idutils (dedicated pkg, 103 refs repo-wide); utils versions become forwarders. **Exclude GenerateID** (see diffs) | utils.* 21 non-test (≈156 incl. tests); forwarders → 0 call-site edits | none for these five | none |
| 4 | `utils.SortCompare` utils/string.go:5 | Re-implements `strings.Compare` (same -1/0/1 contract) | Body → `return strings.Compare(a, b)` (or replace callers, 1 outside go-core) | 2 go-core (repo 5) | none | none |
| 5 | `fexp.FirstFunc` utils/fexp/slice.go:351 vs `fexp.Find` slice.go:286 | Identical: first match else zero T | FirstFunc → `return Find(s, f)` (keep exported for 1 external user) | 0 go-core (repo 1) | none | none |
| 6 | `utils.ShallowCopyMap` utils/copy.go:8 + `ShallowCopyStringMap` copy.go:23 | Same loop, differ only by value type | Add unexported `shallowCopy[V any](dst, src map[string]V)` and make both one-liners; do **not** swap to bare `maps.Copy` | 12 + 17 (all in go-core) unchanged | nil target must still allocate (maps.Copy panics on nil dst) | none if nil branch kept |
| 7 | `utils.RandIntInRange` utils/rand.go:10 vs `utils.RandomInt` idutil.go:36 | Same crypto/rand Int; RandIntInRange is inclusive max | `return RandomInt(min, max+1)` | 1 internal (RandomizeValue), 0 external | inclusive vs exclusive bound — handled by +1 | low |
| 8 | `utils.Round32` utils/float.go:24 / `round` float.go:10 | already delegates; private `round` = half-away-from-zero ≈ `math.Round` | Optional: `round` → `int(math.Round(num))` | 3 | identical for finite values; NaN/huge values may differ (int overflow both ways) | low — optional |

## Rejected
- `utils.GenerateID` (uuid.NewUUID = **v1**, fallback "rand-…") vs `idutils.GenerateID` (uuid.New = **v4**, panics on failure): different behaviour, do not merge.
- `fexp.Distinct` vs `templatefunctions.Distinct`: reflection + path-based template func, different contract.
- `fexp.Diff` vs `jsondiffutil.Diff`, `maputils.Merge` vs `templatefunctions.Merge`: same name only.
- `jsonutils.FromMapToObject[T]` vs `cbreflect.FromMapToObject(reflect.Type)`: runtime-type vs generic; merging needs reflection plumbing.
- `fexp.Filter/Map/Find` → `slices`: stdlib has no Filter/Map; `slices.IndexFunc` swap gains little across 48 sites.
- `fexp.Include`/`IfEmpty`, `utils.ToAnySlice`: unused in go-core but used outside; removal = API change, not a merge.

## Overlap with package-isolate-candidates.md
- #3 / #7 touch utils/idutil.go and utils/rand.go; isolate #7–#9 inline helpers from utils/map.go and utils/url.go — different funcs, same `utils` root pkg; no conflict.
- #2 touches utils/httputil/utils.go; isolate #3 touches utils/httputil/auth.go — same pkg, different files.
