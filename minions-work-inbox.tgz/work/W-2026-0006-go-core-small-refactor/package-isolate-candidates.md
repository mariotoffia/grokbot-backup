# W-2026-0006 go-core.small-refactor — package.isolate candidates
Analysed origin/main (`git archive` snapshot, 240 pkgs, 1208 internal non-test edges). cbanalytics, devicesvc, go-services excluded. Ranked easiest + most valuable first. No code changed.

| # | Edge removed | Why unneeded | Minimal change | Files / call sites | Risk | Cycle |
|---|---|---|---|---|---|---|
| 1 | model/rtc -> provider/providerutils | Only `StandardPipeSource(bool)` (12-line pure map builder; deps only on ifprovider consts, which rtc already imports) | Move `StandardPipeSource` to `model/providermodel` (or a tiny unexported copy in rtc); keep a forwarding func in providerutils | 3 files in model/rtc (overrides_*.go), 4 call sites total | none (pure fn) | **breaks model<->provider** |
| 2 | utils/queueutils -> managers/mgrqueue, awsmgrqueue, dynamodbqueue | queueutils is a factory/selector (`selector.go`), not a util; no non-test importer in go-core | Move `selector.go` into `managers/mgrqueue/qselect` (or mgrqueue subpkg); leave URL parsing (`sqsurl.go`) in queueutils | 1 file, 6 refs; importers outside go-core must update import path | none (move only) | **breaks utils->managers (part)** |
| 3 | utils/httputil -> managers/mgrjwt/mgrgojwt | One call `mgrgojwt.New(ctx).DecodeJWTToken` in auth.go:122, only when `decodeAccessToken` set | Add a `TokenDecoder func(ctx, []byte)` option on the handler; the constructor that sets decodeAccessToken passes `mgrgojwt.New(ctx).DecodeJWTToken` from caller side (or default set by callers in managers) | 1 file + the place(s) enabling decodeAccessToken | low (must keep default when flag set) | **breaks utils->managers (rest)**, also removes httputil->cbenv JWT path |
| 4 | utils/testutils/testenv -> managers/mgriam/mgriamcognito, ctx; utils/testutils -> ctx, tkdisp/runtime | Test harness living under utils | Move `utils/testutils` tree to top-level `testutils/` (or `internal/testutils`) — pure path move | importers are *_test.go only; mechanical import rewrite | none (test-only) | **breaks utils<->ctx, utils<->tkdisp, rest of utils->managers** |
| 5 | ctx -> utils/fileutils | Only `FileNameWithoutExtension` = `strings.TrimSuffix(f, filepath.Ext(f))` | Inline the stdlib one-liner in ctxoptions_security.go:215 | 1 file, 1 site | none | reduces ctx->utils |
| 6 | ctx -> utils | Only `utils.ErrorToJSON` (ctxoptions.go:60) | Keep (utils is a leaf: imports only cberror/ifcore/coremodel/jsonutils) — or move ErrorToJSON to `cberror` as `cberror.ToJSON` with forwarder in utils | 1 site in ctx, 6 total | none | with #4/#5 ctx no longer needs utils subtree |
| 7 | managers/mgrqueue/dynamodbqueue -> utils | Only `ExtractFromStringStringToInt64` (10-line strconv helper) | Inline as unexported helper | 1 file, 1 site | none | n/a (managers->utils is fine once #2-#4 done) |
| 8 | managers/mgrqueue/awsitcorequeue -> utils | Only `CreateSchemeURL` | Inline/unexported copy, or leave | 1 site | none | n/a |
| 9 | managers/mgrlog/remotelog -> utils | Only `GetBoolFromContext` (3-line type assert) | Inline `ctx.Value(k).(bool)` | 1 site | none | n/a |

Notes
- Cycles here are directory-level (Go forbids real package cycles). After #1–#4 the top-level utils↔managers/ctx/tkdisp and model↔provider cycles are gone.
- #7–#9 are optional polish; only do them if touching those files anyway.

## Rejected (too big)
- interfaces <-> model: model/* embed ifcore/ifprovider/iftarget types widely (12 pkgs) and interfaces/* use model types in signatures; needs a types split.
- interfaces/ifevent -> cbevent: CloudEvent types used in interface signatures; moving cbevent types into interfaces is a broad rename.
- managers/mgrqueue -> utils/httputil (RoundTripper types): would require moving roundtripper into its own pkg; directionally fine (managers->utils), not worth it.
- tkdisp/* & managers/* -> utils/jsonutils, awsutils: legit downward deps on leaf utils; keep.
- model/providermodel -> interfaces/ifprovider (ParameterTarget used throughout target.go): core of interfaces<->model, not easy.
