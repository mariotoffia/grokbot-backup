# Code review (KISS): PR #1347 @ a6456ae9, full diff vs origin/main

## Verdict: APPROVED, conditional on CI (Unit Tests, Static Analysis, Architecture and Analyze pending)

No High or Medium findings.

## Checked
- **Scope:** 1 commit, 8 go-core/utils files (+24/-120).
- **(a) Behaviour:** every replaced body is identical to its target.
  - `textutils.ParseDateTime` is byte-identical to `timeutils/parse.go` (same layouts; "15:04" is combined with today in local time).
  - `HasHttpSchemePrefix` and `OnlyDNSName` are identical to `httpauth/utils.go:6,10` (case-sensitive, ports kept, path cut).
  - The Random* functions and `GenerateSimpleID` are identical to `idutils/id.go:14-53` (same alphabets, crypto/rand, panic on error, length 6).
  - `strings.Compare` returns exactly the old -1/0/1.
  - `fexp.Find` (slice.go:286) is the same first-match loop and returns the zero value when nothing matches. There is no bool or index in either function.
- **(b) Delete vs forward:** after the delete, there are zero `textutils.ParseDateTime` callers anywhere in the repo; the only hit is a doc line. Every kept forwarder still has a caller:
  - Outside go-core: OnlyDNSName, RandomString, RandomInt, RandomPostfix, SortCompare, FirstFunc.
  - In-package or go-core only: HasHttpSchemePrefix (httputil/auth.go:67, utils.go:50), RandomStringAZ (idutil.go:35), GenerateSimpleID (4 go-core callers).
- **(c) Signatures:** no exported signature changed.
- **(d) Import cycles:** none. timeutils, httpauth and idutils import none of textutils, httputil or utils.
- **Naming:** no W-/T- IDs in the title, commit subject, comments or docs.

## Gates (owner logs fm-*-a6456ae9*)
- gofmt, vet, tidy, lint, go-services build+vet: rc=0. The earlier lint-try1 run (rc=2) is superseded by the final lint run (rc=0).
- go-core test: rc=1. The sole failure is the accepted cbanalytics #1332 test.

## CI on a6456ae9 (gh)
- Pass: CodeQL.
- Pending: Analyze (actions), Analyze (javascript-typescript), Architecture, Static Analysis, Unit Tests.

## Limits
No local build or test run; I relied on the owner gate logs. Caller and cycle checks were done with git grep, not `go list`.

## Delta a6456ae9..bed929d6 (id 1089)

### Verdict: APPROVED, conditional on CI (Unit Tests and Static Analysis pending)

No High or Medium findings.

- **Delta:** 1 commit, bed929d6 "go-core: drop forwarders that only go-core callers used". 5 files (+9/-22): cbprocess/kzfunc_expr_set.go, managers/mgriot/awsmgriot/dsmanager_aws_shadow.go, utils/httputil/auth.go, utils/httputil/utils.go, utils/idutil.go. Only the stated deletes and repoints.
- **Remaining callers:** a whole-repo git grep for `.HasHttpSchemePrefix(`, `.RandomStringAZ(` and `.GenerateSimpleID(` (any qualifier, plus unqualified in httputil and utils) finds only `httpauth.` and `idutils.` calls. There are no remaining callers, so no build break.
- **Repointed calls:** same function bodies as the deleted forwarders, same args (url, 6, none).
- **Import cycles:** none. idutils imports no teos packages; httpauth imports only cberror, ifcore and securitymodel.
- **Kept forwarders:** all have outside callers, matching the PR body. OnlyDNSName (go-services algeno esv/sv e2e and siemens provision), RandomString, RandomInt (cfin/services.go), RandomPostfix (cmd/cblicense), SortCompare (cfin/merge test) and FirstFunc (nodabuilding sv1/query.go).
- **Naming:** the commit subject has no W-/T- IDs.
- **Gates (fm-*-bed929d6*):** gofmt, vet, tidy, lint, lint-arch, go-services build+vet and go-core test all rc=0.
- **CI on bed929d6:**
  - Pass: Architecture, CodeQL, Analyze (actions), Analyze (javascript-typescript).
  - Pending: Unit Tests, Static Analysis.
  - Skipping: Build (label-gated).
- **Limits:** git grep only (no `go list` or local build); I relied on the owner gate logs.
