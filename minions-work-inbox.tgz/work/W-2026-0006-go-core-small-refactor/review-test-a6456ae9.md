== Verdict ==
APPROVED (#1347 @a6456ae9)

== Findings ==
none

== Rationale ==
Every deleted body matches its survivor, so callers see no behaviour change.
- textutils.ParseDateTime -> timeutils.ParseDateTime: the function bodies diff byte-identical, with the same formats, zone handling (now.Location() for time-only) and error text. Exercised through cmdutils (mulitvalue_test) and textutils (IsDateTime). cmdutils, textutils and timeutils pass.
- httputil HasHttpSchemePrefix/OnlyDNSName -> httpauth: identical bodies. httpauth has no own tests, but it is reached through the httputil tests, which pass.
- utils Random*/GenerateSimpleID -> idutils: identical bodies (crypto/rand, panic on error, same alphabets). utils and idutils pass.
- SortCompare -> strings.Compare: the old code used ==/> on strings, which is byte-wise lexicographic, the same order strings.Compare uses. Both return -1/0/1. utils passes.
- FirstFunc -> Find: same loop, and both return the zero T when nothing is found. fexp passes.
- Gates: gofmt, vet, tidy, lint and go-services build-vet all rc=0 (lint-try1 rc=2, a typecheck error, was superseded by the rc=0 rerun at the same sha). go-core test rc=1, and the only failure is cbanalytics TestAPercentileOfEqualLargestFloatsIsThatFloat (#1332, accepted).
- CI: CodeQL passed. Unit Tests, Static Analysis, Architecture and Analyze are pending.
