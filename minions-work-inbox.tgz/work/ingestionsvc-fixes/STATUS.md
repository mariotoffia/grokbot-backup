- 2026-10-24 12:44 ingestionsvc-fixes start: worktree on minion/ingestionsvc-fixes from origin/main 57f73d23
- 2026-10-24 12:46 ingestionsvc-fixes milestone: issue #1274 created (Bug, Medium/Hours, board Incoming); TDD red recorded, fixes applied
- 2026-10-24 12:52 ingestionsvc-fixes milestone: lint/lint-arch/vet/unit green; Floci lock taken, ingestion-service harness starting
- 2026-10-24 12:56 ingestionsvc-fixes milestone: Floci ingestion-service harness PASS (rc=0), lock released; commit f61fdb1a pushed, draft PR #1275 (Closes #1274)
- 2026-10-24 12:56 ingestionsvc-fixes done: make clean-caches rc=0 (df / 21%, inodes 42%); note: a foreign golangci-lint (pid 116965) was running at the time, guard did not stop it
- 2026-10-24 13:07 ingestionsvc-fixes milestone: bounded unmarshal error text (preview limit 200), TDD red->green, lint/lint-arch/vet/unit green
- 2026-10-24 13:07 ingestionsvc-fixes done: follow-up pushed 519d0297 to PR #1275 (draft)
- 2026-10-24 13:09 test-reviewer start: review PR 1275 tests @519d0297
2026-10-24 13:12 CEST code-reviewer: #1275 review CHANGES_REQUESTED at 519d0297 (M-1 docs sync with #1271)
- 2026-10-24 13:13 test-reviewer done: PR 1275 tests @519d0297 — CHANGES_REQUESTED
- 2026-10-24 13:19 ingestionsvc-fixes milestone: code review — SetBuildingID cause wrapped, 2801 comment fixed, unit-test label added (16da889b)
- 2026-10-24 13:19 ingestionsvc-fixes milestone: test review — cause guard, chain/%v/%+v tests, schema boundaries, stack expiration helper test; 5/5 mutations killed; no S3 max (no official limit)
- 2026-10-24 13:19 ingestionsvc-fixes done: pushed d3b19061 to PR #1275 (draft); gates green
- 2026-10-24 13:21 test-reviewer start: delta 1 review PR 1275 tests 519d0297..d3b19061
- 2026-10-24 13:22 test-reviewer done: delta 1 PR 1275 tests @d3b19061 — APPROVED
- 2026-10-24 13:28 code-reviewer done: PR #1275 Delta 1 @d3b19061 CHANGES_REQUESTED (CI only: Unit Tests pending ~5min); bounded wrap correct/no leak, helper == old logic, gen unchanged, all local gates green; M-1 tracked post-#1271 -> review-1275-code.md
2026-10-24 14:22 CEST code-reviewer: #1275 APPROVED at d3b19061 (CI green)
- 2026-10-24 15:25 ingestionsvc-fixes milestone: PR #1275 ready; Copilot r1 1 comment (Makefile lint misses deployment module) fixed in 61645ac2 + replied
- 2026-10-24 15:25 ingestionsvc-fixes done: Copilot r2 on 61645ac2 clean (no open issues); head 61645ac2, not merged
- 2026-10-24 15:32 code-reviewer #1275 Delta 2 @61645ac2: approvable pending CI (Unit Tests pending); L-1 service-test module not in make lint (msg-W-2026-0001-code-reviewer-071 re dev-lead-523)
- 2026-10-24 16:08 cto watchdog: CI green on 61645ac2 -> 👀 waiting on Mario merge
2026-10-24 16:10 CEST code-reviewer: #1275 APPROVED at 61645ac2 (CI green)
