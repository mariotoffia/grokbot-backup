# Test review: PR #1275 @519d0297 (ingestionsvc fixes)

== Verdict == CHANGES_REQUESTED

== Findings ==
[Medium] [testable] go-services/ingestionsvc/ingestioncore/serialization_test.go:37-53 — Only the `cause != nil` branch is tested. The payload is truncated JSON, so the cause is "unexpected end of JSON input" (short and record-free). The `cause == nil` path (serialization.go: detail = err.Error(), which is the dsmodel text that embeds the whole record) never runs in a test. Mutation: replacing `preview([]byte(detail))` with `detail` (no truncation of the error text) SURVIVES, so the test suite passes. Fix: add a case with syntactically valid JSON that dsmodel rejects with no wrapped cause (probe: `{"state":{"reported":{"x":"<1000 a>M"}}}` gives Unwrap()==nil) and a case with a type error. Put the marker in the payload text dsmodel quotes, and assert NotContains plus the length bound.
[Medium] [testable] deployment/lib/infrastructure/config/yaml_loader_ingestion_settings_test.go:12-54 — Missing boundary cases. Probed on the /tmp copy: -1 rejected, "30" (string) rejected, null rejected, `settings: {}` (missing → default 90) accepted, 1 accepted, 1.0 accepted, 2147483648 and 99999999999999999999 ACCEPTED. The test pins none of these except 0 and 1.5. Fix: add subtests for -1, "30", the minimum 1 (accept), a missing key/empty settings (accept), and a max case. Add a schema `maximum` (S3 lifecycle days; stack.go:270 does int(float64) on an unbounded value) and test the maximum and maximum+1.
[Low] [testable] go-services/ingestionsvc/ingestioncore/serialization_test.go:49-53 — The chain walk uses errors.Unwrap only, so it would skip errors.Join / Unwrap() []error branches. %v/%+v formatting is not asserted (probe: cberror %+v == Error() today, so it would not catch a future %+v that adds the cause or a stack). The bound `2*200+200` is a magic literal. Fix: walk with a helper that handles both `Unwrap() error` and `Unwrap() []error`, assert on fmt.Sprintf("%v"/"%+v"), and use payloadPreviewLimit (same package) in the bound.
[Low] [testable] serialization_test.go:37 / yaml_loader_ingestion_settings_test.go:12 — no t.Parallel(). Both are pure, and LoadFromYAML uses t.TempDir() (auto cleanup), so adding it is safe. Context name "test-buildingservice" is a copy-paste leftover. Fix: t.Parallel() at the top level and in the subtests; use "test-ingestionsvc".
[Low] [hard-to-test] go-services/ingestionsvc/deployment/stack.go:268-272 — no test (package has no test files) that the stack honours objectExpirationDays or falls back to 90. The schema test only proves the loader accepts it. Fix: a CDK synth assertion on the bucket lifecycle rule for set/unset values.
[Info] [non-testable] AGENTS.md:322 asks for tests in the <package>_test package when they test exported functionality. Both new tests are internal-package. Fine for serialization (it needs payloadPreviewLimit if adopted) and consistent with the existing config tests.

Positives: both tests call the real TEOS code (LoadFromYAML with the real provision schema; the real ToDsBuilding → dsmodel). Mutation: dropping the preview truncation → FAIL (marker found, len 10150 > 600). Wrapping the original err instead of cause → FAIL. The payload is 10 KB with a distinctive tail marker. Deterministic, uses t.TempDir, names are clear.

Floci e2e skip: acceptable. Runtime changes are limited to the ToDsBuilding error branch (text/wrapping) and the renamed error constant (same code 2803). The config/schema change is load-time only, and stack.go is unchanged. No AWS/Floci interaction path changed.

== Rationale ==
The real code is exercised, and the payload-truncation regression is caught. But the branch that actually carries the full record into the error text (`cause == nil`) is untested, and a mutation removing its truncation survives, which is the core of #1274. The objectExpirationDays test covers only 0 and 1.5, and the probes show huge values are accepted with no maximum. Both are cheap to fix.

Test run (git archive 519d0297 → /tmp/pr1275, repo untouched):
- deployment: go test -race -count=1 -run TestLoadFromYAML ./lib/infrastructure/config/ → ok (3.2s)
- go-services: go test -race -count=1 ./ingestionsvc/ingestioncore/ ./ingestionsvc/deployment/ → ok (1.0s); deployment: no test files
- Mutations: truncation removed → FAIL; wrap err instead of cause → FAIL; detail truncation removed → PASS (survivor)

== Delta 1 (519d0297..d3b19061) ==

== Verdict == APPROVED

== Findings ==
Previous findings, checked again:
- [Medium] no-cause path untested: FIXED. TestToDsBuildingFailureKeepsPayloadOutOfError covers three failure kinds: truncated JSON, a strconv type error quoting the value, and a SetBuildingID failure quoting the topic. Each puts the marker past 10 KB. assertNoPayload checks Error(), %v and %+v against maxErrorLen (2*payloadPreviewLimit+200), and errorChain walks both Unwrap() error and Unwrap() []error. New tests also check that short causes stay reachable (errors.As finds *json.UnmarshalTypeError and the inner CbError ErrorModelUnableToSetBuildingId).
  Mutations on the /tmp copy:
  - remove the payload preview truncation → FAIL
  - remove the error-text truncation (my Delta-0 survivor) → FAIL (now killed)
  - remove the `len(detail) > limit → cause=nil` gate → FAIL
  - skip the ErrorModelUnmarshalBuilding unwrap → survives (see Low)
- [Medium] missing schema boundaries: FIXED for -1 and "30" (rejected), 1 and missing/`{}` (accepted). New TestObjectExpirationDaysFrom covers nil config, nil settings, missing key, 30 and 1 → 90/90/90/30/1. Max: deliberately not added (see below).
- [Low] Unwrap/Join walk, %v/%+v, magic bound: FIXED. Context names are now "test-ingestionsvc".
- [Low] t.Parallel: the waiver is VALID. .golangci.yml:38-39 forbidigo bans `^\w+\.Parallel$` ("TEOS tests run in sequence: tests that set the environment with t.Setenv cannot run in parallel (TESTS.md)").
- [Low] stack honours the setting: FIXED at unit level (objectExpirationDaysFrom extracted from stack.go and tested). There is no synth assertion, which is acceptable.

Schema maximum waiver:
The citations are accurate. API_LifecycleExpiration says Days is "a non-zero positive integer", "Type: Integer". The CFN AWS::S3::Bucket Rule docs give ExpirationInDays as "Type: Integer" with no Maximum. Neither documents an upper bound, so not inventing a business max is reasonable. The overflow risk is still real at the type level, though.

[Low] [testable] go-services/ingestionsvc/deployment/stack.go (objectExpirationDaysFrom, `int(v)`) — The schema accepts 2147483648 and 99999999999999999999 (probed in Delta 0). In Go, int(1e20) = -9223372036854775808 (checked), so the lifecycle Duration goes negative. 2147483648 survives as int but exceeds the S3 Integer type: aws-sdk-go-v2 s3 v1.101.0 types.LifecycleExpiration.Days is *int32. Either way it fails late, at CDK synth or CFN deploy, with a confusing error, not silently with wrong data. Fix: add `"maximum": 2147483647` to the schema (the type range, not a business limit), or clamp/reject in objectExpirationDaysFrom. Add a 1e20 case to TestObjectExpirationDaysFrom and a 2147483648 reject case to the schema test.
[Low] [testable] go-services/ingestionsvc/ingestioncore/serialization.go:44-47 — Mutation: skipping the ErrorModelUnmarshalBuilding unwrap (wrapping the whole dsmodel error) survives. For large payloads the length gate drops the cause anyway, and for short ones (`{"state":1}`) errors.As still finds the json cause through the wrapped error. So it is nearly equivalent and only the bounded short record text differs. Fix (optional): in TestToDsBuildingDecodeFailureWrapsJSONCause, also assert that errors.Unwrap(err) is the *json.UnmarshalTypeError directly (or that its Code() is not ErrorModelUnmarshalBuilding).

== Rationale ==
Every earlier Medium is fixed with tests that kill the relevant mutations, including the previous survivor. The t.Parallel waiver matches the lint config, and the no-max citation is accurate. What remains is low-severity: a type-range overflow that fails loudly at synth/deploy, and a near-equivalent mutant.

Test run (git archive d3b19061 → /tmp/pr1275b, repo untouched):
- deployment: go test -race -count=1 -run TestLoadFromYAML ./lib/infrastructure/config/ → ok
- go-services: go test -race -count=1 ./ingestionsvc/ingestioncore/ ./ingestionsvc/deployment/ → ok, ok
