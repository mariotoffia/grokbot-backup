# Code review: PR #1275, ingestionsvc fixes (closes #1274)

- **PR:** https://github.com/Thiink-LLC/teos/pull/1275 (draft)
- **Head:** `519d029704cc13d57b6edf0852433dc015778082`, verified; the head has not moved.
- **Commits:**
  - `f61fdb1a fix(ingestionsvc): nil-value error text and settings schema`
  - `519d0297 fix(ingestionsvc): bound unmarshal error text to the payload preview`
- **Verdict: CHANGES_REQUESTED.** The code is correct and every gate is green. The one blocker is M-1: once both PRs merge, the #1271 docs contradict this PR.

## Gate table

| Gate | Result |
|---|---|
| (1) Rename and 2803 references | PASS. A monorepo-wide `git grep` (Go, tests, docs, TS, generated code) finds no `ErrorNilValueRequired` and no "must be nil while". The only `2803` hits are `errorcodes/codes.go:7` and `_design/overview.adoc:297` (updated); the rest are excalidraw coordinates. |
| (2) ExtractSensorComponents comment | PASS with a nit (L-1). transform.go:18-19 matches the code: 2800 for an empty id (:23-29) and 2801 for any `Parse()` failure (:33-41). |
| (3) Schema and generated code | PASS. `provision-schema.json` adds `settings.objectExpirationDays` (integer, minimum 1, default 90, `additionalProperties: false`). Re-running `go run ./cmd/cbgenerate cdklib generate` left the tree clean, so `ingestion_generated.go` is **byte-identical**. The default matches: stack.go:37 sets `objectExpirationDays = 90`, and :268-272 falls back to it when the value is unset. `Settings` arrives through `json.RawMessage` (product/definition.go:37 and 269), so the `.(float64)` assertion at stack.go:270 holds. The new tests confirm `LoadFromYAML` rejects 0, 1.5 and unknown keys. |
| (4) Makefile `lint` | PASS. ingestionsvc/Makefile:11-12 has the same shape as appstore:33-34, realestatecore:102-103 and eventsvc:56 (`lint: lint-arch`, then `cd $(REPO_ROOT) && golangci-lint run ./$(MODULE)/...`). Others prefix the command with `@`; that difference is cosmetic. CONVENTIONS also lists fmt, vet and test targets (L-2). |
| (5) Payload leak | PASS. serialization.go:37-50 no longer wraps the dsmodel error, whose text embeds the whole payload. Only its cause (the `encoding/json` error) is kept, and both the preview and the detail are capped at 200 bytes (:13-24). `CbError.Error()` returns only `msg` (cberror.go:144), so the warn log at main.go:50 stays bounded. No other warn path logs the payload; the trace logs (main.go:60-70, 149, 174) are documented as never-in-production. `errors.Is/As`: nothing in ingestionsvc or its callers matches on `ErrorModelUnmarshalBuilding`, and callers use `.Code()` (2800, unchanged). Unwrapping still reaches the json error. See L-3. |
| gofmt | PASS (changed .go files) |
| go vet | PASS (`go-services/ingestionsvc/...`, `deployment/lib/infrastructure/config`, `deployment/models/services/ingestion`) |
| golangci-lint | PASS. 0 issues from ingestionsvc `make lint` and 0 on the config/models packages. |
| go-arch-lint | PASS. The ingestionsvc map reports "OK - No warnings found". |
| Unit tests `-race -short` | PASS: `ingestioncore`, `handlers/dstransform/main` and `deployment/lib/infrastructure/config` (ingestion and LoadFromYAML tests). No Floci or AWS was used. |
| Prefixes and plan IDs | PASS. None in the title, the commits or the added lines. |
| Issue #1274 | Assignee mariotoffia; labels bug, go, lint, core; Priority Medium; Size Hours; Roadmap unset. Board status is **Progress, not Incoming** (L-4). |
| CI (`gh pr checks 1275`, 13:12 CEST) | Green: CodeQL and both Analyze jobs pass. **Unit Tests, Build, Static Analysis and Architecture were skipped** even though Go files changed (L-5). |

## Findings

### Medium

- **M-1: docs are out of sync with #1271** (still OPEN). This branch has no ingestionsvc docs, and #1271's `ARCHITECTURE.md:247-257` lists exactly these four items as open follow-ups. Its Logging section (:223-228) says warn logs can expose the full record. Whichever PR lands second must remove the four follow-ups and rewrite the Logging bullet to "inner error and payload preview each capped at 200 bytes". Check `LINT.md` for the missing-`lint` note as well. Fix it in this PR after #1271 merges (rebase), or record an explicit follow-up.

### Low

- **L-1, transform.go:19.** "position in message" overstates it. `SensorType.Parse` returns `len(s)` on every teosid failure (eqmodel/sensor-type_functions.go:306), so the logged "position" is always the id length. Suggested wording: "any parse failure; the message holds the id".
- **L-2, ingestionsvc/Makefile.** CONVENTIONS asks for fmt, lint, lint-arch, vet, test and test-integration targets; only lint and lint-arch exist. This was out of scope for #1274, so record it as a follow-up.
- **L-3, serialization.go:41-48.** If `NewDsFullBuildingWithTopic` fails in `SetBuildingID` (building.go:200) rather than in decoding, `errors.Unwrap(err)` can be nil. The new error then wraps nothing and the original error's chain is lost (its text is kept, capped). That error carries no payload, so wrapping `err` when `err.Code() != cberror.ErrorModelUnmarshalBuilding` would keep `errors.As`. Optional.
- **L-4, issue #1274.** Board status is Progress; the expected value is Incoming.
- **L-5, CI.** The Go unit-test, build and static-analysis jobs were skipped on a Go change (probably the draft or path filters), so CI's green does not cover the Go changes. The local gates above do.

### Info

- `dsmodel.NewDsFullBuilding` (go-core/model/dsmodel/building.go:174-178) still embeds the full payload for its other callers, for example providerpipe. That is outside this PR.
- The overview.adoc:298 description "Sensor value is nil" is still accurate.

## Delta 1: 519d0297..d3b19061

**Verdict: CHANGES_REQUESTED, blocked on CI only.** Head verified as d3b190618b5e. The two new commits are 16da889b "fix(ingestionsvc): wrap payload-free dsmodel errors in ToDsBuilding" and d3b19061 "test(ingestionsvc): cover payload-quoting causes and expiration settings". No W-/T- prefixes and no plan IDs. If Unit Tests goes green with no other changes, this becomes APPROVED.

### CI

The Unit Tests check was still pending after about 5 minutes (10×30s), even though the unit-test label is set. CodeQL and Analyze pass. Architecture, Build and Static Analysis were skipped.

### Local gates (all green)

- `gofmt -l` is empty for ingestionsvc, ingestionsvc/deployment and deployment/lib/infrastructure/config.
- `go vet` passes.
- `golangci-lint run ./go-services/ingestionsvc/... ./deployment/lib/infrastructure/config/...` reports 0 issues.
- go-arch-lint (from the Makefile `lint-arch` recipe) reports "OK - No warnings found".
- `go test -race -short -count=1` is ok for:
  - ingestioncore
  - dstransform/main
  - ingestionsvc/deployment
  - deployment/lib/infrastructure/config

  None of these runs needed Floci or AWS.

### Checks

- **SetBuildingID cause is now wrapped (16da889b).** Only `ErrorModelUnmarshalBuilding` is unwrapped down to its decoder cause. Any other dsmodel error is wrapped whole as the cause.
- **Bounded wrap, no payload leak.**
  - `CbError.Error()` returns only its own `msg` and doesn't append the chain. The `detail` length check therefore covers exactly the text that is wrapped.
  - When the text is longer than `payloadPreviewLimit`, the cause is set to nil and only the cut preview is kept.
  - SetBuildingID builds its CbError with a nil cause, so wrapping it whole doesn't pull in a deeper unbounded chain.
  - The tests cover three payloads: truncated JSON, a strconv error quoting a 10 kB value, and a 10 kB topic. `assertNoPayload` checks Error, %v and %+v, and walks the whole chain, including Unwrap() []error, for the tail marker and a length bound.
  - The cause-dropping tradeoff above the limit is an accepted design decision.
- **No-cause and short-cause tests.**
  - `TestToDsBuildingSetBuildingIDFailureWrapsCause` checks that errors.As reaches the inner CbError with code `ErrorModelUnableToSetBuildingId`.
  - `TestToDsBuildingDecodeFailureWrapsJSONCause` checks that errors.As reaches `*json.UnmarshalTypeError`.
- **2801 comment fixed.** transform.go now reads "any parse failure (circuit, ordinal, zone or area); the message holds the id".
- **`objectExpirationDaysFrom` behaves like the old inline code.**
  - A nil config, nil settings or a missing key gives 90.
  - A `float64` value goes through `int(v)`; other types fall back to 90, as before.
  - There's no clamp in code, and there wasn't one before. The minimum of 1 is enforced by provision-schema.json (`"type": "integer", "minimum": 1, "default": 90`).
  - The tests cover nil, no settings, missing, 30 and 1.
  - Not a finding: a non-integer float such as 1.5 would truncate. The schema's integer type rejects it.
- **New schema cases.** `yaml_loader_ingestion_settings_test.go` adds 37 lines of cases and passes.
- **Generated code is unchanged.** provision-schema.json and `deployment/models/services/ingestion/*_generated.go` have no diff in this range, so there's nothing to regenerate.

### Accepted decisions (not findings)

- A cause is wrapped only when its text is at most `payloadPreviewLimit`.
- The schema has no maximum.
- forbidigo bans `t.Parallel`.
- M-1 (the ARCHITECTURE and LINT docs) follows once #1271 merges, so it is tracked as resolved.

The earlier Lows are unchanged.

## Final

APPROVED at d3b19061. CI: Unit Tests passed (run 40089434294), CodeQL and both Analyze jobs passed. Architecture, Build and Static Analysis were skipped in CI; they are covered by the local gates (gofmt, vet, golangci-lint, go-arch-lint, -race tests), which all passed. M-1 is tracked as the docs commit after #1271 merges.

## Delta 2 — d3b19061..61645ac2 (head 61645ac24350ffcded70a1a959481eaac52150d1)

**Verdict: code approvable pending CI** (only Unit Tests pending after about 5 min of rechecks; CodeQL and Analyze pass; Bugbot, Security, Architecture, Build and Static Analysis skipping).

- Head verified. The delta is 1 commit ("build(ingestionsvc): lint the deployment module in make lint") and changes only go-services/ingestionsvc/Makefile (+6/-3). No W-/T- prefixes and no plan IDs.
- The new `lint` target runs `golangci-lint run ./$(MODULE)/... ./$(MODULE)/deployment/...` from the repo root, which matches eventsvc Makefile:56-60. Through go.work, `go list` resolves the nested `deployment` module (package go-services/ingestionsvc/deployment), so it really is loaded and linted; `-v` shows the loader running.
- `make -C go-services/ingestionsvc lint` (including lint-arch) gives rc 0 and 0 issues.
- gofmt -l is clean. go vet passes for ingestionsvc, deployment, and service-test (-tags e2e).

### L-1 (non-blocking): the service-test module is still not linted by `make lint`
- `deployment/service-test` is a third nested module (its own go.mod, every file has `//go:build e2e`). The `./deployment/...` pattern stops at module boundaries, so it is not covered.
- eventsvc covers its service-test through `$(MAKE) -C deployment/service-test lint`, which runs golangci-lint with `--build-tags=e2e,floci` and `--build-tags=e2e`. ingestionsvc has no service-test Makefile, so this PR's claim that it lints "the same way eventsvc does" is only partly true.
- Run by hand from the root, the module currently gives 0 issues with tags e2e, with e2e,floci, and with no tags.
- Suggestion: add `cd $(REPO_ROOT) && golangci-lint run --build-tags=e2e ./$(MODULE)/deployment/service-test/...` (or a service-test Makefile like eventsvc's). This can be a follow-up.

Temp worktree /tmp/w1275 removed.

## Final (Delta 2)

APPROVED at 61645ac2. CI: Unit Tests passed (run 40097306602), CodeQL and both Analyze jobs passed, and the rest were skipped (covered by the local gates). L-1 (service-test lint) is queued for the post-#1271 batch.
