# Code review: PR #1265 (draft, Closes #1264)

Head confirmed: 04c99d00ad0f38dd373260e1586daeedfba4a112 (not moved). The diff is Makefile only (+10/-1) in one commit, as claimed.

## Verdict: APPROVED

## Mario 16:25 rule (no fallback, no rm)
- The recipe is a `command -v` guard, then echo plus `exit 1`, then `golangci-lint cache clean`.
- It has no `rm`, no hard-coded cache path and no alternative path. It always calls golangci-lint, so the location stays up to golangci-lint. OK

## Behaviour (my runs in a clean temp worktree at 04c99d00, GNU Make 4.4.1, /bin/sh = dash)
- `make -n clean-caches`: rc 0, and the new step is listed between modcache and docker.
- `make help`: lists `clean-golangci-cache` and the updated `clean-caches` text. Help comes from the `## ` comments.
- Binary on PATH (~/.local/bin), run twice: rc 0 both times. Idempotent.
- Also rc 0 with SHELL=/bin/bash.
- Binary hidden (PATH=/usr/bin:/bin): stderr shows "ERROR: golangci-lint is not on PATH. Run 'make install' to install it." and make prints `Error 1`. The process exits with **2**, because make exits 2 on any recipe failure. The recipe itself exits 1. The claim "exits 2" refers to make's exit code and is accurate.

## Portability
- POSIX sh only: `if ! command -v ...; then ...; fi`, with backslash continuations. No bashisms. Verified under dash.
- Recipe lines are tab-indented (checked with cat -A).
- Nothing needs GNU make 4.x: no .ONESHELL, no `!=`, no grouped targets. Works on macOS make 3.81.
- `command -v` is POSIX and is in macOS /bin/sh (bash 3.2 / zsh-sh).

## .PHONY / ordering
- `.PHONY: clean-golangci-cache` is declared.
- clean-caches runs its prerequisites in order. Without `-k`, any earlier failure stops the run. A missing golangci-lint now stops clean-caches before clean-docker. That is intended under "no fallback". Under `-j` the order was already unordered before this change.
- The `setenv` prerequisite matches the sibling targets.

## Issue / process
- #1264 is linked: the body says "Closes #1264", and closedByPullRequestsReferences = #1265.
- Assignee mariotoffia. Labels lint, build. Priority=Low. Size=Hours.
- Board (R&D Sprint Board): Status = **Progress**, not Incoming (L1). An iteration (Sprint 21) is set. Roadmap is unset. OK
- PR title, issue title (`build: clean golangci-lint cache in clean-caches`) and commit subject: no W-/T- prefix.

## Gates
- make -n parses: rc 0.
- Evidence in /workspace/minions/work/clean-caches-golangci/: make-n, missing-binary, run1 (441M → cache dir gone, rc 0) and run2 (rc 0).
- `gh pr checks`: Analyze (actions) pass. Architecture, Build, Static Analysis and Unit Tests were skipped by path filters, which is fine for a Makefile-only change. Analyze (javascript-typescript) is pending at review time.
- No failed gate.

## Findings
- L1 (Low, process): the board Status for #1264 is "Progress", while the issue-first checklist requires Incoming. Confirm or reset it.
- I1 (Info): the evidence logs have no `sha`/HEAD header, and missing-binary.log has no rc line. Add `git rev-parse HEAD` and `rc=` lines next time.
- I2 (Info): the CodeQL JS analysis was still pending, and it is irrelevant to a Makefile diff.
