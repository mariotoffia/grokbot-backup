2026-11-05 15:14:04 CET golang-pro started analysis issue-1254
2026-11-05 15:16:12 CET golang-pro finished analysis issue-1254 PASS_on_neutral_path FAIL_when_path_contains_buildingsvc latent_on_fd5775b6
