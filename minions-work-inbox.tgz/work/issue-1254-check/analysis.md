# Issue 1254 analysis — TestBuildingServiceSpec

## Verdict
**FAIL is path-dependent / still latent on origin/main.**  
On a checkout whose absolute path does **not** contain the substring `buildingsvc`, the test **PASSES**.  
On a checkout whose absolute path **does** contain `buildingsvc` (e.g. worktree `…/W-2026-0001-buildingsvc-arch-lint`), the test **FAILS** exactly as reported — picking `meta/spec/api/mac/http-api.yaml` (customer account API).

No fixing commit on `origin/main`; the buggy selector is unchanged.

## SHAs
- Claim base: `41409305` (issue body)
- Analyzed `origin/main`: `fd5775b64f466e4eba2d9faf0615fe5b1fb35699` (Europe/Stockholm fetch 2026-11-05)
- Test file / selector unchanged `41409305..origin/main` for the `Contains(f, "buildingsvc")` logic (no `-S buildingsvc` hits on the test after that commit for a fix)

## Evidence

### Code (still on origin/main)
- `deployment/lib/tests/unit/openapi_all_specs_test.go:37` — `findAllHttpApiYamlFiles`: walks `meta/spec/api` **first**, then `go-services`; returns **absolute** paths.
- `deployment/lib/tests/unit/openapi_all_specs_test.go:395-404` — `TestBuildingServiceSpec` takes the **first** file where `strings.Contains(f, "buildingsvc")` and `break`s.

### Pass (neutral path)
- Scratch: `/tmp/i1254` from `git archive origin/main`
- Command: `cd /tmp/i1254/deployment/lib && go test -count=1 -v -run '^TestBuildingServiceSpec$' ./tests/unit/`
- Result: **PASS** (rc=0). Log: `/workspace/minions/work/issue-1254-check/test.log`
- Only real repo match under normal paths: `go-services/buildingsvc/spec/http-api.yaml`

### Fail (path contains `buildingsvc`) — reproduces issue
- Scratch: `/tmp/i1254-buildingsvc-repro` (same tree)
- Same `go test` command → **FAIL** ValidatePaths/ValidateOperations with paths  
  `/v1/customer/account/create`, `/decline`, `/v1/oauth2/token`, `/accept`  
  (identical to issue / gate logs).
- Log: `/workspace/minions/work/issue-1254-check/test-repro-buildingsvc-in-path.log`
- Historical gate cwd: `/workspace/repos/teos/work/git-worktree/W-2026-0001-buildingsvc-arch-lint`  
  (`…/gates/r3/test.log`)

### Which file is picked / why
When the workspace absolute path contains `buildingsvc`, **every** `http-api.yaml` absolute path matches the substring. Walk order (meta first) yields:

1. `…/meta/spec/api/mac/http-api.yaml` ← **picked** (MAC / customer account)
2. `…/meta/spec/api/rtc/http-api.yaml`
3. … other meta specs …
4. `…/go-services/appstore/api/http-api.yaml`
5. `…/go-services/buildingsvc/spec/http-api.yaml` ← intended
6. …

So the “other path” is not a customer-account spec living under a buildingsvc *directory*; it is the first walked spec (`mac`) whose **full absolute path** happens to contain `buildingsvc` because of the checkout/worktree name.

## Root cause
`strings.Contains` on the full absolute path + first-match is unsafe when any ancestor directory name contains `buildingsvc`. Not fixed on `origin/main`.

## KISS fix (do not implement)
Replace the substring loop with an exact relative path match, e.g.:

```go
if strings.HasSuffix(filepath.ToSlash(f), "/go-services/buildingsvc/spec/http-api.yaml") {
```

(or `filepath.Join(workspaceRoot, "go-services", "buildingsvc", "spec", "http-api.yaml")` and use that file directly).
