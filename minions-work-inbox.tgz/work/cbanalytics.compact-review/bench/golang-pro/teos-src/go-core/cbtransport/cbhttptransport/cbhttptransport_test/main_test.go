//go:build !integration

package cbhttptransport_test

import (
	"os"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestMain applies the TEOS test settings for every unit test in this package.
// The integration build has its own TestMain, which also points the tests at
// an AWS backend.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvDefaults))
}
