package cbhttptransport

import (
	"fmt"
	"time"

	"github.com/PaesslerAG/gval"
	"github.com/aws/aws-xray-sdk-go/v2/xray"
	"github.com/hashicorp/go-retryablehttp"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// HttpEndpoint encapsulates communication with a remote peer
// using the _HTTP_ protocol.
//
// This endpoint do support for retrying request as well as integrated _AWS_ x-ray support.
type HttpEndpoint interface {
	transportmodel.Endpoint
	// NewHttpClient creates a new pre-configured client to be used to communicate
	// with the remote endpoint.
	//
	// .Environment Variables
	// |===
	// |Name 					|Description
	// |CB_IN_UNIT_TEST 		|When set to true, the client will not use xray.Client. Default is false.
	// |CB_REP_RETRY_COUNT 		|The number of times to retry a request. Default is 0.
	// |CB_REP_RETRY_WAIT_MIN 	|The minimum number of milliseconds to wait before retrying a request. Default is 1 second.
	// |CB_REP_RETRY_WAIT_MAX 	|The maximum number of milliseconds to wait before retrying a request. Default is 30 seconds.
	// |===
	NewHttpClient(ctx ifcore.CbContext) *retryablehttp.Client
	// NewRequest creates a new request to be sent to the remote endpoint.
	//
	// This request can be used with the client returned by `NewClient`.
	//
	// The _method_ is the type of request to be done and the _url_ is the *full* _URL_, including
	// query parameters. The _rawBody_ is the body of the request and can be a byte array, string or readable.
	NewRequest(
		ctx ifcore.CbContext,
		method transportmodel.TransportMethod,
		url string,
		rawBody interface{}) (*retryablehttp.Request, error)
}

// HttpSecurityMaterialDecorator is required to be provided if a request is authenticated
// and it is not a well known authentication mechanism.
//
// This is usually provided by the provider and is registered in the endpoint manager to
// be used by the endpoint.
type HttpSecurityMaterialDecorator interface {
	transportmodel.SecurityMaterialDecorator
	// Decorate adds security material to the request. The credentials has already been
	// resolved (if needed) using either standardized flows or custom auth chain.
	//
	// NOTE: If may also use cached credentials.
	Decorate(
		ctx ifcore.CbContext,
		req *retryablehttp.Request,
		credentials securitymodel.StandardCredentials,
	) error
}

// HttpSecurityMaterialDecoratorImpl standard implementation of the `HttpSecurityMaterialDecorator`
// that allows for inline function to do `Decorate`.
type HttpSecurityMaterialDecoratorImpl struct {
	DecorateFunc func(
		ctx ifcore.CbContext,
		req *retryablehttp.Request,
		credentials securitymodel.StandardCredentials,
	) error
}

// Implements the `HttpSecurityMaterialDecorator` interface.
func (hsmd *HttpSecurityMaterialDecoratorImpl) Decorate(
	ctx ifcore.CbContext,
	req *retryablehttp.Request,
	credentials securitymodel.StandardCredentials,
) error {
	return hsmd.DecorateFunc(ctx, req, credentials)
}

// HttpEndpointImpl is a implementation of `HttpEndpoint` interface to handle
// remote _HTTP_ endpoints.
type HttpEndpointImpl struct {
	transportmodel.EndpointImpl
}

// NewClient implements the interface `transportmodel.Endpoint`
func (ep *HttpEndpointImpl) NewClient(
	ctx ifcore.CbContext,
) transportmodel.EndpointClient {
	return &HttpEndpointClientImpl{
		ep:     ep,
		client: ep.NewHttpClient(ctx),
		lang:   gval.Full(cbeval.ConversionLanguage(), cbeval.SingleQuoted()),
	}

}

// NewHttpClient creates a new pre-configured client to be used to communicate
// with the remote endpoint.
func (ep *HttpEndpointImpl) NewHttpClient(ctx ifcore.CbContext) *retryablehttp.Client {
	client := retryablehttp.NewClient()

	client.Logger = &loggerMap{
		context: ctx,
		m:       fmt.Sprintf("%s::HTTP", ctx.Provider()),
		l:       cbenv.CB_REP_MAX_LOG_LEVEL.LogLevel("panic"),
	}

	client.RetryMax = int(cbenv.CB_REP_RETRY_COUNT.Integer(3))
	client.RetryWaitMin = cbenv.CB_REP_RETRY_WAIT_MIN.Duration(10) * time.Millisecond
	client.RetryWaitMax = cbenv.CB_REP_RETRY_WAIT_MAX.Duration(300) * time.Millisecond

	// Use xray when not in unit test
	if !cbenv.CB_IN_UNIT_TEST.Bool(false) {
		client.HTTPClient = xray.Client(client.HTTPClient)
	}

	return client
}

// NewRequest creates a new request to be sent to the remote endpoint.
//
// If the request is successfully created, it will be dumped using `dumpRequest` and
// returned. If an error occur it will be logged and a `ConfigurationError` is returned.
func (ep *HttpEndpointImpl) NewRequest(
	session transportmodel.EndpointSession,
	method transportmodel.TransportMethod,
	url string,
	headers map[string][]string,
	rawBody interface{}) (*retryablehttp.Request, cberror.Error) {
	req, err := retryablehttp.NewRequestWithContext(
		session.GetContext(),
		string(method),
		url,
		rawBody,
	)

	if err == nil {
		// Add headers to request
		for k, v := range headers {
			for _, vv := range v {
				req.Header.Add(k, vv)
			}
		}

		// Auto-inject trace header for cross-service propagation.
		if req.Header.Get("X-Amzn-Trace-Id") == "" {
			if session.GetContext().Trace() != nil {
				if th := session.GetContext().Trace().ToHeader(); th != "" {
					req.Header.Set("X-Amzn-Trace-Id", th)
				}
			}
		}

		dumpRequest(session.GetContext(), session.GetContext().Provider(), req)

		return req, nil
	}

	if l, ok := logger.ClsLog(
		zerolog.ErrorLevel, "NewRequest", logger.LDTDevOps, logger.LISUnclassified, session.GetContext(),
	); ok {
		logger.LogObject(l, "err", err).
			Str("url", fmt.Sprintf("%s %s", string(method), url)).
			Msg("Failed to create request")
	}

	lid, _ := cbtransportutils.GetGlobalParamAsString(
		session,
		string(ifprovider.ParameterLocationID),
	)

	return nil, cberror.NewCbErrorConfigurationExecutionErrorf(
		session.GetContext().Service(),
		cberror.ConfigurationErrorTypeDataPointRemoteIDError,
		1, nil, nil,
		map[string]interface{}{"lid": lid}, "%s", err.Error(),
	)

}
