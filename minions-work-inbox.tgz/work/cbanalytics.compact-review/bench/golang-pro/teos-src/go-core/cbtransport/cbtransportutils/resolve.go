package cbtransportutils

import "github.com/Thiink-LLC/teos/go-core/model/transportmodel"

// ResolverStatusHandlers will try to resolve a `StatusHandlerFunc` from a given name.
//
// It will traverse parent `Endpoint`(s) until it is resolved, otherwise `nil` is returned.
// If _parent_ is set to `false` it will not traverse parent `Endpoint`(s)
func ResolveStatusHandler(
	endpoint transportmodel.Endpoint,
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	name string,
	parent bool,
) transportmodel.StatusHandlerFunc {
	var sh transportmodel.StatusHandlerFunc
	if sh = call.ResolveStatusHandler(name); sh != nil {
		return sh
	}

	if sh = session.ResolveStatusHandler(name); sh != nil {
		return sh
	}

	return endpoint.(transportmodel.EndpointFunctionResolver).ResolveStatusHandler(name, parent)
}
