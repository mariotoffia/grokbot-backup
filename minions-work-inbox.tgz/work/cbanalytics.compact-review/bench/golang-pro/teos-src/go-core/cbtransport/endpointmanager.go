package cbtransport

import (
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// Implements the `iftransport.EndpointManager` interface.
//
// It may read endpoints from _JSON_ data or be programmatically created.
type EndpointManagerImpl struct {
	transport map[string]transportmodel.Endpoint
	names     []string
	parent    transportmodel.EndpointManager
}

// GetEndpoint returns the endpoint with the given name.
//
// If not found, returns `nil`.
func (epm *EndpointManagerImpl) GetEndpoint(name string, parent bool) transportmodel.Endpoint {
	if ep, ok := epm.transport[name]; ok {
		return ep
	}

	if parent && epm.parent != nil {
		return epm.parent.GetEndpoint(name, parent)
	}

	return nil
}

// NewEndpointManager creates a new endpoint manager.
func NewEndpointManager(
	c ifcore.CbContext,
	parent transportmodel.EndpointManager,
	transport map[string]transportmodel.Endpoint,
) *EndpointManagerImpl {
	ti := &EndpointManagerImpl{
		transport: transport,
		parent:    parent,
		names:     make([]string, len(transport)),
	}

	if len(transport) == 0 {
		return ti
	}

	i := 0
	for name := range transport {
		ti.names[i] = name
		i++
	}

	return ti
}
