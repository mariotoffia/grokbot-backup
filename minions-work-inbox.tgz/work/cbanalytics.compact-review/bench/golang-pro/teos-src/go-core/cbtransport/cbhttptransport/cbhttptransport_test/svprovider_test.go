package cbhttptransport_test

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"slices"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// TestCustomSensorValidationExtractionAndUnmarshal will test how the wideco
// _sv_ provider would be partly implemented.
func TestCustomSensorValidationExtractionAndUnmarshal(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(widecoDatapoints))
	}))

	defer svr.Close()

	pc := widecoProviderConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "wideco",
  "credentials": {"required": ["user", "pass", "apikey"]},
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [
        {
          "path": "/datasnap/rest/TServerMethods1/GetUnitsData",
        	"params": {
				"UnitIDs": ["[join(rid,',')]"],
				"Columns": ["[join(col,',')]"],
				"LastValue": []
			},
          "handler": {"200": "ok", "*": "fail"}, "processor": "wideco"
        }
      ]
    }
  }
}`)

	ctx := newCtx(t)
	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data).
		StatusHandler("ok", func(
			session transportmodel.EndpointSession,
			call transportmodel.EndpointCall,
			invoke transportmodel.InvokeArgs) cberror.Error {
			tz, _ := cbtransportutils.GetGlobalParamAsString(
				session, string(ifprovider.ParameterTimeZone),
			)

			dp, err := widecoUnmarshalDatapointList(
				session.GetContext(), tz, invoke.Body(),
			)

			if dp != nil {
				session.GetSessionContext().SetUnmarshalDataPoints(dp)
			}

			return err
		}).
		SensorProcessor("wideco", widecoValidateAndFormatSensorAndColumns)

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*sessionContext*/
		nil, /*statusHandlers*/
	)

	ep := mgr.GetEndpoint("wideco", false /*parent*/)

	err := ep.GetCallChain("", false /*parent*/).Invoke(
		session, ep.NewClient(ctx),
	)

	assert.Equal(t, nil, err)

	dp, found := session.GetSessionContext().GetUnmarshalDataPoints()
	assert.Equal(t, true, found)

	q := dp.([]eqmodel.CbDataPointImpl)
	assert.Equal(t, 4, len(q))

	cdp, found := session.GetSessionContext().CbDataPoints()
	assert.Equal(t, true, found)
	assert.Equal(t, 4, len(cdp))
}

func BenchmarkCustomSensorValidationExtractionAndUnmarshal(t *testing.B) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(widecoDatapoints))
	}))

	defer svr.Close()

	pc := widecoProviderConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "wideco",
  "credentials": {"required": ["user", "pass", "apikey"]},
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [
        {
          "path": "/datasnap/rest/TServerMethods1/GetUnitsData",
        	"params": {
				"UnitIDs": ["[join(rid,',')]"],
				"Columns": ["[join(col,',')]"],
				"LastValue": []
			},
          "handler": {"200": "ok", "*": "fail"}, "processor": "wideco"
        }
      ]
    }
  }
}`)

	ctx := newCtx(t)
	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data).
		StatusHandler("ok", func(
			session transportmodel.EndpointSession,
			call transportmodel.EndpointCall,
			invoke transportmodel.InvokeArgs) cberror.Error {
			tz, _ := cbtransportutils.GetGlobalParamAsString(
				session, string(ifprovider.ParameterTimeZone),
			)

			dp, err := widecoUnmarshalDatapointList(
				session.GetContext(), tz, invoke.Body(),
			)

			if dp != nil {
				session.GetSessionContext().SetUnmarshalDataPoints(dp)
			}

			return err
		}).
		SensorProcessor("wideco", widecoValidateAndFormatSensorAndColumns)

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("wideco", false /*parent*/)
	chain := ep.GetCallChain("", false /*parent*/)
	client := ep.NewClient(ctx)

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		session := transportmodel.NewEndpointSession(
			ctx,
			&oper,
			pc,
			nil, /*sessionContext*/
			nil, /*statusHandlers*/
		)

		_ = chain.Invoke(session, client)
		session.GetSessionContext().GetUnmarshalDataPoints()
	}
}

func widecoUnmarshalDatapointList(
	c ifcore.CbContext,
	tz string,
	body []byte,
) ([]eqmodel.CbDataPointImpl, cberror.Error) {
	type widecoUnit struct {
		ID     int `json:"UnitId"`
		Analog []struct {
			Index int     `json:"AnalogIndex"`
			Time  string  `json:"DataDateTime"`
			Value float64 `json:"DataAnalogValue"`
		} `json:"UnitDataAnalog"`
		PT []struct {
			Index int     `json:"PTIndex"`
			Time  string  `json:"DataDateTime"`
			Value float64 `json:"DataPTValue"`
		} `json:"UnitDataPT"`
	}

	var wdl []widecoUnit
	if err := json.Unmarshal(body, &wdl); err != nil {
		return nil, cberror.NewCbErrorf(
			c.Service(), 1 /*ErrorUnableToUnmarshalProviderDatapoints*/, nil,
			"Unable to unmarshal datapoints, error: %s", err.Error(),
		)
	}

	var dpl []eqmodel.CbDataPointImpl
	for _, wu := range wdl {
		// Get PT entries
		for _, k := range wu.PT {
			ts, _ := coremodel.TryParseTimeStamp32(tz, k.Time, "2006-01-02T15:04:05", nil)
			dpl = append(dpl, eqmodel.CbDataPointImpl{
				ID:        fmt.Sprintf("%d;PT=%d", wu.ID, k.Index),
				Value:     k.Value,
				TimeStamp: ts,
			})
		}
		// Get Analog entries
		for _, k := range wu.Analog {
			ts, _ := coremodel.TryParseTimeStamp32(tz, k.Time, "2006-01-02T15:04:05", nil)
			dpl = append(dpl, eqmodel.CbDataPointImpl{
				ID:        fmt.Sprintf("%d;Analog=%d", wu.ID, k.Index),
				Value:     k.Value,
				TimeStamp: ts,
			})
		}
	}

	return dpl, nil
}

func widecoValidateAndFormatSensorAndColumns(
	client transportmodel.EndpointClient,
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	ctx map[string]any) (sensors map[string]string, err cberror.ConfigurationError) {
	lid, _ := cbtransportutils.GetGlobalParamAsString(
		session, string(ifprovider.ParameterLocationID),
	)

	datapoints, resolveError := cbtransportutils.ResolveIDs(session)
	if err != nil {
		return nil, resolveError.(cberror.ConfigurationError)
	}

	units := make([]string, 0, len(datapoints))
	tables := map[string][]string{}
	validColumns := []string{"PT", "Analog"}

	for _, v := range datapoints {
		unitParts := strings.Split(v, ";")

		if len(unitParts) != 2 {
			return nil, cberror.NewCbErrorConfigurationValidationErrorf(
				session.GetContext().Service(),
				cberror.ConfigurationErrorTypeDataPointRemoteIDError,
				1,
				nil, nil,
				map[string]interface{}{
					"lid": lid,
				},
				"Invalid configuration of datapoint: %s", v,
			)
		}

		alreadyPresent := false
		for _, value := range units {
			if value == unitParts[0] {
				alreadyPresent = true
				break
			}
		}
		if !alreadyPresent {
			units = append(units, unitParts[0])
		}

		tableParts := strings.Split(unitParts[1], "=")
		if len(tableParts) != 2 {
			return nil, cberror.NewCbErrorConfigurationValidationErrorf(
				session.GetContext().Service(),
				cberror.ConfigurationErrorTypeDataPointRemoteIDError,
				2,
				nil, nil,
				map[string]interface{}{
					"lid": lid,
				},
				"Invalid configuration of table definition: %s",
				unitParts[1],
			)
		}

		if !slices.Contains(validColumns, tableParts[0]) {
			return nil, cberror.NewCbErrorConfigurationValidationErrorf(
				session.GetContext().Service(),
				cberror.ConfigurationErrorTypeDataPointRemoteIDError,
				3,
				nil, nil,
				map[string]interface{}{
					"lid": lid,
				},
				"Invalid column selection: %s", tableParts[0],
			)
		}

		if _, ok := tables[tableParts[0]]; ok {
			alreadyPresent = false

			for _, value := range tables[tableParts[0]] {
				if value == tableParts[1] {
					alreadyPresent = true
					break
				}
			}

			if !alreadyPresent {
				tables[tableParts[0]] = append(tables[tableParts[0]], tableParts[1])
			}
		} else {
			tables[tableParts[0]] = append([]string{}, tableParts[1])
		}
	}

	columns := []string{}
	for k, v := range tables {
		columns = append(columns, fmt.Sprintf(`"%s=%s"`, k, strings.Join(v, ",")))
	}

	ctx["col"] = columns
	return datapoints, nil
}

func widecoProviderConfig(serverURL string) *providermodel.ProviderConfigImpl {
	return &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"REP": serverURL,
					"BID": "Måssmyren 18",
					"TZ":  "Europe/Stockholm",
				},
				Operation: map[string]providermodel.Operation{
					"sv": {
						Operation: "sv",
						Params: map[string]interface{}{
							"TZ":  "[TZ]",
							"LTS": true,
						},
					},
				},
				Map: map[string]string{
					"IDT_O1": "14701;PT=0",
					"HUM_O1": "14701;Analog=0",
					"IDT_O2": "14702;PT=0",
					"HUM_O2": "14702;Analog=0",
				},
			},
		},
	}
}

var widecoDatapoints = `[
  {
    "UnitID": 14701,
    "UnitValues": [
      {
        "DataDateTime": "2020-12-11T08:30:21",
        "DataIntrusion": 0,
        "DataBatteryVoltage": 2.9979999,
        "DataInternalTemperature": 0,
        "DataSignalStrength": 0,
        "DataBER": 0
      }
    ],
    "UnitDataAnalog": [
      {
        "AnalogIndex": 0,
        "DataDateTime": "2020-12-11T08:30:21",
        "DataAnalogValue": 29.9
      }
    ],
    "UnitDataPT": [
      {
        "PTIndex": 0,
        "DataDateTime": "2020-12-11T08:30:21",
        "DataPTValue": 20.38
      }
    ]
  },
  {
    "UnitID": 14702,
    "UnitValues": [
      {
        "DataDateTime": "2020-12-11T08:16:23",
        "DataIntrusion": 0,
        "DataBatteryVoltage": 2.9920001,
        "DataInternalTemperature": 0,
        "DataSignalStrength": 0,
        "DataBER": 0
      }
    ],
    "UnitDataAnalog": [
      {
        "AnalogIndex": 0,
        "DataDateTime": "2020-12-11T08:16:23",
        "DataAnalogValue": 32.299999
      }
    ],
    "UnitDataPT": [
      {
        "PTIndex": 0,
        "DataDateTime": "2020-12-11T08:16:23",
        "DataPTValue": 20.31
      }
    ]
  }
]`
