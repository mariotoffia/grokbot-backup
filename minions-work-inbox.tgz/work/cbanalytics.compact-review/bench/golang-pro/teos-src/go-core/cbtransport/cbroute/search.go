package cbroute

import (
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifstorage"
	"github.com/Thiink-LLC/teos/go-core/model/route"
)

// TagSearchMode stipulates how tag search is done.
type TagSearchMode int

const (
	// TagSearchModeAny will return routes that matches at least one of the given tags.
	TagSearchModeAny TagSearchMode = 1
	// TagSearchModeMatchAllInput will return routes that matches all of the given tags.
	// However, there may be additional tags on the route itself.
	TagSearchModeMatchAllInput TagSearchMode = 2
	// TagSearchModeMatchAll will return routes that matches all of the given tags.
	// There must equal amounts of tags on the route as the input.
	TagSearchModeMatchAll TagSearchMode = 3
)

// SearchRoutesByTag will return all routes that matches at least one of the given tags.
//
// Depending on the _mode_ it will match all tags, or only some of the tags.
func SearchRoutesByTag(routes []route.Route, mode TagSearchMode, tags ...string) []route.Route {
	var results []route.Route

	switch mode {
	case TagSearchModeAny:
		results = (&route.RouteTable{Routes: routes}).RouteFromTags(tags...)
	case TagSearchModeMatchAllInput:
		results = (&route.RouteTable{Routes: routes}).RouteFromAllTags(false, tags...)
	case TagSearchModeMatchAll:
		results = (&route.RouteTable{Routes: routes}).RouteFromAllTags(true, tags...)
	default:
		panic("unknown tag search mode")
	}

	return results
}

// SearchRoutesBySourceCtxParameter searches all source route context parameters and matches
// it against the given criteria. The _mode_ determines how the matching is done.
//
// All routes that matches will be returned.
func SearchRoutesBySourceCtxParameter(
	routes []route.Route,
	criteria map[string]string,
	mode route.ParamsMatchMode,
) []route.Route {
	var result []route.Route

	for _, rt := range routes {
		if route.IsMatch(criteria, rt.Source.Ctx, mode) {
			rt := rt
			result = append(result, rt)
		}
	}

	return result
}

// SearchRoutesBySourceParameters searches all source route parameters and matches
// it against the given criteria. The _mode_ determines how the matching is done.
//
// All routes that matches will be returned.
func SearchRoutesBySourceParameters(
	routes []route.Route,
	criteria map[string]string,
	mode route.ParamsMatchMode,
) []route.Route {
	var result []route.Route

	for _, rt := range routes {
		if route.IsMatch(criteria, rt.Source.Prms, mode) {
			rt := rt
			result = append(result, rt)
		}
	}

	return result
}

// SearchRoutesByTarget will search for routes that have the given target.
func SearchRoutesByTarget(routes []route.Route, target string) []route.Route {
	var result []route.Route

	for _, rt := range routes {
		for _, t := range rt.Targets {
			if t.Target == target {
				rt := rt
				result = append(result, rt)
			}
		}
	}

	return result
}

// SearchRoutesByTargetCRD will search for routes that have the given target CRD.
//
// If the _crd_ begins with '$/' the _env_ will not be used as prefix.
// If the _crd_ begins with '$route/' it will prefix the _env_ +
// `ifstorage.TeosPathHttpRouteCredentialsFormat`.
func SearchRoutesByTargetCRD(routes []route.Route, env cbenv.DeployEnv, crd string) []route.Route {
	if !strings.HasPrefix(crd, "$/") {
		crd = "/" + env.String() + crd
	} else {
		crd = crd[1:]
	}

	if strings.HasPrefix(crd, "$route/") {
		crd = env.String() + string(ifstorage.TeosPathHttpRouteCredentialsFormat) + crd[7:]
	}

	var result []route.Route

	for _, rt := range routes {
		for _, t := range rt.Targets {
			if t.Crd == crd {
				rt := rt
				result = append(result, rt)
			}
		}
	}

	return result
}
