package cbtransport

import (
	"io/fs"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// OptServiceEndpointManagerFS will register a `transportmodel.EndpointManager` into
// the `ifcore.ServiceRegistry` named `ifcore.ServiceRegistryEndpointManager`.
//
// .Example Usage
// [source,go]
// ----
// OptServiceEndpointManagerFS(os.DirFS("./endpoints"))
// ----
//
// It is possible to register multiple endpoint managers, hence, build a endpoint
// manager hierarchy.
func OptServiceEndpointManagerFS(f fs.FS) ifcore.CbContextOption {
	return ifcore.CbContextOption{
		Name:     "OptServiceEndpointManagerFS",
		Category: ifcore.CbOptCategoryNewEndpointManager,
		Option: func(c ifcore.CbContext) cberror.Error {
			return ctx.OptServiceRegistry(
				string(ifcore.ServiceRegistryEndpointManager),
				func(
					c ifcore.CbContext,
					reg ifcore.ServiceRegistry,
				) (interface{}, cberror.Error) {
					obj := reg.Get(string(ifcore.ServiceRegistryEndpointManager))
					var parent transportmodel.EndpointManager

					if obj != nil {
						if p, ok := obj.(transportmodel.EndpointManager); ok {
							parent = p
						}
					}

					builder := NewManagerBuilder(c).
						UseParent(parent).
						FromFS(f)

					epm := builder.Build()
					return epm, builder.Error()
				},
			).Option(c)
		},
	}
}

// OptServiceEndpointManagerJSON will register a `transportmodel.EndpointManager` into
// the `ifcore.ServiceRegistry` named `ifcore.ServiceRegistryEndpointManager`.
//
// TIP: The _JSON_ payload may be a single object or an array of endpoint definitions.
//
// It is possible to register multiple endpoint managers, hence, build a endpoint
// manager hierarchy.
func OptServiceEndpointManagerJSON(data []byte) ifcore.CbContextOption {
	return ifcore.CbContextOption{
		Name:     "OptServiceEndpointManagerJSON",
		Category: ifcore.CbOptCategoryNewEndpointManager,
		Option: func(c ifcore.CbContext) cberror.Error {
			return ctx.OptServiceRegistry(
				string(ifcore.ServiceRegistryEndpointManager),
				func(
					c ifcore.CbContext,
					reg ifcore.ServiceRegistry,
				) (interface{}, cberror.Error) {
					obj := reg.Get(string(ifcore.ServiceRegistryEndpointManager))
					var parent transportmodel.EndpointManager

					if obj != nil {
						if p, ok := obj.(transportmodel.EndpointManager); ok {
							parent = p
						}
					}

					builder := NewManagerBuilder(c).
						UseParent(parent).
						FromMultiJSON(data)

					epm := builder.Build()
					return epm, builder.Error()
				},
			).Option(c)
		},
	}
}
