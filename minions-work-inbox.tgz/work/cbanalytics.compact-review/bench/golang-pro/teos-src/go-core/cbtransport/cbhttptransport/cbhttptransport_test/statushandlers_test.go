package cbhttptransport_test

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// TestDefaultStatusHandlerSuccess tests the default status handler for a success
// response. Since the '2*' handler is named _ok_, the default status handler
// should return a success response in the session context.
func TestDefaultStatusHandlerSuccess(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		q, _ := url.QueryUnescape(r.URL.RawQuery)
		_, _ = fmt.Fprintf(w, "returned data: %s", q) //nolint:gosec // G705: test HTTP server, not production
		assert.Equal(t, "/v1/test", r.URL.Path)
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "test",
  "credentials": {"required": ["user", "pass", "apikey"]},
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [
        {
          "path": "/v1/test",
          "params": {"filter": ["['[' + join(rid,',') +']']"]},
          "handler": {"2*": "ok", "*": "fail"}
        }
      ]
    }
  }
}`)

	ctx := newCtx(t)

	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data)

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", false /*parent*/)

	ctxData := map[string]interface{}{
		"test": "extra_data",
	}

	session := transportmodel.NewEndpointSession(ctx, &oper, pc, ctxData, nil /*statusHandlers*/)
	client := ep.NewClient(ctx)

	call := ep.GetCallChain("", false /*parent*/).GetCalls()[0]
	err := client.Invoke(session, call)

	assert.Equal(t, nil, err)
	assert.Equal(
		t,
		"200",
		session.GetSessionContext()[string(transportmodel.SessionContextKeysStatusCode)].(string),
	)
	assert.Equal(t, "extra_data", session.GetSessionContext()["test"].(string))

	assert.True(
		t,
		strings.Contains(
			string(
				session.GetSessionContext()[string(transportmodel.SessionContextKeysBody)].([]byte),
			),
			"returned data: filter=[remote-id",
		),
	)
}

// TestDefaultStatusHandlerFailure tests the default status handler for a failure
// response. The '*' handler is named _fail_  and there's no function associated
// with it. Thus, the default status handler should return a failure response.
func TestDefaultStatusHandlerFail(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "test",
  "credentials": {"required": ["user", "pass", "apikey"]},
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [
        {
          "path": "/v1/test",
          "params": {"filter": ["['[' + join(rid,',') +']']"]},
          "handler": {"2*": "ok", "*": "fail"}
        }
      ]
    }
  }
}`)

	ctx := newCtx(t)

	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data)

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", false /*parent*/)

	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*sessionContext*/
		nil, /*statusHandlers*/
	)
	client := ep.NewClient(ctx)

	call := ep.GetCallChain("", false /*parent*/).GetCalls()[0]
	err := client.Invoke(session, call)

	assert.True(t, err != nil)
	assert.Equal(t, 404, err.Code())

	responseErr, _ := err.(cberror.ResponseError)
	assert.True(t, responseErr != nil)

	assert.Equal(t, 200, responseErr.ExpectedResponseCode())
	assert.Equal(t, "Måssmyren 18", responseErr.Properties()["lid"])
}

// TestCustomStatusHandler tests the ability to register arbitrary amount of
// `transportmodel.StatusHandlerFunc` to do custom processing in code depending
// on the status code. It will always pick the most narrow handler.
func TestCustomStatusHandler(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
		"name": "test",
		"credentials": {"required": ["user", "pass", "apikey"]},
		"baseurl": "[REP]",
		"calls": {
			"default": {
			"chain": [
				{
				"path": "/v1/test",
				"params": {"filter": ["['[' + join(rid,',') +']']"]},
				"handler": {"2*": "ok", "*": "fail", "404": "custom"}
				}
			]
			}
		}
}`)

	ctx := newCtx(t)
	builder := cbtransport.NewManagerBuilder(ctx)

	builder.FromJSON(data).StatusHandler("custom", func(
		session transportmodel.EndpointSession,
		call transportmodel.EndpointCall,
		invoke transportmodel.InvokeArgs) cberror.Error {
		session.GetSessionContext()["custom"] = "custom-func"
		return nil
	})

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", false /*parent*/)

	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*sessionContext*/
		nil, /*statusHandlers*/
	)
	client := ep.NewClient(ctx)

	call := ep.GetCallChain("", false /*parent*/).GetCalls()[0]
	err := client.Invoke(session, call)

	assert.Equal(t, nil, err)
	assert.Equal(t, "custom-func", session.GetSessionContext()["custom"].(string))
}

func TestOverrideCustomStatusHandlerOnEndpointCall(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "test",
  "credentials": {"required": ["user", "pass", "apikey"]},
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [
        {
          "path": "/v1/test",
          "params": {"filter": ["['[' + join(rid,',') +']']"]},
          "handler": {"2*": "ok", "*": "fail", "404": "custom"}
        }
      ]
    }
  }
}`)

	ctx := newCtx(t)
	builder := cbtransport.NewManagerBuilder(ctx)

	builder.FromJSON(data).StatusHandler("custom", func(
		session transportmodel.EndpointSession,
		call transportmodel.EndpointCall,
		invoke transportmodel.InvokeArgs) cberror.Error {
		session.GetSessionContext()["custom"] = "custom-func"
		return nil
	})

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", false /*parent*/)

	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*sessionContext*/
		nil, /*statusHandlers*/
	)
	client := ep.NewClient(ctx)

	call := ep.GetCallChain("", false /*parent*/).GetCalls()[0].Override(
		map[string]transportmodel.StatusHandlerFunc{
			"custom": func(
				session transportmodel.EndpointSession,
				call transportmodel.EndpointCall,
				invoke transportmodel.InvokeArgs) cberror.Error {
				session.GetSessionContext()["custom"] = "custom-func-override"
				return nil
			},
		},
	)

	err := client.Invoke(session, call)

	assert.Equal(t, nil, err)
	assert.Equal(t, "custom-func-override", session.GetSessionContext()["custom"].(string))
}

func TestOverrideCustomStatusHandlerOnEndpointSession(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "test",
  "credentials": {"required": ["user", "pass", "apikey"]},
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [
        {
          "path": "/v1/test",
          "params": {"filter": ["['[' + join(rid,',') +']']"]},
          "handler": {"2*": "ok", "*": "fail", "404": "custom"}
        }
      ]
    }
  }
}`)

	ctx := newCtx(t)
	builder := cbtransport.NewManagerBuilder(ctx)

	builder.FromJSON(data).StatusHandler("custom", func(
		session transportmodel.EndpointSession,
		call transportmodel.EndpointCall,
		invoke transportmodel.InvokeArgs) cberror.Error {
		session.GetSessionContext()["custom"] = "custom-func"
		return nil
	})

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", false /*parent*/)

	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*sessionContext*/
		map[string]transportmodel.StatusHandlerFunc{
			"custom": func(
				session transportmodel.EndpointSession,
				call transportmodel.EndpointCall,
				invoke transportmodel.InvokeArgs) cberror.Error {
				session.GetSessionContext()["custom"] = "custom-func-override"
				return nil
			},
		},
	)
	client := ep.NewClient(ctx)

	call := ep.GetCallChain("", false /*parent*/).GetCalls()[0]
	err := client.Invoke(session, call)

	assert.Equal(t, nil, err)
	assert.Equal(t, "custom-func-override", session.GetSessionContext()["custom"].(string))
}
