package cbroute

import "github.com/Thiink-LLC/teos/go-core/model/route"

// SearchMatchRouteTag is the same function as `SearchRoutesByTag` but it operates on
// a single route to determine if it matches the given tags.
//
// Depending on the _mode_ it will match all tags, or only some of the tags.
func HasTags(rt route.Route, mode TagSearchMode, tags ...string) bool {
	return len(SearchRoutesByTag([]route.Route{rt}, mode, tags...)) != 0
}

// HasSourceCtxParameters checks if the given route has the given context parameters.
func HasSourceCtxParameters(
	rt route.Route,
	criteria map[string]string,
	mode route.ParamsMatchMode,
) bool {
	return route.IsMatch(criteria, rt.Source.Ctx, mode)
}

// HasSourceParameters checks if the given route has the given parameters.
func HasSourceParameters(
	rt route.Route,
	criteria map[string]string,
	mode route.ParamsMatchMode,
) bool {
	return route.IsMatch(criteria, rt.Source.Prms, mode)
}

// HasTarget checks if the given route has the given target.
func HasTarget(rt route.Route, target string) bool {
	for _, t := range rt.Targets {
		if t.Target == target {
			return true
		}
	}

	return false
}

// HasCRD checks if the given route has the given target _CRD_.
func HasCRD(rt route.Route, crd string) bool {
	for _, t := range rt.Targets {
		if t.Crd == crd {
			return true
		}
	}

	return false
}
