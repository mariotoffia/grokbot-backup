package cbhttptransport

import (
	"fmt"
	"io"
	"strconv"
	"time"

	"github.com/PaesslerAG/gval"
	"github.com/hashicorp/go-retryablehttp"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// HttpEndpointClientImpl will process a `HttpEndpoint` along with all
// of the `HttpEndpointCall` instances.
type HttpEndpointClientImpl struct {
	// ep is the actual endpoint to use for communication
	ep     *HttpEndpointImpl
	client *retryablehttp.Client
	lang   gval.Language
}

// Invoke implements the `transportmodel.EndpointClient` interface.
func (epc *HttpEndpointClientImpl) GetEndpoint() transportmodel.Endpoint {
	return epc.ep
}

// Invoke implements the `transportmodel.EndpointClient` interface.
func (epc *HttpEndpointClientImpl) Invoke(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall) cberror.Error {
	// Create the evaluation context
	invokeContext, err := cbtransportutils.CreateInvokeContext(
		epc,
		session,
		call,
		epc.lang,
		&epc.ep.EndpointImpl, /*resolver*/
	)

	if err != nil {
		return err
	}

	decorator, customFlow := epc.resolveDecorator()
	credentials, err := epc.resolveSecurityMaterial(session, call, invokeContext, customFlow)

	if err != nil {
		return err
	}

	var httpDecorator HttpSecurityMaterialDecorator

	if decorator != nil {
		httpDecorator = decorator.(HttpSecurityMaterialDecorator)
	}

	return epc.invoke(
		session, call, invokeContext, httpDecorator, credentials,
	)
}

// invoke will do the actual invocation of the endpoint. It will use the before and after interceptors
// if installed.
//
// If a decorator is passed, it will use the decorator to decorate the request towards the endpoint.
func (epc *HttpEndpointClientImpl) invoke(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
	decorator HttpSecurityMaterialDecorator,
	credentials securitymodel.StandardCredentials,
) cberror.Error {
	var err cberror.Error
	var url, query string
	var headers map[string][]string
	var body []byte

	url, query, headers, body, err = epc.prepareInvocation(session, call, invokeContext)
	if err != nil {
		return err
	}

	var handled bool
	var statusCode string

	args := map[string]any{
		string(transportmodel.InvokeArgsKeyURL):        url,
		string(transportmodel.InvokeArgsKeyQuery):      query,
		string(transportmodel.InvokeArgsKeyCurrentNow): time.Now().UTC().UnixNano(),
	}

	if len(body) > 0 {
		args[string(transportmodel.InvokeArgsKeyBody)] = body
	}

	if len(headers) > 0 {
		args[string(transportmodel.InvokeArgsKeyHeaders)] = headers
	}

	// Interceptor before
	handled, replaceBody, _, replaceHeaders, err := epc.intercept(
		transportmodel.InvokerTypeBefore,
		session,
		call,
		invokeContext,
		args,
	)

	if err != nil {
		return err
	}

	if len(replaceBody) > 0 {
		body = replaceBody
	}

	if len(replaceHeaders) > 0 {
		headers = replaceHeaders
	}

	if !handled {
		var completeUrl string
		if len(query) > 0 {
			completeUrl = fmt.Sprintf("%s?%s", url, query)
		} else {
			completeUrl = url
		}

		// Verify the endpoint is allowed to be invoked
		var verifyConnect transportmodel.VerifyConnectFunc
		if credentials != nil {
			verifyConnect = epc.ep.GetCustomVerifyConnect()
			if verifyConnect == nil {
				verifyConnect = cbtransportutils.VerifyConnect
			}

			if !verifyConnect(epc, session, completeUrl, credentials) {
				lid, _ := cbtransportutils.GetGlobalParamAsString(
					session,
					string(ifprovider.ParameterLocationID),
				)

				return cberror.NewCbErrorConfigurationExecutionErrorf(
					session.GetContext().Service(),
					cberror.ConfigurationErrorTypeEndpointConfigurationURLMismatch,
					0, nil, nil,
					map[string]interface{}{
						"lid": lid,
						"pn":  session.GetContext().Provider(),
					},
					"Connection to %s failed due to restricted to: %s",
					completeUrl,
					credentials.GetEndpoint(),
				)
			}
		}

		// Default Content-Type: application/json if omitted
		if _, ok := headers["Content-Type"]; !ok {
			if headers == nil {
				headers = make(map[string][]string)
			}

			headers["Content-Type"] = []string{"application/json"}
		}

		// Create the request
		req, requestError := epc.ep.NewRequest(
			session,
			call.GetMethod(),
			completeUrl,
			headers,
			body,
		)

		if requestError != nil {
			return requestError
		}

		// Decorate the request
		if err = decorateHttpRequest(session, decorator, credentials, req); err != nil {
			return err
		}

		// Execute the request
		callTime := time.Now().UTC().UnixNano()
		resp, cerr := epc.client.Do(req)

		if callError := checkIfHttpCallError(session, call, url, callTime, cerr); callError != nil {
			return callError
		}

		// Read the response
		defer func() { _ = resp.Body.Close() }()
		dumpResponse(session.GetContext(), session.GetContext().Provider(), resp)

		body, cerr = io.ReadAll(resp.Body)

		if cerr != nil {
			lid, _ := cbtransportutils.GetGlobalParamAsString(
				session,
				string(ifprovider.ParameterLocationID),
			)

			return cberror.NewCbErrorfWithProps(
				session.GetContext().Service(),
				cberror.ErrorTransportInvokeBodyCouldNotBeRead,
				cerr,
				map[string]interface{}{
					"lid": lid,
				},
				"Error reading response body: %s",
				cerr.Error(),
			)
		}

		statusCode = strconv.Itoa(resp.StatusCode)

		if len(body) > 0 {
			args[string(transportmodel.InvokeArgsKeyBody)] = body
		} else {
			delete(args, string(transportmodel.InvokeArgsKeyBody))
		}

		args[string(transportmodel.InvokeArgsKeyStatusCode)] = statusCode
	}

	// Interceptor after
	_, _, _, _, err = epc.intercept(
		transportmodel.InvokerTypeAfter,
		session,
		call,
		invokeContext,
		args,
	)

	if err != nil {
		return err
	}

	// Invoke the status handler (or do default handling)
	return cbtransportutils.InvokeStatusHandlerFunction(
		&epc.ep.EndpointImpl, /*resolver*/
		session,
		call,
		args,
		cbtransportutils.FindStatusHandler(call.GetHandlers(), args),
	)

}
