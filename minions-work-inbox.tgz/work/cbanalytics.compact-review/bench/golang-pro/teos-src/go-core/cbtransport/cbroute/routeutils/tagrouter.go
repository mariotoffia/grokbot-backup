package routeutils

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/route"

	"github.com/rs/zerolog"
)

// GetRoutes will retrieve routes for the _client_.
//
// It will search for any `route.Route`  that matches
// at least one of the given tags. If _all_ is set to
// `true` it *requires* that *all* specified _tags_,
// are present and no more tags exists in the route.
//
// Use the _mode_ to determine how to search for tags.
func GetRoutes(
	ctx ifcore.CbContext,
	client, routeName string,
	mode cbroute.TagSearchMode,
	failLogLevel zerolog.Level,
	routeTags ...string,
) ([]route.Route, cberror.Error) {
	builder := cbroute.NewRouteTableBuilderImpl()

	if err := builder.FromParameterStoreJSON(ctx, routeName); err != nil {
		if log.IsEnabled(failLogLevel) {
			log.Level(ctx, failLogLevel, "" /*lid*/).
				WithDataType(logger.LDTDevOps).
				WithMethod(client).
				WithError(err).
				Str("route", routeName).
				Msg("Unable to get routes.")
		}

		return nil, err
	}

	// Filter out all routes that includes tag account_crawler
	routes := builder.DeleteRoute(func(r route.Route) bool {
		// Delete all routes that do *not* have {tags} int it
		return !cbroute.HasTags(r, mode, routeTags...)
	}).Build().Routes

	return routes, nil
}
