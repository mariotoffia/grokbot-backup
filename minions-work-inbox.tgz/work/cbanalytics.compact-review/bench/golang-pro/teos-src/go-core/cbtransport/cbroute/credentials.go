package cbroute

import (
	"encoding/json"
	"fmt"
	"net/http"
	"path/filepath"
	"sync"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifstorage"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/awsmgrsecstore"
	"github.com/Thiink-LLC/teos/go-core/model/route"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/storagemodel"
	"github.com/Thiink-LLC/teos/go-core/utils/awsutils"

	"github.com/rs/zerolog"
)

// credFmt contains the string version of `ifstorage.TeosPathHttpRouteCredentialsTargetFormat`.
var credFmt = string(ifstorage.TeosPathHttpRouteCredentialsTargetFormat)

// CredentialsCacheImpl is the one reading and writing credentials
// to and from parameter store.
//
// It will cache the credentials in memory. If cache miss
// it will try-load the credentials.
type CredentialsCacheImpl struct {
	// Cache is the actual in-memory cache
	Cache sync.Map
}

// RouteTargetCredentials is a combination of
// a route target and the resolved credentials for the target.
//
// NOTE: Use the `WriteCredentials` to write the credentials to parameter store
// for later use.
type RouteTargetCredentials struct {
	// Target is the target instance
	Target *route.RouteTarget
	// Path is the path to the credentials to use when loading/storing or
	// was loaded using the path.
	Path string
	// Credentials is the resolved credentials for the target
	Credentials *securitymodel.ClientCredentialsMaterial
	// Error represents any error trying to obtain the credentials
	//
	// If this is set, Credentials will be nil and this instance
	// is considered invalid.
	Error cberror.Error
}

// ResolveCredentials will try to resolve `ClientCredentialsMaterial` for the given route.
//
// It will check if a `Crd` exists in the route target. If not, it will default to use
// target _DNS_ or account _ARN_ to resolve the DNS name or the account ID from the _ARN_.
//
// It will the use the `ifstorage.TeosPathHttpRouteCredentialsTargetFormat` and use the
// `routerName` as the format argument and the target DNS name or account ID as the second.
//
// If the target parameter client is present, it will concatenate this to the path, otherwise
// _default_ is used.
//
// CAUTION: The path is *not* prefixed with the deploy environment!
func (cache *CredentialsCacheImpl) ResolveCredentialsPath(
	ctx ifcore.CbContext,
	rt route.Route,
	routerName string,
) []RouteTargetCredentials {
	//
	if routerName == "" {
		return nil
	}

	var results []RouteTargetCredentials

	for _, target := range rt.Targets {
		target := target

		path, err := cache.fromTargetToPath(ctx, &target, routerName)

		results = append(results, RouteTargetCredentials{
			Target: &target,
			Path:   path,
			Error:  err,
		})
	}

	return results
}

// ResolveCredentials will resolve, the unresolved credentials for the given _creds_.
// If the credentials is missing, it will not resolve, instead put an error into the result.
//
// If need to refresh the credentials, set them to `nil` before invoking the function.
//
// CAUTION: A call to `ResolveCredentialsPath` has to bee invoked before this if the Path
// parameter is not set.
func (cache *CredentialsCacheImpl) ResolveCredentials(
	ctx ifcore.CbContext,
	creds []RouteTargetCredentials) []RouteTargetCredentials {
	var (
		store  = awsmgrsecstore.NewParameterStoreImpl(ctx)
		result = make([]RouteTargetCredentials, len(creds))
	)

	for i, c := range creds {
		c := c

		if c.Error != nil {
			result[i] = c

			continue
		}

		if creds, err := cache.resolveCredentials(ctx, store, c.Target.Target, c.Path); err != nil {
			c.Error = err
		} else {
			c.Credentials = creds
			c.Error = nil
		}

		result[i] = c
	}

	return result
}

// DeleteCredentials will delete a credential that do have a
// valid path in _creds_. If it does not have a valid path,
// it will be resolved using `FromTargetToPath` if target is set!
func (cache *CredentialsCacheImpl) DeleteCredentials(
	ctx ifcore.CbContext,
	routerName string,
	creds RouteTargetCredentials) cberror.Error {
	var (
		pmsPath = creds.Path
		err     cberror.Error
	)

	// Resolve the pmsPath
	if pmsPath == "" {
		if creds.Target == nil {
			err = cberror.NewCbErrorf(
				ctx.Service(), http.StatusBadRequest, nil,
				"Missing target and path while trying to delete credentials",
			)
		} else {
			pmsPath, err = cache.fromTargetToPath(ctx, creds.Target, routerName)
		}
	}

	pmsPath = ctx.DeployEnv().EnsureDeployEnvPrefix(pmsPath, "/", "")

	if err != nil {
		return err
	}

	// Delete the credentials
	if pmsPath == "" {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, nil,
			"Missing path while trying to delete credentials",
		)
	}

	store := awsmgrsecstore.NewParameterStoreImpl(ctx)

	store.Delete(ctx, pmsPath)

	return store.Error()
}

// SyncCredentials will synchronize credentials for the given route.
//
// It will iterate the existing ones in the parameter store and compare
// to the _creds_. From that it will calculate which to update, add or remove.
//
// If the _force_ parameter is set, it will overwrite existing credentials. If
// _deleteOrphans_ is set, it will delete orphaned credentials.
//
// If _simulate_ is set, it will not write anything to the parameter store.
func (cache *CredentialsCacheImpl) SyncCredentials(
	ctx ifcore.CbContext,
	routerName string,
	creds []RouteTargetCredentials,
	force, deleteOrphans, simulate bool,
) (
	added []RouteTargetCredentials,
	removed []RouteTargetCredentials,
	updated []RouteTargetCredentials,
	err cberror.Error,
) {
	// Get all credentials in store
	all, err := cache.LoadAllCredentials(ctx, routerName, false /*populateCache*/)

	if err != nil {
		return nil, nil, nil, err
	}

	// Map for fast lookup of existing credentials
	mapAll := make(map[string]RouteTargetCredentials, len(all))

	for i := range all {
		mapAll[all[i].Path] = all[i]
	}

	// Added and updated
	for i := range creds {
		if _, ok := mapAll[creds[i].Path]; ok {
			updated = append(updated, creds[i])
		} else {
			added = append(added, creds[i])
		}

		delete(mapAll, creds[i].Path)
	}

	// Removed
	for _, cred := range mapAll {
		cred := cred
		removed = append(removed, cred)
	}

	if simulate {
		return added, removed, updated, nil
	}

	// Write the added
	for i, cred := range added {
		added[i].Error = cache.storeCredentials(ctx, cred)
	}

	// Write the updated if force is set
	if force {
		for i, cred := range updated {
			updated[i].Error = cache.storeCredentials(ctx, cred)
		}
	} else {
		// Do not return updated since not written
		updated = nil
	}

	// Delete the removed if deleteOrphans is set
	if deleteOrphans {
		for _, cred := range removed {
			_ = cache.DeleteCredentials(ctx, routerName, cred)
		}
	} else {
		// Do not return removed since not deleted
		removed = nil
	}

	return added, removed, updated, nil
}

// LoadAllCredentials will load all credentials for the given router.
//
// If _populateCache_ is set, it will populate the cache with the credentials,
// otherwise it will just do a pass-through.
func (cache *CredentialsCacheImpl) LoadAllCredentials(
	ctx ifcore.CbContext,
	routerName string,
	populateCache bool,
) ([]RouteTargetCredentials, cberror.Error) {
	//
	store := awsmgrsecstore.NewParameterStoreImpl(ctx)

	// Get all Credential Paths
	all := store.GetPath(
		ctx,
		true, /*recurse*/
		ctx.DeployEnv().
			String()+fmt.Sprintf(string(
			ifstorage.TeosPathHttpRouteCredentialsFormat), routerName,
		),
	)

	if store.Error() != nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError, store.Error(),
			"Failed to list credentials for router %s - err: %s",
			routerName, store.Error().Error(),
		)
	}

	credentials := make([]RouteTargetCredentials, len(all))

	for i, crd := range all {
		// Since crd.Path has the deployment environment path set.
		path := ctx.DeployEnv().RemoveDeployEnvPrefix(crd.Path, "/", "") + "/" + crd.Name

		cred, err := cache.MarshalCredentialsFromJSON(ctx, path, crd.ValueAsString())

		if err != nil {
			return nil, err
		}

		credentials[i] = RouteTargetCredentials{
			Path:        path,
			Credentials: cred,
		}
	}

	if populateCache {
		for _, cred := range credentials {
			cache.writeCache(cred.Credentials.Endpoint, cred.Credentials)
		}
	}

	return credentials, nil
}

// StoreCredentials will lookup the path where to store the credentials
// and then stores in into the parameter store.
//
// The returned `RouteTargetCredentials` will contain all parameters including
// error if it fails.
//
// Internally this function uses `FromTargetToPath` and then stores it
// and puts the credentials into cache.
func (cache *CredentialsCacheImpl) StoreCredentials(
	ctx ifcore.CbContext,
	routerName string,
	target *route.RouteTarget,
	credentials *securitymodel.ClientCredentialsMaterial,
) RouteTargetCredentials {
	// Resolve the pmsPath
	pmsPath, err := cache.fromTargetToPath(ctx, target, routerName)

	creds := *credentials

	if creds.Endpoint == "" {
		creds.Endpoint = cache.fromTargetToEndpoint(ctx, target)
	}

	rtc := RouteTargetCredentials{
		Target:      target,
		Path:        pmsPath,
		Credentials: &creds,
		Error:       err,
	}

	if err != nil {
		return rtc
	}

	rtc.Error = cache.storeCredentials(ctx, rtc)

	// Cache the credentials
	if rtc.Error == nil {
		cache.writeCache(rtc.Path, rtc.Credentials)
	}

	return rtc
}

// CreateCredentialsFromJSON creates `securitymodel.ClientCredentialsMaterial`
// from a _JSON_ string.
//
// (The _path_ parameter is just for error reporting.)
func (cache *CredentialsCacheImpl) MarshalCredentialsFromJSON(
	ctx ifcore.CbContext,
	path, creds string) (*securitymodel.ClientCredentialsMaterial, cberror.Error) {
	//
	var credentials securitymodel.ClientCredentialsMaterial

	if err := json.Unmarshal([]byte(creds), &credentials); err != nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError, err,
			"Failed to unmarshal credentials for path: %s", path,
		)
	}

	return &credentials, nil
}

// storeCredentials is a internal function to actual perform the
// storing of credentials to pms
//
// It will make sure that the path is prefixed with the deploy environment.
func (cache *CredentialsCacheImpl) storeCredentials(
	ctx ifcore.CbContext,
	creds RouteTargetCredentials) cberror.Error {
	//
	if creds.Path == "" {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, nil,
			"Missing path for target",
		)
	}

	js, je := json.Marshal(creds.Credentials)

	if je != nil {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, je,
			"Failed to marshal credentials for path: %s", creds.Path,
		)
	}

	store := awsmgrsecstore.NewParameterStoreImpl(ctx)
	pmsPath := ctx.DeployEnv().EnsureDeployEnvPrefix(creds.Path, "/", "")

	store.Write(ctx, true /*force*/, storagemodel.SecureStorageObject{
		Name:        filepath.Base(pmsPath),
		Path:        filepath.Dir(pmsPath),
		DataType:    storagemodel.DataTypeString,
		IsEncrypted: true,
		Value:       string(js),
	})

	return store.Error()
}

// resolveCredentials will resolve the credentials for the given path.
// (The _target_ parameter is just for error message handling)
//
// It will check the cache, if miss, it will try to load it and if successful
// add it to the cache.
func (cache *CredentialsCacheImpl) resolveCredentials(
	ctx ifcore.CbContext,
	store ifstorage.SecurityStorage,
	target, path string,
) (*securitymodel.ClientCredentialsMaterial, cberror.Error) {
	//
	if path == "" {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, nil,
			"Missing path for target %s", target,
		)
	}

	if cred, ok := cache.readCache(path); ok {
		return cred, nil
	}

	objects := store.Get(ctx, ctx.DeployEnv().EnsureDeployEnvPrefix(path, "/", ""))

	if len(objects) == 0 {
		if store.Error() != nil {
			return nil, store.Error()
		}

		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusNotFound, nil,
			"Missing credentials for path %s", path,
		)
	}

	if len(objects) != 1 {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, nil,
			"Expected exactly one object for path %s, got %d", path, len(objects),
		)
	}

	crd, err := cache.MarshalCredentialsFromJSON(ctx, path, objects[0].ValueAsString())

	// Cache the credentials
	if crd != nil {
		cache.writeCache(path, crd)
	}

	return crd, err
}

// fromTargetToEndpoint will resolve a endpoint from a target, it
// may be a DNS name or an account ID.
//
// If it cannot resolve, a empty string is returned.
func (cache *CredentialsCacheImpl) fromTargetToEndpoint(
	ctx ifcore.CbContext,
	target *route.RouteTarget,
) string {
	if target == nil || target.Target == "" {
		return ""
	}

	// Use target to resolve the credentials
	trg, _ := awsutils.IsAccountArn(target.Target)

	if trg == "" {
		// Assume DNS
		trg = target.Target
	}

	return trg
}

// fromTargetToPath will resolve a single _target_ into a path.
//
// If it fails, it will return an error. If no error but no
// path was resolved, the _path_ parameter is empty.
//
// NOTE: This path is *not* prefixed with the deployment environment!
func (cache *CredentialsCacheImpl) fromTargetToPath(
	ctx ifcore.CbContext,
	target *route.RouteTarget,
	routerName string,
) (string, cberror.Error) {
	if target.Crd != "" {
		return target.Crd, nil
	}

	trg := cache.fromTargetToEndpoint(ctx, target)

	if trg == "" {
		return "", nil
	}

	// Resolve the CRD key in pms
	path, err := awsutils.ToParameterStoreCompatibleKeyName(
		ctx, fmt.Sprintf(credFmt, routerName, trg)+"default",
	)

	if log.IsEnabled(zerolog.TraceLevel) {
		log.Trace(ctx).
			WithDataType(logger.LDTDeveloper).
			Str("router", routerName).
			Str("target", trg).
			Str("path", path).
			Msg("Resolved credentials path")
	}

	if err != nil {
		return "", err
	}

	return path, nil
}

// readCache is a thread safe read from cache.
func (cache *CredentialsCacheImpl) readCache(
	path string,
) (*securitymodel.ClientCredentialsMaterial, bool) {
	//
	value, ok := cache.Cache.Load(path)
	if ok {
		if value != nil {
			if v, ok := value.(*securitymodel.ClientCredentialsMaterial); ok {
				return v, true
			}
		}
	}
	return nil, false
}

// writeCache is thread safe write to the cache.
func (cache *CredentialsCacheImpl) writeCache(
	path string,
	value *securitymodel.ClientCredentialsMaterial,
) {
	cache.Cache.Store(path, value)
}
