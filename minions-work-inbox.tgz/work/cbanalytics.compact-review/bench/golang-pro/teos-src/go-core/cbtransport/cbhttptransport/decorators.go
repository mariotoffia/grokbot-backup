package cbhttptransport

import (
	"encoding/base64"
	"errors"
	"fmt"

	"github.com/hashicorp/go-retryablehttp"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// NewBasicAuthDecorator creates a new `HttpSecurityDecorator` that adds basic auth to the request into
// the _Authorization_ header.
func NewBasicAuthDecorator() *HttpSecurityMaterialDecoratorImpl {
	return &HttpSecurityMaterialDecoratorImpl{
		DecorateFunc: func(ctx ifcore.CbContext, req *retryablehttp.Request, credentials securitymodel.StandardCredentials) error {
			req.Header.Add(
				"Authorization",
				fmt.Sprintf(
					"Basic %s",
					base64.StdEncoding.EncodeToString(
						[]byte(
							fmt.Sprintf("%s:%s", credentials.GetUser(), credentials.GetPassword()),
						),
					),
				),
			)

			return errors.New("expecting StandardCredentials")
		},
	}
}

func (epc *HttpEndpointClientImpl) resolveDecorator() (decorator transportmodel.SecurityMaterialDecorator, customFlow bool) {
	switch securitymodel.WellknownAuthenticationFlow(epc.ep.Credentials.AuthenticationFlow) {
	case securitymodel.WellknownAuthenticationFlowBasicAuth:
		decorator = NewBasicAuthDecorator()
	case securitymodel.WellknownAuthenticationFlowNone:
		break
	default:
		decorator = epc.ep.ResolveSecurityMaterialDecorator(true)
		customFlow = true
	}

	return
}
