package cbhttptransport_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbhttptransport"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

func TestSingleHttpCall(t *testing.T) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]
	res := 0

	ep := cbhttptransport.HttpEndpointImpl{
		EndpointImpl: transportmodel.EndpointImpl{
			Name: "", /*default endpoint*/
			Credentials: securitymodel.CredentialConfig{
				Type: securitymodel.CredentialsTypeToken,
				Required: []securitymodel.CredentialItemType{
					securitymodel.CredentialItemTypeUsername,
					securitymodel.CredentialItemTypePassword,
				},
			},
			BaseURL: "[REP]",
			Functions: transportmodel.EndPointFunctions{
				StatusHandlers: map[string]transportmodel.StatusHandlerFunc{
					"fail": func(
						session transportmodel.EndpointSession,
						call transportmodel.EndpointCall,
						invoke transportmodel.InvokeArgs) cberror.Error {
						res = 1
						return nil
					},
					"ok": func(
						session transportmodel.EndpointSession,
						call transportmodel.EndpointCall,
						invoke transportmodel.InvokeArgs) cberror.Error {
						res = 2
						return nil
					},
				},
			},
		},
	}

	call := transportmodel.EndpointCallImpl{
		Direction: locationmodel.ProviderOperationSensorValueIn,
		Path:      "[REP + '/api/v2/test']",
		Params: map[string][]string{
			"filter": {"'[' + join(sensors) + ']'"},
		},
		StatusHandlers: map[string]string{"2*": "ok", "*": "fail"},
	}

	ctx := newCtx(t)
	ctxData := map[string]interface{}{
		"test": "extra_data",
	}

	session := transportmodel.NewEndpointSession(ctx, &oper, pc, ctxData, nil /*statusHandlers*/)
	client := ep.NewClient(ctx)

	err := client.Invoke(session, &call)

	assert.Equal(t, nil, err)
	assert.Equal(t, 2, res)

}
