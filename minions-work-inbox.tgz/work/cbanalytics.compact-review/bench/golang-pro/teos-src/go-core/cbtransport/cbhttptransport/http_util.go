package cbhttptransport

import (
	"errors"

	"github.com/hashicorp/go-retryablehttp"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil"
)

// decorateHttpRequest will decorate the _req_ if any decorators are present.
func decorateHttpRequest(
	session transportmodel.EndpointSession,
	decorator HttpSecurityMaterialDecorator,
	credentials securitymodel.StandardCredentials,
	req *retryablehttp.Request,
) cberror.Error {
	if decorator == nil {
		return nil
	}

	if err := decorator.Decorate(session.GetContext(), req, credentials); err != nil {
		var cerr cberror.Error
		if errors.As(err, &cerr) {
			return cerr
		}

		lid, _ := cbtransportutils.GetGlobalParamAsString(
			session,
			string(ifprovider.ParameterLocationID),
		)

		return cberror.NewCbErrorfWithProps(
			session.GetContext().Service(),
			1,
			err,
			map[string]interface{}{
				"lid": lid,
			},
			"Failed to decorate request",
		)
	}

	return nil
}

// checkIfHttpCallError will check if a error did occur in the http call (returned by http.Do).
//
// NOTE: It will not examine the response body or headers. It will ony check if error
//
//	is flagged and determine the root cause.
func checkIfHttpCallError(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	url string,
	callTime int64,
	httpError error,
) cberror.Error {

	return httputil.HttpCallErrorToError(
		session.GetContext(),
		string(call.GetMethod()),
		url,
		callTime,
		httpError,
	)
}
