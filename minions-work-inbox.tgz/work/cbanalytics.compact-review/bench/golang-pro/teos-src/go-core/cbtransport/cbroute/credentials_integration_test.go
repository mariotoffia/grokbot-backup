//go:build integration

package cbroute_test

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/model/route"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestCreateResolveAndDeleteCredentialForOneTarget(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestCreateResolveAndDeleteCredentialForOneTarget in short mode")
	}

	testenv.Use(t, testenv.EnvUsingManualAWSResources)

	ctx := newCtx(t)
	cache := &cbroute.CredentialsCacheImpl{}
	routeName := utils.RandomPostfix("route")

	res := cache.StoreCredentials(
		ctx,
		routeName,
		&route.RouteTarget{Target: "devlocal05.thiink.systems", Crd: ""},
		&securitymodel.ClientCredentialsMaterial{
			ClientId:     "the-id",
			ClientSecret: "pelle",
			Key:          "test-key",
		},
	)

	require.NotNil(t, res)
	require.NoError(t, res.Error)

	defer func() { assert.NoError(t, cache.DeleteCredentials(ctx, routeName, res)) }()

	// Since no path, it should resolve it from target
	cleanCache := &cbroute.CredentialsCacheImpl{}

	time.Sleep(3 * time.Second) // Give pms a bit of time

	// Resolve paths for the credentials
	creds := cleanCache.ResolveCredentialsPath(ctx, route.Route{
		Targets: []route.RouteTarget{
			{Target: "devlocal05.thiink.systems", Crd: ""},
		},
	}, routeName)

	// Resolve the actual credentials
	creds = cleanCache.ResolveCredentials(ctx, creds)

	require.Len(t, creds, 1)
	assert.NoError(t, creds[0].Error)
	require.NotNil(t, creds[0].Credentials)
	assert.Equal(t, "the-id", creds[0].Credentials.ClientId)
	assert.Equal(t, "pelle", creds[0].Credentials.ClientSecret)
	assert.Equal(t, "test-key", creds[0].Credentials.Key)
}
