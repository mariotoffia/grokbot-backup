package routeutils

import (
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/route"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil/editors"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil/httpauth"
)

// HttpClientRouteTarget is returned by the `PrepareClients` function.
type HttpClientRouteTarget struct {
	// A fully prepared client.
	Client *httputil.HttpRequestDoerImpl
	// Target DNS name to invoke.
	Target string
}

// PrepareClients will take a route, make sure to client to do
// communication with the route target(s).
//
// Each target of a route is one TEOS deployment, named by its account domain
// such as `devlocal02.thiink.systems`. Both clients built for a target, the one
// that fetches the access token and the one that carries the calls, are scoped
// to that account domain. A client scoped to one deployment sends nothing to
// another, so a route with several targets cannot authenticate against one
// deployment and then call a second with the token.
//
// A target that cannot be prepared is left out of the result and the reason is
// logged. The result therefore holds one entry per target that is ready to use,
// which may be fewer entries than the route has targets.
func PrepareClients(
	ctx ifcore.CbContext,
	route route.Route,
	client, routeName string,
	cache *cbroute.CredentialsCacheImpl,
) ([]HttpClientRouteTarget, cberror.Error) {
	// Get the credentials for the route
	creds := cache.ResolveCredentialsPath(ctx, route, routeName)
	creds = cache.ResolveCredentials(ctx, creds)

	var validCreds []cbroute.RouteTargetCredentials

	// Ensure credentials is sane
	for _, crd := range creds {
		if crd.Error != nil {
			log.Warn(ctx).
				WithDataType(logger.LDTDevOps).
				WithMethod(client).
				WithError(crd.Error).
				Str("route", routeName).
				Str("target", crd.Target.Target).
				Msg("Invalid credentials (skipping)")

			continue
		}

		if crd.Credentials == nil ||
			crd.Credentials.ClientId == "" ||
			crd.Credentials.ClientSecret == "" {
			log.Warn(ctx).
				WithDataType(logger.LDTDevOps).
				WithMethod(client).
				Str("route", routeName).
				Str("target", crd.Target.Target).
				Msg("Invalid credentials non existent or bad client id/secret (skipping)")
		} else {
			validCreds = append(validCreds, crd)
		}
	}

	if len(validCreds) == 0 {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadGateway, nil,
			"no credentials found for route",
		)
	}

	targets := make([]HttpClientRouteTarget, 0, len(validCreds))

	for _, cred := range validCreds {
		target := cred.Target.Target

		// Every client built here speaks to this target's deployment and to no
		// other, so the client that fetches the access token is built inside the
		// loop as well. One client reused across targets would ask the first
		// target's login host for a token meant for the second.
		authClient, authClientErr := httputil.NewClient(ctx, client, httputil.WithAccountDomain(target))

		if authClientErr != nil {
			log.Warn(ctx).
				WithDataType(logger.LDTDevOps).
				WithMethod(client).
				WithError(authClientErr).
				Str("route", routeName).
				Str("target", target).
				Msg("Unable to build the client that fetches the access token (skipping)")

			continue
		}

		// Authenticate the client
		token, err := authClient.Authenticate(ctx,
			target,
			*cred.Credentials,
			httpauth.TeosAPI(),
		)

		if err != nil {
			log.Warn(ctx).
				WithDataType(logger.LDTDevOps).
				WithMethod(client).
				WithError(err).
				Str("route", routeName).
				Str("target", target).
				Msg("Unable to authenticate client")

			continue
		}

		// Create and configure the HTTP client
		clientOptions := []httputil.ClientOption{httputil.WithAccountDomain(target)}

		// Has API Key -> Add request editor
		if cred.Credentials.Key != "" {
			apiKey, _ := editors.NewSecurityProviderApiKey(
				"header", "x-api-key",
				cred.Credentials.Key,
			)

			clientOptions = append(clientOptions, httputil.WithRequestEditorFn(apiKey.Intercept))
		}

		// ******
		bearer, _ := editors.NewSecurityProviderBearerToken(token.AccessToken)
		clientOptions = append(clientOptions, httputil.WithRequestEditorFn(bearer.Intercept))

		targetClient, targetClientErr := httputil.NewClient(ctx, client, clientOptions...)

		if targetClientErr != nil {
			log.Warn(ctx).
				WithDataType(logger.LDTDevOps).
				WithMethod(client).
				WithError(targetClientErr).
				Str("route", routeName).
				Str("target", target).
				Msg("Unable to build the client that calls the target (skipping)")

			continue
		}

		// Set the authenticated domain
		targetClient.AuthenticatedDomain = target

		targets = append(targets, HttpClientRouteTarget{
			Client: targetClient,
			Target: target,
		})
	}

	return targets, nil
}
