package cbroute_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// selfAccountDomain is the account domain the routes in these tests belong to.
// A route whose source names this domain is a route out of this account, and
// every other source in the fixtures belongs to someone else.
const selfAccountDomain = "devlocal02.thiink.systems"

// selfAccountID is the AWS account number these tests run as. Route matching
// reads it, so it has to have a value, and no request is ever sent to it.
const selfAccountID = "033549287452"

// testAssign creates a context to resolve routes in, with the account domain
// and account number the fixtures are written against.
//
// It is possible to populate the CallContext with the given parameters.
func testAssign(t testing.TB, callCtxParams ...map[string]string) ifcore.CbContext {
	t.Helper()

	testenv.Use(t, testenv.EnvDefaults)

	t.Setenv(string(cbenv.CB_ACCOUNT_DOMAIN), selfAccountDomain)
	t.Setenv(string(cbenv.AWS_ACCOUNT_ID), selfAccountID)

	c, _ := ctx.NewContext(
		"test-svc", "test", cbenv.DevLocal,
		true /*sort*/, ctx.OptAWSConfigLoadDefault(),
	)

	if len(callCtxParams) == 1 {
		c.PushCallContext(&coremodel.CallContext{
			ContextParams: callCtxParams[0],
		})
	}

	return c
}

func TestNoSrcWithCorrectContextParamsShallReturnRoute(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(testAssign(t), []byte(`{
		"routes": [
			{
				"source": {
					"ctx": {
						"contracted_customer": "bravida"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 1, len(routes), "Expected one route got %d", len(routes))
}

func TestMatchMultipleParametersAreOrTogether(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "plus",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(testAssign(t), []byte(`{
		"routes": [
			{
				"source": {
					"ctx": {
						"contracted_customer": ["nisse-pisse-ab","bravida","plus"]
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Len(t, routes, 1)

	ctx = testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "missing-in-action",
	})

	routes = r.ResolveRoutes(ctx, nil /*params*/)

	assert.Len(t, routes, 0)
}

func TestMatchMultipleParametersWithSomeRegexp(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida_denmark",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(testAssign(t), []byte(`{
		"routes": [
			{
				"source": {
					"ctx": {
						"contracted_customer": ["nisse-pisse-ab","regex://bravida_.*","plus"]
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 1, len(routes), "Expected one route got %d", len(routes))
}

func TestMySrcWithCorrectContextParamsShallReturnRoute(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(testAssign(t), []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 1, len(routes), "Expected one route got %d", len(routes))
}

func TestNotMySrcWithCorrectContextParamsShallReturnNoRoute(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(testAssign(t), []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal14.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 0, len(routes), "Expected zero routes got %d", len(routes))
}

func TestFromJSONWithMalformedJSON(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(
		ctx,
		[]byte(
			`{"routes": [{"source": {"src": "devlocal02.thiink.systems", "ctx": {"contracted_customer": "bravida"}}, "target": {"host": "devlocal03.thiink.systems"}}]`,
		),
	)

	require.Error(t, err)
	assert.Contains(t, err.Error(), "Failed to unmarshal JSON")
}

func TestFromJSONWithEmptyJSON(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(``))

	require.Error(t, err)
	assert.Contains(t, err.Error(), "JSON is empty")
}
