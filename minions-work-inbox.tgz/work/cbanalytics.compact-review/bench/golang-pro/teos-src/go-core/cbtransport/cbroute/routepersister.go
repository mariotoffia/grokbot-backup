package cbroute

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifstorage"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/awsmgrsecstore"
	"github.com/Thiink-LLC/teos/go-core/model/route"
	"github.com/Thiink-LLC/teos/go-core/model/storagemodel"
)

type RoutePersisterImpl struct {
	// The name of the route.
	RouteName string
	// SplitSize is the size when it starts to split the route
	// table into rows -> individual parameters.
	//
	// Defaults to 4096 of less than 512. Max value is 4096
	SplitSize int
}

func (rp *RoutePersisterImpl) RenderParameterStorePath(ctx ifcore.CbContext) string {
	return "/" + ctx.DeployEnv().
		String() +
		fmt.Sprintf(
			string(ifstorage.TeosPathHttpRouteTableFormat),
			rp.RouteName,
		)
}

// validate validates the route persister.
func (rp *RoutePersisterImpl) validate(ctx ifcore.CbContext) cberror.Error {
	if rp.RouteName == "" {
		return cberror.NewCbErrorf(ctx.Service(), http.StatusBadRequest, nil, "routeName is empty")
	}

	if rp.SplitSize < 512 {
		rp.SplitSize = 4096
	}

	if rp.SplitSize > 4096 {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, nil,
			"splitSize is too large (max 4096), got %d", rp.SplitSize,
		)
	}

	return nil
}

// CleanRouteTableInParameterStore clears an entire route table.
func (rp *RoutePersisterImpl) CleanRouteTableInParameterStore(
	ctx ifcore.CbContext,
) cberror.Error {
	if err := rp.validate(ctx); err != nil {
		return err
	}

	store := awsmgrsecstore.NewParameterStoreImpl(ctx)
	path := rp.RenderParameterStorePath(ctx)

	paths := store.List(ctx, false /*recurse*/, path)

	if store.Error() != nil {
		return store.Error()
	}

	store.Delete(ctx, paths...)

	return store.Error()
}

// LoadRouteFromParameterStore will load the route table from the given JSON stored in the parameter store.
//
// If table is large, is is split up into several parameters, named table0-n. If just single, it uses the table0 parameter.
//
// Use appropriate routeName such as _management_.
func (rp *RoutePersisterImpl) LoadRouteFromParameterStore(
	ctx ifcore.CbContext,
) ([]route.Route, cberror.Error) {
	if err := rp.validate(ctx); err != nil {
		return nil, err
	}

	store := awsmgrsecstore.NewParameterStoreImpl(ctx)
	path := rp.RenderParameterStorePath(ctx)
	tables := store.GetPath(ctx, false /*recurse*/, path)

	if store.Error() != nil {
		return nil, store.Error()
	}

	if len(tables) == 0 {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusNotFound, nil,
			"No route table found for routeName: %s", rp.RouteName,
		)
	}

	if len(tables) > 1 {
		// Multi JSON - need to read row by row.
		var routes []route.Route

		for _, table := range tables {
			var route route.Route

			if err := json.Unmarshal([]byte(table.ValueAsString()), &route); err != nil {
				return nil, cberror.NewCbErrorf(
					ctx.Service(),
					http.StatusInternalServerError,
					err,
					"Failed to unmarshal JSON: %s",
					err.Error(),
				)
			}

			routes = append(routes, route)
		}

		return routes, nil
	}

	// Single JSON - just read it.
	var routes []route.Route

	if err := json.Unmarshal([]byte(tables[0].ValueAsString()), &routes); err != nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusInternalServerError,
			err,
			"Failed to unmarshal JSON: %s",
			err.Error(),
		)
	}

	return routes, nil
}

// PersistRoutesInParameterStore will persist the given routes in the parameter store.
//
// If the route is larger than 4KB, it will be split up into several parameters, named table0-n.
func (rp *RoutePersisterImpl) PersistRoutesInParameterStore(
	ctx ifcore.CbContext,
	routes []route.Route,
) cberror.Error {
	if err := rp.validate(ctx); err != nil {
		return err
	}

	var (
		store = awsmgrsecstore.NewParameterStoreImpl(ctx)
		path  = rp.RenderParameterStorePath(ctx)
		write []storagemodel.SecureStorageObject
	)

	if json, err := json.Marshal(routes); err != nil {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError, err,
			"Failed to marshal route table",
		)
	} else if len(json) < rp.SplitSize {
		// If less than SplitSize -> store all in one.
		write = append(write, storagemodel.SecureStorageObject{
			Path:     path,
			Name:     "table0",
			DataType: storagemodel.DataTypeString,
			Value:    string(json),
		})
	}

	if len(write) == 0 {
		// Split each route into a separate parameter.
		for i, route := range routes {
			if json, err := json.Marshal(route); err != nil {
				return cberror.NewCbErrorf(
					ctx.Service(), http.StatusInternalServerError, err,
					"Failed to marshal route %d", i,
				)
			} else {
				write = append(write, storagemodel.SecureStorageObject{
					Path:     path,
					Name:     fmt.Sprintf("table%d", i),
					DataType: storagemodel.DataTypeString,
					Value:    string(json),
				})
			}
		}
	}

	if len(write) == 0 {
		return nil
	}

	// Delete all existing parameters.
	if err := rp.CleanRouteTableInParameterStore(ctx); err != nil {
		return err
	}

	for _, table := range write {
		store.Write(ctx, true /*force*/, table)

		if err := store.Error(); err != nil {
			return cberror.NewCbErrorf(
				ctx.Service(), http.StatusInternalServerError, err,
				"Failed to persist route table",
			)
		}
	}

	return store.Error()
}
