package cbroute_test

import (
	"reflect"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/model/route"
)

func TestAddContextParameterToRouteNilContext(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Src:  "",
			Ctx:  nil,
			Prms: nil,
		},
	}

	key := "param1"
	value := "value1"

	cbroute.AddContextParameterToRoute(r, key, value)

	if r.Source.Ctx == nil {
		t.Errorf("Expected Ctx to be initialized, but got nil")
	}

	if len(r.Source.Ctx) != 1 {
		t.Errorf("Expected Ctx to have one entry, but got %d", len(r.Source.Ctx))
	}

	if r.Source.Ctx[key] != value {
		t.Errorf("Expected Ctx[%s] to be %v, but got %v", key, value, r.Source.Ctx[key])
	}
}

func TestAddContextParameterToRouteNewKey(t *testing.T) {
	existingKey := "existingParam"
	existingValue := "existingValue"

	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]any{
				existingKey: existingValue,
			},
		},
	}

	newKey := "newParam"
	newValue := "newValue"

	cbroute.AddContextParameterToRoute(r, newKey, newValue)

	if len(r.Source.Ctx) != 2 {
		t.Errorf("Expected Ctx to have two entries, but got %d", len(r.Source.Ctx))
	}

	if r.Source.Ctx[newKey] != newValue {
		t.Errorf("Expected Ctx[%s] to be %v, but got %v", newKey, newValue, r.Source.Ctx[newKey])
	}

	if r.Source.Ctx[existingKey] != existingValue {
		t.Errorf(
			"Expected Ctx[%s] to be %v, but got %v",
			existingKey,
			existingValue,
			r.Source.Ctx[existingKey],
		)
	}
}

func TestAddContextParameterToRouteExistingKeySingleValue(t *testing.T) {
	key := "param"
	firstValue := "firstValue"
	secondValue := "secondValue"

	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]any{
				key: firstValue,
			},
		},
	}

	cbroute.AddContextParameterToRoute(r, key, secondValue)

	storedValue, ok := r.Source.Ctx[key].([]any)
	if !ok {
		t.Fatalf("Expected Ctx[%s] to be a slice, but got %T", key, r.Source.Ctx[key])
	}

	if len(storedValue) != 2 {
		t.Fatalf("Expected Ctx[%s] to have two entries, but got %d", key, len(storedValue))
	}

	if storedValue[0] != firstValue || storedValue[1] != secondValue {
		t.Errorf(
			"Expected Ctx[%s] to be [%v, %v], but got %v",
			key,
			firstValue,
			secondValue,
			storedValue,
		)
	}
}

func TestAddContextParameterToRouteExistingKeySliceValue(t *testing.T) {
	key := "param"
	existingValues := []any{"value1", "value2"} //nolint:prealloc
	newValue := "value3"

	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]any{
				key: existingValues,
			},
		},
	}

	cbroute.AddContextParameterToRoute(r, key, newValue)

	storedValue, ok := r.Source.Ctx[key].([]any)
	if !ok {
		t.Fatalf("Expected Ctx[%s] to be a slice, but got %T", key, r.Source.Ctx[key])
	}

	expectedValues := append(existingValues, newValue) //nolint:gocritic

	if len(storedValue) != len(expectedValues) {
		t.Fatalf(
			"Expected Ctx[%s] to have %d entries, but got %d",
			key,
			len(expectedValues),
			len(storedValue),
		)
	}

	for i, v := range expectedValues {
		if storedValue[i] != v {
			t.Errorf("Expected Ctx[%s][%d] to be %v, but got %v", key, i, v, storedValue[i])
		}
	}
}

func TestAddContextParameterToRouteNilValue(t *testing.T) {
	key := "param"

	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]any{},
		},
	}

	cbroute.AddContextParameterToRoute(r, key, nil)

	if len(r.Source.Ctx) != 0 {
		t.Fatalf("Expected Ctx to have zero entry, but got %d", len(r.Source.Ctx))
	}

	if _, ok := r.Source.Ctx[key]; ok {
		t.Errorf("Expected Ctx[%s] to be be found, but got %v", key, r.Source.Ctx[key])
	}
}

func TestAddContextParameterToRouteComplexValue(t *testing.T) {
	key := "param"
	value := map[string]any{
		"nestedKey1": "nestedValue1",
		"nestedKey2": 42,
	}

	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]any{},
		},
	}

	cbroute.AddContextParameterToRoute(r, key, value)

	storedValue, ok := r.Source.Ctx[key].(map[string]any)
	if !ok {
		t.Fatalf("Expected Ctx[%s] to be a map, but got %T", key, r.Source.Ctx[key])
	}

	if len(storedValue) != len(value) {
		t.Fatalf(
			"Expected Ctx[%s] to have %d entries, but got %d",
			key,
			len(value),
			len(storedValue),
		)
	}

	for k, v := range value {
		if storedValue[k] != v {
			t.Errorf("Expected Ctx[%s][%s] to be %v, but got %v", key, k, v, storedValue[k])
		}
	}
}

func TestRemoveContextParameterFromRouteCtxNil(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: nil,
		},
	}

	key := "param"
	value := "value"

	result := cbroute.RemoveContextParameterFromRoute(r, key, value)

	if result {
		t.Errorf("Expected RemoveContextParameterFromRoute to return false when Ctx is nil")
	}

	if r.Source.Ctx != nil {
		t.Errorf("Expected Ctx to remain nil, but got %v", r.Source.Ctx)
	}
}

func TestRemoveContextParameterFromRouteKeyDoesNotExist(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"existingKey": "existingValue",
			},
		},
	}

	keyToRemove := "nonExistingKey"
	valueToRemove := "value"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if result {
		t.Errorf("Expected RemoveContextParameterFromRoute to return false when key does not exist")
	}

	if _, ok := r.Source.Ctx[keyToRemove]; ok {
		t.Errorf("Expected key %s to not exist in Ctx, but it does", keyToRemove)
	}

	if len(r.Source.Ctx) != 1 || r.Source.Ctx["existingKey"] != "existingValue" {
		t.Errorf("Expected Ctx to remain unchanged, but got %v", r.Source.Ctx)
	}
}

func TestRemoveContextParameterFromRouteValueDoesNotMatch(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"key": "existingValue",
			},
		},
	}

	keyToRemove := "key"
	valueToRemove := "nonMatchingValue"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if result {
		t.Errorf(
			"Expected RemoveContextParameterFromRoute to return false when value does not match",
		)
	}

	if len(r.Source.Ctx) != 1 || r.Source.Ctx[keyToRemove] != "existingValue" {
		t.Errorf("Expected Ctx to remain unchanged, but got %v", r.Source.Ctx)
	}
}

func TestRemoveContextParameterFromRouteSingleValueKeyExists(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"key": "valueToRemove",
			},
		},
	}

	keyToRemove := "key"
	valueToRemove := "valueToRemove"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if !result {
		t.Errorf(
			"Expected RemoveContextParameterFromRoute to return true when key exists and values match",
		)
	}

	if _, ok := r.Source.Ctx[keyToRemove]; ok {
		t.Errorf("Expected key %s to be removed from Ctx, but it still exists", keyToRemove)
	}
}

func TestRemoveContextParameterFromRouteArrayValueKeyExistsMultipleElements(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"key": []any{"value1", "valueToRemove", "value2"},
			},
		},
	}

	keyToRemove := "key"
	valueToRemove := "valueToRemove"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if !result {
		t.Errorf(
			"Expected RemoveContextParameterFromRoute to return true when key exists, values match, and value is an array",
		)
	}

	if len(r.Source.Ctx) != 1 {
		t.Fatalf("Expected Ctx to have one entry, but got %d", len(r.Source.Ctx))
	}

	updatedValue, ok := r.Source.Ctx[keyToRemove].([]any)
	if !ok {
		t.Fatalf(
			"Expected Ctx[%s] to be an array, but got %T",
			keyToRemove,
			r.Source.Ctx[keyToRemove],
		)
	}

	expectedValue := []any{"value1", "value2"}
	if !reflect.DeepEqual(updatedValue, expectedValue) {
		t.Errorf("Expected Ctx[%s] to be %v, but got %v", keyToRemove, expectedValue, updatedValue)
	}
}

func TestRemoveContextParameterFromRouteArrayValueKeyExistsSingleElement(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"key": []any{"valueToRemove"},
			},
		},
	}

	keyToRemove := "key"
	valueToRemove := "valueToRemove"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if !result {
		t.Errorf(
			"Expected RemoveContextParameterFromRoute to return true when key exists, values match, and value is an array with a single element",
		)
	}

	if _, ok := r.Source.Ctx[keyToRemove]; ok {
		t.Errorf("Expected key %s to be removed from Ctx, but it still exists", keyToRemove)
	}
}

func TestRemoveContextParameterFromRouteArrayValueKeyExistsValueDoesNotMatch(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"key": []any{"value1", "value2"},
			},
		},
	}

	keyToRemove := "key"
	valueToRemove := "nonMatchingValue"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if result {
		t.Errorf(
			"Expected RemoveContextParameterFromRoute to return false when key exists, value is an array, but no element matches",
		)
	}

	updatedValue, ok := r.Source.Ctx[keyToRemove].([]any)
	if !ok {
		t.Fatalf(
			"Expected Ctx[%s] to be an array, but got %T",
			keyToRemove,
			r.Source.Ctx[keyToRemove],
		)
	}

	expectedValue := []any{"value1", "value2"}
	if !reflect.DeepEqual(updatedValue, expectedValue) {
		t.Errorf(
			"Expected Ctx[%s] to remain %v, but got %v",
			keyToRemove,
			expectedValue,
			updatedValue,
		)
	}
}

func TestRemoveContextParameterFromRouteSingleValueKeyExistsValueDoesNotMatch(t *testing.T) {
	r := &route.Route{
		Source: route.RouteSource{
			Ctx: map[string]interface{}{
				"key": "existingValue",
			},
		},
	}

	keyToRemove := "key"
	valueToRemove := "nonMatchingValue"

	result := cbroute.RemoveContextParameterFromRoute(r, keyToRemove, valueToRemove)

	if result {
		t.Errorf(
			"Expected RemoveContextParameterFromRoute to return false when key exists but values do not match",
		)
	}

	if updatedValue, ok := r.Source.Ctx[keyToRemove]; !ok {
		t.Errorf("Expected key %s to remain in Ctx, but it was removed", keyToRemove)
	} else if updatedValue != "existingValue" {
		t.Errorf("Expected value for key %s to remain as 'existingValue', but got %v", keyToRemove, updatedValue)
	}
}
