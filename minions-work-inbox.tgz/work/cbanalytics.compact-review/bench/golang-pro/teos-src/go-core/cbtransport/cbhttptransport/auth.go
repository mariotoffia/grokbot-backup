package cbhttptransport

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerauth"
)

// resolveSecurityMaterial will resolve the security material to use for the call chain require
// either a standard auth flow or custom flow.
//
// It will cache the credentials that makes it possible to reuse the credentials until _TTL_ expires.
func (epc *HttpEndpointClientImpl) resolveSecurityMaterial(session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
	useCustomFlow bool) (securitymodel.StandardCredentials, cberror.Error) {
	resolver := epc.ep.GetSecurityMaterialResolver()
	if resolver != nil {
		return resolver(epc, session, call, invokeContext)
	}

	if epc.ep.Credentials.CredentialsPointer != "" && epc.ep.Store == nil {
		lid, _ := cbtransportutils.GetGlobalParamAsString(
			session,
			string(ifprovider.ParameterLocationID),
		)

		return nil, cberror.NewCbErrorfWithProps(
			session.GetContext().Service(),
			cberror.ErrorTransportProviderInternalError,
			nil,
			map[string]interface{}{
				"lid": lid,
			},
			"Credentials pointer is set but no cache is set",
		)
	}

	if epc.ep.Store == nil {
		return nil, nil
	}

	crd, err := cbtransportutils.ResolveCredentialPointer(
		epc.ep, session, call, epc.lang, invokeContext,
	)

	if err != nil {
		return nil, err
	}

	if crd == "" {
		return nil, nil
	}

	ptr, _, ephemeral := cbtransportutils.ParseCredString(crd)

	if !ephemeral {
		credItem := epc.ep.Store.Get(ptr)

		if credItem != nil && credItem.Object() != nil {
			if err = providerauth.ValidateCredentials(
				session.GetContext(),
				session.GetOperation().(ifprovider.ConfigOperationErrors),
				credItem.Object(),
				&epc.ep.Credentials,
			); err != nil {
				return nil, err
			}

			return credItem.Object().(securitymodel.StandardCredentials), nil
		}
	}

	credentials, ttl, err := cbtransportutils.GetCredentialsFromCRDPointer(
		session,
		invokeContext,
		crd,
	)

	if err != nil {
		return nil, err
	}

	if useCustomFlow {
		if credentials, ttl, err = epc.runCustomAuthFlow(
			session, call, credentials, invokeContext, ttl,
		); err != nil {
			return nil, err
		}
	}

	// Validate the credentials
	if err = providerauth.ValidateCredentials(
		session.GetContext(),
		session.GetOperation().(ifprovider.ConfigOperationErrors),
		credentials,
		&epc.ep.Credentials,
	); err != nil {
		return nil, err
	}

	// Cache the credentials until ttl
	if !ephemeral {
		if ttl > 0 {
			err = epc.ep.Store.PutExpire(
				ptr, credentials, ttl, false /*persist*/, false, /*encrypt*/
			).Error()

			epc.ep.Store.ClearError()
		}

		if err != nil {
			return nil, err
		}
	}

	return credentials, nil
}

// runCustomAuthFlow will run the custom auth flow chain.
//
// If a `CustomSecurityMaterialResolverFunc` is registered for the endpoint,
// it will be called to resolve the credentials instead.
func (epc *HttpEndpointClientImpl) runCustomAuthFlow(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	crdCredentials securitymodel.StandardCredentials,
	invokeContext map[string]interface{},
	defaultTTL int64,
) (credentials securitymodel.StandardCredentials, ttl int64, err cberror.Error) {
	resolver := epc.ep.GetCustomSecurityMaterialResolver()
	if resolver != nil {
		return resolver(epc, session, call, crdCredentials, invokeContext, defaultTTL)
	}

	authCtx := cbtransportutils.CreateAugmentEvalContextWithCredentials(
		invokeContext,
		crdCredentials,
	)

	chain := epc.ep.GetCallChain(epc.ep.Credentials.AuthenticationFlow, true /*parent*/)

	if chain == nil {
		lid, _ := cbtransportutils.GetGlobalParamAsString(
			session,
			string(ifprovider.ParameterLocationID),
		)

		return nil, -1, cberror.NewCbErrorConfigurationErrorf(
			session.GetContext().Service(),
			cberror.ConfigurationErrorTypeMissingAuthenticationFlow, 0, nil /*config*/, nil,
			map[string]interface{}{
				"lid": lid,
				"pn":  session.GetContext().Provider(),
			}, "Missing Authentication Flow %s", epc.ep.Credentials.AuthenticationFlow)
	}

	// Create new session in order to not spill credentials to "standard" chain
	session = session.Clone(nil /*context*/, nil /*statusHandlers*/)

	// Update the invokeContext with correct session (and call)
	authCtx[string(cbtransportutils.InvokeContextKeySession)] = session

	for _, c := range chain.GetCalls() {
		// NOTE: Internal invoke -> avoid recursion
		authCtx[string(cbtransportutils.InvokeContextKeyCall)] = call
		if err = epc.invoke(session, c, authCtx, nil /*decorator*/, crdCredentials); err != nil {
			return
		}
	}

	ttl, ok := session.GetSessionContext().TokenTTL()

	if !ok {
		ttl = defaultTTL
	}

	if stdCred, ok := session.GetSessionContext().StandardCredentials(); ok {
		credentials = stdCred
		return
	}

	if token, ok := session.GetSessionContext().Token(); ok {
		credentials = &securitymodel.TokenCredentialsImpl{
			Credentials: securitymodel.StandardCredentialsImpl{
				User:     crdCredentials.GetUser(),
				Password: crdCredentials.GetPassword(),
				APIKey:   crdCredentials.GetAPIKey(),
				Endpoint: crdCredentials.GetEndpoint(),
			},
			Token: token,
		}

		return
	}

	lid, _ := cbtransportutils.GetGlobalParamAsString(
		session,
		string(ifprovider.ParameterLocationID),
	)

	err = cberror.NewCbErrorfWithProps(
		session.GetContext().Service(),
		cberror.ErrorTransportProviderInternalError,
		nil,
		map[string]interface{}{
			"lid": lid,
			"pn":  session.GetContext().Provider(),
		},
		"Provider did not return an error, token or standard credentials. One of the options is REQUIRED!",
	)

	return
}
