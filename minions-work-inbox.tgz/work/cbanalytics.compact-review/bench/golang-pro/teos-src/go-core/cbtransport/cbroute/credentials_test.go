package cbroute_test

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
)

func TestCreateCredentialsFromJSON(t *testing.T) {
	ctx := testenv.DefaultContext(t, "test-svc")

	cache := &cbroute.CredentialsCacheImpl{}

	// Define test cases
	testCases := []struct {
		name           string
		path           string
		creds          string
		expectedResult *securitymodel.ClientCredentialsMaterial
		expectedError  bool
	}{
		{ //nolint:gosec // G101: test fixture, not real credentials
			name:  "Valid credentials JSON",
			path:  "valid/path",
			creds: `{"client_id":"test-client-id","client_secret":"test-client-secret", "key":"test-key"}`,
			expectedResult: &securitymodel.ClientCredentialsMaterial{
				ClientId:     "test-client-id",
				ClientSecret: "test-client-secret",
				Key:          "test-key",
			},
			expectedError: false,
		},
		{ //nolint:gosec // G101: test fixture, not real credentials
			name:           "Invalid credentials JSON",
			path:           "invalid/path",
			creds:          `{"client_id":"test-client-id", "client_secret":}`,
			expectedResult: nil,
			expectedError:  true,
		},
	}

	// Execute test cases
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			result, err := cache.MarshalCredentialsFromJSON(ctx, tc.path, tc.creds)

			if tc.expectedError {
				assert.NotNil(t, err, "Expected an error but got nil")
			} else {
				assert.Nil(t, err, "Expected no error but got one")
				assert.Equal(t, tc.expectedResult, result, "Expected result does not match actual result")
			}
		})
	}
}
