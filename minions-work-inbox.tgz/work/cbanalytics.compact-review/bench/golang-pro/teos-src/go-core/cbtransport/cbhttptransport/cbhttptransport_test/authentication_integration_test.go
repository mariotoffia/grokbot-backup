//go:build integration

package cbhttptransport_test

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/mariotoffia/ssm"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbhttptransport"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

func TestCustomAuthenticatorTokenEndpoint(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestCustomAuthenticatorTokenEndpoint in short mode")
	}

	t.Setenv(string(cbenv.CB_IN_UNIT_TEST), "true")

	ctx := newCtx(t)
	apiKey := "1234567890"

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Every call should be decorated with API key
		assert.Equal(t, apiKey, r.Header.Get("Ocp-Apim-Subscription-Key"))

		// This is when it acts as a token endpoint
		if r.Method == "POST" && r.URL.Path == "/Token" {
			assert.Equal(t, "application/x-www-form-urlencoded", r.Header.Get("Content-Type"))

			if body, err := io.ReadAll(r.Body); err == nil {
				if data, err := url.QueryUnescape(string(body)); err == nil {
					if data == "grant_type=password&username=mario.toffia@thiink.com&password=passW0rd" {
						w.WriteHeader(http.StatusOK)
						_, err := w.Write([]byte(`{
							"access_token":"AKKWU9NrSVWsmQYfTKPFYwECE5rrKfjMQskBxYV7pwAbC7aVB",
							"expires_in":7200
						}`))
						assert.NoError(t, err)

						return
					}
				}
			}

			w.WriteHeader(http.StatusBadRequest)
			return
		}

		// Here it acts as an API
		if r.Method == "GET" && r.URL.Path == "/api/v1/test" {
			// This is the default if omitted
			assert.Equal(t, "application/json", r.Header.Get("Content-Type"))

			assert.Equal(
				t,
				"Bearer AKKWU9NrSVWsmQYfTKPFYwECE5rrKfjMQskBxYV7pwAbC7aVB",
				r.Header.Get("Authorization"),
			)

			q, _ := url.QueryUnescape(r.URL.RawQuery)
			w.WriteHeader(http.StatusOK)
			_, err := w.Write([]byte(q)) //nolint:gosec // G705: test HTTP server, not production
			assert.NoError(t, err)
			return
		}

		assert.Fail(t, "Should either be a POST to token or GET to test API")
	}))

	defer svr.Close()

	// Create credentials for the test
	url, _ := url.Parse(svr.URL)
	cred := securitymodel.TokenCredentialsImpl{
		Credentials: securitymodel.StandardCredentialsImpl{
			User:     "mario.toffia@thiink.com",
			Password: "passW0rd",

			APIKey:   apiKey,
			Endpoint: url.Host,
		},
	}

	crd := "/provider/climatix/nordvestor"
	serializer := ssm.NewSsmSerializer(ctx.DeployEnv().String(), utils.RandomPostfix("unit-test")).
		UsePrefix(crd)
	fields := serializer.Marshal(&cred)

	defer func() {
		_, err := serializer.Delete(&cred)
		assert.NoError(t, err)
	}()

	assert.Equal(t, 0, len(fields),
		"It should not return any fields, since those indicates errors!",
	)

	pc := providerConfig(svr.URL)
	pc.Params["CRD"] = crd

	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "test",
  "credentials": {
	"required": ["user", "pass", "apikey"],
	"crd": "[CRD]",
	"flow": "auth"
  },
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [{
          "path": "/api/v1/test",
          "params": {"filter": ["['[' + join(rid,',') +']']"]},
          "handler": {"2*": "ok", "*": "fail"}
        }]
    },
	"auth": {
		"chain": [{
			"method": "POST",
			"path": "/Token",
			"headers": {
				"Content-Type": ["application/x-www-form-urlencoded"],
				"Ocp-Apim-Subscription-Key": ["[apikey]"]
			},
			"body": "['grant_type=password&username=' + qenc(user) + '&password=' + qenc(pass)]",
			"handler": {"200": "auth-ok", "*": "fail"}
		}]
	}
  }
}`)

	store := config.NewSessionStore(ctx)
	defer store.Dispose()

	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data).
		UseStore(store).
		StatusHandler("auth-ok", func(
			session transportmodel.EndpointSession,
			call transportmodel.EndpointCall,
			invoke transportmodel.InvokeArgs) cberror.Error {
			type AuthenticationResponse struct {
				AccessToken string `json:"access_token"`
				ExpiresIn   int64  `json:"expires_in"`
			}

			var authResponse AuthenticationResponse
			if err := json.Unmarshal(invoke.Body(), &authResponse); err != nil {
				return cberror.NewCbErrorf(
					session.GetContext().Service(),
					1,
					err,
					"%s", err.Error(),
				)
			}

			sctx := session.GetSessionContext()
			sctx.SetToken([]byte(authResponse.AccessToken))
			sctx.SetTokenTTL(authResponse.ExpiresIn)

			return nil
		}).
		SecurityMaterialDecorator("http", &cbhttptransport.HttpSecurityMaterialDecoratorImpl{
			DecorateFunc: func(
				ctx ifcore.CbContext,
				req *retryablehttp.Request,
				credentials securitymodel.StandardCredentials) error {
				if crd, ok := credentials.(securitymodel.TokenCredentials); ok {
					req.Header.Set("Authorization", "Bearer "+string(crd.GetToken()))
					req.Header.Set("Ocp-Apim-Subscription-Key", crd.GetAPIKey())
					return nil
				}

				return errors.New("Expecting TokenCredentials")
			}})

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", true /*parent*/)
	client := ep.NewClient(ctx)

	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*ctx-data*/
		nil, /*statusHandlers*/
	)

	chain := ep.GetCallChain("", true /*parent*/)

	var err cberror.Error
	for _, c := range chain.GetCalls() {
		err = client.Invoke(session, c)
		assert.Equal(t, nil, err)
	}

	status := session.GetSessionContext()[string(transportmodel.SessionContextKeysStatusCode)]
	require.NotNil(t, status)
	assert.Equal(t, "200", status.(string))

	body := string(
		session.GetSessionContext()[string(transportmodel.SessionContextKeysBody)].([]byte),
	)

	assert.True(t, strings.Contains(body, "filter=[remote-id-"))
}

func BenchmarkCustomAuthenticatorTokenEndpoint(t *testing.B) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	ctx := newCtx(t)
	apiKey := "1234567890"

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		if r.Method == "POST" && r.URL.Path == "/Token" {
			//nolint:staticcheck // QF1012: test code, result ignored intentionally
			_, _ = fmt.Fprintf(w, `{
				"access_token":"AKKWU9NrSVWsmQYfTKPFYwECE5rrKfjMQskBxYV7pwAbC7aVB",
				"expires_in":%d
			}`, time.Now().Unix()+3600)
		}
	}))

	defer svr.Close()

	// Create credentials for the test
	url, _ := url.Parse(svr.URL)
	cred := securitymodel.TokenCredentialsImpl{
		Credentials: securitymodel.StandardCredentialsImpl{
			User:     "mario.toffia@thiink.com",
			Password: "passW0rd",

			APIKey:   apiKey,
			Endpoint: url.Host,
		},
	}

	crd := "/provider/climatix/nordvestor"
	serializer := ssm.NewSsmSerializer(ctx.DeployEnv().String(), utils.RandomPostfix("unit-test")).
		UsePrefix(crd)
	fields := serializer.Marshal(&cred)

	defer func() {
		_, _ = serializer.Delete(&cred)
	}()

	assert.Equal(t, 0, len(fields),
		"It should not return any fields, since those indicates errors!",
	)

	pc := providerConfig(svr.URL)
	pc.Params["CRD"] = crd

	oper := pc.Operation["sv"]

	data := []byte(`{
  "name": "test",
  "credentials": {
	"required": ["user", "pass", "apikey"],
	"crd": "[CRD]",
	"flow": "auth"
  },
  "baseurl": "[REP]",
  "calls": {
    "default": {
      "chain": [{
          "path": "/api/v1/test",
          "params": {"filter": ["['[' + join(rid,',') +']']"]},
          "handler": {"2*": "ok", "*": "fail"}
        }]
    },
	"auth": {
		"chain": [{
			"method": "POST",
			"path": "/Token",
			"headers": {
				"Content-Type": ["application/x-www-form-urlencoded"],
				"Ocp-Apim-Subscription-Key": ["[apikey]"]
			},
			"body": "['grant_type=password&username=' + qenc(user) + '&password=' + qenc(pass)]",
			"handler": {"200": "auth-ok", "*": "fail"}
		}]
	}
  }
}`)

	store := config.NewSessionStore(ctx)
	defer store.Dispose()

	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data).
		UseStore(store).
		StatusHandler("auth-ok", func(
			session transportmodel.EndpointSession,
			call transportmodel.EndpointCall,
			invoke transportmodel.InvokeArgs) cberror.Error {
			type AuthenticationResponse struct {
				AccessToken string `json:"access_token"`
				ExpiresIn   int64  `json:"expires_in"`
			}

			var authResponse AuthenticationResponse
			if err := json.Unmarshal(invoke.Body(), &authResponse); err != nil {
				return cberror.NewCbErrorf(
					session.GetContext().Service(),
					1,
					err,
					"%s", err.Error(),
				)
			}

			sctx := session.GetSessionContext()
			sctx.SetToken([]byte(authResponse.AccessToken))
			sctx.SetTokenTTL(authResponse.ExpiresIn)

			return nil
		}).
		SecurityMaterialDecorator("http", &cbhttptransport.HttpSecurityMaterialDecoratorImpl{
			DecorateFunc: func(
				ctx ifcore.CbContext,
				req *retryablehttp.Request,
				credentials securitymodel.StandardCredentials) error {
				if crd, ok := credentials.(securitymodel.TokenCredentials); ok {
					req.Header.Set("Authorization", "Bearer "+string(crd.GetToken()))
					req.Header.Set("Ocp-Apim-Subscription-Key", crd.GetAPIKey())
					return nil
				}

				return errors.New("Expecting TokenCredentials")
			}})

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", true /*parent*/)
	client := ep.NewClient(ctx)
	calls := ep.GetCallChain("", true /*parent*/).GetCalls()

	// Need to run once - since first time is really slow and then go test will just run once
	// hence miss the real test where credentials are cached etc.
	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*ctx-data*/
		nil, /*statusHandlers*/
	)
	for _, c := range calls {
		_ = client.Invoke(session, c)
	}

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		session := transportmodel.NewEndpointSession(
			ctx,
			&oper,
			pc,
			nil, /*ctx-data*/
			nil, /*statusHandlers*/
		)
		for _, c := range calls {
			_ = client.Invoke(session, c)
		}
	}

}
