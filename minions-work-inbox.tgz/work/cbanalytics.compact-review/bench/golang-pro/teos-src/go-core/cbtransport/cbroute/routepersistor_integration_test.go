//go:build integration

package cbroute_test

import (
	"fmt"
	"net/http"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/model/route"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

func TestPersistRoutesInParameterStoreEmptyRouteName(t *testing.T) {
	var (
		ctx = newCtx(t)
		rp  = cbroute.RoutePersisterImpl{RouteName: ""}
	)

	routes := []route.Route{
		{
			Tags:   []string{"tag1", "tag2"},
			Source: route.RouteSource{Src: "source1"},
			Targets: []route.RouteTarget{
				{Target: "target1"},
			},
		},
	}

	err := rp.PersistRoutesInParameterStore(ctx, routes)

	if err == nil || err.Code() != http.StatusBadRequest {
		t.Errorf("Expected bad request error, got %v", err)
	}
}

func TestPersistRoutesInParameterStoreMarshalError(t *testing.T) {
	var (
		ctx = newCtx(t)
		rp  = cbroute.RoutePersisterImpl{RouteName: utils.RandomPostfix("route")}
	)

	routes := []route.Route{
		{
			Tags: []string{"tag1", "tag2"},
			Source: route.RouteSource{
				Src: "source1",
				Ctx: map[string]interface{}{
					"key": make(chan int), // Channels cannot be marshaled to JSON
				},
			},
			Targets: []route.RouteTarget{
				{Target: "target1"},
			},
		},
	}

	err := rp.PersistRoutesInParameterStore(ctx, routes)

	if err == nil || err.Code() != http.StatusInternalServerError {
		t.Errorf("Expected internal server error, got %v", err)
	}
}

func TestPersistRoutesInParameterStoreSingleParameter(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestPersistRoutesInParameterStoreSingleParameter in short mode")
	}

	var (
		ctx = newCtx(t)
		rp  = cbroute.RoutePersisterImpl{RouteName: utils.RandomPostfix("route")}
	)

	routes := []route.Route{
		{
			Tags:   []string{"tag1", "tag2"},
			Source: route.RouteSource{Src: "source1"},
			Targets: []route.RouteTarget{
				{Target: "target1"},
			},
		},
	}

	err := rp.PersistRoutesInParameterStore(ctx, routes)

	defer func() { assert.NoError(t, rp.CleanRouteTableInParameterStore(ctx)) }()

	require.NoError(t, err)

	// Give the parameter store some time to update
	time.Sleep(5 * time.Second)
	loaded, err := rp.LoadRouteFromParameterStore(ctx)

	require.NoError(t, err)
	require.Equal(t, len(routes), len(loaded))
}

func TestPersistRoutesInParameterStoreLargeRouteTable(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestPersistRoutesInParameterStoreLargeRouteTable in short mode")
	}

	var (
		ctx    = newCtx(t)
		rp     = cbroute.RoutePersisterImpl{RouteName: utils.RandomPostfix("route"), SplitSize: 512}
		routes []route.Route
	)

	N := 3

	largeString := "A"

	for i := 0; i < 1024; i++ {
		largeString += "A"
	}

	for i := 0; i < N; i++ {
		routes = append(routes, route.Route{
			Tags:   []string{"tag1", "tag2", largeString},
			Source: route.RouteSource{Src: fmt.Sprintf("source%d", i)},
			Targets: []route.RouteTarget{
				{Target: fmt.Sprintf("target%d", i)},
			},
		})
	}

	err := rp.PersistRoutesInParameterStore(ctx, routes)

	defer func() { assert.NoError(t, rp.CleanRouteTableInParameterStore(ctx)) }()

	require.NoError(t, err)

	// Give the parameter store some time to update
	time.Sleep(5 * time.Second)

	loaded, err := rp.LoadRouteFromParameterStore(ctx)

	require.NoError(t, err)
	require.Equal(t, len(routes), len(loaded))
}
