package cbroute

import (
	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/route"
)

// RouteImpl implements a single router.
//
// These routers are small, use a router for each function in the system.
type RouteImpl struct {
	// table are the loaded routes for this instance and
	// is used to filter, resolve routes.
	table route.RouteTable
	// accountDomain is the base domain name of the current account
	// such as 'devlocal02.thiink.systems'.
	//
	// This is loaded from the `cbenv.CB_ACCOUNT_DOMAIN` environment variable.
	accountDomain string
	// accountID is the AWS account ID of the current account
	// such as '033549287452'.
	//
	// This is loaded from the `cbenv.AWS_ACCOUNT_ID` environment variable.
	accountID string
	// routerName is the router name for this router. For example siemens-apis.
	routerName string
}

// NewRouteImpl creates a new RouteImpl instance.
func NewRouteImpl(routerName string) *RouteImpl {
	return &RouteImpl{
		accountDomain: cbenv.CB_ACCOUNT_DOMAIN.String(""),
		accountID:     cbenv.AWS_ACCOUNT_ID.String(""),
		routerName:    routerName,
	}
}

// FromJSON will completely replace the the table with the given JSON.
func (r *RouteImpl) FromJSON(ctx ifcore.CbContext, js []byte) cberror.Error {
	builder := RouteTableBuilderImpl{}

	if err := builder.FromJSON(ctx, js); err != nil {
		return err
	}

	r.table = builder.Build()

	return nil
}

// FromParameterStoreJSON loads the JSON router from parameter store.
//
// It will be loaded under the key `ifstorage.TeosPathHttpRouteTableFormat` and
// use `routerName` as the format argument.
func (r *RouteImpl) FromParameterStoreJSON(ctx ifcore.CbContext) cberror.Error {
	builder := RouteTableBuilderImpl{}

	if err := builder.FromParameterStoreJSON(ctx, r.routerName); err != nil {
		return err
	}

	r.table = builder.Build()

	return nil
}

// RouteFromSource will filter out routes from the given source.
func (r *RouteImpl) RouteFromSource(src string) []route.Route {
	var routes []route.Route

	for _, rt := range r.table.Routes {
		if rt.Source.Src == "" && src == "" {
			routes = append(routes, rt)
		} else if rt.Source.Src != "" && rt.Source.Src == src {
			routes = append(routes, rt)
		}
	}

	return routes
}

// RouteFromTags returns a route that matches at least one the given tags.
func (r *RouteImpl) RouteFromTags(tags ...string) []route.Route {
	return r.table.RouteFromTags(tags...)
}

// RouteFromTarget returns the routes that match the given target.
func (r *RouteImpl) RouteFromTarget(target string) []route.Route {
	var routes []route.Route

	for _, rt := range r.table.Routes {
		for _, t := range rt.Targets {
			if t.Target == target {
				routes = append(routes, rt)
				break
			}
		}
	}

	return routes
}

// ResolveRoutes will resolve all routes that belongs to this account domain and those with no source set.
// It will then match the context parameters and parameters against the route.
//
// The resulting routes are returned.
//
// NOTE: All _params_ keys must be in uppercase.
//
// .Example
// [source, go]
// ----
// credentials := &CredentialsCacheImpl{}
// r := cbroute.NewRouteImpl("siemens_admin")
//
//	if err := r.FromParameterStoreJSON(ctx); err != nil {
//		return err
//	}
//
// routes := r.ResolveRoutes(ctx, nil /*params*/) // <1>
//
//	for _, route := range routes {
//	  targets := credentials.ResolveCredentialsPath(ctx, route) // <2>
//	  targets = credentials.ResolveCredentials(ctx, targets) // <3>
//
//	  for _, target := range targets {
//	    // Invoke HTTP towards target.Target
//	    // using creds: target.Credentials (where target.Error != nil)
//	  }
//	}
//
// ----
// <1> Route only on CbCallContext within CbContext since params are optional and in this case `nil`. Each route may contain many targets.
// <2> Resolve credential paths for the targets (contained within the route).
// <3> Resolve the credentials, either from internal cache or from parameter store.
func (r *RouteImpl) ResolveRoutes(ctx ifcore.CbContext, params map[string]string) []route.Route {
	var routes []route.Route
	var result []route.Route

	// Get routes that matches either my accountDomain as source or no source
	if r.accountDomain != "" {
		routes = append(routes, r.RouteFromSource(r.accountDomain)...)
	}

	routes = append(routes, r.RouteFromSource("")...)

	// Match all routes that matches the context variables.
	for i := range routes {
		if routes[i].Source.IsCtxMatch(ctx, route.ParamsMatchModeInputAll) {
			// Match all parameters
			if routes[i].Source.IsPrmsMatch(params, route.ParamsMatchModeInputAll) {
				result = append(result, routes[i])
			}
		}
	}

	return result
}
