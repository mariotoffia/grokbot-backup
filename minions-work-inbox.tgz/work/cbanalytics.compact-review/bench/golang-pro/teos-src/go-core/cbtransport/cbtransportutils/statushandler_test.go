package cbtransportutils

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

func TestSingleWildCardEntryShallMatchAnyStatusCode(t *testing.T) {
	// Find the most narrow match.
	args := transportmodel.InvokeArgs{"sc": "200"}
	handler := FindStatusHandler(map[string]string{
		"*": string(transportmodel.StatusCodeOutcomeOk),
	}, args)

	assert.Equal(t, "ok", handler)
}

func TestExactMatch(t *testing.T) {
	// Find the most narrow match.
	args := transportmodel.InvokeArgs{"sc": "200"}
	handler := FindStatusHandler(map[string]string{
		"*":   "catch-all",
		"2*":  "almost-there",
		"20*": "almost-there-too",
		"200": "best-match",
	}, args)

	assert.Equal(t, "best-match", handler)
}

func TestNoMatch(t *testing.T) {
	// Find the most narrow match.
	args := transportmodel.InvokeArgs{"sc": "300"}
	handler := FindStatusHandler(map[string]string{
		"2*":  "almost-there",
		"20*": "almost-there-too",
		"200": "best-match",
	}, args)

	assert.Equal(t, "", handler)
}

func TestMatchMostNarrowStatusCode(t *testing.T) {
	// Find the most narrow match.
	args := transportmodel.InvokeArgs{"sc": "200"}
	handler := FindStatusHandler(map[string]string{
		"*":   "catch-all",
		"2*":  "almost-there",
		"20*": "best-match",
	}, args)

	assert.Equal(t, "best-match", handler)
}

func BenchmarkExactMatch(t *testing.B) {
	m := map[string]string{
		"*":   "catch-all",
		"2*":  "almost-there",
		"20*": "almost-there-too",
		"200": "best-match",
	}

	args := transportmodel.InvokeArgs{"sc": "200"}

	for i := 0; i < t.N; i++ {
		FindStatusHandler(m, args)
	}

}

func BenchmarkMatchMostNarrowStatusCode(t *testing.B) {
	m := map[string]string{
		"*":   "catch-all",
		"2*":  "almost-there",
		"20*": "best-match",
	}

	args := transportmodel.InvokeArgs{"sc": "200"}

	for i := 0; i < t.N; i++ {
		FindStatusHandler(m, args)
	}

}
