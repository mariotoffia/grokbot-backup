package cbtransport

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbhttptransport"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// EndpointBuilder is used to create an `transportmodel.EndpointManager`.
type EndpointBuilder struct {
	// h is the endpoint's handlers.
	h transportmodel.EndPointFunctions
	// jsonPtr is the physical `struct` matching the `jsonEp` interface.
	jsonPtr *transportmodel.EndpointImpl
	jsonEp  transportmodel.Endpoint
	name    string
	err     cberror.Error
	// store is the session store configured for all the endpoints.
	store *config.SessionStore
	// ctx is used to format errors.
	ctx ifcore.CbContext
}

// NewBuilder creates a new builder to create an `transportmodel.EndpointManager`.
func NewEndpointBuilder(ctx ifcore.CbContext, name string) *EndpointBuilder {
	return &EndpointBuilder{
		name: name,
		ctx:  ctx,
		h: transportmodel.EndPointFunctions{
			Invokers:                   make(map[string]transportmodel.InvokerFunc),
			SensorProcessors:           make(map[string]transportmodel.ProcessorFunc),
			StatusHandlers:             make(map[string]transportmodel.StatusHandlerFunc),
			SecurityMaterialDecorators: make(map[string]transportmodel.SecurityMaterialDecorator),
		},
	}
}

// Name returns the name of the endpoint.
func (b *EndpointBuilder) Name() string {
	return b.name
}

// UseName will ensure the endpoint has the given name.
func (b *EndpointBuilder) UseName(name string) *EndpointBuilder {
	b.name = name
	return b
}

// Error returns the error that occurred during the build process.
func (b *EndpointBuilder) Error() cberror.Error {
	return b.err
}

// UseStore sets the session store for this endpoint.
func (b *EndpointBuilder) UseStore(store *config.SessionStore) *EndpointBuilder {
	b.store = store
	return b
}

// Build will assemble the `transportmodel.Endpoint` and return it.
func (b *EndpointBuilder) Build() transportmodel.Endpoint {
	if b.err != nil {
		return nil
	}

	// Only JSON is possible right now.
	if b.jsonPtr == nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			cberror.ErrorTransportBuilderError,
			nil,
			"endpoint builder: no JSON data",
		)
		return nil
	}

	b.jsonPtr.Functions = b.h
	b.jsonPtr.Store = b.store

	if b.name != "" && b.jsonPtr.Name != b.name {
		b.jsonPtr.Name = b.name
	}

	jsonEp := b.jsonEp
	b.jsonEp = nil
	b.jsonPtr = nil

	return jsonEp
}

// FromJSON will unmarshal the given JSON data into the endpoint.
//
// If it fails, it will set the builder into an error state.
func (b *EndpointBuilder) FromJSON(data []byte) *EndpointBuilder {
	if b.jsonPtr != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			cberror.ErrorTransportBuilderError,
			nil,
			"endpoint already built",
		)
		return b
	}

	ptr, res, err := b.unmarshalEndpoint(data)
	if err != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			cberror.ErrorCfgMarshal,
			err,
			"%s", jsonutils.ToVerboseJSONError(
				data, err, map[string]interface{}{
					"svc": b.ctx.Service(),
					"pn":  b.ctx.Provider(),
				}).Error(),
		)
		return b
	}

	b.jsonPtr = ptr
	b.jsonEp = res

	if b.name == "" {
		b.name = b.jsonPtr.Name
	}

	return b

}

// Invoker adds / updates a invoker function for the endpoint.
func (b *EndpointBuilder) Invoker(name string, f transportmodel.InvokerFunc) *EndpointBuilder {
	b.h.Invokers[name] = f
	return b

}

// Invokers adds / updates a set invoker function for the endpoint.
func (b *EndpointBuilder) Invokers(
	invokers map[string]transportmodel.InvokerFunc,
) *EndpointBuilder {
	for k := range invokers {
		b.h.Invokers[k] = invokers[k]
	}
	return b

}

// SensorProcessor adds / updates a sensor function for the endpoint.
func (b *EndpointBuilder) SensorProcessor(
	name string,
	f transportmodel.ProcessorFunc,
) *EndpointBuilder {
	b.h.SensorProcessors[name] = f
	return b

}

// SensorProcessors adds / updates a set sensor function for the endpoint.
func (b *EndpointBuilder) SensorProcessors(
	processors map[string]transportmodel.ProcessorFunc,
) *EndpointBuilder {
	for k := range processors {
		b.h.SensorProcessors[k] = processors[k]
	}
	return b

}

// StatusHandler adds / updates a status function for the endpoint.
func (b *EndpointBuilder) StatusHandler(
	name string,
	f transportmodel.StatusHandlerFunc,
) *EndpointBuilder {
	b.h.StatusHandlers[name] = f
	return b

}

// StatusHandlers adds / updates a set status function for the endpoint.
func (b *EndpointBuilder) StatusHandlers(
	handlers map[string]transportmodel.StatusHandlerFunc,
) *EndpointBuilder {
	for k := range handlers {
		b.h.StatusHandlers[k] = handlers[k]
	}
	return b

}

// SecurityMaterialDecorator adds / updates a security material decorator for the endpoint.
func (b *EndpointBuilder) SecurityMaterialDecorator(
	name string,
	f transportmodel.SecurityMaterialDecorator,
) *EndpointBuilder {
	b.h.SecurityMaterialDecorators[name] = f
	return b

}

// SecurityMaterialDecorators adds / updates a set security material decorators for the endpoint.
func (b *EndpointBuilder) SecurityMaterialDecorators(
	handlers map[string]transportmodel.SecurityMaterialDecorator,
) *EndpointBuilder {
	for k := range handlers {
		b.h.SecurityMaterialDecorators[k] = handlers[k]
	}
	return b

}

// SecurityMaterialResolver sets / updates the security material resolver for the endpoint.
func (b *EndpointBuilder) SecurityMaterialResolver(
	resolver transportmodel.SecurityMaterialResolverFunc,
) *EndpointBuilder {
	b.h.SecurityMaterialResolver = resolver
	return b

}

// SecurityMaterialResolver sets / updates the custom security material resolver for the endpoint.
func (b *EndpointBuilder) CustomSecurityMaterialResolver(
	resolver transportmodel.CustomSecurityMaterialResolverFunc,
) *EndpointBuilder {
	b.h.CustomSecurityMaterialResolver = resolver
	return b

}

// SecurityMaterialResolver sets / updates the verify connect function for the endpoint.
func (b *EndpointBuilder) CustomVerifyConnect(
	verify transportmodel.VerifyConnectFunc,
) *EndpointBuilder {
	b.h.CustomVerifyConnect = verify
	return b
}

// unmarshalEndpoint will probe the type of the endpoint and unmarshal the correct
// type.
func (b *EndpointBuilder) unmarshalEndpoint(
	data []byte,
) (ptr *transportmodel.EndpointImpl, res transportmodel.Endpoint, err error) {
	// Read out the type in order to unmarshal the correct type.
	d := &struct {
		Type transportmodel.EndpointType `json:"type"`
	}{}

	if err = json.Unmarshal(data, &d); err != nil {
		return
	}

	if d.Type == "" {
		d.Type = transportmodel.EndPointTypeHTTP
	}

	switch d.Type {
	case transportmodel.EndPointTypeHTTP:
		v := &cbhttptransport.HttpEndpointImpl{}
		ptr = &v.EndpointImpl
		ptr.Type = transportmodel.EndPointTypeHTTP // Make sure "http" is set
		res = v
	default:
		err = fmt.Errorf(
			"unknown endpoint type: %s (supported: http)", d.Type,
		)
		return
	}

	if ptr.Credentials.Type == "" {
		ptr.Credentials.Type = securitymodel.CredentialsTypeToken
	}

	if err = json.Unmarshal(data, res); err != nil {
		return
	}

	ptr.BaseURL = strings.TrimSuffix(ptr.BaseURL, "/")

	if len(ptr.Chains) > 0 {
		for call := range ptr.Chains {
			v := ptr.Chains[call]
			if v.Direction == "" {
				v.Direction = locationmodel.ProviderOperationSensorValueIn
			}

			for j := range v.Calls {
				if v.Calls[j].Direction == "" {
					v.Calls[j].Direction = v.Direction
				}

				if v.Calls[j].Method == "" {
					v.Calls[j].Method = transportmodel.MethodGet
				}
			}
		}
	}

	return
}
