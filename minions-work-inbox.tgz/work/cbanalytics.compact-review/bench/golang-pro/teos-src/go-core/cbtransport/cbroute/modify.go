package cbroute

import "github.com/Thiink-LLC/teos/go-core/model/route"

// AddContextParameterToRoute will add a context parameter value.
//
// If it already exists, it will convert to an array and add it.
// If it does not exist, it will create an array with the value.
func AddContextParameterToRoute(route *route.Route, key string, value any) {
	if value == nil {
		return
	}

	if route.Source.Ctx == nil {
		route.Source.Ctx = map[string]any{}
	}

	if v, ok := route.Source.Ctx[key]; ok {
		if arr, ok := v.([]any); ok {
			arr = append(arr, value)
			route.Source.Ctx[key] = arr
		} else {
			// create an array with the existing value and the new value
			route.Source.Ctx[key] = []any{v, value}
		}

		return
	}

	route.Source.Ctx[key] = value
}

// RemoveContextParameterFromRoute will delete a context parameter from the route.
//
// If the key does not exist, it will return `false`. If the key exists, it compares
// if the value are equal before delete the key.
//
// If the current value is an array it will remove it from the array. If the array
// is empty, it will delete the key.
func RemoveContextParameterFromRoute(route *route.Route, key string, val any) bool {
	if route.Source.Ctx == nil {
		return false
	}

	if v, ok := route.Source.Ctx[key]; ok {
		arr, isArray := v.([]any)

		if !isArray {
			if v == val {
				delete(route.Source.Ctx, key)

				return true
			}

			return false
		}

		for i, v := range arr {
			if v == val {
				// We have a match -> delete element or whole key
				if len(arr) == 1 {
					delete(route.Source.Ctx, key)
				} else {
					arr = append(arr[:i], arr[i+1:]...)
					route.Source.Ctx[key] = arr
				}

				return true
			}
		}
	}

	return false
}
