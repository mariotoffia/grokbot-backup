package cbroute_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
)

func TestRouteFromTagsWithExistingTag(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"tags": ["tag1", "tag2"],
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.RouteFromTags("tag1")

	assert.Equal(t, 1, len(routes), "Expected one route with the given tag but got %d", len(routes))
}

func TestRouteFromTagsWithNonExistentTag(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"tags": ["tag1", "tag2"],
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.RouteFromTags("tag3")

	assert.Equal(
		t,
		0,
		len(routes),
		"Expected zero routes with the given tag but got %d",
		len(routes),
	)
}

func TestRouteFromTargetWithExistingTarget(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			},
			{
				"source": {
					"src": "devlocal03.thiink.systems"
				},
				"targets": [{
					"target": "devlocal04.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.RouteFromTarget("devlocal03.thiink.systems")

	assert.Equal(
		t,
		1,
		len(routes),
		"Expected one route with the given target but got %d",
		len(routes),
	)
}

func TestRouteFromTargetWithNonExistentTarget(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			},
			{
				"source": {
					"src": "devlocal03.thiink.systems"
				},
				"targets": [{
					"target": "devlocal04.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.RouteFromTarget("nonexistent.thiink.systems")

	assert.Equal(
		t,
		0,
		len(routes),
		"Expected zero routes with the given target but got %d",
		len(routes),
	)
}

func TestRouteFromTagsWithMultipleTags(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"tags": ["tag1", "tag2", "tag3"],
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routesWithTag2 := r.RouteFromTags("tag2")
	routesWithTag4 := r.RouteFromTags("tag4")

	assert.Equal(
		t,
		1,
		len(routesWithTag2),
		"Expected one route with the tag 'tag2' but got %d",
		len(routesWithTag2),
	)
	assert.Equal(
		t,
		0,
		len(routesWithTag4),
		"Expected zero routes with the tag 'tag4' but got %d",
		len(routesWithTag4),
	)
}

func TestRouteFromTargetWithMultipleMatchingRoutes(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal01.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			},
			{
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.RouteFromTarget("devlocal03.thiink.systems")

	assert.Equal(
		t,
		2,
		len(routes),
		"Expected two routes with the given target but got %d",
		len(routes),
	)
}

func TestRouteFromTagsWithMultipleProvidedTags(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"tags": ["tag1"],
				"source": {
					"src": "devlocal01.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			},
			{
				"tags": ["tag2"],
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.RouteFromTags("tag1", "tag2")

	assert.Equal(
		t,
		2,
		len(routes),
		"Expected two routes for the provided tags but got %d",
		len(routes),
	)
}
