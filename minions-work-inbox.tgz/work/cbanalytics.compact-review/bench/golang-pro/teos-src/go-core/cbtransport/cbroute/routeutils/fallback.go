package routeutils

import (
	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriam/mgriamcognito"
	"github.com/Thiink-LLC/teos/go-core/model/route"
)

// CreateFallBackRoute will create a route that will be used as a fallback
// when no routes was found but the request should be handled.
//
// This function will check if the `cbenv.CB_ACCOUNT_DOMAIN` is set
// and use it as the target. If not, it will use
// `ifiam.AppClientReader.GetAccountDomain()` to try-get the account domain.
func CreateFallBackRoute(ctx ifcore.CbContext) (route.Route, cberror.Error) {
	var (
		accountDomain = cbenv.CB_ACCOUNT_DOMAIN.String("")
		err           cberror.Error
	)

	if accountDomain == "" {
		accountDomain, err = mgriamcognito.NewCognitoAppClientManager(ctx).
			GetAccountDomain(ctx)
	}

	if err != nil {
		return route.Route{}, err
	}

	// Construct the fallback route
	return route.Route{
		Tags:   []string{"default", "fallback"},
		Source: route.RouteSource{},
		Targets: []route.RouteTarget{
			{Target: accountDomain},
		},
	}, nil
}
