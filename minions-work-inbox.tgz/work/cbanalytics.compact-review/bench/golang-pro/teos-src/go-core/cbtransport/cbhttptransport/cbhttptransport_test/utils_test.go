package cbhttptransport_test

// Util functions for all the tests.
import (
	"testing"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// newCtx returns a test context, closed when the test ends, and turns logging
// down to fatal. TestMain applies the TEOS test settings first.
func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()

	c, err := ctx.NewContext("test-svc", "test", cbenv.DevLocal, true /*sort*/)
	require.NoError(tb, err)
	tb.Cleanup(c.Close)

	zerolog.SetGlobalLevel(zerolog.FatalLevel)

	return c
}

func providerConfig(serverURL string) *providermodel.ProviderConfigImpl {
	return &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"REP": serverURL,
					"BID": "Måssmyren 18",
					"TZ":  "Europe/Stockholm",
					"CRD": "/unit-test/cred",
				},
				Operation: map[string]providermodel.Operation{
					"sv": {
						Operation: "sv",
						Params: map[string]interface{}{
							"TZ":  "[TZ]",
							"LTS": true,
						},
					},
				},
				Map: map[string]string{
					"COMT":   "remote-id-1",
					"ECR":    "remote-id-2",
					"OFFODT": "remote-id-3",
					"ACTODT": "remote-id-4",
					"MPST":   "remote-id-5",
				},
			},
		},
	}
}
