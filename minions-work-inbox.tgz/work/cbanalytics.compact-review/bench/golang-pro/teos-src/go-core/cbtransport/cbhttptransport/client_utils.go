package cbhttptransport

import (
	"net/url"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// prepareBody will get the `transportmodel.EndpointCallImpl.Body` and evaluate it.
//
// TIP: If within pipeline, use generator to generate a _JSON_ layout and then use
//
//	that as a body expression in the `transportmodel.EndpointCallImpl.Body`. For
//	example `[target]`.
func (epc *HttpEndpointClientImpl) prepareBody(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
) ([]byte, cberror.Error) {
	expr := call.GetBody()
	if expr == "" {
		return nil, nil
	}

	evalBody, err := cbtransportutils.EvaluateExpressionToString(
		expr,
		session,
		epc.lang,
		invokeContext,
		cberror.ErrorTransportBodyExpressionMalformed,
	)

	if err != nil {
		return nil, err
	}

	if evalBody == "" {
		return nil, nil
	}

	return []byte(evalBody), nil
}

func (epc *HttpEndpointClientImpl) prepareUrl(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
) (string, cberror.Error) {
	var url string
	path := call.GetPath()

	evalPath, err := cbtransportutils.EvaluateExpressionToString(
		path,
		session,
		epc.lang,
		invokeContext,
		cberror.ErrorTransportUrlExpressionMalformed,
	)

	if err != nil {
		return "", err
	}

	// If path do have a scheme, use path instead!
	if strings.Contains(evalPath, "://") {
		return evalPath, nil
	}

	baseUrl, err := cbtransportutils.EvaluateExpressionToString(
		epc.ep.BaseURL,
		session,
		epc.lang,
		invokeContext,
		cberror.ErrorTransportUrlExpressionMalformed,
	)

	if err != nil {
		return "", err
	}

	baseUrl = strings.TrimSuffix(baseUrl, "/")

	if !strings.HasPrefix(evalPath, "/") {
		evalPath = "/" + evalPath
	}

	url = baseUrl + evalPath

	return url, nil
}

// prepareHeaders makes sure that all elements in the `transportmodel.EndpointCallImpl.Headers`
// are copied and resolved.
//
// If no headers, a empty map is returned.
func (epc *HttpEndpointClientImpl) prepareHeaders(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
) (map[string][]string, cberror.Error) {
	paramsMap := call.GetHeaders()

	headers := map[string][]string{}
	if len(paramsMap) == 0 {
		return headers, nil
	}

	for key, value := range paramsMap {
		values := make([]string, len(value))
		for i, v := range value {
			s, err := cbtransportutils.EvaluateExpressionToString(
				v,
				session,
				epc.lang,
				invokeContext,
				cberror.ErrorTransportPrepareQueryFailed,
			)

			if err != nil {
				return headers, err
			}

			values[i] = s
		}

		headers[key] = values
	}

	return headers, nil
}

func (epc *HttpEndpointClientImpl) prepareQuery(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
) (string, cberror.Error) {
	paramsMap := call.GetParams()

	var sb strings.Builder

	for key, value := range paramsMap {
		if len(value) == 0 {
			sb.WriteString(key)
			sb.WriteString("&")
			continue
		}

		for _, v := range value {
			sb.WriteString(key)
			sb.WriteString("=")

			s, err := cbtransportutils.EvaluateExpressionToString(
				v,
				session,
				epc.lang,
				invokeContext,
				cberror.ErrorTransportPrepareQueryFailed,
			)

			if err != nil {
				return "", err
			}

			sb.WriteString(url.QueryEscape(s))
			sb.WriteString("&")
		}
	}

	s := sb.String()
	if len(s) > 0 {
		s = s[:len(s)-1]
	}

	return s, nil
}

// prepareInvocation prepares, url, query, headers and body for the invocation.
func (epc *HttpEndpointClientImpl) prepareInvocation(
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{}) (
	url string,
	query string,
	headers map[string][]string,
	body []byte,
	err cberror.Error) {
	// Create the url
	if url, err = epc.prepareUrl(session, call, invokeContext); err != nil {
		return
	}
	// Create the query (if any)
	if query, err = epc.prepareQuery(session, call, invokeContext); err != nil {
		return
	}
	// Prepare headers (if any)
	if headers, err = epc.prepareHeaders(session, call, invokeContext); err != nil {
		return
	}
	// Create the body (if any)
	body, err = epc.prepareBody(session, call, invokeContext)
	return
}

func (epc *HttpEndpointClientImpl) intercept(
	invoker transportmodel.InvokerType,
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	invokeContext map[string]interface{},
	args map[string]any,
) (handled bool, body []byte, statusCode string, headers map[string][]string, err cberror.Error) {
	var resolver transportmodel.EndpointFunctionResolver = &epc.ep.EndpointImpl

	invokers := call.GetInvokers()

	interceptor := resolver.ResolveInvoker(
		invokers[invoker],
		true, /*parent*/
	)

	if interceptor == nil {
		return
	}

	// Custom invoker registered -> use it
	handled, err = interceptor(epc, session, call, invokeContext, args)

	if err != nil {
		return
	}

	if invokeContext[string(transportmodel.InvokeArgsKeyBody)] != nil {
		body, _ = invokeContext[string(transportmodel.InvokeArgsKeyBody)].([]byte)
	}

	if invokeContext[string(transportmodel.InvokeArgsKeyStatusCode)] != nil {
		statusCode, _ = invokeContext[string(transportmodel.InvokeArgsKeyStatusCode)].(string)
	}

	if invokeContext[string(transportmodel.InvokeArgsKeyHeaders)] != nil {
		headers, _ = invokeContext[string(transportmodel.InvokeArgsKeyHeaders)].(map[string][]string)
	}

	return
}
