package cbtransport

import (
	"encoding/json"
	"errors"
	"io/fs"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// ManagerBuilder is used to create an `transportmodel.EndpointManager`.
type ManagerBuilder struct {
	// gh is a set of global functions that will be applied to each of the endpoints.
	gh transportmodel.EndPointFunctions
	// ep is all builders for each endpoints.
	ep map[string]*EndpointBuilder
	// store is the session store configured for all the endpoints.
	store *config.SessionStore
	// ctx is used to format errors.
	ctx ifcore.CbContext
	// err is the error that occurred during the build process.
	err cberror.Error
	// parent holds the parent `EndpointBuilder` if this is a child.
	parent transportmodel.EndpointManager
}

// NewManagerBuilder creates a new builder to create an `transportmodel.EndpointManager`.
func NewManagerBuilder(ctx ifcore.CbContext) *ManagerBuilder {
	return &ManagerBuilder{
		ctx: ctx,
		ep:  map[string]*EndpointBuilder{},
		gh: transportmodel.EndPointFunctions{
			Invokers:                   make(map[string]transportmodel.InvokerFunc),
			SensorProcessors:           make(map[string]transportmodel.ProcessorFunc),
			StatusHandlers:             make(map[string]transportmodel.StatusHandlerFunc),
			SecurityMaterialDecorators: make(map[string]transportmodel.SecurityMaterialDecorator),
		},
	}

}

// Error returns the error that occurred during the build process.
func (b *ManagerBuilder) Error() cberror.Error {
	return b.err
}

// Build will build the `transportmodel.EndpointManager` from the configured endpoints.
//
// If any error occurs during the build process, it will set and `nil` is returned.
func (b *ManagerBuilder) Build() *EndpointManagerImpl {
	if b.err != nil {
		return nil
	}

	transport := map[string]transportmodel.Endpoint{}

	for k := range b.ep {
		ep := b.ep[k]

		// add / set global handlers if not already set in the endpoint.
		if b.store != nil && ep.store != b.store {
			ep.UseStore(b.store)
		}

		if b.gh.SecurityMaterialResolver != nil &&
			ep.h.SecurityMaterialResolver == nil {
			ep.SecurityMaterialResolver(b.gh.SecurityMaterialResolver)
		}

		if b.gh.CustomSecurityMaterialResolver != nil &&
			ep.h.CustomSecurityMaterialResolver == nil {
			ep.CustomSecurityMaterialResolver(b.gh.CustomSecurityMaterialResolver)
		}

		if b.gh.CustomVerifyConnect != nil &&
			ep.h.CustomVerifyConnect == nil {
			ep.CustomVerifyConnect(b.gh.CustomVerifyConnect)
		}

		for k := range b.gh.Invokers {
			if ep.h.Invokers[k] == nil {
				ep.Invoker(k, b.gh.Invokers[k])
			}
		}

		for k := range b.gh.SensorProcessors {
			if ep.h.SensorProcessors[k] == nil {
				ep.SensorProcessor(k, b.gh.SensorProcessors[k])
			}
		}

		for k := range b.gh.StatusHandlers {
			if ep.h.StatusHandlers[k] == nil {
				ep.StatusHandler(k, b.gh.StatusHandlers[k])
			}
		}

		for k := range b.gh.SecurityMaterialDecorators {
			if ep.h.SecurityMaterialDecorators[k] == nil {
				ep.SecurityMaterialDecorator(k, b.gh.SecurityMaterialDecorators[k])
			}
		}

		transport[k] = ep.Build()
		b.err = ep.err

		if b.err != nil {
			return nil
		}
	}

	return NewEndpointManager(b.ctx, b.parent, transport)
}

// UseParent sets the parent `EndpointBuilder` for the returned `EndpointManagerImpl`.
func (b *ManagerBuilder) UseParent(parent transportmodel.EndpointManager) *ManagerBuilder {
	b.parent = parent
	return b
}

// Endpoint creates a new or gets existing `EndpointBuilder` to configure a new or update
// an existing `EndpointBuilder`.
func (b *ManagerBuilder) Endpoint(name string) *EndpointBuilder {
	if _, ok := b.ep[name]; !ok {
		b.ep[name] = NewEndpointBuilder(b.ctx, name)
	}
	return b.ep[name]

}

// FromJSON creates a `EndpointBuilder` from a single endpoint definition in _JSON_.
//
// If suspect that the definition contains many endpoints, use `FromMultiJSON` instead.
func (b *ManagerBuilder) FromJSON(data []byte) *EndpointBuilder {
	if b.err != nil {
		return nil
	}

	ep := NewEndpointBuilder(b.ctx, "").FromJSON(data)

	b.err = ep.err
	if b.err != nil {
		return nil
	}

	b.ep[ep.name] = ep

	return ep

}

// UseStore sets the session store for *all* endpoints.
//
// NOTE: If endpoint has a store configured, it will *not* be overwritten.
func (b *ManagerBuilder) UseStore(store *config.SessionStore) *ManagerBuilder {
	b.store = store
	return b

}

// Invoker adds / updates a invoker function for *all* endpoints.
//
// This only is set when the endpoint do not have a invoker configured with the same name.
func (b *ManagerBuilder) Invoker(name string, f transportmodel.InvokerFunc) *ManagerBuilder {
	b.gh.Invokers[name] = f
	return b

}

// Invokers adds / updates a set invoker functions for *all* endpoints.
//
// This only is set when the endpoint do not have a invoker configured with the same name.
func (b *ManagerBuilder) Invokers(invokers map[string]transportmodel.InvokerFunc) *ManagerBuilder {
	for k := range invokers {
		b.gh.Invokers[k] = invokers[k]
	}
	return b

}

// SensorProcessor adds / updates a sensor processor for *all* endpoints.
//
// This only is set when the endpoint do not have a processor configured with the same name.
func (b *ManagerBuilder) SensorProcessor(
	name string,
	f transportmodel.ProcessorFunc,
) *ManagerBuilder {
	b.gh.SensorProcessors[name] = f
	return b

}

// SensorProcessors adds / updates a set sensor processors for *all* endpoints.
//
// This only is set when the endpoint do not have a processor configured with the same name.
func (b *ManagerBuilder) SensorProcessors(
	processors map[string]transportmodel.ProcessorFunc,
) *ManagerBuilder {
	for k := range processors {
		b.gh.SensorProcessors[k] = processors[k]
	}
	return b

}

// StatusHandler adds / updates a status handler for *all* endpoints.
//
// This only is set when the endpoint do not have a status handler configured with the same name.
func (b *ManagerBuilder) StatusHandler(
	name string,
	f transportmodel.StatusHandlerFunc,
) *ManagerBuilder {
	b.gh.StatusHandlers[name] = f
	return b

}

// StatusHandlers adds / updates a set status handlers for *all* endpoints.
//
// This only is set when the endpoint do not have a status handler configured with the same name.
func (b *ManagerBuilder) StatusHandlers(
	handlers map[string]transportmodel.StatusHandlerFunc,
) *ManagerBuilder {
	for k := range handlers {
		b.gh.StatusHandlers[k] = handlers[k]
	}
	return b

}

// SecurityMaterialDecorator adds / updates a security material decorator for *all* endpoints.
//
// This only is set when the endpoint do not have a security material decorator configured with the same name.
func (b *ManagerBuilder) SecurityMaterialDecorator(
	name string,
	f transportmodel.SecurityMaterialDecorator,
) *ManagerBuilder {
	b.gh.SecurityMaterialDecorators[name] = f
	return b

}

// SecurityMaterialDecorators adds / updates a set security material decorators for *all* endpoints.
//
// This only is set when the endpoint do not have a security material decorator configured with the same name.
func (b *ManagerBuilder) SecurityMaterialDecorators(
	handlers map[string]transportmodel.SecurityMaterialDecorator,
) *ManagerBuilder {
	for k := range handlers {
		b.gh.SecurityMaterialDecorators[k] = handlers[k]
	}
	return b

}

// SecurityMaterialResolver sets / updates the security material resolver for *all* endpoints.
//
// This is only set when there's no resolver set on the endpoint.
func (b *ManagerBuilder) SecurityMaterialResolver(
	resolver transportmodel.SecurityMaterialResolverFunc,
) *ManagerBuilder {
	b.gh.SecurityMaterialResolver = resolver
	return b

}

// SecurityMaterialResolver sets / updates the custom security material resolver for *all* endpoints.
//
// This is only set when there's no resolver set on the endpoint.
func (b *ManagerBuilder) CustomSecurityMaterialResolver(
	resolver transportmodel.CustomSecurityMaterialResolverFunc,
) *ManagerBuilder {
	b.gh.CustomSecurityMaterialResolver = resolver
	return b

}

// SecurityMaterialResolver sets / updates the verify connect function for *all* endpoints.
//
// This is only set when there's no resolver set on the endpoint.
func (b *ManagerBuilder) CustomVerifyConnect(
	verify transportmodel.VerifyConnectFunc,
) *ManagerBuilder {
	b.gh.CustomVerifyConnect = verify
	return b
}

// FromFS creates a one or more `EndpointBuilder` by reading _JSON_
// configuration files from _f_ with glob expression _**-endpoint.json_.
//
// NOTE: Sine it may produce many endpoint. The _globalHandlers_ must contain *all*
//
//	named handlers that are referenced for reach `EndpointCallImpl.Handlers`.
//
// Internally it uses ´FromMultiJSON´ and hence each file may contain a single endpoint
// or an array of those.
func (b *ManagerBuilder) FromFS(f fs.FS) *ManagerBuilder {
	err := fileutils.FSWalker(
		f, "", "**-endpoint.json", true, /*load*/
		func(f fs.FS, fqPath string, data []byte) cberror.Error {
			b.FromMultiJSON(data)
			return b.err
		},
	)

	if err != nil {
		var cberr cberror.Error
		if errors.As(err, &cberr) {
			b.err = cberr
		} else {
			b.err = cberror.NewCbErrorf(
				b.ctx.Service(), 1, err, "%s", err.Error(),
			)
		}
	}

	return b
}

// FromMultiJSON will check if it is an array or a single `EndpointBuilder` and
// unmarshal appropriately.
//
// Individual endpoint(s) can accessed using `Endpoint` function.
func (b *ManagerBuilder) FromMultiJSON(data []byte) *ManagerBuilder {
	if !jsonutils.IsJSONArrayPrefix(data) {
		b.FromJSON(data)
		return b
	}

	var err error
	var temp []json.RawMessage

	if err = json.Unmarshal(data, &temp); err != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			cberror.ErrorCfgMarshal,
			err,
			"%s", jsonutils.ToVerboseJSONError(
				data, err, map[string]interface{}{
					"svc": b.ctx.Service(),
					"pn":  b.ctx.Provider(),
				}).Error(),
		)
		return b
	}

	if len(temp) == 0 {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			cberror.ErrorCfgMarshal,
			err,
			"failed to unmarshal endpoints from data (no length), data: '%s'",
			string(data),
		)
		return b
	}

	for i := 0; i < len(temp); i++ {
		b.FromJSON(temp[i])
	}

	return b
}
