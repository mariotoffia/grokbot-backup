package cbhttptransport_test

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbhttptransport"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

func BenchmarkSingleHttpCall(t *testing.B) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	ep := cbhttptransport.HttpEndpointImpl{
		EndpointImpl: transportmodel.EndpointImpl{
			Name: "", /*default endpoint*/
			Credentials: securitymodel.CredentialConfig{
				Type: securitymodel.CredentialsTypeToken,
				Required: []securitymodel.CredentialItemType{
					securitymodel.CredentialItemTypeUsername,
					securitymodel.CredentialItemTypePassword,
				},
			},
			BaseURL: "[REP]",
			Functions: transportmodel.EndPointFunctions{
				StatusHandlers: map[string]transportmodel.StatusHandlerFunc{
					"fail": func(
						session transportmodel.EndpointSession,
						call transportmodel.EndpointCall,
						invoke transportmodel.InvokeArgs) cberror.Error {
						return nil
					},
					"ok": func(
						session transportmodel.EndpointSession,
						call transportmodel.EndpointCall,
						invoke transportmodel.InvokeArgs) cberror.Error {
						return nil
					},
				},
			},
		},
	}

	call := transportmodel.EndpointCallImpl{
		Direction: locationmodel.ProviderOperationSensorValueIn,
		Path:      "[REP + '/api/v2/test']",
		Params: map[string][]string{
			"filter": {"'[' + join(sensors) + ']'"},
		},
		StatusHandlers: map[string]string{"2*": "ok", "*": "fail"},
	}

	ctx := newCtx(t)
	client := ep.NewClient(ctx)

	for i := 0; i < t.N; i++ {
		session := transportmodel.NewEndpointSession(
			ctx,
			&oper,
			pc,
			nil, /*sessionContext*/
			nil, /*statusHandlers*/
		)

		_ = client.Invoke(session, &call)
	}

}

func BenchmarkDefaultStatusHandlerSuccess(t *testing.B) {
	_ = cbenv.CB_IN_UNIT_TEST.SetBool(true)
	defer cbenv.CB_IN_UNIT_TEST.UnSet()

	svr := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = fmt.Fprintf(w, "returned data")
	}))

	defer svr.Close()

	pc := providerConfig(svr.URL)
	oper := pc.Operation["sv"]

	data := []byte(`{
		"name": "test",
		"credentials": {
			"required": ["user","pass","apikey"]
		},
		"baseurl": "[REP]",
		"calls": {
			"default": {
				"chain": [{
					"path": "/v1/test",
					"params": {
						"filter": [ "['[' + join(rid,',') +']']" ]
					},
					"handler": {
						"2*": "ok",
						"*": "fail"
					}
				}]
			}
		}}`)

	ctx := newCtx(t)
	builder := cbtransport.NewManagerBuilder(ctx)
	builder.FromJSON(data)

	if builder.Error() != nil {
		assert.FailNow(t, builder.Error().Error())
	}

	mgr := builder.Build()
	ep := mgr.GetEndpoint("test", false /*parent*/)
	client := ep.NewClient(ctx)
	call := ep.GetCallChain("", false /*parent*/).GetCalls()[0]
	session := transportmodel.NewEndpointSession(
		ctx,
		&oper,
		pc,
		nil, /*sessionContext*/
		nil, /*statusHandlers*/
	)

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		_ = client.Invoke(session, call)
	}

}
