package cbroute

import (
	"encoding/json"
	"maps"
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/route"
)

// RouteReplacer is a function that get's called for each route in the table.
//
// If it returns `true` the route will be replaced with the returned route.
type RouteReplacer func(route.Route) (route.Route, bool)

// RouteDelete is invoked when a request to delete a route using the _DeleteRoutes_ function.
//
// When it return `true` the route will be deleted, otherwise it is kept.
type RouteDelete func(route.Route) bool

// RouteBuilder will manually build a route table.
type RouteTableBuilderImpl struct {
	// routes are those that where build to materialized from JSON
	routes []route.Route
}

// NewRouteTableBuilderImpl will create a new route table builder.
func NewRouteTableBuilderImpl() *RouteTableBuilderImpl {
	return &RouteTableBuilderImpl{}
}

// NewFromRoutesRouteTableBuilderImpl creates a builder from the given routes.
func NewFromRoutesRouteTableBuilderImpl(routes []route.Route) *RouteTableBuilderImpl {
	return &RouteTableBuilderImpl{routes: routes}
}

// FromParameterStoreJSON will load the route table from the given JSON stored in the parameter store.
//
// If table is large, is is split up into several parameters, named table0-n. If just single, it uses the table0 parameter.
//
// Use appropriate routeName such as _management_.
func (rb *RouteTableBuilderImpl) FromParameterStoreJSON(
	ctx ifcore.CbContext,
	routeName string,
) cberror.Error {
	var err cberror.Error

	rb.routes, err = (&RoutePersisterImpl{RouteName: routeName}).LoadRouteFromParameterStore(ctx)

	return err
}

// FromJSON will load the route table from the given JSON and add those to the routes.
func (rb *RouteTableBuilderImpl) FromJSON(ctx ifcore.CbContext, js []byte) cberror.Error {
	if len(js) == 0 {
		return cberror.NewCbErrorf(ctx.Service(), 500, nil, "JSON is empty")
	}

	var table route.RouteTable

	if err := json.Unmarshal(js, &table); err != nil {
		// Try Unmarshal just an array of routes
		table = route.RouteTable{}

		if err := json.Unmarshal(js, &table.Routes); err != nil {
			return cberror.NewCbErrorf(
				ctx.Service(), http.StatusBadRequest, err,
				"Failed to unmarshal JSON: %s", err.Error(),
			)
		}
	}

	// Make sure that all context-/parameters IDs are in uppercase.
	table.PrepareForUse()

	rb.routes = append(rb.routes, table.Routes...)

	return nil
}

// AddRoute adds a single route.
func (rb *RouteTableBuilderImpl) AddRoute(route route.Route) *RouteTableBuilderImpl {
	rb.routes = append(rb.routes, route)

	return rb
}

// ReplaceRouteFromSource will replace the route where it finds the _crit_ source route.
func (rb *RouteTableBuilderImpl) ReplaceRouteFromSource(
	crit route.RouteSource,
	route route.Route,
) *RouteTableBuilderImpl {
	//
	for i, rt := range rb.routes {
		if rt.Source.Src == crit.Src &&
			maps.Equal(rt.Source.Ctx, crit.Ctx) &&
			maps.Equal(rt.Source.Prms, crit.Prms) {
			rb.routes[i] = route
			break
		}
	}

	return rb
}

// ReplaceRouteByTag will replace all routes that matches the _cit_ with the given _rt_ (route).
//
// The matching is done any of the tags exists in the route it will be included
func (rb *RouteTableBuilderImpl) ReplaceRouteByTag(
	crit []string,
	rt route.Route,
) *RouteTableBuilderImpl {
	routes := SearchRoutesByTag(rb.routes, TagSearchModeAny, crit...)

	for i := range routes {
		rb.routes[i] = rt
	}

	return rb
}

// ReplaceRoute will replace all routes that matches the _replacer_ with the given _rt_ (route).
func (rb *RouteTableBuilderImpl) ReplaceRoute(replacer RouteReplacer) *RouteTableBuilderImpl {
	for i, rt := range rb.routes {
		if newRt, replace := replacer(rt); replace {
			rb.routes[i] = newRt
		}
	}

	return rb
}

// DeleteRoute will delete all routes that matches the _del_ function.
func (rb *RouteTableBuilderImpl) DeleteRoute(del RouteDelete) *RouteTableBuilderImpl {
	var routes []route.Route

	for _, rt := range rb.routes {
		if !del(rt) {
			rt := rt
			routes = append(routes, rt)
		}
	}

	rb.routes = routes

	return rb
}

// Build will build the route table.
func (rb *RouteTableBuilderImpl) Build() route.RouteTable {
	table := route.RouteTable{
		Routes: rb.routes,
	}

	table.PrepareForUse()

	return table
}

// RouteSourceBuilderImpl will build a single route source.
type RouteSourceBuilderImpl struct {
	rt route.RouteSource
}

func Source() *RouteSourceBuilderImpl {
	return &RouteSourceBuilderImpl{}
}

// AsSource sets the source discriminator.
func (rb *RouteSourceBuilderImpl) AsSource(src string) *RouteSourceBuilderImpl {
	rb.rt.Src = src

	return rb
}

// WhenContext sets the context parameter to filter targets on.
func (rb *RouteSourceBuilderImpl) WhenContext(id string, value any) *RouteSourceBuilderImpl {
	if rb.rt.Ctx == nil {
		rb.rt.Ctx = make(map[string]any)
	}

	rb.rt.Ctx[id] = value

	return rb
}

// WithParameters sets the parameters to filter targets on.
func (rb *RouteSourceBuilderImpl) WithParameters(id string, value any) *RouteSourceBuilderImpl {
	if rb.rt.Prms == nil {
		rb.rt.Prms = make(map[string]any)
	}

	rb.rt.Prms[id] = value

	return rb
}

// Build will build the route source.
func (rb *RouteSourceBuilderImpl) Build() route.RouteSource {
	return rb.rt
}

// RouteTargetBuilderImpl will build a single route target.
type RouteTargetBuilderImpl struct {
	rt route.RouteTarget
}

func Target(target string) *RouteTargetBuilderImpl {
	return &RouteTargetBuilderImpl{
		rt: route.RouteTarget{
			Target: target,
		},
	}
}

// ToTarget sets the target to invoke.
func (rb *RouteTargetBuilderImpl) ToTarget(target string) *RouteTargetBuilderImpl {
	rb.rt.Target = target

	return rb
}

// WithApi will add one or more api that the target should expose.
func (rb *RouteTargetBuilderImpl) WithApi(api ...string) *RouteTargetBuilderImpl {
	rb.rt.Apis = append(rb.rt.Apis, api...)

	return rb
}

// WithCtxParameters sets the context parameters to invoke the target with.
func (rb *RouteTargetBuilderImpl) WithCtxParameters(id string, value any) *RouteTargetBuilderImpl {
	if rb.rt.Ctx == nil {
		rb.rt.Ctx = make(map[string]any)
	}

	rb.rt.Ctx[id] = value

	return rb
}

// WithCRD sets the credentials pointer to use when invoking the target.
//
// This points to a security material object that contains the credentials to use.
func (rb *RouteTargetBuilderImpl) WithCRD(crd string) *RouteTargetBuilderImpl {
	rb.rt.Crd = crd

	return rb
}

func (rb *RouteTargetBuilderImpl) Build() route.RouteTarget {
	return rb.rt
}
