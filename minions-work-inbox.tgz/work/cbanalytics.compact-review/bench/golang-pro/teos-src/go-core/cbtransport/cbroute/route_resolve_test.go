package cbroute_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
)

func TestResolveRoutesWithMatchingSourceAndCtx(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
		"ANOTHER_PARAMETER":   "value",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida",
						"another_parameter": "value"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 1, len(routes), "Expected one route but got %d", len(routes))
}

func TestResolveRoutesWithMatchingSourceButNonMatchingCtx(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "different_customer",
		"ANOTHER_PARAMETER":   "different_value",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida",
						"another_parameter": "value"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 0, len(routes), "Expected zero routes but got %d", len(routes))
}

func TestResolveRoutesWithSourceNoCtxOrPrmsRequirements(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems"
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 1, len(routes), "Expected one route but got %d", len(routes))
}

func TestResolveRoutesWithNonExistentSource(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal03.thiink.systems"
				},
				"targets": [{
					"target": "devlocal04.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(t, 0, len(routes), "Expected zero routes but got %d", len(routes))
}

func TestResolveRoutesWithMixedCaseCtx(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"ConTracted_CusTomER": "bravida"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(
		t,
		1,
		len(routes),
		"Expected one route with the given mixed-case context but got %d",
		len(routes),
	)
}

func TestResolveRoutesWithRegexInCtx(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida_sweden",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "regex://bravida_.*"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(
		t,
		1,
		len(routes),
		"Expected one route matching the regex pattern but got %d",
		len(routes),
	)
}

func TestResolveRoutesWithRegexInPrms(t *testing.T) {
	ctx := testAssign(t)

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"prms": {
						"USER_REGION": "regex://europe_.*"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, map[string]string{
		"USER_REGION": "europe_north",
	})

	assert.Equal(
		t,
		1,
		len(routes),
		"Expected one route matching the regex pattern in prms but got %d",
		len(routes),
	)
}

func TestResolveRoutesWithMatchingCtxAndPrms(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida"
					},
					"prms": {
						"USER_TYPE": "premium"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, map[string]string{
		"USER_TYPE": "premium",
	})

	assert.Equal(
		t,
		1,
		len(routes),
		"Expected one route matching both ctx and prms but got %d",
		len(routes),
	)
}

func TestResolveRoutesWithOnlyCtxMatching(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida"
					},
					"prms": {
						"USER_TYPE": "elite"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, map[string]string{
		"USER_TYPE": "basic",
	})

	assert.Equal(
		t,
		0,
		len(routes),
		"Expected zero routes since only ctx matched but prms did not, but got %d",
		len(routes),
	)
}

func TestResolveRoutesWithAdditionalPrmsNotMatching(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "bravida"
					},
					"prms": {
						"USER_TYPE": "premium",
						"ACCESS_LEVEL": "admin"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, map[string]string{
		"USER_TYPE": "premium", "ACCESS_LEVEL": "kalle",
	})

	assert.Equal(
		t,
		0,
		len(routes),
		"Expected zero routes since only one prms matched but another did not, got %d",
		len(routes),
	)
}

func TestResolveRoutesWithRegexMatchingInCtx(t *testing.T) {
	ctx := testAssign(t, map[string]string{
		"CONTRACTED_CUSTOMER": "bravida_europe",
	})

	r := cbroute.NewRouteImpl("test-route")

	err := r.FromJSON(ctx, []byte(`{
		"routes": [
			{
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "regex://bravida_.*"
					}
				},
				"targets": [{
					"target": "devlocal03.thiink.systems"
				}]
			}
		]
	}`))

	require.NoError(t, err)

	routes := r.ResolveRoutes(ctx, nil /*params*/)

	assert.Equal(
		t,
		1,
		len(routes),
		"Expected one route since the regex in ctx matched the context parameter, but got %d",
		len(routes),
	)
}
