package routeutils_test

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute/routeutils"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/route"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// A route sends one call to one or more TEOS deployments, each named by its
// account domain. These tests cover that every client built for a target speaks
// to that target's deployment: the client that fetches the access token, and
// the client that makes the calls afterwards.
//
// The deployment target here is the local one, where every TEOS hostname is
// answered by one emulator. The test server below stands in for that emulator
// and records the hostname of every request it answers, which is how a request
// that went to the wrong deployment is visible.

const (
	// firstAccount is the TEOS deployment the process itself runs in.
	firstAccount = "devlocal02.localhost.floci.io"
	// secondAccount is another deployment the route also sends to.
	secondAccount = "devlocal03.localhost.floci.io"
	// vendorHost is an equipment vendor's API, which is never a TEOS hostname.
	vendorHost = "api.bpcloud.siemens.com"
	// routerName names the route table these tests build by hand.
	routerName = "routeutils-test"
)

// Both targets of the route are prepared, and each ends up with a client that
// speaks to its own deployment. The access token for the second deployment is
// fetched from that deployment's own login host, which is the failure a single
// shared authentication client would cause: it would ask the first deployment
// for a token and then call the second with it.
func TestEachRouteTargetAuthenticatesAgainstItsOwnDeployment(t *testing.T) {
	seen := make(chan string, 8)
	server, bundle := emulatorServer(t, seen)

	localRun(t, server.URL, bundle)

	c := testContext(t)
	cache := credentialsFor(t, firstAccount, secondAccount)

	targets, err := routeutils.PrepareClients(c, routeTo(firstAccount, secondAccount), "test", routerName, cache)

	require.Nil(t, err)
	require.Len(t, targets, 2, "both targets of the route are prepared")

	assert.Equal(t, firstAccount, targets[0].Target)
	assert.Equal(t, secondAccount, targets[1].Target)
	assert.Equal(t, firstAccount, targets[0].Client.AuthenticatedDomain)
	assert.Equal(t, secondAccount, targets[1].Client.AuthenticatedDomain)

	assert.Equal(t, "api.auth."+firstAccount, <-seen,
		"the first target's token comes from the first deployment's login host")
	assert.Equal(t, "api.auth."+secondAccount, <-seen,
		"the second target's token comes from the second deployment's login host")

	// Each prepared client now makes a call, and the emulator sees the hostname
	// of the deployment that client belongs to.
	for _, target := range targets {
		request, cerr := target.Client.NewRequest(c, http.MethodGet,
			"https://api."+target.Target+"/lcs/v1/buildings", nil)
		require.Nil(t, cerr)

		response, derr := target.Client.Do(request)
		require.NoError(t, derr, target.Target)

		_ = response.Body.Close()

		assert.Equal(t, "api."+target.Target, <-seen)
	}
}

// A target that cannot be prepared is left out of the result rather than
// leaving an entry with no client in it. Here the second target has no
// credentials, so one target comes back and it is the one that has them.
func TestATargetWithoutCredentialsIsLeftOut(t *testing.T) {
	seen := make(chan string, 8)
	server, bundle := emulatorServer(t, seen)

	localRun(t, server.URL, bundle)

	c := testContext(t)
	cache := credentialsFor(t, firstAccount)

	targets, err := routeutils.PrepareClients(c, routeTo(firstAccount, secondAccount), "test", routerName, cache)

	require.Nil(t, err)
	require.Len(t, targets, 1)

	assert.Equal(t, firstAccount, targets[0].Target)
	require.NotNil(t, targets[0].Client)
}

// localRun points this process at the emulator the test server stands in for,
// as one TEOS deployment on the local deployment target.
func localRun(t *testing.T, serverURL, bundlePath string) {
	t.Helper()
	testenv.Use(t, testenv.EnvDefaults)

	t.Setenv(string(cbenv.TEOS_DEPLOYMENT), string(cbenv.DeploymentTargetLocal))
	t.Setenv(string(cbenv.AWS_ENDPOINT_URL), serverURL)
	t.Setenv(string(cbenv.AWS_CA_BUNDLE), bundlePath)
	t.Setenv(string(cbenv.CB_ACCOUNT_DOMAIN), firstAccount)

	// The AWS configuration is loaded from these, and never used to reach
	// Amazon: no test here makes an AWS API call.
	t.Setenv("AWS_REGION", "eu-west-1")
	t.Setenv("AWS_ACCESS_KEY_ID", "test")
	t.Setenv("AWS_SECRET_ACCESS_KEY", "test")
	t.Setenv("AWS_EC2_METADATA_DISABLED", "true")
}

// testContext is the TEOS request context service code is given. It carries the
// network profile of the process, which the AWS configuration option registers.
func testContext(t *testing.T) ifcore.CbContext {
	t.Helper()

	c, err := ctx.NewContextWithDefaultOptions("routeutils-test", "test", cbenv.DevLocal)
	require.Nil(t, err)
	t.Cleanup(c.Close)

	return c
}

// routeTo is a route with one target per account domain. Each target names the
// parameter store path its credentials are held under, which is what keeps this
// test from reading anything outside the cache below.
func routeTo(accountDomains ...string) route.Route {
	targets := make([]route.RouteTarget, 0, len(accountDomains))

	for _, domain := range accountDomains {
		targets = append(targets, route.RouteTarget{Target: domain, Crd: "/test/credentials/" + domain})
	}

	return route.Route{Tags: []string{"test"}, Targets: targets}
}

// credentialsFor is a credentials cache already holding one set of client
// credentials per account domain, so nothing is read from the parameter store.
func credentialsFor(t *testing.T, accountDomains ...string) *cbroute.CredentialsCacheImpl {
	t.Helper()

	cache := &cbroute.CredentialsCacheImpl{}

	for _, domain := range accountDomains {
		cache.Cache.Store("/test/credentials/"+domain, &securitymodel.ClientCredentialsMaterial{
			ClientId:     "client-of-" + domain,
			ClientSecret: "secret-of-" + domain,
			Endpoint:     domain,
		})
	}

	return cache
}

// emulatorServer starts an HTTPS server standing in for the emulator. It
// answers a token request with an access token and everything else with no
// content, and reports the hostname of every request on seen.
//
// It returns the server and the path of the file holding the certificate to
// trust, which is what a local run puts in AWS_CA_BUNDLE.
func emulatorServer(t *testing.T, seen chan<- string) (*httptest.Server, string) {
	t.Helper()

	names := []string{
		"api.auth." + firstAccount, "api.auth." + secondAccount,
		"api." + firstAccount, "api." + secondAccount,
		vendorHost,
	}

	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	require.NoError(t, err)

	template := &x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{CommonName: names[0]},
		DNSNames:              names,
		IPAddresses:           []net.IP{net.ParseIP("127.0.0.1"), net.ParseIP("::1")},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		IsCA:                  true,
		BasicConstraintsValid: true,
	}

	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	require.NoError(t, err)

	server := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seen <- r.Host

		if r.URL.Path == "/oauth2/token" {
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte(`{"access_token":"an-access-token","token_type":"Bearer","expires_in":3600}`))

			return
		}

		w.WriteHeader(http.StatusNoContent)
	}))
	server.TLS = &tls.Config{
		Certificates: []tls.Certificate{{Certificate: [][]byte{der}, PrivateKey: key}},
		MinVersion:   tls.VersionTLS12,
	}
	server.StartTLS()
	t.Cleanup(server.Close)

	path := filepath.Join(t.TempDir(), "bundle.pem")
	require.NoError(t, os.WriteFile(path,
		pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o600))

	return server, path
}
