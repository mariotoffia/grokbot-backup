package cbtransportutils

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// ResolveIDs will resolve all sensors by getting the `ifprovider.Config` and then
// get all sensors from the config. It then gets the mapped to and returns a
// `map[string]string` with the key being the _CbID_ and the value being the _remote ID_.
//
// If the configuration do not support `ifprovider.ConfigMapping` interface it will
// return an `cberror.ConfigurationError`.
func ResolveIDs(
	session transportmodel.EndpointSession,
) (sensors map[string]string, err cberror.Error) {
	pc := session.GetProviderConfig()

	var cm ifprovider.ConfigMapping
	var ok bool

	if cm, ok = pc.(ifprovider.ConfigMapping); !ok {
		err = cberror.NewCbErrorConfigurationErrorf(
			session.GetContext().Service(),
			1 /*code*/, 1 /*specific*/, nil, nil /*error*/, nil, /*properties*/
			"Requires a ifprovider.ConfigMapping of the provider config",
		)
	} else {
		cbID := pc.ExtractSensors(session.GetOperation())

		sensors = map[string]string{}
		for _, id := range cbID {
			if rid, ok := cm.GetMappedTo(id); ok {
				sensors[id] = rid
			}
		}
	}

	return
}
