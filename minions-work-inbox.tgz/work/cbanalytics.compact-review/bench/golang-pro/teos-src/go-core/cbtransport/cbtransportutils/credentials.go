package cbtransportutils

import (
	"net/url"
	"strconv"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// ParseCredString parses a credentials string and extracts the pointer
// to the credentials and optionally extracts the _ttl_.
//
// If the CRD is a ephemeral it will indicate that by returning _ephemeral_ as `true`.
// This is when the cred is [ttl:]ephemeral-{id}.
func ParseCredString(cred string) (ptr string, ttl string, ephemeral bool) {
	if cred == "" {
		return
	}

	// Remove any prefix
	cred = strings.TrimPrefix(cred, "/devlocal/")
	cred = strings.TrimPrefix(cred, "/dev/")
	cred = strings.TrimPrefix(cred, "/prod/")

	if ephemeral = strings.HasPrefix(cred, "ephemeral-"); ephemeral {
		ptr = cred
		return
	}

	if !strings.HasPrefix(cred, "/") {
		cred = "/" + cred
	}

	c := strings.Split(cred, ":")
	if len(c) == 2 {
		ptr = c[0]
		ttl = c[1]
	} else {
		ptr = cred
	}

	return
}

// ExtractTTL extracts the TTL from the _ttl_ and depending on the value of
// the _ttl_ parameter it parses the value or set one of the _default_ or _token_
// _TTL_.
//
// If it fails to parse the _TTL_ it will return an error.
func ExtractTTL(
	context ifcore.CbContext,
	ttl string,
	defaultTTL int64,
	tokenTTL int64) (int64, cberror.Error) {
	var ttl2 int64
	switch ttl {
	case "token-ttl":
		ttl2 = tokenTTL
	case "":
		ttl2 = defaultTTL
	default:
		{
			var err error
			if ttl2, err = strconv.ParseInt(ttl, 10, 64); err != nil {
				return 0, cberror.NewCbErrorf(
					context.Service(), cberror.ErrorProviderFailedToParseTtl, err,
					"Failed to parse ttl string: '%s' to integer, err: %s", ttl, err.Error(),
				)
			}
		}
	}

	return ttl2, nil
}

// GetCredentialsFromCRDPointer is a function to obtain credentials using the `securitymodel.TokenCredentialsImpl`
// in conjunction with `ServiceConfig`.
//
// The _crd_ `string` is a credential string that is used as prefix on the `ServiceConfig.UsePrefix()` function. If the string
// contains a colon ':' then the string before the colon is used as the prefix and the string after the colon is used as the
// ttl in seconds (defaults to 3600 seconds).
//
// CAUTION: The _crd_ string must be resolved, if it where an expression, before invoking this function!
func GetCredentialsFromCRDPointer(
	session transportmodel.EndpointSession,
	invokeContext map[string]any,
	cred string) (securitymodel.StandardCredentials, int64, cberror.Error) {
	ptr, ttl, ephemeral := ParseCredString(cred)

	var cfg securitymodel.TokenCredentialsImpl

	if !ephemeral {
		s := config.New(session.GetContext()).UsePrefix(ptr).GetConfig(&cfg)

		if s.Error() != nil {
			return nil, 0, s.Error()
		}
	} else {
		if cc := GetClientCredentialsFromPipeContext(invokeContext); cc != nil {
			cfg.Credentials = *securitymodel.FromClientCredentials(cc)
		}
	}

	if len(cfg.Credentials.User) == 0 &&
		len(cfg.Credentials.Password) == 0 &&
		len(cfg.Credentials.APIKey) == 0 {
		return nil, 0, cberror.NewCbErrorf(
			session.GetContext().Service(), cberror.ErrCredentialNotFoundFromCRD,
			nil, "Credentials not found on CRD: %s", ptr,
		)
	}

	var ttl2 int64
	var err error
	switch ttl {
	case "":
		ttl2 = int64(3600) /*default to 1h*/
	default:
		{
			if ttl2, err = strconv.ParseInt(ttl, 10, 64); err != nil {
				return nil, 0, cberror.NewCbErrorf(
					session.GetContext().Service(), cberror.ErrorProviderUnableToParseTtl, err,
					"Failed to parse ttl string: '%s' to integer, err: %s", ttl, err.Error(),
				)
			}
		}
	}

	return &cfg.Credentials, ttl2, nil
}

// VerifyConnect is a common function to verify that the `securitymodel.StandardCredentialsImpl.Endpoint`
// is same as the _remoteUrl_ `url.Host` _DNS_ name.
func VerifyConnect(
	client transportmodel.EndpointClient,
	session transportmodel.EndpointSession,
	remoteUrl string,
	credentials securitymodel.StandardCredentials,
) bool {
	if nil == credentials {
		return false
	}

	if u, err := url.Parse(remoteUrl); err == nil {
		match := u.Host == credentials.GetEndpoint()

		lid, _ := GetGlobalParamAsString(
			session,
			string(ifprovider.ParameterLocationID),
		)

		crd, _ := GetGlobalParamAsString(
			session,
			string(ifprovider.ParameterCredentials),
		)

		log.TraceWithLocationID(session.GetContext(), lid).
			WithDataType(logger.LDTDevOps).
			Str("crd", crd).
			Str("endpoint", credentials.GetEndpoint()).
			Str("host", u.Host).
			Bool("match", match).
			Msg("VerifyConnect")

		return match
	}

	return false
}

// GetClientCredentialsFromPipeContext will try to extract the client credentials from the pipe context.
func GetClientCredentialsFromPipeContext(
	pipeCtx map[string]any,
) *securitymodel.ClientCredentialsMaterial {
	if m, ok := pipeCtx[string(ifprovider.PipeContextCredentials)]; ok {
		if cc, ok := m.(*securitymodel.ClientCredentialsMaterial); ok {
			return cc
		}
	}

	return nil
}
