//go:build integration

package cbroute_test

import (
	"os"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestMain points every test in this package at the AWS backend the build tags
// select: the local emulator with the floci tag, real AWS without it. The tests
// create and remove their own resources and need no deployed TEOS system.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvUsingManualAWSResources))
}

// newCtx returns a context with the AWS configuration of the backend that
// TestMain selected, closed when the test ends.
func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()

	c, err := ctx.NewContext(
		"test-svc", "test", cbenv.DevLocal,
		true /*sort*/, ctx.OptAWSConfigLoadDefault(),
	)
	require.NoError(tb, err)
	tb.Cleanup(c.Close)

	return c
}
