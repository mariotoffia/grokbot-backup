package cbhttptransport

import (
	"net/http"
	"net/http/httputil"

	"github.com/hashicorp/go-retryablehttp"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
)

// dumpRequest will dump the _HTTP_ request to the logger using trace level.
//
// CAUTION: Since this may contain sensitive information the log entry is tagged
// with `logger.LDTContainsSecrets` and `logger.LISClassified`.
func dumpRequest(c ifcore.CbContext, method string, req *retryablehttp.Request) {
	logLevel := zerolog.TraceLevel
	var request string

	if url := req.URL; nil != url {
		request = url.String()
	}

	data, err := httputil.DumpRequest(req.Request, true)

	if err != nil {
		logLevel = zerolog.WarnLevel
	}

	if l, ok := logger.ClsLog(
		logLevel, method+"::HTTPRequest", logger.LDTContainsSecrets, logger.LISClassified, c,
	); ok {
		if err != nil {
			logger.LogObject(l, "error", err).
				Str("request", request).
				Msg("error while dumping request")
		} else {
			l.Msg(string(data))
		}
	}

}

// dumpRequest will dump the _HTTP_ request to the logger using trace level.
//
// CAUTION: Since this may contain sensitive information the log entry is tagged
// with `logger.LDTDeveloper` and `logger.LISClassified`.
func dumpResponse(c ifcore.CbContext, method string, response *http.Response) {
	logLevel := zerolog.TraceLevel

	data, err := httputil.DumpResponse(response, true)

	if err != nil {
		logLevel = zerolog.WarnLevel
	}

	if l, ok := logger.ClsLog(
		logLevel, method+"::HTTPResponse", logger.LDTContainsSecrets, logger.LISClassified, c,
	); ok {
		if err != nil {
			logger.LogObjectf(l, "error", err, "error while dumping response")
		} else {
			l.Msg(string(data))
		}
	}

}

// loggerMap maps client logger to cb core logger
type loggerMap struct {
	context ifcore.CbContext
	m       string
	l       zerolog.Level
}

func (lm *loggerMap) Log(level zerolog.Level, s string, prms ...interface{}) {
	if level > lm.l {
		level = lm.l
	}

	if l, ok := logger.ClsLog(level, lm.m, logger.LDTDeveloper, logger.LISUnclassified, lm.context); ok {
		l.Msgf(s, prms...)
	}

}

func (lm *loggerMap) Error(s string, prms ...interface{}) {
	lm.Log(zerolog.ErrorLevel, s, prms...)
}
func (lm *loggerMap) Warn(s string, prms ...interface{}) {
	lm.Log(zerolog.WarnLevel, s, prms...)
}
func (lm *loggerMap) Info(s string, prms ...interface{}) {
	lm.Log(zerolog.InfoLevel, s, prms...)
}
func (lm *loggerMap) Debug(s string, prms ...interface{}) {
	lm.Log(zerolog.DebugLevel, s, prms...)
}
