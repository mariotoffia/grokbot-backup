package cbroute_test

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbroute"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/model/route"

	"github.com/stretchr/testify/assert"
)

func TestBuildSimpleRoute(t *testing.T) {
	builder := cbroute.RouteTableBuilderImpl{}

	builder.AddRoute(route.Route{
		Tags: []string{"test"},
		Source: cbroute.Source().
			AsSource("devlocal02.thiink.systems").
			WhenContext("contracted_customer", "nordvestor").
			WithParameters("param_01", "a_value").
			Build(),
		Targets: []route.RouteTarget{
			cbroute.Target("devlocal03.thiink.systems").
				WithCtxParameters("pass_along_to_target", "a_value").
				WithCRD("/teos/v1/routes/credentials/devlocal03/sma").
				Build(),
		},
	})

	table := builder.Build()

	assert.Equal(t, 1, len(table.Routes))
	assert.Equal(t, "test", table.Routes[0].Tags[0])
	assert.Equal(t, "devlocal02.thiink.systems", table.Routes[0].Source.Src)
	assert.Equal(t, "nordvestor", table.Routes[0].Source.Ctx["CONTRACTED_CUSTOMER"])
	assert.Equal(t, "a_value", table.Routes[0].Source.Prms["PARAM_01"])
	assert.Equal(t, "devlocal03.thiink.systems", table.Routes[0].Targets[0].Target)
	assert.Equal(t, "a_value", table.Routes[0].Targets[0].Ctx["pass_along_to_target"])
	assert.Equal(t, "/teos/v1/routes/credentials/devlocal03/sma", table.Routes[0].Targets[0].Crd)
}

func TestAddRouteToJSONRoutes(t *testing.T) {
	c, _ := ctx.NewContext(
		"test-svc", "test", cbenv.DevLocal,
		true /*sort*/, ctx.OptAWSConfigLoadDefault(),
	)

	builder := cbroute.RouteTableBuilderImpl{}

	err := builder.FromJSON(c, []byte(`{
		"routes": [
			{
				"tags": ["test"],
				"source": {
					"src": "devlocal02.thiink.systems",
					"ctx": {
						"contracted_customer": "nordvestor"
					},
					"prms": {
						"param_01": "a_value"
					}
				},
				"targets": [
					{
						"target": "devlocal03.thiink.systems",
						"ctx": {
							"pass_along_to_target": "a_value"
						},
						"crd": "/teos/v1/routes/credentials/devlocal03/sma"
					}
				]
			}
		]
	}`))

	assert.NoError(t, err)

	builder.AddRoute(route.Route{
		Tags: []string{"test"},
		Source: cbroute.Source().
			AsSource("devlocal02.thiink.systems").
			WhenContext("contracted_customer", "siemens").
			Build(),
		Targets: []route.RouteTarget{
			cbroute.Target("siemens.thiink.systems").
				WithCRD("/teos/v1/routes/credentials/siemens/ssa").
				Build(),
		},
	})

	table := builder.Build()

	assert.Equal(t, 2, len(table.Routes))
	assert.Equal(t, "test", table.Routes[0].Tags[0])
	assert.Equal(t, "devlocal02.thiink.systems", table.Routes[0].Source.Src)
	assert.Equal(t, "nordvestor", table.Routes[0].Source.Ctx["CONTRACTED_CUSTOMER"])
	assert.Equal(t, "a_value", table.Routes[0].Source.Prms["PARAM_01"])
	assert.Equal(t, "devlocal03.thiink.systems", table.Routes[0].Targets[0].Target)
	assert.Equal(t, "a_value", table.Routes[0].Targets[0].Ctx["pass_along_to_target"])
	assert.Equal(t, "/teos/v1/routes/credentials/devlocal03/sma", table.Routes[0].Targets[0].Crd)
	assert.Equal(t, "test", table.Routes[1].Tags[0])
	assert.Equal(t, "devlocal02.thiink.systems", table.Routes[1].Source.Src)
	assert.Equal(t, "siemens", table.Routes[1].Source.Ctx["CONTRACTED_CUSTOMER"])
	assert.Equal(t, "siemens.thiink.systems", table.Routes[1].Targets[0].Target)
	assert.Equal(t, "/teos/v1/routes/credentials/siemens/ssa", table.Routes[1].Targets[0].Crd)
}

func TestReplaceRouteFromSource(t *testing.T) {
	builder := cbroute.RouteTableBuilderImpl{}

	builder.AddRoute(route.Route{
		Tags: []string{"test"},
		Source: cbroute.Source().
			AsSource("devlocal02.thiink.systems").
			WhenContext("contracted_customer", "nordvestor").
			WithParameters("param_01", "a_value").
			Build(),
		Targets: []route.RouteTarget{
			cbroute.Target("devlocal03.thiink.systems").
				WithCtxParameters("pass_along_to_target", "a_value").
				WithCRD("/teos/v1/routes/credentials/devlocal03/sma").
				Build(),
		},
	})

	builder.ReplaceRouteFromSource(cbroute.Source().
		AsSource("devlocal02.thiink.systems").
		WhenContext("contracted_customer", "nordvestor").
		WithParameters("param_01", "a_value").
		Build(),
		route.Route{
			Tags: []string{"replaced"},
			Source: cbroute.Source().
				AsSource("devlocal02.thiink.systems").
				WhenContext("contracted_customer", "nordvestor").
				WithParameters("param_01", "a_value").
				Build(),
			Targets: []route.RouteTarget{
				cbroute.Target("devlocal04.thiink.systems").
					WithCtxParameters("pass_along_to_target", "a_value").
					WithCRD("/teos/v1/routes/credentials/devlocal04/sca").
					Build(),
			},
		})

	table := builder.Build()

	assert.Equal(t, 1, len(table.Routes))
	assert.Equal(t, "replaced", table.Routes[0].Tags[0])
	assert.Equal(t, "devlocal04.thiink.systems", table.Routes[0].Targets[0].Target)
	assert.Equal(t, "/teos/v1/routes/credentials/devlocal04/sca", table.Routes[0].Targets[0].Crd)
}

func TestReplaceRouteFromTag(t *testing.T) {
	builder := cbroute.RouteTableBuilderImpl{}

	builder.AddRoute(route.Route{
		Tags: []string{"test"},
		Source: cbroute.Source().
			AsSource("devlocal02.thiink.systems").
			WhenContext("contracted_customer", "nordvestor").
			WithParameters("param_01", "a_value").
			Build(),
		Targets: []route.RouteTarget{
			cbroute.Target("devlocal03.thiink.systems").
				WithCtxParameters("pass_along_to_target", "a_value").
				WithCRD("/teos/v1/routes/credentials/devlocal03/sma").
				Build(),
		},
	})

	builder.ReplaceRouteByTag([]string{"test"},
		route.Route{
			Tags: []string{"replaced"},
			Source: cbroute.Source().
				AsSource("devlocal02.thiink.systems").
				WhenContext("contracted_customer", "nordvestor").
				WithParameters("param_01", "a_value").
				Build(),
			Targets: []route.RouteTarget{
				cbroute.Target("devlocal04.thiink.systems").
					WithCtxParameters("pass_along_to_target", "a_value").
					WithCRD("/teos/v1/routes/credentials/devlocal04/sca").
					Build(),
			},
		})

	table := builder.Build()

	assert.Equal(t, 1, len(table.Routes))
	assert.Equal(t, "replaced", table.Routes[0].Tags[0])
	assert.Equal(t, "devlocal04.thiink.systems", table.Routes[0].Targets[0].Target)
	assert.Equal(t, "/teos/v1/routes/credentials/devlocal04/sca", table.Routes[0].Targets[0].Crd)
}

func TestReplaceRouteFromTagUsingReplaceFunc(t *testing.T) {
	builder := cbroute.RouteTableBuilderImpl{}

	builder.AddRoute(route.Route{
		Tags: []string{"test"},
		Source: cbroute.Source().
			AsSource("devlocal02.thiink.systems").
			WhenContext("contracted_customer", "nordvestor").
			WithParameters("param_01", "a_value").
			Build(),
		Targets: []route.RouteTarget{
			cbroute.Target("devlocal03.thiink.systems").
				WithCtxParameters("pass_along_to_target", "a_value").
				WithCRD("/teos/v1/routes/credentials/devlocal03/sma").
				Build(),
		},
	})

	// Use custom function to replace route.
	builder.ReplaceRoute(func(rt route.Route) (route.Route, bool) {
		match := cbroute.HasTags(rt, cbroute.TagSearchModeAny /*all*/, "test")

		if !match {
			return rt, false
		}

		// We have a match -> replace with new route
		return route.Route{
			Tags: []string{"replaced"},
			Source: cbroute.Source().
				AsSource("devlocal02.thiink.systems").
				WhenContext("contracted_customer", "nordvestor").
				WithParameters("param_01", "a_value").
				Build(),
			Targets: []route.RouteTarget{
				cbroute.Target("devlocal04.thiink.systems").
					WithCtxParameters("pass_along_to_target", "a_value").
					WithCRD("/teos/v1/routes/credentials/devlocal04/sca").
					Build(),
			},
		}, true
	})

	table := builder.Build()

	assert.Equal(t, 1, len(table.Routes))
	assert.Equal(t, "replaced", table.Routes[0].Tags[0])
	assert.Equal(t, "devlocal04.thiink.systems", table.Routes[0].Targets[0].Target)
	assert.Equal(t, "/teos/v1/routes/credentials/devlocal04/sca", table.Routes[0].Targets[0].Crd)
}

func TestReplaceRouteFromTagNotFound(t *testing.T) {
	builder := cbroute.RouteTableBuilderImpl{}

	builder.AddRoute(route.Route{
		Tags: []string{"test"},
		Source: cbroute.Source().
			AsSource("devlocal02.thiink.systems").
			WhenContext("contracted_customer", "nordvestor").
			WithParameters("param_01", "a_value").
			Build(),
		Targets: []route.RouteTarget{
			cbroute.Target("devlocal03.thiink.systems").
				WithCtxParameters("pass_along_to_target", "a_value").
				WithCRD("/teos/v1/routes/credentials/devlocal03/sma").
				Build(),
		},
	})

	builder.ReplaceRouteByTag([]string{"test2"},
		route.Route{
			Tags: []string{"replaced"},
			Source: cbroute.Source().
				AsSource("devlocal02.thiink.systems").
				WhenContext("contracted_customer", "nordvestor").
				WithParameters("param_01", "a_value").
				Build(),
			Targets: []route.RouteTarget{
				cbroute.Target("devlocal04.thiink.systems").
					WithCtxParameters("pass_along_to_target", "a_value").
					WithCRD("/teos/v1/routes/credentials/devlocal04/sca").
					Build(),
			},
		})

	table := builder.Build()

	assert.Equal(t, 1, len(table.Routes))
	assert.Equal(t, "test", table.Routes[0].Tags[0])
	assert.Equal(t, "devlocal03.thiink.systems", table.Routes[0].Targets[0].Target)
	assert.Equal(t, "/teos/v1/routes/credentials/devlocal03/sma", table.Routes[0].Targets[0].Crd)
}
