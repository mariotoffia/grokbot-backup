package cbtransportutils

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/PaesslerAG/gval"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/pipeutils"
)

// InvokeContextKey specifies special named _InvokeContext_ keys.
type InvokeContextKey string

const (
	InvokeContextKeyOperation     InvokeContextKey = "op"
	InvokeContextKeyOperationName InvokeContextKey = "oper"
	InvokeContextKeyDirection     InvokeContextKey = "dir"
	// InvokeContextKeyProviderConfig is the key where the `ifprovider.ConfigFull` is stored in the _InvokeContext_.
	//
	// This is the same key as in `ifprovider.PipeContextKeyProviderConfig`
	InvokeContextKeyProviderConfig InvokeContextKey = "pc"
	InvokeContextKeySession        InvokeContextKey = "sess"
	InvokeContextKeyCall           InvokeContextKey = "call"
	InvokeContextKeyCbID           InvokeContextKey = "cbid"
	InvokeContextKeyRemoteID       InvokeContextKey = "rid"
)

// GetGlobalParamAsString returns a global parameter as a string from the session configuration.
func GetGlobalParamAsString(
	session transportmodel.EndpointSession,
	name string,
) (value string, ok bool) {
	pc := session.GetProviderConfig()

	if prms, ok := pc.(ifprovider.ConfigGlobalParams); ok {
		return prms.GetParamAsString(name)
	}

	return "", false
}

// ResolveCredentialPointer will prepare the pointer that is used to fetch the credentials
// to either authenticating the request (e.g. _basic auth_) or in some cases call a remote token endpoint to
// e.g. get OAuth token to use for authenticating the request.
//
// The credential pointer is either a plain string or an expression (wrapped in a _[]_) that is evaluated.
func ResolveCredentialPointer(
	endpoint transportmodel.Endpoint,
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	lang gval.Language,
	ctx map[string]interface{},
) (string, cberror.Error) {
	expr := endpoint.GetCredentials().CredentialsPointer
	if expr == "" {
		return "", nil
	}

	evalCredentialPointer, err := EvaluateExpressionToString(
		expr,
		session,
		lang,
		ctx,
		cberror.ErrorTransportBodyExpressionMalformed,
	)

	if err != nil {
		return "", err
	}

	if evalCredentialPointer == "" {
		return "", nil
	}

	return evalCredentialPointer, nil
}

// CreateAugmentEvalContextWithCredentials will check if _cred_ is not `nil` and publish security
// material onto the context.
//
// CAUTION: This _ctx_ in only expected to be used in custom auth flows in order to e.g. get
//
//	a Oauth token from a remote endpoint.
//
// It will make a shallow copy of the _ctx_ and return it with the security material. If no security
// material was found, the same _ctx_ is returned.
func CreateAugmentEvalContextWithCredentials(
	ctx map[string]any,
	securityMaterial any,
) map[string]any {
	if securityMaterial == nil {
		return ctx
	}

	// Copy security credentials
	if crd, ok := securityMaterial.(securitymodel.StandardCredentials); ok {
		copy := map[string]any{}
		for k, v := range ctx {
			copy[k] = v
		}

		if crd.GetUser() != "" {
			copy[string(securitymodel.CredentialItemTypeUsername)] = crd.GetUser()
		}
		if crd.GetPassword() != "" {
			copy[string(securitymodel.CredentialItemTypePassword)] = crd.GetPassword()
		}
		if crd.GetAPIKey() != "" {
			copy[string(securitymodel.CredentialItemTypeAPIKey)] = crd.GetAPIKey()
		}

		if tokenCred, ok := securityMaterial.(securitymodel.TokenCredentials); ok {
			token := tokenCred.GetToken()
			if len(token) > 0 {
				copy[string(securitymodel.CredentialItemTypeToken)] = token
			}
		}

		return copy
	}

	return ctx
}

// CreateInvokeContext will do a shallow copy of the `session.GetData()` map and upsert entries
// to contain additional information.
//
// .Data
// |===
// |Name 		|Type 								|Description
// |op			|`ifprovider.ConfigOperation`		|The current operation
// |oper		|`string`							|The current operation name
// |dir			|`providermodel.ProviderOperation`	|The current operation type
// |pc			|`ifprovider.Config`				|The current complete provider configuration
// |sess		|`transportmodel.EndpointSession`	|The current endpoint session
// |call		|`transportmodel.EndpointCall`		|The current endpoint call
// |dp			|`[]string`							|The datapoint names for the operation
// |<params>    |Parameter types found `Params`		|The global parameters and operation params overrides
// |===
//
// It will copy the global parameters from the `providermodel.ProviderConfig` as top level keys and
// are overridden by operation parameters (if any) as top level keys. Hence, the operation parameters
// are also copied as top level keys.
//
// If _endpointResolver_ is `nil` or did not resolve to any `transportmodel.ProcessFunc`,
// it will extract all sensors from the provider configuration.
//
// CAUTION: If no direction is set in the _call_ it will use `providermodel.ProviderOperationSensorValueIn`
//
// The _cred_ shall *only* be passed when a preparation of a custom _auth_ flow is to be executed. In this case,
// the _cred_ is used to extract and put into the returned context. Those shall *never* be visible in 'standard'
// flows.
func CreateInvokeContext(
	client transportmodel.EndpointClient,
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	lang gval.Language,
	endpointResolver transportmodel.EndpointFunctionResolver,
) (map[string]interface{}, cberror.Error) {
	var processor transportmodel.ProcessorFunc

	if nil != endpointResolver {
		processor = endpointResolver.ResolveSensorProcessor(
			call.GetProcessor(),
			true, /*parent*/
		)
	}

	// Shallow copy the data context
	m := map[string]interface{}{}
	for k, v := range session.GetSessionContext() {
		m[k] = v
	}

	// Default to include all sensors if no data-points is present
	// in the session context.
	if processor == nil {
		defaultProcessor := func(
			client transportmodel.EndpointClient,
			session transportmodel.EndpointSession,
			call transportmodel.EndpointCall,
			ctx map[string]interface{}) (sensors map[string]string, err cberror.ConfigurationError) {
			s, e := ResolveIDs(session)
			if e != nil {
				return nil, e.(cberror.ConfigurationError)
			}

			return s, nil
		}

		if cbIDs, ok := session.GetSessionContext().CbID(); ok {
			m[string(InvokeContextKeyCbID)] = cbIDs
		} else {
			processor = defaultProcessor
		}

		if remoteIDs, ok := session.GetSessionContext().RemoteID(); ok {
			m[string(InvokeContextKeyRemoteID)] = remoteIDs
		} else {
			processor = defaultProcessor
		}
	}

	// Override data context parameters
	pc := session.GetProviderConfig()
	op := session.GetOperation()

	// Global Params
	if prms, ok := pc.(ifprovider.ConfigGlobalParams); ok {
		globalParams := prms.GetGlobalParams()
		if len(globalParams) > 0 {
			for k, v := range globalParams {
				if resolved, err := EvaluateParameterExpression(
					v, session, lang, m, cberror.ErrorTransportPrepareEvalContextFailed,
				); err == nil {
					m[k] = resolved
				} else {
					return nil, err
				}
			}
		}
	}

	// Default to "sv" if not set in the operation
	dir := call.GetDirection()
	if dir == "" {
		dir = locationmodel.ProviderOperationSensorValueIn
	}

	m[string(InvokeContextKeyOperationName)] = op
	m[string(InvokeContextKeyOperation)] = op.GetOperation()
	m[string(InvokeContextKeyDirection)] = call.GetDirection()
	m[string(InvokeContextKeyProviderConfig)] = pc
	m[string(InvokeContextKeySession)] = session
	m[string(InvokeContextKeyCall)] = call

	// Operation Params
	// If they are expressions, they will be resolved directly.
	operParams := op.GetParams()

	if len(operParams) > 0 {
		for k, v := range operParams {
			if resolved, err := EvaluateParameterExpression(
				v, session, lang, m, cberror.ErrorTransportPrepareEvalContextFailed,
			); err == nil {
				m[k] = resolved
			} else {
				return nil, err
			}
		}
	}

	// Resolve all the datapoints for this call
	if processor != nil {
		sensors, cerr := processor(client, session, call, m)
		if cerr != nil {
			return nil, cerr
		}

		var cbIDs []string
		var remoteIDs []string

		for cbID, remoteID := range sensors {
			cbIDs = append(cbIDs, cbID)
			remoteIDs = append(remoteIDs, remoteID)
		}

		m[string(InvokeContextKeyCbID)] = cbIDs
		m[string(InvokeContextKeyRemoteID)] = remoteIDs
	}

	return m, nil
}

// EvaluateParameterExpression will check if the _expression_ is a string and starts with _[_ and
// ends with a _]_. Hence, interpreted as a parameter expression and is evaluated and returned.
//
// If the expression is not a string, it will be returned as is. If it fails it will return an error
// with error code _errorCodeOnFailEval_.
func EvaluateParameterExpression(
	expression any,
	session transportmodel.EndpointSession,
	lang gval.Language,
	ctx map[string]interface{},
	errorCodeOnFailEval int,
) (any, cberror.Error) {
	if expression == nil {
		return nil, nil
	}

	if str, ok := expression.(string); ok {
		if expr, ok := pipeutils.GetStringExpression(str); ok {
			if res, err := lang.EvaluateWithContext(session.GetContext(), expr, ctx); err != nil {
				if lid, ok := GetGlobalParamAsString(
					session,
					string(ifprovider.ParameterLocationID),
				); ok {
					return nil, cberror.NewCbErrorfWithProps(
						session.GetContext().Service(),
						errorCodeOnFailEval,
						err,
						map[string]interface{}{
							"lid": lid,
						},
						"%s", err.Error(),
					)
				}

				return nil, cberror.NewCbErrorf(
					session.GetContext().Service(),
					errorCodeOnFailEval,
					err,
					"%s", err.Error(),
				)
			} else {
				return res, nil
			}
		}
	}

	return expression, nil
}

// EvaluateExpressionToString will check if the _expression_ is a expression, denoted by beginning and ending with _[]_,
// and evaluate if such is the case.
//
// If it fails to evaluate the expression it will return an error with _errorCodeOnFailEval_.
// If the _expression_ evaluates to `nil` it will return an empty string.
//
// NOTE: When the _expression_ evaluates to anything else than a `string` it will convert it to a `string`.
//
// All non _expression_ will simply be returned as is.
func EvaluateExpressionToString(
	expression string,
	session transportmodel.EndpointSession,
	lang gval.Language,
	ctx map[string]interface{},
	errorCodeOnFailEval int,
) (string, cberror.Error) {
	res, err := EvaluateParameterExpression(
		expression, session, lang, ctx, errorCodeOnFailEval,
	)

	if err != nil {
		return "", err
	}

	if res == nil {
		return "", nil
	}

	if str, ok := res.(string); ok {
		return str, nil
	}

	return fmt.Sprint(res), nil

}
