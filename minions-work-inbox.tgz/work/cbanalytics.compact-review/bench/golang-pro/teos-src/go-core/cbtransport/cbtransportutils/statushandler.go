package cbtransportutils

import (
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/transportmodel"
)

// FindStatusHandler will find any status handler that is registered in the call and best
// matches the _statusCode_.
//
// Which status handler depends on the status code. The status handler registration allows for
// wildcard and it will use the most narrow match.
//
// The _handlers_ is on the `transportmodel.EndpointCallImpl.StatusHandlers` format.
func FindStatusHandler(handlers map[string]string, args transportmodel.InvokeArgs) string {
	// Find the most narrow match.
	statusCode, _ := args.StatusCode()
	handler := handlers[statusCode]

	if len(handler) == 0 {
		l := -1
		for k := range handlers {
			wildcard := strings.Index(k, "*")
			if wildcard == -1 {
				continue
			}

			if wildcard == 0 || strings.HasPrefix(statusCode[:wildcard], k[:wildcard]) {
				if wildcard > l {
					handler = handlers[k]
					l = wildcard
				}
			}
		}
	}

	return handler
}

// InvokeStatusHandlerFunction will invoke the registered status handler function if found.
//
// If handler is found but is one of the well known `transportmodel.StatusCodeOutcome` then the default
// handling will be used. For success it will just copy _body_ and _statusCode_ from the _args_ to
// the _session_ context and return `nil`.
//
// If it is failure it will return a a `cberr.ResponseError`, otherwise it will return an error indicating
// that the handler was not found and no known default was possible.
func InvokeStatusHandlerFunction(
	endpoint transportmodel.Endpoint,
	session transportmodel.EndpointSession,
	call transportmodel.EndpointCall,
	args transportmodel.InvokeArgs,
	handler string,
) cberror.Error {
	sf := ResolveStatusHandler(endpoint, session, call, handler, true /*parent*/)

	if sf != nil {
		return sf(session, call, args)
	}

	if handler == string(transportmodel.StatusCodeOutcomeOk) {
		ctx := session.GetSessionContext()
		body := args.Body()
		if body != nil {
			ctx[string(transportmodel.SessionContextKeysBody)] = body
		}

		if sc, ok := args.StatusCode(); ok {
			ctx[string(transportmodel.SessionContextKeysStatusCode)] = sc
		}

		return nil
	}

	props := map[string]any{}
	if lid, ok := GetGlobalParamAsString(session, string(ifprovider.ParameterLocationID)); ok {
		props["lid"] = lid
	}

	if handler != string(transportmodel.StatusCodeOutcomeFail) {
		return cberror.NewCbErrorfWithProps(
			session.GetContext().Service(),
			1,
			nil,
			props,
			"Unknown status handler: %s",
			handler,
		)
	}

	statusCode, _ := args.StatusCodeAsInt()

	return cberror.NewCbResponseErrorfWithProps(
		session.GetContext().Service(), statusCode,
		fmt.Sprintf("%s %s", call.GetMethod(), args.UrlQuery()),
		args.CurrentNow()-time.Now().UTC().UnixNano(),
		cberror.ResponseErrorTypeExpectedOtherResponseCode,
		http.StatusOK, args.Body(), nil, props, "status-code",
	)
}
