# ADR-0004: Stored rows: adjacent releases read each other's rows, and the deploy repairs what it owns

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-12 |

## Summary

TEOS services keep data in tables: DynamoDB items, database rows and stored
documents. A service release writes rows in one shape, and the next release may
write them in another. This record decides how a stored shape may change so that
an upgrade and a downgrade of a service are both one ordinary deploy, with no
manual step.

The decision in one paragraph:

> Every release reads the rows that the release before it and the release after
> it write. A change to a stored shape only adds attributes. A missing attribute
> reads as a default that the shape's design document states, and an unknown
> attribute is ignored. No release makes an attribute mandatory on read, so none
> requires an attribute that the previous release did not write. When a release
> needs an attribute on every row, the deploy adds it to the rows its service
> owns, on every release. Its conditional writes add only what is missing,
> advance a revision number as every write does, and change no other value. No
> upgrade or downgrade has a manual reset, a script or a recreated table.
> Converters, one decoder per version and `if version == N` branches stay
> forbidden.

## Terms used

| Term | Meaning here |
| --- | --- |
| Stored row | Anything a service writes and reads back later, possibly from another release: a DynamoDB item, a database row, a stored JSON document. |
| Attribute | One named value in a stored row, such as a DynamoDB attribute or a JSON field. |
| Adjacent release | The release of the same service just before or just after a given release. |
| Default | The value a reader uses for an attribute that a row does not have. |
| Service that owns a row | The service whose code writes the row and whose table holds it. Code of that service repairs the row during a deploy. For the IAM catalog, that code is the catalog registrar, and the deploy of any stack that registers catalog rows runs it over every catalog row. |
| Repair | A conditional write that adds the attributes a row lacks and changes no other attribute, except a number used for optimistic locking, which it advances as every write does. |
| Downgrade | A deploy of the previous release of a service over the current one. A CloudFormation rollback of a failed update is one too. |

## Context

The IAM service keeps OAuth scopes, token claims and client packs as rows in the
DynamoDB table `teos-auth-grants`. These rows are called the catalog. Every stack
that declares scopes, claims or packs has a CloudFormation custom resource of
type `Custom::CatalogRegistration`. CloudFormation sends that resource's Create,
Update and Delete events to an IAM Lambda function, the catalog registrar, which
writes the rows.

One IAM release added two attributes to every catalog row:

- `revision`, a number that changes on every write, so that two writers cannot
  overwrite each other without noticing;
- `owner`, which is `deploy` or `operator` and decides whether a deploy may
  change the row.

The same release refused to read a row without them. Its error told the operator
to delete the catalog rows by hand and deploy every stack again. On an AWS
account that held rows from the release before, this is what people saw:

- every deploy of a stack that declares catalog rows failed;
- the admin API's catalog routes answered 409;
- licensing could not read the packs, so no machine client could be created
  from a pack.

The manual reset was the only way forward. It also deleted every row a person
had created through the admin API, because no deploy creates those again.

Two more facts made the problem worse:

1. **A downgrade would break the same way.** The earlier release writes rows
   without the two attributes. After going back to it and forward again, the
   strict release would refuse those rows too.
2. **A release that changes only code never called the registrar.**
   CloudFormation sends an Update to a custom resource only when the resource's
   properties change. The registration's only changing property was the list of
   declarations. A release that kept the same declarations did not run the
   registrar at all, so the deploy had no chance to fix the rows.

The project rule at that time said a stored shape changes by deleting the
previous reader, and that loading an older row fails with an error naming a
reset procedure. That rule assumed no account holds data. Accounts now hold data,
and upgrades and downgrades must work without a person deleting rows.

## Decision

### 1. Every release reads the rows of the release before and after it

A release reads every row that the previous release and the next release write.
These rules make that possible:

- **Only add attributes.** A change never removes, renames or changes the type
  or the meaning of an attribute. It never adds a value to an attribute that
  has a fixed list of values either, because the previous release refuses a
  value it does not know (see the last rule). It adds a new attribute instead.
- **Every attribute has a documented default.** The design document of the
  stored shape says what a row without the attribute means. The default makes
  the row behave as it did in the release that did not write the attribute.
  Changing a default later counts as changing the attribute's meaning, so it is
  not allowed either.
- **Never make an attribute mandatory on read.** In particular, never require
  an attribute that the previous release did not write. A release that starts
  to write a new attribute still reads rows without it, through the default,
  and so does every release after it.
- **Ignore unknown attributes.** A reader does not fail on an attribute it does
  not know. The AWS SDK for Go v2 decoder (`attributevalue.UnmarshalMap` into a
  struct) already skips them. A hand-written decoder must do the same.
- **Refuse types no release writes on read; check content on write.**
  Tolerance covers attributes that are missing or unknown. A present attribute
  stored in a type no release writes for it, such as a number where every
  release writes a string, is refused on read with a typed error that names the
  row and says how to make it readable. So is a value the reader acts on that
  no release writes: a value outside a fixed list, a version number for
  optimistic locking below 1, or an empty string where writers store only
  non-empty text and an empty one would read as missing. Rules about content,
  such as the format of a name, a length limit, the syntax of a pattern or a
  strict semantic version, are checked when a row is written, and a read does
  not repeat them. If a read refused one hand-edited value, every read of the
  table would fail and every deploy would stop until someone fixed that row.
  With the read lenient, only a later change of that one row fails, with an
  error that names the row and its stored value.

### 2. A missing version attribute means "never versioned"

Many stored shapes have a number that changes on every write, used for
optimistic locking: a write succeeds only if the number is still the one that
was read. A row without that number reads as version 0, which means it has never
had one. A write or a delete that read a row without the number is conditioned
on the row still existing and the number still not existing
(`attribute_exists(PK) AND attribute_not_exists(revision)` in DynamoDB), and a
write that read no row on the row still not existing (`attribute_not_exists(PK)`).
Every write stores the number. This is the rule AWS's own optimistic-locking tools
use for a missing version attribute (see Sources).

### 3. The deploy repairs what its service owns, when a release needs it

A tolerant reader already handles a row that lacks an attribute, so most new
attributes need no repair. The deploy adds an attribute to the rows its service
owns only when a release needs it on every row:

- a feature queries or indexes the attribute, so a row without it would be
  missed;
- an older release that may be deployed again requires the attribute, as the
  previous IAM release requires `revision`, `owner` and a pack `version`.

Such a repair:

- runs as part of the deploy, in the same Lambda function that already writes
  the rows during the deploy;
- uses one conditional update per row that only adds what is missing (in
  DynamoDB, `SET a = if_not_exists(a, :value)`), and only while the row exists,
  is still at the optimistic-locking number it read, and still lacks the
  attribute, so it never recreates a deleted row and never overwrites another
  writer's change. A row another writer changed and that
  still lacks the attribute is read and written again, a bounded number of
  times, and then the deploy fails;
- re-checks, in the same condition, every attribute it worked a value out from,
  so a value derived from an attribute another writer changed in the meantime is
  never written;
- gives each attribute a value that keeps the row's meaning for every value a
  real writer stores: the documented default, a value that compares the same
  way against those values (such as `0.0.0` for a missing pack version in IAM,
  which is below every version a write accepts), or, for a version
  number used for optimistic locking, the first number a new row gets;
- changes no other attribute, except a number used for optimistic locking: a
  row that has one gets it plus one, as every write of the row does, so a
  writer that read the row before the repair gets a conflict instead of writing
  it back without what the repair added;
- logs how many rows it changed;
- fails the deploy when it fails, so CloudFormation shows the error and rolls
  the stack back. A failed repair can leave some rows repaired and others not.
  Each row is either fully repaired or untouched, because each gets one
  conditional update, and the next deploy repairs the rest.

The repair is what makes a downgrade work to a release that is stricter than
this record allows. After one deploy every row has the attribute, so that
release can read them. It also means the next release finds the attribute on
every row that the service owns, even though it must still read rows without it.

### 4. The deploy runs on every release

A CloudFormation custom resource that writes or repairs rows has a property
whose value changes on every release: the version in the deploying service's
manifest. The handler ignores the value. Its only job is to make CloudFormation
send an Update on every upgrade and every downgrade. The property is kept apart
from the property that holds the stack's declarations, so the declarations hold
only what the stack declares.

A downgrade and a CloudFormation rollback are ordinary Updates whose properties
are the older ones. The same handler code and the same rules apply to them.

### 5. What stays forbidden

These remain deleted work, not deferred work:

- converters, one-shot migration jobs and scripts, and rewriting rows when they
  are read;
- one decoder per stored version, and `if version == N { ... } else { ... }`
  branches;
- a schema version number stored on each row to choose between decoders;
- field aliases, "the old name still works", and deprecated inputs that are
  still accepted;
- fixtures, goldens or test data kept "for reference" at an older revision;
- notes in documentation that describe what an older release did.

A test that builds a row in the shape the previous release writes, to prove this
release reads it, is not a reference fixture. Every change to a stored shape
needs one (see Verification).

A tolerant reader is one decoder with defaults, not a second decoder. The repair
is a step of the normal deploy that only adds missing attributes, not a
migration job.

### How the IAM catalog follows this record

- A catalog row with no `revision` reads as revision 0. A write or a delete that
  read such a row succeeds only while the row still exists without a
  `revision`, and a write that read no row only while the row is still absent.
- A catalog row with no `owner` reads as `deploy` when its `registeredBy`
  attribute names at least one stack, and as `operator` otherwise. Deploys
  overwrote such rows before `owner` existed, so `deploy` keeps that behaviour.
  A row whose `registeredBy` names no stack reads as `operator`, so no deploy
  changes its content.
- A pack row with no `version` counts as lower than every version, so the next
  deploy that declares the pack may write any valid version.
- Every attribute is read only in the types an IAM release writes for it, and
  any other type is refused with an error that names the row. A `registeredBy`
  that a snapshot restore wrote back as a list of strings reads like the string
  set the registrar writes. An empty `pattern`, `contentHash` or `version`, and
  an empty or repeated stack name in `registeredBy`, set or list, are refused too,
  because no release writes them. The scope routes read scope rows with the
  same rules.
- On every Create and Update, before it registers the stack's declarations, the
  catalog registrar gives every catalog row that lacks a `revision` or an
  `owner` the missing value, and every pack that lacks a `version` the version
  `0.0.0`. Every write refuses a pack version at or below `0.0.0`, such as
  `0.0.0-rc.1`, so `0.0.0` is below every version a pack can declare. The
  update re-checks `registeredBy`, because
  the owner is worked out from it. Repairing first means a registration that
  fails still leaves every row readable for the rollback. Delete does not
  repair.
- After one registration, every catalog row has a `revision` and an `owner`, and
  every pack has a version. The previous IAM release, which requires all three,
  can then read every row and compare every pack, so a downgrade to it works.
- The `Custom::CatalogRegistration` resource has a `ServiceVersion` property, the
  version in the service's `manifest.json`. It is outside the `Payload` property,
  which holds the stack's declarations as one JSON document.

Following the content rule in section 1, the IAM reader does not run the
checks a write runs on a row's content: names, a scope's description, a claim's
pattern as a regular expression, the scopes and claims a pack names, and
whether a pack version is a strict semantic version. A stored value that fails those checks reads as stored, for example
the pack version `1.0`. A deploy or an admin change that changes that pack's
content then fails with an integrity error that names the pack and the stored
version.

The IAM design document `go-services/core/management/iam/_design/catalog.adoc`,
section "Upgrade and Downgrade", describes this in full.

## Alternatives considered

**Keep the manual reset.** Rejected. Every deploy fails until a person acts. The
reset deletes rows that people created through an API, and no deploy creates
them again.

**A one-shot migration job or script.** Rejected. It is a manual or scripted
step on every account. It does not fix rows that the previous release writes
after a downgrade. AWS describes the same choice for DynamoDB (bulk update versus
tolerating missing attributes) and its costs.

**Expand and contract over two releases.** The first release writes the
attribute and still reads rows without it. The second release requires it.
Rejected. The second release is safe only once every row in every account has
the attribute, including rows no deploy writes, and nothing checks that. A row
that lacks it then fails every read. Keeping the default costs a few lines in
the decoder and has no such risk.

**A schema version on each row, with one decoder per version.** This is how
Kubernetes custom resources and Terraform state handle changes. Rejected. It
needs a decoder for every version a reader may meet and a rule for versions newer
than the reader. Terraform refuses a downgrade by design, which is the opposite
of what TEOS needs. Adding attributes needs neither.

**Make the custom resource run on every deploy with a timestamp or a random
value.** Rejected. The template then differs on every synth, so every diff shows
a change, and the handler runs even when nothing changed. The service version
changes exactly once per release.

**Default a missing owner to "unknown, never touch".** Considered for the IAM
catalog. Rejected there, because deploys overwrote declared rows before `owner`
existed. Rows that name a stack keep that behaviour, and rows that name none
already read as operator-owned, which no deploy changes.

## Consequences

**What a person sees.** Upgrading or downgrading a service by one release is one
deploy. Nobody deletes rows, recreates a table or runs a script. Rows that people
created through an API survive both.

**What this allows.**

- Adding attributes to a stored shape, each with a documented default.
- Adding new kinds of rows under new keys, when older readers select rows by
  key and so never read them.
- Refusing, on read, an attribute stored in a type no release writes.

**What this forbids.**

- Removing, renaming or changing the type of an attribute.
- Adding a value to an attribute that has a fixed list of values, because the
  previous release refuses it.
- Making an attribute mandatory on read in any release.
- Changing a documented default.
- A manual step in an upgrade or downgrade.

A change that cannot be made by adding attributes, such as a rename or a type
change, needs its own decision record before any code is written.

**Downgrade works between adjacent releases.** That is what the rules promise and
what tests check. A jump over several releases is not promised.

**Attributes are never removed.** A table keeps attributes that no code uses any
more. The cost is a few bytes per row.

**A redeploy at the same version repairs only when it is forced.**
CloudFormation sends no Update when no property changed. Every release has a
new version, so every release repairs. A redeploy forced with `cbdeploy
--force` sets the CDK context `force=true`. Two custom resources then add a
property, `ForcedAt`, whose value changes on every synth. CloudFormation sends
their registrars an Update, so a forced redeploy repairs too:

- the IAM catalog registration (`Custom::CatalogRegistration`);
- the service registration (`ServiceRegistration`) that every stack has. Its
  registrar, an app store Lambda function, writes the service's rows in the app
  store's service registry.

**A repair costs one read of the owned rows per deploy.** It exists only where
a release needs an attribute on every row. For a large table that read is a
large scan on every release, so a repair there needs an index or a query that
finds only the rows that lack the attribute. For the IAM catalog it is one more
filtered scan of the whole `teos-auth-grants` table per stack that registers
catalog rows. That scan shares the 100-page limit described in the section
"Limits" of the IAM catalog design document.

**Rows the previous release writes during a downgrade lack the new attributes
again.** The tolerant reader reads them, and the next deploy of the newer release
repairs them.

## Verification

A change to a stored shape is complete when these tests exist and pass:

- a test that reads a row in the exact shape the previous release writes and
  gets the documented defaults;
- a test that reads a row with an attribute the reader does not know and gets
  no error;
- a test that an attribute stored in a type no release writes is refused with
  the typed error, and a test that a value that breaks only a content rule
  reads as stored;
- when the shape has a version attribute, a test that a write expecting version
  0 replaces a row without one, and a second such write is a conflict;
- when the deploy repairs rows, a test against the real storage (DynamoDB Local
  for DynamoDB) that the repair adds only the missing attributes, changes nothing
  else, leaves a row another writer changed in between as it is, and changes
  nothing when run a second time;
- when a custom resource repairs rows, a synth test that its version property
  equals the service's manifest version.

## Sources

Primary sources only.

- Martin Fowler, Tolerant Reader:
  <https://martinfowler.com/bliki/TolerantReader.html> ("only take the elements
  you need, ignore anything you don't").
- IETF RFC 9413, Maintaining Robust Protocols:
  <https://www.rfc-editor.org/rfc/rfc9413.html> (silently accepting faulty input
  hides problems; tolerate additions by rule, not invalid values).
- Google AIP-180, Backwards compatibility: <https://google.aip.dev/180> (new
  fields need a default that matches earlier behaviour; no new required fields;
  changing a default is breaking).
- Protocol Buffers, proto2 language guide:
  <https://protobuf.dev/programming-guides/proto2/> ("`required` must not be used
  for new fields"; old binaries ignore new fields).
- AWS Database Blog, Evolve your Amazon DynamoDB table's data model:
  <https://aws.amazon.com/blogs/database/evolve-your-amazon-dynamodb-tables-data-model>
  (tolerate items without the new attribute, or bulk update them).
- AWS SDK for Go v2, `feature/dynamodb/attributevalue/decode.go`:
  <https://github.com/aws/aws-sdk-go-v2/blob/main/feature/dynamodb/attributevalue/decode.go>
  (a struct target skips unknown attributes and leaves missing ones at their zero
  value).
- Amazon DynamoDB, Optimistic locking with a version number (DynamoDBMapper):
  <https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/DynamoDBMapper.OptimisticLocking.html>
  (a null version is a new item, written with the condition that the version
  attribute does not exist).
- AWS SDK for Java v2, `VersionedRecordExtension`:
  <https://github.com/aws/aws-sdk-java-v2/blob/master/services-custom/dynamodb-enhanced/src/main/java/software/amazon/awssdk/enhanced/dynamodb/extensions/VersionedRecordExtension.java>
  (an absent version is written with `attribute_not_exists(version)`).
- Amazon DynamoDB, Update expressions:
  <https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Expressions.UpdateExpressions.html>
  (`if_not_exists`).
- Amazon DynamoDB, Condition expression functions:
  <https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Expressions.OperatorsAndFunctions.html>
  (`attribute_not_exists`, `attribute_exists`).
- AWS CloudFormation, Custom resources:
  <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/template-custom-resources.html>
  and the request reference
  <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/crpg-ref.html>
  (an Update is sent when the resource's properties change; a changed physical
  ID is a replacement).
- AWS CDK, custom resources README:
  <https://github.com/aws/aws-cdk/blob/main/packages/aws-cdk-lib/custom-resources/README.md>
  (a failed Update is followed by an Update with the previous properties).
- AWS CDK, triggers README:
  <https://github.com/aws/aws-cdk/blob/main/packages/aws-cdk-lib/triggers/README.md>
  (no built-in switch to run on every deployment).
- Kubernetes, Versions in CustomResourceDefinitions:
  <https://kubernetes.io/docs/tasks/extend-kubernetes/custom-resources/custom-resource-definition-versioning/>
  (stored objects keep the version they were written in, and an old version
  cannot be dropped while stored data uses it).
- HashiCorp, Manage Terraform versions:
  <https://developer.hashicorp.com/terraform/tutorials/cli/versions> (an older
  Terraform refuses newer state; there is no supported way back).
