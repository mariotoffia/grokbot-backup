# Running a local environment

## Overview

A **local environment** is what stands in for AWS on a developer's machine. It
is two Docker containers plus the Docker network they share:

- **Floci**, an emulator that answers almost every AWS API on one port,
  DynamoDB and DynamoDB Streams included.
- **DynamoDB Local**, Amazon's own single-process build of DynamoDB. Floci
  forwards every DynamoDB call to it and keeps the data there, one database
  per account and region, the way AWS keeps them apart.

DynamoDB Local sits behind Floci on purpose. TEOS storage adapters depend on
conditional-write behaviour: a write happens only when a condition still holds,
and a second writer racing the first one must be rejected. That has to be the
reference behaviour rather than an emulation of it. If an emulator ever accepted
a write the condition should have rejected, a test would pass while the rule it
exists to protect was broken.

Callers only ever talk to Floci, exactly as they would talk to AWS. Streams,
their Lambda event source mappings and tags are served by Floci itself. They
take the address the environment reports, or the AWS configuration it builds,
and hand that to the AWS SDK.

The emulator image has to carry this forwarding. The environment asks the
emulator which DynamoDB backend it runs at start-up and refuses to continue when
the answer is not DynamoDB Local, naming the image to use instead.

Two Go packages and one command are involved:

| Name | What it is |
| --- | --- |
| `go-core/utils/testutils/localenv` | Creates, finds and removes local environments. |
| `go-core/utils/testutils/flocilocal` | The driver for the emulator container itself: its image, its readiness checks, its certificate. |
| `cbtest local` | The command line front end, in `cmd/cbtest`. |

For choosing what a test depends on, see [authoring.md](authoring.md). For the
commands that run the test suites, see [TESTS.md](../../../TESTS.md).

## Build the command

`cbtest` is a Go program in this repository. Build it once, from the
repository root:

```bash
make cbtest-bin
```

That writes `_dist/_output/bin/cbtest`. `make test-integration` builds it for
you. The examples below assume `_dist/_output/bin` is on your `PATH`, or that
you type the full path.

## Start one and keep it

```bash
cbtest local serve --name dev --resources-only
```

This starts the pair, stays in the foreground and prints the settings to export
in another terminal. The terminal it runs in owns the environment: pressing
Ctrl+C, or closing that terminal, ends the environment. There is no background
service and nothing to stop later.

`--name` gives the environment an identifier. Without it, one is made up from
the process identifier and the clock, for example `teos-31162-766000`.

`--resources-only` starts the AWS services and deploys nothing into them. It is
the only mode available today, so pass it. Deploying TEOS into a local
environment is the service-test harness's job, not this command's (see
[SERVICE_TEST.md](../../../SERVICE_TEST.md)).

`--keep` leaves the environment running when `serve` is interrupted, instead of
removing it.

What it prints:

```text
environment dev (resources, temporary)
  emulator:  https://127.0.0.1:60991
  account:   000000000000 in eu-west-1
  certificate: /var/folders/.../teos-dev-ca-3820951248.pem

To use it from another terminal:
  export AWS_ACCESS_KEY_ID='test'
  export AWS_CA_BUNDLE='/var/folders/.../teos-dev-ca-3820951248.pem'
  export AWS_DEFAULT_REGION='eu-west-1'
  export AWS_ENDPOINT_URL='https://127.0.0.1:60991'
  export AWS_ENDPOINT_URL_S3='https://127.0.0.1:60991'
  export AWS_IGNORE_CONFIGURED_ENDPOINT_URLS='false'
  unset AWS_PROFILE
  export AWS_REGION='eu-west-1'
  export AWS_SECRET_ACCESS_KEY='test'
  unset AWS_SESSION_TOKEN
  export CB_ACCOUNT_ID='000000000000'
  export CDK_DEFAULT_ACCOUNT='000000000000'
  export CDK_DEFAULT_REGION='eu-west-1'
  export CDK_DEPLOY_ACCOUNT='000000000000'
  export NODE_EXTRA_CA_CERTS='/var/folders/.../teos-dev-ca-3820951248.pem'
  export TEOS_DEPLOYMENT='local'
  export TEOS_TEST_ENVIRONMENT='dev'

Ready. Press Ctrl+C to stop.
```

The credentials are placeholders. The emulator does not check them, but the AWS
SDK refuses to sign a request without them. `AWS_PROFILE` and
`AWS_SESSION_TOKEN` are removed on purpose, so that a live single-sign-on
session on the machine cannot leak into a run that answers for a made-up
account number. They are removed rather than set to empty, because the AWS
command line tool reads an empty `AWS_PROFILE` as a profile whose name is the
empty string and refuses to run.

Two more settings keep every AWS call on this environment:

- `AWS_IGNORE_CONFIGURED_ENDPOINT_URLS` is `false`. Set to `true`, in the shell
  or as `ignore_configured_endpoint_urls` in the AWS shared configuration file,
  it makes the AWS SDKs drop every address above and call real AWS.
- A per-service address such as `AWS_ENDPOINT_URL_SQS` wins over
  `AWS_ENDPOINT_URL` for its one service. Every such variable this command's
  own process has is printed pointing at the emulator as well, including one
  that is set but empty. `exec` passes the same settings to its command, and a
  test that attaches through the `testenv` package points the variables its
  own process has at the emulator in the same way. Anything else run from a
  shell with a per-service variable of its own is not covered: unset the
  variable first.

The emulator answers for AWS account `000000000000` and signs for region
`eu-west-1`. Both appear in every ARN a local run produces.

## Run one command against a fresh environment

```bash
cbtest local exec --resources-only -- go test -tags=integration,floci ./...
```

This starts a pair, runs the command with those settings passed directly to the
child process, and removes the pair afterwards. Nothing is printed for a shell
to read and re-quote: the settings go into the child's environment.

The child's exit status becomes this command's exit status, so a failing test
run still reports as a failing test run. A setup or clean-up failure also makes
the status non-zero, because an environment left behind changes what the next
run sees.

An interrupt is passed on to the child, so stopping a test run stops the tests
rather than leaving them orphaned.

With `TEOS_LOCAL_KEEP` set, the pair is created as retained (see
[Retained environments](#retained-environments)), so `exec` leaves it running
when the command finishes. It says so as the last thing it prints: the
environment's name, the settings that reach it from another terminal in the
form `serve` prints them, and the command that removes it.

```text
environment teos-46175-513000 was kept and is still running.

To use it from another terminal:
  export AWS_ACCESS_KEY_ID='test'
  ...
  export TEOS_TEST_ENVIRONMENT='teos-46175-513000'

To remove it:
  cbtest local stop --name teos-46175-513000
```

## Remove one

```bash
cbtest local stop --name dev
```

This removes both containers, any containers the emulator launched for that
environment, and the Docker network they shared. Stopped containers are
removed as well: a retained environment's containers stop whenever Docker or
the machine restarts.

`--name` is required. There is no "remove whichever one is running": that would
delete an environment a test run in another terminal is halfway through using.
Naming an environment that is not there is an error, so a typo is reported
rather than silently doing nothing.

## Print the settings of a running environment

```bash
eval "$(cbtest local env)"
```

This prints the settings that reach a running environment that was kept on
standard output, one shell line per variable and nothing else there. `eval` runs those lines in
the current shell. Every message, an error included, goes to standard error,
so a failure leaves nothing for `eval` to run. It starts nothing and removes
nothing.

It picks the environment the way a test does (see
[Attaching from a test](#attaching-from-a-test)):

1. The one `--name` names.
2. The one the `TEOS_TEST_ENVIRONMENT` variable names.
3. The only one running.

When none is running, or several are running and none is named, it fails and
the error lists the identifiers of the ones that are running. Name one:

```bash
eval "$(cbtest local env --name dev)"
```

It refuses an environment that is not kept. Such an environment is removed
when the process that started it ends, and a certificate file printed for it
would be left with nothing to remove it. `cbtest local serve` and
`cbtest local exec` print the settings of the environment they start
themselves. For one that stays, start it with
`cbtest local serve --name dev --resources-only --keep`, or keep one with TEOS
deployed as [SERVICE_TEST.md](../../../SERVICE_TEST.md#keep-one) shows.

It prints the environment's own settings: the emulator address, the
certificate file, the placeholder credentials, the account and region for the
AWS SDKs and the CDK, the deployment target and the environment's name. It
adds one more, `CB_ACCOUNT_DOMAIN`, the account domain. That is what a deploy of a provision config to the local target
gets: the account alias in front of `common.dns.local.baseDomain`, for example
`devlocal02.localhost.floci.io`. The file read is
`deployment/provision-config.yaml` in the repository the current directory is
in. Name another with `--provision-config <file>`, and name the one the
environment was deployed from, so the name matches what is deployed.

The certificate file in `AWS_CA_BUNDLE` and `NODE_EXTRA_CA_CERTS` stays after
the command ends. It is named `teos-<name>-ca-<number>.pem` in the temporary
directory, which is the name `cbtest local stop --name <name>` removes. When a
file of that name already holds the emulator's certificate, such as the one
`serve` wrote, that file is printed instead of a new one, so running the
command again writes nothing new.

Each line is `export KEY='value'`, except for `AWS_PROFILE` and
`AWS_SESSION_TOKEN`, which are removed with `unset KEY`. A live single-sign-on
session must not reach a run against the emulator's made-up account, and the
AWS command line tool refuses every command when `AWS_PROFILE` is exported
empty. With them removed, the `aws` command, `cdk` and `cbdeploy` all work in
that shell.

## Sign in with a browser

The command that signs an operator in to a deployment (`cbdeploy sso login`)
works against a deployment in a kept local environment, with a real browser:

```bash
eval "$(cbtest local env)"   # or: eval "$(cbtest local env --name dev)"
cbdeploy sso login
```

On the local target (`TEOS_DEPLOYMENT=local`) the browser opens
`http://api.auth.<account domain>:<emulator port>/oauth2/authorize?...`, with
the port taken from `AWS_ENDPOINT_URL`. This works with no certificate in the
browser, for three reasons:

- Every name under `localhost.floci.io` resolves to this machine through
  public DNS, so the name reaches the port the emulator is published on.
- The emulator answers plain HTTP and HTTPS on that one port.
- The emulator finds the user pool of a Cognito custom domain by the host name
  alone, so the sign-in page answers on the plain address too.

The rest of the sign-in is the same as on AWS. After the browser signs in,
`cbdeploy` exchanges the code at `https://api.auth.<account domain>/oauth2/token`
over verified HTTPS, sent to the emulator and trusting the certificate file,
like every other TEOS call from a command line tool. On the AWS target the
browser opens `https://api.auth.<account domain>/oauth2/authorize`.

Each environment publishes its emulator on a port of its own, and the address
the browser opens includes that port. A shell set up for one environment
therefore signs in to that environment, even when another one runs a
deployment with the same account domain.

The environment has to hold these before a sign-in can work:

| What | Created by |
| --- | --- |
| The public Cognito user pool | The groundzero stack |
| Its custom domain `api.auth.<account domain>`, with a certificate | The groundzero stack |
| The app client `teos-cbdeploy`, and the CloudFormation export `TeosCbdeployWebClientId` that `cbdeploy` reads its identifier from | The IAM service stack, from `services.iam.appClients` in the provision config |
| A user with a password | The IAM service stack, from `services.iam.seedUsers`, or created by hand |

Deploying the IAM service deploys groundzero first, because it depends on it.
Both deploy on the emulator image `common.local.emulator` names, including the
`teos-cbdeploy` client and the seed user, with Lambda code signing switched
off. The emulator cannot create a code signing configuration, and
`deployment/provision-config.yaml` switches signing on, so deploy from a file
like this one. It must sit inside the repository, because the `inherit` and
`$copy` paths are read from the repository root:

```yaml
alias: $copy:deployment/provision-config.yaml::alias
common:
  environment: devlocal
  architecture: arm64
  dns:
    inherit: deployment/provision-config.yaml::common.dns
  local:
    inherit: deployment/provision-config.yaml::common.local
  signing:
    lambda:
      disabled: true
      daysValid: 30
services:
  iam:
    inherit: deployment/provision-config.yaml::services.iam
```

Then, from the repository root, with a kept environment named `dev`:

```bash
eval "$(cbtest local env --name dev)"
cbdeploy cfn bootstrap --account 000000000000 --region eu-west-1
cbdeploy cfn deploy --provision-config <that file> --service iam-service
```

The seed user has no password the emulator can mail, so set one. The pool
requires at least 20 characters, with upper case, lower case, a digit and a
symbol:

```bash
pool=$(aws cognito-idp describe-user-pool-domain --domain "api.auth.$CB_ACCOUNT_DOMAIN" \
  --query DomainDescription.UserPoolId --output text)
aws cognito-idp admin-set-user-password --user-pool-id "$pool" \
  --username <seed user's email> --password '<password>' --permanent
cbdeploy sso login
```

`cbdeploy sso login` finds the `teos-cbdeploy` client through its export, so
it needs no `--client-id`.

## Attaching from a test

A test that asks for AWS resources and was compiled with the `floci` build tag
attaches to a running environment. It starts no container and removes none.

The environment is selected in this order:

1. The endpoints the caller supplied in code. Supplying them means supplying
   both: the emulator address and the root certificate that verifies the
   emulator. A certificate downloaded over an unauthenticated connection from an
   arbitrary machine is not evidence that the machine can be trusted, so it has
   to be passed in.
2. The environment named by the `TEOS_TEST_ENVIRONMENT` variable.
3. The single suitable environment running on the machine.

Finding none and finding several are both errors. Guessing which one a test
meant is how one test run destroys another's work.

An environment is suitable when it is prepared at least as far as the test
needs. A test that needs a deployed TEOS is not handed a bare set of running
services. A test that only needs running services may use a deployed one.

The test signs its requests for the AWS region the environment was made for,
which the environment records in a label. The emulator keeps region-scoped
resources, such as parameters, apart per region, so a test signing for another
region would not find them. Asking for a different region is an error.

Attaching never deletes anything. The containers, the network and the
creator's certificate file are left exactly as they were found. Closing an
attachment removes only the attaching process's own copy of the certificate
file. Ownership is never inferred. Deleting an environment is a separate call
that names it: the library's `Remove` function, which `cbtest local stop
--name` uses (see "Remove one" above).

The service-test harness (`deployment/lib/svctest`) deploys into an
environment it did not create when `TEOS_TEST_ENVIRONMENT` names one. It
deploys the services it tests again, even when they are already there, and
removes them at the end. It leaves their dependencies, such as groundzero, and
the environment itself in place. [SERVICE_TEST.md](../../../SERVICE_TEST.md)
explains service tests end to end, keeping and reusing an environment
included.

## Retained environments

By default a created environment is **temporary**: the process that created it
removes it when it finishes.

Two things make one **retained**, meaning it stays running until somebody
removes it explicitly:

- `cbtest local serve --keep`.
- The `TEOS_LOCAL_KEEP` variable, set to anything other than an explicit off
  value. The off values are an empty string, `0`, `false`, `no` and `off`.

Retention is decided when the containers are created, not when the process
stops. Docker fixes a container's labels at creation, so an environment cannot
be relabelled as retained after the fact.

What stays for a retained environment: both containers, the Docker network,
any containers and volumes the emulator created, and the certificate file the
creating process wrote. The file stays because the settings the creator printed
name it, and a later shell that takes those settings has to find it.

Remove a retained environment with `cbtest local stop --name <name>`. That
removes all of the above, the certificate file included. `serve` and `exec`
print that command, with the name filled in, whenever they finish and leave a
retained environment running.

## Docker labels

Every container in one environment carries five labels. Docker stores labels
with the container, so any process on the machine can find the group again.

| Label | Values | Meaning |
| --- | --- | --- |
| `teos.environment.id` | the environment's identifier | What "the same environment" means. |
| `teos.environment.purpose` | `resources` or `deployment` | How far it is prepared. `resources` means the AWS services run and nothing is deployed into them. `deployment` means TEOS itself has been deployed, so its tables, functions and APIs exist. |
| `teos.environment.lifecycle` | `temporary` or `retained` | Whether it outlives the process that created it. |
| `teos.environment.role` | `floci` or `dynamodb` | Which of the two containers this is. |
| `teos.environment.region` | an AWS region, such as `eu-west-1` | The region the environment was made for, and the one a test attaching to it signs for. |

List what is running:

```bash
docker ps --filter "label=teos.environment.role=floci" \
  --format '{{.Names}}\t{{.Ports}}'
```

Read one environment's labels:

```bash
docker inspect -f '{{json .Config.Labels}}' dev-floci
```

Names are derived from the identifier, so `docker ps` is readable without
reading labels: the emulator container is `<id>-floci`, the database container
is `<id>-floci-ddblocal`, and the network is `teos-net-<id>`.

## Certificates

The emulator creates its own certificate authority every time it starts. A
client therefore has to be told to trust that exact authority, and a certificate
kept from an earlier run is worth nothing.

**Go clients get it in memory.** `Local.AwsConfig()` builds an AWS configuration
whose HTTP transport trusts exactly that certificate, on top of the ones the
machine already trusts. That client does **not** read `AWS_CA_BUNDLE`, because
it is constructed directly rather than loaded from the environment.

**Command line tools need a file.** Two variables name it, and both are set to
the same path:

| Variable | Read by |
| --- | --- |
| `AWS_CA_BUNDLE` | The AWS SDKs and the AWS command line tool. |
| `NODE_EXTRA_CA_CERTS` | Node.js, which runs the AWS CDK command line tool. |

Each process writes its **own** copy of that file, including a process that
attached to somebody else's environment. Closing an attachment removes only that
process's copy, so it never takes away the file the creator's tools are still
reading.

The file is created readable and writable by its owner alone, with a name no
concurrent run can take.

Nothing in this machinery changes the operating system's trust store, the
process-wide default HTTP transport, or the verification settings of any client
it did not build.

## HTTPS, and the four exceptions

Ordinary service calls to the emulator use verified HTTPS. There are exactly
four places where plain HTTP is used, and each is deliberate:

1. **Fetching the certificate itself**, from an emulator on this machine. This
   is the one request that cannot be verified, because it is the request that
   establishes verification. Everything after it uses the HTTPS address.
2. **Floci's calls to DynamoDB Local.** DynamoDB Local serves no HTTPS at all.
   Only Floci reaches it, over the Docker network the two share, and nothing on
   this machine is given its address.
3. **Isolated fake HTTP servers inside unit tests**, such as one built with the
   standard library's `httptest`. Nothing leaves the process.
4. **The browser's sign-in pages** on the local target. The browser does not
   trust the certificate authority the emulator makes up when it starts, so
   `cbdeploy sso login` hands it the plain address of the login host (see
   [Sign in with a browser](#sign-in-with-a-browser)). Only the browser uses
   it. The token exchange that follows is verified HTTPS.

A TLS failure stops the operation. Nothing retries the same call over plain
HTTP, nothing switches certificate verification off, and no test flag rewrites a
URL's scheme.

## Troubleshooting

### No environment is running

```text
localenv: no local environment is running, so there is nothing to attach to;
start one with "cbtest local serve", or set TEOS_TEST_ENVIRONMENT to the
identifier of a remote one
```

The test was compiled with the `floci` build tag and asked for AWS resources,
and there is nothing to attach to. Start one in another terminal with
`cbtest local serve --name dev --resources-only`, or wrap the whole run in
`cbtest local exec`.

### Several environments are running

```text
localenv: 2 local environments are running (dev, teos-31162-766000), so which
one to use has to be said explicitly; set TEOS_TEST_ENVIRONMENT to one of those
identifiers
```

Export `TEOS_TEST_ENVIRONMENT=dev`, or remove the ones you do not want with
`cbtest local stop --name <name>`.

### A stale certificate path

A shell kept from an earlier run still exports `AWS_CA_BUNDLE` pointing at a
file that has been removed. What you see depends on what reads it. A TEOS
service that loads its AWS configuration refuses to start, naming the file. An
HTTP client from `httputil.NewClient` writes a warning naming the file and then
connects without trusting the emulator, so the connection fails.

Re-export the settings the current environment printed. An emulator that has
been restarted also has a new port, so `AWS_ENDPOINT_URL` is stale as well.

### An unknown certificate authority

```text
x509: certificate signed by unknown authority
```

The connection reached the emulator but nothing on this side trusts the
certificate it presented. Either the two certificate variables are not set at
all, or they name the file of a different environment. Export the ones the
running environment printed.

If the failing caller is a Go client you built yourself, that is the cause: a
client constructed directly does not read `AWS_CA_BUNDLE`. Build it from
`Local.AwsConfig()` instead, or add the certificate to its pool yourself.

### A hostname mismatch

```text
x509: certificate is valid for <one name>, not <another>
```

The certificate the emulator presented does not cover the name that was asked
for. The TLS handshake always uses the hostname in the URL, so this means the
URL named something the emulator has no certificate for. Check the account
domain you passed: a local run uses `<alias>.localhost.floci.io`, not
`<alias>.thiink.systems`. If the name is right, the deployment that creates that
custom domain has not been made in this environment yet.

### Missing Cognito metadata on a deployment

```text
testenv: read which TEOS deployment this test is attached to: ...
```

A test that asked for a deployed TEOS could not read the deployment's identity.
That identity lives on the deployment's public Cognito user pool: the account
domain is the pool's custom login domain, and the alias and tier are the tags
`teos:account-alias` and `teos:deploy-env`.

An incomplete answer means the deployment does not carry the current
configuration. Deploy the groundzero stack again from the current provisioning
configuration, which is what writes those tags. If the account holds more than
one public pool, name the one you mean with `testenv.Options{UserPoolID: ...}`.

### Half an environment

```text
localenv: environment "dev" has a running emulator but no running DynamoDB
container, so any test storing data would fail part way through; remove what is
left of it and start a new one
```

One of the two containers has stopped or been removed by hand. Remove the rest
with `cbtest local stop --name dev` and start a new one.

## Where to go next

- [TESTS.md](../../../TESTS.md) — the commands that run tests.
- [SERVICE_TEST.md](../../../SERVICE_TEST.md) — deploying a service into a
  local environment or an AWS account, testing it and removing it.
- [authoring.md](authoring.md) — choosing an initializer and writing the test.
- [API_ENDPOINT.md](../../../API_ENDPOINT.md) — how a TEOS HTTPS call reaches
  the emulator without the URL changing.
