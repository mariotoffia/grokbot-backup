# Writing a TEOS test

## Overview

Every Go test in this repository starts by saying what it depends on. It does
that by calling one of three **initializers** from the package
`go-core/utils/testutils/testenv`. An initializer is a function that prepares
the process for a test: it sets the environment variables TEOS code reads at
start-up, and, when the test asks for it, gets hold of an AWS backend.

The name of the initializer is the declaration. `testenv.EnvDefaults` says "I
need nothing outside this process". `testenv.EnvUsingManualAWSResources` says
"I call AWS APIs and create my own resources". `testenv.EnvTEOSDeployed` says
"I call a TEOS system somebody has already deployed".

This page covers how to choose one, how to attach it to a test or to a whole
package, and the rules that follow. For the commands that run the tests, see
[TESTS.md](../../../TESTS.md). For starting and operating the local containers
that stand in for AWS, see [local-environments.md](local-environments.md).

## Decide what your test depends on

| Your test… | Initializer | What it gets | Backend |
| --- | --- | --- | --- |
| Calls only the code under test, with fakes you build yourself | none | nothing | none |
| Needs TEOS settings, such as a deployment tier or an account domain, but reaches nothing outside the process | `testenv.EnvDefaults` | TEOS settings | none |
| Owns a container or server that only this test binary uses, such as its own DynamoDB Local | `testenv.EnvDefaults`, inside your own initializer that starts the fixture | TEOS settings plus your fixture | none, you own the fixture |
| Creates the AWS resources it needs and removes them again | `testenv.EnvUsingManualAWSResources` | TEOS settings plus a working AWS configuration | the build tag decides |
| Calls the APIs, functions or tables of a deployed TEOS | `testenv.EnvTEOSDeployed` | the above, plus the deployment's account domain, account alias and tier | the build tag decides |
| Calls an equipment vendor's API and nothing of ours | `testenv.UseDotEnv(t)` and `testenv.RequireEnv(t, ...)`, then `testenv.EnvDefaults` or nothing at all | the vendor's credentials from the repository's `.env`, plus TEOS settings if you asked for them | none; the vendor is reached at its real address on both backends |

A test with no initializer at all is the normal case for pure logic. Do not add
one to a test that does not need it.

### A test that calls an equipment vendor

The vendor's credentials live in the `.env` file at the root of the
repository, the directory that holds `go.work`. `.env-example` lists every
variable. None of the initializers reads that file, so the test reads it
itself, before its initializer. It then names the credentials it needs, so
that a checkout without them skips the test instead of failing it:

```go
func TestListLocations(t *testing.T) {
    testenv.UseDotEnv(t)
    env := testenv.RequireEnv(t, "BUILDINGX_TEST_CLIENT_ID", "BUILDINGX_TEST_CLIENT_SECRET")
    testenv.Use(t, testenv.EnvDefaults)

    clientID := env["BUILDINGX_TEST_CLIENT_ID"]
    // ...
}
```

A value already exported in the shell wins over the file, and Go removes the
file's values again when the test ends. A missing file reads nothing, because
the values can also come from the shell. Read the variables inside the test,
never into a package-level variable: Go fills those in before any test runs.

`testenv.RequireEnv` returns the value of every variable it names. When one
or more of them is unset, or holds only white space, it skips the test with a
message that names every missing variable and says to set it in `.env` or in
the shell. Call it before the first call to the vendor, and name every
variable the test reads, so one message lists all of them. Every name must be
in `.env-example`, because the message sends the reader there. A test that
only parses recorded vendor data needs no credentials: do not add the check
to it.

A `TestMain` cannot skip a test, so it uses `testenv.RequireEnvMain`
instead. It copies each named variable the process does not have from the
`.env` file into the process, and only those, so the file's other settings do
not change how the rest of `TestMain` runs. It returns the same message when
something is still missing. `TestMain` prints it and exits with status 0, as a
uService test does when `CB_SERVICE_TEST` does not select it:

```go
func TestMain(m *testing.M) {
    if !svctest.ShouldRunServiceTest() {
        os.Exit(0)
    }

    skip, err := testenv.RequireEnvMain("CB_DEFAULT_GEOCODERAPI_KEY")
    if err != nil {
        panic(err)
    }

    if skip != "" {
        fmt.Println(skip)
        os.Exit(0)
    }

    // build the harness and run the tests
}
```

Use it only for a key the whole package cannot run without, such as one the
deployment itself requires. When only some tests need a credential, check it
in those tests with `testenv.RequireEnv`, so the others still run.

### A pure test needs nothing

```go
func TestPercentOfCapacity(t *testing.T) {
    assert.Equal(t, 50, percentOfCapacity(5, 10))
}
```

### A test whose subject is how TEOS reads its own settings

Use the standard library's own helper, `t.Setenv`, not an initializer. Such a
test has to control the exact values it is checking, and an initializer would
overwrite them.

The deployment target is the usual case. A provisioning configuration names one
set of DNS names per target — `aws` for Amazon's endpoints, `local` for the
local emulator — and the loader chooses between them by reading
`TEOS_DEPLOYMENT`. A test that checks a resolved domain sets that variable
itself: a run inside a local environment exports `TEOS_DEPLOYMENT=local` to
every test process, so a test that does not set it checks whichever target it
inherited. Where the code under test takes the target as an argument, pass it
there instead. A test about what a target resolves to is worth running for both
targets, so it pins the rule rather than one target's answer.

## The three initializers

### `testenv.EnvDefaults`

Sets the handful of variables TEOS code reads when it starts, and nothing else.
It reads no environment file, asks AWS for nothing, looks for no Docker
containers and discovers no deployment.

Its account domain is `unit.invalid`. An **account domain** is the complete DNS
name of one TEOS deployment, for example `devlocal02.thiink.systems`. The ending
`.invalid` is reserved by the internet standards as a name that never resolves.
So a test that accidentally tries to reach its own account domain fails to
connect at once, instead of reaching a machine that happens to answer for a
developer's real deployment. The matching constants are
`testenv.UnitAccountDomain`, `testenv.UnitAccountAlias` and
`testenv.UnitAccountID`.

Asking such an environment for an AWS configuration returns an error on
purpose. Handing back something that looked usable would let a test built for
no external dependency quietly reach a real account:

```go
env := testenv.Use(t, testenv.EnvDefaults)

_, err := env.AWSConfig()  // always an error, by design
```

A test that needs an AWS client here must build one against its own fake
server.

### `testenv.EnvUsingManualAWSResources`

For a test that calls AWS APIs and creates the resources it needs itself. TEOS
does not have to be deployed anywhere.

It does everything `EnvDefaults` does, then gets an AWS configuration for the
backend the build tag selected, and finally asks the AWS Security Token Service
whose credentials are in use. That last check runs before the test creates
anything, so a wrong account is reported rather than filled with rubbish.

The test owns exactly the resources it makes, and must remove them again.

### `testenv.EnvTEOSDeployed`

For a test that calls a deployed TEOS system: its APIs, its Lambda functions,
its tables or its configuration.

It does everything `EnvUsingManualAWSResources` does, then reads the deployment
itself to find out which account domain, account alias and deployment tier it
is talking to. Those three come from the deployment's own public Cognito user
pool: the account domain from the pool's custom login domain, and the alias and
tier from the tags `teos:account-alias` and `teos:deploy-env` that the
deployment writes on the pool.

They are never taken from the process environment. A developer's shell often
carries an account domain left over from a different deployment, and a test
that trusted it would check one system while reporting on another.

Read the account domain back with `env.AccountDomain()`.

The test attaches to infrastructure it does not own. It may create and remove
resources of its own. It must not remove anything it found.

### Settings you can pass

All three take an optional `testenv.Options` value. The zero value is what
almost every test uses. The fields configure values, never the kind of
dependency a test has — the initializer you called decides that.

| Field | Meaning |
| --- | --- |
| `LogLevel` | The TEOS log level for the test. Nil means errors only. |
| `DotEnvFile` | An environment file to read defaults from. Only the initializers that talk to something outside the process read it. A value already in the process environment always wins over the file. `Use` and `Run` take the file's values back with every other change setup made. An empty path reads no file. |
| `ExpectedAccountID` | The AWS account the test insists on. Setup fails when the credentials in use belong to another one. It has no meaning for a local run, which always answers for one made-up account number. |
| `DeployEnv` | The deployment tier, such as development or quality assurance. It matters for managers whose resource names contain the tier. It is not the choice between AWS and the local emulator. `EnvDefaults` and `EnvUsingManualAWSResources` publish it as `CB_DEPLOY_ENV`, or `devlocal` when it is left out. `EnvTEOSDeployed` publishes the tier the deployment records, and when this is set it refuses a deployment of any other tier. |
| `UserPoolID` | The Cognito user pool to read deployment details from. Empty means "find the one public pool of the deployment". |

Pass at most one `Options` value. Two would silently drop everything after the
first, so setup rejects that with an error naming the count.

## Two lifetimes: one test, or one package

### `testenv.Use(t, setup, opts...)` — one test

Changes are made through the standard library's own test environment helper,
`t.Setenv`. Go restores the previous values — and the previous absence of a
value — when the test finishes.

Setup failure stops the test at once with `t.Fatal`. A test that cannot get the
environment it asked for must not carry on and report something about a
different environment.

### `testenv.Run(m, setup, opts...)` — a whole package

Called from `TestMain`, the function Go runs once before the tests of a
directory. Write it exactly like this:

```go
func TestMain(m *testing.M) {
    os.Exit(testenv.Run(m, testenv.EnvDefaults))
}
```

A deferred clean-up followed by `os.Exit(m.Run())` is **not** equivalent.
`os.Exit` ends the process immediately and does not run deferred work, so the
clean-up would never happen.

The returned status is the tests' own status, unless setup or clean-up failed,
in which case it is non-zero. Work that fails to tidy up counts as a failure,
because the next run starts from whatever was left behind.

`Run` remembers each variable's previous state before changing it, and puts
that exact state back afterwards. A variable that was present with an empty
value is restored as present and empty, not removed.

## Worked example: one test, TEOS settings only

```go
package tariff_test

import (
	"os"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestTheAccountDomainIsSetForThisTest shows the shortest possible setup: one
// test, TEOS settings only, nothing outside the process.
func TestTheAccountDomainIsSetForThisTest(t *testing.T) {
	testenv.Use(t, testenv.EnvDefaults)

	// Every TEOS setting is in place for the length of this test, and Go puts
	// the previous values back when the test ends.
	assert.Equal(t, testenv.UnitAccountDomain, os.Getenv(string(cbenv.CB_ACCOUNT_DOMAIN)))
}
```

## Worked example: one setup for a whole package

```go
package inventory_test

import (
	"os"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestMain prepares the environment once for every test in this directory.
//
// Write it exactly like this. A deferred clean-up followed by os.Exit is not
// the same thing, because os.Exit ends the process without running deferred
// work.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvDefaults))
}

func TestOnePartOfTheSubject(t *testing.T) {
	// The settings are already in place. This test calls no setup of its own.
}

func TestAnotherPartOfTheSubject(t *testing.T) {
	// The same settings, still in place.
}
```

## Worked example: a fixture this package owns

A **private fixture** is a container or server that only this test binary uses.
Nothing else on the machine looks for it, and nothing else may take it away.
Start it inside an initializer of your own, which calls `testenv.EnvDefaults`
first and then starts the fixture.

```go
package ledger_test

import (
	"fmt"
	"os"
	"testing"

	"github.com/aws/aws-sdk-go-v2/service/dynamodb"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/ctxutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// The fixture this package owns: one DynamoDB Local container, started once
// and shared by every test in the directory.
var (
	database       *testutils.DynamoDbLocal
	client         *dynamodb.Client
	fixtureContext ifcore.CbContext
)

func TestMain(m *testing.M) {
	os.Exit(runTests(m))
}

// runTests is a function of its own so that the container is removed even
// though TestMain ends the process. os.Exit skips deferred work, so the
// deferred call has to sit in a function that returns first.
func runTests(m *testing.M) int {
	defer stopDatabase()

	return testenv.Run(m, startDatabase)
}

// startDatabase is this package's own initializer. It asks for TEOS settings
// and nothing else, then starts the container the tests share.
func startDatabase(opts ...testenv.Options) (env *testenv.Environment, err error) {
	env, err = testenv.EnvDefaults(opts...)
	if err != nil {
		return nil, err
	}

	// Close the environment if the work below fails, because a setup function
	// that returns an error returns no environment for anything else to close.
	defer testenv.CloseOnError(&env, &err)

	fixtureContext = ctxutils.NewNullContext("ledger-test", "fixture", cbenv.DevLocal)
	database = testutils.NewLocalDynamoDb(utils.RandomPostfix("ledger"))

	if err := database.Start(fixtureContext); err != nil {
		return env, fmt.Errorf("start the DynamoDB Local container this package owns: %w", err)
	}

	client = database.DynamoDbClient()

	return env, nil
}

func stopDatabase() {
	if database == nil {
		return
	}

	_ = database.Close()

	database = nil
	client = nil
}
```

Three details matter here. The container name ends in a random suffix
(`utils.RandomPostfix`), so two runs on one machine cannot collide. The
initializer returns the error rather than stopping the process, so `Run` can
report it and still put the environment back. And the deferred
`testenv.CloseOnError` gives the environment back when the work after
`testenv.EnvDefaults` fails: a setup function that returns an error returns no
environment, so `Run` has nothing to close and whatever the environment took
would stay taken.

`testenv.CloseOnError` needs the results of the setup function to be named
(`(env *testenv.Environment, err error)`), because a deferred call reads them
as the function returns. Every failing return below it hands the environment
back rather than `nil`; `CloseOnError` is what replaces it with `nil`, so the
caller never receives an environment that has already been closed.

## A private fixture when the code under test reads the environment

A client built from the fixture — `database.DynamoDbClient()`, or a TEOS
context from `database.SubContext(...)` — carries the container's address
inside it. It reaches that container whatever the `AWS_ENDPOINT_URL` variables
of the process say, so nothing more is needed.

Some code builds its own client instead, by loading an AWS configuration from
the environment with `config.LoadDefaultConfig`. Command line tools do this,
and so does TEOS code that asks for a context with
`ctx.OptAWSConfigLoadDefault`. For that code the environment is the only way to
name the fixture, and setting `AWS_ENDPOINT_URL` alone is not enough: the AWS
SDK prefers a service-specific `AWS_ENDPOINT_URL_DYNAMODB` when one is set, and
the shell the test was started from can carry one. The test then seeds rows in
its own container while the code under test reads somewhere else, and the
failure names a missing table rather than the settings that caused it.

One call puts every endpoint variable on the fixture:

```go
func TestTheCommandWritesItsRows(t *testing.T) {
	// Every AWS call this test makes now goes to the container above, and to
	// nothing else. t.Setenv restores the inherited values afterwards, so the
	// test must not call t.Parallel.
	database.UseAsTheOnlyAWSEndpoint(t)

	// ... run the command that loads its AWS configuration from the environment
}
```

It also checks the result the way the code under test will get it, by loading a
configuration from the environment and asking where a DynamoDB client built
from it would send a request. A setting that does not survive that check fails
the test there, with the two addresses in the message.

## Worked example: a test against a deployed TEOS

```go
//go:build e2e

package buildings_test

import (
	"net/http"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbnet"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestTheDeployedAPIAnswers calls a TEOS system somebody has already deployed.
//
// The account domain comes from the deployment itself, never from the shell
// this test was started in.
func TestTheDeployedAPIAnswers(t *testing.T) {
	env := testenv.Use(t, testenv.EnvTEOSDeployed)

	url, err := cbnet.APIURL(env.AccountDomain(), "lcs", "/v1/buildings")
	require.NoError(t, err)

	profile, err := cbnet.FromEnv()
	require.NoError(t, err)

	response, err := profile.HTTPClient(30 * time.Second).Get(url)
	require.NoError(t, err)

	defer func() { _ = response.Body.Close() }()

	// Without an access token the deployed API answers "unauthorized". That is
	// enough to show the request reached the deployment.
	require.Equal(t, http.StatusUnauthorized, response.StatusCode)
}
```

`cbnet.APIURL` builds the public address of one service on the deployment's API
host. [API_ENDPOINT.md](../../../API_ENDPOINT.md) explains the address shape and
the other helpers beside it.

## What setup does, in order

For `EnvUsingManualAWSResources` and `EnvTEOSDeployed`:

1. Read the environment file, when `Options.DotEnvFile` named one. Values
   already in the process environment win over the file.
2. Decide the backend. The build tag says which one. A `TEOS_DEPLOYMENT`
   setting that names the other backend is an error, not an override, whether
   the shell exported it or the environment file supplied it.
3. Apply the TEOS settings, the same ones `EnvDefaults` applies.
4. Publish the chosen backend in `TEOS_DEPLOYMENT`.
5. Get the backend.
   - Locally, attach to a running pair of containers and publish their
     addresses. Any per-service address variable the process inherited, such
     as `AWS_ENDPOINT_URL_SQS`, is pointed at the emulator too, and
     `AWS_IGNORE_CONFIGURED_ENDPOINT_URLS` is set to `false`. Without these, the
     shell or the AWS shared configuration file could still send a call
     elsewhere.
   - On AWS, refuse any `AWS_ENDPOINT_URL` or `AWS_ENDPOINT_URL_*` variable
     that is set. Then load this process's own credentials and region, and
     refuse any `endpoint_url` the AWS shared configuration file gives the
     selected profile, in the profile itself or in the services section it
     names. Each of those would send the requests somewhere other than AWS.
6. On AWS only, ask the Security Token Service whose credentials these are.
   Credentials belonging to the account number the local emulator answers for
   are refused, and so is any account other than `Options.ExpectedAccountID`
   when that was set.
7. For `EnvTEOSDeployed` only, read the deployment's account domain, alias and
   tier from its public Cognito user pool and publish those three. A tier
   other than `Options.DeployEnv`, when that was set, is refused.

Each step's failure stops setup and releases whatever the earlier steps took.

## `TestMain`, and the trap of two test packages in one directory

A Go directory produces **one** test binary, even when it holds both
`package foo` (tests inside the package) and `package foo_test` (tests outside
it). Both sets of tests are linked into that single binary.

Two consequences:

- `TestMain` may be declared in only one of the two packages. Declaring it in
  both is a compile failure.
- Whichever package declares it, that `TestMain` runs before the tests of
  **both** packages.

So moving a test into the external `_test` package does **not** give it a setup
of its own. If the directory has a `TestMain` that starts a container, your new
test gets that container too, whether it wanted it or not. When a test really
needs different setup, put it in a directory of its own.

The repository convention is to write tests in the external package
(`package foo_test`) whenever the test exercises exported behaviour, and to use
the internal package only for a file's own edge cases.

## Cleanup when a test fails

`Use` registers the clean-up with `t.Cleanup`, so it runs whether the test
passed, failed or called `t.Fatal`. A clean-up that fails is reported with
`t.Errorf`, which marks the test failed: an environment that was not released
changes what the next test sees.

`Run` closes the environment after `m.Run` returns and then restores the
environment variables. Both failures make the exit status non-zero.

`Environment.Close` releases everything setup took, in the reverse of the order
it was taken, and reports every failure rather than only the first. Calling it
twice is safe.

What `Close` removes depends on how the environment was obtained. A local
environment this process **attached** to is left exactly as it was found: the
containers and the Docker network belong to whoever started them. See
[local-environments.md](local-environments.md).

## A test using `Use` cannot run in parallel

`testenv.Use` changes process environment variables through `t.Setenv`. Go
forbids that from a test that also calls `t.Parallel()`, because environment
variables are process-wide and another test running at the same time would see
the change. Go reports it itself, and the run stops:

```text
panic: testing: test using t.Setenv, t.Chdir, or cryptotest.SetGlobalRandom can not use t.Parallel
```

A test that must run in parallel has to take its configuration as an argument
instead of from the environment. That usually means the test needs no
initializer at all.

## Build tags

Two kinds of build tag appear on tests, and they answer different questions.

| Tag | Question it answers |
| --- | --- |
| `floci` | Which backend does a test that asks for AWS resources get: the local emulator (`floci`) or a real AWS account (no tag)? |
| `integration`, `e2e` | What does this test need? They select which tests are compiled at all. |

Tag a test `integration` when it calls AWS APIs for one component and creates
and deletes every resource it uses, without needing a deployed TEOS. Tag it
`e2e` when it needs a TEOS system that is already deployed, or when it calls an
outside vendor's API with that vendor's credentials. Vendor tests carry `e2e`
for now even when they need no deployed TEOS.

`integration` and `e2e` do **not** choose between AWS and the emulator. Only
the `floci` tag does, and only for a test that asked for a backend. A test with
no resource initializer behaves identically either way: the tag alone creates
no Docker requirement and no AWS requirement.

The backend is never a fallback. A test compiled for AWS that finds an
`AWS_ENDPOINT_URL*` variable, or an `endpoint_url` in the AWS shared
configuration file for the profile in use, fails. The message names the
settings it found and the `floci` tag. A test compiled for one backend that is
told at run time to use the other fails too, and that message names
`TEOS_DEPLOYMENT` and the `floci` tag.

## Where to go next

- [TESTS.md](../../../TESTS.md) — the commands that run tests, and what each
  one selects.
- [local-environments.md](local-environments.md) — starting, attaching to and
  removing the containers that stand in for AWS, and what to do when
  certificates fail.
- [API_ENDPOINT.md](../../../API_ENDPOINT.md) — building a TEOS API address and
  getting a client that reaches it.
