# ADR-0001: One network profile decides where TEOS connects

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-09-17 |
| **See also** | [ADR-0002](0002-routing-and-trust-are-scoped-to-one-account-domain.md), which scopes the profile's routing and trust to one account domain |

## Summary

TEOS speaks HTTPS to its own public hostnames: the API host, the login host that
issues access tokens, and the host devices connect to. On the AWS deployment
target those names resolve to Amazon's endpoints and the calls just work. On the
local deployment target they all resolve to the developer's own machine, where
nothing listens on the standard HTTPS port, because the emulator listens on a
port it is given when it starts and signs its certificates with a root
certificate it invents at that moment.

One package, `go-core/cbnet`, holds the single rule that reconciles the two. It
builds an immutable value called a **profile** from the environment, and the
profile answers two questions for any connection: which address to open it to,
and which certificates to trust. A profile speaks to one TEOS deployment, named
by its account domain, and on the local target a connection to that name or to a
name under it is opened to the emulator's address; every other hostname is
opened as written. The URL, the hostname in the TLS handshake and the
hostname in the `Host` header are never changed, and certificate verification is
never switched off.

The profile is carried on the TEOS request context, in the existing service
registry, under the key `ifcore.ServiceRegistryNetProfile`. The shared HTTP
client builder `httputil.NewClient` applies it, so ordinary service code writes
the same URL on both targets and passes no endpoint, port or certificate
anywhere.

The previous home of this logic, a helper for deployment scripts called
`NewEndpointAwareHTTPClient` in `deployment/lib/script`, is deleted along with
its tests. Its two callers build their clients from `cbnet` instead.

## Terms used

| Term | Meaning here |
| --- | --- |
| Deployment target | Where a deployment runs: `aws` (Amazon's endpoints) or `local` (emulators in Docker). Read from the environment variable `TEOS_DEPLOYMENT`; unset means `aws`. |
| Base domain | The DNS suffix a provisioning configuration sets for a target, for example `thiink.systems` on AWS and `localhost.floci.io` locally. |
| Account domain | `<alias>.<base domain>`, identifying one deployment. A running service is handed its own in `CB_ACCOUNT_DOMAIN`. |
| Emulator | Floci, the program that answers for every AWS API on one address on a developer's machine, which keeps its DynamoDB data in DynamoDB Local behind it. |
| Emulator address | The host and port the emulator answers on, taken from the standard AWS SDK variable `AWS_ENDPOINT_URL`. |
| Certificate bundle | The file named by the standard AWS SDK variable `AWS_CA_BUNDLE`, holding certificates to trust on top of the machine's own. They count only for a TEOS hostname of the account domain the profile speaks to: that name, or a name underneath it. |
| Profile | `cbnet.Profile`: the deployment target, the account domain it speaks to, the emulator address and the certificates to trust, read once from the environment. |
| Service registry | A map of named services already carried by the TEOS request context `ifcore.CbContext`. A derived context has a registry of its own whose lookups fall through to its parent's. |

## Context

Two kinds of network call exist in TEOS, and only one of them was already
solved.

**AWS SDK calls were already correct.** The context builds its `aws.Config` with
the AWS SDK's own `config.LoadDefaultConfig`, which reads `AWS_ENDPOINT_URL` and
`AWS_CA_BUNDLE` by itself. Every SDK client therefore goes to the emulator on
the local target with no TEOS code involved.

**HTTPS calls TEOS makes itself were not.** These are calls to TEOS's own public
hostnames: the OAuth 2.0 token exchange against `https://api.auth.<account
domain>/oauth2/token`, the building service's API client against
`https://api.<account domain>/lcs/`, the cross-service helpers in
`go-services/clients`, and the health-summary and SUR clients. On the local
target each of those names resolves to `127.0.0.1`, `https` means port 443, and
nothing is listening there. Even if something were, its certificate would be
signed by an authority the machine does not trust.

The logic existed in exactly one place, a helper for deployment lifecycle
scripts: `NewEndpointAwareHTTPClient` in `deployment/lib/script`. Two callers
used it, a groundzero lifecycle script that checks the login domain answers and
the matching test. That had two problems.

1. **It was in the wrong module.** `deployment/lib` is the deployment library. A
   service cannot depend on it, so no service code could reach this behaviour.
2. **Its rule was too blunt.** With `AWS_ENDPOINT_URL` set it redirected *every*
   connection. In a deployment script that is harmless, because a script talks
   only to AWS. In a service it would be wrong: a collector calling an equipment
   vendor's API, such as Siemens Building X or NODA, would have its call sent to
   the emulator, which would answer with something that is not the vendor's
   data. That failure is silent and hard to trace.

## Decision

### 1. One package holds the rule

`go-core/cbnet` depends on the standard library, `go-core/cbenv` for the
deployment target and the environment variables it reads, and
`go-core/interfaces/ifcore` for the context accessor. It does not depend on `go-core/ctx` or on
`go-core/utils/httputil`, so any package may use it.

`cbnet.FromEnv()` builds a profile from the environment, and fails rather than
guessing in five cases:

- `TEOS_DEPLOYMENT` holds a value that is neither `aws` nor `local`;
- `CB_ACCOUNT_DOMAIN` holds a value that is not a DNS name. An empty value is
  allowed and leaves the profile speaking to no deployment, which is what a
  process that only calls AWS APIs needs;
- `AWS_CA_BUNDLE` names a file that cannot be read or that holds no
  certificate;
- the target is `local` and `AWS_ENDPOINT_URL` is empty, which would send every
  call of that run to Amazon;
- the target is `local` and `AWS_ENDPOINT_URL` names a host that is plainly
  Amazon's own: `amazonaws.com`, or anything ending in `.amazonaws.com`,
  `.amazonaws.com.cn` or `.api.aws`. The comparison is on whole labels, so
  `amazonaws.com.localhost.floci.io` is not Amazon's and is accepted.

### 2. The rule is a whole-label test against one account domain

`Profile.DialAddress(address)` answers where a connection should go. On the
local target, a host that is the account domain the profile speaks to, or a name
one or more whole labels below it, is answered with the emulator's address.
Everything else, and everything on the AWS target, is answered with the address
unchanged. A profile that was given no account domain answers every address
unchanged.

Comparison ignores case and a trailing dot. It is on whole labels, so
`evil-devlocal02.thiink.systems` does not match `devlocal02.thiink.systems`, and
neither does another deployment such as `devlocal03.thiink.systems`.

### 3. Applying the profile keeps what the caller configured

`Profile.ConfigureTransport(*http.Transport)` changes three things and nothing
else.

It names the bundle's certificates as the ones to trust, but only when the
transport does not already name a certificate pool of its own. A caller that
named one keeps exactly that pool. Widening it would let a client built to
accept one server's certificate accept another's, which is the opposite of what
naming a pool is for. The minimum TLS version and the certificate verification
setting are left as the caller set them.

The bundle's certificates count only for a TEOS hostname of the target. The
transport is given a check that runs at the end of a handshake to any other
hostname, and that check verifies the certificate the server presented against
the machine's own trusted certificates alone. A certificate that only the bundle
vouches for fails it, and the connection is refused. So a bundle that was put
there for the emulator cannot vouch for an equipment vendor's API. A check the
caller had installed of its own is kept and runs afterwards.

It wraps whatever dialler the transport already has, so that the address every
connection is opened to passes through the rule. `DialTLSContext` is
deliberately not set, so the standard library performs the handshake itself for
the hostname in the URL.

There is one thing a caller can configure that the profile cannot work with. A
transport may hold a function that opens an already encrypted connection by
itself, in the field `DialTLSContext` or the older field `DialTLS`. The standard
library gives every HTTPS connection to that function, and then uses neither the
plain dialler nor the TLS settings. Those two are where both of the profile's
decisions live, so on such a transport it can decide neither where a connection
to a TEOS hostname is opened nor which certificates count. That transport is
therefore refused: nothing on it is changed, and applying the profile returns an
error saying so. Writing two fields that nothing reads would leave the caller
believing its connections follow the rule while they do not. The client that
`Profile.HTTPClient` hands out never runs into this, because it clears both
fields on its copy of the standard library's transport before applying the
profile. `httputil.NewClient` returns the reason as an error and no client, so
no request is made by a client whose routing was not applied.

On the local target it also wraps the transport's proxy function, so that a
request to a hostname of the account domain the profile speaks to uses no
proxy. This is not a
convenience: when a proxy applies to a request, the standard library opens the
connection to the proxy and hands the dialler the proxy's own address, so the
rule would never see the TEOS hostname and the request would go wherever the
proxy sent it. No proxy knows where a developer's emulator listens. Every other
request gets whatever the transport's own proxy function answers, and a
transport with no proxy function keeps none. On the AWS target the proxy
settings are not touched.

### 4. The context carries the profile

`ctx.OptAWSConfigLoadDefault`, the option that loads the AWS configuration,
reads the profile first and registers it in the context's service registry under
`ifcore.ServiceRegistryNetProfile`. Because a derived context falls through to
its parent's registry, every per-invocation context sees the profile the service
registered at start-up.

Reading the profile before loading the AWS configuration makes the third failure
case above a safety net: a process on the local target that was never told where
its emulator is refuses to build an AWS configuration at all.

### 5. The shared HTTP client applies it

`httputil.NewClient` takes the profile from the context it is given and applies
it to the transport the options left in place. A caller that passed no TLS
option gets the pooled transport configured; a caller that passed one gets the
transport that option installed. A caller speaking to a second TEOS deployment
names it with `httputil.WithAccountDomain`, and the client is then built on a
copy of the profile pointed at that deployment.

It returns `(*HttpRequestDoerImpl, cberror.Error)` and gives back no client when
it could not be built as asked: a client option that failed, a certificate that
is not a PEM certificate, an account domain that is not a DNS name, a profile
that cannot be read, and a transport the profile cannot be applied to. A client
that ignored any of those would send its requests to whatever address the
hostname resolves to, which on the local target is a machine where nothing
listens and against an account is a different deployment from the one the caller
named.

One client keeps its own routing, and says so: a caller that passes
`httputil.WithRoundTripper` supplies the round tripper that carries every
request, which is how a test double answers without a network. The profile is
not applied to such a client, because it decides for itself where its requests
go.

### 6. URL helpers, so nobody writes a hostname

`cbnet.APIHost`, `AuthHost`, `IoTHost`, `TokenURL` and `APIURL` build the public
names and addresses from an account domain. They answer the same on both
targets, lower-case the domain and refuse an empty one. A profile answers the
same five from the account domain it speaks to, and a profile that has none
returns an error naming `CB_ACCOUNT_DOMAIN` rather than an address built on an
empty name.

## Alternatives considered

**A new method on `ifcore.CbContext`.** Rejected. That interface already has 24
methods and three implementations, one of which is a hand-written test double in
a service. The project rule is small interfaces. The service registry the
context already carries exists precisely so that optional services can be
attached without changing the interface, and it already carries three others.

**Publishing host port 443 for the emulator.** If the emulator listened on 443,
every TEOS hostname would resolve to `127.0.0.1:443` and reach it with no code
at all. Rejected for three reasons. Only one local run per machine could hold
that port, so two developers' runs, or one developer's two runs, would collide.
Binding port 443 needs elevated privileges on Unix-like systems. And it would
not solve trust: Go on macOS ignores `SSL_CERT_FILE`, so the emulator's root
certificate would still have to be put into a pool by code, which is the larger
half of this decision anyway.

**Redirecting every connection when `AWS_ENDPOINT_URL` is set.** This is what
the deleted helper did. Rejected because it would send a call to an equipment
vendor's API into the emulator. The suffix test costs one string comparison and
removes that whole class of mistake.

**Replacing the AWS SDK's HTTP client with the profile's.** Rejected. Every AWS
SDK already reads `AWS_ENDPOINT_URL` and `AWS_CA_BUNDLE` itself, so SDK calls
are already correct on both targets. The SDK's own HTTP client is tuned for its
retry and timeout behaviour, and replacing it would change that for no gain.

## Consequences

**What a person sees.** Service code writes one URL and it works in an AWS
account and against the local emulators. Nobody passes an endpoint, a port or a
certificate to a TEOS client. A local run that is missing its emulator address
stops at start-up with a message naming the variable, instead of quietly talking
to Amazon.

**On the AWS target nothing changes.** With no certificate bundle named,
applying a profile changes nothing at all: the transport keeps the machine's
certificates, its own dialler and its own proxy settings.

**Third-party calls are unaffected on both targets**, because a vendor hostname
is neither the account domain nor a name under it.

**A client that names its own certificates gets nothing added.** The client
option `httputil.WithServerCertPEM` builds a pool from the certificates the
caller passed, and that pool is left alone. On the local target such a client
does not trust the emulator's root certificate, so a call it makes to a TEOS
hostname fails certificate verification unless the caller passes that
certificate too. Clients that name no certificates, which is all of them by
default, are unaffected.

**The deployment library shrinks.** `deployment/lib/script/endpoint_client.go`
and its two test files are deleted. The groundzero lifecycle script that checks
the login domain and the groundzero test that probes the same endpoint build
their clients from `cbnet` instead, and their modules gain a direct dependency
on `go-core`, which they already had indirectly.

**A test that builds a context on the local target must supply an emulator
address**, or not load the default AWS configuration. That is the safety net
working as intended.

**The refusal of an Amazon address has two limits.** The first is that it
recognises hostname shapes, not endpoints. Amazon serves APIs on other names,
and an address behind a private link or a custom domain in a real account reads
like any other host, so a local run can still be pointed at a real account by
someone who tries. It catches the obvious mistake; it is not a guarantee. The
second is where the variable comes from. A Lambda function deployed locally is
given `AWS_ENDPOINT_URL` by the emulator that launches it, because TEOS itself
writes no address into a function's environment. The check
therefore protects such a function only as far as that emulator sets the
variable correctly. A person sees the difference at start-up: a run that is
caught refuses to start with a message naming the host, and a run that is not
caught starts normally and talks to whatever the address points at.

## Verification

- Table tests for the rule: the account domain itself, names one and several
  labels deep, mixed case, a trailing dot, names that merely end in or contain
  the same letters, a second deployment's name, the platform suffix above the
  account domain, a vendor hostname, IPv4 and IPv6 literals, with and without
  ports, and the same set on the AWS target where nothing is redirected even
  with an emulator address set.
- `FromEnv` covered for every failure: a misspelled target, a missing or
  unparsable emulator address, a certificate file that is absent or holds no
  certificate, the local target with no emulator address, and the local target
  pointed at each of the hostname endings Amazon serves its APIs on, alongside
  hostnames that merely contain that text and are accepted.
- An HTTPS test server presenting a certificate issued for a name under
  `localhost.floci.io`: a request to that name reaches the server through the
  rule and verifies against a bundle file, and the same request without the
  bundle fails certificate verification. That pair proves the redirect works and
  that verification stayed on.
- An HTTPS test server presenting a certificate for an equipment vendor's
  hostname, signed by the certificate in the bundle file, with every connection
  sent to that server: the request is refused, and the message names the
  hostname and the variable `AWS_CA_BUNDLE`. A check the caller installed on its
  own TLS settings is shown to still run on a request to a TEOS hostname that
  succeeds.
- A certificate appended to the pool `Profile.CertPool` handed out does not
  reach a transport the profile configures afterwards, which is checked by
  verifying that certificate against the transport's pool and requiring the
  failure.
- A transport carrying a caller's own TLS settings keeps its minimum version,
  keeps its own settings object, still verifies a server its own certificate
  pool vouches for, and does not gain the certificate the profile carries, which
  is checked by verifying that certificate against the resulting pool and
  requiring the failure.
- A transport whose proxy function always answers with a proxy: a request to a
  TEOS hostname of the account domain gets no proxy, a request to another
  hostname gets the proxy, and on the AWS target the field still holds the
  caller's own function.
- Three checks that nothing is installed on the AWS target: a transport with no
  dialler, no proxy function and no TLS settings still has none; a transport
  with a dialler of its own is asked for the address unchanged, for a name of
  the account domain as well; and with `AWS_CA_BUNDLE` set, the certificates
  are the only change, with HTTP/2 still attempted, the caller's protocol list
  intact, and the dialler and proxy function untouched.
- The context option registers the profile, a derived context sees the same one,
  and the local target with no emulator address refuses to load an AWS
  configuration.
- A client from `httputil.NewClient` on the local target reaches a TEOS hostname
  at the test server and leaves a vendor hostname alone. On the AWS target its
  transport is compared field by field with one the same library builds, and a
  transport a client option installed comes back with its own dialler, no proxy
  function and no TLS settings, and is asked for the address in the request.
- A client is still built, and its request still succeeds, when `AWS_CA_BUNDLE`
  names a file that is gone.
- A context variable holding a pointer that is nil is answered from the
  environment rather than stopping the process.
- A Docker-backed test against the real emulator: the profile reads that run's
  emulator address, and its client gets HTTP 200 and the emulator's own health
  document from `https://localhost.floci.io/_floci/health` with verification on.
  A second request, to a name one label deeper, is answered by the emulator with
  its own request identifier, which proves that name reached it too.
- A benchmark of the rule, because it runs on every connection a service opens.
