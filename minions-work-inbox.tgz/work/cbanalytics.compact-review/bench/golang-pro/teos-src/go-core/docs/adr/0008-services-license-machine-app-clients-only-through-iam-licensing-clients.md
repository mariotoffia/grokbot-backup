# ADR-0008: Services license machine app clients only through the IAM function iam-licensing-clients

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-16 |

## Summary

TEOS gives a program, such as a tklocal device at a customer site, a machine
app client: a Cognito app client in the public user pool, an API Gateway key,
and a license. The license is unsigned JSON that holds the client's ID and
secret, the API key, the client's claims and the TLS certificate of the API
domain. The IAM service decides which scopes
and claims such a client gets, from a named pack in its catalog. IAM also
keeps a record of the pack each client was made from, and uses it to protect
packs that are in use. This record decides how services other than IAM
create, renew and delete machine app clients, and who may ask for that.

The decision in one paragraph:

> Services create, renew and delete machine app clients only by invoking the
> IAM Lambda function `iam-licensing-clients`. IAM is the only writer of a
> client's pack copy. The function accepts only a typed direct invocation,
> refuses every other payload, an API Gateway event included, and reads no
> caller claims, so it never trusts them. AWS IAM decides who may invoke it.
> Permission to invoke it is account-wide authority to license machine
> clients: whoever has it can create a client from any pack, with extra
> scopes and claims of their choice, in the public user pool, and can renew
> or delete any machine client. So, among the roles TEOS stacks create, only
> the tklocal admin API's role gets it, because that API checks which site
> its caller may manage and forwards no scopes or claims its caller chose.
> Operators get it through their own AWS permissions. The REST licensing
> function `iam-licensing-api` stays closed to every service role.

## Terms used

| Term | Meaning here |
| --- | --- |
| Machine app client | A Cognito app client in the user pool `teos-public` with an API Gateway key and a license, used by a program rather than a person. The license is unsigned JSON with the client's credentials, its claims and the TLS certificate of the API domain. |
| Pack | A named, versioned set of scopes and claims in the IAM catalog. A machine app client is made from one pack. |
| Pack copy | The row `PK = CLIENT#<clientId>`, `SK = PACK` in the IAM table `teos-auth-grants`. It records the pack a client was made from, its version, its scopes and claims, and when the client's license expires. |
| In-use check | IAM refuses to delete a pack, unless the delete is forced, while the pack copy of a client with an unexpired license names it. It refuses to renew a license whose pack is gone. |
| `iam-licensing-clients` | The IAM Lambda function that creates, renews and deletes machine app clients for a direct invocation. Its handler is `go-services/core/management/iam/handlers/licensingclients`. |
| `iam-licensing-api` | The IAM Lambda function behind the licensing REST API (`/v1/app-clients`, `/v1/packs`). API Gateway checks the caller's token and passes the caller's claims to it in the event. |
| Typed direct invocation | A call of the AWS Lambda `Invoke` API whose JSON payload is a go-core `licensing.AppClientRequest`. A payload with a field that type does not have is refused before anything is done. |
| tklocal admin API | The admin Lambda of the tklocal service. It creates, renews and deletes the instance of one customer site, named by its remote system ID (`rsid`). |
| `cbiam` | The operator command that creates app clients, renews their licenses and deletes them. It runs with the operator's own AWS profile. |

## Context

IAM counts a pack as in use only while some client's pack copy names it.
Before this decision, only the licensing REST API wrote pack copies. The
tklocal admin API and `cbiam create` made Cognito app clients and API keys
themselves, through the shared go-core code `licensing.Manager`. Those
clients had no pack copy. So:

- IAM did not count them, and a pack they were made from could be deleted
  without `force`. The clients kept working with scopes from a pack that no
  longer existed.
- Their licenses were renewed even after their pack was gone, because the
  renewal check reads the pack copy.
- Every caller that made clients itself needed write permissions on Cognito
  app clients and API Gateway keys.

The licensing REST function `iam-licensing-api` trusts the caller claims in
any API Gateway event it receives, because API Gateway normally checks the
token first. A role allowed to invoke that function directly can send a
made-up event and act as any caller, a super-admin included. So no service
role may invoke it.

## Decision

### 1. One function licenses machine app clients for services

`iam-licensing-clients` answers three actions: `CreateAppClient`,
`RenewLicense` and `DeleteAppClient`. It runs the same IAM application
services as the licensing REST API, so both apply the same pack rules: the
in-use check, the refused renewal of a client whose pack is gone, the refused
renewal across a major pack version, and the same rules when a create reuses
an existing client of the same name. It reads the pack catalog for every
request and keeps no copy between requests, so a deleted pack is refused at
once.

The two functions differ for a delete of an ID that no client has.
`iam-licensing-clients` still deletes the API keys tagged with that ID, and
the grant, metadata and pack copy of that ID, and then answers 404. A create
makes the client first and its API key and pack copy after it, so a delete
that runs between those steps leaves both behind, and the caller that got
the create's answer removes them with a delete by the client's ID. The
licensing REST API answers 404 for such an ID and deletes nothing, because
it checks its caller against the client's `rsid` and `oid` first, and a
client that does not exist has neither.

### 2. IAM is the only writer of the pack copy

Only IAM's licensing code writes, updates and deletes pack copies. No other
service writes rows of `teos-auth-grants` itself. Other stacks register their
scopes, claims and packs through IAM's catalog registrar function, which is
IAM code too. The go-core `licensing.Manager` sends requests to
`iam-licensing-clients` and keeps its reads (finding a client by name, reading
API keys and the domain certificate).

### 3. The function never trusts caller claims

The function decodes the payload strictly as a `licensing.AppClientRequest`.
It refuses an API Gateway event, runs no access policy and reads no caller
claims. The request has no field that names a user pool: every action works
in `teos-public`, the only user pool the function's role may change.
Nothing but AWS IAM decides who may call it. No resource policy lets API
Gateway or another AWS service invoke it, and no REST API route sends
requests to it.

### 4. Permission to invoke it is account-wide licensing authority

Whoever may invoke the function can:

- create a machine app client from any pack in the catalog;
- add scopes and claims of their choice to it, except the claims `rsid` and
  `oid` and claim scopes, which IAM refuses;
- renew or delete any machine app client in the public user pool.

So a role gets `lambda:InvokeFunction` on it only when the code behind that
role limits what its own callers may license. Among the roles TEOS stacks
create, only the tklocal admin API's role has it. That API checks with its
access policy that its caller may manage the site the request names, and
sends IAM only the site's `rsid`, the client name `tklocal-<rsid>`, the pack,
the remote type and the evidence. It sends no scopes or claims its caller
chose. Operators invoke the function through `cbiam` with their own AWS
permissions.

### 5. The REST licensing function stays closed to services

No role that a TEOS stack creates may invoke `iam-licensing-api` directly.
Only operators do, with their own AWS permissions, for example
`cbiam create -list-packs`.

## Alternatives considered

**tklocal calls the licensing REST API with machine credentials.** Rejected.
The routes that create and delete app clients allow only members of the
Cognito group `teos-super-admin`, and a client-credentials token belongs to
no group. The access policy of the most powerful licensing routes would need
a rule for machine callers. tklocal would also hold the secret of a client
with those rights, and that secret works from anywhere on the internet, not
only from one AWS role.

**go-core writes the pack copy into IAM's table, a second writer.** Rejected.
The tklocal admin API and `cbiam` would keep making clients themselves, and
also write `CLIENT#<clientId>` / `PACK`. Their roles would need write access
to IAM's table. The pack rules would exist twice, in IAM and in go-core, and
could differ. Two services with their own release cycles would write one
stored format, so IAM could no longer change that format on its own, which
ADR-0004 requires of the service that owns the rows.

**Keep the read-only packs function.** Rejected. An IAM function that only
returned the packs let the tklocal admin API and `cbiam` read a pack and
make the client themselves. IAM still never saw the client, so it wrote no
pack copy, and the in-use check stayed blind to those clients.

## Consequences

**What a person sees.**

- Every machine app client created through the tklocal admin API or
  `cbiam create` counts as using its pack. Deleting that pack without `force`
  is refused while the client's license has not expired.
- Renewing the license of such a client is refused with 409 once its pack is
  gone, and with 400 across a major pack version until a super-admin upgrades
  the client through the licensing REST API.
- Creating a client under a name an existing client has is refused with 409
  when the request names another pack than the existing client was made from.
- When `iam-licensing-clients` fails or is not deployed, the tklocal admin API
  cannot create, renew or delete an instance and answers 500.

**What this allows.**

- Adding or changing a pack rule in IAM once, for every caller.
- Changing the pack copy's stored format inside IAM, under ADR-0004.

**What this forbids.**

- Any service other than IAM creating, changing or deleting a machine app
  client or its API key in Cognito or API Gateway.
- Any service other than IAM writing a pack copy, or any other row of
  `teos-auth-grants`, other than through an IAM function.
- Giving `lambda:InvokeFunction` on `iam-licensing-clients` to a role whose
  code does not limit which sites its callers may license, or that forwards
  scopes or claims its callers chose.
- Giving any service role `lambda:InvokeFunction` on `iam-licensing-api`.
- Adding a resource policy, or an API Gateway integration, that lets an AWS
  service invoke `iam-licensing-clients`.

## Verification

- `go-services/core/management/iam/handlers/licensingclients/action_test.go`:
  `TestAPayloadThatIsNoAppClientRequestIsRefused` checks that an API Gateway
  event, an unknown field and a payload that is not one JSON request are
  refused before anything is created.
  `TestCreateAppClientAnswersTheLicenseAndKeepsThePackCopy` and
  `TestRenewLicenseOfAClientWhosePackIsGoneIsRefused` check that the function
  writes the pack copy and refuses the renewal of a client whose pack is gone.
- `go-services/core/management/iam/handlers/licensingclients/create_existing_test.go`
  checks the pack rules of a create that reuses an existing client.
- `go-services/core/management/iam/handlers/licensingclients/pack_catalog_test.go`:
  `TestTheFunctionReadsThePackCatalogOnEveryRequest` checks that the function
  keeps no copy of the packs.
- `go-services/core/management/iam/handlers/licensingclients/manager_e2e_test.go`:
  `TestTheLicensingManagerWorksThroughTheFunction` checks that the go-core
  `licensing.Manager` creates, renews and deletes clients through the
  function.
- `go-services/core/management/iam/handlers/licensingclients/delete_during_create_test.go`
  checks that a delete by the ID of a client deleted while it was created
  deletes the API key and the rows left with that ID, and answers 404.
  `go-services/core/management/iam/handlers/licensingapi/handlers_test.go`:
  `TestRoute_DeleteAppClient_UnknownID_Returns404` checks that the REST
  delete of such an ID answers 404 and deletes nothing.
- `go-services/core/management/iam/deployment/stack_licensing_clients_test.go`:
  `TestLicensingClientsLambdaHasNoResourcePolicy` checks that no resource
  policy and no REST API route reaches the function.
  `TestLicensingClientsLambdaMayWriteOnlyAppClientRows` checks that its role
  may write only rows whose partition key starts with `CLIENT#`.
- `go-services/providers/eastbound/tklocal/deployment/stack_admin_api_test.go`:
  `TestAdminAPILambdaMayInvokeOnlyTheIAMClientsLambda` checks that the tklocal
  admin API's role may invoke `iam-licensing-clients` and not
  `iam-licensing-api`.
