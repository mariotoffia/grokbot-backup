# ADR-0002: Routing and trust are scoped to one selected account domain

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-09-18 |

## Summary

A TEOS deployment is addressed by an **account domain**, its complete DNS name,
for example `devlocal02.thiink.systems`. Every public hostname TEOS owns is a
prefix on that name, and every certificate, hosted zone and API Gateway custom
domain is created for it.

That name is chosen once, from the provisioning configuration of the deployment
being built, and checked before anything is built from it. The resolver
`product.ResolveDNS` reads one block of that configuration, keyed by the
deployment target, and returns the base domain, the account domain and the role
that delegates the account's DNS zone. It has no fallback: not to the other
target's block, not to a file elsewhere in the repository, and not to a value
written into the binary.

Three rules follow from that choice, and they are the subject of this record.

1. **A deployment's names are resolved once, where the configuration is loaded.**
   Nothing below a loader reads `TEOS_DEPLOYMENT` to work out a domain.
2. **Routing is scoped to one selected account domain.** A connection to that
   name, or to a name under it, is sent to the local emulator on the local
   target. Every other hostname is connected to as written, on both targets.
3. **Trust is scoped the same way.** The emulator's root certificate counts only
   for that account domain and names under it. It cannot vouch for an equipment
   vendor's API, and it cannot vouch for a second deployment a client was not
   pointed at.

The on-premise agent is deliberately outside all of this. It keeps its own list
of trusted platform suffixes in Go source, because that list is a security
control rather than a deployment setting.

## Terms used

| Term | Meaning here |
| --- | --- |
| Deployment target | Where a deployment runs: `aws` (Amazon's endpoints) or `local` (emulators in Docker). Read from the environment variable `TEOS_DEPLOYMENT`; unset means `aws`. |
| Base domain | The DNS suffix a provisioning configuration sets for a deployment target, for example `thiink.systems` on AWS and `localhost.floci.io` locally. |
| Account domain | One deployment's complete name below the base domain, such as `devlocal02.thiink.systems`. A running service is handed its own in `CB_ACCOUNT_DOMAIN`. |
| Provisioning configuration | The YAML file that describes a deployment. The DNS block is `common.dns`, with one entry per deployment target. |
| Product definition | The parsed configuration, handed to every CDK stack, every Lambda environment block and every lifecycle script. |
| Resolver | `product.ResolveDNS` in `deployment/lib/core/domain/product/dns.go`. |
| Network profile | `cbnet.Profile`: the deployment target, the account domain it speaks to, the emulator's address and the certificates to trust, read once from the environment. See [ADR-0001](0001-one-network-profile-decides-where-teos-connects.md). |
| On-premise agent | `go-services/tklocal`, the program that runs on a customer's own hardware and is installed with a signed licence. |

## Context

A deployment's domain name is not decoration. It decides which Route 53 hosted
zone is created, which names the API Gateway custom domains answer for, which
name a certificate is issued for, what a Lambda is told in `CB_ACCOUNT_DOMAIN`,
which origins the web dashboard's Content-Security-Policy header allows, and
which platform an on-premise agent is willing to talk to.

Two forces shape the decision.

**The name is needed in many places.** The foundational stack needs it for the
hosted zone and its delegation. The deployment tool needs it to work out which
account it is addressing. The Content-Security-Policy builder needs it for the
origins the web dashboard may load from. A service needs it to address another
service. Every one of those could work the name out for itself, and then every
one of them could disagree with the others.

The local deployment target makes the cost of disagreement concrete. Every name
it uses ends in `localhost.floci.io`, and one place that decides otherwise
produces a stack that tries to create a certificate, or delegate a zone, under
the company domain.

**A default would be worse than an error.** Falling back to the company domain
when a configuration names none looks harmless and is not. The deployment
succeeds, the hostnames are created in the wrong place, and the mistake becomes
visible only later as a name that resolves to nothing, or as a certificate
issued for a domain nobody meant to use.

At run time the shape of the problem is different. A Lambda function has no
provisioning configuration to read. It is told its own account domain when it is
deployed, and what it still has to decide, on every outgoing connection, is
whether a hostname belongs to this deployment target at all.

## Decision

### 1. One resolver, called where the configuration is loaded

`product.ResolveDNS(definition, target)` returns the base domain, the account
domain and the delegation role for one deployment target. `ApplyResolvedDNS`
calls it and stores the answer on the product definition;
`product.ApplyDefaults` calls `ApplyResolvedDNS` last.

Every loader calls `ApplyDefaults` at the point where the configuration is read
and the target is known:

- `deployment/lib/script/loader.go`, used by lifecycle scripts;
- `deployment/lib/infrastructure/config/context.go`, used by the CDK stacks;
- `go-services/appstore/cmd/cbdeploy/internal/config/info.go`, used by the
  deployment tool.

Below that point, code reads `Definition.GetBaseDomain()`,
`Definition.GetAccountDomain()` and `Definition.GetDelegationRole()`. No stack,
script or tool works the answer out again, and none of them reads
`TEOS_DEPLOYMENT` to decide a domain.

### 2. A configuration that names no domain is an error

The configured block for the selected target must name a base domain. The
account domain is the configured `accountDomain` when there is one, and
otherwise the account alias joined to the base domain.

Three further conditions are checked before anything is built:

- the base domain is a plain DNS name;
- the account domain is a plain DNS name;
- the account domain sits below the base domain, one or more whole labels
  deeper.

A name that fails is never repaired. Deleting the characters that do not belong
until what is left looks like a domain turns a typo into a different,
valid-looking deployment address.

### 3. One rule for what a name is and where it sits

`go-core/cbnet` owns both checks, so the deployment tool that writes a hostname
into a template and the runtime code that connects to it agree.

`cbnet.ValidateDomain` decides what a DNS name may look like and returns it in
lower case. `cbnet.IsBelowDomain` decides containment on whole labels:
`devlocal02.thiink.systems` is below `thiink.systems`, and `evilthiink.systems` is
not, even though it ends with the same letters.

Whole-label comparison is the security-relevant half. A plain string suffix test
would accept `evilthiink.systems` as part of the deployment and, at run time,
would send its traffic to the emulator and let the emulator's certificate vouch
for it.

### 4. Routing and trust use one selected account domain

The runtime rule in `cbnet.Profile` asks one question of every connection: is
this hostname the account domain this client speaks to, or a name under it?

A profile carries exactly one account domain. A deployed service is handed its
own in `CB_ACCOUNT_DOMAIN`, and that value is checked with `ValidateDomain`
before anything is built from it. A process that only calls AWS APIs may have
none at all; such a profile recognises no hostname, and asking it to build a
TEOS address is an error rather than a half-formed URL.

A TEOS service legitimately calls another deployment's API, and a cross-account
route is exactly that. Such a caller asks for a copy of the profile pointed at
the deployment it is calling, with `Profile.ForAccount`, and uses that copy for
both the call that fetches an access token and the calls that follow. The copy
is separate, so two deployments are reached side by side and the profile the
process runs on is never changed to reach one of them.

The rule is equally deliberately **not** "everything". A collector calling an
equipment vendor's API, such as Siemens Building X or NODA, is neither the
account domain nor a name under it, so it is connected to as written and
verified against the machine's own certificates alone.
[ADR-0001](0001-one-network-profile-decides-where-teos-connects.md) records that
rule and how it is applied to an HTTP transport.

### 5. The on-premise agent keeps its own list

`go-services/tklocal/security/platform.go` holds the DNS suffixes the agent will
talk to, as Go constants. The agent validates a signed licence offline, before
it has contacted anything, and the licence carries the account domain it was
issued for.

That list is not read from the licence, not read from `CB_ACCOUNT_DOMAIN`, not
fetched by a discovery call and not derived from a provisioning configuration
file. Any of those would let the thing being checked decide what the check
compares against. `TEOS_DEPLOYMENT` picks which entry of the list applies; it
cannot introduce a new one, and a value naming no entry makes every licence
check fail.

Trusting one more platform means editing that file, which is a change a reviewer
sees.

## Alternatives considered

**Keep a default base domain in the resolver.** Rejected. A deployment whose
configuration does not say which domain it runs on is a mistake, and the default
would silently make it the company domain. An error names the missing setting at
load time, before a certificate or a hosted zone exists.

**Let each stack read `TEOS_DEPLOYMENT` and pick its own block.** Rejected. It
means the same decision taken in several places, each able to disagree with the
others. Resolving once and passing the answer down leaves one place that can be
wrong rather than one per caller.

**Scope the runtime rule to the platform suffix every deployment shares.**
Rejected. Every deployment of a target sits under the same suffix, so one
client would send a request meant for one deployment to whichever deployment
answered, and the emulator's certificate would vouch for all of them at once. A
caller that has to reach a second deployment says so, and gets a profile for
that deployment.

**Let a caller change the account domain of the process's own profile.**
Rejected. One profile is read by every goroutine in the process and configures
transports that outlive the call that changed it, so the change would move
traffic belonging to unrelated work. `ForAccount` hands out a copy instead.

**Derive the on-premise agent's trusted platforms from the same configuration.**
Rejected. The agent runs on hardware the company does not control and validates
a licence it was given. Deriving the trusted list from a file that arrives with
the installation, or from the licence itself, means the input decides its own
acceptance.

**Read the account domain from the environment in tests against a deployment.**
Rejected for the same reason in a smaller way. A developer's shell often carries
an account domain left over from a different deployment. Tests that call a
deployed TEOS read the account domain from the deployment's own public Cognito
user pool instead, so they cannot check one system while reporting on another.

## Consequences

**What a person sees.** A deployment to a different domain is a change to one
block of one configuration file. A configuration that forgets it fails at load
time with a message naming `common.dns.<target>.baseDomain`, instead of
deploying into the wrong place.

**A local deployment creates nothing under the company domain.** The `local`
block names `localhost.floci.io` and no delegation role, so the foundational
stack creates a hosted zone under that name and no cross-account delegation
resource.

**Service code names no domain of its own.** It reads `CB_ACCOUNT_DOMAIN`,
builds a URL with the helpers in `cbnet`, and takes a client that already knows
where to connect. Nothing in a service mentions a base domain.

**A running service needs no compiled-in domain.** The runtime rule needs the
name of the deployment the client speaks to, and a Lambda has no configuration
file to read. It takes that name from `CB_ACCOUNT_DOMAIN`, which the deployment
writes into the function's environment, or from the account domain a caller
names for a second deployment. No domain is written into the binary at build
time, so changing where a deployment answers is a configuration change.

**A configuration file can inherit the block.** Service-test configurations that
say `inherit: deployment/provision-config.yaml::common.dns` receive both targets
and select the right one with no edit of their own.

**Changing what the agent trusts is a code review.** It is not a configuration
change, not a licence field and not a runtime setting. That is the point.

## Verification

- `ResolveDNS` returns the `aws` block's names for the AWS target and the
  `local` block's names for the local target.
- A configuration with no base domain for the selected target, a name that is
  not a plain DNS name, and an account domain that does not sit below the base
  domain are each an error rather than a repaired value.
- `ApplyDefaults` stores the resolved names on the definition, builds the
  account domain from the alias when the configuration names none, and fails
  when the selected target has no base domain. The three accessors of an
  unresolved definition return empty strings.
- A per-account override merges field by field, so a configuration that names
  only its own account domain keeps the shared base domain and delegation role,
  and an override of one target leaves the other alone.
- The foundational stack's parent hosted zone name follows the configured base
  domain, including when that domain is neither of the two the repository ships
  with. On the local target the delegation role is empty and the parent zone
  name is the local base domain. A definition nobody resolved has no parent zone
  name at all.
- The Content-Security-Policy builder names the exact API and sign-in origins
  of the account domain it was given, lower-cases it, refuses one that is not a
  domain name, and keeps its other directives untouched.
- `ValidateDomain` table tests: the length limits for a name and for one label,
  a leading dot, a trailing dot, two dots in a row, a label starting or ending
  with a hyphen, a last label of digits only, a URL scheme, a path, a port, a
  wildcard, and IPv4 and IPv6 literals.
- `IsBelowDomain` table tests: one label deeper, several labels deeper, the same
  name on both sides, a name that merely ends in the same letters, and an
  invalid name on either side.
- Licence tests in both directions: an account domain ending with the current
  target's trusted suffix is accepted, and one from the other target's suffix is
  rejected. Matching has to end on a label boundary. A deployment target the
  agent has no entry for refuses every licence, and so does an unset one.
- Profile tests with two account domains and one equipment vendor: a client
  reaches the emulator for its own deployment's names, leaves the second
  deployment's names and the vendor's name as written, and a client pointed at
  the second deployment does the same the other way round.
- A profile that cannot be read produces no HTTP client and therefore no
  outgoing request.
