# ADR-0009: IoT things are the tklocal instance inventory

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-16 |

## Summary

A tklocal instance is one on-premise tklocal device at a customer site. The
tklocal admin API creates, lists, reads, renews and deletes instances. Each
instance has records in several places: an AWS IoT thing, a Cognito app
client, an API Gateway key, and IAM's own records of the app client. This
record decides which of those places the admin API reads to answer "which
instances exist", and what that means for creating and deleting an instance.

The decision in one paragraph:

> The tklocal admin API lists instances from the IoT things it creates, not
> from licensing records. Each instance has the IoT thing `tklocal-<rsid>`
> with the attributes `rsid`, `provider=tklocal`, `type`, `displayName`,
> `pack` and `remoteType`, and, once they apply, `clientId`,
> `licenseExpiresAt` and `revokedAt`. The list asks AWS IoT fleet indexing
> for every thing with the attribute `provider=tklocal`, and makes one
> entry per thing from its attributes, its status included. It reads no API
> keys, no Cognito app clients and no IAM records. So the admin API stores
> everything the list shows as thing attributes. Revoking an instance
> marks the thing with `revokedAt` before it deletes the app client, and
> keeps the thing. Deleting an instance takes the same steps as a revoke,
> and then deletes the thing, so an instance never leaves the list while
> its credentials still work. Creating an instance writes the ID of the app
> client IAM gave it as the thing's `clientId`, then reads the thing again,
> and deletes that client, by that ID, when the thing is marked or no
> longer exists. Revoking and deleting delete the app client by the
> thing's `clientId`, and then by name. So when a create and a revoke or a
> delete of the same instance run at the same time, the instance has no
> working app client once the revoke or the delete has succeeded, and a
> revoke or a delete sent again reaches an API key that the create could
> not delete. No lock is needed for this.

## Terms used

| Term | Meaning here |
| --- | --- |
| tklocal instance | One tklocal device at a customer site, named by its remote system ID (`rsid`), for example `site01`. It has an IoT thing, a Cognito app client and an API Gateway key, all named after the `rsid`, and a license. |
| tklocal admin API | The admin Lambda of the tklocal service, behind `https://api.<accountDomain>/tklocal`. Its handlers are in `go-services/providers/eastbound/tklocal/handlers/admin-api`. |
| IoT thing | An entry in the AWS IoT registry. It has a name, a thing type and attributes, which are name and value strings. The admin API creates and deletes things through the device service's Lambda function `devicesvc-device-api`. |
| Thing attribute | One name and value pair on an IoT thing. AWS IoT accepts only the letters a to z and A to Z, digits and the characters `_ . , @ / : # = [ ] -` in a value. A space is refused. |
| Fleet indexing | The AWS IoT search over the thing registry (the `SearchIndex` API). It also records whether each thing's device is connected. The device service enables it for the whole account after its first deploy. |
| Licensing records | The records that let a device authenticate: the Cognito app client in the user pool `teos-public`, its API Gateway key, and IAM's metadata and pack copy for the client in the IAM table `teos-auth-grants`. |
| `iam-licensing-clients` | The IAM Lambda function that creates, renews and deletes machine app clients. ADR-0008 makes it the only way a service changes licensing records. |

## Context

The instance list (`GET /api/v1/tklocal/instances`) needs, for every
instance, its `rsid`, display name, pack, remote type and whether its device
is connected.

The list used to read API Gateway keys tagged `provider=tklocal`, and a
`pack` tag. Nothing sets either tag: an API key gets only the tags `cid` (the
app client's ID) and `rsid`. So on a real account the list was always empty.

Since ADR-0008, IAM is the only writer of app clients and their API keys. The
admin API cannot add tags to a key itself, and IAM has no reason to know
tklocal's fields, such as the remote type or the display name.

The admin API already creates an IoT thing for every instance, before it asks
IAM for the app client. The thing has a name built from the `rsid`, and
attributes the admin API chooses. Fleet indexing can find all those things in
one search, and also knows whether each device is connected.

## Decision

### 1. The list reads only IoT things

The list asks fleet indexing for `attributes.provider:tklocal`, 100 things at
a time, and follows the search's next token until no pages are left. Each
thing gives one entry:

- `rsid`, `displayName`, `pack` and `remoteType` come from the thing's
  attributes of the same names. A missing attribute reads as empty.
- `thingName` and `thingType` come from the thing's name and type.
- `connected` and `lastSeenAt` come from fleet indexing's connectivity
  status.
- `expiresAt` comes from the attribute `licenseExpiresAt`.
- `status` comes from the attributes `revokedAt` and `licenseExpiresAt`,
  as section 4 says.

A thing without the attribute `rsid` is not listed. The list does not read
Cognito, API Gateway or IAM, so an entry has no app client ID, API key ID or
creation time. When the search fails, the list answers 500.

### 2. Create stores what the list shows as thing attributes

Creating an instance creates the thing `tklocal-<rsid>` with the thing type
`location` and the attributes `rsid`, `provider=tklocal`, `type=building`,
`pack` and `remoteType`, and `displayName` when the request gives one. It
creates the thing before it asks IAM for the app client. When the IAM call
fails, it deletes the thing it created in that request.

The create request refuses a `pack`, `remoteType` or `displayName` with a
character a thing attribute cannot hold with 400, before anything is
created.

As soon as IAM answers, the create writes the app client's ID as the
thing's attribute `clientId` (section 8).

### 3. Delete revokes the instance, then deletes the thing

Deleting an instance (`DELETE /api/v1/tklocal/instances/{rsid}`) first
reads the thing. It then takes the two steps of a revoke (section 6), with
the same code: it writes `revokedAt` on the thing, keeping the value of an
earlier revoke, and asks IAM to delete the app client of the thing's
`clientId`, when the thing has one, and every app client named
`tklocal-<rsid>`, with their API keys (section 8). Then it deletes the
thing.

- When the thing cannot be read, the delete answers 500 and changes
  nothing.
- When the write of `revokedAt` fails, the delete answers 500 and does not
  ask IAM. The instance keeps its app client and stays `active`.
- When the IAM delete fails, the delete answers IAM's 4xx status or 500.
  The thing is kept and marked, so the instance is listed as `revoked`.
- When the thing delete fails, the delete answers 500, whatever status the
  failure has. The app client is gone and the thing is marked, so the
  instance is listed as `revoked`.
- A 404 from the thing delete is a failure as well. AWS Lambda answers 404
  when the device service's function does not exist, and the thing is then
  still there.
- After any of these failures, a delete or a revoke sent again repeats the
  steps. IAM treats an ID or a name with no app client as already deleted,
  and the thing keeps its first `revokedAt`.

When the instance has no thing, the delete asks IAM to delete every app
client named `tklocal-<rsid>`, and answers 204. It marks and deletes no
thing. A thing that a create makes after the delete read none belongs to
that create, and is kept. Deleting it after the create read it again would
leave the create's app client working on an instance that is not listed
(section 7).

### 4. One function decides the status from the thing's attributes

The list and the read of one instance
(`GET /api/v1/tklocal/instances/{rsid}`) decide the status with one
function. The first rule that holds decides:

1. `revoked` when the thing has the attribute `revokedAt`.
2. `expired` when the thing has the attribute `licenseExpiresAt`, and that
   time is not after now.
3. `disabled` when the instance's API key is disabled. Only the read of one
   instance reads the API key, so the list never answers `disabled`.
4. `active` otherwise.

Both attributes hold a time in RFC 3339 format in UTC, such as
`2026-10-17T06:30:32Z`, whose characters a thing attribute may hold. A thing
without `revokedAt` is not revoked. A thing without `licenseExpiresAt`, or
with a value that is not such a time, is not expired: the list and the read
log a warning that names the thing, and do not refuse it. These are the
defaults of the two attributes under ADR-0004.

### 5. The admin API stores the license expiry when IAM issues a license

The license expires when the certificate of the account's API domain inside
it expires. Creating an instance, renewing its license and downloading a
license each get a license from IAM, and then write that certificate's
expiry as the thing's attribute `licenseExpiresAt`. A renewal or download
writes it only when the thing does not already hold that value. When the
write fails, the handler logs it at error level and still answers the
license, because the caller has it and the next renewal writes the
attribute again.

Creating an instance whose thing exists, is not revoked and has no app
client reuses the thing. Before it asks IAM, it writes the request's
attributes on the thing and removes its `licenseExpiresAt`, which belongs
to an earlier license. A failed write of the new expiry then leaves the
instance not expired rather than expired by the earlier license.

### 6. Revoking marks the thing, then deletes the app client

Revoking an instance (`POST /api/v1/tklocal/instances/{rsid}/revoke`) first
writes `revokedAt` on the thing. It then asks IAM to delete the app client
of the thing's `clientId`, when the thing has one, and every app client
named `tklocal-<rsid>`, with their API keys (section 8). The thing is kept,
so the instance stays in the list as `revoked`.

- An instance without a thing answers 404, and nothing is revoked.
- A thing that already has `revokedAt` keeps it, so the attribute holds the
  time of the first revoke.
- When the write of `revokedAt` fails, the revoke answers 500 and does not
  ask IAM. The instance keeps its app client and stays `active`.
- When the IAM revoke fails, the revoke answers IAM's 4xx status, or 500.
  The thing stays marked, so the instance is listed as `revoked` and gets
  no new license, but its app client works until the revoke is sent again.
- Sending the revoke again repeats both steps. IAM treats an ID or a name
  with no app client as already revoked.

A revoked instance has no app client once its revoke answered 204. So
renewing or downloading its license, and creating it again, answer 409
without asking IAM. Deleting it takes the same steps as for any instance:
the mark keeps the first `revokedAt`, and the thing is deleted.

### 7. A create and a revoke or delete of one site order their steps instead of locking

Each request to the admin API runs in its own Lambda invocation, and two
invocations share nothing in memory. A lock inside the handler cannot stop
a create and a revoke of the same `rsid` from running at the same time,
with their steps in any order. A lock outside it, such as a conditional
write to a table, would be one more store to keep in step with the thing
and IAM. The two handlers order their steps instead:

- The revoke writes `revokedAt` before it asks IAM to delete the app
  client (section 6).
- The create reads the thing again after IAM created or reused the app
  client and the create wrote the client's ID as `clientId`, and before it
  answers. When the thing has `revokedAt` now, the
  create asks IAM to delete the app client it got, by the client ID in
  IAM's answer, writes no `licenseExpiresAt`, and answers 409 with the
  detail `instance <rsid> is revoked; delete it and create it again`.

The revoke's write comes either before or after the create's second read:

- Before: the create sees the mark and deletes its own app client.
- After: the revoke asks IAM after its write, so after IAM gave the create
  its app client, and the revoke deletes that client. The create answers
  201 with credentials that stop working when the revoke deletes them.

In both cases a revoked instance keeps no app client, and no lock is
needed. The rule relies on AWS IoT answering a read of a thing
(`DescribeThing`) with every attribute write (`UpdateThing`) that finished
before the read.

The create deletes its app client by ID, not by the name `tklocal-<rsid>`,
because of how IAM creates a client. IAM makes the Cognito app client
first, and the client's API key after it, tagged with the client's ID. A
revoke whose request reaches IAM between those two steps deletes the
client by its name and finds no key yet. IAM then makes the key, and the
create's IAM call succeeds. A delete by name would now find no client and
do nothing, so the enabled key would stay. A delete by the ID reaches it:
when no client has the ID, IAM still deletes the API keys tagged with that
ID, and the client's grant, metadata and pack copy, and answers 404, which
the admin API reads as "already deleted".

- When the create's second read fails, the create cannot tell whether the
  thing is revoked. It keeps the app client, logs the failure at error
  level with the `rsid`, the thing name and the client ID, and answers
  500. It does not delete the client, because another create of the same
  instance may already have answered 201 with that client's credentials
  (section 8). The thing holds the client's ID, so a revoke or a delete of
  the instance deletes the client by that ID, and then by name. Until
  then, the same create sent again answers 409 with the detail
  `instance already exists for rsid: <rsid>`.
- When the thing is revoked and IAM does not delete the create's app
  client, the create answers 500. The thing stays revoked and holds the
  client's ID, so a revoke or a delete sent again deletes the app client,
  its API key and its pack copy by that ID (section 8).

A delete of the same instance (section 3) can also run at the same time
as the create. It writes `revokedAt` before it asks IAM, as a revoke does,
and deletes the thing only after IAM answered. So the same two cases hold
as for a revoke:

- The delete marked the thing before the create's second read. The create
  sees the mark, or no thing when the delete has deleted it by then, and
  deletes its own app client.
- The delete marks the thing after the create's second read. The delete
  asks IAM after that, so after IAM gave the create its app client, and
  deletes that client. The create answers 201 with credentials that stop
  working when the delete deletes them.

In both cases the instance has no app client once the delete answered
204, and is not listed. An instance that is not listed must not keep
working credentials, which is why the create treats a missing thing like
a revoked one:

- It asks IAM to delete the app client it got, by the client ID in IAM's
  answer, writes no `licenseExpiresAt`, and answers 409 with the detail
  `instance <rsid> was deleted while it was being created; create it again`.
  When the delete has marked the thing but not yet deleted it, the create
  answers the 409 for a revoked instance instead.
- When IAM does not delete the client, the create logs the failure at
  error level and answers 500. No thing holds the client's ID, so a delete
  sent again reaches the client only by its name.

Another create of the same instance may have answered this client's
credentials with 201. The instance has been deleted since, so those
credentials must stop working too, as they do after a revoke.

A delete that finds no thing marks and deletes no thing (section 3). A
create that made the thing after that read keeps it, so the instance is
listed. The delete still asks IAM to delete the app clients named
`tklocal-<rsid>`, which can delete the create's client. The known limits
below say what a person sees then.

A revoke that is slow to reach its write, for example one that read the
thing before the instance was deleted and created again, marks the new
thing and then deletes the new app client. Once that revoke answers 204,
the new instance is revoked as a whole: it is listed as `revoked`, and it
has no app client.

### 8. The thing records its app client's ID, and revoke and delete use it

The create writes the Cognito client ID in IAM's answer as the thing's
attribute `clientId`. It writes it as soon as IAM answers, before it reads
the thing again for a revoke (section 7) and before `licenseExpiresAt`. A
Cognito client ID is letters and digits, which a thing attribute can hold.
A create that reuses a thing replaces the ID the thing holds.

When the write fails, the create reads the thing again:

- The thing has `revokedAt`. The create asks IAM to delete the app client
  by the client ID in IAM's answer, as it does for a revoked thing in
  section 7, and answers 409 with the detail
  `instance <rsid> is revoked; delete it and create it again`. When IAM
  does not delete the client, the create answers 500. The thing does not
  hold the client's ID then, so a revoke sent again reaches the client
  only by its name.
- The thing no longer exists, because a delete of the instance deleted
  it. The write fails for that reason too. The create asks IAM to delete
  the app client by the client ID in IAM's answer, as it does when its
  second read finds no thing (section 7), and answers 409 with the detail
  `instance <rsid> was deleted while it was being created; create it again`.
  When IAM does not delete the client, the create answers 500, and a
  delete sent again reaches the client only by its name.
- The thing has no `revokedAt`, or cannot be read. The
  create keeps the app client, logs the failure at error level with the
  `rsid`, the thing name and the client ID, and answers 500. It does not
  delete the client, because another create of the same instance can run
  at the same time, and IAM gives both creates the client that has the
  instance's name. That other create may already have answered 201 with
  the client's credentials. Deleting the client would stop them working
  although nobody revoked or deleted the instance.

In every case the thing, when there is one, is kept.

A kept client has the instance's name, and the thing does not hold its
ID. A revoke or a delete reaches it by name. While it exists, the instance
has an app client, so the same create sent again answers 409 with the
detail `instance already exists for rsid: <rsid>`. Deleting the instance
and creating it again gives the caller new credentials.

Revoking and deleting an instance delete its app clients in two steps:

1. When the thing has `clientId`, ask IAM to delete the client of that ID
   (the `iam-licensing-clients` action `DeleteAppClient`). When no client
   has the ID any more, IAM still deletes the API keys tagged with it, and
   the grant, metadata and pack copy of that ID, and answers 404, which
   the admin API reads as "already deleted".
2. Ask IAM to delete every app client named `tklocal-<rsid>`.

When step 1 fails, the request answers IAM's 4xx status or 500 and does
not take step 2. Sent again, it repeats both steps. A thing without
`clientId` reads it as empty, and its app clients are deleted by name only.

The ID is needed because the name cannot always find the client. This
sequence leaves an enabled API key that no name reaches:

1. A revoke deletes the Cognito app client by name in the middle of IAM's
   create, after IAM made the client and before it made the client's API
   key.
2. IAM makes the key, tagged with the client's ID, and the pack copy, and
   answers the create.
3. The create sees `revokedAt` and asks IAM to delete the client by that
   ID. That delete fails for a passing reason, for example because API
   Gateway throttles the key delete. The create answers 500.
4. The operator sends the revoke again. No client has the name, so a
   revoke by name sends nothing to IAM and answers 204. The key and the
   pack copy stay.

With the ID on the thing, the revoke sent again in step 4 asks IAM to
delete that ID, and IAM deletes the key and the pack copy.

The delete by name stays because the thing's ID does not always name the
instance's client. When a create cannot write the new client's ID and
keeps the new client, a new thing holds no `clientId`, and a reused thing
still holds the ID of the earlier instance's client, which IAM no longer
has. A delete by that ID alone would answer 204 and leave the new client
working.

## Alternatives considered

**List the API keys by tag.** Rejected. Nothing writes the tags `provider`
or `pack` on an API key. Since ADR-0008, IAM creates every key, so only IAM
could add them. IAM creates keys for every kind of machine client, and would
need to learn tklocal's fields to tag them. The key would still not hold the
remote type, the display name or whether the device is connected.

**Read IAM's client metadata through a new read action on
`iam-licensing-clients`.** Rejected. IAM keeps metadata and a pack copy for
each client it creates, so a new action could answer every client named
`tklocal-*` with its pack. But:

- ADR-0008 keeps that function to three actions, and makes permission to
  invoke it account-wide licensing authority. A list action would answer
  every machine client of the account, not only tklocal's.
- The display name, the remote type and the connection status are not in
  IAM. The list would still read the IoT things and join the two answers.
- IAM would have to be released before tklocal could list anything.

**Keep the app client's ID only in the create's memory, and have the create
retry its delete by ID until it succeeds.** Rejected. A Lambda invocation
has a time limit, and the create cannot tell a passing failure from a
lasting one. Once the create answers, the ID is gone, and no later request
can find the API key of a client that no longer has the instance's name.

**Record the app client's ID in a table of the admin API's own.** Rejected.
It would be one more store to keep in step with the thing and IAM, which
section 7 avoids. The thing is already read by every request that revokes
or deletes.

## Consequences

**What a person sees.**

- The list shows every instance whose IoT thing exists. A new instance
  appears a few seconds after it is created, when fleet indexing has indexed
  its thing.
- A list entry has no creation time, app client ID or API key ID. Reading
  the one instance answers them.
- The list shows each instance as `active`, `expired` or `revoked`, and its
  `status` filter keeps the instances with that status. An instance whose
  API key is disabled is listed as `active`. Reading the one instance
  answers `disabled`.
- A revoked instance stays in the list until it is deleted. Renewing or
  downloading its license, and creating it again, answer 409 with the
  detail `instance <rsid> is revoked; delete it and create it again`.
- A revoke whose IAM step fails answers IAM's 4xx status or 500, and the
  instance is already listed as `revoked`. Its device can still
  authenticate until the revoke is sent again.
- A create and a revoke of the same instance sent at the same time end
  with the instance revoked and without an app client or API key. The
  create answers 409 when the revoke marked the thing before the create
  read it again, and 201 otherwise. The credentials in that 201 answer
  stop working when the revoke deletes the app client.
- When such a create cannot delete its app client, it answers 500. The
  instance is listed as `revoked`, and "Revoke Again" in the web app, or a
  delete, removes the client's API key and pack copy by the ID on the
  thing, also when no client has the instance's name any more.
- A create whose write of `clientId` fails answers 500. When the thing is
  not revoked, the create keeps the app client it got, and the instance is
  listed as `active`. Creating it again answers 409 until the instance is
  deleted. A revoke or a delete removes the client by name. When the thing
  is revoked, or no longer exists, the create deletes the client and
  answers 409, as for any create that finds the thing revoked or gone.
- A create and a delete of the same instance sent at the same time end
  with the instance not listed and without an app client, once the delete
  answered 204. When the delete marked the thing before the create read it
  again, the create deletes its app client and answers 409: with the
  detail `instance <rsid> was deleted while it was being created; create it again`
  when the thing is gone by then, and with the detail for a revoked
  instance when it is still there. Otherwise the create answers 201, and
  the delete deletes that client. Creating the instance again gives new
  credentials.
- When such a create cannot delete its app client, it answers 500. Once
  the delete has deleted the thing, the instance is not listed, but its
  app client works until a delete is sent again, which removes the client
  by name.
- Two creates of the same instance at the same time can get the same app
  client from IAM. When the later one cannot write `clientId`, or cannot
  read the thing again, the credentials the earlier one answered keep
  working.
- A create makes one more call to the device service than a create that
  writes no `clientId`.
- A revoke that arrives late, after the instance was deleted and created
  again, revokes the new instance.
- A create whose second read of the thing fails answers 500 and keeps the
  app client it got. The instance is listed as `active`, and creating it
  again answers 409 until it is deleted. A revoke or a delete removes the
  client by the thing's `clientId` and by name.
- An instance whose thing has no `licenseExpiresAt` is never `expired`.
  Creating it, or renewing or downloading its license, writes the
  attribute.
- When the write of `licenseExpiresAt` after a license fails, the caller
  still gets the license, and the instance keeps the expiry the thing held
  until the next renewal writes it.
- A thing without the attributes `pack` or `remoteType` is listed with them
  empty, and a `pack` filter does not match it.
- Creating an instance with a space, or another character a thing attribute
  cannot hold, in its pack, remote type or display name answers 400. A
  display name such as `Test Site Alpha` must be written `Test-Site-Alpha`.
- A delete that fails keeps the instance in the list. It is listed as
  `revoked` once the delete marked the thing, and as `active` when that
  mark failed. Sending the delete again finishes it. Sending a revoke
  again finishes removing the credentials, and keeps the thing.
- A delete whose IAM step fails answers IAM's 4xx status or 500. The
  instance is listed as `revoked`, and its device can still authenticate
  until the delete or a revoke is sent again.
- A delete whose thing delete fails answers 500. Until the delete is sent
  again, the instance is listed as `revoked` and has no app client, so
  renewing or downloading its license, and creating it again, answer 409
  with the detail `instance <rsid> is revoked; delete it and create it again`.
- Reading one instance, renewing and downloading a license, revoking and
  deleting read the thing first. When the device service cannot read it,
  they answer 500.
- An instance whose thing was removed outside the admin API, for example in
  the AWS console, is not listed, although its app client and API key still
  work. Deleting it through the admin API revokes the app client by name,
  because there is no thing to hold its ID, and marks and deletes no
  thing.
  Creating it again with the pack its app client was made from creates a
  new thing, and IAM reuses the existing app client, so it is listed again.
- When fleet indexing is off or fails, the list answers 500. The other
  routes do not use it.

**What this allows.**

- Listing every instance with one search per 100 instances, without a call
  to Cognito, API Gateway or IAM per instance.
- Showing whether each device is connected in the same list.
- Showing revoked and expired instances in the same list, with a status
  filter, still without a call per instance.
- Keeping `iam-licensing-clients` to its three actions.
- Creating and revoking or deleting an instance at the same time without
  a lock and without another store.

**What this forbids.**

- Adding a list field that is not a thing attribute. A new field is a new
  attribute that the admin API writes, and a thing without it reads it as
  empty.
- Deleting an instance's thing before the delete marked it with
  `revokedAt` and IAM deleted the instance's app clients.
- A revoke or a delete that asks IAM to delete the app client before the
  thing has `revokedAt`. A create that read the thing again in between
  would answer 201 and keep its client, and a delete would then leave
  that client working on an instance that is not listed.
- A delete that deletes a thing when it found none. That thing belongs to
  a create that started after the delete read, and the create's client
  would work on an instance that is not listed.
- A create that answers 201 without reading the thing again after IAM gave
  it an app client.
- A create that deletes the app client it got by the client's name rather
  than by the client ID in IAM's answer. The API key IAM made after a
  revoke deleted the client would stay.
- A create that deletes the app client it got when the thing, read again
  after IAM gave the create that client, exists without `revokedAt` or
  cannot be read. Another create of the same instance may have answered
  that client's credentials to its caller.
- A create that answers 201, or keeps the app client it got, when it reads
  the thing again and finds it gone. The instance is not listed, so nobody
  would see that its credentials still work.
- A create that reads the thing again for a revoke before `clientId` holds
  the ID of the app client it got. A create whose delete then fails would
  leave a key no later request can reach.
- A revoke or a delete that deletes the app client only by name when the
  thing has `clientId`, or only by `clientId`. The first misses the API
  key of a client that no longer has the instance's name. The second
  misses a client whose ID the thing does not hold.
- Removing `revokedAt` from a thing outside the admin API. The instance
  would read as active without an app client.
- Changing or removing the attribute `clientId` of a tklocal thing outside
  the admin API. A revoke or delete would then not reach the API key of a
  client that no longer has the instance's name. A value IAM refuses as a
  client ID makes the revoke and the delete answer 400 until it is
  corrected.
- Changing or removing the attributes `provider` or `rsid` of a tklocal
  thing outside the admin API. Either change hides the instance from the
  list.

**Known limit.**

- Two creates of the same instance at the same moment, together with a
  revoke and one failed cleanup, can leave an API key and a pack copy of
  an app client that no longer exists. The thing holds one `clientId` at a
  time, so the ID one create writes can replace the ID the other wrote.
  One order of steps that does it, for two creates A and B that both read
  the thing before the revoke marks it:
  1. IAM makes an app client for create B. A revoke marks the thing and
     deletes that client by name, before IAM made the client's API key.
  2. Create A's whole IAM call runs next. No client has the instance's
     name, so IAM makes a new client and API key for create A.
  3. IAM makes create B's API key and answers create B. The key has the
     instance's name, so it replaces create A's key.
  4. Create B writes its client's ID as `clientId`. Create A, which is
     slower, then writes its own client's ID over it.
  5. Both creates read the thing again and find it revoked. Create A
     deletes its client by ID and answers 409. Create B's delete of its
     client by ID fails, so create B answers 500.

  The thing now holds create A's client ID, and no client has the
  instance's name. So a revoke or a delete sent again does not reach
  create B's API key and pack copy. A single create leaves the same kind
  of key when a revoke deletes its client in the middle of IAM's create
  and both its write of `clientId` and its delete by ID fail, because the
  thing never held that ID. It also leaves one when a delete of the
  instance deletes its client by name in the middle of IAM's create, and
  the create's delete by ID fails, because no thing holds that ID.
  What it means for a person:
  - The key cannot get tokens, because its app client is gone.
  - The pack copy keeps the pack counted as in use in IAM until the
    license it recorded expires. Until then a super-admin can delete the
    pack only with `force`.
  - Deleting the instance and creating it again replaces the key. IAM
    finds the key by its name, sees that its `cid` tag names another
    client, deletes it and makes a new one.

  There is no lock against this. Creates of one site are operator
  actions, and two of them at the same moment are rare. A lock that holds
  across Lambda invocations would need a conditional write with an expiry,
  so that the lock of an invocation that stopped is released again.
- A delete of an instance that has no thing yet, sent while a create of
  it runs, marks and deletes no thing. When the create makes the thing
  after the delete read none, and the delete's request to IAM comes after
  IAM gave the create its app client, the delete deletes that client by
  name. The create found its thing unmarked when it read it again, so it
  answered 201. The instance is then listed as `active` without a working
  app client. Creating it again reuses its thing and gives it new
  credentials. The delete cannot delete the thing instead: when its
  request to IAM comes before the create's, the create's client survives,
  and deleting the thing would leave that client working on an instance
  that is not listed.
- A create that finds the thing revoked or gone deletes its app client by
  ID a moment after that read. When the instance is deleted and created
  again in that moment, and the new create gets the same client from IAM,
  the new instance is listed as `active` without a working app client.
  Reading it answers 404. Creating it again reuses its thing and gives it
  new credentials.

## Verification

- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_list_test.go`:
  `TestListInstances_EntryFromThing` checks the search query and that every
  field of an entry comes from the thing. `TestListInstances_ReadsEverySearchPage`
  checks that every page of the search is read.
  `TestListInstances_ThingWithoutPackOrRemoteType` checks that a thing
  without those attributes is listed with them empty.
  `TestListInstances_SearchError` checks that a failed search answers 500.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_thing_attributes_test.go`:
  `TestCreateInstance_PackAndRemoteTypeCharacters` and
  `TestCreateInstance_DisplayNameCharacters` check that create stores the
  pack, the remote type and the display name as thing attributes, and
  refuses a value a thing attribute cannot hold with 400.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_delete_test.go`:
  `TestDeleteInstance_HappyPath` checks that the delete marks the thing,
  then asks IAM, then deletes the thing, and that no thing, app client or
  API key of the instance is left.
  `TestDeleteInstance_RevokeFails_KeepsThing` checks that a failed IAM
  delete keeps the thing, listed as `revoked`, and that a retry finishes.
  `TestDeleteInstance_ThingDeleteFails_Answers500` checks that a failed
  thing delete answers 500, that the instance stays listed as `revoked`,
  and that a retry keeps the first `revokedAt` and finishes the delete.
  `TestDeleteInstance_MarkFails_AsksIAMNothing` checks that a failed mark
  answers 500, asks IAM nothing and leaves the instance `active`.
  `TestDeleteInstance_ThingAlreadyGone` and
  `TestDeleteInstance_ThingAlreadyGone_RevokeFails` check that an instance
  without a thing has its app clients deleted by name, and that no thing
  is marked or deleted.
  `TestDeleteInstance_RevokedInstance` checks that a revoked instance
  keeps its first `revokedAt` until its thing is deleted.
  `TestDeleteInstance_ThingWithClientID_DeletesByTheIDThenByName` checks
  that a thing with `clientId` has its app client deleted by that ID, then
  by name, then the thing deleted.
  `TestDeleteInstance_DeleteByClientIDFails_KeepsThing` and
  `TestDeleteInstance_ThingReadFails_Answers500` check that a failed
  delete by ID, and a failed read of the thing, keep the thing.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_get_test.go`:
  `TestGetInstance_WithAPIKey` checks that reading one instance answers
  `disabled` when its API key is disabled.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/status_test.go`:
  `TestInstanceStatus` checks the order of the status rules and the
  defaults of missing attributes.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_list_test.go`:
  `TestListInstances_StatusFromThingAttributes` checks the status and
  `expiresAt` of list entries. `handlers_get_status_test.go` checks them
  for the read of one instance, and that a revoked instance is answered
  from its thing.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_revoke_test.go`:
  checks that the revoke marks the thing before it asks IAM, that a failed
  mark asks IAM nothing, that a failed IAM revoke leaves the thing marked
  and a retry deletes the app client, and that the first `revokedAt` is
  kept. `TestRevokeInstance_ThingWithClientID_DeletesByTheIDThenByName`
  and `TestRevokeInstance_DeleteByClientIDFails_ThingStaysMarked` check
  the two delete steps of a thing with `clientId`, and that a failed
  delete by ID stops before the delete by name.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_create_during_revoke_test.go`:
  runs a revoke inside a create, at each point that matters.
  `TestCreateInstance_RevokedBeforeTheCheck_DeletesItsAppClient` marks the
  thing between the create's IAM call and its second read, and holds the
  revoke's IAM call until the create has answered.
  `TestCreateInstance_RevokedAfterTheCheck_RevokeDeletesTheAppClient` runs
  the whole revoke after that read.
  `TestCreateInstance_RevokedInsideTheIAMCall_DeletesTheAppClientByItsID`
  runs the whole revoke inside the create's IAM call, and checks that the
  create then deletes the app client by the ID IAM answered.
  `TestCreateInstance_RevokedInsideTheIAMCall_CleanupFails_TheThingsClientIDReachesTheKey`
  makes that delete fail once, so the create answers 500 and the API key
  of the client is left, and checks that a revoke sent again, and a
  delete, answer 204 and leave no API key or pack copy of that ID.
  `TestCreateInstance_CheckCannotReadTheThing_KeepsItsAppClient` makes the
  second read fail, and checks that the create answers 500 and keeps the
  app client and its API key, that the same create sent again answers
  409, and that a revoke, or a delete, then deletes the client by the
  thing's `clientId` and by name.
  `TestCreateInstance_CannotDeleteTheAppClientOfARevokedThing_Answers500`
  makes the create's delete of its app client fail, and checks that a
  revoke sent again deletes it.
  `TestCreateInstance_RevokedInsideTheIAMCall_ClientIDWriteFails_DeletesTheAppClientByItsID`
  makes the create's write of `clientId` fail after the revoke, and checks
  that the create reads the thing again, deletes the app client and its
  API key by the ID IAM answered, and answers 409.
  `TestCreateInstance_RevokedThing_ClientIDWriteAndDeleteFail_ARevokeSentAgainDeletesItByName`
  makes that delete fail too, and checks that the create answers 500 and
  a revoke sent again deletes the client by name.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_create_during_delete_test.go`:
  runs a delete inside a create.
  `TestCreateInstance_DeletedDuringTheIAMCall_DeletesItsAppClient` runs
  the whole delete while the create's request is on its way to IAM, so
  the create's write of `clientId` fails. It checks that the create finds
  no thing, deletes the app client and its API key by the ID IAM
  answered, answers 409 with the detail for a deleted instance, and that
  creating the instance again answers 201.
  `TestCreateInstance_DeletedAfterTheClientIDWrite_DeletesItsAppClient`
  holds the delete before it deletes the thing until the create has
  written `clientId`, and checks the same for the create's second read.
  `TestCreateInstance_DeletedDuringTheIAMCall_CleanupFails_ADeleteSentAgainDeletesItByName`
  and
  `TestCreateInstance_DeletedAfterTheClientIDWrite_CleanupFails_ADeleteSentAgainDeletesItByName`
  make that delete fail, and check that the create answers 500, that the
  instance is not listed while its client still exists, and that a delete
  sent again deletes the client by name.
  `TestCreateInstance_DeleteMarkedTheThingBeforeTheCheck_DeletesItsAppClient`
  holds the delete before it deletes the thing, after it marked the thing
  and asked IAM before the create's IAM call, until the create has
  answered. It checks that the create's second read finds the mark, that
  the create deletes its app client and answers 409, and that no thing,
  app client or API key is left once the delete answered 204.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_create_thing_test.go`:
  `TestCreateInstance_ClientIDIsOnTheThingAtTheCheck` checks that the
  thing holds `clientId` when the create reads it again, and has no
  `licenseExpiresAt` yet. `TestCreateInstance_ReusedThingIsBroughtUpToDate`
  checks that a reused thing gets the new client's ID.
  `TestCreateInstance_ClientIDWriteFails_KeepsTheAppClient` checks that a
  failed write of `clientId` on a thing that is not revoked, or cannot be
  read again, answers 500 and sends IAM no delete, that the same create
  sent again answers 409, and that a delete and a create after it answer
  204 and 201. `TestCreateInstance_ClientIDWriteFails_ARevokeDeletesTheClientByName`
  checks that a revoke deletes, by name, the client the create kept,
  also when the thing holds an earlier client's ID.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_create_twice_test.go`:
  `TestCreateInstance_SecondCreateGetsTheSameClient_ClientIDWriteFails_KeepsTheFirstCallersClient`
  runs a whole create inside the IAM call of a second create of the same
  instance. The first answers 201. IAM gives the second the same app
  client, and its write of `clientId` fails. The test checks that the
  second answers 500 and that the first caller's app client and API key
  still exist.
- `go-services/core/management/iam/handlers/licensingclients/delete_during_create_test.go`:
  `TestADeleteByTheIDOfAClientDeletedWhileItWasCreatedDeletesItsAPIKey`
  deletes a client between IAM's two create steps, and checks that a
  delete by that client's ID answers 404 and leaves no API key, grant,
  metadata or pack copy of that ID.
  `manager_e2e_test.go`:
  `TestTheLicensingManagerDeletesTheAPIKeyOfAClientRevokedWhileItWasCreated`
  checks the same through the go-core `licensing.Manager`, with a revoke
  by name in the middle of the create and a delete by ID after it.
- `go-services/providers/eastbound/tklocal/handlers/admin-api/service/handlers_license_expiry_test.go`
  and `handlers_create_thing_test.go`: check that a license's expiry is
  written after IAM issued it, that a failed write still answers the
  license, that a reused thing is brought up to date, and that a revoked
  instance answers 409 without asking IAM.
- `go-services/providers/eastbound/tklocal/deployment/stack_admin_api_test.go`:
  `TestAdminAPILambdaMaySearchTheFleetIndex` checks that the admin API's
  role may search the fleet index.
