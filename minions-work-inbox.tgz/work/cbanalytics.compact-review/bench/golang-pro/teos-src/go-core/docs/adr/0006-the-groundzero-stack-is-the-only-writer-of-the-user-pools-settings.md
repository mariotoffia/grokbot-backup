# ADR-0006: The GroundZero stack is the only writer of the user pool's settings

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-14 |

## Summary

Every TEOS account has one shared Cognito user pool, `teos-public`. The
GroundZero stack creates it. The IAM service's pre-token-generation function
must be attached to it, because that function puts each user's scopes and
claims into their tokens. This record decides who writes the pool's settings,
the trigger included.

The decision in one paragraph:

> The GroundZero stack is the only writer of the user pool's settings. Its
> CloudFormation definition of the pool declares the pre-token-generation
> trigger: the alias `live` of the function `iam-pre-token-gen`, with the
> V2_0 event. The ARN is built from those two fixed names and the stack's own
> partition, region and account. The names live in one place in the
> deployment library, and the IAM stack creates the function and the alias
> with them. No other stack calls Cognito's `UpdateUserPool`. The IAM stack
> keeps one custom resource that only reads the pool, so that removing it
> never runs the action deployed IAM stacks stored with it.

## Terms used

| Term | Meaning here |
| --- | --- |
| User pool | The Cognito user pool `teos-public` that every TEOS user signs in to. |
| GroundZero stack | The base stack every TEOS account has (`deployment/stacks/groundzero`). It creates the user pool as an `AWS::Cognito::UserPool` resource. |
| IAM stack | The stack of the IAM service (`go-services/core/management/iam/deployment`). It deploys after GroundZero. |
| Pre-token-generation trigger | A Lambda function Cognito calls before it issues tokens to a signed-in user. Its event version V2_0 lets it change access tokens. Cognito does not call it for a machine client's client-credentials token. |
| Trigger function | The IAM service's function `iam-pre-token-gen`. Cognito calls its alias `live`. |
| Custom resource | A CloudFormation resource whose create, update and delete actions are calls that a Lambda function makes. The IAM stack uses CDK's `AwsCustomResource`, which stores one AWS SDK call for each action. |

## Context

The GroundZero stack owns the user pool through CloudFormation. Any second
writer of the pool's settings and that CloudFormation resource undo each
other:

- **`UpdateUserPool` resets every setting it is not given.** Cognito sets each
  setting a request leaves out back to its default. A second writer that
  sends only the trigger therefore also resets the pool's other settings, for
  example whether users may sign themselves up.
- **A CloudFormation update of the pool removes undeclared triggers.**
  CloudFormation updates the pool with the settings the template declares. A
  trigger the template does not declare is removed by every GroundZero update
  of the pool, and a custom resource in another stack runs again only when
  its own properties change, so nothing puts the trigger back.

When the trigger is gone, Cognito no longer calls the trigger function. Every
access token a signed-in user gets then holds only the scope
`aws.cognito.signin.user.admin`, so every TEOS API call that needs a scope is
refused for users. A machine client's client-credentials token does not use
the trigger and keeps the scopes it asks for.

The local emulator Floci does not show the problem. Its `UpdateUserPool`
changes only the settings in the request, so service tests on Floci pass.

Cognito accepts a trigger whose function does not exist yet. The function and
its alias have fixed names, and the IAM stack grants Cognito the right to call
the alias.

## Decision

### 1. GroundZero declares the trigger

The GroundZero stack's pool declares the pre-token-generation trigger with the
V2_0 event (`addPreTokenGenTrigger` in
`deployment/stacks/groundzero/cognito.go`). The trigger is the ARN
`arn:<partition>:lambda:<region>:<account>:function:iam-pre-token-gen:live`,
built from the stack's own partition, region and account.

The function is imported by that ARN without permissions, so GroundZero
creates no Lambda permission. The function does not exist when GroundZero
first deploys.

### 2. One definition of the names

The deployment library holds the function name, the alias name and the
function that builds the ARN (`PreTokenGenFunctionName`,
`PreTokenGenAliasName` and `PreTokenGenTriggerArn` in
`deployment/lib/adapters/cdk/idm/pretokengen.go`). The IAM stack names its
function and alias with the same constants, and grants Cognito the right to
invoke the alias.

### 3. No other stack writes the pool

No stack other than GroundZero calls `UpdateUserPool` or changes the pool's
settings in any other way. A stack that needs a setting on the pool adds it to
the GroundZero stack's definition of the pool.

### 4. The IAM stack keeps a read-only custom resource

Deployed IAM stacks hold the custom resource `PreTokenGenTrigger`. Its stored
delete action detaches the trigger. If that resource left the template, or
were replaced, CloudFormation would run the stored delete action and remove
the trigger again.

So the IAM stack keeps a custom resource with the same construct ID, and so
the same logical ID, and the same physical ID
(`keepPreTokenGenTriggerResource` in
`go-services/core/management/iam/deployment/stack_pretokengen_trigger.go`).
Its create, update and delete actions call `DescribeUserPool` and return only
the pool ID. The policy statement it adds allows only `DescribeUserPool` on
the pool. This resource must stay in the template.

## Alternatives considered

**Keep the IAM stack as the writer of the trigger, and copy every other
setting into its `UpdateUserPool` call.** Rejected. Every GroundZero update
would still remove the trigger, and the copy would have to follow every
setting GroundZero adds.

**Let the IAM stack run its `UpdateUserPool` on every deploy.** Rejected. It
still resets the settings it leaves out, and a GroundZero deploy after it
still removes the trigger.

**Delete the IAM stack's custom resource.** Rejected. CloudFormation would run
the delete action stored with it in each deployed IAM stack, and that action
detaches the trigger.

## Consequences

**What a person sees.**

- A GroundZero deploy keeps the trigger. Tokens keep the scopes and claims the
  IAM service gives them.
- Deploying GroundZero with this decision puts the trigger back on a pool that
  has none. The update also sets every setting the template declares.
- Between GroundZero's first deploy and the IAM stack's first deploy, the pool
  calls a function that does not exist yet, so a sign-in fails. No user exists
  in that window: the IAM stack creates the first users.
- Removing the IAM stack leaves the trigger on the pool, so every sign-in fails
  until the IAM stack is deployed again.
- Deploying an IAM release from before this decision runs that release's update
  action. It writes the pool with only the trigger, and resets the pool's other
  settings to Cognito's defaults. A GroundZero deploy undoes that only when its
  definition of the pool changed, because CloudFormation skips a resource whose
  definition did not change.

**What this allows.**

- Changing the pool's settings, the trigger included, in the GroundZero
  stack's definition of the pool.

**What this forbids.**

- Any other stack calling `UpdateUserPool`, or changing the pool's settings
  any other way.
- Renaming the trigger function or its alias in one stack only. Both stacks
  read the names from the deployment library, and a rename needs a GroundZero
  deploy as well as an IAM deploy.
- Removing the IAM stack's `PreTokenGenTrigger` resource, changing its
  construct ID or its physical ID, or giving it an action that writes the pool.

## Verification

- `deployment/stacks/groundzero/cognito_trigger_test.go`:
  `TestUserPoolDeclaresTheIAMPreTokenGenerationTrigger` checks that the pool
  declares the trigger with the V2_0 event and the alias ARN built from the
  stack's partition, region and account. It also checks that GroundZero
  creates no Lambda permission for the function.
- `go-services/core/management/iam/deployment/stack_pretokengen_trigger_test.go`:
  `TestPreTokenGenTriggerResourceOnlyReadsTheUserPool` checks that the custom
  resource keeps the logical ID `PreTokenGenTrigger1A12F540` that deployed IAM
  stacks hold. It checks that its three actions call `DescribeUserPool` with
  the physical ID `PreTokenGenTrigger-pretokengen-trigger` and return only the
  pool ID, and that its role may only read the pool. It also checks that the
  template holds no `updateUserPool` call.
- The IAM service test on Floci and on AWS signs users in and checks that their
  access tokens hold the scopes of their groups.
