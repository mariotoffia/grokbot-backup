# ADR-0007: A delegated token comes from a server-side sign-in of the subject

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-14 |

## Summary

The IAM service lets an admin create a delegation: a stored rule that lets one
user, the actor, act on behalf of another user, the subject. The actor then
calls the token exchange (`POST /v1/exchange` on the IAM REST API) and expects
an access token that acts as the subject and names the actor. This record
decides where that token comes from.

The decision in one paragraph:

> The IAM delegation function signs the subject in on the server, inside the
> exchange call, with Cognito's custom sign-in flow. It signs in through one
> app client that exists only for this, `teos-iam-exchange`, which has a client
> secret. It answers the one challenge with the ID of the exchange session it
> just stored, and sends the same ID in the `ClientMetadata` of that answer.
> The pre-token-generation trigger recognises the app client by its exact ID,
> uses up the session named in the metadata, checks that the delegation still
> allows it, and writes the session's scopes and claims and the `act` claim
> into the token. The GroundZero stack declares the IAM function
> `iam-exchange-auth` (alias `live`) as the pool's three custom sign-in
> triggers, and that function refuses a custom sign-in through any other app
> client. Before it hands the token to the actor, the exchange decodes it and
> refuses it unless it acts as the subject, names the actor, and holds only
> the session's scopes, never Cognito's self-service scope.

## Terms used

| Term | Meaning here |
| --- | --- |
| User pool | The Cognito user pool `teos-public` that every TEOS user signs in to. The GroundZero stack creates it. |
| Delegation | A stored rule, created by an admin, that lets the actor act on behalf of the subject with a limited set of scopes. It lasts until it is deleted, or until the end of its optional validity window. |
| Actor | The user who calls the token exchange and receives the token. |
| Subject | The user the token acts as. The token's `sub` claim is the subject. |
| Exchange session | A single-use record the exchange stores in the DynamoDB table `teos-auth-grants`. It holds the scopes and claims the token gets, and the actor and subject. |
| `act` claim | The RFC 8693 actor claim. In a delegated token it names the actor, as `act.sub`. |
| Custom sign-in flow | Cognito's `CUSTOM_AUTH` flow. Three Lambda triggers on the pool decide it: *define auth challenge* decides the next step, *create auth challenge* makes the challenge, and *verify auth challenge response* checks the answer. |
| Pre-token-generation trigger | The IAM function `iam-pre-token-gen`, which Cognito calls before it issues tokens to a signed-in user. It writes each user's scopes and claims into the access token. |
| Token-exchange app client | The Cognito app client `teos-iam-exchange`. The IAM stack creates it. |
| `ClientMetadata` | A map of strings a Cognito sign-in request may hold. Cognito passes it to the triggers. |
| `SECRET_HASH` | The value Cognito requires on every sign-in request to an app client with a secret: Base64(HMAC-SHA256(secret, user name + client ID)). |
| Self-service scope | Cognito's scope `aws.cognito.signin.user.admin`. Every token from a Cognito API sign-in holds it. It lets the holder read and change the signed-in user's own profile: change the email address, delete the account, sign the user out everywhere. |

## Context

- **Only a sign-in as the subject gives a token whose `sub` is the subject.**
  Cognito never lets the pre-token-generation trigger add, change or remove
  `sub`, `username`, `cognito:username` or `client_id`.
- **The only way for a server to sign a user in without the user's password is
  the custom sign-in flow.** It needs the three custom sign-in triggers on the
  pool.
- **Data reaches the pre-token-generation trigger only through the final
  challenge answer.** The `ClientMetadata` of `AdminRespondToAuthChallenge`
  reaches it. The `ClientMetadata` of `AdminInitiateAuth` does not.
- **Cognito generates every app client ID.** No app client can be given an ID
  that marks it as an exchange client.
- **An app client that names no sign-in flows allows the custom sign-in
  flow,** because it is one of Cognito's defaults. Once the pool has custom
  sign-in triggers, anyone who holds such a client can start a custom sign-in
  through it. An app client created at run time (by the IAM licensing API,
  the tklocal admin API or the `cbiam` command) names only the refresh-token
  flow (`ALLOW_REFRESH_TOKEN_AUTH`), so no user sign-in can start through it.
  An app client that already exists keeps the flows it was created with. One
  that names none has Cognito's defaults, and the custom sign-in trigger
  refuses a custom sign-in through it, because the trigger accepts only the
  token-exchange app client. The web app clients `teos-public-spa` and
  `teos-cbdeploy` name their flows and leave the custom sign-in out, so
  Cognito refuses a custom sign-in through them before any trigger runs.
- **A token from a Cognito API sign-in holds the self-service scope.** A token
  that acts as the subject and holds it lets the actor change the subject's
  email address. The pre-token-generation trigger may remove it.
- **API Gateway's Cognito authorizers accept only tokens the user pool
  signed.** They check the signature and the expiry. They do not ask Cognito
  whether a token was revoked.
- **The GroundZero stack is the only writer of the pool's settings**
  (ADR-0006). Cognito accepts a trigger whose function does not exist yet.

## Decision

### 1. The exchange signs the subject in on the server

After it has checked the delegation and stored the exchange session, the IAM
delegation function (`iam-delegation-api`) makes two Cognito calls through
the token-exchange app client:

1. `AdminInitiateAuth` with the flow `CUSTOM_AUTH`, the subject's `sub` as the
   user name, and the `SECRET_HASH`.
2. `AdminRespondToAuthChallenge` to the `CUSTOM_CHALLENGE`, with the session ID
   as the answer, the `SECRET_HASH`, and `ClientMetadata` holding the session
   ID under the key `teosExchangeSession`.

Cognito answers the second call with the tokens. The function keeps the access
token and throws the ID token and the refresh token away. The caller makes one
call and gets the access token in the answer, with `tokenType` `Bearer` and
`expiresIn` in seconds.

### 2. One confidential app client exists only for the exchange

The IAM stack creates the app client `teos-iam-exchange` on the user pool:

- It has a client secret. The delegation function is the function that reads
  the secret, with `DescribeUserPoolClient` on first use, and signs in with it.
- It allows the custom sign-in flow and no OAuth flow. CDK adds the refresh
  flow itself.
- Its access and ID tokens live for the minutes the provision config sets in
  `services.iam.exchangeClient.accessTokenValidityMinutes` (5 to 1,440),
  15 when the setting is absent.
- Its refresh tokens live 60 minutes, or as long as the access token when that
  is longer. Cognito allows no shorter refresh token. Nobody receives one.
- Its ID reaches four IAM functions as the environment variable
  `CB_IAM_EXCHANGE_CLIENT_ID`: the delegation function, the
  pre-token-generation function, the exchange-auth function and the
  licensing API function. It is not exported.

### 3. One function answers the custom sign-in triggers

The IAM function `iam-exchange-auth`, through its alias `live`, answers all
three custom sign-in triggers
(`go-services/core/management/iam/handlers/exchangeauth`):

- **Define auth challenge** refuses a sign-in through any app client other
  than the token-exchange client. For that client it asks one
  `CUSTOM_CHALLENGE`, issues tokens after exactly one correct answer, and
  refuses everything else.
- **Create auth challenge** makes the challenge with one private parameter,
  `challenge` = `exchange-session`, because Cognito refuses a challenge with no
  parameters. The public parameters are empty, and private parameters go only
  to the verify step, so the caller receives no challenge parameter from the
  create step. The answer is the session ID, which the delegation function
  already holds.
- **Verify auth challenge response** accepts the answer only through the
  token-exchange client, and only when it is the ID of a stored session that
  has not expired and whose subject is the user signing in. It reads the
  session and leaves it in place.

### 4. GroundZero declares the triggers

The GroundZero stack's definition of the pool declares the alias ARN
`arn:<partition>:lambda:<region>:<account>:function:iam-exchange-auth:live` as
the define, create and verify auth challenge triggers
(`addExchangeAuthTriggers` in `deployment/stacks/groundzero/cognito.go`). It
creates no Lambda permission. The IAM stack creates the function and the alias
and grants Cognito the right to invoke the alias. Both stacks read the names
from the deployment library (`deployment/lib/adapters/cdk/idm/exchangeauth.go`).

### 5. The pre-token-generation trigger writes the delegated token

A sign-in is an exchange when its app client ID equals
`CB_IAM_EXCHANGE_CLIENT_ID`. An empty setting means no app client is the
exchange client. For an exchange, the trigger:

1. reads the session ID from `ClientMetadata["teosExchangeSession"]`, and
   refuses the token when it is missing;
2. reads and deletes the session in one DynamoDB call, so the session gives at
   most one token;
3. refuses the token unless the session has not expired and the signed-in user
   is its subject;
4. reads the delegation, and refuses the token unless it exists, is active, and
   names the session's actor and subject;
5. writes the session's scopes and claims, `rsid` and `oid` included, and the
   `act` claim into the access token;
6. suppresses every requested scope the session does not hold, and always the
   self-service scope.

Every error on this path refuses the token. Cognito then fails the sign-in.

### 6. The exchange checks the token before it hands it out

The delegation function decodes the access token's payload. It does not check
the signature, because the token came straight from Cognito. It refuses the
token unless `sub` is the subject, `act.sub` is the actor, and every scope in
the `scope` claim is a scope of the session and not the self-service scope.
A pool without the IAM
pre-token-generation trigger issues the subject's own token, with the
self-service scope and no `act` claim. This check stops that token from
reaching the actor.

- A failed sign-in answers 503 with the detail `service unavailable`.
- A token that fails the check answers 500 with the detail `internal error`.
- In both cases the function deletes the session. It does not count against
  the actor's limit of 10 open sessions.

## Alternatives considered

**The actor signs in again, and the trigger narrows the actor's token.**
Rejected. The token's `sub` would be the actor, because the trigger cannot
change `sub`. Every TEOS API reads the user from `sub`, so each call would work
on the actor's data, not the subject's.

**The client completes the sign-in.** The exchange would return the session ID,
and the caller would answer the custom challenge itself. Rejected. The caller
cannot compute a `SECRET_HASH`, so the app client would need to be public. The
session ID would then be a bearer secret: anyone holding it could redeem it.
The caller would also need the subject's Cognito user name.

**IAM signs its own JSON Web Token.** Rejected. API Gateway's Cognito
authorizers accept only tokens the user pool signed, so every TEOS API would
refuse the token.

**One app client per exchange.** Rejected. Cognito generates the client ID, so
the pre-token-generation trigger could only find the session through a stored
mapping. A pool holds at most 1,000 app clients by default, and
`CreateUserPoolClient` is limited to 15 calls per second.

## Consequences

**What a person sees.**

- One call to `POST /v1/exchange` returns the delegated access token. The
  token acts as the subject, so every TEOS API works on the subject's data. Its
  `act` claim names the actor.
- The token lives 15 minutes by default. A deployment changes that in its
  provision config. The IAM stack gives the delegation function the same
  minutes in the environment variable `CB_IAM_EXCHANGE_TOKEN_MINUTES`.
- A delegation's `maxLifetimeSec` is an upper bound on the token's lifetime.
  A value above 0 and below the token's lifetime is refused with 400, when
  the delegation is created and at each exchange, because every token would
  outlive it. 0 means the token's lifetime applies. The value also sets how
  long the stored session may live before it is used, 5 minutes when 0.
- The token cannot be refreshed. The actor calls the exchange again for a new
  one. A delegated token cannot exchange again, because it holds `act`.
- The token never holds the self-service scope, so it cannot change the
  subject's own Cognito profile.
- A deleted or disabled delegation issues no new token. No API route disables
  a delegation. Only a direct change of the stored row does. A token already
  issued works until it expires, because API Gateway checks only the signature
  and the expiry.
- A custom sign-in through any other app client, such as the web app client,
  fails at once. Nobody gets a challenge.
- When the subject's Cognito account was deleted after the delegation was
  created, the exchange answers 404. It reads the subject's groups before it
  signs in, and Cognito no longer knows the user. No session is stored.
- When Cognito cannot sign the subject in, the exchange answers 503. That
  includes a subject whose Cognito account is disabled.
- In the normal deploy order, GroundZero first and then IAM, the triggers point
  at a function that does not exist yet between the two deploys. Custom
  sign-ins fail in that window. Nothing else does.
- With IAM deployed before GroundZero, the pool has no custom sign-in triggers,
  so every exchange answers 503.
- Downgrading IAM to a release without the function leaves the triggers
  pointing at nothing. Custom sign-ins fail. Normal sign-ins are untouched.

**What this costs.**

- A delegated token reaches whatever the subject's groups and organizations
  reach. It holds the subject's Cognito groups, because it is the subject's
  token. It holds the subject's `rsid` and `oid` claims too, because the
  subject's value wins when the two users' claims are merged. The exchange
  narrows only the scopes, to those both users hold. Many TEOS access
  policies decide by group membership and by `oid`, not by scope.
- So an actor who creates a delegation for a more powerful subject gets a
  token that those policies treat as the subject. For example, a member of
  `teos-admin` whose `oid` is one organization can create a delegation for a
  member of `teos-super-admin` whose `oid` is `all`. The token the
  actor then gets is in the group `teos-super-admin`, and `all` covers
  every organization, so the actor can read the data of every organization.
  Most TEOS access policies refuse a change made with a delegated token, so
  the actor can read much more but change little. Only members of
  `teos-admin` and `teos-super-admin` can create a delegation, and not with a
  delegated token. This cost is accepted.
- Each exchange is one Cognito sign-in, and counts against the pool's shared
  sign-in quota (120 per second by default).
- Three function roles that TEOS stacks create may call
  `DescribeUserPoolClient` on the pool, so they can read the client secret:
  the delegation function, the IAM licensing API function
  (`iam-licensing-api`) and the tklocal admin API function
  (`tklocal-<deployEnv>-admin-api`). The last two manage machine app
  clients, so they may also update and delete any app client of the pool,
  this one included.
- An IAM permission for `DescribeUserPoolClient` names a user pool, never
  one app client. So the delegation function can read the secret of every
  app client of the pool, the machine clients included, not only this one.
- The IAM licensing API does not show or change this client. The IAM
  deploy gives the licensing API function the client's ID in the
  environment variable `CB_IAM_EXCHANGE_CLIENT_ID`. Reading, licensing or
  deleting this client through the licensing API, or setting its grants,
  answers 404, as for an unknown client ID, and the list of app clients
  leaves it out. So no caller of the licensing API gets this client's
  secret, licenses it or deletes it.
- The secret alone signs nobody in. A custom sign-in through this client also
  needs the ID of a stored, unexpired session whose subject is the user
  signing in, or the verify step refuses it. The pre-token-generation trigger
  refuses every sign-in through this client that names no session, and
  writes the token only from that session. A session is stored while its
  exchange call runs. It stays until it expires when the delegation function
  times out or stops after storing it, or when the delete after a failed
  exchange fails.
- A role that can both write a session row in the table `teos-auth-grants`
  and read the secret could sign in as any user. It could store its own
  session, for any subject, any actor and any scopes, and complete the custom
  sign-in itself through Cognito's public `InitiateAuth` and
  `RespondToAuthChallenge` calls, which need no AWS permission, only the
  `SECRET_HASH`. Every trigger check would pass.
- Only the delegation function writes session rows. Only the delegation
  function, after an exchange that issued no token, and the
  pre-token-generation trigger, which uses a session up, delete them. A
  session row is a row whose partition key starts with `SESSION#`.
- IAM enforces this. Every other IAM function role that may write the table
  (the identity, authorization, licensing, admin and recompute functions and
  the catalog registrar) has an explicit deny of `PutItem`, `UpdateItem`,
  `DeleteItem` and `BatchWriteItem` on the table for any request whose
  partition keys include one that starts with `SESSION#`. The role of the
  custom resources that seed the group grants at deploy time has the same
  deny. An explicit deny wins over every allow. So the licensing API
  function, which can read the secret, cannot store a session, and cannot
  sign anyone in through this client.
- The exchange-auth function reads only session rows. Its role allows
  `dynamodb:GetItem` on the table, and only when every partition key the
  request names starts with `SESSION#`. It has no other access to the table.
- The licensing API function can still rewrite every group's grants in the
  same table. Those grants decide every user's scopes and claims, so,
  misused, it can give itself any access, but it cannot act under another
  user's identity.
- The tklocal admin API role has no access to the table. Misused, it can only
  change or delete the client. If it deleted the client, every exchange would
  answer 503 until the client is created again. An IAM deploy does not create
  the client again, because CloudFormation does not notice that it is gone. A
  deploy that leaves the client's settings unchanged does nothing to it, and
  one that changes them fails, because CloudFormation cannot update a client
  that no longer exists. The client comes back only with a deploy that makes
  CloudFormation create a new one, for example by giving its construct a new
  ID. If it changed the client's token lifetime, delegated tokens would live
  that long.

**What this allows.**

- Changing the delegated token's lifetime per deployment, in the provision
  config.

**What this forbids.**

- Letting any app client other than the token-exchange client complete a
  custom sign-in.
- Handing the actor a token from the exchange without the check in decision 6.
- Renaming `iam-exchange-auth` or its alias in one stack only. A rename needs a
  GroundZero deploy as well as an IAM deploy.
- Recognising the exchange by anything but the exact app client ID.

## Verification

- `go-services/core/management/iam/handlers/exchangeauth/challenge_test.go`:
  `TestDefineAuthChallengeRefusesAnotherClient`,
  `TestDefineAuthChallengeAllowsOneAttemptOnly`,
  `TestVerifyAuthChallengeAcceptsTheSubjectsSession` and
  `TestVerifyAuthChallengeRefuses` check the three triggers.
- `go-services/core/management/iam/handlers/pretokengen/exchange_session_test.go`:
  `TestIsExchangeClientMatchesTheConfiguredIDExactly`,
  `TestExchangeSignInWithoutSessionMetadataFailsClosed`,
  `TestExchangeClientRefreshWithoutSessionFailsClosed`,
  `TestExchangeTokenUsesTheSessionNamedInTheMetadata`,
  `TestExchangeTokenRefusesADeletedDelegation` and
  `TestExchangeTokenSuppressesEveryScopeTheSessionLacks` check the
  pre-token-generation trigger.
- `go-services/core/management/iam/internal/core/application/tests/delegation_signin_test.go`:
  `TestExchangeReturnsTheDelegatedToken`,
  `TestExchangeSignInFailureDeletesTheSession` and
  `TestExchangeRefusesATokenWithoutAct` check the exchange and its token check.
- `go-services/core/management/iam/deployment/stack_exchange_test.go`:
  `TestExchangeClientIsConfidentialAndAllowsOnlyCustomSignIn`,
  `TestThreeFunctionsGetTheExchangeClientID` and
  `TestCognitoMayInvokeTheExchangeAuthAlias` check the IAM stack.
- `deployment/stacks/groundzero/cognito_trigger_test.go`:
  `TestUserPoolDeclaresTheIAMCustomSignInTriggers` checks that the pool
  declares the three triggers on the alias ARN.
- `go-services/core/management/iam/deployment/service-test/delegation_test.go`:
  `TestDelegatedTokenActsAsTheSubject` and
  `TestCustomSignInThroughTheWebClientIsRefused` check on a deployed IAM
  service that the exchanged token acts as the subject, names the actor and
  reads only what the subject may read, and that the triggers refuse a custom
  sign-in through the web app client.
