# ADR-0003: One access check per Lambda, with the route in the policy input

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-10 |

## Summary

Most TEOS Lambda functions serve several routes and decide who may call them
with one Rego access policy. This record decides how that works for every
transport adapter in `go-core/tkdisp`: API Gateway REST API (v1) and HTTP API
(v2) through `cbhttp`, plain Lambda invocations through `cblambda`, and SQS
through `cbsqs`.

The decision in one paragraph:

> A Lambda function has **one** policy registration for access, of the form
> `PROCESS <name>/access`. The route goes into the policy **input**, not into
> the registration. One shared function, `cbpolicy.CheckAccess`, builds the
> input the same way on every transport and evaluates it. On HTTP, a router
> called `cbhttp.AccessMux` runs that check before every route registered on it,
> so a route cannot be added without being checked. A refusal answers 403. A
> missing policy, a missing registration or a policy that does not say `allow`
> refuses the request.

## Terms used

| Term | Meaning here |
| --- | --- |
| Policy decision point (PDP) | The component that runs Rego policies. Its configuration file (`*-pdp.json`) holds **registrations**. |
| Registration | One entry in the PDP configuration. It names an operation (`GET`, `POST`, `PROCESS`, ...), a path such as `appstore/access`, the policy to run and the Rego query that gives the answer. The PDP finds a registration by exact operation and exact path. |
| Policy path | The path of the registration a check uses, for example `appstore/access`. |
| Route | The name of what a request calls. On HTTP it is the path pattern the handler registered on the Go router, for example `/v1/sites/{rsid}/things`. On SQS and plain Lambda it is the route name the handler was started with, for example `config/dispatch`. |
| Base path | The first path segment API Gateway's custom domain adds in front of a service's paths, for example `sur` in `https://api.{accountDomain}/sur/v1/...`. |
| Call context | The per-request record on `ifcore.CbContext` that holds the operation, path, path parameters, query parameters and headers. The adapter creates it. `CallContext()` returns the newest one on a stack. |
| Security context input | The `input.sc` document a Rego policy reads to learn who the caller is. |
| Floci | The local AWS emulator TEOS tests run against. |

## Context

Three API families work this way today: the five AppStore API Lambdas, the five
IAM API Lambdas and the GoBridge runtime API. Each has one registration such as
`PROCESS appstore/access`, and its Rego rules look at the method and the route.
The tklocal admin API has a copy of the IAM code. Each service wrote 60 to 190
lines of glue to make it work, because `tkdisp` offers nothing for it. The
default path `tkdisp` does offer has traps that leave a route unprotected
without any error.

These are the problems this record has to solve. Each ends with what a person
sees.

1. **The default policy lookup uses the concrete path.**
   `cbpolicy.BeforeEvent(PolicyConfig{})` looks up a registration under the
   request's actual path, such as `v1/sites/abc/things`. Nobody can register
   that, because the PDP matches exact paths only. Without `Required: true` the
   check is skipped and the request succeeds. With it, the request fails with
   500. A route that looks protected is not, and nothing reports it.
2. **The same route has two spellings.** Through the custom domain the event's
   `path` starts with the base path (`/sur/v1/...`). Through a direct invocation
   or Floci it does not (`/v1/...`). Handlers register every route twice, and a
   policy keyed on the path has two keys for one route.
3. **The route template never reaches the handler.** Handlers type every route
   pattern a second time by hand when they call the policy, about 60 times in
   AppStore and as many in IAM. A typo checks a different route than the one
   that runs.
4. **`BeforeEvent` puts no method or route into the input.** A policy that
   covers several routes needs the handler to add them itself.
5. **The caller document differs between the two ways to call a policy.**
   `BeforeEvent` sends only `input.sc.oidc`. `pep.Process` also sends
   `caller_type`, `sub`, `client_id`, `grant_type`, `groups` and `scopes`. A
   policy written for one silently loses fields on the other.
6. **A refusal answers 400 Bad Request.** The `cberror` code for a refused
   policy is 400. GoBridge converts it to 403 by hand. AppStore and SUR send 400
   to the caller, who is told the request was malformed when it was forbidden.
7. **PATCH, HEAD and OPTIONS become `PROCESS`.** A registration for `PATCH` can
   never match, and a PATCH route collides with `PROCESS` registrations.
8. **Using a `PROCESS` registration from an HTTP route means pushing a new call
   context.** AppStore never removes it, so code after the check reads the
   policy's empty headers. The client's `X-Correlation-ID` is lost and a new one
   is generated.
9. **`BeforeEvent` fits only `cbhttp.JSON`.** With `Handler`, `Action`,
   `RawHandler` or a generated server, the check has to be called by hand inside
   every handler.
10. **`cbhttp.Authorize`, `AuthorizeWithBody` and `AuthFunc` have no callers.**
    go-core ships no policy implementation for them.
11. **API Gateway v2 gets no caller token.** `cbhttp.CognitoContextFactory`
    reads only v1 events. No TEOS Lambda uses v2 today.
12. **`cblambda` and `cbsqs` give one route per handler and no caller token.**
    The operation is always `PROCESS`. `cblambda` gets a token only through
    `WithTokenExtractor`, which nothing calls. `cbsqs` never sets one.

## Decision

### 1. The route is the pattern the handler registered

On HTTP, the route is the path part of the Go `http.ServeMux` pattern that
matched the request: the value of `r.Pattern` without the method and host. For
a handler registered as `GET /v1/sites/{rsid}/things` the route is
`/v1/sites/{rsid}/things`. It is the string the handler author wrote, and
nothing types it a second time.

The REST API adapter removes the base path before the router sees the request.
A new adapter option, `cbhttp.WithBasePath("sur")`, makes `APIGatewayV1` remove
a leading `/sur` when the path is exactly `/sur` or starts with `/sur/`. Through
the custom domain, the `execute-api` address, a direct invocation and Floci, the
router then sees `/v1/...`. A handler registers each route once, without the
base path. The call context's path is the path after the base path is removed,
so the path a policy sees is also the same on every invocation path.

`APIGatewayV2` accepts the option, because both adapters take the same option
type, and ignores it. An HTTP API's `rawPath` never contains the custom domain's
API mapping, so there is nothing to remove.

On SQS and plain Lambda, the route is the route name the handler was started
with (`cbsqs.JSONWithRoute`, `cblambda.JSONWithRoute` and the other `WithRoute`
constructors).

The call context gets a new field for it. `ifcore.CbCallContext` gains
`GetRoute() string`, and `coremodel.CallContext` gains `Route string`.
`runtime.DefaultContextFactory` copies `RequestMeta.RouteName` into it. The HTTP
adapters leave it empty, because the route is known only once the router has
matched. `cbhttp.AccessMux` (section 5) fills it in.

### 2. One registration per Lambda; the route goes into the input

PDP registrations keep matching exact paths. Nothing adds path templates or
wildcards to the PDP. A Lambda's access policy has one registration:

```json
{
  "method": "PROCESS",
  "path": ["appstore", "access"],
  "policies": { "process": "appstore-access" },
  "queries": { "process": "data.appstore.access.result" }
}
```

The route, method and path parameters are in the input, and the Rego rules
decide on them. This is the shape the three working API families already use.

### 3. One input shape for every access check

Every access check sends this input to Rego, on every transport:

| Field | Value |
| --- | --- |
| `input.method` | The HTTP method in upper case, for example `GET` or `PATCH`. `PROCESS` for a queue message or a plain Lambda invocation. |
| `input.route` | The route from section 1. |
| `input.path` | The concrete path without the base path, for example `/v1/sites/abc/things`. The route name on SQS and plain Lambda. The router redirects a path with `.`, `..` or `//` before any check, but keeps a trailing slash, so a rule that compares exact paths compares the path the handler acts on, not this field. |
| `input.params` | The path parameters by name, for example `{"rsid": "abc"}`. An empty object when there are none. |
| `input.sc` | Who the caller is, described below. |
| `input.<name>` | Facts the handler adds, such as `target_oid`. They cannot replace the five fields above. |

`input.sc` is the same document for access checks, `BeforeEvent`,
`AfterEvent`, `AfterObject` and `pep.Process`. The
builder `pep` uses today becomes the only one, exported as
`pep.BuildSecurityContext`:

| Field | Value |
| --- | --- |
| `input.sc.oidc` | The whole token. Claims sit at the top level of it, so the scope string is `input.sc.oidc.scope` and the remote system is `input.sc.oidc.rsid`. |
| `input.sc.caller_type` | `user`, `app` for a machine client, or `none` when the request carries no token. |
| `input.sc.grant_type`, `sub`, `client_id` | From the token. `grant_type` is `none` when the caller type is `none`. |
| `input.sc.scopes` | The scope string split into a list. |
| `input.sc.groups` | The Cognito groups. |
| `input.sc.oid` | The organisation ids. |
| `input.sc.is_exchange`, `act` | Present when the token's `act` claim was decoded as a structured actor. A delegated token always has the raw claim at `input.sc.oidc.act`, so a rule that asks "is this token delegated" tests that field. |

The three list fields, `scopes`, `groups` and `oid`, are always present, and
empty when the token has none. A missing list would make a rule such as
`not g in input.sc.groups` undefined instead of true, so a caller with no groups
would pass a check meant to refuse them.

`caller_type` is `none` when the token has neither a subject nor a `client_id`
claim. Today such a token is reported as `app`, with the grant type
`client_credentials`, so a queue message with no caller looks like a machine
client and a rule that admits machine clients admits it.
`securitymodel.CallerTypeNone` and the grant type `none` are added for it.

### 4. One shared check: `cbpolicy.CheckAccess`

```go
// package github.com/Thiink-LLC/teos/go-core/tkdisp/cbpolicy
func CheckAccess(ctx ifcore.CbContext, policyPath string, extras map[string]any) error
```

It reads the method, route, path and path parameters from
`ctx.CallContext()`, adds `extras`, and evaluates the `PROCESS` registration at
`policyPath`. It never pushes or pops a call context.

The registration's query must return an object with a boolean `allow` and an
optional `deny` list, as every TEOS access policy already does:

```rego
result := {"allow": allow, "deny": deny}
```

| What happened | Result |
| --- | --- |
| `allow` is `true`, `deny` is empty and the policy asks for no change to a body | `nil`: the request may proceed. |
| `allow` is not `true`, or `deny` is not empty | A `cberror.Error` with status 403. Its message is the `deny` reasons joined with `"; "`, or `access denied` when there are none. The caller sees it as the problem details `detail`. |
| No PDP, no `PROCESS` registration at `policyPath`, a call context with no route or no path, an extra that uses one of the five reserved names, a policy that cannot be evaluated, a query that returns nothing or not an object, a `deny` or obligation of the wrong type, or a policy that asks to change a body | A `cberror.Error` with status 500 that names the problem, logged at error level. These are configuration mistakes, and the first test that calls the route fails with one. None of them panics. The shape of the result is checked before anything else, so a malformed result is never reported as a refusal. |

`CheckAccess` gets the result from the PDP's `Decide`, which reads `deny` and
the obligations before it returns. The PDP therefore converts each of those
values with a checked type conversion and returns an error for a value of the
wrong type, such as `deny: [1]`. Without that, a malformed result would panic
inside the PDP and stop the Lambda invocation before `CheckAccess` could answer
500.

Every access policy declares `default allow := false`, so a request that no
`allow` rule grants is refused with 403. A policy without that line leaves
`allow`, and so `result`, undefined for such a request, and the check answers
500. Either way the request does not reach the handler. An `allow` rule that
names no method and route grants every route of the Lambda, so each `allow`
rule names the method and route it is for.

Policy authors write the `deny` reasons as fixed text, because the caller reads
them. A reason never contains a value from the input or the token.

### 5. HTTP routes are checked by the router: `cbhttp.AccessMux`

```go
// package github.com/Thiink-LLC/teos/go-core/tkdisp/cbhttp
func NewAccessMux(policyPath string, extras func(*http.Request) map[string]any) *AccessMux

func (m *AccessMux) Handle(pattern string, handler http.Handler)
func (m *AccessMux) HandleFunc(pattern string, handler func(http.ResponseWriter, *http.Request))
func (m *AccessMux) ServeHTTP(w http.ResponseWriter, r *http.Request)
```

`AccessMux` is a router that holds an `http.ServeMux`. Every route registered on
it passes the access check before its handler runs. It keeps the `ServeMux`
private, so there is no way to register a route on it without the check. For
each request that matches a route, it:

1. pushes a copy of the current call context with the route and the router's
   path parameters (`r.PathValue` for every `{name}` and `{name...}` in the
   pattern) filled in;
2. calls `extras(r)` when `extras` is not nil, and calls
   `cbpolicy.CheckAccess(ctx, policyPath, thoseExtras)`;
3. on an error, writes the same problem details response the `cbhttp` handler
   wrappers write and does not call the handler;
4. otherwise calls the handler, which can read `ctx.CallContext().GetRoute()`
   and the path parameters;
5. pops the copy when the handler returns, so the call context the adapter
   created, with its headers, is the current one again.

It works with `cbhttp.JSON`, `Handler`, `Action`, `RawHandler`, plain handlers
and servers generated by `oapi-codegen`, which accept it as their `BaseRouter`.

The router answers some requests itself, without running any registered
handler: 404 for a path no pattern matches, 405 for a method no pattern allows,
and a redirect for a path with `.`, `..` or `//`, or for a path that lacks the
final slash of a pattern ending in `/`, `/{$}` or a `{name...}` wildcard. These
answers run no handler and no policy check, and they change nothing. A
redirect's `Location` has no base path, so it does not work through the custom
domain. Handlers therefore register patterns that end in none of `/`, `/{$}`
and `{name...}`, apart from a catch-all `/`.

A route anyone may call, such as `GET /v1/health`, is allowed by the policy
(`allow if { input.method == "GET"; input.route == "/v1/health" }`). A handler
may instead register it on a plain `http.ServeMux` in front of the `AccessMux`,
where it is visibly outside the check.

The `extras` function is for facts that are known before the handler runs but
are not in the path, such as the organisation AppStore resolves from a query
parameter.

**Facts only the handler knows.** Some checks need a value from the request
body, or from a stored object the handler loads. The handler calls
`cbpolicy.CheckAccess(ctx, policyPath, extras)` again with those facts. It does
so before it changes anything or writes any part of the response, and on an
error it returns the zero result together with the error. The `cbhttp` wrappers
and `cblambda` prefer a non-zero result over an error, so a handler that returns
a loaded object with the refusal would answer as if it had been allowed. The
router's check has run first without these facts. A policy keeps the two apart
like this:

```rego
# Who may call the route at all: decided on the router's check.
allow if {
    input.method == "PUT"
    input.route == "/v1/users/{sub}/groups"
    "teos/identity-admin" in input.sc.scopes
}

# A fact the handler adds later: a deny rule that applies only when the fact
# is present.
deny contains "the caller cannot assign a group it is not a member of" if {
    some g in input.target_groups
    not g in input.sc.groups
}
```

### 6. A refusal answers 403

`CheckAccess` returns 403. `cberror.ErrorDispatcherPayloadRejectedByPolicy`, the
code `BeforeEvent`, `AfterEvent` and `AfterObject` return for a refusal, changes
from 400 to 403. `httputil.StatusCodeFromError` passes codes between 100 and 511
through as the HTTP status, so every refusal answers 403 with no conversion in
any service.

### 7. Fail closed by default

- `PolicyConfig` has no optional mode. `BeforeEvent`, `AfterEvent` and
  `AfterObject` always fail when there is no PDP or no registration for their
  operation and path. All three check this before they call the endpoint, and
  do not call it when the check fails. So `AfterEvent` and `AfterObject` also
  fail for an output that would have been empty. Every production caller
  already asks for this behaviour.
- With a registration present, `AfterEvent` and `AfterObject` return an output
  that marshals to an empty JSON object or to `null` without evaluating it.
  `AfterObject` does the same for an empty JSON array.
- When the endpoint returns an error, `AfterEvent` and `AfterObject` return the
  zero output with it. The `cbhttp` wrappers and `cblambda` prefer a non-zero
  result over an error, so a partial output returned with an error would
  otherwise reach the caller unfiltered.
- When `PolicyConfig.Path` is empty, those three use the call context's
  **route**, not its concrete path. Under an `AccessMux` that is the pattern,
  which a registration can name exactly. Outside one, an HTTP call context has
  no route. The middleware then returns an error that says the policy has no
  path. It looks nothing up and does not guess a path.
- `AccessMux` checks every route registered on it, and `CheckAccess` refuses
  unless the policy says `allow`.

### 8. A check never replaces the request's call context

`CheckAccess` only reads the call context. `AccessMux` pushes a copy that keeps
every header, query parameter and context parameter of the original, and pops it
when the handler returns. The services' own pushes of an empty `PROCESS` call
context are deleted.

### 9. Every HTTP method is its own operation

`runtime.DefaultContextFactory` maps a method to the operation of the same name
in upper case: `PATCH`, `HEAD` and `OPTIONS` stop becoming `PROCESS`. Only an
empty method is `PROCESS`. A registration for `PATCH` can then match, and an
HTTP route never shares a key with a `PROCESS` registration.

### 10. Queue messages and plain Lambda invocations

- **Route.** The route name the handler was started with. A queue that carries
  several kinds of message keeps one route, and the handler adds the kind as an
  extra (`map[string]any{"kind": msg.Kind}`). There is no per-message route.
- **Caller token.** SQS has none, and `input.sc.caller_type` is `none`. Two AWS
  IAM permissions decide who can reach the handler: who may send to the queue,
  and who may invoke the function directly. Both stay limited to trusted
  senders, because a direct invocation can carry a payload shaped like an SQS
  batch. A message that acts for a person carries that person's identity in its
  body. The handler adds the facts it trusts as extras, and they are only as
  trustworthy as those senders. A plain Lambda invocation whose payload carries
  a token keeps using `cblambda.WithTokenExtractor`; without one, the caller is
  `none` as well.
- **Check.** The handler calls `cbpolicy.CheckAccess(ctx, policyPath, extras)`
  where it needs one. A function that serves an API and a queue through
  `cblambda.Select` uses one registration for both: the API side is an
  `AccessMux`, the queue side calls `CheckAccess`, and the one Rego file has
  rules for `input.method == "PROCESS"`.
- A refused message is an ordinary handler error. SQS delivers it again until
  the queue's receive limit moves it to the dead-letter queue.
- Records that `cbsqs.WithParallelism` runs at the same time share one policy
  context, and the policy context is not safe for concurrent evaluation. So
  `tkdisp/cbpolicy` holds one lock while it evaluates a policy. The policy
  evaluations that package makes, through `CheckAccess` and the payload
  middleware alike, run one at a time across the package. Other code that
  evaluates policies, in `cbpipeline`, `pubsub/projection` and `cbpolicy/pep`,
  does not take this lock. Parallel records still run their other work at the
  same time. Only their policy evaluations in `tkdisp/cbpolicy` wait for each
  other.

### 11. API Gateway v2

`cbhttp.CognitoContextFactory` keeps reading v1 events only. A v2 handler behind
a JWT authorizer gets no token, so `caller_type` is `none` and any policy that
needs a scope or a claim refuses the call with 403. The failure is visible.
Reading v2 claims is added with the first v2 API. Its claims arrive as a map of
strings with lists flattened into one string, and need their own decoding.

### 12. One way to check access

`AccessMux` and `CheckAccess` are the only access-check code in `tkdisp`:

- `cbhttp` has no other authorization helper;
- `PolicyConfig` has no optional mode;
- the REST API adapter has no option to remove a stage name, because a REST API
  never puts the stage name into the event's `path`.

A service has no access code of its own. It pushes no call context for a policy,
builds no policy input by hand, types no route pattern a second time and
converts no refusal to 403.

`BeforeEvent`, `AfterEvent` and `AfterObject` stay for **payload** policies:
policies that validate or filter a request or response body. They do not add a
method or a route, because access is decided by `CheckAccess`.

## Alternatives considered

**Match path templates in the PDP.** Rejected. It needs a second router inside
the PDP, with its own rules for which of two matching templates wins, that can
disagree with the Go router. It needs one registration per route, about 60 for
AppStore alone, each a place to forget one. The three API families that work
today already use one registration with the route in the input.

**Take the route from API Gateway's `resource` (v1) or `routeKey` (v2).**
Rejected. API Gateway sets them, but a direct invocation or a test event often
does not. They are a second spelling of the route that can disagree with the
pattern the handler registered. AppStore routes through a router nested inside
another, where only the inner pattern names the route.

**Work out the base path from `resource` and `path`.** Rejected. A greedy
`{proxy+}` resource matches any number of segments, so the base path cannot be
found by counting segments. An explicit option is one line per handler and
cannot guess wrong.

**Keep `BeforeEvent` as the access check and add method and route to its
input.** Rejected. Its input is the typed request body, so the added fields can
collide with body fields. It fits only `cbhttp.JSON`. A route that does not
wrap its endpoint is not checked, and nothing reports it.

**Wrap each route by hand, for example `mux.Handle(p, access(h))`.** Rejected.
Forgetting one wrapper leaves a route open, which is the problem this record
exists to remove. `AccessMux` makes the checked registration the only one
available.

**Check the whole router once, outside it, with `ServeMux.Handler(r)`.**
Rejected. That call returns the matched pattern but not the path parameters, so
the check would have to parse the path a second time.

**Keep the optional mode (`Required: false`).** Rejected. No production caller
uses it, and it is the mode in which a misnamed registration lets every request
through.

**Read v2 JWT claims now.** Deferred. No TEOS Lambda uses v2, and its claim
format differs from v1's. Without it a v2 handler refuses callers instead of
admitting them.

## Consequences

**What a person sees.** A refused request answers 403 with the policy's reason
in the problem details. A route registered on an `AccessMux` is checked; there
is no second step to forget. A policy file that does not mention a route refuses
it. A wrong registration name or query fails the first test that calls the
route, with a 500 that names the missing registration.

**Handlers get shorter.** A handler names its policy path once, when it builds
the router, and its routes once, when it registers them. AppStore, IAM, GoBridge,
SUR and tklocal delete their own glue. The client's `X-Correlation-ID` reaches
code after the check.

**Rego files change.** Moving a service onto this design renames its input
fields: the route is `input.route` (not `input.resource` or `input.path`), the
concrete path is `input.path`, path parameters are `input.params.<name>`
(not `target_sub` or `target_rsid`), and the caller is `input.sc.<field>` (not
`caller_sub` or `has_act_claim`). A handler embeds its policy files
(`pdp-config/` and its Rego policies) in its own Lambda binary, next to the code
that builds the policy input, so both always deploy together. The old names are
therefore deleted, not kept beside the new ones.

**One route spelling.** A handler registers `/v1/...` once and passes its base
path to the REST API adapter with `WithBasePath`.

**Checks that need the body run twice.** The router's check runs first, without
the body. A route whose policy needs a body or stored-object fact also needs the
handler's second `CheckAccess` call. A missing second call is not detected by
the framework, so a handler test must cover the refusal for every such fact.

**Queue messages retry when refused.** A refused message is retried until it
reaches the dead-letter queue. A handler that wants to drop it instead logs the
refusal and returns `nil`.

**`cbhttp` depends on `tkdisp/cbpolicy`.** `tkdisp/cbpolicy` does not import
`cbhttp`, so there is no import cycle.

## Verification

The implementation is complete when these tests exist and pass:

- `runtime`: `GET`, a lower-case `post`, `PATCH`, `HEAD` and `OPTIONS` map to
  operations of the same upper-case name; an empty method maps to `PROCESS`;
  `DefaultContextFactory` copies `RequestMeta.RouteName` into the call
  context's route.
- `securitymodel`: a token with no subject and no `client_id` has caller type
  `none` and grant type `none`, and `EnrichSecurityContext` writes both. For a token with no scope,
  no groups and no organisation ids, `scopes`, `groups` and `oid` are present
  and empty.
- `cbpolicy.CheckAccess`, against a real PDP with an embedded Rego file:
  - allowed when `allow` is true;
  - 403 carrying the `deny` reasons when the policy denies;
  - 403 `access denied` when `allow` is false and `deny` is empty;
  - 500 for each configuration mistake: no PDP, no registration, an empty route,
    an empty path, a reserved extra name, a query that is undefined, a result
    that is not an object, a `deny` that is not a list of strings (including an
    object such as `{}`), and a body obligation, with no panic;
  - the documented group rule refuses a caller whose token has no groups;
  - the input holds `method`, `route`, `path`, `params`, the extras and the full
    `sc` document;
  - the current call context is the same object before and after the call.
- `cbsqs` with `WithParallelism` and a handler that calls `CheckAccess` for each
  record, against a real PDP, passes `go test -race`.
- `cbpolicy.BeforeEvent`: with no registration it fails with no option set; with
  an empty `Path` it looks up the call context's route; a refusal written
  through `cbhttp.JSON` answers 403; `input.sc.caller_type` is present.
- `cbpolicy.AfterEvent` and `AfterObject`: with no registration they fail
  without calling the endpoint, also for an endpoint that would return an
  empty map, an empty array or a nil output; when the endpoint returns a
  non-zero output with an error, the caller of `cbhttp.JSON` gets the error, not
  the output.
- `cbhttp.AccessMux`:
  - the route is the pattern without method and host, for patterns with and
    without a method, with a host, with `{name...}` and with `{$}`;
  - path parameters come from the router, and `{$}` is not one;
  - a refused route answers 403 problem details and the handler is not called;
  - a missing registration answers 500;
  - a path that matches no route answers 404 without a policy evaluation;
  - values from `extras` reach the policy;
  - the handler sees the route and the parameters on its call context;
  - after the handler, `X-Correlation-ID` is read from the original call
    context;
  - it is accepted as an `oapi-codegen` `BaseRouter`, and it works with `JSON`,
    `Handler`, `Action` and `RawHandler`.
- `cbhttp.WithBasePath` on `APIGatewayV1`: `/sur/v1/x` routes as `/v1/x`;
  `/v1/x` is unchanged; `/surx/v1/x` is unchanged; `/sur` routes as `/`; the
  call context's path has the base path removed.
- The deleted functions are gone, and `make test` passes for go-core and for
  every service whose call sites changed.
