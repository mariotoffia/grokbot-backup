# ADR-0005: The alarm feature names its organization setting `organization`

| | |
| --- | --- |
| **Status** | Accepted |
| **Date** | 2026-10-13 |

## Summary

The event service has an alarm feature. One of its settings names the
organization that owns the sources the feature monitors. That setting was named
`tenant`, but in TEOS a tenant is something else. This record decides the new
name. Because the app store stores documents that use this name, the change is a
rename of a stored field. ADR-0004 says such a rename needs its own decision
record, and this is that record.

The decision in one paragraph:

> The alarm feature's setting for the organization that owns the monitored
> sources is named `organization`. A runtime scope names its organization in
> `organizationId`. The Lambda functions get the value in the environment
> variable `CB_ORGANIZATION_ID`. No release reads the old names. The app store
> checks stored feature overrides against the feature's schema, so the rename
> also renames a field of a stored document. That is accepted once, because no
> account stores an alarm feature override. No deploy rewrites stored overrides.
> If such an override exists when an account moves across this release, a
> person stores it again with the name that release reads, or deletes it. This
> record allows that one manual step, for this rename only. The names inside
> stored evidence rows keep their stored spelling.

## Terms used

| Term | Meaning here |
| --- | --- |
| Organization | The unit TEOS keeps data apart by. Its ID is the `oid` claim in an access token, for example `skebo` or `default`. The format is one or more segments of lowercase letters and digits, separated by dots. |
| Tenant | A customer account inside a remote system's own software, the `tid` value a provider works with. It is not an organization. |
| Event service | The TEOS service that collects evidence and runs monitors over it. Its section in the provision configuration is `event`. The app store catalog names it `event-service`. |
| Alarm feature | The part of the event service that stores evidence in a DynamoDB table and runs monitors over it. Its settings are the block `services.event.features.alarm`. |
| Evidence | Records the event service collects, for example CloudWatch log lines, stored so that monitors can read them. |
| Provision configuration | The YAML file (`provision-config.yaml`) an account is deployed with. |
| Feature schema | The JSON Schema of one feature's settings. The alarm feature's is `go-services/eventsvc/manifest/features/alarm.schema.json`. |
| App store | The TEOS service that installs and configures services for each organization. Its catalog holds every registered service, including its feature schemas. |
| Feature override | A JSON document the app store stores for one organization, one service and one feature. It holds the complete settings of that feature, in place of the ones the service ships. |
| Runtime scope | One entry of the alarm setting `runtimeScopes`: one stream of evidence, at one location, that a monitor reads. |

## Context

The alarm feature has one setting per deployment that names the organization
that owns the monitored sources.

The setting had three names:

- `tenant` in the provision configuration and in the feature schema;
- `tenantId` on a runtime scope;
- `CB_TENANT_ID` in the environment of the evidence writer and evidence monitor
  Lambda functions.

The value is an organization ID. TEOS uses the word tenant only for the tenant
inside a remote system (see `go-services/appstore/_design/organizations.adoc`
and `UBIQUITOUS.md`). A person who reads `tenant` looks for a remote system's
tenant ID and fills that in. Nothing fails, because the writer and the monitor
get the same value:

- The evidence writer stamps every evidence record with the value
  (`go-services/eventsvc/evidencecollector/internal/adapters/evidence/normalize.go:72`).
- The organization is part of the stored keys: the stream scope and the
  identity row (`go-core/cbevent/evidence/envelopestream/dynamodbstream/writer.go:154`
  and `:165`), and the row that records how far the evidence is complete
  (`go-core/cbevent/evidence/envelopestream/dynamodbstream/watermark_schema.go:57`).
- The monitor reads only evidence stamped with its own value, and skips the
  rest (`go-services/eventsvc/evidencemonitor/internal/adapters/source/reader.go:234`).

So the evidence is stored and kept apart under an ID that is not the
organization that owns it. When someone corrects the value later, the monitor
reads only evidence stamped with the new value. The evidence stored under the
old value is no longer read.

The name appears in four places. Only some of them are stored data:

1. **The provision configuration.** This is a file that the deploy of the same
   release reads. The deploy checks each service block against that release's
   schema, which refuses settings it does not know. It is not stored data.
2. **The Lambda environment.** The same deploy that installs the code sets it.
   It is not stored data.
3. **App store feature overrides.** These are stored, one DynamoDB row per
   override, under the sort key `OVFEATURE#<feature>`. When a release of the
   event service is registered in the app store catalog, its feature schemas
   go into the catalog with it. The app store checks every stored feature
   override of a service against the feature schema in the catalog when it
   installs, updates or reconfigures that service
   (`go-services/appstore/internal/application/catalog_feature_validator.go`,
   called from `applyFeatureOverrides` in `service_lifecycle_helpers.go`). The
   preview of what a baseline change would affect (`GET /v1/baseline/affected`)
   runs the same check for a service the app store installed. It lists such a
   service whose override fails the check with the schema error in place of
   its change summary (`baseline_diff_service.go:212-229`). A service that a
   deploy registered, rather than the app store, is listed as
   "registrar-adopted; not managed by AppStore", with no check
   (`baseline_diff_service.go:201-210`). The app store checks a new override
   the same way before storing it. Reading a stored override runs no check.
   The alarm schema refuses unknown settings (`additionalProperties: false`).
   So after the rename, a stored override that says `tenant` is refused, and
   before it, one that says `organization` would be refused. That is a rename
   of a stored field.
4. **Stored evidence.** The word tenant is part of four stored names. Three of
   them hold the organization ID:
   - the JSON field `tenant_id` in an evidence envelope and in a stored
     rejection;
   - the DynamoDB attribute `identity_tenant` on a stream identity row;
   - the JSON field `tenantId` in a monitor's read position, which is stored
     in checkpoints.

   The fourth is the stored rejection reason `no_tenant`, which is recorded
   when the organization is missing. One release writes these and the next one
   reads them.

These facts show that no account stores an alarm feature override:

- The app store stores a feature override only when that feature is in its
  catalog. Otherwise the write answers 404 and stores nothing
  (`go-services/appstore/handlers/editing-api/server_impl_features.go:130-135`,
  `go-services/appstore/internal/application/catalog_feature_validator.go:144-147`).
  An install that brings feature settings with it stores them through the
  same check.
- Every writer goes through that check. The web app, the operator command
  that pushes an override file (`cbdeploy cloud override push`) and a direct
  call with a token all store through the one route
  `PUT /v1/services/{name}/overrides/features/{feature}`.
- The event service, and with it the alarm feature, enters an app store's
  catalog only when it is deployed to that account or synced to its app store.
- No account file in the repository turns the event service on. The deploy
  command skips a service that its file does not turn on, with a warning,
  unless it is forced on (`--force-enable`).
  - `deployment/provision-config.yaml` turns the event service off and has no
    alarm block.
  - `customers/umea-energi/provision-config.yaml` has no `event` block. It
    also has no `appstore` block. That account's tables were not read.
- The event service's own test deployment forces the service on
  (`svctest.WithForceEnableService()` in
  `go-services/eventsvc/deployment/service-test/main_test.go`). It deploys
  into the account the developer's credentials point at, and registers the
  event service in that account's catalog. So a development account can hold
  the alarm feature in its catalog.
- The development account devlocal02 is the one that was checked. On
  2026-10-13 its app store table held no event service registration and no
  override rows.
- The web app could not store any app store override in the release before
  this one. Its app store client took the organization from a browser store
  that no code filled in, so every app store request stopped in the browser
  with "No tenant selected" before it was sent.

Four files in the repository do configure the alarm feature, and none of them
is an account file:

- the example `deployment/provision-config.example.yaml`;
- the event service's two test deployments,
  `go-services/eventsvc/deployment/service-test/provision-config.yaml` and
  `provision-config.local.yaml`;
- `deployment/lib/tests/unit/testdata/provision-config.example.yaml`, a fixture
  for the deployment library's parsing tests.

## Decision

### 1. The setting is named `organization`

- In the provision configuration and the feature schema, the setting is
  `organization`. It is required when the feature is configured. It must have
  the organization ID format and at most 128 characters.
- On a runtime scope, the field is `organizationId`. A scope without it belongs
  to the feature's organization. Any other value is refused.
- The evidence writer and the evidence monitor get the value in the
  environment variable `CB_ORGANIZATION_ID`.

### 2. The old names are not read

No release reads `tenant`, `tenantId` or `CB_TENANT_ID` as the alarm
organization. A block that names only `tenant` has no organization:

- The deploy's schema check refuses it when the provision file loads, and
  names the unknown setting `tenant`. The deploy stops there.
- The alarm feature's own check refuses it too, with "organization is
  required", wherever a block is parsed without the schema check.

### 3. Stored evidence keeps its stored names

The four stored names `tenant_id`, `identity_tenant`, `tenantId` (in a read
position) and `no_tenant` do not change. ADR-0004 forbids renaming them, and
each adjacent release must keep reading them. The Go fields that hold them are
named for the organization, and a comment on each states the stored name.

### 4. Stored overrides are not rewritten

No deploy renames `tenant` in stored overrides, and no release reads both
names. The rename is accepted because no account stores an alarm feature
override that uses the field.

If an alarm override that names the setting exists when an account moves
across this release, in either direction, the move needs one manual step. A
person stores the override again with the name that release reads, or deletes
it. ADR-0004 does not otherwise allow a manual step. This record allows it for
this rename only, for three reasons:

- no account holds such an override at the upgrade;
- the refusal answers a request for the event service and names the unknown
  setting, so a person can find the override to fix;
- both ways to avoid the step are forbidden: reading both names, and a deploy
  step that rewrites stored overrides (see Alternatives considered).

## Alternatives considered

**Keep `tenant`.** Rejected. It keeps the word tenant for an organization ID,
and TEOS uses tenant only for a remote system's tenant. People would keep
filling in the wrong identifier.

**Add `organization` and keep `tenant` as a second name.** This is the
add-only way that ADR-0004 prefers. Rejected. Two settings would hold the same
value, which is an alias: "the old name still works". The project rules for
stored data forbid aliases. A reader would also need a rule for a block that
sets both names to different values.

**A deploy step that renames `tenant` in stored overrides.** Rejected. It is a
converter, which ADR-0004 forbids. The repair that ADR-0004 allows only adds
missing attributes. A downgrade would also need the opposite step.

**A schema version on each override, with one schema per version.** Rejected
for the reasons ADR-0004 gives. The app store would need every schema version a
stored override may name, and a rule for versions newer than itself.

## Consequences

**What a person sees.**

- An operator writes `organization: <organization ID>` under
  `services.event.features.alarm`. A provision configuration that still says
  `tenant` is refused when the deploy loads it, before anything in the account
  changes. The operator renames the setting in the file and deploys again.
- No account is affected by the stored-override problem today, for the reasons
  listed in Context.
- If an alarm feature override that names `tenant`, or a runtime scope with
  `tenantId`, were stored before an account upgrades, the app store would
  refuse to install, update or reconfigure the event service for that
  organization once the new release is registered. The error says that a
  feature override violates its schema, and names the unknown setting. The
  stored override stays as it was. To fix it, a member of the Cognito group
  `teos-admin` (or `teos-super-admin`) whose token covers that organization
  stores the override again with `organization`. The calls go to the app store
  API under the base path `appstore`, and each needs the OAuth scope
  `teos/teos-app-deployer`:
  1. `GET /v1/services/event-service/overrides/features/alarm?oid=<organization ID>`
     returns the stored override and its version in the `ETag` header.
  2. `PUT` on the same route stores the corrected document. The request sends
     that `ETag` value in the `If-Match` header. Without it the app store
     answers 428.

  The app store names the event service `event-service`, the `name` in its
  manifest, not `event`, its section name in the provision configuration. The
  write checks the override against the new schema. Deleting the override
  with `DELETE` on the same route, which needs no `If-Match`, also ends the
  refusal, because there is then no override to check.
- The same happens on a downgrade across this release. When the previous
  release of the event service is registered again, its schema says `tenant`.
  An alarm override stored with `organization` is then refused at install,
  update and reconfigure in the same way. The fix is the same: store it again
  with the name that release reads, or delete it.
- An alarm override that does not set the organization, such as
  `{"enabled": false}`, matches both schemas and is not affected.

**What this allows.**

- Renaming these three names once: `tenant` to `organization`, `tenantId` on a
  runtime scope to `organizationId`, and `CB_TENANT_ID` to
  `CB_ORGANIZATION_ID`.
- One manual step when an account moves across this release, in either
  direction, while an alarm override that names the setting is stored: store
  the override again with the name that release reads, or delete it. This is
  allowed for this rename only, for the reasons in Decision 4.

**What this forbids.**

- Reading the old names as the alarm organization in any release.
- Renaming the four stored names in evidence rows.
- Renaming a field in any other feature schema that the app store checks
  stored overrides against, without its own decision record. That record must
  show that no account stores the field.

## Verification

These tests cover the decision:

- `go-services/eventsvc/deployment/features/alarm/organization_test.go`:
  - `TestTheFeatureReadsTheOrganizationThatOwnsTheMonitoredSources` - the
    setting is read, and a runtime scope without `organizationId` takes it;
  - `TestTheFeatureRefusesAnOrganizationIDThatBreaksTheFormat` - a value that
    is not an organization ID is refused;
  - `TestTheFeatureRequiresTheOrganization` - a block that leaves the setting
    out, leaves it blank, or names it `tenant` is refused;
  - `TestTheFeatureRefusesARuntimeScopeOfAnotherOrganization`;
  - `TestTheShippedProvisionFilesNameAnOrganization` - the three provision
    files that configure the feature name a valid `organization`: the example
    `deployment/provision-config.example.yaml` and the event service's test
    deployments `service-test/provision-config.yaml` and
    `service-test/provision-config.local.yaml`.
- `go-services/eventsvc/deployment/features/alarm/schema_test.go`:
  - `TestTheSchemaRefusesTheSettingNamedTenant` - the published feature schema
    refuses a block that names the setting `tenant`, and a runtime scope that
    names `tenantId`. The error names the unknown setting. The test uses the
    deploy's schema validator. The app store checks a stored override against
    the same schema file with the same JSON Schema library.
  - `TestTheSchemaRefusesAnOrganizationIDThatBreaksTheFormat` - the schema
    checks the same organization ID format as the parser.
- `go-services/eventsvc/deployment/features/alarm/writer_completeness_test.go`:
  `TestBothLambdasAreToldTheOrganizationThatOwnsTheEvidence` - both Lambda
  functions get `CB_ORGANIZATION_ID` and neither gets `CB_TENANT_ID`.
- The stored evidence names:
  - in `go-core/cbevent/evidence/envelopestream`,
    `TestAnEnvelopeStoredByThePreviousReleaseReads` and
    `TestARejectionStoredByThePreviousReleaseReads` (`tenant_id`);
  - in `go-services/eventsvc/evidencecollector/internal/adapters/evidence`,
    `TestNormalize_MissingIdentityRejects` (`no_tenant`);
  - in `go-core/cbevent/evidence/envelopestream/dynamodbstream`,
    `TestStreamIdentityRowKeepsTheOrganizationUnderItsStoredName`
    (`identity_tenant`, against DynamoDB Local).
- The stored read position, in
  `go-services/eventsvc/evidencemonitor/internal/adapters/source/reader_refusals_test.go`:
  `TestAReadPositionStoredByThePreviousReleaseReads` (`tenantId`).
- How the app store checks a stored override, in
  `go-services/appstore/internal/application`:
  `TestInstallService_RejectsInstallWhenOverrideViolatesSchema` and
  `TestCatalogFeatureValidator_Validate_RejectsSchemaViolation`.
