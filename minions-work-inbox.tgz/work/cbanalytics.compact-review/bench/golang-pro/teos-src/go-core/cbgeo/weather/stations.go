package weather

import (
	"embed"
	"sort"

	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"

	"github.com/mariotoffia/go-geoindex"
)

//go:embed stations.parquet
var StationData embed.FS

// WeatherStation represents the transformed structure of the data.
type WeatherStation struct {
	ID        string  `parquet:"id"`
	Name      string  `parquet:"name"`
	Country   string  `parquet:"country"`
	Region    string  `parquet:"region"`
	Timezone  string  `parquet:"timezone"`
	Latitude  float64 `parquet:"latitude"`
	Longitude float64 `parquet:"longitude"`
}

type WeatherStationsIndexImpl struct {
	// stationIndex is the index that is used to search for points.
	stationIndex *geoindex.ClusteringIndex
	// stations is only stored when _metaQuery_ is `true` to conserve memory.
	stations []WeatherStation
}

type PointWithDistance struct {
	// From is the point the calculated distance was calculated From.
	From *geoindex.GeoPoint `json:"-"`
	// To is the To of where the distance is calculated To.
	To *geoindex.GeoPoint `json:"to"`
	// Distance in meters
	Distance geoindex.Meters `json:"distance"`
}

// WeatherStationWithDistance is `WeatherStation` with a distance.
type WeatherStationWithDistance struct {
	WeatherStation
	Distance geoindex.Meters `json:"distance"`
}

// NewWeatherStations creates a new NewWeatherStationsIndexImpl that can be used to perform queries against.
//
// When _metaQuery_ is `true`, the stations can be queried by other means than k nearest such as city, country, etc.
//
// CAUTION: Do not set this to `true` if you're not querying those, since it will consume *a large amount* of memory*.
func NewWeatherStations(metaQuery bool) *WeatherStationsIndexImpl {
	stations, err := parquetutils.LoadParquetFileFS[WeatherStation](
		fileutils.AferoEmbedded{FS: StationData},
		"stations.parquet",
	)

	if err != nil {
		panic(err)
	}

	wsi := &WeatherStationsIndexImpl{
		stationIndex: createIndex(stations),
	}

	if metaQuery {
		wsi.stations = stations
	}

	return wsi
}

// createIndex will create a single index to use for searching.
func createIndex(stations []WeatherStation) *geoindex.ClusteringIndex {
	index := geoindex.NewClusteringIndex()

	for _, station := range stations {
		// Create a point with latitude and longitude
		point := geoindex.GeoPoint{
			Pid:  station.ID,
			Plat: station.Latitude,
			Plon: station.Longitude,
		}
		// Add the point to the index
		index.Add(&point)
	}

	return index
}

// Query will query using a custom filer. If nothing is set, it will return `nil`.
func (index *WeatherStationsIndexImpl) Query(
	filter func(ws *WeatherStation) bool,
) []WeatherStation {
	//
	if filter == nil {
		return nil
	}

	var stations []WeatherStation

	for i := range index.stations {
		if filter(&index.stations[i]) {
			stations = append(stations, index.stations[i])
		}
	}

	return stations
}

// QueryFromDistance will get all stations from the specified distances. And
// return a distinct result.
//
// NOTE: This is done through checking the ID of the station and not lat, long.
func (index *WeatherStationsIndexImpl) QueryFromDistance(
	distances ...PointWithDistance,
) []WeatherStationWithDistance {
	//
	var (
		res []WeatherStationWithDistance
	)

	for _, dist := range distances {
		for i := range index.stations {
			if index.stations[i].ID == dist.To.Pid {
				res = append(res, WeatherStationWithDistance{
					WeatherStation: index.stations[i],
					Distance:       dist.Distance,
				})

				break
			}
		}

		if len(res) == len(index.stations) {
			break
		}
	}

	return res
}

// KNearest will search for the nearest points to the specified point (within 50m squares).
//
// The _k_ is the number of k nearest points to return within a _maxDistance_.
//
// If no accept function is passed it will return all points.
func (index *WeatherStationsIndexImpl) KNearest(
	point geoindex.Point, k int, maxDistance geoindex.Meters,
	accept ...func(p geoindex.Point) bool,
) []geoindex.Point {
	//
	var acp func(p geoindex.Point) bool

	if len(accept) > 0 {
		acp = accept[0]
	} else {
		acp = func(p geoindex.Point) bool {
			return true
		}
	}

	return index.stationIndex.KNearest(point, k, maxDistance, acp)
}

// SortByDistanceFrom will sort the _res_ by distance to the _from_ in ascending order.
//
// The returning points are sorted by distance to the _from_ point and the distance is included in the
// returning structure.
func (index *WeatherStationsIndexImpl) SortByDistanceFrom(
	from geoindex.Point,
	res []geoindex.Point,
) []PointWithDistance {

	pointsWithDistances := make([]PointWithDistance, len(res))
	fr := from.(*geoindex.GeoPoint)

	for i := range res {
		pointsWithDistances[i] = PointWithDistance{
			From:     fr,
			To:       res[i].(*geoindex.GeoPoint),
			Distance: index.Distance(from, res[i]),
		}
	}

	sort.Slice(pointsWithDistances, func(i, j int) bool {
		return pointsWithDistances[i].Distance < pointsWithDistances[j].Distance
	})

	return pointsWithDistances
}

// Distance will return the distance between _p1_ and _p2_.
func (index *WeatherStationsIndexImpl) Distance(p1, p2 geoindex.Point) geoindex.Meters {
	return geoindex.Distance(p1, p2)
}
