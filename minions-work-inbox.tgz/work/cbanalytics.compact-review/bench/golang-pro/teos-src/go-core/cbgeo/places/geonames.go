package places

import (
	"archive/zip"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil"
)

type GeoNamesFile string

// FeatureClass is a single character depicting the feature class such as `P` for city, village, town...
type FeatureClass string

const (
	// GeoNameFileCities500 where the population is at least 500
	GeoNameFileCities500 GeoNamesFile = "cities500.zip"
	// GeoNameFileCities1000 where the population is at least 1000
	GeoNameFileCities1000 GeoNamesFile = "cities1000.zip"
	// GeoNameFileCities5000 where the population is at least 5000
	GeoNameFileCities5000 GeoNamesFile = "cities5000.zip"

	// FeatureClassPopulatedPlace is a populated place (city, village, town)
	FeatureClassPopulatedPlace FeatureClass = "P"
	// FeatureClassLocality is a locality such as a FeatureClassLocality or a battlefield
	FeatureClassLocality FeatureClass = "L"
)

// cSpell: disable

// GeoNamesGetData downloads cities from the https://download.geonames.org/export/dump/ (only cities) CSV dataset.
//
// The cities dataset is formulated as follows:
//
// Example: 2693152	Malå	Mala		65.18501	18.74243	P	PPLA2	SE		23	2418			2043		324	Europe/Stockholm	2020-10-25
//
// Csv Columns:
// 1. 1234 (geonameid),
// 2. "Malå" (Name),
// 3. "Mala" (asciiname, skip),
// 4. "Mala,..."|"" (alternatenames, skip),
// 5. "65.18501" (Lat),
// 6. "18.74243" (Long),
// 7. "P" (feature class, skip), - http://www.geonames.org/export/codes.html, char(1) - "P" = city, village,...
// 8. "PPLA2" (feature code, skip), - http://www.geonames.org/export/codes.html, varchar(10)
// 9. "SE" (Country), - ISO-3166 2-letter country code, 2 characters
// 10. "" (cc2, skip), - alternate country codes, comma separated, ISO-3166 2-letter country code, 200 characters
// 11. "23" (admin1 code, skip), - fipscode
// 12. "2418" (admin2 code, skip), - code for the second administrative division, a county in the US
// 13. "" (admin3 code, skip), - code for third level administrative division, varchar(20)
// 14. "2043" (admin4 code, skip), - code for fourth level administrative division, varchar(20)
// 15. 324 (population), - bigint (8 byte int)
// 16. "" (elevation in meters (int), skip),
// 17. "" (elevation model, skip),
// 18. "Europe/Stockholm" (timezone, skip),
// 19. "2020-10-25" (modification date, skip),
func GeoNamesGetData(force bool, geofile GeoNamesFile) (string, error) {
	// static temp folder for the actual geofile
	geonames := filepath.Join(os.TempDir(), "geonames")

	if !fileutils.DirectoryExists(geonames) {
		if err := os.MkdirAll(geonames, os.ModePerm); err != nil {
			return "", err
		}
	}

	geofileName := fileutils.FileNameWithoutExtension(string(geofile)) + ".txt"
	file := filepath.Join(geonames, geofileName)

	if !force && fileutils.FileExists(file) {
		return file, nil
	}

	// temp download folder for the zip file
	downloadFolder := fileutils.GetOrCreateTempDir("geonames")

	defer func() { _ = os.RemoveAll(downloadFolder) }()

	zipfile := filepath.Join(downloadFolder, string(geofile))

	ctx, _ := ctx.NewContextWithDefaultOptions("geonames", "cbgeo", cbenv.Prod)

	if err := httputil.DownloadFile(
		ctx,
		zipfile, fmt.Sprintf("https://download.geonames.org/export/dump/%s", geofile), http.StatusOK,
	); err != nil {
		return "", err
	}

	// Decompress the file

	gr, err := zip.OpenReader(zipfile)

	if err != nil {
		return "", err
	}

	defer func() { _ = gr.Close() }()

	for _, f := range gr.File {
		// Clean the file path to prevent directory traversal
		fpath := filepath.Join(downloadFolder, filepath.Clean(f.Name))

		// Ensure the cleaned path is still within the intended directory
		if !strings.HasPrefix(fpath, filepath.Clean(downloadFolder)+string(os.PathSeparator)) {
			return "", fmt.Errorf("invalid file path: %s", fpath)
		}

		if f.FileInfo().IsDir() {
			_ = os.MkdirAll(fpath, os.ModePerm)
			continue
		}

		if err := os.MkdirAll(filepath.Dir(fpath), os.ModePerm); err != nil {
			return "", err
		}

		outFile, err := os.OpenFile(fpath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
		if err != nil {
			return "", err
		}

		rc, err := f.Open()
		if err != nil {
			return "", err
		}

		// Custom io.Copy that respects the size limit
		bytesCopied, err := io.CopyN(outFile, rc, maxSize)

		// Close the file without defer to handle error
		_ = outFile.Close()
		_ = rc.Close()

		if err != nil {
			if !errors.Is(err, io.EOF) {
				return "", err // Handle other errors
			}
		}

		if bytesCopied >= maxSize {
			return "", fmt.Errorf("extracted file size exceeds the limit")
		}

		if f.Name == geofileName {
			_ = os.Rename(fpath, file)
			break
		}
	}

	return file, nil
}

// ReadAllCitiesGeoNamesCSV will read the file and return all places that are of the specified feature classes.
//
// If no _include_ is specified, it will default to `FeatureClassPopulatedPlace`. The second return is a logg
// of what was skipped. The third return is an error if something went wrong.
func ReadAllCitiesGeoNamesCSV(file string, include ...FeatureClass) ([]Place, string, error) {
	if len(include) == 0 {
		include = []FeatureClass{FeatureClassPopulatedPlace}
	}

	f, err := os.Open(file)

	if err != nil {
		return nil, "", err
	}

	defer func() { _ = f.Close() }()

	places := make([]Place, 0)

	r := csv.NewReader(f)
	r.Comma = '\t' // tab separated

	buff := strings.Builder{}

	for {
		record, err := r.Read()

		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}

			id := "unknown"

			if len(record) > 0 {
				id = record[0]
			}

			fmt.Fprintf(&buff, "Skipping record id: '%s' since error: %s\n", id, err.Error()) //nolint:gosec // G705: writes to bytes.Buffer, not HTTP response

			continue
		}

		fc := FeatureClass(record[6][0])

		if !slices.Contains(include, fc) {
			fmt.Fprintf(&buff, "Skipping record '%s', class: %v\n", record[1], fc) //nolint:gosec // G705: writes to bytes.Buffer, not HTTP response

			continue
		}

		place := Place{
			Name:       record[1 /*Name*/], // ascii name record[2]
			Lat:        utils.ConvertToFloat64(record[4], -999 /*invalid*/),
			Long:       utils.ConvertToFloat64(record[5], -999 /*invalid*/),
			ShortCode:  countryCodes[record[8]],
			Population: int(utils.ConvertToInt64(record[14], -1 /*invalid*/)),
		}

		if place.Lat == -999 || place.Long == -999 {
			fmt.Fprintf(&buff, "Skipping record '%s', invalid lat/long\n", record[1]) //nolint:gosec // G705: writes to bytes.Buffer, not HTTP response

			continue
		}

		places = append(places, place)
	}

	return places, buff.String(), nil
}
