package geoservices_test

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	geoutils "github.com/Thiink-LLC/teos/go-core/cbgeo/geoservices"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// newCtx creates a new context with the specified log level for testing.
func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	c, err := ctx.NewContext(
		"test-svc", "test", cbenv.DevLocal,
		true /*sort*/, ctx.OptAWSConfigLoadDefault(),
	)
	require.NoError(tb, err)
	tb.Cleanup(c.Close)

	return c
}

// TestUseDefaultGeocoder asks a geocoding service on the internet to turn a
// pair of coordinates into a street address.
//
// The service is a paid third party, not part of TEOS and not part of AWS, so
// the test only runs when the two settings that name it are already in the
// environment: CB_DEFAULT_GEOCODER picks the service and
// CB_DEFAULT_GEOCODERAPI_KEY is the key to call it with.
func TestUseDefaultGeocoder(t *testing.T) {
	geocoder := cbenv.CB_DEFAULT_GEOCODER.String("")

	if geocoder == "" || cbenv.CB_DEFAULT_GEOCODERAPI_KEY.String("") == "" {
		t.Skip(
			"set CB_DEFAULT_GEOCODER and CB_DEFAULT_GEOCODERAPI_KEY to run this test against a " +
				"geocoding service",
		)
	}

	testenv.Use(t, testenv.EnvDefaults)

	// The default settings name a geocoding service of their own, and the key
	// in the environment belongs to the one the caller chose.
	t.Setenv(string(cbenv.CB_DEFAULT_GEOCODER), geocoder)

	ctx := newCtx(t)

	addr, err := geoutils.DefaultReverseLookup(ctx, 55.60387537258482, 12.997614182846538)

	assert.NoError(t, err)
	require.NotNil(t, addr)

	fmt.Println(string(jsonutils.ToJSONPretty(addr)))
}
