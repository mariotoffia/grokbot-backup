package places

import "github.com/mariotoffia/go-geoindex"

type Place struct {
	Name       string      `parquet:"name"`
	Lat        float64     `parquet:"lat"`
	Long       float64     `parquet:"long"`
	ShortCode  CountryCode `parquet:"int_16"`
	Population int         `parquet:"int32"`
}

type PointWithDistance struct {
	// From is the point the calculated distance was calculated From.
	From *geoindex.GeoPoint `json:"-"`
	// To is the To of where the distance is calculated To.
	To *geoindex.GeoPoint `json:"to"`
	// Distance in meters
	Distance geoindex.Meters `json:"distance"`
}

// WeatherStationWithDistance is `WeatherStation` with a distance.
type PlaceWithDistance struct {
	Place
	Distance geoindex.Meters `json:"distance"`
}
