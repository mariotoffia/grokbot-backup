package places

import (
	"embed"
	"sort"
	"sync"

	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"

	"github.com/mariotoffia/go-geoindex"
)

//go:embed places.parquet
var PlacesData embed.FS

type PlacesIndexImpl struct {
	// placeIndex is the index that is used to search for points.
	placeIndex *geoindex.PointsIndex
	// places is only stored when _metaQuery_ is `true` to conserve memory.
	places []Place
	// mtx is a mutex to protect the places slice.
	mtx *sync.RWMutex
}

// NewPlaces creates a new NewPlacesIndexImpl that can be used to perform queries against.
//
// When _metaQuery_ is `true`, the places can be queried by other means than k nearest such as name, region and country.
//
// CAUTION: Do not set this to `true` if you're not querying those, since it will consume *a large amount* of memory*.
//
// This will spawn a go routine to load the places in the background. The returned instance is safe to invoke due to the
// mutex protection.
func NewPlaces(metaQuery bool) *PlacesIndexImpl {
	wsi := &PlacesIndexImpl{mtx: &sync.RWMutex{}}

	wsi.mtx.Lock()

	go func(wsi *PlacesIndexImpl) {
		defer wsi.mtx.Unlock()

		places, err := parquetutils.LoadParquetFileFS[Place](
			fileutils.AferoEmbedded{FS: PlacesData},
			"places.parquet",
		)

		if err != nil {
			panic(err)
		}

		wsi.placeIndex = createIndex(places)

		if metaQuery {
			wsi.places = places
		}
	}(wsi)

	return wsi
}

// createIndex will create a single index to use for searching.
func createIndex(places []Place) *geoindex.PointsIndex {
	index := geoindex.NewPointsIndex(geoindex.Km(0.5))

	for _, place := range places {
		// Create a point with latitude and longitude
		point := geoindex.GeoPoint{
			Pid:  place.Name,
			Plat: place.Lat,
			Plon: place.Long,
		}
		// Add the point to the index
		index.Add(&point)
	}

	return index
}

// Query will query using a custom filer. If nothing is set, it will return `nil`.
func (index *PlacesIndexImpl) Query(
	filter func(ws *Place) bool,
) []Place {
	//
	index.mtx.RLock()
	defer index.mtx.RUnlock()

	if filter == nil {
		return nil
	}

	var stations []Place

	for i := range index.places {
		if filter(&index.places[i]) {
			stations = append(stations, index.places[i])
		}
	}

	return stations
}

// GetMeta will get all place metadata from the specified distances (points). And
// return a distinct result.
//
// NOTE: This is done through matching the _Name_ of the place and match that to the
// _To.Pid_ of the _distances_.
//
// The returned slice, will be in the same order as the _distances_ but all duplicates
// will be removed.
func (index *PlacesIndexImpl) GetMeta(
	distances ...PointWithDistance,
) []PlaceWithDistance {
	//
	index.mtx.RLock()
	defer index.mtx.RUnlock()

	var (
		res []PlaceWithDistance
	)

	for _, dist := range distances {
		for i := range index.places {
			if index.places[i].Name == dist.To.Pid {
				res = append(res, PlaceWithDistance{
					Place:    index.places[i],
					Distance: dist.Distance,
				})

				break
			}
		}

		if len(res) == len(index.places) {
			break
		}
	}

	return res
}

// Range will return all points within the bounding box of the _topLeft_ and _bottomRight_.
//
// In order to get the distance within the box use `SortByDistanceFrom` on the result.
func (index *PlacesIndexImpl) Range(
	topLeft geoindex.Point,
	bottomRight geoindex.Point,
) []geoindex.Point {
	return index.placeIndex.Range(topLeft, bottomRight)
}

// KNearest will search for the nearest points to the specified point (within 50m squares).
//
// The _k_ is the number of k nearest points to return within a _maxDistance_.
//
// If no accept function is passed it will return all points.
func (index *PlacesIndexImpl) KNearest(
	point geoindex.Point, k int, maxDistance geoindex.Meters,
	accept ...func(p geoindex.Point) bool,
) []geoindex.Point {
	//
	index.mtx.RLock()
	defer index.mtx.RUnlock()

	var acp func(p geoindex.Point) bool

	if len(accept) > 0 {
		acp = accept[0]
	} else {
		acp = func(p geoindex.Point) bool {
			return true
		}
	}

	return index.placeIndex.KNearest(point, k, maxDistance, acp)
}

// SortByDistanceFrom will sort the _res_ by distance to the _from_ in ascending order.
//
// The returning points are sorted by distance to the _from_ point and the distance is included in the
// returning structure.
func (index *PlacesIndexImpl) SortByDistanceFrom(
	from geoindex.Point,
	res []geoindex.Point,
) []PointWithDistance {
	//
	pointsWithDistances := make([]PointWithDistance, len(res))
	fr := from.(*geoindex.GeoPoint)

	for i := range res {
		pointsWithDistances[i] = PointWithDistance{
			From:     fr,
			To:       res[i].(*geoindex.GeoPoint),
			Distance: Distance(from, res[i]),
		}
	}

	sort.Slice(pointsWithDistances, func(i, j int) bool {
		return pointsWithDistances[i].Distance < pointsWithDistances[j].Distance
	})

	return pointsWithDistances
}

// Distance will return the distance between _p1_ and _p2_.
func (index *PlacesIndexImpl) Distance(p1, p2 geoindex.Point) geoindex.Meters {
	return Distance(p1, p2)
}
