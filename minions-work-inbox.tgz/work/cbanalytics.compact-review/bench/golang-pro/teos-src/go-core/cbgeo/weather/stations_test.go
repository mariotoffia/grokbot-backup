package weather_test

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbgeo/weather"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils"

	"github.com/mariotoffia/go-geoindex"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestListAllStationsInSweden(t *testing.T) {
	idx := weather.NewWeatherStations(true /*metaQuery*/)

	var stations []weather.WeatherStation

	elapsed := testutils.Clock(func() {
		stations = idx.Query(func(ws *weather.WeatherStation) bool {
			return ws.Country == "SE"
		})
	})

	assert.True(t, len(stations) > 0)

	fmt.Println("Query took", elapsed) // Around 100µs on my machine
	fmt.Println(len(stations))
}

// cSpell: disable

func TestGetNearestStationInVarutrask(t *testing.T) {
	idx := weather.NewWeatherStations(true /*metaQuery*/)

	var (
		positions []weather.PointWithDistance
		from      = &geoindex.GeoPoint{
			Plat: 64.81405223411952, Plon: 20.711390578723933,
		}
	)

	elapsed := testutils.Clock(func() {
		positions = idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))
	})

	fmt.Println("Query took", elapsed) // Around 20ms on my machine

	dist := idx.QueryFromDistance(positions...)
	require.True(t, len(dist) > 0)
	assert.Equal(t, "Skelleftea Airport", dist[0].Name)
	/*
		for _, ws := range dist {
			fmt.Printf("%s: %f\n", ws.Name, ws.Distance)
		}
	*/
}

func TestGetNearestStationInNorsjo(t *testing.T) {
	idx := weather.NewWeatherStations(true /*metaQuery*/)

	var (
		positions []weather.PointWithDistance
		from      = &geoindex.GeoPoint{
			Plat: 64.9132104997094, Plon: 19.483414232384007,
		}
	)

	elapsed := testutils.Clock(func() {
		positions = idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))
	})

	fmt.Println("Query took", elapsed)

	dist := idx.QueryFromDistance(positions...)
	require.True(t, len(dist) > 0)
	assert.Equal(t, "Norsjoe Finnäs", dist[0].Name)
}

func TestGetNearestStationInMala(t *testing.T) {
	idx := weather.NewWeatherStations(true /*metaQuery*/)

	var (
		positions []weather.PointWithDistance
		from      = &geoindex.GeoPoint{
			Plat: 65.1852980235202, Plon: 18.748393418534878,
		}
	)

	elapsed := testutils.Clock(func() {
		positions = idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))
	})

	fmt.Println("Query took", elapsed)

	dist := idx.QueryFromDistance(positions...)
	require.True(t, len(dist) > 0)
	assert.Equal(t, "Malaa-Braennan Släppträsk", dist[0].Name)
}

func TestGetNearestStationInRumania(t *testing.T) {
	idx := weather.NewWeatherStations(true /*metaQuery*/)

	var (
		positions []weather.PointWithDistance
		from      = &geoindex.GeoPoint{
			Plat: 45.034181289816566, Plon: 25.877761598742048,
		}
	)

	elapsed := testutils.Clock(func() {
		positions = idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))
	})

	fmt.Println("Query took", elapsed)

	dist := idx.QueryFromDistance(positions...)
	require.True(t, len(dist) > 0)

	assert.Equal(t, "Ploiesti", dist[0].Name)
}
