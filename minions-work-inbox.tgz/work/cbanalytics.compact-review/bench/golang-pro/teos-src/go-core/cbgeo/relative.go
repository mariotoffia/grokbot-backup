package cbgeo

import (
	"math"
	"math/rand"
	"time"
)

// Earth's radius in meters
const EarthRadiusMeters = 6371000

// RandomPositionWithinRadius generates a random position within a given radius of a given position.
func RandomPositionWithinRadius(lat, long, radiusMeters float64) (float64, float64) {
	if radiusMeters == 0 {
		return lat, long
	}

	// Seed the random number generator
	rand.New(rand.NewSource(time.Now().UnixNano())) // nolint:gosec

	// Generate random distance within the radius
	randomDistance := rand.Float64() * radiusMeters // nolint:gosec

	// Generate random bearing
	randomBearing := rand.Float64() * 360 // nolint:gosec

	// Calculate delta latitude and delta longitude
	deltaLat, deltaLong := distanceAndBearingToDeltaLatLong(
		randomDistance,
		randomBearing,
		lat,
		long,
	)

	// Apply deltas to original position
	newLat := lat + deltaLat
	newLong := long + deltaLong

	// Ensure new position is within bounds
	newLat = float64(math.Max(math.Min(float64(newLat), 90), -90))
	newLong = float64(math.Mod(float64(newLong)+180, 360) - 180)

	return newLat, newLong
}

func distanceAndBearingToDeltaLatLong(
	distance, bearing, lat, long float64,
) (deltaLat, deltaLong float64) {
	// Convert distance to radians
	distanceRadians := distance / EarthRadiusMeters

	// Convert latitude and longitude to radians
	latRadians := lat * math.Pi / 180
	longRadians := long * math.Pi / 180 // Corrected: Convert longitude to radians

	// Convert bearing to radians
	bearingRadians := bearing * math.Pi / 180

	// Calculate new latitude in radians
	newLatRadians := math.Asin(math.Sin(latRadians)*math.Cos(distanceRadians) +
		math.Cos(latRadians)*math.Sin(distanceRadians)*math.Cos(bearingRadians))

	// Corrected calculation for new longitude in radians
	newLongRadians := longRadians + math.Atan2(
		math.Sin(bearingRadians)*math.Sin(distanceRadians)*math.Cos(latRadians),
		math.Cos(distanceRadians)-math.Sin(latRadians)*math.Sin(newLatRadians),
	)

	// Convert delta lat and delta long from radians to degrees
	deltaLat = (newLatRadians - latRadians) * 180 / math.Pi
	deltaLong = (newLongRadians - longRadians) * 180 / math.Pi

	return deltaLat, deltaLong
}
