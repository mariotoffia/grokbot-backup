package main

import (
	"flag"
	"os"

	"github.com/Thiink-LLC/teos/go-core/cbgeo/weather"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"

	"github.com/spf13/afero"
)

// When changes, re-generate this and check-in the stations.parquet file.

//go:generate go run stations.go
func main() {
	var (
		force bool
		out   string
	)

	flagSet := flag.NewFlagSet("stations", flag.ExitOnError)

	flagSet.BoolVar(&force, "force", false, "Force download.")
	flagSet.StringVar(&out, "out", "", "Output file.")

	_ = flagSet.Parse(os.Args[1:])

	raw, err := weather.MeteostatGetData(force)

	if err != nil {
		panic(err)
	}

	if out == "" {
		out = "../stations.parquet"
	}

	if fileutils.FileExists(out) {
		_ = os.Remove(out)
	}

	err = parquetutils.WriteJSONAsParquetToFileFS[weather.WeatherStation](
		afero.NewOsFs(),
		weather.MeteostatWeatherStationConverter,
		raw,
		out,
	)

	if err != nil {
		panic(err)
	}

}
