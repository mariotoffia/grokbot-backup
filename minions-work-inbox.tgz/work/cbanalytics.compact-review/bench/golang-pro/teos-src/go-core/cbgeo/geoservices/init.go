package geoservices

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/mariotoffia/geo-golang"
	"github.com/rs/zerolog"
)

var logCtx ifcore.CbContext

func init() {
	geo.Log = GeoLogger(0)
	geo.DefaultTimeout = 30 * time.Second

	logCtx, _ = ctx.NewContext("logger", "logger", cbenv.DevLocal, false /*sort*/)
}

// GeoLogger is a logger that logs into _TEOS_ logging system.
type GeoLogger int

var _ geo.Logger = GeoLogger(0)

func (GeoLogger) Log(ctx context.Context, level zerolog.Level, msg string, args ...any) {
	var lCtx ifcore.CbContext

	if cbCtx, ok := ctx.(ifcore.CbContext); ok {
		lCtx = cbCtx
	} else {
		lCtx = logCtx
	}

	if log.IsEnabled(level) {
		// Check if any of the arguments are json?
		l := log.Level(lCtx, level, "" /*lid*/)

		for i, arg := range args {
			if jsonutils.IsJsonPrefixOrStruct(arg) {
				name := fmt.Sprintf("arg%d", i)

				if s, ok := arg.(string); ok {
					l.AsJSON(name, strings.ReplaceAll(s, "\n", ""))
				} else {
					l.AsJSON(name, arg)
				}

				args[i] = fmt.Sprintf("Check %s", name)
			}
		}

		l.Msgf(msg, args...)
	}
}

func (g GeoLogger) Debug(ctx context.Context, msg string, args ...any) {
	g.Log(ctx, zerolog.DebugLevel, msg, args...)
}

func (g GeoLogger) Info(ctx context.Context, msg string, args ...any) {
	g.Log(ctx, zerolog.InfoLevel, msg, args...)
}

func (g GeoLogger) Error(ctx context.Context, msg string, args ...any) {
	g.Log(ctx, zerolog.ErrorLevel, msg, args...)
}
