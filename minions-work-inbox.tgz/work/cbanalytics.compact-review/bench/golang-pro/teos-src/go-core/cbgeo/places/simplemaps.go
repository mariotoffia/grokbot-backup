package places

import (
	"archive/zip"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil"
)

const maxSize = 800 * 1024 * 1024 // 800 MB

// SimpleMapsGetData downloads cities from the https://simplemaps.com/data/world-cities CSV dataset.
//
// The free dataset is formulated as follows:
// 1. "Östersund" (Name),
// 2. "Ostersund"(skip),
// 3. "63.1792" (Lat),
// 4. "14.6358"(Long),
// 5. "Sweden" (Country),
// 6. "SE" (ShortCode),
// 7. "SWE"(skip),
// 8. "Jämtland" (region),
// 9. "admin" (skip),
// 10. "49806" (population),
// 11. "1752026711" (Id)
func SimpleMapsGetData(force bool) (string, error) {
	simplemaps := filepath.Join(os.TempDir(), "simplemaps")

	if !fileutils.DirectoryExists(simplemaps) {
		if err := os.MkdirAll(simplemaps, os.ModePerm); err != nil {
			return "", err
		}
	}

	file := filepath.Join(simplemaps, "worldcities.csv")

	if !force && fileutils.FileExists(file) {
		return file, nil
	}

	dir := fileutils.GetOrCreateTempDir("simplemaps")

	defer func() { _ = os.RemoveAll(dir) }()

	zipfile := filepath.Join(dir, "full.csv.zip")

	ctx, _ := ctx.NewContextWithDefaultOptions("places", "cbgeo", cbenv.Prod)

	if err := httputil.DownloadFile(
		ctx,
		zipfile, "https://simplemaps.com/static/data/world-cities/basic/simplemaps_worldcities_basicv1.76.zip", http.StatusOK,
	); err != nil {
		return "", err
	}

	// Decompress the file

	gr, err := zip.OpenReader(zipfile)

	if err != nil {
		return "", err
	}

	defer func() { _ = gr.Close() }()

	for _, f := range gr.File {
		// Clean the file path to prevent directory traversal
		fpath := filepath.Join(dir, filepath.Clean(f.Name))

		// Ensure the cleaned path is still within the intended directory
		if !strings.HasPrefix(fpath, filepath.Clean(dir)+string(os.PathSeparator)) {
			return "", fmt.Errorf("invalid file path: %s", fpath)
		}

		if f.FileInfo().IsDir() {
			_ = os.MkdirAll(fpath, os.ModePerm)
			continue
		}

		if err := os.MkdirAll(filepath.Dir(fpath), os.ModePerm); err != nil {
			return "", err
		}

		outFile, err := os.OpenFile(fpath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
		if err != nil {
			return "", err
		}

		rc, err := f.Open()
		if err != nil {
			return "", err
		}

		// Custom io.Copy that respects the size limit
		bytesCopied, err := io.CopyN(outFile, rc, maxSize)

		// Close the file without defer to handle error
		_ = outFile.Close()
		_ = rc.Close()

		if err != nil {
			if !errors.Is(err, io.EOF) {
				return "", err // Handle other errors
			}
		}

		if bytesCopied >= maxSize {
			return "", fmt.Errorf("extracted file size exceeds the limit")
		}

		if f.Name == "worldcities.csv" {
			_ = os.Rename(fpath, file)
			break
		}
	}

	return file, nil
}

func ReadAllCitiesSimpleMapCSV(file string) ([]Place, error) {
	f, err := os.Open(file)

	if err != nil {
		return nil, err
	}

	defer func() { _ = f.Close() }()

	places := make([]Place, 0)

	r := csv.NewReader(f)

	// Skip header
	_, err = r.Read()

	if err != nil {
		return nil, err
	}

	for {
		record, err := r.Read()

		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}

			continue
		}

		place := Place{
			Name:       record[0],
			Lat:        utils.ConvertToFloat64(record[2], -999 /*invalid*/),
			Long:       utils.ConvertToFloat64(record[3], -999 /*invalid*/),
			ShortCode:  countryCodes[record[5]],
			Population: int(utils.ConvertToInt64(record[9], -1 /*invalid*/)),
		}

		if place.Lat == -999 || place.Long == -999 {
			continue
		}

		places = append(places, place)
	}

	return places, nil
}
