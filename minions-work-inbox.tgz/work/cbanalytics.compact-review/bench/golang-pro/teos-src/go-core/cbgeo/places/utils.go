package places

import (
	"math"

	"github.com/mariotoffia/go-geoindex"
)

var (
	EarthRadius = geoindex.Km(6371.0)
)

func Distance(p1, p2 geoindex.Point) geoindex.Meters {
	//
	dLat := ToRadians(p2.Lat() - p1.Lat())
	dLng := ToRadians(p2.Lon() - p1.Lon())
	sindLat := math.Sin(dLat / 2)
	sindLng := math.Sin(dLng / 2)

	a := math.Pow( //nolint:staticcheck // QF1005: current form is more readable
		sindLat,
		2,
	) + math.Pow( //nolint:staticcheck // QF1005: current form is more readable
		sindLng,
		2,
	)*math.Cos(
		ToRadians(p1.Lat()),
	)*math.Cos(
		ToRadians(p2.Lat()),
	)

	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))
	dist := float64(EarthRadius) * c

	return geoindex.Meters(dist)
}

func ToRadians(x float64) float64 {
	return x * math.Pi / 180.0
}

// NearestWithLargestPopulation will check which in  _places_, _withinDistance_ by checking the `Population` and `Distance` field
// in `PlaceWithDistance` and return the one with the largest population.7
//
// This is useful, when a query returns multiple places and you want to find the one with the largest population within a certain
// range (that may be shorter than the initial query).
func NearestWithLargestPopulation(
	places []PlaceWithDistance,
	withinDistance geoindex.Meters,
) *PlaceWithDistance {
	//
	var (
		nearest *PlaceWithDistance
	)

	for _, p := range places {
		if p.Distance < withinDistance {
			if nearest == nil || p.Population > nearest.Population {
				nearest = &p
			}
		}
	}

	return nearest
}
