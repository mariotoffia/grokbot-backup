package geoservices

import (
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"

	"github.com/zsefvlol/timezonemapper"
)

// LatLongToIanaTz wil try to translate the lat/long to an IANA timezone.
func LatLongToIanaTz(ctx ifcore.CbContext, lat, long float64) (string, cberror.Error) {
	tz := timezonemapper.LatLngToTimezoneString(lat, long)

	if tz == "" {
		return "", cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusInternalServerError, nil,
			"No timezone found for lat,long (%f,%f)", lat, long)
	}

	return tz, nil
}
