package geoservices

import (
	"context"
	"fmt"
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"

	"github.com/mariotoffia/geo-golang"
	"github.com/mariotoffia/geo-golang/arcgis"
	"github.com/mariotoffia/geo-golang/baidu"
	"github.com/mariotoffia/geo-golang/bing"
	"github.com/mariotoffia/geo-golang/frenchapigouv"
	"github.com/mariotoffia/geo-golang/geocod"
	"github.com/mariotoffia/geo-golang/google"
	"github.com/mariotoffia/geo-golang/here"
	"github.com/mariotoffia/geo-golang/locationiq"
	"github.com/mariotoffia/geo-golang/mapbox"
	"github.com/mariotoffia/geo-golang/mapquest/nominatim"
	"github.com/mariotoffia/geo-golang/mapquest/open"
	"github.com/mariotoffia/geo-golang/mapzen"
	"github.com/mariotoffia/geo-golang/opencage"
	"github.com/mariotoffia/geo-golang/pickpoint"
	"github.com/mariotoffia/geo-golang/tomtom"
	"github.com/mariotoffia/geo-golang/yandex"
)

// GeoCoderType specifies which geocoder to use when doing
// lookups.
type GeoCoderType string

// cSpell:disable

const (
	// GeocoderNull is a null geocoder that always returns
	// an `nil` result or an error (based on it's configuration).
	GeocoderNull GeoCoderType = "null"
	// GeocoderGoogle uses the Google Geocoding API.
	GeocoderGoogle GeoCoderType = "google"
	// GeocoderMapquestNominatim uses the Mapquest Nominatim API.
	GeocoderMapquestNominatim GeoCoderType = "mapquest-nominatim"
	// GeocoderMapquestOpen uses the Mapquest Open API.
	GeocoderMapquestOpen GeoCoderType = "mapquest-open"
	// GeocoderOpenCage uses the OpenCage Data API.
	GeocoderOpenCage GeoCoderType = "opencage"
	// GeocoderHere uses the HERE Geocoder API.
	GeocoderHere GeoCoderType = "here"
	// GeocoderBing uses the Bing Geocoding API.
	GeocoderBing GeoCoderType = "bing"
	// GeocoderBaidu uses the Baidu Geocoding API.
	GeocoderBaidu GeoCoderType = "baidu"
	// GeocoderMapbox uses the Mapbox API.
	GeocoderMapbox GeoCoderType = "mapbox"
	// GeocoderOpenStreetMap uses the OpenStreetMap API.
	GeocoderOpenStreetMap GeoCoderType = "openstreetmap"
	// GeocoderPickPoint uses the PickPoint API.
	GeocoderPickPoint GeoCoderType = "pickpoint"
	// GeocoderLocationIQ uses the LocationIQ API.
	GeocoderLocationIQ GeoCoderType = "locationiq"
	// GeocoderArcGIS uses the ArcGIS API.
	GeocoderArcGIS GeoCoderType = "arcgis"
	// GeocoderGeocodio uses the geocod.io API.
	GeocoderGeocodio GeoCoderType = "geocodio"
	// GeocoderMapzen uses the Mapzen API.
	GeocoderMapzen GeoCoderType = "mapzen"
	// GeocoderTomTom uses the TomTom API.
	GeocoderTomTom GeoCoderType = "tomtom"
	// GeocoderYandex uses the Yandex API.
	GeocoderYandex GeoCoderType = "yandex"
	// GeocoderFrenchAPIGouv uses the FrenchAPIGouv API.
	GeocoderFrenchAPIGouv GeoCoderType = "frenchapigouv"
)

// GetGeocoder is a factor method that returns a geocoder
// based on the type passed in.
//
// The _apiKey_ parameter is the API key for the geocoder
// being used.
//
// If fails to resolve, it returns a NullGeocoder that returns
// error upon lookup.
func GetGeocoder(gc GeoCoderType, apiKey string) geo.Geocoder {
	switch gc {
	case GeocoderGoogle:
		return google.Geocoder(apiKey)
	case GeocoderMapquestNominatim:
		return nominatim.Geocoder(apiKey)
	case GeocoderMapquestOpen:
		return open.Geocoder(apiKey)
	case GeocoderOpenCage:
		return opencage.Geocoder(apiKey)
	case GeocoderHere:
		return here.Geocoder(apiKey, "", 50 /*radius*/)
	case GeocoderBing:
		return bing.Geocoder(apiKey)
	case GeocoderBaidu:
		return baidu.Geocoder(apiKey, "en", "bd09ll")
	case GeocoderMapbox:
		return mapbox.Geocoder(apiKey)
	case GeocoderOpenStreetMap:
		return nominatim.Geocoder(apiKey)
	case GeocoderPickPoint:
		return pickpoint.Geocoder(apiKey)
	case GeocoderLocationIQ:
		return locationiq.Geocoder(apiKey, 18 /*zoom*/)
	case GeocoderArcGIS:
		return arcgis.Geocoder(apiKey)
	case GeocoderGeocodio:
		return geocod.Geocoder(apiKey)
	case GeocoderMapzen:
		return mapzen.Geocoder(apiKey)
	case GeocoderTomTom:
		return tomtom.Geocoder(apiKey)
	case GeocoderYandex:
		return yandex.Geocoder(apiKey)
	case GeocoderFrenchAPIGouv:
		return frenchapigouv.Geocoder()
	}

	return &NullGeocoder{}
}

// GetDefaultGecoder will return the default geocoder based
// on `cbenv.CB_DEFAULT_GEOCODER` environment variable.
//
// `cbenv.CB_DEFAULT_GEOCODERAPI_KEY` to use as the API key.
func GetDefaultGecoder(ctx ifcore.CbContext) (geo.Geocoder, cberror.Error) {
	gct := GeoCoderType(cbenv.CB_DEFAULT_GEOCODER.String("null"))
	apiKey := cbenv.CB_DEFAULT_GEOCODERAPI_KEY.String("")

	if gct != GeocoderNull && apiKey == "" {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError, nil,
			"API key for default geocoder is not set",
		)
	}

	return GetGeocoder(gct, apiKey), nil
}

// DefaultLookup will use the `GetDefaultGecoder` to do a `Lookup`.
func DefaultLookup(
	ctx ifcore.CbContext,
	address AddressInfo,
) (*geo.Location, cberror.Error) {
	if gct, err := GetDefaultGecoder(ctx); err != nil {
		return nil, err
	} else {
		return Lookup(ctx, gct, address)
	}
}

// Lookup will use the `GetDefaultGecoder` to do a lookup based on the _address_.
func Lookup(
	ctx ifcore.CbContext,
	gc geo.Geocoder,
	address AddressInfo,
) (*geo.Location, cberror.Error) {
	retries := 3

	addr := address.String()

	for {
		if loc, err := gc.Geocode(ctx, addr); err != nil {
			if retries == 0 {
				return nil, cberror.NewCbErrorf(
					ctx.Service(), http.StatusInternalServerError, err,
					"Failed to lookup address: '%s'", err.Error(),
				)
			}
		} else if loc != nil {
			return loc, nil
		} else {
			return nil, cberror.NewCbErrorf(
				ctx.Service(), http.StatusInternalServerError, nil,
				"Failed to lookup address: '%s' needs to be manually translated",
				addr,
			)
		}

		retries--
	}
}

// DefaultReverseLookup will use the `GetDefaultGecoder` to
// do a reverse lookup.
func DefaultReverseLookup(
	ctx ifcore.CbContext,
	lat, long float64) (*geo.Address, cberror.Error) {
	if gct, err := GetDefaultGecoder(ctx); err != nil {
		return nil, err
	} else {
		return ReverseLookup(ctx, gct, lat, long)
	}
}

// ReverseLookup will do a reverse lookup using the geocoder
// passed in.
func ReverseLookup(
	ctx ifcore.CbContext,
	gc geo.Geocoder,
	lat, long float64) (*geo.Address, cberror.Error) {
	//
	retries := 3

	for {
		if addr, err := gc.ReverseGeocode(ctx, lat, long); err != nil {
			if retries == 0 {
				return nil, cberror.NewCbErrorf(
					ctx.Service(), http.StatusInternalServerError, err,
					"Failed to reverse lookup address",
				)
			}
		} else if addr != nil {
			return addr, nil
		} else {
			return nil, cberror.NewCbErrorf(
				ctx.Service(), http.StatusInternalServerError, nil,
				"Failed to reverse lookup address coordinates (%f, %f) needs to be manually translated",
				lat, long,
			)
		}

		retries--
	}
}

// NullGeocoder is a geocoder that always returns an error or empty result.
type NullGeocoder struct {
	ReturnEmptyResult bool
}

var _ geo.Geocoder = (*NullGeocoder)(nil)

func (gc *NullGeocoder) Geocode(ctx context.Context, address string) (*geo.Location, error) {
	if !gc.ReturnEmptyResult {
		return nil, fmt.Errorf("NullGeocoder always returns an error")
	}

	return nil, nil
}

func (gc *NullGeocoder) ReverseGeocode(
	ctx context.Context,
	lat, lng float64,
) (*geo.Address, error) {
	if !gc.ReturnEmptyResult {
		return nil, fmt.Errorf("NullGeocoder always returns an error")
	}

	return nil, nil
}
