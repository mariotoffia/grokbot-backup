package places_test

import (
	"fmt"
	"sort"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbgeo/places"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils"

	"github.com/mariotoffia/go-geoindex"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

func TestLoadParquetPerformance(t *testing.T) {
	var (
		pls []places.Place
		err error
	)

	elapsed := testutils.Clock(func() {
		pls, err = parquetutils.LoadParquetFileFS[places.Place](
			fileutils.AferoEmbedded{FS: places.PlacesData},
			"places.parquet",
		)
	})

	require.NoError(t, err)
	assert.True(t, len(pls) > 200000)

	fmt.Println("Load took", elapsed) // Around 115ms on my machine
	fmt.Println(len(pls))
}

func TestListAllPlacesInSweden(t *testing.T) {
	idx := places.NewPlaces(true /*metaQuery*/)

	var (
		pls []places.Place
		sc  = places.CountryCodeFromString("SE")
	)

	elapsed := testutils.Clock(func() {
		pls = idx.Query(func(ws *places.Place) bool {
			return ws.ShortCode == sc
		})
	})

	require.True(t, len(pls) > 1300)

	fmt.Println("Query took", elapsed) // Around 700µs on my machine

	// Sort by population
	sort.Slice(pls, func(i, j int) bool {
		return pls[i].Population > pls[j].Population
	})

	// Print the top 10
	for _, p := range pls[:10] {
		fmt.Printf("%s - %d\n", p.Name, p.Population)
	}
}

func TestGetNearestTownsInRumania(t *testing.T) {
	idx := places.NewPlaces(true /*metaQuery*/)

	var (
		positions []places.PointWithDistance
		from      = &geoindex.GeoPoint{
			Plat: 45.034181289816566, Plon: 25.877761598742048,
		}
	)

	elapsed := testutils.Clock(func() {
		positions = idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))
	})

	fmt.Println("Query took", elapsed)

	dist := idx.GetMeta(positions...)
	require.True(t, len(dist) > 0)

	assert.Equal(t, "Liliești", dist[0].Name)
	assert.Equal(t, "Dâmbu", dist[1].Name)
	assert.Equal(t, "Băicoi", dist[2].Name)
}

func TestGetNearestTownsWithLargestPopulationFromLilesti(t *testing.T) {
	idx := places.NewPlaces(true /*metaQuery*/)

	var (
		place *places.PlaceWithDistance
		from  = &geoindex.GeoPoint{
			Plat: 45.034181289816566, Plon: 25.877761598742048,
		}
	)

	elapsed := testutils.Clock(func() {
		dist := idx.GetMeta(
			idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))...)

		place = places.NearestWithLargestPopulation(
			dist,
			geoindex.Km(10), /*try with shorter than query*/
		)
	})

	fmt.Println("Query took", elapsed)

	assert.Equal(t, "Băicoi", place.Name)
}

func TestGetNearestTownsFromMala(t *testing.T) {
	idx := places.NewPlaces(true /*metaQuery*/)

	var (
		positions []places.PointWithDistance
		from      = &geoindex.GeoPoint{
			Plat: 65.1852980235202, Plon: 18.748393418534878,
		}
	)

	elapsed := testutils.Clock(func() {
		positions = idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))
	})

	fmt.Println("query took: ", elapsed)

	dist := idx.GetMeta(positions...)
	require.True(t, len(dist) > 3)
	assert.Equal(t, "Malå", dist[0].Name)
	assert.Equal(t, "Norsjö", dist[1].Name)
	assert.Equal(t, "Arvidsjaur", dist[2].Name)

	place := places.NearestWithLargestPopulation(
		dist,
		geoindex.Km(50),
	)

	assert.Equal(t, "Arvidsjaur", place.Name)
}

func TestGetNearestLargerTownFromMyckle(t *testing.T) {
	idx := places.NewPlaces(true /*metaQuery*/)

	from := &geoindex.GeoPoint{
		Plat: 64.73975339688145, Plon: 20.73336817386889,
	}

	positions := idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(100)))

	place := places.NearestWithLargestPopulation(
		idx.GetMeta(positions...),
		geoindex.Km(20),
	)

	assert.Equal(t, "Skellefteå", place.Name)
}

func TestGetNearestLargerTownFromTallboda(t *testing.T) {
	idx := places.NewPlaces(true /*metaQuery*/)

	from := &geoindex.GeoPoint{
		///58.42927220201568, 15.684417836324178
		Plat: 58.42927220201568, Plon: 15.684417836324178,
	}

	positions := idx.SortByDistanceFrom(from, idx.KNearest(from, 1000, geoindex.Km(20)))
	dir := idx.GetMeta(positions...)
	place := places.NearestWithLargestPopulation(dir, geoindex.Km(20))

	assert.Equal(t, "Tallboda", dir[0].Name)
	assert.Equal(t, "Linköping", place.Name)
}
