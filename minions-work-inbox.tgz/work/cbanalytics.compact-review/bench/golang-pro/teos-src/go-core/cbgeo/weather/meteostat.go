package weather

import (
	"compress/gzip"
	"io"
	"net/http"
	"os"
	"path/filepath"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil"
)

// MeteostatWeatherStationConverter converts the raw JSON data to the WeatherStation structure.
//
// This is fo JSON downloaded from: https://dev.meteostat.net/bulk/stations.html#endpoints
// e.g. https://bulk.meteostat.net/v2/stations/full.json.gz.
//
// Their OSS Project is hosted at: https://github.com/meteostat
func MeteostatWeatherStationConverter(data map[string]any) *WeatherStation {
	ws := &WeatherStation{
		ID:       utils.ExtractStringFromMap("id", data, ""),
		Country:  utils.ExtractStringFromMap("country", data, ""),
		Region:   utils.ExtractStringFromMap("region", data, ""),
		Timezone: utils.ExtractStringFromMap("timezone", data, ""),
	}

	// Extract the name - prefer English
	if name, ok := data["name"]; ok {
		if name, ok := name.(map[string]any); ok {
			if _, ok := name["en"]; ok {
				ws.Name = utils.ExtractStringFromMap("en", name, "")
			} else if len(name) > 0 {
				for k := range name {
					ws.Name = utils.ExtractStringFromMap(k, name, "")
					break
				}
			}
		}
	}

	if location, ok := data["location"]; ok {
		if location, ok := location.(map[string]any); ok {
			ws.Latitude = utils.ExtractFloat64FromMap("latitude", location, 999 /*illegal*/)
			ws.Longitude = utils.ExtractFloat64FromMap("longitude", location, 999 /*illegal*/)
		}
	}

	return ws
}

// MeteostatGetData will load the data from the Meteostat API and store it in a temp
// folder and return the path to the file.
//
// If _force_ is set to `false`, it will check if the file is already downloaded and
// return the path to the file.
func MeteostatGetData(force bool) (string, error) {
	meteostat := filepath.Join(os.TempDir(), "meteostat")

	if !fileutils.DirectoryExists(meteostat) {
		if err := os.MkdirAll(meteostat, os.ModePerm); err != nil {
			return "", err
		}
	}

	file := filepath.Join(meteostat, "full.json")

	if !force && fileutils.FileExists(file) {
		return file, nil
	}

	dir := fileutils.GetOrCreateTempDir("meteostat")

	defer func() { _ = os.RemoveAll(dir) }()

	gzfile := filepath.Join(dir, "full.json.gz")

	ctx, _ := ctx.NewContextWithDefaultOptions("meteostat", "cbgeo", cbenv.Prod)

	if err := httputil.DownloadFile(
		ctx,
		gzfile, "https://bulk.meteostat.net/v2/stations/full.json.gz", http.StatusOK,
	); err != nil {
		return "", err
	}

	// Decompress the file

	in, err := os.Open(gzfile)

	if err != nil {
		return "", err
	}

	defer func() { _ = in.Close() }()

	gr, err := gzip.NewReader(in)

	if err != nil {
		return "", err
	}

	defer func() { _ = gr.Close() }()

	out, err := os.Create(file)

	if err != nil {
		return "", err
	}

	defer func() { _ = out.Close() }()

	if _, err := io.Copy(out, gr); err != nil { //nolint:gosec // G110 - trusted weather data source
		return "", err
	}

	return file, nil
}
