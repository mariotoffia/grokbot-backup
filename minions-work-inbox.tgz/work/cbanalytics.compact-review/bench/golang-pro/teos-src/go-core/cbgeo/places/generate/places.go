package main

import (
	"flag"
	"os"

	"github.com/Thiink-LLC/teos/go-core/cbgeo/places"
)

// When changes, re-generate this and check-in the places.parquet file.

// https://www.geoapify.com/data-share/localities/ (complement with this??)

//go:generate go run places.go
func main() {
	var (
		force bool
		out   string
	)

	flagSet := flag.NewFlagSet("places", flag.ExitOnError)

	flagSet.BoolVar(&force, "force", false, "Force download.")
	flagSet.StringVar(&out, "out", "../places.parquet", "Output file.")

	_ = flagSet.Parse(os.Args[1:])

	err := places.GeneratePlaces(out, force)

	if err != nil {
		panic(err)
	}
}
