package places_test

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbgeo/places"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDownloadAndGenerateGeoNamePlaces(t *testing.T) {
	t.Skip("TestDownloadAndGenerateGeoNamePlaces: Manual test only!")

	path, err := places.GeoNamesGetData(false /*force*/, places.GeoNameFileCities500)
	require.NoError(t, err)
	require.NotEmpty(t, path)

	places, log, err := places.ReadAllCitiesGeoNamesCSV(path, places.FeatureClassPopulatedPlace)
	require.NoError(t, err)
	fmt.Println(log)

	require.NotEmpty(t, places)
	assert.True(t, len(places) > 200000)
}

func TestDownloadAndGenerateSimpleMapsPlaces(t *testing.T) {
	t.Skip("TestDownloadAndGenerateSimpleMapsPlaces: Manual test only!")

	path, err := places.SimpleMapsGetData(false /*force*/)
	require.NoError(t, err)
	require.NotEmpty(t, path)

	places, err := places.ReadAllCitiesSimpleMapCSV(path)
	require.NoError(t, err)

	require.NotEmpty(t, places)
	assert.True(t, len(places) > 44600)
}

func TestGenerateNewParquetFile(t *testing.T) {
	t.Skip("TestGenerateNewParquetFile: Manual test only!")

	err := places.GeneratePlaces("places.parquet", false /*force*/)
	require.NoError(t, err)
}
