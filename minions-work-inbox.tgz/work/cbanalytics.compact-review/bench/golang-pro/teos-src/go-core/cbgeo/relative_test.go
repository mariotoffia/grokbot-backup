package cbgeo_test

import (
	"math"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbgeo"
)

func distanceBetweenPoints(lat1, lon1, lat2, lon2 float64) float64 {
	// Haversine formula to calculate distance between two points on the Earth
	rad := math.Pi / 180

	h := math.Sin(float64(lat2-lat1)*rad/2)*math.Sin(float64(lat2-lat1)*rad/2) +
		math.Cos(float64(lat1)*rad)*math.Cos(float64(lat2)*rad)*
			math.Sin(float64(lon2-lon1)*rad/2)*math.Sin(float64(lon2-lon1)*rad/2)

	return float64(2 * math.Atan2(math.Sqrt(h), math.Sqrt(1-h)) * cbgeo.EarthRadiusMeters)
}

func TestRandomPositionWithinRadius(t *testing.T) {
	lat := 64.7565372
	long := 20.8941459

	// Test with a radius of 1000 meters
	radiusMeters := 1000.0
	newLat, newLong := cbgeo.RandomPositionWithinRadius(lat, long, radiusMeters)

	// Check if the position is within the specified radius (this check is approximate due to Earth's curvature)
	distance := distanceBetweenPoints(lat, long, newLat, newLong)
	if distance > radiusMeters {
		t.Errorf(
			"Generated position is not within the specified radius. Distance: %v, Radius: %v",
			distance,
			radiusMeters,
		)
	}
}

func TestRandomPositionWithinRadiusBounds(t *testing.T) {
	lat, long := float64(0), float64(0) // Equator and Prime Meridian
	radiusMeters := float64(10000)      // 10 km

	for i := 0; i < 100; i++ {
		newLat, newLong := cbgeo.RandomPositionWithinRadius(lat, long, radiusMeters)

		if newLat < -90 || newLat > 90 {
			t.Errorf("Latitude out of bounds: %v", newLat)
		}

		if newLong < -180 || newLong > 180 {
			t.Errorf("Longitude out of bounds: %v", newLong)
		}

		// Check if the position is within the specified radius (this check is approximate due to Earth's curvature)
		distance := distanceBetweenPoints(lat, long, newLat, newLong)

		if distance > radiusMeters {
			t.Errorf(
				"Generated position is not within the specified radius. Distance: %v, Radius: %v",
				distance,
				radiusMeters,
			)
		}
	}
}

func TestRandomPositionWithinRadiusZeroRadius(t *testing.T) {
	lat, long := float64(50), float64(14) // A point in Prague, Czech Republic
	radiusMeters := float64(0)
	newLat, newLong := cbgeo.RandomPositionWithinRadius(lat, long, radiusMeters)

	if lat != newLat || long != newLong {
		t.Errorf(
			"Expected the same position for zero radius. Got: %v, %v; Want: %v, %v",
			newLat,
			newLong,
			lat,
			long,
		)
	}
}

// Add more tests as necessary
