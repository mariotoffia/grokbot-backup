package geoservices

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// Address is used to geocode a address into long and lat.
type AddressInfo struct {
	Street  string `json:"street"`
	Postal  string `json:"postal"`
	City    string `json:"city"`
	Country string `json:"country"`
	State   string `json:"state,omitempty"`
}

// Returns a string on the following format: Street, Postal, City, Country
func (info *AddressInfo) String() string {
	return fmt.Sprintf("%s, %s, %s, %s", info.Street, info.Postal, info.City, info.Country)
}

// Parse will parse a string on format: Street, Postal, City, Country
func Parse(ctx ifcore.CbContext, address string) (*AddressInfo, cberror.Error) {
	components := strings.Split(address, ",")

	if len(components) < 4 {
		return nil, cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusBadRequest,
			nil,
			"invalid address format, need Street, Postal, City, Country",
		)
	}

	for i := range components {
		components[i] = strings.TrimSpace(components[i])

		if components[i] == "" || components[i] == "nil" || components[i] == "null" ||
			components[i] == "N/A" ||
			components[i] == "<nil>" {
			return nil, cberror.NewCbErrorf(
				ctx.Service(), http.StatusBadRequest, nil,
				"invalid address format, need Street, Postal, City, Country, got: %s", address,
			)
		}
	}

	return &AddressInfo{
		Street:  strings.TrimSpace(components[0]),
		Postal:  strings.TrimSpace(components[1]),
		City:    strings.TrimSpace(components[2]),
		Country: strings.TrimSpace(components[3]),
	}, nil
}
