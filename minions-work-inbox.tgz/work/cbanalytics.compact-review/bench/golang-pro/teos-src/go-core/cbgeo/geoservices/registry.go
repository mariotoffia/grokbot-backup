package geoservices

import (
	"net/http"
	"sync"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"

	"github.com/spf13/afero"
)

// AddressLocation is a location that matches a certain address.
type AddressLocation struct {
	// ID is the address as in `AddressInfo.String()`.
	ID string `parquet:"id"`
	// Latitude is the latitude of the location.
	Latitude float64 `parquet:"lat"`
	// Longitude is the longitude of the location.
	Longitude float64 `parquet:"long"`
	// ClusteredLatitude is the optional clustered latitude of the location.
	ClusteredLatitude float64 `parquet:"clat"`
	// ClusteredLongitude is the optional clustered longitude of the location.
	ClusteredLongitude float64 `parquet:"clong"`
	// IsRelative is `true` if the location is relative to the address and not an absolute location.
	//
	// The radius is typically _1km_, and was randomly chosen using the `cbgeo.RandomLocation` function.
	IsRelative bool `parquet:"is_relative"`
}

// GeoRegistry is a local registry for geo data that can be cached into
// a file as a database.
type GeoRegistry struct {
	// filePath is the file used to load and save the registry.
	filePath string
	// fs the file system used to load and save the registry.
	fs afero.Fs
	// cache is the loaded cache of addresses.
	cache map[string]*AddressLocation
	// rwLock is the lock used to protect the cache.
	rwLock *sync.RWMutex
}

func NewGeoRegistry(fs afero.Fs, filePath string) (*GeoRegistry, error) {
	if !fileutils.FileExistsAfero(fs, filePath) {
		return &GeoRegistry{
			filePath: filePath,
			fs:       fs,
			cache:    map[string]*AddressLocation{},
			rwLock:   &sync.RWMutex{},
		}, nil
	}

	locations, err := parquetutils.LoadParquetFileFS[AddressLocation](fs, filePath)

	if err != nil {
		return nil, err
	}

	cache := map[string]*AddressLocation{}

	for _, loc := range locations {
		loc := loc
		cache[loc.ID] = &loc
	}

	return &GeoRegistry{
		filePath: filePath,
		fs:       fs,
		cache:    cache,
		rwLock:   &sync.RWMutex{},
	}, nil
}

// GetLocation returns the location of the address.
//
// It will return the location and `true` if it exists, otherwise `false`.
func (r *GeoRegistry) GetLocation(address AddressInfo) (*AddressLocation, bool) {
	addr := address.String()

	r.rwLock.RLock()
	defer r.rwLock.RUnlock()

	if loc, ok := r.cache[addr]; ok {
		return loc, true
	} else {
		return nil, false
	}
}

// CacheLocation caches the location of the address.
//
// If _save_ is set to `true`, it will persist the cache to the directly.
func (r *GeoRegistry) CacheLocation(
	ctx ifcore.CbContext,
	address AddressInfo,
	location AddressLocation,
	save bool,
) cberror.Error {
	addr := address.String()

	r.rwLock.Lock()
	defer r.rwLock.Unlock()

	location.ID = addr
	r.cache[addr] = &location

	if save {
		// Save the cache to the file.
		return r.save(ctx)
	}

	return nil
}

// Save saves the registry to the file.
func (r *GeoRegistry) Save(ctx ifcore.CbContext) cberror.Error {
	return r.save(ctx)
}

func (r *GeoRegistry) save(ctx ifcore.CbContext) cberror.Error {
	locations := make([]AddressLocation, len(r.cache))

	i := 0

	for _, loc := range r.cache {
		locations[i] = *loc

		i++
	}

	if err := parquetutils.WriteParquetFileFS(r.fs, r.filePath, locations); err != nil {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError,
			err, "failed to save cache: %s", err.Error(),
		)
	}

	return nil
}
