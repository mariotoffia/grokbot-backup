package weather_test

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbgeo/weather"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestLoadParquetFile(t *testing.T) {
	//
	elapsed := testutils.Clock(func() {
		stations, err := parquetutils.LoadParquetFileFS[weather.WeatherStation](
			fileutils.AferoEmbedded{FS: weather.StationData},
			"stations.parquet",
		)
		require.NoError(t, err)
		assert.True(t, len(stations) > 0)
	})

	fmt.Printf("Parquet file loaded in %s\n", elapsed) // around 30ms on my machine
}
