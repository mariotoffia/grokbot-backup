package places

import (
	"fmt"
	"os"

	"github.com/spf13/afero"

	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
	"github.com/Thiink-LLC/teos/go-core/utils/parquetutils"
)

// GeneratePlaces generates a parquet file with all the cities from the simplemaps dataset.
//
// The _outFile_ is the output file where the parquet file will be written including the filename.
//
// _force_ is a flag to force download the dataset again instead of using local cache.
func GeneratePlaces(outFile string, force bool) error {
	if outFile == "" {
		return fmt.Errorf("outFile is required")
	}

	smfile, err := SimpleMapsGetData(force)

	if err != nil {
		return err
	}

	gnfile, err := GeoNamesGetData(force, GeoNameFileCities500)

	if err != nil {
		return err
	}

	if fileutils.FileExists(outFile) {
		_ = os.Remove(outFile)
	}

	places, err := ReadAllCitiesSimpleMapCSV(smfile)

	if err != nil {
		return err
	}

	places2, _, err := ReadAllCitiesGeoNamesCSV(gnfile, FeatureClassPopulatedPlace)

	if err != nil {
		return err
	}

	m := map[string]string{}

	for _, p := range places {
		m[p.Name] = p.Name
	}

	// Merge the two datasets, prefer the simplemaps dataset.
	overlapped := 0

	for _, p2 := range places2 {
		if _, ok := m[p2.Name]; !ok {
			places = append(places, p2)
		} else {
			overlapped++ // Note we may have duplicates in dataset an hence this counter may not be accurate.
		}
	}

	return parquetutils.WriteParquetFileFS(afero.NewOsFs(), outFile, places)
}
