package logger

import (
	"sync"
	"testing"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/utils/ctxutils"
)

// TestResolveLogger_ConcurrentAccess exercises ResolveLogger and
// SetGlobalLogLevel from multiple goroutines simultaneously. Under
// `go test -race` this will fail if any logmap access is unsynchronized.
func TestResolveLogger_ConcurrentAccess(t *testing.T) {
	ctx := ctxutils.NewNullContext("test", "test", cbenv.DevLocal)

	// Seed the map so the fast path is exercised.
	_ = ResolveLogger(ctx, LISUnclassified)

	var wg sync.WaitGroup

	for i := 0; i < 8; i++ {
		wg.Add(2)

		go func() {
			defer wg.Done()
			for j := 0; j < 200; j++ {
				_ = ResolveLogger(ctx, LISUnclassified)
			}
		}()

		go func() {
			defer wg.Done()
			for j := 0; j < 200; j++ {
				SetGlobalLogLevel(zerolog.InfoLevel)
			}
		}()
	}

	wg.Wait()
}

// TestResolveLogger_ConcurrentMultipleLIS verifies that concurrent
// first-access for different LIS values (slow path) is race-free.
func TestResolveLogger_ConcurrentMultipleLIS(t *testing.T) {
	// Reset logmap so all LIS values hit the slow path.
	s.Lock()
	saved := logmap
	logmap = map[LogInfoSensitivity]*logMapItem{}
	s.Unlock()

	defer func() {
		s.Lock()
		logmap = saved
		s.Unlock()
	}()

	ctx := ctxutils.NewNullContext("test", "test", cbenv.DevLocal)
	allLIS := []LogInfoSensitivity{LISUnclassified, LISPII, LISClassified, LISPolicyControlled}

	var wg sync.WaitGroup
	for _, lis := range allLIS {
		wg.Add(1)
		go func(l LogInfoSensitivity) {
			defer wg.Done()
			_ = ResolveLogger(ctx, l)
		}(lis)
	}

	wg.Wait()

	// All four should have been created.
	s.RLock()
	defer s.RUnlock()
	for _, lis := range allLIS {
		if _, ok := logmap[lis]; !ok {
			t.Errorf("expected logmap entry for %q", lis)
		}
	}
}

// TestResolveLogger_NilContextIsNotCached resolves a logger with a nil
// context before any logger exists. It must return a logger, and it must not
// store it: a later call with a real context then builds the logger that
// context configures.
func TestResolveLogger_NilContextIsNotCached(t *testing.T) {
	s.Lock()
	saved := logmap
	logmap = map[LogInfoSensitivity]*logMapItem{}
	s.Unlock()

	defer func() {
		s.Lock()
		logmap = saved
		s.Unlock()
	}()

	if ResolveLogger(nil, LISUnclassified) == nil {
		t.Fatal("expected a logger for a nil context")
	}

	s.RLock()
	defer s.RUnlock()

	if _, ok := logmap[LISUnclassified]; ok {
		t.Error("a logger resolved with a nil context must not be stored")
	}
}
