package logger

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
)

// LogGroup handles log groups
type LogGroup map[LogInfoSensitivity]string

// This is populated from the CB_LOG_SECURITY_GROUPS environment variable.
var loggroup LogGroup

// findFromGroup will search the group and return all the log-info sensitivity
func (lg LogGroup) findFromGroup(group string) []LogInfoSensitivity {
	var sensitivity []LogInfoSensitivity

	for lis, grp := range lg {
		if grp == group {
			sensitivity = append(sensitivity, lis)
		}
	}

	return sensitivity
}

// newFromEnvironment translate a string group=lis,lis,... where groups are space separated.
// into a map `LogInfoSensitivity` to group. This is extracted from _CB_LOG_SECURITY_GROUPS_
// environment variable.
//
// If the _CB_LOG_SECURITY_GROUPS_ is malformed, it will *panic*.
func (lg LogGroup) NewFromEnvironment() LogGroup {
	grp, err := cbenv.CB_LOG_SECURITY_GROUPS.SplitMapArray(" ", ",")

	if err != nil {
		panic(
			fmt.Sprintf("the CB_LOG_SECURITY_GROUPS is malformed: %s", err.Error()),
		)
	}

	res := LogGroup{}

	for group, v := range grp {
		for _, lis := range v {
			res[LogInfoSensitivity(lis)] = group
		}
	}

	loggroup = res
	return loggroup
}
