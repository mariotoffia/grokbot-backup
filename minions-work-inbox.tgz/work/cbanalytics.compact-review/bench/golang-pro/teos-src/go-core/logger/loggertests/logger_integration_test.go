//go:build integration

package loggertests

import (
	"fmt"
	"os"
	"testing"
	"time"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrlog"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrlog/clwlog"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

func TestLogStringJSON(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestLogStringJSON in short mode")
	}

	t.Skip("clutters the test output")

	s := `{ "state": { "desired": { "sensors": {"OFFODT":2.72} } }, "clientToken": "climatecontrol:627b499c-1e9b-11eb-8afd-c22cea361f16:cc-evt:outbound" }`

	lg := zerolog.New(os.Stderr).With().Timestamp().Logger()

	logger.LogObjectf(lg.Info(), "body", s, "test-logging JSON string")

}

func TestLogByteArrayJSON(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestLogByteArrayJSON in short mode")
	}

	t.Skip("clutters the test output")

	s := []byte(
		`{ "state": { "desired": { "sensors": {"OFFODT":2.72} } }, "clientToken": "climatecontrol:627b499c-1e9b-11eb-8afd-c22cea361f16:cc-evt:outbound" }`,
	)

	lg := zerolog.New(os.Stderr).With().Timestamp().Logger()

	logger.LogObjectf(lg.Info(), "body", s, "test-logging JSON string")

}

func TestParseSecurityGroupValidSingleGroup(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestParseSecurityGroupValidSingleGroup in short mode")
	}

	defer cbenv.CB_LOG_SECURITY_GROUPS.UnSet()

	_, err := cbenv.CB_LOG_SECURITY_GROUPS.SetString(
		fmt.Sprintf("classified_log=%s,%s", logger.LISPII, logger.LISClassified),
	)
	require.NoError(t, err)

	loggroup := logger.LogGroup{}.NewFromEnvironment()

	assert.Equal(t, 2, len(loggroup))
	assert.Equal(t, "classified_log", loggroup[logger.LISPII])
	assert.Equal(t, "classified_log", loggroup[logger.LISClassified])
}

func TestClsLoggerWithOneSecurityGroup(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestClsLoggerWithOneSecurityGroup in short mode")
	}

	lg := utils.RandomPostfix("test")

	_, err := cbenv.CB_LOG_SECURITY_GROUPS.SetString(
		fmt.Sprintf("%s=%s,%s", lg, logger.LISPII, logger.LISClassified),
	)
	require.NoError(t, err)

	// Since init will already run before setting _CB_LOG_SECURITY_GROUPS_
	logger.LogGroup{}.NewFromEnvironment()

	c, err := ctx.NewContextWithDefaultOptions(
		"test", "test", cbenv.DevLocal,
		clwlog.OptCloudWatchBackingLog(),
	)

	clw := c.LogInfo().BackingLogger.(*mgrlog.LogManager)

	streamName := time.Now().Format("2006-01-02")

	defer func() {
		logger.Close(c) // Flushes the loggers.

		clw.ClearError().
			DeleteLogStream(c, lg, streamName).
			ClearError().
			DeleteLogGroup(c, lg)

		cbenv.CB_LOG_SECURITY_GROUPS.UnSet()
	}()

	require.Equal(t, nil, err)

	clw.CreateLogGroup(
		c, lg, "", coremodel.Tag{Name: "purpose", Value: "unit-test"},
	)

	require.Equal(t, nil, clw.Error())

	l, _ := logger.ClsLog(
		zerolog.DebugLevel,
		"test",
		logger.LDTContainsSecrets,
		logger.LISClassified,
		c,
	)

	l.Msgf("hello world")

	logger.FlushLogMap(c)
}
