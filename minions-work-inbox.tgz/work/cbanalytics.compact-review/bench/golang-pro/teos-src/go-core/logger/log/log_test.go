package log_test

import (
	"bytes"
	"encoding/json"
	"testing"

	"github.com/rs/zerolog"
	zlog "github.com/rs/zerolog/log"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/logger/log"
)

func TestParseOverrideString(t *testing.T) {
	m := log.ParseLogLevelOverrides("Måssmyren 18=info:warn,lid2=debug:info")

	assert.Len(t, m, 2)
	require.Contains(t, m, "Måssmyren 18")
	assert.Equal(t, zerolog.InfoLevel, m["Måssmyren 18"].From)
	assert.Equal(t, zerolog.WarnLevel, m["Måssmyren 18"].To)
	require.Contains(t, m, "lid2")
	assert.Equal(t, zerolog.DebugLevel, m["lid2"].From)
	assert.Equal(t, zerolog.InfoLevel, m["lid2"].To)

	m2 := log.ParseLogLevelOverrides("Vesslegatan 4 (stangastaden)=trace:info")
	assert.Len(t, m2, 1)
	require.Contains(t, m2, "Vesslegatan 4 (stangastaden)")
	assert.Equal(t, zerolog.TraceLevel, m2["Vesslegatan 4 (stangastaden)"].From)
	assert.Equal(t, zerolog.InfoLevel, m2["Vesslegatan 4 (stangastaden)"].To)
}

// TestNilContextLogsWithoutContextFields logs at every level with a nil
// context. Each event must be written with its message and location ID, and
// without the service field that only a context can supply.
//
// No logger exists yet in this test binary, so the events go to the zerolog
// package logger, which the test points at a buffer.
func TestNilContextLogsWithoutContextFields(t *testing.T) {
	var buf bytes.Buffer

	savedLogger := zlog.Logger
	zlog.Logger = zlog.Logger.Output(&buf)
	t.Cleanup(func() { zlog.Logger = savedLogger })

	savedLevel := zerolog.GlobalLevel()
	zerolog.SetGlobalLevel(zerolog.TraceLevel)
	t.Cleanup(func() { zerolog.SetGlobalLevel(savedLevel) })

	const lid = "location-1"

	cases := []struct {
		name  string
		event func() *log.EventWrapper
		lid   string
	}{
		{"Trace", func() *log.EventWrapper { return log.Trace(nil) }, ""},
		{"Debug", func() *log.EventWrapper { return log.Debug(nil) }, ""},
		{"Info", func() *log.EventWrapper { return log.Info(nil) }, ""},
		{"Warn", func() *log.EventWrapper { return log.Warn(nil) }, ""},
		{"Error", func() *log.EventWrapper { return log.Error(nil) }, ""},
		{"Fatal", func() *log.EventWrapper { return log.Fatal(nil) }, ""},
		{"Panic", func() *log.EventWrapper { return log.Panic(nil) }, ""},
		{"Level", func() *log.EventWrapper { return log.Level(nil, zerolog.InfoLevel, "") }, ""},
		{"TraceWithLocationID", func() *log.EventWrapper { return log.TraceWithLocationID(nil, lid) }, lid},
		{"DebugWithLocationID", func() *log.EventWrapper { return log.DebugWithLocationID(nil, lid) }, lid},
		{"InfoWithLocationID", func() *log.EventWrapper { return log.InfoWithLocationID(nil, lid) }, lid},
		{"WarnWithLocationID", func() *log.EventWrapper { return log.WarnWithLocationID(nil, lid) }, lid},
		{"ErrorWithLocationID", func() *log.EventWrapper { return log.ErrorWithLocationID(nil, lid) }, lid},
		{"FatalWithLocationID", func() *log.EventWrapper { return log.FatalWithLocationID(nil, lid) }, lid},
		{"PanicWithLocationID", func() *log.EventWrapper { return log.PanicWithLocationID(nil, lid) }, lid},
		{"LogWithLocationID", func() *log.EventWrapper {
			return log.LogWithLocationID(nil, lid, zerolog.WarnLevel)
		}, lid},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			buf.Reset()

			require.NotPanics(t, func() { tc.event().WithMethod("m1").Msg(tc.name) })

			var event map[string]any
			require.NoError(t, json.Unmarshal(buf.Bytes(), &event), "output: %q", buf.String())

			assert.Equal(t, tc.name, event["message"])
			assert.Equal(t, "m1", event["m"])
			assert.NotContains(t, event, "s")

			if tc.lid == "" {
				assert.NotContains(t, event, "lid")
			} else {
				assert.Equal(t, tc.lid, event["lid"])
			}
		})
	}
}
