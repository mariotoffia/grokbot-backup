package logger

import (
	"os"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"

	"github.com/rs/zerolog"
)

func init() {
	// Initialize loggroups
	loggroup.NewFromEnvironment()
}

// ToZeroLogLevel will try to use string level name in *lower case* into a
// `zerolog.Level` constant. If it fails, it will use _defaultLevel_ instead.
func ToZeroLogLevel(level string, defaultLevel zerolog.Level) zerolog.Level {
	switch level {
	case "trace":
		return zerolog.TraceLevel
	case "debug":
		return zerolog.DebugLevel
	case "info":
		return zerolog.InfoLevel
	case "warn":
		return zerolog.WarnLevel
	case "error":
		return zerolog.ErrorLevel
	case "fatal":
		return zerolog.FatalLevel
	case "panic":
		return zerolog.PanicLevel
	case "disabled":
		return zerolog.Disabled
	default:
		return defaultLevel
	}
}

// SetLogLevelFromContext sets the context log level
// as per SetLogLevel(level) function.
func SetLogLevelFromContext(context ifcore.CbContext) {
	SetGlobalLogLevel(context.LogInfo().LogLevel)
}

// ClsLog returns a pre-setup logger from context, method and with appropriate
// level. If level is not configured this method return false but the logger is still
// configured and hence possible to log with.
func ClsLog(level zerolog.Level,
	method string,
	ldt LogDataType,
	lis LogInfoSensitivity,
	c ifcore.CbContext) (*zerolog.Event, bool) {
	var l *zerolog.Event
	lg := ResolveLogger(c, lis)

	switch level {
	case zerolog.TraceLevel:
		l = lg.Trace()
	case zerolog.InfoLevel:
		l = lg.Info()
	case zerolog.DebugLevel:
		l = lg.Debug()
	case zerolog.WarnLevel:
		l = lg.Warn()
	case zerolog.ErrorLevel:
		l = lg.Error()
	case zerolog.FatalLevel:
		l = lg.Fatal()
	case zerolog.PanicLevel:
		l = lg.Panic()
	default:
		l = lg.Info()
	}

	if !l.Enabled() {
		return l, false
	}

	l.Str("m", method).
		Str("lis", string(lis)).
		Str("ldt", string(ldt))

	// A nil context logs the event without the fields a context supplies.
	if c == nil {
		return l, true
	}

	l.Str("s", c.Service())

	pn := c.Provider()

	if pn != "" {
		l.Str("pn", pn)
	}

	version := c.Version()

	if version != "" {
		l.Str("ver", version)
	}

	trace := c.Trace()

	if trace.RequestID != "" {
		l.Str("rid", trace.RequestID)
	}

	if trace.Root != "" {
		l.Str("xr", trace.Root)
		if trace.Parent != "" {
			l.Str("xrp", trace.Parent)
		}
	}

	return l, true
}

// Flush will ensure that _stderr_  logs are flushed
//
// It will also flush any _logmap_ backing loggers, each under
// its own flush timeout.
func Flush(c ifcore.CbContext) error {
	FlushLogMap(c)
	return os.Stderr.Sync()

}

// ClsLogCognito is ClsLog for code that has no context: the event carries
// no fields from a context.
func ClsLogCognito(level zerolog.Level,
	method string,
	ldt LogDataType,
	lis LogInfoSensitivity) (*zerolog.Event, bool) {
	return ClsLog(level, method, ldt, lis, nil)
}
