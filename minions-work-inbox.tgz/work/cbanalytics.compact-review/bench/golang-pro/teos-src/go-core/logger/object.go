package logger

import (
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/utils"
)

// LogObject will log the object _value_ named as _key_ in the _JSON_ data.
//
// If it fails to `Marshal` the _value_ it will silently exit. If the _value_ is
// not of object type, e.g. a `string` then it will create an object.
//
// .Auto Creation of Object
// [source,json]
// ----
// {"value": "hello"} // <1>
// ----
// <1> When e.g. a string containing hello is submitted as _value_ parameter.
func LogObject(
	event *zerolog.Event,
	key string,
	value interface{}) *zerolog.Event {
	if key == "" || nil == value {
		return event
	}

	if data := utils.ToJSONByteArray(value); nil != data {
		return event.RawJSON(key, data)
	}

	return event
}

// LogObjectf will log the object _value_ named as _key_ in the _JSON_ data.
//
// It also accepts a formatting _msg_ and the corresponding _params_ as `Msgf()`.
// If it fails to marshal the _value_ it will only emit the message.
//
// If the _value_ is not of object type, e.g. a `string` then it will create an object.
//
// .Auto Creation of Object
// [source,json]
// ----
// {"value": "hello"} // <1>
// ----
// <1> When e.g. a string containing hello is submitted as _value_ parameter.
func LogObjectf(
	event *zerolog.Event,
	key string,
	value interface{},
	msg string,
	params ...interface{}) {
	if key == "" || nil == value {
		event.Msgf(msg, params...)
		return
	}

	LogObject(event, key, value).Msgf(msg, params...)
}
