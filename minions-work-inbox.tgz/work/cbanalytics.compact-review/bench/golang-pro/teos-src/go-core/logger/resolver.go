package logger

import (
	"fmt"
	"io"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"gopkg.in/natefinch/lumberjack.v2"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/iflog"
	"github.com/Thiink-LLC/teos/go-core/logger/memory"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrlog"
)

type logMapItem struct {
	// original is the root logger and will only be used to clone and set into zlogger.
	original *zerolog.Logger
	// zlogger is the logger that is used by the application
	zlogger       *zerolog.Logger
	backing       *mgrlog.LogManager
	memoryLoggers []*memory.MemoryLogger
	batch         iflog.BatchLogger
	stream        string
	closed        bool
}

// logmap contains all the logmap
var logmap = map[LogInfoSensitivity]*logMapItem{}

var s sync.RWMutex

// Close closes and flushes all logging.
//
// Use this as `defer logging.Close(c)` in main to flush and close all loggers.
// The batch loggers send what they still hold under their own flush timeout,
// not under the deadline of _c_.
func Close(c ifcore.CbContext) error {
	s.Lock()
	defer s.Unlock()

	lastError := os.Stderr.Sync()

	for _, v := range logmap {
		if !v.closed {
			v.closed = true

			if err := v.batch.Close(c); err != nil {
				lastError = err
			}

			for _, ml := range v.memoryLoggers {
				ml.Close()
			}
		}
	}

	return lastError
}

// createLogger will create a new logger with the configured output specified in _ctx_ logger
// settings.
//
// This is used internally by the `ResolveLogger` function.
func createLogger(ctx ifcore.CbContext) (*zerolog.Logger, []*memory.MemoryLogger) {
	var (
		li      = ctx.LogInfo()
		writers []io.Writer
		level   = ctx.LogInfo().LogLevel
	)

	if level == zerolog.NoLevel {
		// Default to info level
		level = zerolog.InfoLevel
	}

	if li.FileLogInfo != nil {
		writers = append(writers, &lumberjack.Logger{
			Filename:   li.FileLogInfo.Filename,
			MaxSize:    li.FileLogInfo.MaxSize,
			MaxBackups: li.FileLogInfo.MaxBackups,
			MaxAge:     li.FileLogInfo.MaxAge,
			Compress:   li.FileLogInfo.Compress,
		})
	}

	var memoryLoggers []*memory.MemoryLogger

	if li.MemoryLogInfo != nil {
		ml := memory.New(
			li.MemoryLogInfo.SizeThreshold,
			li.MemoryLogInfo.TimeThreshold,
			li.MemoryLogInfo.Compress,
			li.MemoryLogInfo.OnFull,
		)

		writers = append(writers, ml)
		memoryLoggers = append(memoryLoggers, ml)
	}

	if li.UseStdErrLogging {
		writers = append(writers, os.Stderr)
	}

	if len(li.CustomWriters) > 0 {
		writers = append(writers, li.CustomWriters...)
	}

	var (
		writer io.Writer
		lg     zerolog.Logger
	)

	switch {
	case len(writers) > 1:
		writer = io.MultiWriter(writers...)
	case len(writers) == 1:
		writer = writers[0]
	default:
		writer = os.Stderr
	}

	if li.UseConsoleLog {
		output := zerolog.ConsoleWriter{Out: writer, TimeFormat: time.RFC3339}
		output.FormatLevel = func(i interface{}) string {
			return strings.ToUpper(fmt.Sprintf("| %-6s|", i))
		}
		output.FormatMessage = func(i interface{}) string {
			return fmt.Sprintf("%s -> ", i)
		}
		output.FormatFieldName = func(i interface{}) string {
			return fmt.Sprintf("%s:", i)
		}
		output.FormatFieldValue = func(i interface{}) string {
			return fmt.Sprintf("%s", i)
		}

		lg = zerolog.New(output).Level(level).With().Timestamp().Logger()
	} else {
		lg = zerolog.New(writer).Level(level).With().Timestamp().Logger()
	}

	// Make sure global logger follows our level.
	zerolog.SetGlobalLevel(level)

	return &lg, memoryLoggers
}

// SetGlobalLogLevel sets the global log level for all loggers.
func SetGlobalLogLevel(level zerolog.Level) {
	s.Lock()
	defer s.Unlock()

	for _, v := range logmap {
		zl := v.original.Level(level) // Create child logger from root with min level
		v.zlogger = &zl               // Assign it to zlogger
	}

	zerolog.SetGlobalLevel(level)
}

// GetGlobalLogLevel returns the global log level.
func GetGlobalLogLevel() zerolog.Level {
	return zerolog.GlobalLevel()
}

// ResolveLogger resolves to correct logger.
//
// A nil _ctx_ gets the logger already built for _lis_. When none exists yet it
// gets the zerolog package logger, which writes to stderr, and nothing is
// stored, so the first real context still configures the logger for _lis_.
//
// This function is thread safe.
func ResolveLogger(ctx ifcore.CbContext, lis LogInfoSensitivity) *zerolog.Logger {
	// Fast path: logger already exists - read lock only.
	s.RLock()
	if zl, ok := logmap[lis]; ok {
		if !zl.needSwitchStream() {
			lg := zl.zlogger
			s.RUnlock()
			return lg
		}
		// Need to mutate stream - upgrade to write lock.
		s.RUnlock()

		s.Lock()
		if zl.needSwitchStream() {
			zl.stream = calculateStreamName()
			zl.batch.ChangeStream(zl.stream)
		}
		lg := zl.zlogger
		s.Unlock()
		return lg
	}
	s.RUnlock()

	if ctx == nil {
		return &log.Logger
	}

	// Slow path: first access for this LIS - write lock.
	s.Lock()
	defer s.Unlock()

	// Double-check after acquiring write lock.
	if zl, ok := logmap[lis]; ok {
		return zl.zlogger
	}

	// check if we have a log group for current _lis_ -yes-> Configure backing logger
	group, hasLogGroup := loggroup[lis]
	backingLogger := ctx.LogInfo().BackingLogger

	// No log group && no backing logger -> standard logger creation
	if !hasLogGroup || backingLogger == nil {
		logger, memoryLoggers := createLogger(ctx)

		logmap[lis] = &logMapItem{zlogger: logger, original: logger, memoryLoggers: memoryLoggers}

		return logmap[lis].zlogger
	}

	// We have a log group and a backing logger -> create a new logger for the log group
	stream := calculateStreamName()
	backing := backingLogger.(*mgrlog.LogManager).
		CloneToLogManager(ctx).
		UseGroup(group).
		UseStream(stream).
		CreateStreamIfMissing(true)

	// we have a log group and now we need to set it up

	// Find all the configured lis for the particular group
	all := loggroup.findFromGroup(group)

	bl := backing.BatchLogger(
		ctx, time.Duration(5*time.Second), iflog.DefaultFlushTimeout, 10, /*retries*/
	)

	lg := log.Logger.Output(bl)

	// Assign all positions one group may server many LIS!
	lm := &logMapItem{
		zlogger:  &lg,
		original: &lg,
		backing:  backing,
		batch:    bl,
		stream:   stream,
	}

	for _, n := range all {
		logmap[n] = lm
	}

	return lm.zlogger
}

// flushLogMapItems walks through the _logmap_ and
// flushes all individual batch loggers.
//
// Since some may have shared `*logMapItem`, it will
// only flush each unique batch logger once. Each one
// flushes under its own flush timeout, not under the
// deadline of _c_.
//
// This function is thread safe
func FlushLogMap(c ifcore.CbContext) {
	s.Lock()

	flush := []iflog.BatchLogger{}

	for k := range logmap {
		bl := logmap[k]
		if bl == nil || bl.batch == nil {
			continue
		}

		found := false
		for _, f := range flush {
			if bl.batch == f {
				found = true
				break
			}
		}

		if !found {
			flush = append(flush, bl.batch)
		}
	}

	s.Unlock()

	for i := range flush {
		_ = flush[i].Flush(c)
	}

}

func (lm *logMapItem) needSwitchStream() bool {
	if lm.backing == nil {
		return false
	}

	now := calculateStreamName()

	return lm.stream != now
}

// Produces a stream name of current year-month-day
// in _'YYYY-MM-DD'_ format.
func calculateStreamName() string {
	return time.Now().Format("2006-01-02")
}
