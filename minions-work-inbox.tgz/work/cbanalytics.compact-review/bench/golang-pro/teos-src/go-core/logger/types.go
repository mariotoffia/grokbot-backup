package logger

// LogInfoSensitivity determines the information sensitivity e.g. PII, GDPR, Classified
type LogInfoSensitivity string

// LogDataType stipulates what type of data e.g. na, auth-data, std
type LogDataType string

const (
	// LISPII is the generic for of personal identity information
	LISPII LogInfoSensitivity = "pii"
	// LISClassified is generic classified data e.g. auth-data
	LISClassified LogInfoSensitivity = "clzf"
	// LISPolicyControlled stating that the data is more important than `LISUnclassified` since worth policy control
	// it. But it can range all the way up to _PII_ data.
	LISPolicyControlled LogInfoSensitivity = "plc"
	// LISUnclassified means that no information classification has ben done for the log entry.
	LISUnclassified LogInfoSensitivity = "na"

	// LDTUntyped no typing (this needs to be corrected)
	LDTUntyped LogDataType = "na"
	// LDTAuthData is data that contains e.g. token, username / password (thus needs to be protected)
	//
	// This is more explicit than LDTContainsSecrets since it qualifies to explicit AuthData.
	LDTAuthData LogDataType = "auth"
	// LDTContainsSecrets states that the entry contains secrets of any kind.
	LDTContainsSecrets LogDataType = "sec"
	// LDTStd is just standard plain log, not needed to be typed in any way
	LDTStd LogDataType = "std"
	// LDTDevOps specifies that this log entry is a entry to be interpreted in a devOps context
	//
	// For example, that a publish a message to a queue failed or that this endpoint url was used
	// to update the thing shadow.
	LDTDevOps LogDataType = "devops"
	// LDTDeveloper specifies that the log entry is for developer eyes
	//
	// For example a pipeline executor log output or other lowlevel program specific output.
	LDTDeveloper LogDataType = "dev"
)

// String converts LogDataType to a plain string
func (ldt LogDataType) String() string {
	return string(ldt)
}

// String converts LogInfoSensitivity to a plain string
func (lis LogInfoSensitivity) String() string {
	return string(lis)
}
