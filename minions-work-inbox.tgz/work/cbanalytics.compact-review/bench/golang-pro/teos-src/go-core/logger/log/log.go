package log

import (
	"errors"
	"strings"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
)

// A struct to represent the parsed override for each LID
type LogLevelOverride struct {
	From zerolog.Level // Minimum level in the range
	To   zerolog.Level // The level to which events will be remapped
}

var lidOverrides map[string]LogLevelOverride

func init() {
	lidOverrides = ParseLogLevelOverrides(cbenv.CB_LOG_LEVEL_LID_OVERRIDES.String(""))
}

// ReloadOverrides re-reads CB_LOG_LEVEL_LID_OVERRIDES and refreshes the
// in-memory override map. Call this after updating the environment variable
// at runtime (e.g. after loading config.json).
func ReloadOverrides() {
	lidOverrides = ParseLogLevelOverrides(cbenv.CB_LOG_LEVEL_LID_OVERRIDES.String(""))
}

func ParseLogLevelOverrides(overrides string) map[string]LogLevelOverride {
	result := map[string]LogLevelOverride{}

	if overrides == "" {
		return result
	}

	pairs := strings.Split(overrides, ",")

	for _, pair := range pairs {
		kv := strings.Split(pair, "=")

		if len(kv) != 2 {
			continue // Ignore invalid pairs
		}

		lid := kv[0]
		levelRange := kv[1]

		from, to, err := parseLevelRange(levelRange)

		if err == nil {
			result[lid] = LogLevelOverride{From: from, To: to}
		}
	}

	return result
}

func parseLevelRange(levelRange string) (zerolog.Level, zerolog.Level, error) {
	levels := strings.Split(levelRange, ":")

	if len(levels) != 2 {
		return zerolog.NoLevel, zerolog.NoLevel, errors.New("invalid level range format")
	}

	from, err := zerolog.ParseLevel(levels[0])

	if err != nil {
		return zerolog.NoLevel, zerolog.NoLevel, err
	}

	to, err := zerolog.ParseLevel(levels[1])
	if err != nil {
		return zerolog.NoLevel, zerolog.NoLevel, err
	}

	return from, to, nil
}

type EventWrapper struct {
	*zerolog.Event
	ctx   ifcore.CbContext
	ldt   logger.LogDataType
	lis   logger.LogInfoSensitivity
	level zerolog.Level
}

var nullWrapper = &EventWrapper{
	ctx:   nil,
	ldt:   logger.LDTUntyped,
	lis:   logger.LISUnclassified,
	level: zerolog.Disabled,
}

func newEvent(
	ctx ifcore.CbContext,
	level zerolog.Level,
	lis logger.LogInfoSensitivity,
	lid string,
) *EventWrapper {
	if lid != "" {
		// Override exist for lid?
		if override, exists := lidOverrides[lid]; exists {
			if level >= override.From && level < override.To {
				level = override.To // Remap to the specified "to" level
			}
		}
	}

	if zerolog.GlobalLevel() > level {
		return nullWrapper
	}

	lg := logger.ResolveLogger(ctx, lis)

	l := EventWrapper{
		Event: lg.WithLevel(level),
		ctx:   ctx,
		ldt:   logger.LDTUntyped,
		level: level,
	}

	if lid != "" {
		l.Str("lid", lid)
	}

	// A nil context logs the event without the fields a context supplies.
	if ctx == nil {
		return &l
	}

	l.Str("s", ctx.Service())

	pn := ctx.Provider()

	if pn != "" {
		l.Str("pn", pn)
	}

	version := ctx.Version()

	if version != "" {
		l.Str("ver", version)
	}

	trace := ctx.Trace()

	if trace.RequestID != "" {
		l.Str("rid", trace.RequestID)
	}

	if trace.Root != "" {
		l.Str("xr", trace.Root)
		if trace.Parent != "" {
			l.Str("xrp", trace.Parent)
		}
	}

	return &l
}

func toLIS(lis []logger.LogInfoSensitivity) logger.LogInfoSensitivity {
	if len(lis) > 0 {
		return lis[0]
	}

	return logger.LISUnclassified
}

func Level(
	ctx ifcore.CbContext,
	level zerolog.Level,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, level, toLIS(lis), lid)
}

func TraceWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.TraceLevel, toLIS(lis), lid)
}

func Trace(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.TraceLevel, toLIS(lis), "")
}

func LogWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	level zerolog.Level,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, level, toLIS(lis), lid)
}

func DebugWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.DebugLevel, toLIS(lis), lid)
}

func Debug(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.DebugLevel, toLIS(lis), "")
}

func InfoWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.InfoLevel, toLIS(lis), lid)
}

func Info(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.InfoLevel, toLIS(lis), "")
}

func WarnWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.WarnLevel, toLIS(lis), lid)
}

func Warn(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.WarnLevel, toLIS(lis), "")
}

func ErrorWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.ErrorLevel, toLIS(lis), lid)
}

func Error(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.ErrorLevel, toLIS(lis), "")
}

func FatalWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.FatalLevel, toLIS(lis), lid)
}

func Fatal(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.FatalLevel, toLIS(lis), "")
}

func PanicWithLocationID(
	ctx ifcore.CbContext,
	lid string,
	lis ...logger.LogInfoSensitivity,
) *EventWrapper {
	return newEvent(ctx, zerolog.PanicLevel, toLIS(lis), lid)
}

func Panic(ctx ifcore.CbContext, lis ...logger.LogInfoSensitivity) *EventWrapper {
	return newEvent(ctx, zerolog.PanicLevel, toLIS(lis), "")
}

func IsEnabledWithLocationID(
	level zerolog.Level,
	lid string,
) bool {
	if override, exists := lidOverrides[lid]; exists {
		if level >= override.From && level < override.To {
			level = override.To
		}
	}

	if level == zerolog.NoLevel {
		return false
	}

	global := zerolog.GlobalLevel()

	return level >= global && global != zerolog.Disabled
}

// IsEnabled returns true if the _level_ is enabled
func IsEnabled(level zerolog.Level) bool {
	if level == zerolog.NoLevel {
		return false
	}

	global := zerolog.GlobalLevel()

	return level >= global && global != zerolog.Disabled
}

// IsEnabled returns `true“ if the log level is enabled.
//
// If it returns `false`, the log event will not be logged.
func (l *EventWrapper) IsEnabled() bool {
	return l != nullWrapper
}

func (l *EventWrapper) WithBody(body interface{}) *EventWrapper {
	if l == nullWrapper || body == nil {
		return l
	}

	return l.AsJSON("body", body)
}

func (l *EventWrapper) AsJSON(key string, obj any) *EventWrapper {
	if l == nullWrapper {
		return l
	}

	logger.LogObject(l.Event, key, obj)
	return l
}

func (l *EventWrapper) WithMethod(method string) *EventWrapper {
	if l == nullWrapper {
		return l
	}

	l.Str("m", method)
	return l
}

func (l *EventWrapper) WithDataType(ldt logger.LogDataType) *EventWrapper {
	if l == nullWrapper {
		return l
	}

	l.Str("ldt", string(ldt))
	return l
}

func (l *EventWrapper) WithError(err error) *EventWrapper {
	if l == nullWrapper || err == nil {
		return l
	}

	logger.LogObject(l.Event, "err", err)
	return l
}
