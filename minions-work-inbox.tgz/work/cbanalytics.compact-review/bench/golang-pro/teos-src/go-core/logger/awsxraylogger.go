package logger

import (
	"fmt"

	"github.com/aws/aws-xray-sdk-go/v2/xraylog"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// AWSXRayLogger implements the `xraylog.Logger` interface to it may
// be used to set as a logger for the AWS X-Ray SDK.
type AWSXRayLogger struct {
	LogDataType        LogDataType
	LogInfoSensitivity LogInfoSensitivity
	Context            ifcore.CbContext
}

// Log is invoked by the X-RAY SDK to log a message.
func (log *AWSXRayLogger) Log(level xraylog.LogLevel, msg fmt.Stringer) {
	if l, ok := ClsLog(
		fromXRayLogLevel(level), "xray",
		log.LogDataType,
		log.LogInfoSensitivity,
		log.Context); ok {
		l.Msg(msg.String())
	}
}

// fromXRayLogLevel translates a xray log level into `zerolog.Level` of
// which is native to thiink.
func fromXRayLogLevel(level xraylog.LogLevel) zerolog.Level {
	switch level {
	case xraylog.LogLevelError:
		return zerolog.ErrorLevel
	case xraylog.LogLevelWarn:
		return zerolog.WarnLevel
	case xraylog.LogLevelInfo:
		return zerolog.InfoLevel
	case xraylog.LogLevelDebug:
		return zerolog.DebugLevel
	default:
		return zerolog.InfoLevel
	}
}

// ToXRayLogLevel translates the thiink log level to a `xraylog.LogLevel`
func ToXRayLogLevel(logLevel string) xraylog.LogLevel {
	switch logLevel {
	case "trace", "debug":
		return xraylog.LogLevelDebug
	case "info":
		return xraylog.LogLevelInfo
	case "warn":
		return xraylog.LogLevelWarn
	case "fatal", "error", "panic":
		return xraylog.LogLevelError
	}

	return xraylog.LogLevelInfo

}
