package memory

import (
	"bytes"
	"compress/gzip"
	"sync"
	"time"
)

// MemoryLogger is a logger that will log messages into memory until a threshold is reached.
//
// It will not cut log messages in half, instead if will check if it fits. If not, it will
// copy the memory invoke the `onFull` function with the copied data. The buffer will be reset
// after the `onFull` function is called and log statements will continue to be written.
type MemoryLogger struct {
	buffer        *bytes.Buffer
	sizeThreshold int
	TimeThreshold time.Duration
	compress      bool
	mutex         *sync.Mutex
	onFull        func(data []byte)
	// timer to handle the time threshold
	timer *time.Timer
}

// New creates a new `MemoryLogger` with the specified threshold and onFull function.
//
// NOTE: _sizeThreshold_ is in bytes! For example, use 1*1024*1024 for 1MB.
//
// If the _timeThreshold_ is zero or less, it will not flush the buffer based on time.
//
// The _onFull_ function will be called when the buffer is full and will be passed a copy of the
// current buffer's data. It is called in a go routine and the function will have exclusive access
// to passed buffer. The writer will continue while the _onFull function is running.
//
// If _compress_ is set to true, it will compress the buffer before passing it to the _onFull_.
func New(
	sizeThreshold int,
	timeThreshold time.Duration,
	compress bool,
	onFull func(data []byte),
) *MemoryLogger {
	ml := &MemoryLogger{
		sizeThreshold: sizeThreshold,
		TimeThreshold: timeThreshold,
		onFull:        onFull,
		compress:      compress,
		mutex:         &sync.Mutex{},
		buffer:        bytes.NewBuffer([]byte{}),
	}

	if ml.TimeThreshold > 0 {
		ml.timer = time.AfterFunc(ml.TimeThreshold, func() {
			ml.mutex.Lock()
			defer ml.mutex.Unlock()

			if ml.buffer.Len() == 0 {
				return
			}

			_ = ml.invokeOnFull()

			if ml.TimeThreshold > 0 {
				ml.timer.Reset(ml.TimeThreshold)
			}
		})
	}

	return ml
}

func (m *MemoryLogger) Close() {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	if m.timer != nil {
		m.timer.Stop()
	}

	m.timer = nil
}

// Write implements the io.Writer interface for `io.Writer`.
//
// It writes p (log data) into the logger's buffer and checks the threshold.
func (m *MemoryLogger) Write(p []byte) (n int, err error) {
	m.mutex.Lock()
	defer m.mutex.Unlock()

	if len(p)+m.buffer.Len() >= m.sizeThreshold {
		_ = m.invokeOnFull()
	}

	n, err = m.buffer.Write(p)
	if err != nil {
		return 0, err
	}

	return n, nil
}

func (m *MemoryLogger) invokeOnFull() error {
	var data []byte

	if m.compress {
		var compressedBuffer bytes.Buffer

		gz := gzip.NewWriter(&compressedBuffer)
		_, err := gz.Write(m.buffer.Bytes())
		if err != nil {
			return err
		}

		err = gz.Close()
		if err != nil {
			return err
		}

		data = compressedBuffer.Bytes()
	} else {
		data = make([]byte, m.buffer.Len())

		copy(data, m.buffer.Bytes())
	}

	go m.onFull(data)

	m.buffer.Reset()

	return nil
}
