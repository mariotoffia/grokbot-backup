package logger

import (
	"testing"

	"github.com/rs/zerolog"
)

// TestClsLogCognitoDoesNotConfigureTheLogger logs through ClsLogCognito, the
// helper for code that has no context, before any logger exists. That log must
// not build and store the logger for its sensitivity, or the first such log in
// a process would decide the outputs and level that every later context gets.
func TestClsLogCognitoDoesNotConfigureTheLogger(t *testing.T) {
	s.Lock()
	saved := logmap
	logmap = map[LogInfoSensitivity]*logMapItem{}
	s.Unlock()

	savedLevel := zerolog.GlobalLevel()

	defer func() {
		s.Lock()
		logmap = saved
		s.Unlock()
		zerolog.SetGlobalLevel(savedLevel)
	}()

	l, ok := ClsLogCognito(zerolog.ErrorLevel, "test", LDTDevOps, LISUnclassified)
	if !ok {
		t.Fatal("an error level event must be enabled")
	}

	l.Discard().Msg("no context in scope")

	s.RLock()
	defer s.RUnlock()

	if _, stored := logmap[LISUnclassified]; stored {
		t.Error("a log without a context must not build and store the logger")
	}
}
