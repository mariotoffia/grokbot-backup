# GO-CORE instructions

## Setup GIT & Azure DevOps

It is important that you use the https://dev.azure.com/dataductus instead of https://dataductus.visualstudio.com as starting URL. Since we're using the former, everything is resolved through the DNS
name of _dev.azure.com_.

In order to allow git to access to the repository (this is how golang resolves it's modules) you
need to create a Personal Access Token (PAT) on https://dev.azure.com/dataductus. Issue a `git config --global url."https://dataductus:$PAT@dev.azure.com".insteadOf "https://dev.azure.com"`.

This makes it possible to fetch go modules from the private repositories on our azure DevOps repositories.

*NOTE* since this repo do contain a _GIT sub module_ it is neccesary to pull it down using `git submodule update --init --recursive` for the first time. Subsquent updates is done through `git pull --recurse-submodules`.

## Documentation Generation

This repos is based around asciidoctor. It uses the [goasciidoc](https://github.com/mariotoffia/goasciidoc) open source project. This is installed to $GOAPTH/bin folder when doing `make dep`.

It is also neccesary to install google chrome. This is how you [install](https://linuxize.com/post/how-to-install-google-chrome-web-browser-on-ubuntu-20-04/) it via bash in Ubuntu. Chrome is used to run headless to provide with PDF output. What it basically states is:
1) `wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb`
2) `sudo apt install ./google-chrome-stable_current_amd64.deb` or om mac M1 `brew install chromium` (follow the guide https://linguinecode.com/post/how-to-fix-m1-mac-puppeteer-chromium-arm64-bug)

It has then updated the list so it is possible to e.g. do `sudo apt-get update` and `upgrade` to upgrade the browser. If you want you may verify `cat /etc/apt/sources.list.d/google-chrome.list`.

If you get the following error _error while loading shared libraries: libXss.so.1: cannot open shared object file: No such file or directory_, please install `sudo apt-get install libxss1`.

**NOTE:** You have to configure the asciidoctor plugin to allow for secure content and use local kroki url if using a local `docker-compose` of kroki server - please cheout [this](https://blog.anoff.io/2019-05-08-asciidoc-plantuml-vscode/) blog for more information.

## Tools installations

* Formatting lines with `golines` by `go install github.com/segmentio/golines@latest`. Open _.vscode/settings.json_ and add the following snippet.
```json
 "emeraldwalk.runonsave": {
        "commands": [
            {
                "match": "\\.go$",
                "cmd": "golines ${file} -w"
            }
        ]
    }
```

The `go-core` do contain tools that may be useful. The installation is done on the following format `env GOPRIVATE="github.com/Thiink-LLC/teos/go-core" go get -u github.com/Thiink-LLC/teos/go-core/cmd/your-cmd-here@if-branch-here`. Replace _your-cmd-here_ with your wanted command and _if-branch-here_ with the branch wanted if other than _master_.

Example install _cmd/identity_ command from branch _feature-cbctx-v2_ would be `env GOPRIVATE="github.com/Thiink-LLC/teos/go-core" go get -u github.com/Thiink-LLC/teos/go-core/cmd/identity@feature-cbctx-v2` or if on _main_ branch `env GOPRIVATE="github.com/Thiink-LLC/teos/go-core" go get -u github.com/Thiink-LLC/teos/go-core/cmd/identity`.

This will download, compile, and put the command under your _GOBIN_ folder, typically _~/go/bin_.

## Versions

### v0.7.91

#### Breaking Changes

`PipelineAwareProvider.GetTargetType() interface{}` is removed. Providers need to implement the `ProviderPipelineTypeContributor` of which allows for many types to be registered at once. This means that all providers now need to always register their types since not implicit `dsmodel.DsFullBuilding` type is registered.
