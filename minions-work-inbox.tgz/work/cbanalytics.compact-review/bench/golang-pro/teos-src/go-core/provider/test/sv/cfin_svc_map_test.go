package sv

import (
	"fmt"
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/cfgmodel"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel"
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel/core"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const testProvider = "test-provider"

func TestCFINMapSVC(t *testing.T) {
	pid := "myPlantID"
	lid := "Måssmyren 44"

	now := *coremodel.NewTime32Now()
	simulatedHCTEntryChangeTime := now.Add(10 * time.Second)

	// Simulate call to remote endpoint for fetching sensor service config
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			//
			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{ID: "virtualOBT", Value: 18, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualITT", Value: 20, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualITL", Value: 16, TimeStamp: now},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualESL",
					Value:     "Small (<= 100 kW)",
					TimeStamp: now,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O1", Value: -20, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O1", Value: 65, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O2", Value: -10, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O2", Value: 55, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O3", Value: -5, TimeStamp: now},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualHCTST_O3",
					Value:     45,
					TimeStamp: simulatedHCTEntryChangeTime,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O4", Value: 0, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O4", Value: 40, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O5", Value: 5, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O5", Value: 37, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O6", Value: 10, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O6", Value: 35, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O7", Value: 20, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O7", Value: 30, TimeStamp: now},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/svc-map",
				 "prms": {
					 "LOG": true,
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default"
				}
		}`, pid, lid),
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	m := cbevent.ExtractResult[map[string]cfgmodel.ImportConfigEvent](res, 0)
	require.Equal(t, 1, len(m))

	cfgevt := m["target"]
	require.Len(t, cfgevt.Services, 1)

	settings := cfgevt.Services[0]

	require.Equal(t, "noda-building", settings.Name)

	assert.Equal(t, settings.Config.Realizes.Type[0], core.ServiceTypeHeating)

	bindings, err2 := core.GetSlice[string](&settings.Config, "bindings")
	require.NoError(t, err2)

	assert.Len(t, bindings, 1)
	assert.Equal(t, "CIRCUIT1", bindings[0])

	esl, _ := settings.GetEffectServiceLevel()
	assert.Equal(t, servicemodel.TeosEffectServiceLevelSmall, esl)

	itl, _ := settings.GetIndoorTemperatureLimitLow()
	assert.Equal(t, float64(16), itl)

	itt, _ := settings.GetIndoorTargetTemperature()
	assert.Equal(t, float64(20), itt)

	obt, _ := settings.GetOutdoorBalanceTemperature()
	assert.Equal(t, float64(18), obt)

	hct, err2 := settings.GetHeatCurve()
	require.NoError(t, err2)
	assert.Equal(t, 7, len(hct))

	assert.Equal(t, float64(-20), hct[0].OutdoorTriggerTemp)
	assert.Equal(t, float64(65), hct[0].SupplyTemp)
	assert.Equal(t, float64(-10), hct[1].OutdoorTriggerTemp)
	assert.Equal(t, float64(55), hct[1].SupplyTemp)
	assert.Equal(t, float64(-5), hct[2].OutdoorTriggerTemp)
	assert.Equal(t, float64(45), hct[2].SupplyTemp)
	assert.Equal(t, float64(0), hct[3].OutdoorTriggerTemp)
	assert.Equal(t, float64(40), hct[3].SupplyTemp)
	assert.Equal(t, float64(5), hct[4].OutdoorTriggerTemp)
	assert.Equal(t, float64(37), hct[4].SupplyTemp)
	assert.Equal(t, float64(10), hct[5].OutdoorTriggerTemp)
	assert.Equal(t, float64(35), hct[5].SupplyTemp)
	assert.Equal(t, float64(20), hct[6].OutdoorTriggerTemp)
	assert.Equal(t, float64(30), hct[6].SupplyTemp)

	meta := settings.Config.Meta
	require.NotNil(t, meta)

	require.NotNil(t, meta.Ts)
	ts := *meta.Ts

	assert.Equal(t, now.Unix(), ts[string(eqmodel.ConfigurationTypeOutdoorBalanceTemperature)])
	assert.Equal(t, now.Unix(), ts[string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow)])
	assert.Equal(t, now.Unix(), ts[string(eqmodel.ConfigurationTypeIndoorTemperatureTarget)])
	assert.Equal(
		t,
		simulatedHCTEntryChangeTime.Unix(),
		ts[string(eqmodel.ConfigurationTypeHeatingCurve)],
	)
}

func BenchmarkCFINMapSVC(t *testing.B) {
	pid := "myPlantID"
	lid := "Måssmyren 44"

	now := *coremodel.NewTime32Now()
	simulatedHCTEntryChangeTime := now.Add(10 * time.Second)

	// Simulate call to remote endpoint for fetching sensor service config
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			//
			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{ID: "virtualOBT", Value: 18, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualITT", Value: 20, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualITL", Value: 16, TimeStamp: now},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualESL",
					Value:     "Small (<= 100 kW)",
					TimeStamp: now,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O1", Value: -20, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O1", Value: 65, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O2", Value: -10, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O2", Value: 55, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O3", Value: -5, TimeStamp: now},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualHCTST_O3",
					Value:     45,
					TimeStamp: simulatedHCTEntryChangeTime,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O4", Value: 0, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O4", Value: 40, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O5", Value: 5, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O5", Value: 37, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O6", Value: 10, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O6", Value: 35, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTODT_O7", Value: 20, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualHCTST_O7", Value: 30, TimeStamp: now},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	payload := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/svc-map",
				 "prms": {
					 "LOG": true,
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default"
				}
		}`, pid, lid),
		},
	})

	for i := 0; i < t.N; i++ {
		_, invokeError := pctx.Invoker().InvokeRaw(ctx, payload)
		require.NoError(t, invokeError)
	}
}
