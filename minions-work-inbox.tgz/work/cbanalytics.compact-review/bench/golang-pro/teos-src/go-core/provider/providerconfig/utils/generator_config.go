package utils

import (
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// ResolveMaxSensorIDsForTemplateGenerator will gather which IDs to use from
// generator prototypes. It returns maximum amount, since it won't take account
// of which are optional or not.
func ResolveMaxSensorIDsForTemplateGenerator(cfg ifprovider.ConfigFull) []string {
	pid := map[string]bool{}

	pid = getSpaceSeparatedIDsFromGlobalParams(
		cfg, ifprovider.ParameterProviderRequiredGeneratorProtoTypeIDs, pid,
	)

	if cfg.ContainsGlobalParam(string(ifprovider.ParameterGeneratorProtoTypeIDs), true) {
		pid = getSpaceSeparatedIDsFromGlobalParams(
			cfg, ifprovider.ParameterGeneratorProtoTypeIDs, pid,
		)
	} else {
		pid = getSpaceSeparatedIDsFromGlobalParams(
			cfg, ifprovider.ParameterMappingIDs, pid,
		)
	}

	ids := make([]string, 0, len(pid))
	for id := range pid {
		ids = append(ids, id)
	}

	return ids
}

// ResolveOptionalSensorsAsSet will resolve which if the _ids_ are marked as optional and return it as
// a map (that acts as a set). If _oper_ is set it will query the operation config in addition to global
// config.
func ResolveOptionalSensorsAsSet(
	cfg ifprovider.ConfigFull,
	ids []string,
	oper string,
) (map[string]bool, error) {
	op, _ := cfg.GetConfigOperation(oper)
	optSensors, error := cfg.GetOptionalSensors(op, ids)

	if nil != error {
		return nil, error
	}

	var optionals map[string]bool

	if len(optSensors) > 0 {
		optionals = map[string]bool{}
		for _, s := range optSensors {
			optionals[s] = true
		}
	}

	return optionals, nil
}

// HasOptionalSensorParameter checks if the `ifprovider.ParameterOptionalSensors` is present in the
// global configuration and it has a value. If _oper_ is set, it will also check the operation config.
func HasOptionalSensorParameter(cfg ifprovider.ConfigFull, oper string) bool {
	found := cfg.ContainsGlobalParam(string(ifprovider.ParameterOptionalSensors), true)

	if oper == "" || found {
		return found
	}

	op, _ := cfg.GetConfigOperation(oper)
	if str, ok := op.GetParamAsString(string(ifprovider.ParameterOptionalSensors)); ok {
		found = len(str) > 0
	}

	return found
}

// HasFullGeneratorTemplate checks if a full generator template exists.
//
// If not, probably it has a prototype templates to generate a full generator template from
// those.
func HasFullGeneratorTemplate(cfg *providermodel.ProviderConfigImpl, templateID string) bool {
	_, ok := cfg.Generate[templateID]
	return ok
}

// HasTimeStampCheckEnabled checks if time stamp check is enabled for the
// _cfg_. This will make the generator template to include the time stamp
// if possible.
func HasTimeStampCheckEnabled(cfg ifprovider.ConfigGlobalParams) bool {
	if strings.ToLower(
		cfg.GetParamAsStringWithDefault(
			string(ifprovider.ParameterCheckTimeStampOnUpdate),
			"",
		),
	) == "true" ||
		strings.ToLower(
			cfg.GetParamAsStringWithDefault(
				string(ifprovider.ParameterLocalCheckAndReportTimeStamp),
				"",
			),
		) == "true" {
		return true
	}

	return false
}

// GetTemplateGeneratorMode will fetch the generator mode for the config. If _oper_ is provided it will
// try to fetch the mode from the operation config first.
//
// If nothing is set, it will return `ifprovider.GeneratorTemplateGenerationAuto`.
//
// NOTE: It does not support expression in the parameter.
func GetTemplateGeneratorMode(
	cfg ifprovider.ConfigFull,
	oper string,
) ifprovider.GeneratorTemplateGenerationModes {
	if oper != "" {
		op, _ := cfg.GetConfigOperation(oper)
		if str, ok := op.GetParamAsString(string(ifprovider.ParameterGeneratorTemplateGeneration)); ok {
			return ifprovider.GeneratorTemplateGenerationModes(str)
		}
	}

	if str, ok := cfg.GetParamAsString(string(ifprovider.ParameterGeneratorTemplateGeneration)); ok {
		return ifprovider.GeneratorTemplateGenerationModes(str)
	}

	return DefaultGeneratorMode

}

// GetMappingMode gets the mapping mode
func GetMappingMode(cfg ifprovider.ConfigFull, oper string) ifprovider.MappingMode {
	if oper != "" {
		op, _ := cfg.GetConfigOperation(oper)
		if str, ok := op.GetParamAsString(string(ifprovider.ParameterMappingMode)); ok {
			return ifprovider.MappingMode(str)
		}
	}

	if str, ok := cfg.GetParamAsString(string(ifprovider.ParameterMappingMode)); ok {
		return ifprovider.MappingMode(str)
	}

	return ifprovider.MappingModeStrict
}

// IsConfigGenerationApplyDelayed checks if the `ifprovider.ParameterConfigGenerationUsage` is
// set to `ifprovider.ConfigGenerationUsageDelayApply`.
func IsConfigGenerationApplyDelayed(cfg ifprovider.ConfigFull) bool {
	if str, ok := cfg.GetParamAsString(string(ifprovider.ParameterConfigGenerationUsage)); ok {
		return ifprovider.ConfigGenerationUsage(str) == ifprovider.ConfigGenerationUsageDelayApply
	}

	return false
}

func getSpaceSeparatedIDsFromGlobalParams(
	cfg ifprovider.ConfigGlobalParams,
	id ifprovider.ParameterTypes,
	pid map[string]bool,
) map[string]bool {
	c := strings.Split(cfg.GetParamAsStringWithDefault(string(id), ""), " ")

	for i := range c {
		if len(c[i]) > 0 {
			pid[c[i]] = true
		}
	}

	return pid
}
