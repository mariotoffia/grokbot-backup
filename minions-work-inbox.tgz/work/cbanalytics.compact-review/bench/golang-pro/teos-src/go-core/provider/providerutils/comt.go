package providerutils

import (
	"fmt"
	"slices"
	"strconv"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/collection"
	"github.com/Thiink-LLC/teos/go-core/utils/fexp"
)

type HandleCOMTOptions struct {
	// MID, if provided, it will be adjusted to add/remove _COMT_ datapoints. It will then be returned. If
	// no _mid_ is provided, it will return the added _COMT_ datapoints in a mid string syntax.
	MID string
	// Mapping is a optional table where mapping from TeosID to remote ID is stored. It will be used to decode
	// the TEOS ID from the remote ID.
	//
	// TIP: If mapping is not provided, it is expected that the `eqmodel.CbDataPoint.GetID()` will return a proper _teosID_.
	//
	// If a mapping table is provided and the ID could not be resolved, it will use the ID as is and hence will in practice be
	// ignored. Since mapping tables are _teosID_ = _remoteID_ this function will create a reverse mapping table.
	Mapping map[string]string
	// ComtIdMustExistInMapping is when a _COMT_ needs to be added. By default it will just add the _teosID_ e.g. COMT_C14. But
	// if the remote IDs are some other format e.g. a GUID, it has to be found in the mapping table. If it is not found, it will
	// filter out the control signal instead of adding the _COMT_.
	ComtIdMustExistInMapping bool
}

// HandleCOMT will make sure that proper _COMT_ (or COMT_Cn - where n is a circuit number) is set in the datapoints
// if it is not present and a _COMT_ is found in the _pipeCtx_. It will also make sure to strip out _COMT_ when
// no control signal is found for either global or the specific circuit(s).
//
// .Example Usage
// [source,go]
// ----
// var (
//
//	mid      string
//	modifiedMid bool
//
// )
// dps, mid, modifiedMid = providerutils.HandleCOMT( // <1>
//
//	ctx, lid, pipeCtx, dps,
//	providerutils.HandleCOMTOptions{
//		MID: pc.GetParamAsStringWithDefault(string(ifprovider.ParameterMappingIDs), ""), // <2>
//		Mapping: mapping, // <3>
//	},
//
// )
//
//	if modifiedMid {
//		pc.GetGlobalParams()[string(ifprovider.ParameterMappingIDs)] = mid // <4>
//	}
//
// ----
// <1> Handle the _COMT_ datapoints and adjust the mid string accordingly.
// <2> Get the current mid string from the provider config.
// <3> This is typically provided by the provider sdk in the target function, otherwise use it
// from the provider config mapping table.
// <4> If there are any datapoints added/removed, update the mid string in the global params.
func HandleCOMT(
	ctx ifcore.CbContext,
	lid string,
	pipeCtx map[string]any,
	dp []eqmodel.CbDataPoint,
	opts ...HandleCOMTOptions,
) ([]eqmodel.CbDataPoint, string, bool) {
	const method = "HandleCOMT"

	var (
		opt      HandleCOMTOptions
		comt     int
		mids     []string
		modified bool
		reverse  map[string]string
	)

	if len(opts) > 0 {
		opt = opts[0]
	}

	if len(opt.MID) > 0 {
		mids = strings.Split(opt.MID, " ")
	}

	if len(opt.Mapping) > 0 {
		reverse = make(map[string]string, len(opt.Mapping))

		for k, v := range opt.Mapping {
			reverse[v] = k
		}
	}

	if v, ok := pipeCtx[string(eqmodel.DataPointCommunicationTimer)]; ok {
		switch t := v.(type) {
		case int:
			comt = t
		case int64:
			comt = int(t)
		case float64:
			comt = int(t)
		case float32:
			comt = int(t)
		case string:
			if i, err := strconv.ParseInt(t, 10, 32); err == nil {
				comt = int(i)
			} else {
				log.WarnWithLocationID(ctx, lid).
					WithMethod(method).
					WithError(err).
					Str("comt", t).
					Msg("Failed to parse COMT value")
			}
		}
	}

	if comt == 0 {
		log.InfoWithLocationID(ctx, lid).
			WithMethod(method).
			Msg("No COMT valid value found in pipe context, skipping comt handling")

		return dp, opt.MID, modified
	}

	var keys []string

	if len(opt.Mapping) > 0 {
		keys = fexp.Map(dp, func(d eqmodel.CbDataPoint) string {
			id := d.GetID()

			if r, ok := reverse[id]; ok {
				return r
			} else {
				return id
			}
		})
	} else {
		keys = fexp.Map(dp, func(d eqmodel.CbDataPoint) string {
			return d.GetID()
		})
	}

	ctrSignals := eqmodel.ToCbSensorReportItems(
		eqmodel.ToSensorTypes(keys, eqmodel.AllOptimizationsControlPrincipleSensors...)...,
	)

	allComt := eqmodel.ToCbSensorReportItems(
		eqmodel.ToSensorTypes(keys, eqmodel.SensorType(eqmodel.DataPointCommunicationTimer))...,
	)

	comtNoSignal := make(collection.Set[eqmodel.SensorType], len(ctrSignals))
	signalNoComt := make(collection.Set[eqmodel.SensorType], len(allComt))

	for _, signal := range ctrSignals {
		if comt := fexp.Find(allComt, func(comt ingestionmodel.CbSensorReportItem) bool {
			return signal.Circuit == comt.Circuit
		}); comt.Sensor == "" {
			// No COMT found for this signal.
			signalNoComt.Add(eqmodel.SensorType(signal.GetID()))
		}
	}

	for _, comt := range allComt {
		if signal := fexp.Find(ctrSignals, func(signal ingestionmodel.CbSensorReportItem) bool {
			return signal.Circuit == comt.Circuit
		}); signal.Sensor == "" {
			// No signal found for this COMT.
			comtNoSignal.Add(eqmodel.SensorType(comt.GetID()))
		}
	}

	// Helper function to remove id from the mids
	removeMid := func(id string) {
		if len(mids) > 0 {
			// Remove from mid
			mids = slices.DeleteFunc(mids, func(s string) bool {
				return s == string(id)
			})
		}
	}

	// Remove all _COMT_ that do not have a corresponding control signal
	for _, comt := range comtNoSignal.All() {
		log.InfoWithLocationID(ctx, lid).
			WithMethod(method).
			Str("comt", string(comt)).
			Msgf("Removing %s since no corresponding control signal found", string(comt))

		dp = slices.DeleteFunc(dp, func(d eqmodel.CbDataPoint) bool {
			return d.GetID() == string(comt)
		})

		removeMid(string(comt))

		modified = true
	}

	now := *coremodel.NewTime32Now()

	// Add all _COMT_ that are missing (if we have a COMT in global params)
	if len(signalNoComt) > 0 {
		for _, ct := range signalNoComt.All() {
			var id string

			if circuit := ct.CircuitString(); circuit == "" {
				id = string(eqmodel.DataPointCommunicationTimer)
			} else {
				id = fmt.Sprintf(
					"%s_C%s", string(eqmodel.DataPointCommunicationTimer), ct.CircuitString(),
				)
			}

			if opt.ComtIdMustExistInMapping {
				if _, ok := opt.Mapping[id]; !ok {
					log.WarnWithLocationID(ctx, lid).
						WithMethod(method).
						Str("signal", string(ct)).
						Str("comt", id).
						Msgf("Skipping %s since it is not found in mapping, removing signal: %s", id, string(ct))
				}

				// Remove the signal

				dp = slices.DeleteFunc(dp, func(d eqmodel.CbDataPoint) bool {
					return reverse[d.GetID()] == string(ct)
				})

				removeMid(string(ct))

				modified = true

				continue
			}

			dp = append(dp,
				&eqmodel.CbDataPointImpl{
					ID:        id,
					Value:     comt,
					TimeStamp: now,
				})

			if len(mids) > 0 {
				mids = append(mids, id)
			}

			modified = true

			log.InfoWithLocationID(ctx, lid).
				WithMethod(method).
				Str("signal", string(ct)).
				Str("comt", id).
				Int("value", int(comt)).
				Msgf("Adding missing %s:%d for signal: %s", id, int(comt), string(ct))
		}
	}

	return dp, strings.Join(slices.Compact(mids), " "), modified
}
