package providerutils

import (
	"bytes"
	"errors"
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// SplitPartitionAndID takes a fully qualified id and splits it to the datapoint id and partition id.
//
// If it fails it should return the in parameter as _id_ and the _partition_ as empty string.
type SplitPartitionAndID func(fqId string) (id string, partition string)

// ToTeosIDFunc is a function that takes a datapoint and returns the TEOS ID.
//
// If the function returns an empty string, the default is used.
type ToTeosIDFunc func(dp eqmodel.CbDataPoint) string

// ReportContext is the configuration how to perform
// the reporting.
type ReportContext struct {
	// SplitPartitionAndIDFunc is optional but when submitted it will be used
	// to determine the ID and partition by submitting the `eqmodel.CbDataPoint.GetID()`
	// to the function.
	//
	// CAUTION: If `nil` the _ID_ is _REQUIRED_ to be a _ID_ without any partition.
	SplitPartitionAndIDFunc SplitPartitionAndID
	// ToTeosID is the function that will be used to determine the TEOS ID. If none
	// is provided, the default `toTEOSID` is used.
	ToTeosID ToTeosIDFunc
	// Operation is the operation that has been performed
	Operation *providermodel.Operation
	// ProviderConfig is the used `ifprovider.Config` being used
	ProviderConfig *providermodel.ProviderConfigImpl
	// ProviderOperation is the direction of the provider
	ProviderOperation locationmodel.ProviderOperation
	// DataPoints is the handled datapoints
	// CAUTION: Make sure that the `eqmodel.CbDataPoint.GetID()` is on the same
	// format as _wantedSensor_ parameter since comparisons will be done on it.
	DataPoints []eqmodel.CbDataPoint
	// WantedSensors is optional. If not provided, `ProviderConfig.ExtractSensors()`
	// will be used. This is used to determine which of the datapoints is wanted.
	//
	// NOTE: The reporting system will determine which where optional amongst the
	// wanted sensors.
	WantedSensors []string
	// Body is optional the body when receiving or transmitting the data points.
	Body []byte
	// MapperWithoutPartition is a flag to state when mapping the datapoint id
	// from or to the remote id.
	//
	// When set to `true``, the partition is not present in the mapping section.
	// However, when is set to false, it will the partition is present in the mapping.
	//
	// This is used to translate a `eqmodel.CbDataPoint.GetID()` to a _TEOS ID_.
	MapperWithoutPartition bool
	// Err is optional an error that did occur during the operation. It will be used
	// log out in every report.
	Err error
	// mandatoryDP is the mandatory sensors that must be present or otherwise reported
	// as missing.
	mandatoryDP []eqmodel.CbDataPoint
	// mandatoryID is the mandatory sensorsIDs matching the `mandatoryDP`
	mandatoryID []string
	// optionalDP is the optional sensors that can be present but will not be reported as
	// missing.
	optionalDP []eqmodel.CbDataPoint
	// optionalID is the optional sensorsIDs matching the `optionalDP`
	optionalID []string
	// optionalSet has the same contents as _optionalID_ but is a set for faster lookup.
	optionalSet map[string]bool
}

// IsOptional checks if the _teosID_ is optional or mandatory sensor.
func (ctx *ReportContext) IsOptional(teosID string) bool {
	_, optional := ctx.optionalSet[teosID]
	return optional
}

// DataPointReport is helper function to log `missingDataPointReport`, `importDataPointReport`
// or `exportDataPointReport`
//
// If an error is returned, it is when no datapoints at all is found. If the configuration is set to
// _pre-provisioned_ the return code `cberror.ErrorFailedInPreProvisionedState` otherwise
// `cberror.ErrorInvalidNumberOfDatapoints`.
func DataPointReport(
	context ifcore.CbContext,
	config *ReportContext,
) cberror.Error {
	// Make sure that the body is valid JSON
	if len(config.Body) > 0 {
		if !jsonutils.IsJSONObjectOrArrayPrefix(config.Body) {
			buf := &bytes.Buffer{}
			buf.WriteString(`{ "body": "`)
			buf.Write(config.Body)
			buf.WriteString(`" }`)
			config.Body = buf.Bytes()
		}
	}

	// Use all sensors if none is provided
	if len(config.WantedSensors) == 0 {
		config.WantedSensors = config.ProviderConfig.ExtractSensors(config.Operation)
	}

	// Determine the configuration status
	pst := ifprovider.ProvisionedState(
		config.ProviderConfig.GetParamAsStringWithDefault(
			string(ifprovider.ParameterProvisionedState),
			string(ifprovider.ProvisionedStateProvisioned),
		))

	// Prepare optional and mandatory sensors
	if optError := toMandatoryAndOptional(context, config); optError != nil {
		return optError
	}

	// Handling missing data points
	lenErrs := eqmodel.SizeDataPointErrors(config.DataPoints)
	mandatoryDataPointLen := len(config.mandatoryDP)

	// Missing DataPoint Report is emitted both for mandatory and optional
	//
	// NOTE: When importing configuration -> TEOS we do not emit missing data points!
	if (len(config.DataPoints) != len(config.WantedSensors) || lenErrs != 0) &&
		config.ProviderOperation != locationmodel.ProviderOperationConfigurationIn {
		if report, ok := generateMissingDataPointReport(context, config); ok {
			logReport(
				context,
				zerolog.InfoLevel,
				pst,
				report,
				fmt.Sprintf(
					"Missing sensors while operation '%s' from/to provider",
					string(config.ProviderOperation),
				),
			)
		}
	}

	// No mandatory data points found or all mandatory are errors
	if (mandatoryDataPointLen == 0 && len(config.mandatoryID) > 0) ||
		(mandatoryDataPointLen == lenErrs && lenErrs > 0) {
		lid := config.ProviderConfig.GetParamAsStringWithDefault(
			string(ifprovider.ParameterLocationID),
			"",
		)

		var code int
		var msg string

		switch config.ProviderOperation {
		case locationmodel.ProviderOperationSensorValueIn:
			code = cberror.ErrorZeroDataPointImported
			msg = "No mandatory data points imported from remote endpoint"
		case locationmodel.ProviderOperationSensorValueOut:
			code = cberror.ErrorZeroDataPointExported
			msg = "No mandatory data points exported to remote endpoint"
		case locationmodel.ProviderOperationDataPointDiscovery:
			code = cberror.ErrorZeroDataPointImported
			msg = "No mandatory discovery datapoints imported from remote endpoint"
		case locationmodel.ProviderOperationConfigurationOut:
			code = cberror.ErrorZeroConfigurationItemsExported
			msg = "No mandatory configuration items where exported to remote endpoint"
		case locationmodel.ProviderOperationConfigurationIn:
			code = cberror.ErrorZeroConfigurationItemsImported
			msg = "No mandatory configuration items where imported from remote endpoint"
		default:
			code = cberror.ErrorZeroDataPointImported
			msg = fmt.Sprintf(
				"No mandatory data points for operation: %s",
				config.ProviderOperation,
			)
		}

		config.Err = cberror.NewCbErrorfWithProps(
			context.Service(),
			code,
			config.Err,
			map[string]interface{}{
				"lid": lid,
			},
			"%s", msg,
		)

		if pst == ifprovider.ProvisionedStatePreProvisioned {
			config.Err = cberror.NewCbErrorInPreProvisionedMode(
				context.Service(), config.Err,
				map[string]interface{}{
					"lid": lid,
				},
			)
		}
	}

	switch config.ProviderOperation {
	case locationmodel.ProviderOperationSensorValueIn:
		report := generateImportDataPointReport(context, config)

		logReport(
			context, zerolog.InfoLevel, pst, report,
			"Imported the following sensors from provider",
		)
	case locationmodel.ProviderOperationSensorValueOut:
		report := generateExportDataPointReport(context, config)

		logReport(
			context, zerolog.InfoLevel, pst, report,
			"Exported the following sensors from provider",
		)
	case locationmodel.ProviderOperationDataPointDiscovery:
		report := generateImportDataPointReport(context, config)

		logReport(
			context, zerolog.InfoLevel, pst, report,
			"Discovered the following sensors from provider",
		)
	case locationmodel.ProviderOperationConfigurationOut:
		report := generateExportDataPointReport(context, config)

		logReport(
			context, zerolog.InfoLevel, pst, report,
			"Exported the following configuration from TEOS -> provider -> remote endpoint",
		)
	case locationmodel.ProviderOperationConfigurationIn:
		report := generateImportDataPointReport(context, config)

		logReport(
			context, zerolog.InfoLevel, pst, report,
			"Imported the following configuration from remote endpoint -> provider -> TEOS",
		)
	}

	if config.Err != nil {
		var cbError cberror.Error
		if errors.As(config.Err, &cbError) {
			return cbError
		}

		return cberror.NewCbErrorf(
			context.Service(), -1, config.Err, "%s", config.Err.Error(),
		)
	}

	return nil
}
