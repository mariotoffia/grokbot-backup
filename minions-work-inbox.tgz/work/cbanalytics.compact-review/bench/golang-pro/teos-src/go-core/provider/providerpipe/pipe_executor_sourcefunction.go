package providerpipe

import (
	"maps"
	"sync"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/fexp"
	"github.com/Thiink-LLC/teos/go-core/utils/maputils"
)

// SourceFunctionInvoker is a struct that has functionality to setup and invoke the `SourceFunction` registered
// for the current provider pipe.
//
// Make sure to properly populate each field in the `SourceFunctionInvoker` struct before invoking the `Invoke` method.
//
// This type supports three different ways of invoking a source function on a provider:
//
// 1. Invoke - It will invoke the source function with the default mechanism or with `providermodel.Selector` if present.
// 2. InvokeWithSingleSelector - It will invoke the source function with a single selector and return the result.
// 3. InvokeParallel - It will invoke the source function with multiple selectors in parallel and return the result.
type SourceFunctionInvoker struct {
	// PipeContext is the pipe context object.
	PipeContext map[string]any
	// ProviderConfig is the provider config.
	ProviderConfig *providermodel.ProviderConfigImpl
	// Operation is the full operation object that the `OperationName` is pointing to.
	Operation *providermodel.Operation
	// OperationName is the operation to perform.
	OperationName string
	// Ctx is the current context to use in all operations.
	Ctx ifcore.CbContext
	// Credentials is the credentials to use when invoking the source function on the provider.
	Credentials any
	// SourceFunction is the source function to invoke.
	SourceFunction SourceFunction
	// DelayedReportContexts if _MMO_ is anything else then explicit, it will store the
	// report contexts here since the MID and mapping section will be processed at a later
	// point in time.
	DelayedReportContexts []*providerutils.ReportContext
}

// Include return all entires in _src_ that matches the _selections_.
func (sfi *SourceFunctionInvoker) Include(
	src map[string]any,
	selections []providermodel.Selection,
) map[string]any {
	if len(src) == 0 || len(selections) == 0 {
		return nil
	}

	filtered := make(map[string]any, len(selections))

	for _, sel := range selections {
		if v, ok := src[sel.RemoteId]; ok {
			filtered[sel.RemoteId] = v
		}
	}

	return filtered
}

// Exclude will return all entries in _src_ that does not match the _selections_.
func (sfi *SourceFunctionInvoker) Exclude(
	src map[string]any,
	selections []providermodel.Selection,
) map[string]any {
	if len(src) == 0 {
		return nil
	}

	if len(selections) == 0 {
		return maps.Clone(src)
	}

	filtered := make(map[string]any, len(src))

	for k, v := range src {
		found := false

		for _, sel := range selections {
			if sel.RemoteId == k {
				found = true
				break
			}
		}

		if !found {
			filtered[k] = v
		}
	}

	return filtered
}

// InvokeWithSingleSelector will invoke a single _selector_ and return the result. This
// is a optimized path for when only a single selector is present. If multiple _selector_(s) are found in map, it
// will return an error. If zero, it will return an empty map and no selection.
//
// It will return the original provider key of which the values was returned under. Independent, the returned map is
// always a ID: value pairing.
//
// When the _dataSet_ is _"$global" it return an empty map and no selection since it cannot invoke a provider when the data set is global.
func (sfi *SourceFunctionInvoker) InvokeWithSingleSelector(
	selector map[string]providermodel.Selector,
	pipeCtx map[string]any,
) (map[string]any, string, []providermodel.Selection, cberror.Error) {
	if len(selector) == 0 {
		return nil, "", nil, nil
	}

	if pipeCtx == nil {
		pipeCtx = sfi.PipeContext
	}

	if len(selector) > 1 {
		return nil, "", nil, cberror.NewCbErrorf(
			sfi.Ctx.Service(), 400, nil,
			"Multiple selectors found, expected only one",
		)
	}

	dataSet, sel := maputils.First(selector)

	if src, key, err := sfi.Invoke(sfi.PipeContext, dataSet, &sel); err != nil {
		return nil, "", nil, err
	} else {
		if selection, err := sfi.Select(pipeCtx, src, sel.Selectors); err != nil {
			return nil, "", nil, err
		} else {
			return src, key, selection, nil
		}
	}
}

// InvokeParallel will invoke multiple _selectors_ in parallel. It will merge the results and return them.
//
// The returned `providermodel.Selection` is filtered so only distinct `providermodel.Selection.TeosId` are returned.
//
// It will return the original provider key of which the values was returned under. Independent, the returned map is
// always a ID: value pairing.
//
// This will automatically detect _"$global"_ and run that last on _all_ loaded data from provider.
func (sfi *SourceFunctionInvoker) InvokeParallel(
	selectors map[string]providermodel.Selector,
	pipeCtx map[string]any,
) (map[string]any, string, []providermodel.Selection, cberror.Error) {
	// We have multiple selectors -> run all of them and merge the results
	var (
		all       = map[string]any{}
		selection []providermodel.Selection
		globals   map[string]providermodel.SelectObject
		errors    []cberror.Error
		vg        sync.WaitGroup
		mtx       sync.Mutex
		key       string
	)

	// Run in parallel
	for dataSet, selector := range selectors {
		if dataSet == "$global" {
			globals = selector.Selectors

			continue
		}

		vg.Add(1)

		go func(selector providermodel.Selector, dataSet string, pipeCtx map[string]any) {
			src, k, err := sfi.Invoke(pipeCtx, dataSet, &selector)

			var sel []providermodel.Selection

			// Do selection outside of lock to avoid contention
			if err == nil {
				sel, err = sfi.Select(pipeCtx, src, selector.Selectors)
			}

			mtx.Lock()

			if err != nil {
				errors = append(errors, err)
			} else {
				all = maputils.Merge(all, src)
				selection = append(selection, sel...)
				key = k
			}
			mtx.Unlock()

			vg.Done()
		}(selector, dataSet, maps.Clone(sfi.PipeContext)) // Shallow clone pipeCtx since we're modifying it.
	}

	vg.Wait()

	if len(errors) > 0 {
		return nil, "", nil, cberror.NewCbCompositeErrorf(
			sfi.Ctx.Service(), cberror.ErrorProviderUnableExecutePipeline,
			cberror.FromCbErrorsToErrors(errors), nil, /*properties*/
			"Failed to obtain data from provider, first error: %s",
			errors[0].Error(),
		)
	}

	if len(globals) > 0 {
		if sel, err := sfi.Select(pipeCtx, all, globals); err != nil {
			return nil, "", nil, err
		} else {
			selection = append(selection, sel...)
		}
	}

	return all, key, fexp.DistinctFunc(selection, func(a, b providermodel.Selection) bool {
		return a.TeosId == b.TeosId
	}), nil
}

// Invoke will invoke the provider source func. If _selector_ object is present, it will shallow clone
// the providerContext and set the `providermodel.Selector` object in the `ifprovider.ParameterSelectGroupings` key (_SELECT_).
//
// If the _pipeContext_ is not set, it will use the `SourceFunctionInvoker.PipeContext` object instead.
//
// When the _selector_ object is present, it will examine if the `providermodel.Selector.DataSet` is a cbeval expression. If so
// it will evaluate it and use the result as the `providermodel.Selector.DataSet` instead. It will use the cloned _pipeContext_ as
// parameters to the evaluation.
//
// CAUTION: If the provider is a standard src provider, i.e. it puts an array of objects into src key. It checks if this array is a
// `[]eqmodel.CbDataPoint`. If such is the case , it use the `eqmodel.CbDataPoint.GetID()` as key and the object as value. If not,
// it will use the index as key and the object as value if the provider returns "source" map or just key, value map.
//
// The above is only true when a `selector` has been passed. If no selector is passed, it will return the source as is.
//
// It will return the key the data was originally returned under, if any.
//
// The _dataSet_ *must* be supplied and is the name of the data set to use. This is the same as `SourceInstruction.Select` key. If
// the _dataSet_ is _"$global" it returns a empty map, and empty key since it will not invoke a provider when the dataset is global.
func (sfi *SourceFunctionInvoker) Invoke(
	pipeContext map[string]any,
	dataSet string,
	selector *providermodel.Selector,
) (map[string]any, string, cberror.Error) {
	if dataSet == "$global" {
		return nil, "", nil
	}

	if pipeContext == nil {
		pipeContext = sfi.PipeContext
	}

	if selector != nil {
		pipeContext = maps.Clone(pipeContext)

		sel := *selector

		if cbeval.IsCbEvalExpression(dataSet) {
			if ds, err := cbeval.Evaluate[string](sfi.Ctx, dataSet, pipeContext, true /*cache*/, cbeval.EvalCacheLangFullCB); err != nil {
				return nil, "", cberror.NewCbErrorf(
					sfi.Ctx.Service(),
					1,
					err,
					"Failed to evaluate selector dataSet expression: %s, err: %s",
					dataSet,
					err.Error(),
				)
			} else {
				dataSet = ds
			}
		}

		pipeContext[string(ifprovider.ParameterSelectGroupings)] = providermodel.SelectorWithDataSet{
			Selector: sel,
			DataSet:  dataSet,
		}
	}

	src, err := sfi.SourceFunction(
		sfi.Ctx, sfi.OperationName, sfi.Operation, sfi.ProviderConfig, pipeContext, sfi.Credentials,
	)

	if err != nil {
		return nil, "", cberror.NewCbErrorf(
			sfi.Ctx.Service(), cberror.ErrorProviderUnableExecutePipeline, err,
			"Could not obtain data from provider, error: %s", err.Error(),
		)
	}

	if drp, ok := src["_report"].([]*providerutils.ReportContext); ok {
		sfi.DelayedReportContexts = append(sfi.DelayedReportContexts, drp...)
	}

	if selector == nil {
		var key string

		if _, ok := src["src"]; ok {
			key = "src"
		} else if _, ok := src["source"]; ok {
			key = "source"
		}

		return src, key, nil
	}

	if src, ok := src["src"].([]eqmodel.CbDataPoint); ok {
		// Convert to map
		newSrc := make(map[string]any, len(src))

		for _, v := range src {
			newSrc[v.GetID()] = v
		}

		return newSrc, "src", nil
	}

	if source, ok := src["source"].(map[string]any); ok {
		return source, "source", nil
	}

	return src, "", nil
}
