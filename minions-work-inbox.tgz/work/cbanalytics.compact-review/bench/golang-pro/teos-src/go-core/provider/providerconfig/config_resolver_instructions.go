package providerconfig

import (
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/pipeutils"

	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
)

// CreateMapping will create a JSON object that is a SetInstruction to be incorporated
// in a Pipeline. If nothing is to be mapped, an empty string is returned.
//
// The result of an mapping is put under "mapped" key in context. If no filtering
// is present in cfg it will put it under generate instead.
func CreateMapping(
	cfg ifprovider.ConfigFull,
	mappingDirection providermodel.MappingDirection,
) string {
	m := cfg.GetMapping()
	l := len(m)

	if l == 0 {
		return ""
	}

	s := "\"set-mapping\": {\n"

	target := "mapped."
	if !cfg.HasFilter() {
		target = targetGenerate
	}

	optionals, err := utils.ResolveOptionalSensorsAsSet(
		cfg,
		cfg.ExtractMappingSensors(),
		"", /*operation*/
	)

	if nil != err {
		if l, ok := logger.ClsLogCognito(
			zerolog.ErrorLevel, "CreateMapping", logger.LDTDevOps, logger.LISUnclassified,
		); ok {
			l.Str("error", err.Error()).Msg("failed to get optional sensors")
		}
	}

	for key, value := range m {
		var left, right string
		if mappingDirection == providermodel.MappingDirectionRightAssign {
			left = value
			right = key
		} else {
			left = key
			right = value
		}

		if strings.Contains(left, "\"") {
			left = strings.ReplaceAll(left, "\"", "\\\"")
		}

		if target != "" && !strings.HasPrefix(left, target) {
			left = target + left
		}

		expression := fmt.Sprintf("source['%s']", right)
		if written, ok := pipeutils.GetStringExpression(value); ok {
			expression = written
		}

		if optionals != nil && optionals[key] {
			// The reading may not be there. The assignment is written in the long
			// form so that it happens only when it is.
			s += fmt.Sprintf(
				`"%s": { "if": "=exist(source['%s'])", "value": "=%s" }`, left, right, expression)
		} else {
			s += fmt.Sprintf(`"%s": "=%s"`, left, expression)
		}

		l--
		if l > 0 {
			s += ",\n"
		} else {
			s += "\n"
		}
	}

	s += "}"
	return s
}

// CreateFilter will create a JSON object that is a SetInstruction to be incorporated
// in a Pipeline. If nothing is to be filtered, an empty string is returned.
//
// If no mapping exist it will use source as the key to index the elements. Otherwise it
// will use mapped as the key. It will always write to generate since provider must
// have that section if not overridden and that section shall generate to target context key.
func CreateFilter(
	cfg ifprovider.ConfigFull,
	mappingDirection providermodel.MappingDirection,
) string {
	// Check if we have filters
	filters := cfg.GetFilters()
	l := len(filters)
	if l == 0 {
		return ""
	}

	s := "\"set-filter\": {\n"

	source := "mapped"
	if !cfg.HasMapping() {
		source = "source"
	}

	for key, value := range filters {
		var left, right string
		if mappingDirection == providermodel.MappingDirectionRightAssign {
			left = value
			right = key
		} else {
			left = key
			right = value
		}

		var fqkey string
		if !strings.HasPrefix(left, targetGenerate) {
			fqkey = targetGenerate + left
		} else {
			fqkey = left
		}

		s += fmt.Sprintf(
			`"%s": { "if": "=%s", "value": "=%s['%s']" }`,
			fqkey,
			right,
			source,
			left,
		)

		l--
		if l > 0 {
			s += ",\n"
		} else {
			s += "\n"
		}
	}

	s += "}"
	return s
}

// CreateGeneratorTemplate looks up the template and renders it as a JSON payload
// to be included into the pipeline context to be referenced by a GeneratorInstruction.
//
// This instruction may be rendered using CreateGeneratorInstruction.
//
// If a full generator template exists matching the _ID_ it is returned. Otherwise
// it will create a template based on `GeneratorPrototype` if _ID_ matches such
// set of prototypes. Hence the *full* template has _PRECEDENCE_!
//
// If full generator template do not exist, it adheres to `ParameterMappingIDs`,
// `ParameterGeneratorProtoTypeIDs` and `ParameterProviderRequiredGeneratorProtoTypeIDs` to
// create a *new* generator template. This is done, if `GeneratorPrototype` can be found
// matching the _ID_ (_see respective parameter for info how this is done_).
//
// If fails to produce a generator template, it returns an error.
//
// If a static generator template cannot be created, it will signal that through setting
// the _delayCreation_ to `true` and hence the creation of the generator template is
// delayed until the map/filter is executed and then know which sensors to include in
// the template.
func CreateGeneratorTemplate(
	ctx ifcore.CbContext,
	cfg ifprovider.ConfigFull,
	templateID, genProtoFallbackID string,
	logEnabled bool,
	pipeCtx map[string]any,
) (result string, delayCreation bool, err cberror.Error) {
	//
	generatorMode := utils.GetTemplateGeneratorMode(cfg, "" /*operation*/)

	if generatorMode == ifprovider.GeneratorTemplateGenerationDynamic {
		return "", true, nil
	}

	if !cfg.HasGenerate(templateID) {
		if !cfg.HasGenerate(genProtoFallbackID) {
			return "", false, cberror.NewCbErrorfWithProps(
				ctx.Service(),
				404, /*notFound*/
				nil,
				map[string]interface{}{
					cberror.PropertyProvider: ctx.Provider(),
				},
				"no generator template/prototype found for ID: %s or fallBackID: %s",
				templateID,
				genProtoFallbackID,
			)
		}
	}

	if t, ok := cfg.GetGenerate()[templateID]; ok {
		if l, ok := logger.ClsLog(zerolog.TraceLevel, "CreateGeneratorTemplate", logger.LDTUntyped, logger.LISUnclassified, ctx); ok &&
			logEnabled {
			l.Msgf("Use full Generator Template (instead of prototype):\n%s", t)
		}

		return t, false, nil
	}

	// Gather which IDs to use from generator prototypes
	pid := utils.ResolveMaxSensorIDsForTemplateGenerator(cfg)

	// Since Config Operations may Clear, hence no data elements may be present
	needPID := true //nolint:staticcheck // QF1007: current form is more readable

	if templateID == string(locationmodel.ProviderOperationClimateControlEventOut) ||
		templateID == string(locationmodel.ProviderOperationConfigurationIn) {
		needPID = false
	}

	if len(pid) == 0 && needPID {
		// No sensor IDs at all → no mandatory sensors → cancel pipeline gracefully
		// This handles empty source data with empty MID/map configurations
		if log.IsEnabled(zerolog.DebugLevel) {
			log.Debug(ctx).
				WithMethod("CreateGeneratorTemplate").
				Str("op", templateID).
				Msg("no sensor IDs found, cancelling pipeline (no mandatory sensors, no data)")
		}

		return "", false, cberror.NewCancelPipelineError(
			ctx.Service(),
			cberror.CancelReasonNoMandatorySensorsNoData,
		)
	}

	if generatorMode != ifprovider.GeneratorTemplateGenerationStatic {
		// Check if there are any optional parameters -> must render within pipeline
		if utils.HasOptionalSensorParameter(cfg, "" /*operation*/) {
			optionals, resolveError := cfg.GetOptionalSensors(nil /*operation*/, pid)

			if resolveError != nil {
				return "", false, cberror.NewCbErrorf(
					ctx.Service(), 1, resolveError,
					"failed to resolve optional sensors",
				)
			}

			if len(optionals) > 0 {
				return "", true, nil
			}
		}
	}

	// No optional/forced static -> render static generator template
	goTemplate := utils.IsGoGeneratorTemplate(cfg)

	if goTemplate {
		result, err = utils.RenderGeneratorGoTemplateByName(
			ctx,
			cfg,
			templateID,
			genProtoFallbackID,
			pid,
			pipeCtx,
			logEnabled,
		)
	} else {
		result, err = utils.RenderGeneratorPrototypeByName(ctx, cfg, templateID, genProtoFallbackID, pid)
	}

	if err != nil {
		return result, false, err
	}

	if log.IsEnabled(zerolog.DebugLevel) {
		log.Debug(ctx).
			WithMethod("CreateGeneratorTemplate").
			WithBody(result).
			AsJSON("ceID", pid).
			Str("id", templateID).
			Str("fallbackID", genProtoFallbackID).
			Bool("goTemplate", goTemplate).
			Msg("generated generator template")
	}

	return result, false, nil
}

// CreateGeneratorInstruction creates a JSON block to be parsed as a GeneratorInstruction.
//
// The _genref_ is the key in the pipe context that the generator template is stored and is to be
// used in the `gen` instruction. The _mode_ is one of the GeneratorPolicyMode values to use when
// executing the `gen` instruction. If none is supplied, the default is "fail".
//
// Valid modes: "fail", "report", "remove", "error-silent", "error-report".
//
// The function returns a string of which is the GeneratorInstruction. Since the GeneratorInstruction
// is referring to the context template, it is needed here as the genref argument.
//
// For example a GenerateInstruction JSON could be rendered as this:
//
//	"gen-ds": {
//	  "key": "target",
//	  "from": "=genref",
//	  "mode": "error-silent"
//	}
//
// The context needs to be loaded with key specified in the genref variable to hold the generator template
// rendered using CreateGeneratorTemplate function.
//
// If the _delayedGeneratorTemplate_ parameter is set to `true` it will emit a function that will
// generate the template and do the actual generation in one swoop.
func CreateGeneratorInstruction(
	genref, mode string,
	delayedGeneratorTemplate bool,
	genTemplateType ifprovider.GeneratorTemplateType,
	mappingDirection providermodel.MappingDirection,
) string {
	if delayedGeneratorTemplate {
		// Dynamically create the generator template. If mandatory data
		// is omitted, it will still be added to the static template.
		if genTemplateType == ifprovider.GeneratorTemplateTypeGoTemplate {
			// The only difference is that it will select the whole context instead
			// of just the pipeCtx.generate section (as for native gen templates)
			genref = fmt.Sprintf(
				`gentemplate(_ctx.CbContext(), :.:, _cfg.operation, false, '%s', pc)`,
				mappingDirection,
			)
		} else {
			genref = fmt.Sprintf(
				`gentemplate(_ctx.CbContext(), generate, _cfg.operation, false, '%s', pc)`,
				mappingDirection,
			)
		}
	}

	if mode == "" {
		mode = "fail"
	}

	return fmt.Sprintf(`{ "key": "target", "from": "=%s", "mode": "%s" }`, genref, mode)

}

// CreateMarshalInstruction creates a `parser.MarshalInstruction` _JSON_ that can be used
// in a _JSON_ pipeline.
func CreateMarshalInstruction(
	marshalExpression string,
) string {
	return fmt.Sprintf(`{ "target": "=%s" }`, marshalExpression)

}
