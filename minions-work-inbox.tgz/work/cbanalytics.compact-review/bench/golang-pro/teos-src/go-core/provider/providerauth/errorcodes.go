package providerauth

const (
	// ErrorCredentialsMissingAPIKey is when a API key is required in the credentials but is not present.
	ErrorCredentialsMissingAPIKey = 1
	// ErrorCredentialsMissingToken is when a token (e.g. Access Token) is required in the credentials but is not present.
	//
	// This is typically fetched from remote provider but is stored in the local cache.
	ErrorCredentialsMissingToken = 2
	// ErrorCredentialsMissingUsername is when a username is required in the credentials but is not present.
	ErrorCredentialsMissingUsername = 3
	// ErrorCredentialsMissingPassword is when a password is required in the credentials but is not present.
	ErrorCredentialsMissingPassword = 4
	// ErrorFailedToUseToken is when the token (e.g. Access Token) is present in the credentials but is invalid and cannot
	// be used.
	ErrorFailedToUseToken = 5
	// ErrorCredentialsUnknownType is a generic error when the credentials type is unknown.
	ErrorCredentialsUnknownType = 6
	// ErrorCredentialsMissing is when credentials is completely missing and is required.
	ErrorCredentialsMissing = 7
)
