package cbsensorsrc

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

// DefaultCbSensorPipeSource will convert a config change event into a map of `ingestionmodel.CbSensorReportItem`.
// The key is the _TEOS_ Id and the value is a `ingestionmodel.CbSensorReportItem`.
func DefaultCbSensorPipeSource() providerpipe.SourceFunction {
	//
	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		if sensors, m, err := extractEventFromPayload(ctx, pipeCtx); err != nil {
			return nil, err
		} else {
			return map[string]any{
				"src":    sensors,
				"source": m,
			}, nil
		}
	}
}

func extractEventFromPayload(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
) (map[string]ingestionmodel.CbSensorReportItem, map[string]any, cberror.Error) {
	//
	evt, ok := pipeCtx[ifprovider.PipeContextKeyEvent]

	if !ok {
		return nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorFailToFindEventInPipeContext, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Missing event in pipe context",
		)
	}

	event, ok := evt.(*cbevent.ProviderEvent)

	if !ok {
		return nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting *cbevent.ProviderEvent, got %T", evt,
		)
	}

	if event.PayloadType != cbevent.PayloadSensorReportItemMap {
		return nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting '%s', got '%s'", cbevent.PayloadSensorReportItemMap, event.PayloadType,
		)
	}

	var (
		sensors map[string]ingestionmodel.CbSensorReportItem
		m       map[string]any
	)

	if err := json.Unmarshal(*event.Payload, &sensors); err != nil {
		return nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, err,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Failed to unmarshal payload",
		)
	}

	_ = json.Unmarshal(*event.Payload, &m)

	return sensors, m, nil
}
