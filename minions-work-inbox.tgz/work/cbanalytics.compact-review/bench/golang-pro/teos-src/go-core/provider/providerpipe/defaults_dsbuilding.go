package providerpipe

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/interfaces/iftarget"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot/awsmgriot"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// DefaultDsFullBuildingSourceFunc is a source function to load a `dsmodel.DsFullBuilding` from a `*cbevent.ProviderEvent`.
// and supply it to the pipeline.
func DefaultDsFullBuildingSourceFunc() SourceFunction {
	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		//
		event, err := extractEventFromPayload(ctx, pipeCtx)

		if err != nil {
			return nil, err
		}

		// Set context variables for dryrun
		if event.DryRun || op.GetParamsAsBool("dryrun") {
			ctx.SetValue(provider.ProviderCtxDryRun, true)
		}

		ds, err := eventToBuildingDeviceShadow(ctx, event)

		if err != nil {
			return nil, err
		}

		// If payload contains _rpt_ -> override global param
		if ds.State != nil && ds.State.Desired != nil && ds.State.Desired.ReportType != "" {
			pc.Params[string(ifprovider.ParameterReportType)] = ds.State.Desired.ReportType
		}

		if ds.State != nil && ds.State.Desired != nil {
			return map[string]any{
				"src":    ds.State.Desired,
				"source": ds.State.Desired.Sensors,
			}, nil
		}

		return map[string]any{}, nil
	}
}

// defaultTarget is used when an error occurred or no target was specified.
//
// It default to building and `iftarget.TargetDataTypeDsBuilding`.
var defaultTarget = &providermodel.Target{
	Names:          []string{"building"},
	TargetDataType: string(iftarget.TargetDataTypeDsBuilding),
	TargetName:     "",
}

// DefaultDsBuildingImportTargetFunction is a default function to update the device shadow and
// do reporting for importing sensors for buildings.
//
// NOTE: This function requires that the following keys are present in the calling `ifcore.CbContext`:
//   - `provider.ProviderCtxEndpoint` (*url.URL)
//   - `provider.ProviderCtxDryRun` (bool)
//
// This function adheres to the following global parameters:
//
//   - `ifprovider.ParameterLocationID` (string)
//   - `ifprovider.ParameterProvisionedState` (string)
//   - `ifprovider.ParameterReportType` (string)
//   - `ifprovider.ParameterTarget` (string) - second attempt if not found in operation
//
// It also adheres to the operation specific parameters:
//
//   - `ifprovider.ParameterCheckTimeStampOnUpdate` (bool)
//   - `ifprovider.ParameterLocalCheckAndReportTimeStamp` (bool)
//   - `ifprovider.ParameterReportTimeStamp` (bool)
//   - `ifprovider.ParameterTarget` (string) - first attempt
func DefaultDsBuildingImportTargetFunction() TargetFunction {
	return func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		// Get the ds building
		ds := providerutils.ExtractDsBuilding(target)
		if ds == nil {
			return cberror.NewCbErrorf(
				ctx.Service(), cberror.ErrorProviderEventPayloadNotFound, nil,
				"DsBuildingImportTargetFunction: no DsBuilding found in target map",
			)
		}

		buildingID := pc.GetParamAsStringWithDefault(
			string(ifprovider.ParameterLocationID), "",
		)

		targets, _ := providerutils.GetDsFullBuildingTargets(pc, eop, defaultTarget)

		if len(target) == 0 {
			targets = []providermodel.Target{*defaultTarget}
		}

		targetDeviceShadowName := targets[0].Names

		checkDeviceShadowTimestamp := eop.GetParamsAsBool(
			string(ifprovider.ParameterCheckTimeStampOnUpdate),
		)
		localCheckReportTimestamp := eop.GetParamsAsBool(
			string(ifprovider.ParameterLocalCheckAndReportTimeStamp),
		)
		uploadTsSensorDataToTarget := eop.GetParamsAsBool(
			string(ifprovider.ParameterReportTimeStamp),
		)

		pst := ifprovider.ProvisionedState(pc.GetParamAsStringWithDefault(
			string(ifprovider.ParameterProvisionedState),
			string(ifprovider.ProvisionedStateProvisioned),
		))

		// Set the report type from _RPT_ config or default
		reportType := providerutils.ReportDsBuildingType(
			pc.GetParamAsStringWithDefault(string(ifprovider.ParameterReportType), ""),
		)

		if reportType == "" {
			if operation == string(locationmodel.ProviderOperationSensorValueIn) {
				reportType = providerutils.ReportDsBuildingInbound
			} else {
				reportType = providerutils.ReportDsBuildingAcknowledge
			}
		}

		var timeStampPolicy []byte
		if data, ok := pc.PolicyData[operation]; ok {
			timeStampPolicy = []byte(data)
		}

		deviceShadowEndpoint := utils.GetURLFromContext(
			ctx,
			provider.ProviderCtxEndpoint,
		)

		dryRun := utils.GetBoolFromContext(
			ctx,
			provider.ProviderCtxDryRun,
		)

		if deviceShadowEndpoint == nil {
			log.WarnWithLocationID(ctx, buildingID).
				WithMethod("DsBuildingImportTargetFunction").
				Msg("Endpoint not found in context, will auto probe endpoint")

		}

		_, err := providerutils.ReportDsBuilding(
			ctx,
			timeStampPolicy,
			reportType,
			ctx.Provider(),
			buildingID,
			checkDeviceShadowTimestamp,
			localCheckReportTimestamp,
			uploadTsSensorDataToTarget,
			pst,
			targetDeviceShadowName[0],
			deviceShadowEndpoint,
			awsmgriot.NewAWSDSManager(ctx),
			ds,
			dryRun)

		return err
	}
}

// DsBuildingAfterFunction is a `AfterFunction` that extracts the `ifprovider.PipeContextKeyEvent`
// in the current pipeContext. If found, it will use that extract what to acknowledge to the
// `providerutils.Report` function.
//
// This reports on the _desired_ state only!!
func DsBuildingReportAfterFunction() AfterFunction {
	return func(
		ctx ifcore.CbContext,
		pipeCtx map[string]any,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		target map[string]any) cberror.Error {
		//
		event, err := extractEventFromPayload(ctx, pipeCtx)

		if err != nil {
			return err
		}

		ds, err := eventToBuildingDeviceShadow(ctx, event)

		if err != nil {
			return err
		}

		if ds.BuildingID == "" {
			ds.BuildingID = pc.GetParamAsStringWithDefault(
				string(ifprovider.ParameterLocationID), "",
			)
		}

		if ds.BuildingID == "" {
			return cberror.NewCbErrorf(
				ctx.Service(), 400, nil,
				"BuildingID not found in event or config",
			)
		}

		pst := ifprovider.ProvisionedState(pc.GetParamAsStringWithDefault(
			string(ifprovider.ParameterProvisionedState),
			string(ifprovider.ProvisionedStateProvisioned),
		))

		// Set the report type from _RPT_ config or default
		reportType := providerutils.ReportDsBuildingType(pc.GetParamAsStringWithDefault(
			string(ifprovider.ParameterReportType),
			string(providerutils.ReportDsBuildingAcknowledge),
		))

		// If payload contains _rpt_ use that instead
		if ds.State != nil && ds.State.Desired != nil && ds.State.Desired.ReportType != "" {
			reportType = providerutils.ReportDsBuildingType(
				ds.State.Desired.ReportType,
			)
		}

		deviceShadowEndpoint := utils.GetURLFromContext(
			ctx,
			provider.ProviderCtxEndpoint,
		)

		dryrun := utils.GetBoolFromContext(
			ctx,
			provider.ProviderCtxDryRun,
		)

		if deviceShadowEndpoint == nil {
			log.WarnWithLocationID(ctx, ds.BuildingID).
				WithMethod("DsBuildingImportTargetFunction").
				Msg("Endpoint not found in context")

			return cberror.NewCbErrorfWithProps(
				ctx.Service(), cberror.ErrorRemoteEndpointIsNotSet, nil,
				map[string]any{cberror.PropertyProvider: ctx.Provider()},
				"Endpoint not found in context",
			)
		}

		targets, _ := providerutils.GetDsFullBuildingTargets(pc, op, defaultTarget)

		if len(target) == 0 {
			targets = []providermodel.Target{*defaultTarget}
		}

		targetDeviceShadowName := targets[0].Names

		// Guard: this function reports on desired state only
		if ds.State == nil || ds.State.Desired == nil {
			return cberror.NewCbErrorf(
				ctx.Service(), cberror.ErrorProviderEventPayloadNotFound, nil,
				"DsBuildingReportAfterFunction requires state.desired but it is nil for buildingID: %s",
				ds.BuildingID,
			)
		}

		_, err = providerutils.ReportDsBuilding(ctx,
			nil, /*timestampPolicy*/
			reportType,
			ctx.Provider(),
			ds.BuildingID,
			false, /*checkDeviceShadowTimeStamp*/
			false, /*checkLocalTimeStamp*/
			false, /*uploadSensorTsToTarget*/
			pst,
			targetDeviceShadowName[0],
			deviceShadowEndpoint,
			awsmgriot.NewAWSDSManager(ctx),
			ds.State.Desired,
			dryrun,
		)

		return err
	}
}

// DefaultPipelineExecutorForOperationRequest is a default creator of a `ProviderPipeExecutorImpl` for a given operation.
func DefaultPipelineExecutorForOperationRequest() PipelineExecutorForOperationRequest {
	return func(
		ctx ifcore.CbContext,
		pipeline *ProviderPipelineImpl,
		operation string,
		args map[string]any,
		pc ifprovider.ConfigFull,
		allowMutateGlobalParams bool,
	) (executor *ProviderPipeExecutorImpl, err cberror.Error) {

		pipe, ok := pipeline.operations[operation]
		if !ok {
			return nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), cberror.ErrProviderOperationNotFound, nil,
				map[string]any{"pn": ctx.Provider()},
				"Cannot find operation: %s in pipeline", operation,
			)
		}

		pipe.Owner = pipeline

		builder := NewExecutorBuilder(ctx).
			UsePipe(pipe).
			UseConfig(pc).
			UseInput(args).
			UseAutoLogging()

		if allowMutateGlobalParams {
			builder.AllowMutateGlobalParams()
		}

		return builder.Build(), nil
	}
}

func eventToBuildingDeviceShadow(
	ctx ifcore.CbContext,
	event *cbevent.ProviderEvent,
) (*dsmodel.DsFullBuilding, cberror.Error) {
	//
	if event.PayloadType != cbevent.PayloadBuildingDeviceShadow {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorProviderEventIncorrectType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting PayloadBuildingDeviceShadow, got '%s'", event.PayloadType,
		)
	}

	if event.Payload == nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorProviderEventPayloadNotFound, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting payload in event but got nil",
		)
	}

	data := []byte(*event.Payload)

	var ds *dsmodel.DsFullBuilding
	err := json.Unmarshal(data, &ds)

	if err != nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorModelUnmarshalBuilding, err,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Failed to unmarshal *dsmodel.DsFullBuilding",
		)
	}

	if ds == nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorModelUnmarshalBuilding, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Unmarshaled DsFullBuilding is nil (payload was JSON null)",
		)
	}

	return ds, nil
}

func extractEventFromPayload(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
) (*cbevent.ProviderEvent, cberror.Error) {
	//
	evt, ok := pipeCtx[ifprovider.PipeContextKeyEvent]

	if !ok {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorFailToFindEventInPipeContext, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Missing event in pipe context",
		)
	}

	event, ok := evt.(*cbevent.ProviderEvent)

	if !ok {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting *cbevent.ProviderEvent, got %T", evt,
		)
	}

	return event, nil
}
