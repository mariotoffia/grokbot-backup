package providercontext_test

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
)

// mockRawInvoker satisfies runtime.RawInvoker for testing.
type mockRawInvoker struct {
	called  bool
	payload []byte
	out     any
}

var _ runtime.RawInvoker = (*mockRawInvoker)(nil)

func (m *mockRawInvoker) InvokeRaw(_ context.Context, payload []byte) (any, error) {
	m.called = true
	m.payload = payload
	return m.out, nil
}

func TestProviderContextBuilder_UseInvoker_ReturnsInvoker(t *testing.T) {
	mock := &mockRawInvoker{out: "ok"}

	// Verify UseInvoker returns the builder for fluent chaining
	b := providercontext.NewProviderContextBuilder().UseInvoker(mock)
	require.NotNil(t, b)
}

func TestProviderContextBuilder_UseInvoker_DelegatesInvokeRaw(t *testing.T) {
	mock := &mockRawInvoker{out: "result"}

	// Verify the invoker correctly delegates InvokeRaw calls
	out, err := mock.InvokeRaw(context.Background(), []byte(`{"key":"val"}`))
	require.NoError(t, err)
	require.True(t, mock.called)
	require.Equal(t, []byte(`{"key":"val"}`), mock.payload)
	require.Equal(t, "result", out)
}

// Verify that a nil RawInvoker satisfies the interface type constraint.
func TestRawInvoker_NilInterface(t *testing.T) {
	var inv runtime.RawInvoker
	require.Nil(t, inv)
}
