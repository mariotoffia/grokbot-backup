package s3_test

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	s3loader "github.com/Thiink-LLC/teos/go-core/provider/providercontext/loaders/userconfig/s3"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

const unitBucket = "config-bucket"

// fakeS3 answers a HeadBucket for unitBucket with _bucketStatus_ and every
// object request with _objectStatus_. It counts the HeadBucket requests.
func fakeS3(t *testing.T, objectStatus, bucketStatus int) (ifcore.CbContext, *atomic.Int32) {
	t.Helper()

	testenv.Use(t, testenv.EnvDefaults)

	var bucketChecks atomic.Int32

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodHead && strings.Trim(r.URL.Path, "/") == unitBucket {
			bucketChecks.Add(1)
			w.WriteHeader(bucketStatus)

			return
		}

		w.WriteHeader(objectStatus)
	}))
	t.Cleanup(srv.Close)

	cfg := aws.Config{
		Region:       "eu-west-1",
		Credentials:  credentials.NewStaticCredentialsProvider("test", "test", ""),
		BaseEndpoint: aws.String(srv.URL),
	}

	c, err := ctx.NewContext("s3-loader-unit", "test", cbenv.DevLocal, true, ctx.OptAWSSetConfig(cfg, true))
	require.Nil(t, err)

	return c, &bucketChecks
}

// TestLoadTellsAMissingBucketFromAMissingKey covers each way a download can
// fail. S3 gives a missing bucket and a missing key the same 404, so an
// optional loader asks for the bucket before it decides there is no config.
func TestLoadTellsAMissingBucketFromAMissingKey(t *testing.T) {
	tests := []struct {
		name             string
		optional         bool
		objectStatus     int
		bucketStatus     int
		wantCode         int // 0 means no error
		wantBucketChecks int32
	}{
		{"optional, key missing, bucket exists", true, http.StatusNotFound, http.StatusOK, 0, 1},
		{"optional, bucket missing", true, http.StatusNotFound, http.StatusNotFound, http.StatusNotFound, 1},
		{"optional, bucket check denied", true, http.StatusNotFound, http.StatusForbidden, http.StatusForbidden, 1},
		{"optional, download denied", true, http.StatusForbidden, http.StatusOK, http.StatusForbidden, 0},
		{"required, key missing", false, http.StatusNotFound, http.StatusOK, http.StatusNotFound, 0},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c, bucketChecks := fakeS3(t, tt.objectStatus, tt.bucketStatus)

			loader := s3loader.NewS3ProviderConfigLoader(c, unitBucket, "prefix", tt.optional)

			cfg, err := loader.Load(c, "location")

			assert.Equal(t, "", cfg)
			assert.Equal(t, tt.wantBucketChecks, bucketChecks.Load(), "HeadBucket requests")

			if tt.wantCode == 0 {
				assert.Nil(t, err)
				return
			}

			require.NotNil(t, err)
			assert.Equal(t, tt.wantCode, err.Code())
		})
	}
}
