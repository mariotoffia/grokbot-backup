package providerutils

import (
	"encoding/json"
	"fmt"
	"net/url"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/reportmodel"
	cbprovider "github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// ReportDsBuildingType specifies the report type
type ReportDsBuildingType string

const (
	// ReportDsBuildingInbound specifies that this new values reported inbound
	ReportDsBuildingInbound ReportDsBuildingType = "inbound"
	// ReportDsBuildingAcknowledge specifies that this is a acknowledge of a set
	ReportDsBuildingAcknowledge ReportDsBuildingType = "acknowledge"
	// ReportDsBuildingAcknowledgeSilent is same as `ReportDsBuildingAcknowledge` but
	// will not update the device shadow.
	ReportDsBuildingAcknowledgeSilent ReportDsBuildingType = "acknowledge-silent"
)

// ReportDsBuilding do report a `dsmodel.DsBuilding` to using the supplied _mgr_.
//
// If it fails, it will return an `cberror.Error` otherwise the _JSON_ submitted to the
// _mgr_ is returned.
//
// When _reportType_ is set to `ReportDsBuildingAcknowledgeSilent`, it will do everything
// except the acknowledge onto the device shadow. This is useful when only outbound data
// is to be provisioned and reported on and the device shadow already contains the correct data.
//
// Otherwise it will update the device shadow with the new values and
// _<provider>:<id>:<action>:acknowledge_ the in the _clientToken_.
func ReportDsBuilding(context ifcore.CbContext, /*  NOSONAR */
	timestampPolicy []byte,
	reportType ReportDsBuildingType,
	providerName, lid string,
	checkDeviceShadowTimestamp,
	checkLocalTimestamp,
	uploadSensorTsToTarget bool,
	pst ifprovider.ProvisionedState,
	targetDeviceShadowName string,
	ep *url.URL,
	mgr *mgriot.DSManager,
	ds *dsmodel.DsBuilding,
	dryrun bool) (js string, err cberror.Error) {
	// Create the IoT core / device shadow manager
	dm := configureDsManager(
		context,
		reportType,
		mgr,
		pst,
		providerName,
		lid,
		targetDeviceShadowName,
		ep,
	)

	if log.IsEnabledWithLocationID(zerolog.DebugLevel, lid) {
		log.DebugWithLocationID(context, lid).
			WithMethod(string(reportType)+":ReportDsBuilding").
			WithDataType(logger.LDTDeveloper).
			WithBody(ds).
			Str("pst", string(pst)).
			Bool("check-local-timestamp", checkLocalTimestamp).
			Bool("check-device-shadow-timestamp", checkDeviceShadowTimestamp).
			Bool("upload-sensor-ts-to-target", uploadSensorTsToTarget).
			Str("report-type", string(reportType)).
			Msg("Enter - ReportDsBuilding")
	}

	original := ds
	if len(ds.SensorTimestamps) > 0 {
		ds = ds.Clone()

		if (checkLocalTimestamp || checkDeviceShadowTimestamp) && timestampPolicy != nil {
			if checker, err := NewPolicyTimeStampChecker(lid, timestampPolicy); err == nil {
				if checkLocalTimestamp {
					filterUsingLocalTimestamps(context, checker, ds, lid)
				}
				if checkDeviceShadowTimestamp && !dryrun {
					_ = filterUsingDeviceShadow(
						context,
						checker,
						lid,
						ds,
						mgr,
					)
				}
			} else {
				log.WarnWithLocationID(context, lid).
					WithMethod("ReportDsBuilding").
					WithDataType(logger.LDTDevOps).
					WithError(err).
					Str("pst", string(pst)).
					Msg("Failed to create timestamp checker")
			}
		}
	}

	if !uploadSensorTsToTarget {
		// RTS is false, hence cleanse the device original timestamps
		// and use device metadata for any TS check.
		ds.SensorTimestamps = nil

		if log.IsEnabledWithLocationID(zerolog.TraceLevel, lid) {
			l := log.TraceWithLocationID(context, lid).
				WithMethod("ReportDsBuilding").
				WithDataType(logger.LDTDeveloper).
				WithBody(ds).
				Str("pst", string(pst))

			if ds.SensorTimestamps != nil {
				l.Msg("Removing sensor timestamps (since RDS is false)")
			} else {
				l.Msg("No sensor timestamps to remove from locationID")
			}
		}

		ds.SensorTimestamps = nil
	}

	now := coremodel.NewTime32Now().CbTime32UTC().RFC3339()
	operation := "sv"

	if reportType == ReportDsBuildingAcknowledge ||
		reportType == ReportDsBuildingAcknowledgeSilent {
		operation = "esv"
	}

	if len(ds.Sensors) == 0 {
		reportFailed(context, lid, operation, now, targetDeviceShadowName, pst, original, dm)
		return
	}

	out_data, marshalError := json.Marshal(ds)

	if marshalError != nil {
		log.WarnWithLocationID(context, lid).
			WithMethod("ReportDsBuilding").
			WithDataType(logger.LDTDeveloper).
			WithError(marshalError).
			Str("pst", string(pst)).
			Msgf("Failed to marshal the dsmodel.DsBuilding")

		reportFailed(context, lid, operation, now, targetDeviceShadowName, pst, original, dm)

		err = cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToMarshalBuildingShadow, marshalError,
			"Failed to marshal the ds '%#v' for building: '%s'  error: %s",
			ds, lid, marshalError.Error(),
		)

		return
	}

	if dryrun || reportType == ReportDsBuildingAcknowledgeSilent {
		mode := "dryrun"
		if reportType == ReportDsBuildingAcknowledgeSilent {
			mode = string(ReportDsBuildingAcknowledgeSilent)
		}

		if log.IsEnabledWithLocationID(zerolog.DebugLevel, lid) {
			log.DebugWithLocationID(context, lid).
				WithMethod("ReportDsBuilding").
				WithDataType(logger.LDTDeveloper).
				WithBody(ds).
				Str("pst", string(pst)).
				Str("mode", mode).
				Bool("dryrun", dryrun).
				Msgf("Dryrun mode or mode == silent, skipping device shadow update")
		}

		return
	}

	// Set return parameter
	js = string(out_data)

	// configure the IoT core / device shadow manager
	dm.UseReportedStatePayload(out_data, "ingest" /*action*/, true /*includeClientToken*/)

	// Update the device shadow
	if dm.UpsertReported().Error() != nil {
		log.WarnWithLocationID(context, lid).
			WithMethod("ReportDsBuilding").
			WithDataType(logger.LDTDevOps).
			WithBody(dm.ReportedStatePayload()).
			WithError(dm.Error()).
			Str("pst", string(pst)).
			Msgf("Failed to update the device shadow")

		reportFailed(context, lid, operation, now, targetDeviceShadowName, pst, original, dm)

		err = cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToUpdateBuildingShadow, dm.Error(),
			"Failed to update the device shadow for building %s with doc: %s, error: %s",
			lid, string(dm.ReportedStatePayload()), dm.Error().Error(),
		)

		return
	}

	if log.IsEnabledWithLocationID(zerolog.InfoLevel, lid) {
		l := log.InfoWithLocationID(context, lid).
			WithMethod(string(reportmodel.ReportTypeCoreTargetDataPointReport))

		success := map[string]*reportmodel.CoreDataPointInfo{}
		failed := map[string]*reportmodel.CoreDataPointInfo{}

		for sensorID := range ds.Sensors {
			success[sensorID] = &reportmodel.CoreDataPointInfo{
				Value: ds.Sensors[sensorID],
			}

			if sensorTimeStamp, ok := original.SensorTimestamps[sensorID]; ok {
				success[sensorID].TimeStamp = sensorTimeStamp.RFC3339()
			} else {
				success[sensorID].TimeStamp = now
			}
		}

		// Check if we have some filtered, set those as failed since not updated
		err := cberror.NewCbErrorf(
			context.Service(), cberror.ErrorFilteredOutDataPoint, nil, "TTL",
		)

		for sensorID := range original.Sensors {
			if _, ok := ds.Sensors[sensorID]; !ok {
				failed[sensorID] = &reportmodel.CoreDataPointInfo{
					Value: original.Sensors[sensorID],
					Error: err,
				}

				if sensorTimeStamp, ok := original.SensorTimestamps[sensorID]; ok {
					failed[sensorID].TimeStamp = sensorTimeStamp.RFC3339()
				} else {
					failed[sensorID].TimeStamp = now
				}
			}
		}

		data := json.RawMessage(dm.ReportedStatePayload())
		operationSuccess := reportmodel.CoreTargetDataPointReportOk

		if len(failed) > 0 {
			if len(success) > 0 {
				operationSuccess = reportmodel.CoreTargetDataPointReportPartial
			} else {
				operationSuccess = reportmodel.CoreTargetDataPointReportFail
			}
		}

		l.WithBody(&reportmodel.CoreTargetDataPointReport{
			Operation: operation,
			Success:   operationSuccess,
			Body:      &data,
			Info: &reportmodel.CoreTargetDataPointReportInfo{
				Target:    reportmodel.CoreTargetDataPointReportTargetDeviceShadow,
				SubTarget: targetDeviceShadowName,
				TargetID:  getTargetID(lid, dm),
			},
			DataPoints: &reportmodel.CoreTargetDataPointReportBody{
				CountSuccess: len(success),
				CountFailed:  len(failed),
				Success:      success,
				Failed:       failed,
			},
		}).
			Str("pst", string(pst)).
			Msgf(
				"Updated device shadow for building: %s", lid,
			)
	}

	return
}

func reportFailed(
	context ifcore.CbContext,
	lid, operation, now, targetDeviceShadowName string,
	pst ifprovider.ProvisionedState,
	original *dsmodel.DsBuilding,
	dm *mgriot.DSManager) {
	failed := map[string]*reportmodel.CoreDataPointInfo{}

	for sensorID := range original.Sensors {
		failed[sensorID] = &reportmodel.CoreDataPointInfo{
			Value: original.Sensors[sensorID],
		}

		if sensorTimeStamp, ok := original.SensorTimestamps[sensorID]; ok {
			failed[sensorID].TimeStamp = sensorTimeStamp.RFC3339()
		} else {
			failed[sensorID].TimeStamp = now
		}
	}
	if log.IsEnabledWithLocationID(zerolog.InfoLevel, lid) {
		log.InfoWithLocationID(context, lid).
			WithMethod(string(reportmodel.ReportTypeCoreTargetDataPointReport)).
			WithDataType(logger.LDTDevOps).
			WithBody(&reportmodel.CoreTargetDataPointReport{
				Operation: operation,
				Success:   reportmodel.CoreTargetDataPointReportFail,
				Info: &reportmodel.CoreTargetDataPointReportInfo{
					Target:    reportmodel.CoreTargetDataPointReportTargetDeviceShadow,
					SubTarget: targetDeviceShadowName,
					TargetID:  getTargetID(lid, dm),
				},
				DataPoints: &reportmodel.CoreTargetDataPointReportBody{
					CountFailed: len(failed),
					Failed:      failed,
				},
			}).
			Str("pst", string(pst)).
			Msgf(
				"No sensors to report for building: '%s' skipping device shadow update", lid,
			)
	}

}

func getTargetID(lid string, dm *mgriot.DSManager) string {
	if dm == nil {
		return lid
	}

	url := dm.Endpoint()
	if url == nil {
		return lid
	}

	return fmt.Sprintf("%s/%s/building", url.String(), dm.EncodedDeviceName())
}

func configureDsManager(
	c ifcore.CbContext,
	reportType ReportDsBuildingType,
	mgr *mgriot.DSManager,
	pst ifprovider.ProvisionedState,
	provider, lid, targetDeviceShadowName string,
	ep *url.URL) *mgriot.DSManager {
	dataManager := mgr.
		UseDeviceName(lid).
		UseProvider(provider).
		UseShadowName(targetDeviceShadowName)

	if reportType == ReportDsBuildingAcknowledge {
		dataManager.UseCustomClientToken(provider + ":" + utils.GenerateID() + ":acknowledge")
	}

	if nil == ep {
		dataManager.DiscoverEndpoint()

		// Cache discovered endpoint in context for subsequent pipeline phases
		if discovered := dataManager.Endpoint(); discovered != nil {
			c.SetValue(cbprovider.ProviderCtxEndpoint, discovered)
		}
		log.WarnWithLocationID(c, lid).
			WithMethod("configureDsManager").
			WithDataType(logger.LDTDevOps).
			Str("pst", string(pst)).
			Msgf(
				"No endpoint configured for this lambda, please set it manually using CB_REP environment variable, auto discovered %v",
				dataManager.Endpoint(),
			)
	} else {
		dataManager.UseEndpoint(ep)
	}

	return dataManager
}
