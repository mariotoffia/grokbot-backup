package esvprovider

import (
	"encoding/json"

	"github.com/aws/aws-lambda-go/events"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// processSQSEvent iterates the records and `Unmarshal` to `cbevent.SensorValueOutboundEvent` that is sent to the
// `exportSensorValues` function.
//
// It will return the last error encountered but will process all records regardless.
func (esv *ESVPlugin) processSQSEvent(
	c ifcore.CbContext,
	ds *events.SQSEvent,
	endpoint string,
	dryrun bool) error {
	var err error
	var lasterr error

	for _, record := range ds.Records {
		if record.Body != "" {
			var evt cbevent.SensorValueOutboundEvent
			err = json.Unmarshal([]byte(record.Body), &evt)

			if err != nil {
				err = jsonutils.ToVerboseJSONError([]byte(record.Body), err, nil)

				log.Error(c).
					WithMethod("processSQSEvent").
					WithBody(record.Body).
					WithError(err).
					Msg("Failed to create SensorValueOutboundEvent from body (skipping)")
			} else {
				if dryrun {
					evt.DryRun = dryrun
				}

				if evt.Endpoint == "" {
					evt.Endpoint = endpoint
				}

				err = esv.exportSensorValues(c, &evt)

				if nil != err {
					lasterr = err
				}
			}
		}
	}

	return lasterr
}

// exportSensorValues is the main runner that dispatches to sub-functions to perform the export of the
// sensor values using the plugin implementation methods.
func (esv *ESVPlugin) exportSensorValues(
	c ifcore.CbContext,
	evt *cbevent.SensorValueOutboundEvent) error {
	// Plugin takes *all* responsibilities to process this event.
	if esv.pluginCaps.BooleanByName(CapsProviderSVOPluginExportSensorValues, false) {
		if pex, ok := esv.plugin.(SensorValuesOutboundPluginExt); ok {
			return pex.ExportSensorValues(c, evt)
		}

		return cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderImplementationMissing, nil,
			"Misconfigured provider, expected to implement SensorValuesOutboundPluginExt",
		)
	}

	ds := &evt.BuildingData
	if err := ds.SetBuildingID(c); err != nil {
		if l, ok := logger.ClsLog(zerolog.WarnLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
			l.Msgf("Could not get buildingID, error: %s", err.Error())
		}

		return err
	}

	if l, ok := logger.ClsLog(zerolog.TraceLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
		l.Msgf("buildingID: %s", ds.BuildingID)
	}

	if l, ok := logger.ClsLog(zerolog.DebugLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
		if ds.State != nil && ds.State.Delta != nil && ds.State.Reported != nil {
			old := ds.State.Delta.TimeZone
			ds.State.Delta.TimeZone = ds.State.Reported.TimeZone // Just for logging

			logger.LogObject(l, "body", ds.State.Desired)
			logger.LogObjectf(l, "buildingId", ds.BuildingID, "exporting sensor values for building")

			ds.State.Delta.TimeZone = old
		} else if ds.State != nil {
			logger.LogObject(l, "body", ds.State.Desired)
			logger.LogObjectf(l, "buildingId", ds.BuildingID, "exporting sensor values for building")
		}
	}

	cfg := ""
	if len(evt.Config) > 0 {
		cfg = evt.ToConfigString(0)
	}

	if cfg == "" {
		if l, ok := logger.ClsLog(zerolog.TraceLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
			l.Msgf("buildingID: %s has no config, unable to perform export", ds.BuildingID)
		}

		return cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderUnableToExportCfg, nil,
			"buildingID: %s has no config, unable to perform export", ds.BuildingID,
		)
	}

	if l, ok := logger.ClsLog(zerolog.TraceLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
		l.Msgf("buildingID: %s, config: %s", ds.BuildingID, cfg)
	}

	p, err := esv.createPipeLine(c)

	if err != nil {
		return err
	}

	if err := esv.executeExport(c, p, cfg, evt); err != nil {
		return err
	}

	return nil
}
