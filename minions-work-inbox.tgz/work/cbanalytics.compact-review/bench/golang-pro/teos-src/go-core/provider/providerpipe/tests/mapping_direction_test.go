package tests

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

// =============================================================================
// MAPPING DIRECTION TESTS
// =============================================================================
//
// These tests validate the behavior when mapping direction is configured
// correctly vs incorrectly.
//
// With MappingDirectionLeftAssign:
//   - CORRECT: map = { "TEOS_ID": "Provider_ID" }
//   - WRONG:   map = { "Provider_ID": "TEOS_ID" }
//
// The wrong direction causes secondary errors that mask the root cause.
// See SECONDARY_ERRORS.md for documentation of these cascading failures.
//
// =============================================================================

// TestCorrectMappingDirectionSucceeds verifies that with the correct mapping
// direction (TEOS_ID: Provider_ID), the pipeline processes sensor values
// successfully.
//
// Test Flow:
// ─────────────────────────────────────────────────────────────────────────────
//
//	Source Data          Mapping Config         Result
//	─────────────        ──────────────         ──────
//	sensorTemp=22.5  →   IDT: sensorTemp    →   IDT=22.5 ✓
//	outdoorTemp=-5.2 →   ODT: outdoorTemp   →   ODT=-5.2 ✓
//
// ─────────────────────────────────────────────────────────────────────────────
func TestCorrectMappingDirectionSucceeds(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Simulate source data with PROVIDER IDs
						return []eqmodel.CbDataPoint{
							&eqmodel.CbDataPointImpl{ID: "sensorTemp", Value: 22.5},
							&eqmodel.CbDataPointImpl{ID: "outdoorTemp", Value: -5.2},
						}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "correct-direction"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))
	require.NoError(t, result[0].Error, "Pipeline should succeed with correct mapping direction")
	require.Contains(t, result[0].Result, "target")

	target := result[0].Result["target"].(*dsmodel.DsBuilding)
	require.NotNil(t, target)

	// Verify TEOS IDs are present with correct values
	assert.Equal(t, "Europe/Stockholm", target.TimeZone)
	assert.Equal(t, float64(22.5), target.Sensors["IDT"], "IDT should be mapped from sensorTemp")
	assert.Equal(t, float64(-5.2), target.Sensors["ODT"], "ODT should be mapped from outdoorTemp")
}

// TestWrongMappingDirectionGivesDescriptiveError verifies that when the mapping
// direction is wrong (Provider_ID: TEOS_ID instead of TEOS_ID: Provider_ID),
// the system produces an error.
//
// WRONG Configuration:
// ─────────────────────────────────────────────────────────────────────────────
//
//	map: {
//	  "sensorTemp": "IDT",    ← WRONG! Should be "IDT": "sensorTemp"
//	  "outdoorTemp": "ODT"    ← WRONG! Should be "ODT": "outdoorTemp"
//	}
//	MID: "sensorTemp outdoorTemp"  ← Generated from wrong map keys
//
// ─────────────────────────────────────────────────────────────────────────────
//
// This test documents the CURRENT behavior (secondary errors).
// See SECONDARY_ERRORS.md for the cascade of errors this causes.
func TestWrongMappingDirectionGivesDescriptiveError(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Source data with PROVIDER IDs
						return []eqmodel.CbDataPoint{
							&eqmodel.CbDataPointImpl{ID: "sensorTemp", Value: 22.5},
							&eqmodel.CbDataPointImpl{ID: "outdoorTemp", Value: -5.2},
						}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "wrong-direction"}`).
		Build()

	result := pe.Execute()

	// The pipeline should fail or produce incorrect results due to mapping mismatch
	require.Equal(t, 1, len(result))

	// Document the current behavior - this test captures what happens with wrong mapping
	// The error may be a secondary error (symptom) rather than the root cause.
	// See SECONDARY_ERRORS.md for documentation of these cascading failures.
	if result[0].Error != nil {
		// If there's an error, it's likely one of the secondary errors documented
		// in SECONDARY_ERRORS.md. The test passes to document this behavior.
		t.Logf("Error with wrong mapping direction: %v", result[0].Error)

		// Check if error message contains hints about the mapping issue
		errMsg := result[0].Error.Error()
		containsMappingHint := false

		// These are the secondary errors we expect to see
		secondaryErrors := []string{
			"unknown parameter",
			"failed to get policy data",
			"sensor",
			"not mapped",
			"missing",
		}

		for _, hint := range secondaryErrors {
			if containsIgnoreCase(errMsg, hint) {
				containsMappingHint = true
				t.Logf("Secondary error detected: contains '%s'", hint)
				break
			}
		}

		assert.True(t, containsMappingHint || result[0].Error != nil,
			"Wrong mapping should produce an error or secondary error symptoms")
	} else {
		// If no error but wrong results, the sensors won't be correctly mapped
		if target, ok := result[0].Result["target"].(*dsmodel.DsBuilding); ok {
			// With wrong mapping, TEOS IDs (IDT, ODT) should NOT be present
			// because the map keys are provider IDs, not TEOS IDs
			_, hasIDT := target.Sensors["IDT"]
			_, hasODT := target.Sensors["ODT"]

			// Document that wrong mapping leads to missing expected sensors
			if !hasIDT && !hasODT {
				t.Log("Wrong mapping direction resulted in missing expected TEOS IDs (IDT, ODT)")
			}
		}
	}
}

// containsIgnoreCase checks if s contains substr (case insensitive)
func containsIgnoreCase(s, substr string) bool {
	return len(s) >= len(substr) &&
		(s == substr ||
			len(substr) == 0 ||
			(len(s) > 0 && containsIgnoreCaseImpl(s, substr)))
}

func containsIgnoreCaseImpl(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if equalFoldAt(s, i, substr) {
			return true
		}
	}
	return false
}

func equalFoldAt(s string, start int, substr string) bool {
	for j := 0; j < len(substr); j++ {
		c1 := s[start+j]
		c2 := substr[j]
		if c1 != c2 && toLower(c1) != toLower(c2) {
			return false
		}
	}
	return true
}

func toLower(c byte) byte {
	if c >= 'A' && c <= 'Z' {
		return c + 32
	}
	return c
}

// TestRightAssignMappingDoesNotTriggerInvertedError verifies that when using
// MappingDirectionRightAssign, the inverted mapping detection does NOT trigger.
//
// CONTEXT: In real outbound/export handlers:
//   - They use UseSource() + UseTargetWithReport() (NOT UseSourceWithReport)
//   - Map is TEOS_ID: Provider_ID (e.g., "COMT": "1!6WHH6DKH3CCVW-")
//   - They use MappingDirectionRightAssign
//
// The inverted mapping detection was added to UseSourceWithReport/UseSourceMapWithReport
// which are ONLY used by inbound handlers. This test verifies the direction-aware
// guard works correctly - ensuring the check is skipped for RightAssign even if
// UseSourceWithReport is used (defensive programming).
//
// See: go-services/providers/eastbound/climatixic/handlers/esv/main.go
// for a real esv example.
func TestRightAssignMappingDoesNotTriggerInvertedError(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	// Track if source function was called
	sourceWasCalled := false

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				// Use RightAssign (outbound direction)
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						sourceWasCalled = true
						// Return data - with RightAssign the check should not trigger
						return []eqmodel.CbDataPoint{
							&eqmodel.CbDataPointImpl{ID: "sensorTemp", Value: 22.5},
							&eqmodel.CbDataPointImpl{ID: "outdoorTemp", Value: -5.2},
						}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueOut).
		UsePipeline(*pipeline).
		// Use the right-assign profile with esv operation
		FromUserConfig(`{"profile": "right-assign"}`).
		Build()

	result := pe.Execute()

	// The key assertion: with RightAssign, the inverted mapping detection
	// should NOT trigger, so we should get past the sensor extraction phase.
	// The error (if any) should NOT be about inverted mapping.
	if result.HasError() {
		errMsg := result[0].Error.Error()
		assert.NotContains(t, errMsg, "mapping_direction_inverted",
			"RightAssign should not trigger inverted mapping detection")
		assert.NotContains(t, errMsg, "MappingDirectionLeftAssign",
			"RightAssign should not mention LeftAssign in error")
		t.Logf("Error (not inverted mapping): %v", result[0].Error)
	}

	// The source should be called because the inverted mapping check is skipped
	assert.True(t, sourceWasCalled, "Source function should have been called with RightAssign")
}
