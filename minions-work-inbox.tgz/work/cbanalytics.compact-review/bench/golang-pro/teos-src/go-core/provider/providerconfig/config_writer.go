package providerconfig

import (
	"bytes"
	"strings"

	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// CfgWriter supports writing configuration that may be
// serialized onto any media.
type CfgWriter struct {
	Buffer           *bytes.Buffer
	Error            cberror.Error
	pc               *providermodel.ProviderConfigImpl
	gen              map[string]string
	genproto         map[string]providermodel.GeneratorPrototypeImpl
	genprototemplate map[string]string
	pipe             map[string]string
	policydata       map[string]string
	scripts          map[string][]byte
	context          ifcore.CbContext
	pretty           bool
}

// NewConfigWriter creates a new config writer
func NewConfigWriter(context ifcore.CbContext) *CfgWriter {
	return NewConfigWriterBuffer(context, bytes.NewBufferString(""))
}

// NewConfigWriterBuffer creates a new config writer using the in param
// buffer to do the write operations onto.
func NewConfigWriterBuffer(context ifcore.CbContext, buffer *bytes.Buffer) *CfgWriter {
	return &CfgWriter{
		Buffer:           buffer,
		context:          context,
		gen:              map[string]string{},
		genproto:         map[string]providermodel.GeneratorPrototypeImpl{},
		genprototemplate: map[string]string{},
		pipe:             map[string]string{},
		policydata:       map[string]string{},
		scripts:          map[string][]byte{},
	}
}

// Pretty will set the writer to pretty print the output.
func (cw *CfgWriter) Pretty() *CfgWriter {
	cw.pretty = true
	return cw
}

// AddProviderConfig will add a provider config to the writer.
// If the provider config contains generator templates, pipes
// those will be extracted and added to respective collection.
func (cw *CfgWriter) AddProviderConfig(pc *providermodel.ProviderConfigImpl) *CfgWriter {
	cw.pc = pc

	if nil != pc.Generate {
		for key, value := range pc.Generate {
			cw.AddGenerator(key, value)
		}
	}

	if len(pc.GenProtoTemplates) > 0 {
		for key, value := range pc.GenProtoTemplates {
			cw.AddGeneratorPrototypeTemplate(key, value)
		}
	}

	if len(pc.PolicyData) > 0 {
		for key, value := range pc.PolicyData {
			cw.AddPolicyData(key, value)
		}
	}

	if len(pc.GenProto) > 0 {
		for name, value := range pc.GenProto {
			for id, prototype := range value {
				cw.AddGeneratorPrototype(name, ":TS:"+id, prototype)
			}
		}
	}

	if len(pc.GenProtoTs) > 0 {
		for name, value := range pc.GenProtoTs {
			for id, prototype := range value {
				cw.AddGeneratorPrototype(name, id, prototype)
			}
		}
	}

	if nil != pc.Pipe {
		for key, value := range pc.Pipe {
			cw.AddPipe(key, value)
		}
	}

	return cw
}

func (cw *CfgWriter) AddGeneratorPrototype(name, id, prototype string) *CfgWriter {
	if _, ok := cw.genproto[name]; !ok {
		cw.genproto[name] = providermodel.GeneratorPrototypeImpl{}
	}

	cw.genproto[name][id] = prototype

	return cw
}

func (cw *CfgWriter) AddPolicyData(name string, data string) *CfgWriter {
	cw.policydata[name] = data
	return cw
}

// AddGeneratorPrototypeTemplate adds a generator prototype template to the collection
func (cw *CfgWriter) AddGeneratorPrototypeTemplate(name string, template string) *CfgWriter {
	cw.genprototemplate[name] = template
	return cw
}

// AddGenerator adds a generator template to the collection
func (cw *CfgWriter) AddGenerator(name string, template string) *CfgWriter {
	cw.gen[name] = template
	return cw
}

// AddPipe adds a pipe definition to the collection
func (cw *CfgWriter) AddPipe(name string, pipe string) *CfgWriter {
	cw.pipe[name] = pipe
	return cw
}

func (cw *CfgWriter) Write() *CfgWriter {
	written := false

	if nil != cw.pc {
		cw.marshalJSON(cw.pc)
		if nil != cw.Error {
			return cw
		}

		written = true
	}

	for key, value := range cw.gen {
		if err := cw.writeString(ConfTypeGeneratorTemplate, key, value, written); err != nil {
			cw.Error = err
			return cw
		}

		written = true
	}

	for key, value := range cw.genprototemplate {
		if err := cw.writeString(ConfTypeGeneratorPrototypeTemplate, key, value, written); err != nil {
			cw.Error = err
			return cw
		}

		written = true
	}

	for name, value := range cw.genproto {
		var sb strings.Builder

		for id, prototype := range value {
			sb.WriteString(id + ": " + prototype + "\n")
		}

		if err := cw.writeString(ConfTypeGeneratorPrototype, name, sb.String(), written); err != nil {
			cw.Error = err
			return cw
		}

		written = true
	}

	for key, value := range cw.policydata {
		if err := cw.writeString(ConfTypePolicyData, key, value, written); err != nil {
			cw.Error = err
			return cw
		}

		written = true
	}

	for key, value := range cw.scripts {
		if err := cw.writeString(ConfTypeScript, key, string(value), written); err != nil {
			cw.Error = err
			return cw
		}

		written = true
	}

	for key, value := range cw.pipe {
		if err := cw.writeString(ConfTypePipeDefinition, key, value, written); err != nil {
			cw.Error = err
			return cw
		}

		written = true
	}

	return cw
}

func (cw *CfgWriter) marshalJSON(t interface{}) {
	var jsonError error
	var jsonData []byte

	if cw.pretty {
		jsonData, jsonError = json.MarshalIndent(t, "", "  ")
	} else {
		jsonData, jsonError = json.Marshal(t)
	}

	if nil != jsonError {
		cw.Error = cberror.NewCbErrorf(
			cw.context.Service(),
			cberror.ErrorProviderUnableToMarshalJson,
			jsonError,
			"Error when marshal %T",
			t,
		)
	}

	cw.Buffer.Write(jsonData)
}

func (cw *CfgWriter) writeString(
	oper ConfType,
	name string,
	data string,
	written bool) cberror.Error {
	if written {
		cw.Buffer.WriteByte('\n')
	}

	str := "--" + oper.String()

	if name != "" {
		str = str + "=" + name + "\n"
	}

	_, err := cw.Buffer.WriteString(str)

	if nil != err {
		return cberror.NewCbErrorf(
			cw.context.Service(),
			cberror.ErrorProviderUnableToWriteString,
			err,
			"failed to write '%s'",
			str,
		)
	}

	_, err = cw.Buffer.WriteString(data)

	if nil != err {
		return cberror.NewCbErrorf(
			cw.context.Service(),
			cberror.ErrorProviderUnableToWriteString,
			err,
			"failed to write '%s'",
			data,
		)
	}

	return nil
}
