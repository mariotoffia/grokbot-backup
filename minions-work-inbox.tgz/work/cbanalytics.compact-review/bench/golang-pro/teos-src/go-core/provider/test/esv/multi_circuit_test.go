package esv

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSimpleMultiCircuitExportObjectMapped(t *testing.T) {
	type UpdateDataPointList struct {
		Values []*eqmodel.CbDataPointImpl `json:"values"`
	}

	// Received in the target function
	var toTransmit *UpdateDataPointList

	targetFunc := func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		// Extract the target
		toTransmit = providerutils.ExtractTarget[UpdateDataPointList](target)
		return nil
	}

	afterInvoked := false

	after := func(
		ctx ifcore.CbContext,
		pipeCtx map[string]any,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		target map[string]any) cberror.Error {
		//
		afterInvoked = true
		return nil
	}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider-2", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", &UpdateDataPointList{}).
				UseSource(providerpipe.DefaultDsFullBuildingSourceFunc()).
				UseTarget(targetFunc).
				UseAfter(after).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	// Bind the dispatcher to provider context.
	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(simpleTestPath, builder))

	pctx := builder.Build()

	conf := `{
		"profile": "test/comt-test",
			"prms": {
				"LOG": "off","MID": "",
				"CRD": "", "BID": "Måssmyren 18", "PID": "1234", "TID": "1", "OPT": "**"
			},
			"map": {
				"COMT_C1": "COMT_C1",
				"COMT_C2": "COMT_C2",
				"ESHG": "ESHG",
				"OFFSPSSHCT_C1": "OFFSPSSHCT_C1",
				"OFFSPSSHCT_C2": "OFFSPSSHCT_C2"
			}
	}`

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider:    "test-provider-2",
		Result:      true,
		Config:      []any{conf},
		PayloadType: cbevent.PayloadBuildingDeviceShadow,
		Payload: jsonutils.ToJSONRawMessage(&dsmodel.DsFullBuilding{
			BuildingID: "Måssmyren 18",
			State: &dsmodel.DsFullBuildingState{
				Desired: &dsmodel.DsBuilding{
					TimeZone:   "Europe/Stockholm",
					ReportType: string(providerutils.ReportDsBuildingAcknowledge),
					Sensors: map[string]any{
						"OFFSPSSHCT_C1": -5.55,
						"OFFSPSSHCT_C2": 4.44,
					},
				},
			},
		}),
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))
	require.Equal(t, "", res.Status[0])

	require.NotNil(t, toTransmit, "The target function was not invoked")
	assert.True(t, afterInvoked, "The after function was not invoked")

	target := cbevent.ExtractResult[map[string]UpdateDataPointList](res, 0)

	require.NotNil(t, target)
	require.Contains(t, target, "target")

	real := target["target"]
	require.NotNil(t, real)
	assert.Equal(t, 5, len(real.Values))

	m := map[string]any{}

	for _, v := range real.Values {
		m[v.GetID()] = v.GetValue()
	}

	assert.Contains(t, m, "1234;COMT_C1")
	assert.Equal(t, float64(120), m["1234;COMT_C1"])
	assert.Contains(t, m, "1234;COMT_C2")
	assert.Equal(t, float64(120), m["1234;COMT_C2"])
	assert.Contains(t, m, "1234;ESHG")
	assert.Equal(t, nil, m["1234;ESHG"])
	assert.Contains(t, m, "1234;OFFSPSSHCT_C1")
	assert.Equal(t, float64(-5.55), m["1234;OFFSPSSHCT_C1"])
	assert.Contains(t, m, "1234;OFFSPSSHCT_C2")
	assert.Equal(t, float64(4.44), m["1234;OFFSPSSHCT_C2"])
}

func TestSimpleMultiCircuitExportKvMapped(t *testing.T) {
	// Received in the target function
	var toTransmit map[string]any

	targetFunc := func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		// Extract the target
		toTransmit = *providerutils.ExtractTarget[map[string]any](target)
		return nil
	}

	afterInvoked := false

	after := func(
		ctx ifcore.CbContext,
		pipeCtx map[string]any,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		target map[string]any) cberror.Error {
		//
		afterInvoked = true
		return nil
	}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider-2", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", map[string]any{}).
				UseSource(providerpipe.DefaultDsFullBuildingSourceFunc()).
				UseTarget(targetFunc).
				UseAfter(after).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	// Bind the dispatcher to provider context.
	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(simpleTestPath, builder))

	pctx := builder.Build()

	conf := `{
		"profile": "test/comt-kv-test",
			"prms": {
				"LOG": "off","MID": "",
				"CRD": "", "BID": "Måssmyren 18", "PID": "1234", "TID": "1", "OPT": "**"
			},
			"map": {
				"COMT_C1": "COMT_C1",
				"COMT_C2": "COMT_C2",
				"ESHG": "ESHG",
				"OFFSPSSHCT_C1": "OFFSPSSHCT_C1",
				"OFFSPSSHCT_C2": "OFFSPSSHCT_C2"
			}
	}`

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider:    "test-provider-2",
		Result:      true,
		Config:      []any{conf},
		PayloadType: cbevent.PayloadBuildingDeviceShadow,
		Payload: jsonutils.ToJSONRawMessage(&dsmodel.DsFullBuilding{
			BuildingID: "Måssmyren 18",
			State: &dsmodel.DsFullBuildingState{
				Desired: &dsmodel.DsBuilding{
					TimeZone:   "Europe/Stockholm",
					ReportType: string(providerutils.ReportDsBuildingAcknowledge),
					Sensors: map[string]any{
						"OFFSPSSHCT_C1": -5.55,
						"OFFSPSSHCT_C2": 4.44,
					},
				},
			},
		}),
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))
	require.Equal(t, "", res.Status[0])

	require.NotNil(t, toTransmit, "The target function was not invoked")
	assert.True(t, afterInvoked, "The after function was not invoked")

	target := cbevent.ExtractResult[map[string]map[string]any](res, 0)

	require.NotNil(t, target)
	require.Contains(t, target, "target")

	real := target["target"]
	require.NotNil(t, real)
	assert.Len(t, real, 4)

	assert.Contains(t, real, "COMT_C1")
	assert.Equal(t, float64(45), real["COMT_C1"])
	assert.Contains(t, real, "COMT_C2")
	assert.Equal(t, float64(45), real["COMT_C2"])
	assert.Contains(t, real, "OFFSPSSHCT_C1")
	assert.Equal(t, float64(-5.55), real["OFFSPSSHCT_C1"])
	assert.Contains(t, real, "OFFSPSSHCT_C2")
	assert.Equal(t, float64(4.44), real["OFFSPSSHCT_C2"])
}
