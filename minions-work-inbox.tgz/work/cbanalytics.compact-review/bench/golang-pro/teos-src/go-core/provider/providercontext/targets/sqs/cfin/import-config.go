package cfin

import (
	"fmt"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrqueue/awsmgrqueue"
	"github.com/Thiink-LLC/teos/go-core/model/cfgmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/queuemodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// ImportTargetOverrideFunc is a function that can be used to override functionality just before
// sending the `cfgmodel.ImportConfigEvent` to SQS.
//
// If the return is `nil`, the event will be dropped.
type ImportTargetOverrideFunc func(ctx ifcore.CbContext, evt *cfgmodel.ImportConfigEvent) *cfgmodel.ImportConfigEvent

type ImportTargetOptions struct {
	// DropEmptyNonBootstrapEvents will drop any empty `cfgmodel.ImportConfigEvent` that
	// has `cfgmodel.ImportConfigEvent.Bootstrap` set to `false`.
	//
	// By empty, it means that it does not have any services, equipment or sensors. This
	// is to safeguard against completely wipe out any configuration for a malfunctioning
	// provider.
	DropEmptyNonBootstrapEvents bool
	// Override when set will override the `cfgmodel.ImportConfigEvent` just before it is
	// sent to SQS.
	//
	// If the return is `nil`, the event will be dropped.
	Override ImportTargetOverrideFunc
}

// ImportConfigTarget will extract the `*cfgmodel.ImportConfigEvent` and push it to SQS.
//
// It will use the `CB_QUEUE_IMPORTCFG` environment variable to determine the SQS queue.
// to push the event to.
func ImportConfigTargetSQS(opt ...ImportTargetOptions) providerpipe.TargetFunction {
	queueURL := cbenv.CB_QUEUE_FMT.StringFormat("IMPORTCFG", "")

	if queueURL == "" {
		panic("No queue url set in the CB_QUEUE_IMPORTCFG environment variable")
	}

	queue := utils.CreateSchemeURL("https", queueURL)

	if queue == nil {
		panic(fmt.Sprintf("Invalid queue URL: %s", queueURL))
	}

	var options *ImportTargetOptions

	if len(opt) > 0 {
		options = &opt[0]
	}

	is_bootstrap_event := func(event *cfgmodel.ImportConfigEvent) bool {
		if event == nil || len(event.Params) == 0 {
			return false
		}

		return utils.ExtractBoolFromMap("bootstrap", event.Params, false)
	}

	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any, target map[string]any) cberror.Error {
		//
		lid := pc.GetParamAsStringWithDefault(string(ifprovider.ParameterLocationID), "")
		event := providerutils.ExtractTarget[cfgmodel.ImportConfigEvent](target)

		if event == nil {
			log.WarnWithLocationID(ctx, lid).
				WithMethod("ImportConfigTargetSQS").
				WithBody(target).
				Msg("No event found in target")

			return nil
		}

		if options != nil && options.DropEmptyNonBootstrapEvents {
			if len(event.Services) == 0 &&
				len(event.Equipment) == 0 &&
				len(event.Sensors) == 0 && !is_bootstrap_event(event) {
				log.InfoWithLocationID(ctx, lid).
					WithMethod("ImportConfigTargetSQS").
					WithBody(event).
					Msg("Dropping empty non-bootstrap event")

				return nil
			}
		}

		if options != nil && options.Override != nil {
			if override := options.Override(ctx, event); override == nil {
				log.InfoWithLocationID(ctx, lid).
					WithMethod("ImportConfigTargetSQS").
					WithBody(event).
					Msg("Dropping event due to override returned nil")

				return nil
			} else {
				event = override
			}
		}

		mgr := awsmgrqueue.NewQManagerSQS(ctx).UseQueueURL(queue)

		mgr.Send(queuemodel.QueueMessage{
			Body: jsonutils.ToJSON(event),
		})

		if log.IsEnabledWithLocationID(zerolog.DebugLevel, lid) {
			l := log.DebugWithLocationID(ctx, lid).
				WithMethod("ImportConfigTargetSQS").
				WithBody(event).
				WithError(mgr.Error())

			if mgr.Error() != nil {
				l.Msg("Failed to send event to SQS")
			} else {
				l.Msg("Sent event to SQS")
			}
		}

		return mgr.Error()
	}
}
