package providerpipe

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDefaultPartition_WithSeparator(t *testing.T) {
	partitioner := DefaultPartition(";")

	id, partition := partitioner("plant1;sensor123")
	assert.Equal(t, "sensor123", id)
	assert.Equal(t, "plant1", partition)
}

func TestDefaultPartition_WithoutSeparator(t *testing.T) {
	partitioner := DefaultPartition(";")

	id, partition := partitioner("sensor123")
	assert.Equal(t, "sensor123", id)
	assert.Equal(t, "", partition)
}

func TestDefaultPartition_MultipleSeparators(t *testing.T) {
	partitioner := DefaultPartition(";")

	// SplitN with 2 means only the first separator is used
	id, partition := partitioner("plant1;sensor;123")
	assert.Equal(t, "sensor;123", id)
	assert.Equal(t, "plant1", partition)
}

func TestDefaultPartition_EmptyString(t *testing.T) {
	partitioner := DefaultPartition(";")

	id, partition := partitioner("")
	assert.Equal(t, "", id)
	assert.Equal(t, "", partition)
}

func TestDefaultPartition_DifferentSeparator(t *testing.T) {
	partitioner := DefaultPartition(":")

	id, partition := partitioner("plant1:sensor123")
	assert.Equal(t, "sensor123", id)
	assert.Equal(t, "plant1", partition)
}

func TestNoopObtainCredentials_ReturnsCredentials(t *testing.T) {
	credFunc := NoopObtainCredentials("user", "pass", "key", "api.example.com", []byte("token"))

	c := testenv.DefaultContext(t, "test")

	result, ttl, err := credFunc(c, "cred", nil, &providermodel.Operation{})

	require.NoError(t, err)
	assert.Equal(t, int64(3600), ttl)

	creds, ok := result.(*securitymodel.TokenCredentialsImpl)
	require.True(t, ok)
	assert.Equal(t, "user", creds.Credentials.User)
	assert.Equal(t, "pass", creds.Credentials.Password)
	assert.Equal(t, "key", creds.Credentials.APIKey)
	assert.Equal(t, "api.example.com", creds.Credentials.Endpoint)
	assert.Equal(t, []byte("token"), creds.Token)
}

func TestDefaultVerifyConnect_NilCredentials(t *testing.T) {
	c := testenv.DefaultContext(t, "test")

	result := DefaultVerifyConnect(c, "cred", nil, &providermodel.Operation{})

	assert.False(t, result)
}

func TestDefaultVerifyConnect_MatchingEndpoint(t *testing.T) {
	c := testenv.DefaultContext(t, "test")

	creds := &securitymodel.TokenCredentialsImpl{
		Credentials: securitymodel.StandardCredentialsImpl{
			Endpoint: "https://api.example.com/v1/data",
		},
	}

	op := &providermodel.Operation{
		Operation: "https://api.example.com/v2/other",
	}

	result := DefaultVerifyConnect(c, "cred", creds, op)

	assert.True(t, result)
}

func TestDefaultVerifyConnect_NonMatchingEndpoint(t *testing.T) {
	c := testenv.DefaultContext(t, "test")

	creds := &securitymodel.TokenCredentialsImpl{
		Credentials: securitymodel.StandardCredentialsImpl{
			Endpoint: "https://api.example.com/v1/data",
		},
	}

	op := &providermodel.Operation{
		Operation: "https://api.other.com/v2/other",
	}

	result := DefaultVerifyConnect(c, "cred", creds, op)

	assert.False(t, result)
}

func TestDefaultVerifyConnect_StandardCredentials(t *testing.T) {
	c := testenv.DefaultContext(t, "test")

	creds := &securitymodel.StandardCredentialsImpl{
		Endpoint: "api.example.com",
	}

	op := &providermodel.Operation{
		Operation: "https://api.example.com/data",
	}

	result := DefaultVerifyConnect(c, "cred", creds, op)

	assert.True(t, result)
}

func TestDefaultVerifyConnect_UnknownCredentialType(t *testing.T) {
	c := testenv.DefaultContext(t, "test")

	// Pass an unsupported credential type
	creds := "unsupported"

	op := &providermodel.Operation{
		Operation: "https://api.example.com/data",
	}

	result := DefaultVerifyConnect(c, "cred", creds, op)

	assert.False(t, result)
}
