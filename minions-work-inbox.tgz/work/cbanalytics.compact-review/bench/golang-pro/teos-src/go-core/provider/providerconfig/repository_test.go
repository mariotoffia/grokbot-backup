package providerconfig

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// cSpell: disable
func TestMergeConfig(t *testing.T) {
	pc := genProviderConfig()
	ctx := newCtx(t)

	pc.Operation["sv"].Params["pcparam"] = "kalle"

	rep := NewProviderConfigRepository(ctx).Add(&pc)

	pcnew := &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "test",
				Params: map[string]interface{}{
					"newprm": "hello!",
				},
				Operation: map[string]providermodel.Operation{
					"sv": {
						Operation: "https://{{REP}}/DataPoints/Values2/",
						Params: map[string]interface{}{
							"parentId": `[{"Plants":"[{"Plants":"{{FUD}}"}]"}]`,
							"added":    "param",
						},
					},
					"bld": {
						Operation: "bubben",
						Params: map[string]interface{}{
							"jupp": "buppen",
						},
					},
				},
				Map: map[string]string{
					"BII": "Bibbi",
				},
				Filter: map[string]string{
					"BAAH": "JoJo",
				},
			},
		},
		GenerationImpl: providermodel.GenerationImpl{
			Generate: map[string]string{
				"refgen": "a template",
			},
		},
		PipesImpl: providermodel.PipesImpl{
			Pipe: map[string]string{
				"a-pipe": "THE pipe",
			},
		},
	}

	merged, _ := rep.Merge(ctx, "test", pcnew)

	assert.Equal(t, "hello!", merged.Params["newprm"])
	assert.Equal(t, "Månstenen 9", merged.Params["BID"])
	assert.Equal(t, "https://{{REP}}/DataPoints/Values2/", merged.Operation["sv"].Operation)

	assert.Equal(
		t,
		`[{"Plants":"[{"Plants":"{{FUD}}"}]"}]`,
		merged.Operation["sv"].Params["parentId"],
	)

	assert.Equal(t, "param", merged.Operation["sv"].Params["added"])
	assert.Equal(t, "kalle", merged.Operation["sv"].Params["pcparam"])
	assert.Equal(t, "JoJo", merged.Filter["BAAH"])
	assert.Equal(t, "V > -100 && V < 100", merged.Filter["IDT"])
	assert.Equal(t, "Bibbi", merged.Map["BII"])
	assert.Equal(t, "Room temp.comf.", merged.Map["IDT"])
	assert.Equal(t, "bubben", merged.Operation["bld"].Operation)
	assert.Equal(t, "buppen", merged.Operation["bld"].Params["jupp"])
	assert.Equal(t, "a template", merged.Generate["refgen"])
	assert.Equal(t, "THE pipe", merged.Pipe["a-pipe"])
}

func TestMergeConfigWithAliasFromIncomingConfigAndMappingInOriginal(t *testing.T) {
	pc := genProviderConfig()
	ctx := newCtx(t)

	// All mappings specified in the provider profile
	pc.Map["MFPS_C1_O3"] = "1!virtMFPS_C1_O3"
	pc.Map["MFPS_C1_O4"] = "1!virtMFPS_C1_O4"
	pc.Map["MFPS_C1_O14"] = "1!virtMFPS_C1_O14"
	pc.Map["MFRS_O1"] = "1!virtMFRS_O1"

	pc.Operation["sv"].Params["pcparam"] = "kalle"

	rep := NewProviderConfigRepository(ctx).Add(&pc)

	pcnew := &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "test",
				Params: map[string]interface{}{
					"newprm": "hello!",
					// Incoming config "aliases" the provider config mapping.
					string(ifprovider.ParameterMappingIDs): "OFFODT MFPS:MFPS_C1_O14 MFRS:MFRS_O1",
				},
				Operation: map[string]providermodel.Operation{
					"sv": {
						Operation: "https://{{REP}}/DataPoints/Values2/",
						Params: map[string]interface{}{
							"parentId": `[{"Plants":"[{"Plants":"{{FUD}}"}]"}]`,
							"added":    "param",
						},
					},
					"bld": {
						Operation: "bubben",
						Params: map[string]interface{}{
							"jupp": "buppen",
						},
					},
				},
				Map: map[string]string{
					"BII": "Bibbi",
				},
				Filter: map[string]string{
					"BAAH": "JoJo",
				},
			},
		},
		GenerationImpl: providermodel.GenerationImpl{
			Generate: map[string]string{
				"refgen": "a template",
			},
		},
		PipesImpl: providermodel.PipesImpl{
			Pipe: map[string]string{
				"a-pipe": "THE pipe",
			},
		},
	}

	merged, _ := rep.Merge(ctx, "test", pcnew)

	assert.Equal(
		t,
		"OFFODT MFPS MFRS IDT BII",
		merged.Params[string(ifprovider.ParameterMappingIDs)],
	)

	// Nothing since not selected by MID
	assert.Equal(t, "", merged.Map["MFPS_C1_O3"])
	assert.Equal(t, "", merged.Map["MFPS_C1_O4"])
	assert.Equal(t, "", merged.Map["MFPS_C1_O14"])
	assert.Equal(t, "", merged.Map["MFRS_O1"])
	assert.Equal(t, "", merged.Map["OFFODT"])

	assert.Equal(t, "Room temp.comf.", merged.Map["IDT"])
	assert.Equal(t, "Bibbi", merged.Map["BII"])

	assert.Equal(t, "1!virtMFPS_C1_O14", merged.Map["MFPS"], "Should be alias mapped!")
	assert.Equal(t, "1!virtMFRS_O1", merged.Map["MFRS"], "Should be alias mapped!")
}

func TestMergeGeneratorPrototypeWithProviderDefaultAddOne(t *testing.T) {
	pc := genProviderConfig()
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "float64(generate[{{ID}}].Value)",
			"IDT_O1": `float64(generate["IDT_O1"].Value)`,
			"*":      "float64(generate[{{ID}}].Value)",
		},
	}
	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"*": "generate[{{ID}}].TimeStamp",
		},
	}

	rep := NewProviderConfigRepository(newCtx(t)).Add(&pc)

	pcnew := &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "test",
			},
		},
		GenerationImpl: providermodel.GenerationImpl{
			GenProto: map[string]providermodel.GeneratorPrototypeImpl{
				"sv": {"ODT": "float64(generate[{{ODT}}].Value)"},
			},
			GenProtoTs: map[string]providermodel.GeneratorPrototypeImpl{
				"sv": {"ODT": "generate[{{ODT}}].TimeStamp"},
			},
		},
	}

	merged, _ := rep.Merge(newCtx(t), "test", pcnew)
	assert.Equal(t, "float64(generate[{{ID}}].Value)", merged.GenProto["sv"]["IDT"])
	assert.Equal(t, `float64(generate["IDT_O1"].Value)`, merged.GenProto["sv"]["IDT_O1"])
	assert.Equal(t, "float64(generate[{{ID}}].Value)", merged.GenProto["sv"]["*"])
	assert.Equal(t, "float64(generate[{{ODT}}].Value)", merged.GenProto["sv"]["ODT"])
	assert.Equal(t, "generate[{{ID}}].TimeStamp", merged.GenProtoTs["sv"]["*"])
	assert.Equal(t, "generate[{{ODT}}].TimeStamp", merged.GenProtoTs["sv"]["ODT"])
}

func TestMergeGeneratorPrototypeWithProviderDefaultOverwriteOne(t *testing.T) {
	pc := genProviderConfig()
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT": "generate[{{ID}}].TimeStamp",
			"*":   "generate[{{ID}}].TimeStamp",
		},
	}

	rep := NewProviderConfigRepository(newCtx(t)).Add(&pc)

	pcnew := &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "test",
			},
		},
		GenerationImpl: providermodel.GenerationImpl{
			GenProto: map[string]providermodel.GeneratorPrototypeImpl{
				"sv": {"*": "round(float64(generate[{{ID}}]), 1)"},
			},
			GenProtoTs: map[string]providermodel.GeneratorPrototypeImpl{
				"sv": {"*": "cb32(generate[{{ID}}].TimeStamp)"},
			},
		},
	}

	merged, _ := rep.Merge(newCtx(t), "test", pcnew)
	assert.Equal(t, "generate[{{ID}}]", merged.GenProto["sv"]["IDT"])
	assert.Equal(t, `generate["IDT_O1"]`, merged.GenProto["sv"]["IDT_O1"])
	assert.Equal(t, "round(float64(generate[{{ID}}]), 1)", merged.GenProto["sv"]["*"])
	assert.Equal(t, "generate[{{ID}}].TimeStamp", merged.GenProtoTs["sv"]["IDT"])
	assert.Equal(t, "cb32(generate[{{ID}}].TimeStamp)", merged.GenProtoTs["sv"]["*"])
}

func TestMergeGeneratorPrototypeWithNoProviderDefaultAddOne(t *testing.T) {
	pc := genProviderConfig()
	rep := NewProviderConfigRepository(newCtx(t)).Add(&pc)

	pcnew := &providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "test",
			},
		},
		GenerationImpl: providermodel.GenerationImpl{
			GenProto: map[string]providermodel.GeneratorPrototypeImpl{
				"sv": {"ODT": "float64(generate[{{ODT}}].Value)"},
			},
			GenProtoTs: map[string]providermodel.GeneratorPrototypeImpl{
				"sv": {"ODT": "generate[{{ODT}}].TimeStamp"},
			},
		},
	}

	merged, _ := rep.Merge(newCtx(t), "test", pcnew)
	assert.Equal(t, "float64(generate[{{ODT}}].Value)", merged.GenProto["sv"]["ODT"])
	assert.Equal(t, "generate[{{ODT}}].TimeStamp", merged.GenProtoTs["sv"]["ODT"])
}

func BenchmarkMergeConfig(t *testing.B) {
	pc := genProviderConfig()
	pc.Operation["sv"].Params["pcparam"] = "kalle"

	rep := NewProviderConfigRepository(newCtx(t)).Add(&pc)

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		pcnew := &providermodel.ProviderConfigImpl{
			ProfileImpl: providermodel.ProfileImpl{
				BaseProfile: providermodel.BaseProfile{
					Profile: "test",
					Params: map[string]interface{}{
						"newprm": "hello!",
					},
					Operation: map[string]providermodel.Operation{
						"sv": {
							Operation: "https://{{REP}}/DataPoints/Values2/",
							Params: map[string]interface{}{
								"parentId": `[{"Plants":"[{"Plants":"{{FUD}}"}]"}]`,
								"added":    "param",
							},
						},
						"bld": {
							Operation: "bubben",
							Params: map[string]interface{}{
								"jupp": "buppen",
							},
						},
					},
					Map: map[string]string{
						"BII": "Bibbi",
					},
					Filter: map[string]string{
						"BAAH": "JoJo",
					},
				},
			},
			GenerationImpl: providermodel.GenerationImpl{
				Generate: map[string]string{
					"refgen": "a template",
				},
			},
			PipesImpl: providermodel.PipesImpl{
				Pipe: map[string]string{
					"a-pipe": "THE pipe",
				},
			},
		}

		_, _ = rep.Merge(newCtx(t), "test", pcnew)
	}
}

//cSpell: enable
