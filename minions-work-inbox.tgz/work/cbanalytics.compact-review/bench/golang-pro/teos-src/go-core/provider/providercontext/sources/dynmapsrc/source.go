package dynmapsrc

import (
	"slices"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

type DynamicMappingSourceOptions struct {
	// Loader is the function that will load the remote id's to TeosID's.
	Loader providerpipe.SourceFunction
	// Source is the function that will get the name:value pair for each TeosID.
	Source providerpipe.SourceFunction
	// PartitionKey is the key to use for partition, if not found in operation or global params.
	PartitionKey string
	// SyntheticId is the TeosID's that could be injected if present in global params or pipeCtx.
	//
	// It is expected to be in it's raw ID form e.g. _COMT_ not COMT_C1 so it may map any circuit.
	//
	// NOTE: The ID need to be present in the source map as selection but not in source data. Then
	// it will check the pipe context and global params for the value to inject.
	SyntheticId []string
}

// DynamicMappingSource will use the _loader_ to load and select remote id's to _TeosID_'s. It will then
// use the _source_ to get the name:value pair for each _TeosID_. The result is a map with the remoteId and
// `eqmodel.CbDataPointImpl` populated with remote ID, TeosID, value and the partition taken from the operation or
// global params by the _partitionKey_ (use "" if none).
//
// The _source_ function keys is the _TeosID_ and the value is the value to be set. The _loader_ is the reverse, where
// the key is the remote Id and the TeosID can be found in the `eqmodel.CbDataPoint.GetId()`.
//
// The _source_ values can be:
// 1. `eqmodel.CbDataPointImpl` - The value is already a `eqmodel.CbDataPointImpl` and will be used as is.
// 2. `eqmodel.CbDataPoint` - The value is a `eqmodel.CbDataPoint` and will be converted to a `eqmodel.CbDataPointImpl`.
// 3. `any` - The value is a `any` and will be used in creation of new to a `eqmodel.CbDataPointImpl`.
//
// NOTE: If no _src_ segment is found, it will just return the _source_ data.
//
// This function *REQUIRES* that the _source_ returns a map with the "source" syntax, i.e. `map[string]any{"source": map[string]any{...}}`!
//
// TIP: Since _COMT_ is seldom sent to a provider, it is possible to inject COMT if present in global params or _pipeCtx_ by adding it to SyntheticId.
func DynamicMappingSource(
	ctx ifcore.CbContext,
	opt DynamicMappingSourceOptions,
) providerpipe.SourceFunctionWithSelection {
	//
	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any,
	) (map[string]any, []providermodel.Selection, cberror.Error) {
		//
		var partition string

		if opt.PartitionKey != "" {
			if partition = op.GetParamAsStringWithDefault(opt.PartitionKey, ""); partition == "" {
				partition = pc.GetParamAsStringWithDefault(opt.PartitionKey, "")
			}
		}

		// No src, just load the original source and return
		if len(pc.GetSelectors()) == 0 {
			src, err := opt.Source(ctx, operation, op, pc, pipeCtx, cred)

			return src, nil, err
		}

		_, selection, drc, err := providerpipe.InvokeAndSelectOnSourceFunction(
			ctx, opt.Loader, pipeCtx, pc, operation, op, cred, false, /*noFilter*/
		)

		if err != nil {
			return nil, nil, err
		}

		src, err := loadSource(ctx, opt.Source, operation, op, pc, pipeCtx, cred, partition)

		if err != nil {
			return nil, nil, err
		}

		sm, _ := src["source"].(map[string]any)

		// Need to filter and map the src using the selection
		useSelections := make([]providermodel.Selection, 0, len(selection))

		for i := range selection {
			v, ok := sm[selection[i].TeosId]

			if !ok && len(opt.SyntheticId) > 0 {
				rawID := eqmodel.SensorType(selection[i].TeosId).RawID()
				if idx := slices.Index(opt.SyntheticId, rawID); idx != -1 {
					var val any

					val, ok = pipeCtx[rawID]

					if !ok {
						val, ok = pc.GetGlobalParams()[rawID]
					}

					if ok {
						v = &eqmodel.CbDataPointImpl{
							ID:        selection[i].RemoteId,
							Value:     val,
							TimeStamp: *coremodel.NewTimeUTC32Now(),
							Partition: partition,
						}

						sm[selection[i].TeosId] = v
					}
				}
			}

			if ok {
				if dp, ok := v.(*eqmodel.CbDataPointImpl); ok {
					useSelections = append(useSelections, selection[i])

					if partition != "" {
						dp.Partition = partition
					}

					dp.ID = selection[i].RemoteId
				}
			}
		}

		if len(drc) > 0 {
			src["_report"] = drc
		}

		return src, useSelections, nil
	}
}

func loadSource( /* NOSONAR */
	ctx ifcore.CbContext,
	source providerpipe.SourceFunction,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	pipeCtx map[string]any,
	cred any,
	partition string,
) (map[string]any, cberror.Error) {
	src, err := source(ctx, operation, op, pc, pipeCtx, cred)

	if err != nil {
		return nil, err
	}

	var sm map[string]any
	if s, ok := src["source"]; ok {
		sm, _ = s.(map[string]any)
	}

	if sm == nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), 400, nil,
			"loadSource requires that the returned source has a 'source' protocol in returned map",
		)
	}

	// Check if all is `eqmodel.CbDataPointImpl` and if not convert to `eqmodel.CbDataPointImpl`
	var needConvert bool

	for _, v := range sm {
		if _, ok := v.(*eqmodel.CbDataPointImpl); !ok {
			needConvert = true
			break
		}
	}

	if !needConvert {
		return src, nil
	}

	var converted = make(map[string]any, len(sm))

	for k, v := range sm {
		switch t := v.(type) {
		case *eqmodel.CbDataPointImpl:
			converted[k] = t
		case eqmodel.CbDataPoint:
			converted[k] = &eqmodel.CbDataPointImpl{
				ID:        t.GetID(),
				Value:     t.GetValue(),
				TimeStamp: t.GetTimeStamp(),
				Partition: t.GetPartition(),
				Error:     t.GetError(),
			}
		default:
			converted[k] = &eqmodel.CbDataPointImpl{
				ID:        k,
				Value:     v,
				TimeStamp: *coremodel.NewTimeUTC32Now(),
				Partition: partition,
			}
		}
	}

	src["source"] = converted

	return src, nil
}
