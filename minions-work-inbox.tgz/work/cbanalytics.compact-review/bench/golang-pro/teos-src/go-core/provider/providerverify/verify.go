package providerverify

import (
	"encoding/json"
	"fmt"
	"regexp"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// As the intended audience of static verification are users responsible of creating provider configuration. +
// The verification is triggered by setting SensorValueEvent.ProviderTestParameters.VerifyConfigStatic property to true. +
// The function will never error out. Instead it will report errors back to users as an SensorValueProviderResultEvent and the status array. An empty status array represent a valid configuration otherwise failure. +
//
// The static verification supports 2 types of capabilities
//
// * CapsProviderVerifyConfig - The provider uses the support for verification from the provider SDK. The capability requires that the provider implements the VerifyConfigStatic interface.
// * CapsProviderVerifyConfigEx - The provider will perform all verification by itself. The capability requires that the provider implements the VerifyConfigStaticEx interface.
//
// Provider SDK capability +
// As the capability CapsProviderVerifyConfigEx is handled by the provider , the CapsProviderVerifyConfig will be explained.
//
// .ConfigParam
// [source,go]
// ----
// include::${gad:current:fq}[tag=configparam,indent=0]
// ----
// <1> The CtxType defines the "domain" for verification ex GlobalParams
// <2> The CtxName defines an additional "subdomain" for a CtxType
// <3> The ID is a regular expression for matching configuration keys
// <4> The Value is a regular expression for matching configuration values
// <5> The State is either Mandatory or Optional
//
// A ConfigParam with mandatory state has to match one or more configuration key and the configuration value must match the ConfigParam value. +
// A ConfigParam with optional state could match a configuration key and if matched, the configuration value must match the ConfigParam value. +
//
// Example with provider SDK support
// [source,go]
// ----
//	func (sb *sv) GetVerifyConfig() []providerverify.ConfigParam {
// 		return []providerverify.ConfigParam {
// 			{providerverify.GlobalParams, "", `BID`, `.*`, providerverify.Mandatory}, //<1>
//			{providerverify.GlobalParams, "", `REP`, `.*`, providerverify.Mandatory},
//			{providerverify.GlobalParams, "", `PID`, `.*`, providerverify.Mandatory},
//			{providerverify.GlobalParams, "", `TTY`, 4.0, providerverify.Optional}, //<2>
//			{providerverify.GlobalParams, "", `*`, `*`, providerverify.Optional}, //<3>
//			{providerverify.OperationsParams, "sv", `BID`, `\[BID\]`, providerverify.Mandatory},
//			{providerverify.OperationsParams, "sv", `REP`, `\[REP\]`, providerverify.Mandatory},
//	 		{providerverify.OperationsParams, "sv", `*`, `*`, providerverify.Optional},
//			{providerverify.Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, providerverify.Mandatory}, //<4>
// 		}
//	}
// ----
// <1> The configuration key "BID" has be present and has to match the expression ".*"
// <2> The configuration key "TTY" could be present and if present it has to match the value 4.0
// <3> All other key are optional and value could be anything. If this items is removed, the verification will fail as all items in a "domain" must be matched.
// <4> The reason for all items in a "domain" must be matched is related to expressions that matches more the one key. +
// If the provider requires that all keys in are matched, the provider omits the optional "*" ConfigParam. A typo in the mapping configuration will be regarded as an error as it is unmatched.
//
// In case of verification errors, the SensorValueProviderResultEvent.Status array contains string representations of verifyError struct.
// .VerifyError
// [source,go]
// ----
// include::${gad:current:fq}[tag=verifyerror,indent=0]
// }
// ----
// The Cfg property is the failed verification configuration item.
//
// Error codes +
//
// [cols=3*,options=header]
// |===
// |Name
// |Code
// |Description
//
// |ErrorProviderVerifyMandatoryParamMissing
// |1732
// |Mandatory item is missing.
//
// |ErrorProviderVerifyMandatoryParamValue
// |1733
// |Value of a mandatory item expression failed.
//
// |ErrorProviderVerifyOptionalParamValue
// |1734
// |Value of a optional item expression failed.
//
// |ErrorProviderVerifyNoMatch
// |1735
// |Unmatched item or items in context type domain.
// ...
// |===

// ConfigType is the supported config type
type ConfigType string

// ConfigState is the supported config state
type ConfigState string

// ConfigTypes are supported domains for static verification
const (
	Root             ConfigType = "Root"
	GlobalParams     ConfigType = "GlobalParams"
	OperationsParams ConfigType = "OperationsParams"
	Mapping          ConfigType = "Mapping"
	Filter           ConfigType = "Filter"
)

// ConfigStates supports Mandatory and optional config items
const (
	Mandatory ConfigState = "Mandatory"
	Optional  ConfigState = "Optional"
)

// Provider SDK supported interface
type VerifyConfigStatic interface {
	GetVerifyConfig() []ConfigParam
}

type VerifyConfigExFunction func(config *providermodel.ProviderConfigImpl) []cberror.CbError

// Verification performed by provider
type VerifyConfigStaticEx interface {
	VerifyConfigEx() VerifyConfigExFunction
}

// tag::verifyerror[]
type verifyError struct {
	Svc  string      `json:"service"`
	Code int         `json:"code"`
	Cfg  ConfigParam `json:"cfg"`
	Msg  string      `json:"msg"`
}

// end::verifyerror[]

// tag::configparam[]
type ConfigParam struct {
	CtxType ConfigType  `json:"type"`  // <1>
	CtxName string      `json:"name"`  // <2>
	ID      string      `json:"id"`    // <3>
	Value   interface{} `json:"value"` // <4>
	State   ConfigState `json:"state"` // <5>
}

// end::configparam[]

// private struct for matched config in domain
type configItem struct {
	key   string
	value interface{}
}

type domain struct {
	ctxType        ConfigType
	ctxName        string
	rules          []configRule
	unmatchedItems []ConfigParam
}

type configRule struct {
	configParam ConfigParam
	configItems []configItem
}

type StaticVerifier struct {
	domains map[string]*domain
	ctx     ifcore.CbContext
}

func NewStaticVerifier(c ifcore.CbContext) *StaticVerifier {
	return &StaticVerifier{
		ctx: c,
	}
}

// Init the verifier with configuration provided by the provider. +
// The setup will map the configuration to verification domain based on type and name
func (sv *StaticVerifier) Setup(c ifcore.CbContext, configParams []ConfigParam) cberror.Error {
	sv.domains = map[string]*domain{}

	// Add the mandatory root item "profile". VerifyConfig checks the root item "oid" in verifyOwner.
	index := fmt.Sprintf("%v:%v", Root, "")
	sv.domains[index] = &domain{rules: []configRule{}, unmatchedItems: []ConfigParam{}}
	sv.domains[index].ctxType = Root
	sv.domains[index].ctxName = ""
	sv.domains[index].rules = append(
		sv.domains[index].rules,
		configRule{configParam: ConfigParam{Root, "", "profile", ".*", Mandatory}},
	)

	for _, v := range configParams {
		index := fmt.Sprintf("%v:%v", v.CtxType, v.CtxName)

		if _, present := sv.domains[index]; !present {
			sv.domains[index] = &domain{rules: []configRule{}, unmatchedItems: []ConfigParam{}}
			sv.domains[index].ctxType = v.CtxType
			sv.domains[index].ctxName = v.CtxName
		}

		if v.ID == "*" && v.State != Optional {
			return cberror.NewCbErrorf(
				c.Service(), cberror.ErrorConfigurationValidation, nil,
				"Generic id '*' only valid for state: Optional",
			)
		}

		sv.domains[index].rules = append(sv.domains[index].rules, configRule{configParam: v})
	}

	return nil
}

func (sv *StaticVerifier) VerifyConfig(
	config *providermodel.ProviderConfigImpl,
) cbevent.ProviderResultEvent {
	index := fmt.Sprintf("%v:%v", Root, "")
	rootItems := map[string]interface{}{}
	rootItems["profile"] = config.Profile
	matchInterfaceItems(rootItems, sv.domains[index])

	index = fmt.Sprintf("%v:%v", GlobalParams, "")
	matchInterfaceItems(config.Params, sv.domains[index])

	for opKey, op := range config.Operation {
		index = fmt.Sprintf("%v:%v", OperationsParams, opKey)

		domain := sv.domains[index]

		if domain == nil {
			continue
		}

		matchInterfaceItems(op.Params, domain)
	}

	index = fmt.Sprintf("%v:%v", Mapping, "")
	matchStringItems(config.Map, sv.domains[index])

	index = fmt.Sprintf("%v:%v", Filter, "")
	matchStringItems(config.Filter, sv.domains[index])

	result := sv.verifyDomains()
	sv.verifyOwner(&result, config.Owner)

	return result
}

// ownerRule is the mandatory root item "oid", the owner ID of a provider configuration. Its value
// is the owner ID format: "all" or an organization ID. A status entry shows it when the owner
// ID is missing or refused.
var ownerRule = ConfigParam{
	CtxType: Root,
	ID:      "oid",
	Value:   coremodel.OwnerIDPattern,
	State:   Mandatory,
}

// verifyOwner adds a status entry when the owner ID is empty
// (ErrorProviderVerifyMandatoryParamMissing) or when coremodel.ValidateOwnerID refuses it
// (ErrorProviderVerifyMandatoryParamValue). The second entry's message names the value and the
// format.
func (sv *StaticVerifier) verifyOwner(result *cbevent.ProviderResultEvent, owner string) {
	if owner == "" {
		sv.AppendError(
			result, sv.ctx.Service(), cberror.ErrorProviderVerifyMandatoryParamMissing, &ownerRule, "",
		)

		return
	}

	if err := coremodel.ValidateOwnerID(owner); err != nil {
		sv.AppendError(
			result, sv.ctx.Service(), cberror.ErrorProviderVerifyMandatoryParamValue, &ownerRule,
			"%v", err,
		)
	}
}

func (sv *StaticVerifier) verifyDomains() cbevent.ProviderResultEvent {
	resultEvent := cbevent.ProviderResultEvent{
		Status: []string{},
		Result: []any{},
	}

	for _, domain := range sv.domains {
		for _, rule := range domain.rules {
			if rule.configParam.State == Mandatory { //nolint:staticcheck // QF1003: if/else is clearer than switch
				if len(rule.configItems) == 0 {
					sv.AppendError(
						&resultEvent,
						sv.ctx.Service(),
						cberror.ErrorProviderVerifyMandatoryParamMissing,
						&rule.configParam,
						"",
					)
				} else {
					for _, item := range rule.configItems {
						if !matchValue(rule.configParam.Value, item.value) {
							sv.AppendError(&resultEvent, sv.ctx.Service(), cberror.ErrorProviderVerifyMandatoryParamValue, &rule.configParam, "configured value: %v", item.value)
						}
					}
				}
			} else if rule.configParam.State == Optional {
				for _, item := range rule.configItems {
					if !matchValue(rule.configParam.Value, item.value) {
						sv.AppendError(&resultEvent, sv.ctx.Service(), cberror.ErrorProviderVerifyOptionalParamValue, &rule.configParam, "configured value: %v", item.value)
					}
				}
			}
		}
		for _, unmatchedValue := range domain.unmatchedItems {
			sv.AppendError(
				&resultEvent,
				sv.ctx.Service(),
				cberror.ErrorProviderVerifyNoMatch,
				&unmatchedValue,
				"Unmatched config item",
			)
		}
	}
	return resultEvent
}

func matchStringItems(items map[string]string, domain *domain) {
	if domain == nil {
		return
	}

	for paramKey, paramValue := range items {
		matchedRule := false

		for ruleKey, ruleValue := range domain.rules {
			if matchKey(ruleValue.configParam.ID, paramKey) {
				matchedRule = true
				domain.rules[ruleKey].configItems = append(
					domain.rules[ruleKey].configItems,
					configItem{key: paramKey, value: paramValue},
				)
				break
			}
		}
		if !matchedRule {
			domain.unmatchedItems = append(
				domain.unmatchedItems,
				ConfigParam{
					CtxType: domain.ctxType,
					CtxName: domain.ctxName,
					ID:      paramKey,
					Value:   paramValue,
				},
			)
		}
	}
}

func matchInterfaceItems(items map[string]interface{}, domain *domain) {
	if domain == nil {
		return
	}
	for paramKey, paramValue := range items {
		matchedRule := false

		for ruleKey, ruleValue := range domain.rules {
			if matchKey(ruleValue.configParam.ID, paramKey) {
				matchedRule = true
				domain.rules[ruleKey].configItems = append(
					domain.rules[ruleKey].configItems,
					configItem{key: paramKey, value: paramValue},
				)
				break
			}
		}
		if !matchedRule {
			domain.unmatchedItems = append(
				domain.unmatchedItems,
				ConfigParam{
					CtxType: domain.ctxType,
					CtxName: domain.ctxName,
					ID:      paramKey,
					Value:   paramValue,
				},
			)
		}
	}
}

func (sv *StaticVerifier) AppendError(
	resultEvent *cbevent.ProviderResultEvent,
	svc string,
	code int,
	cfg *ConfigParam,
	msg string,
	args ...interface{},
) {
	e := verifyError{Svc: svc, Code: code, Cfg: *cfg, Msg: fmt.Sprintf(msg, args...)}

	if data, err := json.Marshal(e); err == nil {
		resultEvent.Status = append(resultEvent.Status, string(data))
	}
}

func (sv *StaticVerifier) CreateError(
	svc string,
	code int,
	cfg *ConfigParam,
	msg string,
	args ...interface{},
) cbevent.ProviderResultEvent {
	resultEvent := cbevent.ProviderResultEvent{
		Status: []string{},
		Result: []any{},
	}

	if cfg != nil {
		sv.AppendError(&resultEvent, svc, code, cfg, msg, args...)
	} else {
		sv.AppendError(&resultEvent, svc, code, &ConfigParam{}, msg, args...)
	}
	return resultEvent
}

func matchKey(vkey string, ckey string) bool {
	if vkey == "*" {
		return true
	}

	if ok, _ := regexp.MatchString(vkey, ckey); ok {
		return true
	}

	return false

}

func matchValue(exp interface{}, val interface{}) bool {
	expStr := fmt.Sprintf("%v", exp)
	valStr := fmt.Sprintf("%v", val)

	if expStr == "*" {
		return true
	}

	if ok, _ := regexp.MatchString(expStr, valStr); ok {
		return true
	}

	return false
}
