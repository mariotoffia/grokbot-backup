package s3

import (
	"fmt"
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/awamgrstore"
)

// S3ProviderConfigLoader is a `providercontext.UserProviderConfigLoader` that uses _S3_ as backend to load
// user configurations.
type S3ProviderConfigLoader struct {
	// mgr holds the bucket and prefix. Each load works on its own clone of it.
	mgr *awamgrstore.S3Manager
	// optional wether a missed key is an error or not
	optional bool
	// fullPrefix is the full prefix to use when loading the user config.
	fullPrefix string
}

// NewS3ProviderConfigLoader creates a new `S3ProviderConfigLoader`.
//
// NOTE: The _prefix_ is optional and can be empty.
func NewS3ProviderConfigLoader(
	ctx ifcore.CbContext,
	bucket, prefix string,
	optional bool,
) *S3ProviderConfigLoader {
	mgr := awamgrstore.NewS3Manager(ctx)
	mgr.UseBucket(bucket)

	fullPrefix := bucket

	if prefix != "" {
		mgr.UsePrefix(prefix)
		fullPrefix = fmt.Sprintf("%s/%s", bucket, prefix)
	}

	return &S3ProviderConfigLoader{
		mgr:        mgr,
		optional:   optional,
		fullPrefix: fullPrefix,
	}
}

// Load loads the user configuration for the given _locationID_ in the S3 bucket.
//
// If the configuration is not found but everything else is correctly setup it will
// not return an error but an empty string. Other errors are returned.
//
// This function is the `providercontext.UserProviderConfigLoader` interface.
func (l *S3ProviderConfigLoader) Load(
	ctx ifcore.CbContext,
	locationID string,
) (string, cberror.Error) {
	var buffer []byte

	// The clone runs on the caller's context and serves both the download and
	// the bucket check below. Clone on an S3 manager always returns one.
	mgr := l.mgr.Clone(ctx).(*awamgrstore.S3Manager)

	mgr.ClearError()
	mgr.DownloadBuffer(fmt.Sprintf("%s.json", locationID), &buffer)

	err := mgr.Error()

	if err == nil {
		return string(buffer), nil
	}

	if !l.optional || err.Code() != http.StatusNotFound {
		return "", err
	}

	// S3 answers a missing bucket and a missing key with the same 404 and no
	// body, so only asking for the bucket itself tells the two apart.
	mgr.ClearError()

	if !mgr.BucketExists() {
		if berr := mgr.Error(); berr != nil {
			return "", berr
		}

		return "", cberror.NewCbErrorf(
			ctx.Service(), http.StatusNotFound, err,
			"user config bucket %s does not exist", l.mgr.Bucket(),
		)
	}

	log.InfoWithLocationID(ctx, locationID).
		WithError(err).
		Str("bucket", l.mgr.Bucket()).
		Str("prefix", l.mgr.Prefix()).
		Msgf("Failed to location user config: %s/%s.json (but it may be ok since it's optional)",
			l.fullPrefix, locationID)

	return "", nil
}
