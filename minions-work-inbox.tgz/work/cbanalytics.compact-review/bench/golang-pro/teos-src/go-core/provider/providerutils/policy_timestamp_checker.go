package providerutils

import (
	"encoding/json"
	"fmt"
	"sort"
	"time"

	"github.com/gobwas/glob"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

type PolicyTimeStampChecker struct {
	id       string
	checkers []policyChecker
}

type policyChecker struct {
	id  string
	glb glob.Glob
	ts  TimeStampInfo
}

type TimeStampInfo struct {
	Drop   int64 `json:"drop"`
	Report int64 `json:"report"`
}

func NewPolicyTimeStampChecker(id string, policy []byte) (*PolicyTimeStampChecker, error) {
	var m map[string]interface{}
	if err := json.Unmarshal(policy, &m); err != nil {
		return nil, err
	}

	ts := map[string]TimeStampInfo{}

	if tsMap, ok := m["ts"]; ok {
		if tsIter, ok := tsMap.(map[string]interface{}); ok {
			for k, v := range tsIter {
				tsInfo := TimeStampInfo{Drop: -1, Report: -1}

				if v, ok := v.(map[string]interface{}); ok {
					if drop, ok := v["drop"]; ok {
						if drop, ok := drop.(float64); ok {
							tsInfo.Drop = int64(drop)
						}
					}

					if report, ok := v["report"]; ok {
						if report, ok := report.(float64); ok {
							tsInfo.Report = int64(report)
						}
					}
				}

				ts[k] = tsInfo
			}
		}
	} else {
		return nil, fmt.Errorf("no ts entry found in policy: %s", string(policy))
	}

	ptsc := &PolicyTimeStampChecker{id: id}

	for id, ts := range ts {
		glb, err := glob.Compile(id, '_')
		if err != nil {
			return nil, err
		}

		ptsc.checkers = append(ptsc.checkers, policyChecker{id: id, glb: glb, ts: ts})
	}

	sort.Slice(ptsc.checkers, func(i, j int) bool {
		return len(ptsc.checkers[j].id) < len(ptsc.checkers[i].id)
	})

	return ptsc, nil
}

// CheckPolicyTimeStamp checks if the id matches any of the configured in policy
//
// First available match is processed, even if multiple matches may be possible.
// When match, it uses the remote sensor timestamp and adds the configuration drop, report
// if it is less than the _cbTimeStamp_ timestamp it will either drop, report or both.
//
// NOTE: The _cbTimeStamp_ may be a local time or retrieved from a database such as a
// device shadow.
//
// If _cbTimeStamp_ time is `IsZero()` it will be set to current environments _UTC_ time.
//
// When the _remoteTimeStampPreserved_ is set to `true`. Then the _cbTimeStamp_ has preserved
// the last updated of the _id_ device original timestamp. This implies that it will check
// if the remoteSensor timestamp is less or equal to the _cbTimeStamp_ to drop. It will calculate
// report from a local timestamp offset from the _cbTimeStamp_ instead from the _remoteSensor_
// (they should be the same).
func (ptsc *PolicyTimeStampChecker) Check(
	id string, remoteSensor, cbTimeStamp coremodel.CbTime32,
	remoteTimeStampPreserved bool,
) (drop bool, report bool, ts *TimeStampInfo) {
	// Set default to now if not set
	if cbTimeStamp.IsZero() {
		cbTimeStamp = coremodel.NewTime32Now().CbTime32UTC()
	}

	for _, pc := range ptsc.checkers {
		if pc.glb.Match(id) {

			// When remote timestamp is preserved in _TEOS_ we handle
			// it differently.
			if remoteTimeStampPreserved {
				// If same or before the cbTimeStamp -> drop it!
				if pc.ts.Drop > 0 {
					// NOTE: We don't follow the drop offset semantics here!
					drop = remoteSensor.Equal(cbTimeStamp) || remoteSensor.Before(cbTimeStamp)
				}

				// If remote sensor is older than (now + report offset) -> report it!
				if pc.ts.Report > 0 {
					report = remoteSensor.Add(
						time.Second * time.Duration(pc.ts.Report),
					).Before(coremodel.NewTime32Now().CbTime32UTC())
				}

				if report || drop {
					ts = &pc.ts
				}

				return
			}

			// Standard handling when device shadow metadata timestamps
			// or local timestamps

			// If remote is newer than cbTimeStamp, then keep it!
			if remoteSensor.After(cbTimeStamp) {
				return
			}

			// Mark it as to be dropped if the remote sensor ts + drop offset
			// is less then the cbTimeStamp.
			//
			// I.e. the cbTimeStamp is newer than the remote sensor ts + drop offset.
			if pc.ts.Drop > 0 {
				drop = remoteSensor.Add(
					time.Second * time.Duration(pc.ts.Drop),
				).Before(cbTimeStamp)
			}

			if pc.ts.Report > 0 {
				report = remoteSensor.Add(
					time.Second * time.Duration(pc.ts.Report),
				).Before(cbTimeStamp)
			}

			if report || drop {
				ts = &pc.ts
			}

			return
		}
	}

	return
}
