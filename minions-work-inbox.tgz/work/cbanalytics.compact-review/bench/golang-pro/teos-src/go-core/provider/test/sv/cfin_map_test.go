package sv

import (
	"fmt"
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/cfgmodel"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestCFINMapIDT maps a distinct set of config into a config discovery. This is akin to the "standard"
// sensor value import.
func TestCFINMapIDT(t *testing.T) {
	pid := "myPlantID"
	lid := "Måssmyren 44"

	now := *coremodel.NewTime32Now()
	simNow := now.Add(10 * time.Second)

	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			//
			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{ID: "virtualCNTIDT", Value: 4, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualBRAND", Value: "siemens", TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualMODELID", Value: "POL348", TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualSERIAL", Value: "serial-123", TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualSTATE", Value: 1, TimeStamp: now},
				&eqmodel.CbDataPointImpl{ID: "virtualIndoorTemp1", Value: 20.4, TimeStamp: now},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualIndoorTempSerial1",
					Value:     "serial-888",
					TimeStamp: now,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualIndoorTempState1", Value: 1, TimeStamp: now},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualIndoorTemp2",
					Value:     22.1,
					TimeStamp: simNow,
				},
				&eqmodel.CbDataPointImpl{
					ID:        "virtualIndoorTempSerial2",
					Value:     "serial-999",
					TimeStamp: now,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualIndoorTempState2", Value: 2, TimeStamp: now},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "thiink", string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		UseCredentialsFunction(
			func(context ifcore.CbContext, cred string, pipeCtx map[string]any, op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
						Credentials: securitymodel.StandardCredentialsImpl{
							Endpoint: "api.climatixic.com",
						}},
					360, nil
			},
		).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/idt-map",
				 "prms": {
					 "LOG": true,
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default",
					 "CRD": "ptr/to/my/credentials",
					 "CFGGEN": {
						"targets": [
							{
								"enabled": true,
								"mode": { "target": "update-only", "prms": "update-only", "mapping": "create-update-delete" },
								"pn": "thiink",
								"op": "sv",
								"group": "widcli",
								"res": "15min",
								"profile": "teos/heating-service",
								"im": "IDT**",
								"prms": { "PID": "[PID]", "TID": "[TID]", "CRD": "[CRD]", "BID": "[BID]", "TZ": "[TZ]" }					
							}
						]
					}			
				}
		}`, pid, lid),
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	m := cbevent.ExtractResult[map[string]cfgmodel.ImportConfigEvent](res, 0)
	require.Equal(t, 1, len(m))

	ie := m["target"]
	assert.Equal(t, lid, ie.LocationID)
	assert.Equal(t, "cfin/idt-map", ie.Profile)
	assert.Equal(t, "thiink", ie.ProviderName)
	require.Len(t, ie.Params, 0)
	require.Len(t, ie.Equipment, 1)

	eq := ie.Equipment[0]

	assert.Equal(t, lid, eq.LocationID)
	assert.Equal(t, pid, eq.EquipmentID)
	assert.Equal(t, "POL348", eq.ModelID)
	assert.Equal(t, "siemens", eq.ModelName)
	assert.Equal(t, "serial-123", eq.Serial)
	assert.Equal(t, "default", eq.OwnerID)
	require.Len(t, eq.Location, 0)
	require.Len(t, eq.Params, 6)
	assert.Equal(t, pid, eq.RemoteID)
	assert.Equal(t, "", eq.TeosID)
	assert.Equal(t, "online", eq.Params[string(eqmodel.EqState)])
	assert.Equal(t, float64(now.Unix()), eq.Params[string(eqmodel.EqLastUpdated)])
	assert.Equal(t, float64(4), eq.Params["CNTIDT"])

	require.Len(t, ie.Sensors, 4)

	mp := map[string]eqmodel.InstalledSensor{}

	for _, s := range ie.Sensors {
		mp[s.SensorID] = s
	}

	require.Contains(t, mp, "IDT_O1")
	require.Contains(t, mp, "IDT_O2")
	require.Contains(t, mp, "IDT_O3")
	require.Contains(t, mp, "IDT_O4")

	s := mp["IDT_O1"]

	assert.Equal(t, lid, s.LocationID)
	assert.Equal(t, pid, s.EquipmentID)
	assert.Equal(t, "serial-888", s.Serial)
	assert.Equal(t, "default", s.OwnerID)
	assert.Equal(t, "sensative", s.ModelName)
	assert.Equal(t, "strip-v2", s.ModelID)
	assert.Equal(t, eqmodel.SensorIndoorTemp, s.Type)
	assert.Equal(t, "virtualIndoorTemp1", s.RemoteID)
	assert.Equal(t, "", s.TeosID)
	assert.Equal(t, "online", s.Params[string(eqmodel.EqState)])
	assert.Equal(t, float64(now.Unix()), s.Params[string(eqmodel.EqLastUpdated)])
	assert.Contains(t, s.Params, "OPVAL")
	assert.Equal(t, float64(20.4), s.Params["OPVAL"].(map[string]any)["IDT"])

	s = mp["IDT_O2"]

	assert.Equal(t, lid, s.LocationID)
	assert.Equal(t, pid, s.EquipmentID)
	assert.Equal(t, "serial-999", s.Serial)
	assert.Equal(t, "default", s.OwnerID)
	assert.Equal(t, "sensative", s.ModelName)
	assert.Equal(t, "strip-v2", s.ModelID)
	assert.Equal(t, eqmodel.SensorIndoorTemp, s.Type)
	assert.Equal(t, "virtualIndoorTemp2", s.RemoteID)
	assert.Equal(t, "", s.TeosID)
	assert.Equal(t, "offline", s.Params[string(eqmodel.EqState)])
	assert.Equal(
		t,
		float64(simNow.Unix()),
		s.Params[string(eqmodel.EqLastUpdated)],
	)
	assert.Contains(t, s.Params, "OPVAL")
	assert.Equal(t, float64(22.1), s.Params["OPVAL"].(map[string]any)["IDT"])

	s = mp["IDT_O3"]

	assert.Equal(t, lid, s.LocationID)
	assert.Equal(t, pid, s.EquipmentID)
	assert.Equal(t, "", s.Serial)
	assert.Equal(t, "default", s.OwnerID)
	assert.Equal(t, "sensative", s.ModelName)
	assert.Equal(t, "strip-v2", s.ModelID)
	assert.Equal(t, eqmodel.SensorIndoorTemp, s.Type)
	assert.Equal(t, "virtualIndoorTemp3", s.RemoteID)
	assert.Equal(t, "", s.TeosID)
	assert.Equal(t, "online", s.Params[string(eqmodel.EqState)])
	assert.True(t, s.Params[string(eqmodel.EqLastUpdated)].(float64) >= float64(now.Unix()))
	assert.Contains(t, s.Params, "OPVAL")
	assert.NotContains(t, s.Params["OPVAL"], "IDT")

	s = mp["IDT_O4"]

	assert.Equal(t, lid, s.LocationID)
	assert.Equal(t, pid, s.EquipmentID)
	assert.Equal(t, "", s.Serial)
	assert.Equal(t, "default", s.OwnerID)
	assert.Equal(t, "sensative", s.ModelName)
	assert.Equal(t, "strip-v2", s.ModelID)
	assert.Equal(t, eqmodel.SensorIndoorTemp, s.Type)
	assert.Equal(t, "virtualIndoorTemp4", s.RemoteID)
	assert.Equal(t, "", s.TeosID)
	assert.Equal(t, "online", s.Params[string(eqmodel.EqState)])
	assert.True(t, s.Params[string(eqmodel.EqLastUpdated)].(float64) >= float64(now.Unix()))
	assert.Contains(t, s.Params, "OPVAL")
	assert.NotContains(t, s.Params["OPVAL"], "IDT")
}

func BenchmarkCFINMapIDT(t *testing.B) {
	pid := "myPlantID"
	lid := "Måssmyren 44"

	now := *coremodel.NewTime32Now()
	simNow := now.Add(10 * time.Second)

	payload := []eqmodel.CbDataPoint{
		&eqmodel.CbDataPointImpl{ID: "virtualCNTIDT", Value: 4, TimeStamp: now},
		&eqmodel.CbDataPointImpl{ID: "virtualBRAND", Value: "siemens", TimeStamp: now},
		&eqmodel.CbDataPointImpl{ID: "virtualMODELID", Value: "POL348", TimeStamp: now},
		&eqmodel.CbDataPointImpl{ID: "virtualSERIAL", Value: "serial-123", TimeStamp: now},
		&eqmodel.CbDataPointImpl{ID: "virtualSTATE", Value: 1, TimeStamp: now},
		&eqmodel.CbDataPointImpl{ID: "virtualIndoorTemp1", Value: 20.4, TimeStamp: now},
		&eqmodel.CbDataPointImpl{
			ID:        "virtualIndoorTempSerial1",
			Value:     "serial-888",
			TimeStamp: now,
		},
		&eqmodel.CbDataPointImpl{ID: "virtualIndoorTempState1", Value: 1, TimeStamp: now},
		&eqmodel.CbDataPointImpl{
			ID:        "virtualIndoorTemp2",
			Value:     22.1,
			TimeStamp: simNow,
		},
		&eqmodel.CbDataPointImpl{
			ID:        "virtualIndoorTempSerial2",
			Value:     "serial-999",
			TimeStamp: now,
		},
		&eqmodel.CbDataPointImpl{ID: "virtualIndoorTempState2", Value: 2, TimeStamp: now},
	}

	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			//
			return payload, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "thiink", string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		UseCredentialsFunction(
			func(context ifcore.CbContext, cred string, pipeCtx map[string]any, op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
						Credentials: securitymodel.StandardCredentialsImpl{
							Endpoint: "api.climatixic.com",
						}},
					360, nil
			},
		).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	data := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/idt-map",
				 "prms": {
					 "LOG": false,
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default"
				}
		}`, pid, lid),
		},
	})

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		result, invokeError := pctx.Invoker().InvokeRaw(ctx, data)

		require.NoError(t, invokeError)
		require.NotNil(t, result)
	}
}
