package evb

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifstate"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrevent/awsmgrevent"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

type Options struct {
	// RemoveKeys is a set of keys that will be removed from the event.
	RemoveKeys []string
	// AllowEmptyDetails is a flag to allow sending events with empty details.
	AllowEmptyDetails bool
	// OnlyTimeStampAndValueOnDataPoint is a flag to only send timestamp and value when the event
	// is one or more `eqmodel.CbDataPoint`(s).
	//
	// Otherwise it will marshal the error, partition and other fields as well.
	OnlyTimeStampAndValueOnDataPoint bool
}

// ImportEventViaEventBridge will import data and send it to the event bridge.
//
// The _additionalDetail_ can be supplied to add more info (if not already existent) into
// the _detail_ field of the event. It also supports macro $<parameter> of which the value
// is retrieved from the global parameters.
//
// When _allowEmptyDetails_ is set to `true`, it will send events with empty details.
//
// This function handles the following pointer to event types in "target":
// - `cbevent.CloudEventImpl`
// - `cbevent.DataPointCloudEventImpl` (it will be tried by the `opt.Convert` function)
//
// When `cbevent.DataPointCloudEventImpl` is present in _target["target"]_, it will check
// if _stateful_ key is present in _pipeCtx_ and commit the stateful data and sent that as
// well. The type expected in _stateful_ is `ifstate.StatefulCommitter`.
//
// WARN: When _stateful_ exists for plain `cbevent.CloudEventImpl`, it will `Abort` the _stateful_
// import and log a warning since it does not know what to do with it.
func ImportEventViaEventBridge(opt Options) providerpipe.TargetFunction { /* NOSONAR */
	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any, target map[string]any) cberror.Error {
		//
		var evt *cbevent.CloudEventImpl

		var committer ifstate.StatefulCommitter

		if st, ok := pipeCtx["stateful"]; ok {
			if c, ok := st.(ifstate.StatefulCommitter); ok {
				committer = c
			}
		}

		lid := pc.GetParamAsStringWithDefault(string(ifprovider.ParameterLocationID), "")

		if trg, ok := target["target"]; ok {
			if evt, ok := trg.(*cbevent.DataPointCloudEventImpl); ok {
				if evt.Data.LocationID == "" {
					evt.Data.LocationID = lid
				}

				return HandleDataPointCloudEvent(
					ctx, evt, committer, pc.GetGlobalParams(), opt,
				)
			}

			if e, ok := trg.(*cbevent.CloudEventImpl); ok {
				evt = e
			}
		}

		if evt == nil {
			return cberror.NewCbErrorf(
				ctx.Service(), 400, nil, "Failed to get the event from the target",
			)
		}

		if committer != nil {
			log.Warn(ctx).
				WithMethod("ImportEventViaEventBridge").
				WithBody(evt).
				Msg("Stateful committer is present, but the event is not DataPointCloudEventImpl (aborting committer")

			if err := committer.Abort(ctx); err != nil {
				log.Error(ctx).
					WithMethod("ImportEventViaEventBridge").
					WithError(err).
					Msg("Failed to abort stateful committer")
			}
		}

		res, err := awsmgrevent.NewAWSEventManager(ctx.Config()).PutEvents(ctx, evt)
		if err != nil {
			log.Error(ctx).
				WithMethod("ImportEventViaEventBridge").
				WithError(err).
				Msg("Failed to send event to EventBridge")
		}

		return emitCoreToTargetReport(ctx, lid, evt, res, true /*suppressError*/)
	}
}
