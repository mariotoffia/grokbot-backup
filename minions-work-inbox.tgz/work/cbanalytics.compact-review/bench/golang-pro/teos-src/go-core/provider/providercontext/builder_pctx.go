package providercontext

import (
	"io/fs"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/fexp"

	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
)

// ProviderContextBuilderImpl is a builder to build a complete provider service.
type ProviderContextBuilderImpl struct {
	// pipelineBuilder is the builder to create the pipelineBuilder to use
	// to execute the requests
	pipelineBuilder *providerpipe.PipelineBuilder
	// providerConfig is the provider configuration (if set). This is used
	// if the _pipelineBuilder_ do not have configuration set (and this is).
	providerConfig fs.FS
	// instance is the instance that is return when built.
	instance *ProviderContextImpl
	// built is a flag to indicate if the instance has been built.
	built bool
}

// NewProviderContextBuilder creates a new `ProviderContextBuilder
func NewProviderContextBuilder() *ProviderContextBuilderImpl {
	return &ProviderContextBuilderImpl{
		instance: &ProviderContextImpl{},
	}
}

// Build will return the dispatcher to use for the provider service.
//
// Use the `ProviderContext.Start()` to start the dispatcher. For
// a lambda dispatcher, it will freeze the current goroutine and
// wait for requests to come in.
func (b *ProviderContextBuilderImpl) Build() ProviderContext {
	// Set a few default on the pipeline, if these are already set,
	// nothing will be changed.
	b.pipelineBuilder.
		UseCredentialsFunction(providerpipe.DefaultObtainCredentials).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(b.instance.rootContext))

	if b.providerConfig != nil {
		b.pipelineBuilder.WithConfigRepository(
			providerconfig.NewProviderConfigRepository(
				b.instance.rootContext,
				providerconfig.NewFsProviderConfigLoader(b.providerConfig),
			),
		)
	}

	b.instance.pipeline = b.pipelineBuilder.Build()

	b.built = true
	return b.instance
}

// AllowGlobalParameterMutation will allow the global parameters of a provider configuration to be mutated.
//
// NOTE: Make sure that the provider configuration is always cloned and used for a single purpose when this
// option is set.
func (b *ProviderContextBuilderImpl) AllowGlobalParameterMutation() *ProviderContextBuilderImpl {
	b.instance.allowMutateGlobalParams = true
	return b
}

// AsProviderType specifies the type of the provider.
//
// NOTE: This is the main type, it may perform other operations as well but
// the main purpose is to e.g. import sensor values (but is capable of a _dpdisc_ etc.)
func (b *ProviderContextBuilderImpl) AsProviderType(
	providerType locationmodel.ProviderOperation,
) *ProviderContextBuilderImpl {
	b.instance.providerType = providerType
	return b
}

// WithRootContext sets the root context for the provider _TEOS_ service.
//
// All requests towards the provider is a sub-context from this one. Make
// sure to configure the root context with the correct options in order to
// handle the requests correctly footnote:[Such as adding polices,
// policy decision points (PDP), etc.].
func (b *ProviderContextBuilderImpl) WithRootContext(
	rootContext ifcore.CbContext,
) *ProviderContextBuilderImpl {
	b.instance.rootContext = rootContext
	return b
}

// WithProviderConfiguration is used when the `*providerpipe.PipelineBuilder` submitted via
// the `UsePipeline` is not configured with a configuration repository. This is added when
// `Build` is called.
func (b *ProviderContextBuilderImpl) WithProviderConfiguration(
	fs fs.FS,
) *ProviderContextBuilderImpl {
	b.providerConfig = fs
	return b
}

// UsePipeline sets the pipeline builder used to create the pipeline.
//
// NOTE: When passing the _builder_ the caller is passing the ownership
// of the pipeline to the `ProviderContextBuilder`. The caller should not
// use the pipeline after passing it to this method.
//
// The `ProviderContextBuilder` will take ownership of the pipeline
// and will set defaults for obtain & verify, credentials including creating
// session store (if not yet set).
func (b *ProviderContextBuilderImpl) UsePipeline(
	builder *providerpipe.PipelineBuilder,
) *ProviderContextBuilderImpl {
	b.pipelineBuilder = builder
	return b
}

// UseProviderDispatcher calls the given factory function to create a HandlerInvoker
// and stores it as the invoker for this provider.
func (b *ProviderContextBuilderImpl) UseProviderDispatcher(
	f ProviderHandlerFunc,
) *ProviderContextBuilderImpl {
	h := f(b.instance)
	b.instance.invoker = h
	return b
}

// UseInvoker sets the RawInvoker for this provider.
// When set, ProviderContext.Invoker() returns it directly.
func (b *ProviderContextBuilderImpl) UseInvoker(
	inv dispruntime.RawInvoker,
) *ProviderContextBuilderImpl {
	b.instance.invoker = inv
	return b
}

// UseHandler sets a HandlerInvoker directly as the invoker.
// Use this when constructing a handler without a ProviderHandlerFunc factory.
func (b *ProviderContextBuilderImpl) UseHandler(
	h dispruntime.HandlerInvoker,
) *ProviderContextBuilderImpl {
	b.instance.invoker = h
	return b
}

// UseLoaders sets the _optional_ user configuration loader(s) to use.
//
// .Example S3 User Configuration Loader
// [source,go]
// ----
// UseLoader(s3.NewS3ProviderConfigLoader(ctx, "my-bucket", "rtcingest/sv/v1.0.0", true))
// ----
//
// When this is set, the `Execute` function will use the loader when it needs to load user configuration.
func (b *ProviderContextBuilderImpl) UseLoaders(
	userConfigLoader ...UserProviderConfigLoader,
) *ProviderContextBuilderImpl {
	b.instance.userConfigLoader = fexp.Filter(
		userConfigLoader,
		func(loader UserProviderConfigLoader) bool {
			return loader != nil
		},
	)

	return b
}

func (b *ProviderContextBuilderImpl) UserConfigUsage(
	usage ProviderUserConfigUsage,
) *ProviderContextBuilderImpl {
	b.instance.userConfigUsage = usage
	return b
}

// ProviderContext exposes the instance that is being built.
//
// CAUTION: Do not use this instance to anything before the `Build` is called. It will `panic`!!
func (b *ProviderContextBuilderImpl) ProviderContext() ProviderContext {

	if !b.built {
		panic("ProviderContextBuilder.ProviderContext() called before Build()")
	}

	return b.instance
}
