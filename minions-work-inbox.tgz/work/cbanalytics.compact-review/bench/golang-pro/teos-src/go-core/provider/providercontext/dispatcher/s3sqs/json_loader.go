package s3sqs

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/awamgrstore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/storeloader"
	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/model/storagemodel"
)

// JSONLoaderFunc is the function that loads the JSON data from a _location_ and a _key_
// inside that location. For example the _location_ could be a S3 bucket and the _key_
// could be the path to the _JSON_ object inside the bucket.
//
// It will decode the object and return the _payloadData_. It is a best effort function
// any partial errors are logged but the data is still returned. If all fails an error
// is returned.
//
// NOTE: It may return multiple `PayloadData` for a single _LocationID_.
type JSONLoaderFunc func(
	ctx ifcore.CbContext,
	location, key string,
) ([]*PayloadData, cberror.Error)

// S3JsonLoader will load the JSON data from the S3 bucket and return a map of
// locationID to payloadData. Where the payloadData is for the provider
// pipeline to process.
//
// It uses the generic storeloader utility for download, decompression, and NDJSON
// unmarshalling. The domain-specific PayloadData grouping (by LocationID with
// duplicate-ID handling) is applied after unmarshalling.
//
// CAUTION: It expect the _JSON_ to be on JSON per line format (jsonl), that it
// each line is separated by a single `\n`. The format is *REQUIRED* to be
// `ingestionmodel.CbSensorReportItem`.
//
// This function is a best-effort function where it will try to load as many JSON
// objects as possible, each one, it fails, it will log the error (as warning) and continue.
//
// If all lines fails, it will, though, return an error.
//
// NOTE: When it finds a duplicate, for same _LocationID_ and _ID_, it will create a new
// payloadData. Hence, it may return multiple `PayloadData` for a single _LocationID_.
func S3JsonLoader(
	ctx ifcore.CbContext,
	location, key string,
) ([]*PayloadData, cberror.Error) {
	// Use storeloader to download, decompress, and unmarshal NDJSON.
	var (
		reports []ingestionmodel.CbSensorReportItem
		loadErr cberror.Error
	)

	loader := storeloader.NewStorageEventLoader(
		ctx,
		awamgrstore.NewStorageManagerS3(ctx),
		storeloader.NDJSONUnmarshal[ingestionmodel.CbSensorReportItem](),
		func(
			items []ingestionmodel.CbSensorReportItem,
			_ storagemodel.ObjectDescriptor,
			err cberror.Error,
		) {
			if err != nil {
				loadErr = err
				return
			}
			reports = items
		},
		storeloader.WithDecompression(true),
	)

	if err := loader.Process([]storagemodel.StorageObjectEvent{
		{Location: location, Key: key, Source: "aws:s3"},
	}); err != nil {
		return nil, err
	}

	if loadErr != nil {
		return nil, loadErr
	}

	// Group reports into PayloadData by LocationID (domain-specific logic).
	// Items with empty LocationID are logged and skipped. When a duplicate
	// ID is found within the same LocationID, a new PayloadData is created.
	m := map[string][]*PayloadData{}

	for i := range reports {
		report := reports[i]

		if report.LocationID == "" {
			log.Warn(ctx).
				WithMethod("loadJSON").
				Msg("LocationID is empty")

			continue
		}

		// New -> Add
		if payload, ok := m[report.LocationID]; !ok {
			m[report.LocationID] = append(m[report.LocationID], &PayloadData{
				LocationID: report.LocationID,
				Data: map[string]any{
					report.GetID(): &report,
				},
			})
		} else {
			// Existing -> Check if ID already exists in last payload.
			last := payload[len(payload)-1]

			if _, ok := last.Data[report.GetID()]; ok {
				// Found -> Create new payload.
				m[report.LocationID] = append(m[report.LocationID], &PayloadData{
					LocationID: report.LocationID,
					Data: map[string]any{
						report.GetID(): &report,
					},
				})
			} else {
				// Not found -> Update last payload.
				last.Data[report.GetID()] = &report
			}
		}
	}

	if len(m) == 0 && len(reports) > 0 {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), 500, nil,
			"No valid reports (all had empty LocationID), total: %d", len(reports),
		)
	}

	result := make([]*PayloadData, 0, len(m))

	for lid := range m {
		result = append(result, m[lid]...)
	}

	return result, nil
}
