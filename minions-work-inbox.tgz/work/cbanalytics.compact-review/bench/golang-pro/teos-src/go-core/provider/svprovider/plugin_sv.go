package svprovider

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"io/fs"
	"os"

	"github.com/aws/aws-lambda-go/events"
	"github.com/google/uuid"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/lambdasupport"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerexecutors"
	"github.com/Thiink-LLC/teos/go-core/pubsub"
	dispatcher "github.com/Thiink-LLC/teos/go-core/tkdisp/cbprovider"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// SVPlugin drives a `SensorValuesInboundPlugin`.
type SVPlugin struct {
	plugin       SensorValuesInboundPlugin
	pluginCaps   *coremodel.Capabilities
	sessionStore *config.SessionStore
	contextName  string
	provider     string
	reader       *bufio.Reader
}

// NewPlugin creates a new plugin ready for execution.
//
// This accepts the minimal interface `provider.SensorValuesInboundPlugin` but
// is not usable with that interface. Currently, all plugins must implement `PipelineAwareProvider`
// interface method. Below table outlines the interfaces and their functions.
//
// .Interfaces & Functions
// |===
// |Interface |Functionality
// |PipelineAwareProviderEx
// a|
// Bypasses all functionality around credentials and pipe management. Instead it's own pipe is used.
//
// NOTE: This is *mutual exclusive* the interface `PipelineAwareProvider`!
//
// |PipelineCredentialsProvider
// |When the default mechanism is not enough to get and validate credentials.
//
// |PipelineAwareProvider
// |Base functionality for pipeline execution, get templates and target type is a _REQUIREMENT_ to  use `SVPlugin` (if not PipelineAwareProviderEx).
//
// |InitializationProvider
// |If process initialization and context / session store management is wanted
//
// |Provider
// |Base interface that only provides with capability exposure and the name of the provider / plugin.
//
// |SensorValuesInboundPluginDsBuilding
// |Handles `dsmodel.DsFullBuilding` sensor value import (includes `PipelineAwareProvider`).
//
// |===
func NewPlugin(
	plugin SensorValuesInboundPlugin,
	contextName, provider string,
	reader *bufio.Reader) *SVPlugin {
	caps := plugin.GetCapabilities()

	return &SVPlugin{
		contextName: contextName,
		provider:    provider,
		reader:      reader,
		plugin:      plugin,
		pluginCaps:  &caps,
	}

}

// NewDsBuildingPlugin creates a sensor value import plugin using the `dsmodel.DsBuilding` device shadow as update method.
//
// See documentation for `NewPlugin` for more details on parameters and usage / implementation.
func NewDsBuildingPlugin(
	plugin SensorValuesInboundPluginDsBuilding,
	contextName, provider string,
	reader *bufio.Reader) *SVPlugin {
	return NewPlugin(plugin, contextName, provider, reader)

}

// Execute will start the execution. It will in it's turn call `ProviderExecutor`
// and return the error code.
//
// See `ProviderExecutor` for more details.
func (sv *SVPlugin) Execute() int {
	return providerexecutors.ProviderExecutor(sv, sv.contextName, sv.provider, sv.reader)

}

// endpoint is holder for command line switch _ep_ that may express a *deviceshadow Data-ATS endpoint*.
var endpoint string

// InitFlags adds _ep_ as a `StringVar` to set a remote endpoint with help text
// "Set the device shadow Data-ATS endpoint to be used. Otherwise it is picket up by env CB_REP"
func (sv *SVPlugin) InitFlags(flagSet *flag.FlagSet) bool {
	add := true
	if sv.pluginCaps.BooleanByName(provider.CapsProviderInitFlags, false) {
		if pb, ok := sv.plugin.(provider.InitializationProvider); ok {
			add = !pb.InitFlags(flagSet)
		}
	}

	if add {
		flagSet.StringVar(
			&endpoint,
			"ep",
			"",
			"Set the device shadow Data-ATS endpoint to be used. Otherwise it is picket up by env CB_REP",
		)
	}

	return true /* allow caller to have own flags */
}

// ContextInitialized resolves any endpoint set in _ep_ switch or overrides using environment variable `CB_REP`
func (sv *SVPlugin) ContextInitialized(
	context ifcore.CbContext,
	sessionStore *config.SessionStore,
) {
	sv.sessionStore = sessionStore

	if endpoint == "" {
		endpoint = os.Getenv("CB_REP")
	}

	if endpoint != "" {
		if ep := utils.CreateSchemeURL("https", endpoint); nil != ep {
			context.SetValue(provider.ProviderCtxEndpoint, ep)
		} else {
			panic(fmt.Sprintf("Failed to parse endpoint: %s", endpoint))
		}
	}

	if pb, ok := sv.plugin.(provider.InitializationProvider); ok {
		pb.ContextInitialized(context, sessionStore)
	}
}

// ContextOptions returns the augmented options or the complete replacement of options that will create
// the initial, _static_, `ifcore.CbContext`.
//
// The _current_ is the ones intended to be used to initialize the new `ifcore.CbContext`.
func (sv *SVPlugin) ContextOptions(
	current []ifcore.CbContextOption,
) (options []ifcore.CbContextOption, replace bool) {
	if pb, ok := sv.plugin.(provider.StaticContextInitializerProvider); ok {
		return pb.ContextOptions(current)
	}

	return nil, false
}

// GetPolicyRetrievalPoints is expected to return zero or more
// `ifcore.PolicyRetrievalPoint` that will be added to the `ifcore.PolicyContext`.
func (sv *SVPlugin) GetPolicyRetrievalPoints() []ifcore.PolicyRetrievalPoint {
	if pb, ok := sv.plugin.(provider.StaticPRPContributingProvider); ok {
		return pb.GetPolicyRetrievalPoints()
	}

	return nil

}

// GetPDPConfigFSys is expected to return zero or more `fs.FS` that will be scanned
// for _"**-pdp.json"_ object. All other files are ignored.
func (sv *SVPlugin) GetPDPConfigFSys() []fs.FS {
	if pb, ok := sv.plugin.(provider.StaticPDPContributingProvider); ok {
		return pb.GetPDPConfigFSys()
	}

	return nil

}

// BuildPublishSubscribeManager implements the `provider.PublishSubscribeContributingProvider`
// interface.
func (sv *SVPlugin) BuildPublishSubscribeManager(builder *pubsub.ManagerBuilder) {
	if pb, ok := sv.plugin.(provider.PublishSubscribeManagerContributingProvider); ok {
		pb.BuildPublishSubscribeManager(builder)
	}

}

// GetPEPConfig gets the `ifcore.PolicyEnforcementPoint` registration for this provider.
func (sv *SVPlugin) GetPEPConfig() *provider.PEPConfig {
	if pb, ok := sv.plugin.(provider.StaticPEPContributingProvider); ok {
		return pb.GetPEPConfig()
	}

	return nil
}

// SetupDispatchers set up the dispatcher to handle `cbevent.EventTransport`, `apiv1 events.APIGatewayProxyRequest`,
// `apiv2 events.APIGatewayV2HTTPRequest`, and `cbevent.NativeTransport` as `events.SQSEvent`. All of them are
// realized as one `cbevent.SensorValueInboundEvent` except for _SQSEvent_ of which has a batch of those.
//
// If _provider.ProviderCtxDryRun_ has been set to `true` in _context_, it wil set `SensorValueInboundEvent.DryRun` to `true`. It
// also tries to extract the _provider.ProviderCtxEndpoint_ as a `*url.URL` (endpoint).
func (sv *SVPlugin) SetupDispatchers(
	context ifcore.CbContext,
	lambdaType, path string,
) dispatcher.Dispatcher {
	dryrun := utils.GetBoolFromContext(context, provider.ProviderCtxDryRun)
	ep := utils.GetURLFromContext(context, provider.ProviderCtxEndpoint)

	return dispatcher.SetupDispatcher(context, lambdaType, path,
		func(c ifcore.CbContext,
			et cbevent.EventTransport,
			evt cbevent.SensorValueInboundEvent) (cbevent.ProviderResultEvent, error) {
			return sv.importSensorValues(c, ep, dryrun, &evt)
		},
		func(c ifcore.CbContext,
			apiv1 events.APIGatewayProxyRequest,
			evt cbevent.SensorValueInboundEvent) (cbevent.ProviderResultEvent, error) {
			return sv.importSensorValues(c, ep, dryrun, &evt)
		},
		func(c ifcore.CbContext,
			apiv2 events.APIGatewayV2HTTPRequest,
			evt cbevent.SensorValueInboundEvent) (cbevent.ProviderResultEvent, error) {
			return sv.importSensorValues(c, ep, dryrun, &evt)
		},
		func(c ifcore.CbContext, native cbevent.NativeTransport, evt events.SQSEvent) error {
			return sv.processSQSEvent(c, &evt, ep, dryrun)
		},
	)
}

// DoCommand dispatches the `cbevent.SensorValueInboundEvent` through a _shell_ command.
func (sv *SVPlugin) DoCommand(context ifcore.CbContext, reader *bufio.Reader) int {
	if l, ok := logger.ClsLog(zerolog.InfoLevel, "main", logger.LDTUntyped, logger.LISUnclassified, context); ok {
		l.Msg(
			"No lambda, reading from stdin as SVIInstructionEvent",
		)
	}

	var evt cbevent.SensorValueInboundEvent
	err := lambdasupport.ReadDataFromReader(context, reader, &evt)

	if err != nil {
		panic(err.Error())
	}

	dryrun := utils.GetBoolFromContext(context, provider.ProviderCtxDryRun)
	ep := utils.GetURLFromContext(context, provider.ProviderCtxEndpoint)

	evt.CorrID = fmt.Sprintf("console-%s", uuid.New().String())

	var outdata []byte
	var marshalError error

	res, err := sv.importSensorValues(context, ep, dryrun, &evt)

	outdata, marshalError = json.MarshalIndent(res, "", " ")
	if marshalError != nil {
		panic(marshalError)
	}

	if l, ok := logger.ClsLog(zerolog.InfoLevel, "DoCommand", logger.LDTUntyped, logger.LISUnclassified, context); ok {
		l.Msgf(
			"Result from importSensorValues: %v",
			string(outdata),
		)
	}

	if err != nil {
		panic(err)
	}

	return 0
}
