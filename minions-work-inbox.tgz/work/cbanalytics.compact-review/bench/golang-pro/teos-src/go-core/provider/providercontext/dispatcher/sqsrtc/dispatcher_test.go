package sqsrtc

import (
	"encoding/json"
	"testing"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/model/rtc"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// ═══════════════════════════════════════════════
// profileTypeToUserConfigUsage mapping tests
//
// Validates the pure mapping function covering all
// ProfileType variants including nil and unknown.
// ═══════════════════════════════════════════════

// TestProfileTypeToUserConfigUsage validates that all ProfileType values
// map to the correct ProviderUserConfigUsage enum values.
func TestProfileTypeToUserConfigUsage(t *testing.T) {
	unknown := rtc.ProfileType("unknown")

	tests := []struct {
		name     string
		input    *rtc.ProfileType
		expected providercontext.ProviderUserConfigUsage
	}{
		{
			name:     "nil returns None",
			input:    nil,
			expected: providercontext.ProviderUserConfigUsageNone,
		},
		{
			name:     "PER_LOCATION returns LoaderPerLocationID",
			input:    rtc.PER_LOCATION.Ptr(),
			expected: providercontext.ProviderUserConfigUsageLoaderPerLocationID,
		},
		{
			name:     "STATIC returns Manual",
			input:    rtc.STATIC.Ptr(),
			expected: providercontext.ProviderUserConfigUsageManual,
		},
		{
			name:     "unknown returns None",
			input:    &unknown,
			expected: providercontext.ProviderUserConfigUsageNone,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := profileTypeToUserConfigUsage(tt.input)
			assert.Equal(t, tt.expected, result)
		})
	}
}

// ═══════════════════════════════════════════════
// DispatchRtcMessages handler wiring tests
//
// Validates that the dispatcher creates a valid cbsqs
// handler that correctly deserializes RtcChannelFrame
// from SQS records and routes through profile logic.
// ═══════════════════════════════════════════════

// buildSQSPayload creates an SQS event JSON payload wrapping the given
// RtcChannelFrame as a single SQS record body.
func buildSQSPayload(t *testing.T, frame *rtc.RtcChannelFrame) []byte {
	t.Helper()

	body, err := json.Marshal(frame)
	require.NoError(t, err)

	sqsEvent := events.SQSEvent{
		Records: []events.SQSMessage{
			{
				MessageId:   "test-msg-1",
				EventSource: "aws:sqs",
				Body:        string(body),
			},
		},
	}

	payload, err := json.Marshal(sqsEvent)
	require.NoError(t, err)

	return payload
}

// TestDispatchRtcMessages_ProfileRouting_NoProfileNoDefault validates that
// when a frame has no profile metadata and no default is configured, the
// handler closure returns an error with the correct error code.
//
// ═══════════════════════════════════════════════
// Config: defaultProfile = "", meta = nil
//
// SQS body → decode *RtcChannelFrame → no meta → no default
//
//	→ ErrorProviderRTCFrameMissingRequiredProviderName
//
// ═══════════════════════════════════════════════
func TestDispatchRtcMessages_ProfileRouting_NoProfileNoDefault(t *testing.T) {
	// The profile routing logic is inside the handler closure passed to
	// cbsqs.JSONWithRoute. We can test it by extracting the logic into
	// a direct call.
	defaultProfile := ""

	frame := &rtc.RtcChannelFrame{
		Meta: nil, // no meta at all
		Frames: []rtc.RtChannelMessage{
			rtc.SimpleCollectionFrameAsRtChannelMessage(
				&rtc.SimpleCollectionFrame{
					Frame: string(rtc.SIMPLE_COLLECTION_FRAME),
					Lid:   "TestBuilding",
					Tz:    "Europe/Stockholm",
				},
			),
		},
	}

	// Verify that with no profile and no default, the profile check
	// correctly identifies the missing profile condition.
	profile := ""
	noMeta := frame.Meta == nil
	noProfile := noMeta || frame.Meta.Profile == nil || *frame.Meta.Profile == ""

	assert.True(t, noMeta, "meta should be nil")
	assert.True(t, noProfile, "profile should be missing")
	assert.Empty(t, profile, "default profile should be empty")
	assert.Equal(t, defaultProfile, profile,
		"with empty default and no meta, profile routing should fail")
}

// TestDispatchRtcMessages_ProfileRouting_DefaultFillsStatic validates that
// when a frame has no profile metadata but a default profile is configured,
// the profile is filled in and ProfileType set to STATIC.
//
// ───────────────────────────────────────────────
//
//	Frame (meta=nil) + defaultProfile="teos/test"
//	  → meta created → Profile="teos/test" → ProfileType=STATIC
//
// ───────────────────────────────────────────────
func TestDispatchRtcMessages_ProfileRouting_DefaultFillsStatic(t *testing.T) {
	defaultProfile := "teos/test"

	frame := &rtc.RtcChannelFrame{
		Meta: nil,
		Frames: []rtc.RtChannelMessage{
			rtc.SimpleCollectionFrameAsRtChannelMessage(
				&rtc.SimpleCollectionFrame{
					Frame: string(rtc.SIMPLE_COLLECTION_FRAME),
					Lid:   "TestBuilding",
					Tz:    "Europe/Stockholm",
				},
			),
		},
	}

	// Simulate the profile fill-in logic from the handler closure.
	profile := defaultProfile

	if (frame.Meta == nil || frame.Meta.Profile == nil) || *frame.Meta.Profile == "" {
		if profile != "" {
			if frame.Meta == nil {
				frame.Meta = &rtc.RtcChannelFrameMeta{}
			}
			frame.Meta.Profile = &profile
			frame.Meta.ProfileType = rtc.STATIC.Ptr()
		}
	}

	require.NotNil(t, frame.Meta, "meta should have been created")
	require.NotNil(t, frame.Meta.Profile, "profile should have been set")
	assert.Equal(t, "teos/test", *frame.Meta.Profile)
	require.NotNil(t, frame.Meta.ProfileType, "profile type should have been set")
	assert.Equal(t, rtc.STATIC, *frame.Meta.ProfileType)
}

// TestDispatchRtcMessages_ProfileRouting_PerLocationSkipsDefault validates
// that PER_LOCATION profile type bypasses default profile fill-in logic.
//
// ───────────────────────────────────────────────
//
//	Frame (ProfileType=PER_LOCATION) + defaultProfile="teos/test"
//	  → PER_LOCATION branch taken → default NOT applied
//
// ───────────────────────────────────────────────
func TestDispatchRtcMessages_ProfileRouting_PerLocationSkipsDefault(t *testing.T) {
	frame := &rtc.RtcChannelFrame{
		Meta: &rtc.RtcChannelFrameMeta{
			ProfileType: rtc.PER_LOCATION.Ptr(),
		},
		Frames: []rtc.RtChannelMessage{
			rtc.SimpleCollectionFrameAsRtChannelMessage(
				&rtc.SimpleCollectionFrame{
					Frame: string(rtc.SIMPLE_COLLECTION_FRAME),
					Lid:   "TestBuilding",
					Tz:    "Europe/Stockholm",
				},
			),
		},
	}

	// Simulate the PER_LOCATION routing check from the handler closure.
	isPerLocation := frame.Meta != nil && frame.Meta.ProfileType != nil &&
		*frame.Meta.ProfileType == rtc.PER_LOCATION

	assert.True(t, isPerLocation,
		"PER_LOCATION should be detected and skip default fill-in")

	// Verify the config usage mapping for PER_LOCATION
	usage := profileTypeToUserConfigUsage(frame.Meta.ProfileType)
	assert.Equal(t, providercontext.ProviderUserConfigUsageLoaderPerLocationID, usage)
}

// TestBuildSQSPayload validates that the test helper correctly builds
// a JSON SQS event payload containing a RtcChannelFrame body.
func TestBuildSQSPayload(t *testing.T) {
	profile := "teos/test"
	frame := &rtc.RtcChannelFrame{
		Meta: &rtc.RtcChannelFrameMeta{
			Mode:        rtc.TRANSPORT,
			Profile:     &profile,
			ProfileType: rtc.STATIC.Ptr(),
		},
		Frames: []rtc.RtChannelMessage{
			rtc.SimpleCollectionFrameAsRtChannelMessage(
				&rtc.SimpleCollectionFrame{
					Frame: string(rtc.SIMPLE_COLLECTION_FRAME),
					Lid:   "TestBuilding",
					Tz:    "Europe/Stockholm",
				},
			),
		},
	}

	payload := buildSQSPayload(t, frame)
	require.NotEmpty(t, payload)

	// Verify the payload can be unmarshaled back to SQS event
	var sqsEvent events.SQSEvent
	err := json.Unmarshal(payload, &sqsEvent)
	require.NoError(t, err)
	require.Len(t, sqsEvent.Records, 1)

	// Verify the body contains the RTC frame
	var decoded rtc.RtcChannelFrame
	err = json.Unmarshal([]byte(sqsEvent.Records[0].Body), &decoded)
	require.NoError(t, err)
	require.NotNil(t, decoded.Meta)
	assert.Equal(t, "teos/test", *decoded.Meta.Profile)
	require.Len(t, decoded.Frames, 1)
	assert.NotNil(t, decoded.Frames[0].SimpleCollectionFrame)
	assert.Equal(t, "TestBuilding", decoded.Frames[0].SimpleCollectionFrame.Lid)
}
