package providerpipe

import (
	"net/http"
	"slices"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// invokeSourceFunction will invoke the source function registered in the `ProviderPipeImpl` instance
// (if found) and return the result.
//
// If it fails it will set the error state and return `nil`.
//
// When selection has been done, the returned src will be filtered to only include the selected items. This may be overridden by
// supplying a _noFilter_ parameter set to `true`.
func (e *ProviderPipeExecutorImpl) invokeSourceFunction(
	credentials any,
	noFilter bool,
) (map[string]any, []providermodel.Selection, []*providerutils.ReportContext) {
	// Check if in error state
	if e.err != nil {
		return nil, nil, nil
	}

	var (
		src       map[string]any
		selection []providermodel.Selection
		drc       []*providerutils.ReportContext
		err       cberror.Error
	)

	if e.pipeConfig.sourceWithSelection != nil {
		if e.pipeConfig.source != nil {
			e.err = cberror.NewCbErrorf(
				e.ctx.Service(),
				400,
				nil,
				"ProviderPipeExecutorImpl::Cannot have both source and source with selection functions",
			)

			return nil, nil, nil
		}

		src, selection, err = e.pipeConfig.sourceWithSelection(
			e.ctx,
			e.pipeConfig.operation,
			e.operation,
			utils.ToProviderConfigImpl(e.config),
			e.pipeContext,
			credentials,
		)

		drc, _ = src["_report"].([]*providerutils.ReportContext)

	} else {
		src, selection, drc, err = InvokeAndSelectOnSourceFunction(
			e.ctx,
			e.pipeConfig.source,
			e.pipeContext,
			utils.ToProviderConfigImpl(e.config),
			e.pipeConfig.operation,
			e.operation,
			credentials,
			noFilter,
		)
	}

	if err != nil {
		e.err = err

		return nil, nil, nil
	} else {
		return src, selection, drc
	}
}

// handleMappingFilter will use the `ifprovider.ParameterMappingFilter` set in the _filter_ parameter
// to, possibly, filter out any mappings.
func (e *ProviderPipeExecutorImpl) handleMappingFilter(filter string, sourceData map[string]any) {
	// Check if in error state
	if e.err != nil {
		return
	}

	// No filter -> skip
	if filter == "none" || filter == "" {
		return
	}

	mapping := e.config.GetMapping()

	// Keys that we will remove
	var keys []string

	// Filter out mappings that have same lhs and rhs
	if filter == "eq" {
		for k, v := range mapping {
			if v == k {
				keys = append(keys, k)
			}
		}
	} else { // Expression evaluation to remove mappings
		// No expression -> skip
		if !cbeval.IsCbEvalExpression(filter) {
			return
		}

		// Evaluate the expression
		evl, err := cbeval.GlobalEvalCache.GetEval(
			e.ctx,
			cbeval.UnwrapExpression(filter),
			cbeval.EvalCacheLangFull,
		)

		if err != nil {
			e.err = err
		}

		for k, v := range mapping {
			res, err := evl(e.ctx, map[string]any{"lhs": k, "rhs": v, "src": sourceData})

			if err != nil {
				e.err = cberror.FromError(e.ctx.Service(), http.StatusInternalServerError, err)
				return
			}

			if res, ok := res.(bool); ok && !res {
				keys = append(keys, k)
			}
		}
	}

	mid := strings.Split(
		e.config.GetParamAsStringWithDefault(string(ifprovider.ParameterMappingIDs), ""), " ",
	)

	needUpdate := len(mid) > 0

	// Remove the mappings
	for _, k := range keys {
		delete(mapping, k)

		idx := slices.Index(mid, k)
		if idx != -1 {
			mid = append(mid[:idx], mid[idx+1:]...)
		}
	}

	if needUpdate {
		e.config.GetGlobalParams()[string(ifprovider.ParameterMappingIDs)] = strings.Join(mid, " ")
	}
}

// handleMappingMode will handle strict, src, and source mapping modes.
//
// When _selection_ is not empty and the mode is _selection_ it will use those _selection_(s), otherwise those
// are discarded.
func (e *ProviderPipeExecutorImpl) handleMappingMode(
	mmo ifprovider.MappingMode,
	selection []providermodel.Selection,
	sourceData map[string]any) {
	errText := ""

	var src map[string]any

	switch mmo {
	case ifprovider.MappingModeStrict:
		// Strict mode, i.e. nothing is processed
		return
		// Source mapping mode, i.e. throttle source data through the mapping.
	case ifprovider.MappingModeSelection:
		if sd, ok := sourceData["source"]; ok {
			if s, ok := sd.(map[string]any); ok {
				src = s
			} else {
				errText = "Source data is not a map[string]any which is required for selection mapping mode"
			}
		} else {
			log.Info(e.ctx).
				WithMethod("handleMappingMode").
				Msgf("Source data is missing (nothing to process) when selection mapping mode is set")

			return
		}
	case ifprovider.MappingModeSource:
		if sd, ok := sourceData["source"]; ok {
			if s, ok := sd.(map[string]any); ok {
				src = s
			} else {
				errText = "Source data is not a map[string]any which is required for source mapping mode"
			}
		} else {
			log.Info(e.ctx).
				WithMethod("handleMappingMode").
				Msgf("Source data is missing (nothing to process) - expecting key 'source' in the source data when source mapping mode is set")

			return
		}
		// Src mapping, extract the function and invoke it using the src data.
		// It is expected to produce a map[string]any which is then used as the
		// source data for `e.handleSourceMappingMode(src)`.
	case ifprovider.MappingModeSrc:
		if src, e.err = cbeval.Evaluate[map[string]any](e.ctx, mmo.SrcFunction(), sourceData["src"], true /*cache*/); e.err != nil {
			return
		}
		// Unknown mapping mode
	default:
		return
	}

	if errText != "" {
		e.err = cberror.NewCbErrorConfigurationErrorf(
			e.ctx.Service(),
			cberror.ConfigurationErrorSourceMappingWithNoSourceData,
			1, nil /*configuration*/, nil, /*error*/
			map[string]any{
				cberror.PropertyProvider: e.ctx.Provider(),
			},
			"%s", errText,
		)

		return
	}

	// Handle the source mapping
	e.handleSourceMappingMode(mmo, src, selection)

}

// handleGlobalParameterOverrides will check if _globals_ is a key with _map[string]any_ value.
// If so, it will copy those not present in global params and into the pipe context.
func (e *ProviderPipeExecutorImpl) handleGlobalParameterOverrides(sourceData map[string]any) {
	// Is there any config overrides to apply?
	configOverrides, ok := sourceData[string(ifprovider.WellKnownSourceTypeGlobals)]
	if !ok {
		return
	}

	delete(sourceData, string(ifprovider.WellKnownSourceTypeGlobals))

	if configOverrides, ok := configOverrides.(map[string]any); ok {
		full := utils.ToProviderConfigImpl(e.config)

		for k, v := range configOverrides {
			if _, ok := full.Params[k]; !ok {
				e.pipeContext[k] = configOverrides[k]
				full.Params[k] = v
			}
		}
	}
}

// handleSourceMappingMode will handle the source mapping mode where the mapping section
// will be populated with the source data keys filtered by the MID parameter.
//
// NOTE: MID may contain wildcard to include all keys from the source data.
func (e *ProviderPipeExecutorImpl) handleSourceMappingMode(
	mmo ifprovider.MappingMode,
	sourceData map[string]any,
	selection []providermodel.Selection,
) {
	switch mmo {
	case ifprovider.MappingModeSelection:
		sourceMapViaSelection(e.config, sourceData, selection)
	case ifprovider.MappingModeSource, ifprovider.MappingModeSrc:
		if err := sourceMap(e.config, sourceData); err != nil {
			e.err = cberror.FromError(e.ctx.Service(), http.StatusInternalServerError, err)
		}
	}
}
