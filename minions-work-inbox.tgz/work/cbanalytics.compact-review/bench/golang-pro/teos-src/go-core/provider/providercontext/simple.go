package providercontext

import (
	"io/fs"
)

// SimpleProviderWithPolicySupport is a helper function to create a builder with
// all options for a "standard" provider with policy support.
//
// The service name may be overridden by the environment variable CB_SERVICE_NAME and
// endpoint is retrieved by the environment variable CB_REP (if needed).
//
// The _policies_ is a file system that points to a directory with policies, e.g. './policies'.
// The _pdp_ is a file system that points to a directory with PDP configuration, e.g. './pdp-config'.
func SimpleProviderWithPolicySupport(
	provider, service string,
	dryRun bool,
	policies, pdp fs.FS,
) *CbContextBuilder {
	// Create a builder with all options for a "standard" provider.
	builder := NewContextBuilder().
		InProvider(provider).
		AsService(service).
		WithDefaultAWSConfiguration().
		EnableLogging().
		LoadPolicyFromEnvironment().
		LoadPoliciesFromFileSystem(policies).
		WithPolicyDecisionPoint(pdp)

	if dryRun {
		builder.EnableDryRun()
	}

	return builder
}
