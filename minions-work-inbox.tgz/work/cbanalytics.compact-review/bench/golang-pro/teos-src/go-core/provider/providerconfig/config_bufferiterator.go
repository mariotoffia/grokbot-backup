package providerconfig

import (
	"bytes"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"

	"github.com/rs/zerolog"
)

type BufferIterator struct {
	context ifcore.CbContext
	File    string
	splits  [][]byte
	index   int
	num     int
}

func NewBufferIterator(context ifcore.CbContext, file string, buffer []byte) *BufferIterator {
	var iter BufferIterator

	if len(buffer) == 0 {
		iter = BufferIterator{context: context, File: file}
	} else {
		iter = BufferIterator{
			context: context,
			File:    file,
			splits:  bytes.Split(buffer, []byte("\n##")),
		}
	}

	iter.num = len(iter.splits)

	if l, ok := logger.ClsLog(zerolog.TraceLevel, "newBufferIterator", logger.LDTUntyped, logger.LISUnclassified, context); ok {
		l.Msgf("buffer: %s, splits: %d", string(buffer), iter.num)
	}

	return &iter
}

func (bi *BufferIterator) Next() []byte {
	if bi.index >= bi.num {
		return []byte{}
	}

	buff := bi.splits[bi.index]
	bi.index++

	if len(buff) == 0 {
		if l, ok := logger.ClsLog(zerolog.TraceLevel, "newBufferIterator::Next()", logger.LDTUntyped, logger.LISUnclassified, bi.context); ok {
			l.Msgf("buffer is empty, index: %d", bi.index)
		}

		return []byte{}
	}

	if buff[0] == '#' {
		l := len(buff)
		for i := 0; i < l; i++ {
			if buff[i] == '\n' {
				return buff[(i + 1):]
			}
		}
	}

	return buff
}
