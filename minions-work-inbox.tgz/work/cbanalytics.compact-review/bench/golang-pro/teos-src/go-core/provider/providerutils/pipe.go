package providerutils

import "github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"

// StandardPipeSource creates a standard pipe source.
// When _includeGlobals_ is `true`, the globals map is also created
// footnote:[Used to set global parameters in the current provider config.]
func StandardPipeSource(includeGlobals bool) (map[string]any, map[string]any, map[string]any) {
	var globals map[string]any

	if includeGlobals {
		globals = map[string]any{}
	}

	source := map[string]any{}

	dp := map[string]any{string(ifprovider.WellKnownSourceTypeSource): source}

	if includeGlobals {
		dp[string(ifprovider.WellKnownSourceTypeGlobals)] = globals
	}

	return dp, source, globals
}
