package utils_test

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	c := testenv.DefaultContext(tb, "unit-test")
	zerolog.SetGlobalLevel(zerolog.FatalLevel)
	return c
}

func TestOnlyStaticInputArguments(t *testing.T) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "TID PID REP")

	enumerator.Resolve(map[string]any{
		"TID":    "the_TID",
		"PID":    "the_PID",
		"REP":    "the_REP",
		"PID_O1": "the_PID_O1",
		"SID":    "the_SID",
		"PT_O1":  "the_PT_O1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID", args["PID"])
	assert.Equal(t, "the_REP", args["REP"])

	// Since "static"
	assert.Equal(t, nil, args[string(ifprovider.ParameterOrdinal)])
	assert.Equal(t, nil, args[string(ifprovider.ParameterCircuit)])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func TestOneTwoOrdinalNoCircuitGlobArgument(t *testing.T) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "PID**")

	enumerator.Resolve(map[string]any{
		"TID":    "the_TID",
		"PID_O1": "the_PID_O1",
		"PID_O2": "the_PID_O2",
		"PT_O1":  "the_PT_O1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 2, len(args))
	assert.Equal(t, "the_PID_O1", args["PID_O1"])
	assert.Equal(t, 1, args[string(ifprovider.ParameterOrdinal)])
	assert.Equal(t, nil, args[string(ifprovider.ParameterCircuit)])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 2, len(args))
	assert.Equal(t, "the_PID_O2", args["PID_O2"])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func TestOneTwoOrdinalOneCircuitGlobArgument(t *testing.T) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "PID**")

	enumerator.Resolve(map[string]any{
		"TID":       "the_TID",
		"PID_O1_C1": "the_PID_O1_C1",
		"PID_O2_C1": "the_PID_O2_C1",
		"PT_O1":     "the_PT_O1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_PID_O1_C1", args["PID_O1_C1"])
	assert.Equal(t, 1, args[string(ifprovider.ParameterOrdinal)])
	assert.Equal(t, 1, args[string(ifprovider.ParameterCircuit)])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_PID_O2_C1", args["PID_O2_C1"])
	assert.Equal(t, 2, args[string(ifprovider.ParameterOrdinal)])
	assert.Equal(t, 1, args[string(ifprovider.ParameterCircuit)])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func TestOneTwoOrdinalNoCircuitAndOneCircuitGlobArgument(t *testing.T) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "PID**")

	enumerator.Resolve(map[string]any{
		"TID":       "the_TID",
		"PID_O1":    "the_PID_O1",
		"PID_O2":    "the_PID_O2",
		"PID_O1_C1": "the_PID_O1_C1",
		"PID_O2_C1": "the_PID_O2_C1",
		"PT_O1":     "the_PT_O1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 2, len(args))
	assert.Equal(t, "the_PID_O1", args["PID_O1"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 2, len(args))
	assert.Equal(t, "the_PID_O2", args["PID_O2"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_PID_O1_C1", args["PID_O1_C1"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_PID_O2_C1", args["PID_O2_C1"])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func TestOneTwoOrdinalNoCircuitAndOneCircuitGlobArgumentWithAssignment(t *testing.T) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "PID=PID**")

	enumerator.Resolve(map[string]any{
		"TID":       "the_TID",
		"PID_O1":    "the_PID_O1",
		"PID_O2":    "the_PID_O2",
		"PID_O1_C1": "the_PID_O1_C1",
		"PID_O2_C1": "the_PID_O2_C1",
		"PT_O1":     "the_PT_O1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 2, len(args))
	assert.Equal(t, "the_PID_O1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 2, len(args))
	assert.Equal(t, "the_PID_O2", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_PID_O1_C1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_PID_O2_C1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func TestOneTwoOrdinalNoCircuitAndOneCircuitGlobArgumentWithAssignmentAndStatic(t *testing.T) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "PID=PID** TID")

	enumerator.Resolve(map[string]any{
		"TID":       "the_TID",
		"PID_O1":    "the_PID_O1",
		"PID_O2":    "the_PID_O2",
		"PID_O1_C1": "the_PID_O1_C1",
		"PID_O2_C1": "the_PID_O2_C1",
		"PT_O1":     "the_PT_O1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O2", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 4, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O1_C1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 4, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O2_C1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func TestOneTwoOrdinalNoCircuitAndOneCircuitGlobArgumentWithAssignmentAndStaticWithMisalignedOrdo(
	t *testing.T,
) {
	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "PID=PID** TID PT**")

	enumerator.Resolve(map[string]any{
		"TID":       "the_TID",
		"PID_O1":    "the_PID_O1",
		"PID_O2":    "the_PID_O2",
		"PID_O1_C1": "the_PID_O1_C1",
		"PID_O2_C1": "the_PID_O2_C1",
		"PT_O1":     "the_PT_O1",
		"PT_O2_C1":  "the_PT_O2_C1",
	})

	args, ok := enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 4, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O1", args["PID"])
	assert.Equal(t, "the_PT_O1", args["PT_O1"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 3, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O2", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 4, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O1_C1", args["PID"])

	args, ok = enumerator.Next()
	require.Equal(t, true, ok)
	assert.Equal(t, 5, len(args))
	assert.Equal(t, "the_TID", args["TID"])
	assert.Equal(t, "the_PID_O2_C1", args["PID"])
	assert.Equal(t, "the_PT_O2_C1", args["PT_O2_C1"])

	args, ok = enumerator.Next()
	require.Equal(t, false, ok)
	assert.Equal(t, 0, len(args))
}

func BenchmarkParseStaticArguments(t *testing.B) {
	for i := 0; i < t.N; i++ {
		utils.ParseInputExpression("TID PID REP")
	}
}

func BenchmarkOnlyStaticInputArgumentsComplete(t *testing.B) {
	data := map[string]any{
		"TID":    "the_TID",
		"PID":    "the_PID",
		"REP":    "the_REP",
		"PID_O1": "the_PID_O1",
		"SID":    "the_SID",
		"PT_O1":  "the_PT_O1",
	}

	ctx := newCtx(t)

	for i := 0; i < t.N; i++ {
		enumerator := utils.NewInputEnumeratorImpl(ctx, "TID PID REP")
		enumerator.Resolve(data)
		enumerator.Next()
		enumerator.Next()
	}
}

func BenchmarkOnlyStaticInputArgumentsNewEnumerator(t *testing.B) {
	ctx := newCtx(t)

	for i := 0; i < t.N; i++ {
		utils.NewInputEnumeratorImpl(ctx, "TID PID REP")
	}
}

func BenchmarkOnlyStaticInputArgumentOnlyResolve(t *testing.B) {
	data := map[string]any{
		"TID":    "the_TID",
		"PID":    "the_PID",
		"REP":    "the_REP",
		"PID_O1": "the_PID_O1",
		"SID":    "the_SID",
		"PT_O1":  "the_PT_O1",
	}

	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "TID PID REP")

	for i := 0; i < t.N; i++ {
		enumerator.Resolve(data)
	}
}

func BenchmarkOnlyStaticInputArgumentOnlyIterate(t *testing.B) {
	data := map[string]any{
		"TID":    "the_TID",
		"PID":    "the_PID",
		"REP":    "the_REP",
		"PID_O1": "the_PID_O1",
		"SID":    "the_SID",
		"PT_O1":  "the_PT_O1",
	}

	enumerator := utils.NewInputEnumeratorImpl(newCtx(t), "TID PID REP")
	enumerator.Resolve(data)

	for i := 0; i < t.N; i++ {
		enumerator.Next()
		enumerator.Next()
		enumerator.Reset()
	}
}

func BenchmarkComplex(t *testing.B) {
	data := map[string]any{
		"TID":       "the_TID",
		"PID_O1":    "the_PID_O1",
		"PID_O2":    "the_PID_O2",
		"PID_O1_C1": "the_PID_O1_C1",
		"PID_O2_C1": "the_PID_O2_C1",
		"PT_O1":     "the_PT_O1",
		"PT_O2_C1":  "the_PT_O2_C1",
	}

	ctx := newCtx(t)

	for i := 0; i < t.N; i++ {
		enumerator := utils.NewInputEnumeratorImpl(ctx, "PID=PID** TID PT**")
		enumerator.Resolve(data)
		enumerator.Next()
		enumerator.Next()
		enumerator.Next()
		enumerator.Next()
		enumerator.Next()
	}
}
