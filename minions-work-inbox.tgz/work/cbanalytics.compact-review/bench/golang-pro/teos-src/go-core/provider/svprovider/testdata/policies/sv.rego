package sv

deny[dp] := msg if {
	some dp, my in input.sensors
	my == "$error"

	not obligation[dp]

	msg := $"failed to import sensors.{dp} due to errors"
}

deny[dp] := msg if {
	some dp, my in input.sensors
	my != "$error"

	range := get_range(dp)

	not in_range(my, range[0], range[1])
	not obligation[dp]

	msg := $"failed to import sensors.{dp}: {my} due to out of range: {range} "
}

# Errors to be skipped
# If present in report as well it will not be skipped
# (report overrides skip)
obligation[dp] := ob if {
	some dp, my in input.sensors
	my == "$error"

	match_skip(dp)

	not match_report(dp)

	ob := {
		"deny": "Error while importing",
		"report": "skip",
		"infosec": "plc",
		"remove": $"sensors.[{dp}]",
	}
}

# Errors to be skipped when out of range
obligation[dp] := ob if {
	some dp, my in input.sensors
	my != "$error"

	match_skip(dp)

	not match_report(dp)

	range := get_range(dp)
	not in_range(my, range[0], range[1])

	ob := {
		"deny": $"Value not in range: {range} value: {my}",
		"report": "skip",
		"infosec": "plc",
		"remove": $"sensors.[{dp}]",
	}
}

# Errors to be reported
# If matches both in skip and report -> report overrides skip
obligation[dp] := ob if {
	some dp, my in input.sensors
	my == "$error"

	match_report(dp)

	ob := {
		"deny": "Error while importing",
		"report": "report",
		"infosec": "plc",
		"remove": $"sensors.[{dp}]",
	}
}

# Errors to be reported when out of range
obligation[dp] := ob if {
	some dp, my in input.sensors
	my != "$error"

	match_report(dp)

	range := get_range(dp)
	not in_range(my, range[0], range[1])

	ob := {
		"deny": $"Value not in range: {range} value: {my}",
		"report": "report",
		"infosec": "plc",
		"remove": $"sensors.[{dp}]",
	}
}

in_range(num, low, high) if {
	num >= low
	num <= high
}

get_range(dp) := range if {
	some key, range in data.range

	glob.match(key, ["_"], dp)
}

match_skip(dp) if {
	some pattern in data.skip
	glob.match(pattern, ["_"], dp)
}

match_report(dp) if {
	some pattern in data.report
	glob.match(pattern, ["_"], dp)
}
