package providerpipe

import (
	"net/http"
	"time"

	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// ProviderPipeline is where the provider feed their data through
// to map, filter or otherwise process the inbound or outbound data.
//
// It consists of a `providerconfig.ProviderConfRepository` that holds all
// templates, pipelines, generator templates etc. Use `CreateConfigFromString`
// or `CreateConfigFromItems` to populate this repository.
//
// This repository is then when `Execute` to get the items needed to execute
// a pipeline. This also uses a concept of last error, where it stops working
// when an `Error()` is set. Use `ClearError()` to recover from such situation.
//
// The `ProviderPipeline` is meant to be as a singleton in a _Lambda_ service
// that is initialized at startup an uses `NewProviderPipelineExecutor` to create
// a new executor for each request.
//
// In order to handle authentication, OAuth tokens it hosts a `SessionStore` that
// may be populated with credentials, OAuth tokens that may be accessed from the
// pipeline.
type ProviderPipeline struct {
	repository        *providerconfig.ProviderConfRepository
	context           ifcore.CbContext
	lasterr           cberror.Error
	store             *config.SessionStore
	obtainCredentials ObtainCredentialsFunction
	verifyConnect     VerifyConnectFunction
	providerName      string
}

// NewProviderPipeline creates a new provider based pipeline
func NewProviderPipeline(
	ctx ifcore.CbContext,
	providerName string,
	store *config.SessionStore,
	obtainCredentials ObtainCredentialsFunction,
	verifyConnect VerifyConnectFunction) *ProviderPipeline {
	return &ProviderPipeline{
		context:           ctx,
		providerName:      providerName,
		store:             store,
		repository:        providerconfig.NewProviderConfigRepository(ctx),
		obtainCredentials: obtainCredentials,
		verifyConnect:     verifyConnect,
	}

}

// Error returns an error if such has occurred.
//
// NOTE: The `ProviderPipeline` methods will stop function when it is in error state!
func (p *ProviderPipeline) Error() cberror.Error {
	return p.lasterr
}

// ClearError clears any possible errors in the `ProviderPipeline`.
func (p *ProviderPipeline) ClearError() *ProviderPipeline {
	p.lasterr = nil
	return p
}

// ProviderName returns the name of the provider, e.g. _climatixic_
func (p *ProviderPipeline) ProviderName() string {
	return p.providerName
}

func (p *ProviderPipeline) AddProviderConfigLoader(
	loader providerconfig.ProviderConfigLoader,
) *ProviderPipeline {
	if p.lasterr != nil {
		return p
	}

	p.repository.AddProviderLoader(loader)
	return p
}

func (p *ProviderPipeline) verifyConnectInvocation(
	pc *providermodel.ProviderConfigImpl,
	eop *providermodel.Operation,
	credentials any) bool {
	if eop == nil || eop.Params == nil || p.obtainCredentials == nil {
		return true
	}

	cred, found := pc.Params[string(ifprovider.ParameterCredentials)]
	if !found {
		return true
	}

	if s, ok := cred.(string); ok {
		if s == "" {
			return true
		}

		return p.verifyConnect(p.context, s, credentials, eop)
	}

	return false
}

func (p *ProviderPipeline) obtainCredentialsInvocation(
	dir locationmodel.ProviderOperation,
	pc *providermodel.ProviderConfigImpl,
	pipeCtx map[string]any,
	op *providermodel.Operation) (any, cberror.Error) {
	if op == nil || op.Params == nil || p.obtainCredentials == nil {
		return nil, nil
	}

	cred, found := pc.Params[string(ifprovider.ParameterCredentials)]
	if !found {
		return nil, nil
	}

	s, ok := cred.(string)

	if !ok {
		return nil, cberror.NewCbErrorf(
			p.context.Service(), cberror.ErrorProviderCredentialWrongType, nil,
			"The CRED Parameter is not of string type: %T, value: %v", cred, cred,
		)
	}

	if s == "" {
		return nil, nil
	}

	ptr, _, ephemeral := cbtransportutils.ParseCredString(s)

	if !ephemeral {
		item := p.store.Get(ptr)

		if item != nil && nil != item.Object() {
			return item.Object(), nil
		}
	}

	credentials, ttl, errCredentials := p.obtainCredentials(p.context, s, pipeCtx, op)

	if credentials == nil && errCredentials == nil {
		errCredentials = cberror.NewCbErrorf(
			p.context.Service(), http.StatusInternalServerError, errCredentials,
			"Failed to obtain credentials for CRD: %s (credentials = nil)", s,
		)
	}

	if errCredentials != nil {
		_ = providerutils.DataPointReport(p.context, &providerutils.ReportContext{
			Operation:         op,
			ProviderConfig:    pc,
			ProviderOperation: dir,
			DataPoints:        nil,
			Body:              nil,
			Err:               errCredentials,
		})

		return credentials, errCredentials
	}

	if ephemeral {
		return credentials, nil
	}

	p.store.PutExpire(
		ptr,
		credentials,
		time.Now().Unix()+ttl,
		false, /*no persist*/
		false, /*no encrypt*/
	)

	item := p.store.Get(ptr)

	if item != nil && nil != item.Object() {
		return item.Object(), nil
	}

	log.Warn(p.context).
		WithMethod("getCredentials").
		Str("crd", s).
		Msgf("Failed to cache credentials for CRD (returning non cached credentials)")

	return credentials, nil
}
