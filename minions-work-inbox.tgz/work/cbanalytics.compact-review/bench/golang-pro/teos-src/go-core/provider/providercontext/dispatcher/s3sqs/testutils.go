package s3sqs

import (
	"bytes"
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/require"
)

// AddSamplesToBucket is a helper to marshal and upload to S3.
func AddSamplesToBucket(
	t *testing.T,
	mgr *mgrstore.StoreManager,
	key string,
	values ...*ingestionmodel.CbSensorReportItem,
) events.S3EventRecord {
	//
	require.NoError(
		t, mgr.UploadBuffer(strings.TrimPrefix(key, "/"), Data(values...)).Error(),
	)

	return Rec(mgr.Bucket(), key)
}

// Itm creates a `ingestionmodel.CbSensorReportItem` for testing.
func Itm(lid, id string, value any, t ...time.Time) *ingestionmodel.CbSensorReportItem {
	var tm time.Time
	if len(t) == 0 {
		tm = time.Now()
	} else {
		tm = t[0]
	}

	item := eqmodel.SensorType(id).ToCbSensorReportItem()
	item.Value = value
	item.TimeStamp = tm
	item.LocationID = lid
	item.Provider = "test"

	return &item
}

// Payload creates a `s3sqs.PayloadData` for testing.
func Payload(lid string, values ...*ingestionmodel.CbSensorReportItem) *PayloadData {
	res := &PayloadData{
		LocationID: lid,
	}

	if len(values) == 0 {
		return res
	}

	res.Data = map[string]any{}

	for i := range values {
		res.Data[values[i].GetID()] = values[i]
	}

	return res
}

// Data marshals the given values to JSON and returns the result as a byte slice.
func Data(values ...*ingestionmodel.CbSensorReportItem) []byte {
	var buff bytes.Buffer

	for _, v := range values {
		fmt.Fprintln(&buff, string(jsonutils.ToJSON(v)))
	}

	return buff.Bytes()
}

// Recs creates a slice of `events.S3EventRecord` for testing.
func Recs(location, key string) []events.S3EventRecord {
	key = strings.TrimPrefix(key, "/")

	return []events.S3EventRecord{
		{
			S3: events.S3Entity{
				Bucket: events.S3Bucket{Name: location},
				Object: events.S3Object{Key: key},
			},
		},
	}
}

// Rec creates a single `events.S3EventRecord` for testing.
func Rec(location, key string) events.S3EventRecord {
	return events.S3EventRecord{
		S3: events.S3Entity{
			Bucket: events.S3Bucket{Name: location},
			Object: events.S3Object{Key: key},
		},
	}
}
