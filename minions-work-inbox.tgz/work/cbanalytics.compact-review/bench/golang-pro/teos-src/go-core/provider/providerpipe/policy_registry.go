package providerpipe

import (
	"sync"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline/builtin"
)

// errorMarker is the text a generator writes in place of a sensor value it could
// not produce. Provider payloads carry a map called "sensorts" that holds one
// timestamp per sensor. When a sensor value is missing, its timestamp is this
// marker rather than a time, and it has to be taken out before the payload is
// sent on.
const errorMarker = "$error"

// removeFailedSensorTimestamps deletes every entry of the "sensorts" map whose
// value is the marker a generator writes when it could not produce a value. It
// runs on the result of a policy step in a provider pipeline. Without it a
// building payload reaches its target with entries such as
// "T_SUPPLY": "$error" where a timestamp belongs.
//
// This shape is specific to provider payloads, which is why it lives here and
// not in the pipeline library: the library has no idea what a sensor is.
func removeFailedSensorTimestamps(result map[string]any) error {
	sensorts, ok := result["sensorts"].(map[string]any)
	if !ok {
		return nil
	}

	for key, val := range sensorts {
		if val == errorMarker {
			delete(sensorts, key)
		}
	}
	return nil
}

// policyStepFactory builds the policy step of a pipeline exactly as the pipeline
// library does, and then attaches removeFailedSensorTimestamps to it.
//
// It is a wrapper rather than a copy so that any change to the library's own
// policy step reaches provider pipelines too. Only the one extra thing is added
// here.
type policyStepFactory struct {
	builtin.PolicyFactory
}

// Compile reads the policy step's settings, adds the provider-specific clean-up
// of the result, and then hands the settings to the library's own policy step.
func (f policyStepFactory) Compile(
	cc cbpipeline.CompileContext, cfg any,
) (cbpipeline.Executor, cberror.Error) {
	if policyCfg, ok := cfg.(*builtin.PolicyConfig); ok {
		policyCfg.PostProcessor = removeFailedSensorTimestamps
	}
	return f.PolicyFactory.Compile(cc, cfg)
}

// StepTypes returns the set of pipeline step types provider pipelines use.
//
// It is the pipeline library's own set with one change: the step that asks a
// policy also cleans up the sensor timestamps of the payload, as described on
// removeFailedSensorTimestamps.
//
// Losing that change would not break any test that only checks a policy step was
// built, because the step would still work; the payload would simply go out with
// "$error" where timestamps belong. That is why the change is made by replacing
// the step type rather than by setting something after the fact, and why the
// test for it runs a pipeline and looks at the result.
//
// It is built once and reused, because the set of step types is part of the key
// a compiled pipeline is stored under: two different sets must never share a
// compiled pipeline, and one set must not look different on every call.
var StepTypes = sync.OnceValue(func() *cbpipeline.Registry {
	reg := cbpipeline.MustNewRegistry()

	for _, factory := range builtin.All() {
		if factory.Type() == builtin.TypePolicy {
			continue
		}
		if err := reg.Register(factory); err != nil {
			panic("providerpipe: building the provider set of step types failed: " + err.Error())
		}
	}

	if err := reg.Register(policyStepFactory{}); err != nil {
		panic("providerpipe: registering the provider policy step failed: " + err.Error())
	}
	return reg
})
