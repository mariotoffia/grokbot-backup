package reportablesrc

import (
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// ReportableSourceMapOptions optional options.
//
// CAUTION: If using pipe-builder, these has to be synced with the pipe-builder so
// they are the same.
type ReportableSourceMapOptions struct {
	// MapperWithoutPartition is a flag to state when mapping the datapoint id
	// from or to the remote id.
	//
	// When set to `true``, the partition is not present in the mapping section.
	// However, when is set to false, it will the partition is present in the mapping.
	//
	// This is used to translate a `eqmodel.CbDataPoint.GetID()` to a _TEOS ID_.
	MapperWithoutPartition bool
	// SplitPartitionAndIDFunc is optional but when submitted it will be used
	// to determine the ID and partition by submitting the `eqmodel.CbDataPoint.GetID()`
	// to the function.
	//
	// CAUTION: If `nil` the _ID_ is _REQUIRED_ to be a _ID_ without any partition.
	SplitPartitionAndIDFunc providerutils.SplitPartitionAndID
	// ToTeosID is the function that will be used to determine the TEOS ID. If none
	// is provided, the default `toTEOSID` is used.
	ToTeosID providerutils.ToTeosIDFunc
	// DoNotReport will omit any reporting of the data points.
	//
	// This is useful when e.g. using source mapping on export where it need to import
	// datapoints and use those for selection-mapping thus should not be reported but can
	// reuse a sv handler.
	DoNotReport bool
}

func ReportableSourceMap(
	source providerpipe.ReportableSourceMapFunction,
	providerOperation locationmodel.ProviderOperation,
	opts ...ReportableSourceMapOptions,
) providerpipe.SourceFunction {
	var opt ReportableSourceMapOptions

	if len(opts) > 0 {
		opt = opts[0]
	}

	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		//
		if op == nil {
			return nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), http.StatusBadRequest, nil, map[string]any{
					cberror.PropertyProvider: ctx.Provider(),
				}, "no operation configuration found for operation: %s, is it present in profile?", operation,
			)
		}

		// Extract cbid and remote ids
		var rid []string
		cbid := pc.ExtractSensors(op)

		for _, sensor := range cbid {
			if n, ok := pc.GetMappedTo(sensor); ok {
				rid = append(rid, n)
			} else {
				return nil, cberror.NewCbErrorfWithProps(
					ctx.Service(), 1, nil, map[string]any{
						"pn": ctx.Provider(),
					}, "sensor %s is not mapped", sensor,
				)
			}
		}

		dp, src, body, err := source(ctx, pipeCtx, operation, op, pc, rid, cred)

		dps := make([]eqmodel.CbDataPoint, len(dp))
		i := 0

		for k := range dp {
			dps[i] = dp[k]
			i++
		}

		// Create the report context
		if !opt.DoNotReport {
			rc := &providerutils.ReportContext{
				Operation:               op,
				ProviderConfig:          pc,
				ProviderOperation:       providerOperation,
				WantedSensors:           cbid,
				DataPoints:              dps,
				MapperWithoutPartition:  opt.MapperWithoutPartition,
				SplitPartitionAndIDFunc: opt.SplitPartitionAndIDFunc,
				ToTeosID:                opt.ToTeosID,
				Err:                     err,
				Body:                    body,
			}

			if err != providerutils.DataPointReport(ctx, rc) {
				return nil, err
			}
		} else if err != nil {
			return nil, err
		}

		// gval needs this - otherwise it will resort to reflection
		// and it will throw error if we navigate on non existent
		// elements. If we do like this, it will return nil instead.
		pdp := make(map[string]any, len(dp))
		for k := range dp {
			pdp[k] = dp[k]
		}

		m := map[string]any{
			"source": pdp,
		}

		if src != nil {
			m["src"] = src
		}

		return m, nil
	}
}
