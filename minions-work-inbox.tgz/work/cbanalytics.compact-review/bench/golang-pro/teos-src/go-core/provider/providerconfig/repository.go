package providerconfig

import (
	"sync"

	"github.com/mohae/deepcopy"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

const msg_repositoryMerge = "Repository::Merge"

type ProviderConfigLoader interface {
	// Find will find a profile by name. If not found, `nil` is returned.
	Find(c ifcore.CbContext, profile string) (*providermodel.ProviderConfigImpl, cberror.Error)
}

// ProviderConfRepository handles all known provider
// configurations.
type ProviderConfRepository struct {
	ctx     ifcore.CbContext
	cache   map[string]*providermodel.ProviderConfigImpl
	loaders []ProviderConfigLoader
	mtx     sync.Mutex
}

// NewProviderConfigRepository creates a new instance of the config repository
func NewProviderConfigRepository(
	ctx ifcore.CbContext,
	loaders ...ProviderConfigLoader,
) *ProviderConfRepository {
	return &ProviderConfRepository{
		ctx:     ctx,
		cache:   map[string]*providermodel.ProviderConfigImpl{},
		loaders: loaders,
	}
}

func (pcr *ProviderConfRepository) AddProviderLoader(
	loader ProviderConfigLoader,
) *ProviderConfRepository {
	// Lock the loaders
	pcr.mtx.Lock()
	defer pcr.mtx.Unlock()

	pcr.loaders = append(pcr.loaders, loader)

	return pcr
}

// Add will add a ProviderConfig with ProviderConfig.Profile as the key.
//
// It will clone the _pc_ and thus the original _pc_ can be safely modified.
func (pcr *ProviderConfRepository) Add(
	pc *providermodel.ProviderConfigImpl,
) *ProviderConfRepository {
	// Add has precedence over any earlier added
	pcr.mtx.Lock()
	defer pcr.mtx.Unlock()

	pcr.cache[pc.Profile] = deepcopy.Copy(pc).(*providermodel.ProviderConfigImpl)
	return pcr
}

// GetOriginal will returned the cached original.
//
// CAUTION: If unsure, use `GetClone` instead!!
func (pcr *ProviderConfRepository) GetOriginal(
	profile string,
) (pc *providermodel.ProviderConfigImpl, ok bool) {
	// Try find it in the cache
	pcr.mtx.Lock()
	defer pcr.mtx.Unlock()

	if pc, ok = pcr.cache[profile]; !ok {
		// Cache miss -> try find it from the loaders
		pc, ok = pcr.load(profile)
	}

	// Clone it so the cached one is not modified
	if ok {
		pc = deepcopy.Copy(pc).(*providermodel.ProviderConfigImpl)
	}

	return
}

// GetClone clones a profile and returns it. If not found, this function will return
// nil.
func (pcr *ProviderConfRepository) GetClone(
	profile string,
) (pc *providermodel.ProviderConfigImpl, ok bool) {
	// Try find it in the cache
	pcr.mtx.Lock()
	defer pcr.mtx.Unlock()

	if pc, ok := pcr.cache[profile]; ok {
		return pc.Clone(), true
	}

	// Cache miss -> try find it from the loaders
	if pc, ok := pcr.load(profile); ok {
		return pc.Clone(), true
	}

	return nil, false
}

// Merge will lookup the _profile_, clone it, and then merge with the supplied _from_ config.
// The newly cloned and merged instance is then returned.
func (pcr *ProviderConfRepository) Merge(
	c ifcore.CbContext,
	profile string,
	from *providermodel.ProviderConfigImpl,
) (*providermodel.ProviderConfigImpl, cberror.Error) {
	//
	if clonedProfile, ok := pcr.GetClone(profile); ok {
		if l, ok := logger.ClsLog(zerolog.TraceLevel, msg_repositoryMerge, logger.LDTUntyped, logger.LISUnclassified, c); ok {
			logger.LogObjectf(
				l, "body", clonedProfile,
				"profile [%s] (cloned) to be used when merging", profile,
			)
		}

		if l, ok := logger.ClsLog(zerolog.TraceLevel, msg_repositoryMerge, logger.LDTUntyped, logger.LISUnclassified, c); ok {
			logger.LogObjectf(
				l, "body", from,
				"the profile to merge from [%s]", from.Profile,
			)
		}

		merger := ProfileMerger(0)
		clonedProfile = merger.MergeFrom(from, clonedProfile)

		mam := clonedProfile.GetParamAsStringWithDefault(
			string(ifprovider.ParameterMappingMode),
			string(ifprovider.MappingModeStrict),
		)

		// Filter out the mappings that are not used when MID mode
		//
		// If SRC mode, this is done later (delayed) when executing.
		// This deferring is done in the pipe_executor_mapping.go::handleSourceMappingMode
		if mam == string(ifprovider.MappingModeStrict) {

			clonedProfile.Map = merger.FilterMappingSection(
				true, /*all*/
				clonedProfile.Map,
				merger.EnabledSensorMappings(clonedProfile),
			)
		}

		if l, ok := logger.ClsLog(zerolog.DebugLevel, msg_repositoryMerge, logger.LDTUntyped, logger.LISUnclassified, c); ok {
			logger.LogObjectf(
				l, "body", clonedProfile,
				"the merged profile [%s]", clonedProfile.Profile,
			)
		}

		return clonedProfile, nil
	} else {
		return nil, cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderProfileNameMissing, nil,
			"Profile %s not found", profile,
		)
	}
}

// MergeFromConfigString will take a _conf_ string that represents a `providermodel.ProviderConfigImpl`
// and merge it with the profile that is present in this provider.
//
// NOTE: The minimum configuration is to have `profile: <name>` in the config string.
// It will then just act as key to lookup the local profile and use it without any overrides.
//
// .Minimum Configuration
// [source,json]
// ----
//
//	{
//	  "profile": "default"
//	}
//
// ----
//
// The _conf_ parameter is either a pure _JSON_ parameter or a set of _JSON_ payloads
// (_see `ReadConfig()` for more information_).
func (p *ProviderConfRepository) MergeFromConfigString(
	ctx ifcore.CbContext,
	conf string,
) (*providermodel.ProviderConfigImpl, cberror.Error) {

	items, err := ReadConfig(ctx, conf)
	if err != nil {
		return nil, err
	}

	confAsProfile, err := CreateConfig(items...)
	if err != nil {
		errString := "none"
		innerError := err.Unwrap()

		if nil != innerError {
			errString = innerError.Error()
		}

		if l, ok := logger.ClsLog(zerolog.WarnLevel, "MergeFromConfigString", logger.LDTUntyped, logger.LISUnclassified, ctx); ok {
			logger.LogObjectf(l, "body", conf, "%s, inner-error: %s", conf, errString)
		}

		return nil, err
	}

	if confAsProfile.Profile == "" {
		if log.IsEnabled(zerolog.DebugLevel) {
			log.Debug(ctx).
				WithMethod("MergeFromConfigString").
				WithBody(confAsProfile).
				Str("conf", conf).
				Msg("Profile name missing in config string (body is the confAsProfile - if {} it probably is double encoded JSON or other error in JSON")
		}
		return nil, cberror.NewCbErrorConfigurationValidationErrorf(
			ctx.Service(), cberror.ConfigurationErrorMissingProfileName, 1,
			[]byte(conf), nil, map[string]any{
				"pn": ctx.Provider(),
			},
			"Must specify profile name in config",
		)
	}

	merged, err := p.Merge(ctx, confAsProfile.Profile, confAsProfile)

	if err != nil {
		return nil, err
	}

	if merged == nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), cberror.ErrorProviderUnableToMergeProfile, nil,
			"Failed to merge profile %s with config %s", confAsProfile.Profile, conf,
		)
	}

	// Resulting ProviderConfig is based on a cloned profile
	// and overridden by conf parameter!
	return merged, nil
}

// load will load a profile from the loaders and add it to the cache.
func (pcr *ProviderConfRepository) load(
	profile string,
) (pc *providermodel.ProviderConfigImpl, ok bool) {
	for _, loader := range pcr.loaders {
		if pc, err := loader.Find(pcr.ctx, profile); nil == err {
			// Found profile
			if pc == nil {
				log.Warn(pcr.ctx).
					WithMethod("Provider::GetClone").
					Str("profile", profile).
					Msgf("Profile %s not found", profile)

				return nil, false
			}

			// Add to cache
			pcr.cache[profile] = pc
			return pc, true
		} else {
			// Failed to load profile
			log.Error(pcr.ctx).
				WithMethod("Provider::GetClone").
				WithError(err).
				Str("profile", profile).
				Msgf("Failed to load profile %s from loader", profile)
		}
	}

	log.Info(pcr.ctx).
		WithMethod("ProviderConfRepository::load").
		Str("profile", profile).
		Msgf("Profile %s not found", profile)

	return nil, false
}
