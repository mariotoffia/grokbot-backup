package providerutils

import (
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
)

// IsSyntheticID will return `true` if the mapped _teosID_ is a synthetic ID.
//
// NOTE: All mapped values that are synthetic is prefixed with `Syn:`.
func IsSyntheticID(teosID string, cfg ifprovider.ConfigMapping) bool {
	to, ok := cfg.GetMappedTo(teosID)
	if ok && strings.HasPrefix(to, "Syn:") {
		return true
	}

	return false
}
