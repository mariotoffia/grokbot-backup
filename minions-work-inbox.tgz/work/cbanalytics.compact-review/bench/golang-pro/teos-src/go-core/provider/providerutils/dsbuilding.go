package providerutils

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
)

type TimeStampType string

const (
	// TimeStampIllegal is used when the timestamp is illegal
	TimeStampIllegal = ""
	// TimeStampLocal is a timestamp gotten from the local operating system
	// using the `package time`
	TimeStampLocal TimeStampType = "local"
	// TimeStampDeviceShadow is the timestamp gotten from the device shadow
	TimeStampDeviceShadow TimeStampType = "device-shadow"
	// TimeStampDeviceShadowPreservedRemoteTimeStamp is a timestamp gotten from the _sensorts_ in the
	// device shadow where the original remote timestamp is preserved.
	TimeStampDeviceShadowPreservedRemoteTimeStamp TimeStampType = "device-shadow-preserved-remote-timestamp"
)

// ExtractDsBuilding will extract the `dsmodel.DsBuilding` from the target key in the
// provided _data_.
//
// If not found or it is not a `dsmodel.DsBuilding` it returns nil.
func ExtractDsBuilding(data map[string]interface{}) *dsmodel.DsBuilding {
	if trg, ok := data["target"]; ok {
		if tempTarget, ok := trg.(*dsmodel.DsBuilding); ok {
			return tempTarget
		}
	}

	return nil
}

// ExtractTarget will extract the target from the target key in the provided _data_.
func ExtractTarget[T any](target map[string]interface{}) *T {
	if trg, ok := target["target"]; ok {
		if tempTarget, ok := trg.(*T); ok {
			return tempTarget
		}
	}

	return nil
}

// ExtractTargetError will extract the target from the target key in the provided _data_.
// If it is not found, it will return an error.
func ExtractTargetError[T any](
	ctx ifcore.CbContext,
	target map[string]interface{},
) (*T, cberror.Error) {
	trg := ExtractTarget[T](target)
	if trg != nil {
		return trg, nil
	}

	var t *T
	return nil, cberror.NewCbErrorfWithProps(ctx.Service(), 1, nil, map[string]any{
		cberror.PropertyProvider: ctx.Provider(),
	}, "Could not extract or type incorrect type, found: %T, expected type: %T", target["target"], t)
}

// VerifyTarget verifies that the target do exist and is of correct type.
func VerifyTarget[T any](ctx ifcore.CbContext, target map[string]interface{}) cberror.Error {
	_, err := ExtractTargetError[T](ctx, target)
	return err
}
