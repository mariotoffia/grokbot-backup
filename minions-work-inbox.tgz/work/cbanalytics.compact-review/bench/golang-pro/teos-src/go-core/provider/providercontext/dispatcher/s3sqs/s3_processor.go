package s3sqs

import (
	"net/http"
	"net/url"
	"time"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
)

// processS3Events will iterate the event load the files and dispatch them to the
// provider.
func processS3Events(
	ctx ifcore.CbContext,
	pc providercontext.ProviderContext,
	event *events.S3Event,
	defaultProfile string,
	parallelism int,
	timeout time.Duration,
	jsonLoader JSONLoaderFunc,
) cberror.Error {
	//
	if len(event.Records) == 0 {
		return nil
	}

	profile := cbenv.CB_PROV_DEFAULT_PROFILE.String("")

	if profile != "" {
		defaultProfile = profile
	}

	if parallelism <= 0 {
		parallelism = 1
	}

	if len(event.Records) == 1 || parallelism == 1 {
		// Run it in serial.
		return processRecordsSerial(event, ctx, pc, defaultProfile, parallelism, jsonLoader)
	} else {
		// Run it in parallel.
		return processRecordsParallel(parallelism, event, ctx, timeout, defaultProfile, pc, jsonLoader)
	}
}

// processRecordsSerial will load the JSON data and execute the payloads in serial.
//
// NOTE: Thus function will execute everything callers go routine and does not
// allow for any parallelism.
//
// It is a best effort function and will not return any errors if partial failure, it will just log them.
//
// If all records fail, it will return an error.
func processRecordsSerial(
	event *events.S3Event,
	ctx ifcore.CbContext,
	pc providercontext.ProviderContext,
	defaultProfile string,
	parallelism int,
	jsonLoader JSONLoaderFunc,
) cberror.Error {
	var errCount int

	for i := range event.Records {
		key := event.Records[i].S3.Object.Key
		if decoded, err := url.QueryUnescape(key); err == nil {
			key = decoded
		}

		if payloads, err := jsonLoader(
			ctx, event.Records[i].S3.Bucket.Name, key,
		); err == nil {
			executePayloads(payloads, ctx, pc, defaultProfile, parallelism)
		} else {
			errCount++

			log.Warn(ctx).
				WithMethod("processS3Events").
				WithBody(event.Records[i]).
				WithError(err).
				Msg("Failed to load or process S3 event record(s)")
		}
	}

	if len(event.Records) == errCount {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError, nil, "All S3 event records failed",
		)
	}

	return nil
}
