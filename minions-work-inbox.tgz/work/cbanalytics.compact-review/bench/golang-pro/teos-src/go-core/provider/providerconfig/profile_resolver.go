package providerconfig

import (
	"strings"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
)

// ProfileResolverImpl will handle the `profile` section in the `process` section.
//
// .Example Profile Selection in Process
// [source,json]
// ----
//
//	"profile": {
//		"#/profiles/plant-b": "['*.-wds1100$' =~ PTP]",
//		"#/profiles/plant-a":"['bravida-idt' == PTP]"
//	}
//
// ----
type ProfileResolverImpl struct {
	repository *ProviderConfRepository
}

// NewProfileResolver creates a new `ProfileResolverImpl`.
func NewProfileResolver(
	repository *ProviderConfRepository,
) *ProfileResolverImpl {
	return &ProfileResolverImpl{
		repository: repository,
	}
}

// ResolveClonedProfileAndReferences will resolve the profile and all references and return
// the complete, _cloned_, profile.
//
// This method will get the main profile to use when "local" reference within the profile.
// If the _profileExpression_ is not local it will resolve that and use it for optional local
// navigation.
//
// CAUTION: In any invocation, it is required that the `ifprovider.PipeContextKeyProviderConfig`
// key in the _evalContext_ is set to the profile to use for local navigation - even if it
// is *not* a local navigation!
//
// NOTE: It will also resolve global parameters if there are any expressions by using the _evalContext_
// as the context for the evaluation.
func (resolver *ProfileResolverImpl) ResolveClonedProfileAndReferences(ctx ifcore.CbContext,
	profileExpression string,
	evalContext map[string]any,
	overwrite bool,
) (ifprovider.ConfigFull, cberror.Error) {
	var err cberror.Error
	var resolvedProfile ifprovider.ConfigFull
	var pc ifprovider.ConfigFull

	// Get profile from eval context.
	pcf, ok := evalContext[string(ifprovider.PipeContextKeyProviderConfig)]

	if !ok {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
			"Profile '%s' not found since is not registered "+
				"in pc key in evalContext", profileExpression,
		)
	}

	pc, ok = pcf.(ifprovider.ConfigFull)

	if !ok {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
			"Profile '%s' could not be fetched from the pc key "+
				"in evalContext", profileExpression,
		)
	}

	// Resolve the profile
	if resolvedProfile, err = resolver.resolveProfileAndClone(ctx, pc, profileExpression, evalContext); err != nil {
		return nil, err
	}

	profile := utils.ToProviderConfigImpl(resolvedProfile)

	if profile == nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
			"Profile resolved with expression '%s' is not ProviderConfigImpl", profileExpression,
		)
	}

	// Resolve global parameters
	if _, ok := profile.Params["$ref"]; ok {
		if profile.Params, err = resolver.resolveMap(ctx, pc, evalContext, profile.Params, overwrite); err != nil {
			return nil, err
		}
	}

	// Resolve operations
	for _, op := range profile.Operation {
		if _, ok := op.Params["$ref"]; ok {
			if op.Params, err = resolver.resolveMap(ctx, pc, evalContext, op.Params, overwrite); err != nil {
				return nil, err
			}
		}
	}

	// If no operations - copy it from the profile.
	if len(profile.Operation) == 0 {
		pcr := utils.ToProviderConfigImpl(pc)
		profile.Operation = make(map[string]providermodel.Operation, len(pcr.Operation))

		for k := range pcr.Operation {
			op := pcr.Operation[k]
			profile.Operation[k] = *op.Clone()
		}
	}

	if _, ok := profile.Map["$ref"]; ok {
		// Resolve the reference
		profile.Map, err = resolver.resolveStringMap(ctx, pc, evalContext, profile.Map, overwrite)
		if err != nil {
			return nil, err
		}
	}

	// Evaluate global params.

	var resolveError error
	for key, value := range profile.Params {
		if s, ok := value.(string); ok {
			if cbeval.IsCbEvalExpression(s) {
				s = s[1 : len(s)-1]

				// Special case for just single value expressions.
				if data, ok := evalContext[s]; ok {
					profile.Params[key] = data
					continue
				}

				resolve, err := cbeval.GlobalEvalCache.GetEval(
					ctx, s, cbeval.EvalCacheLangCompositeSearch,
				)

				if err != nil {
					return nil, err
				}

				profile.Params[key], resolveError = resolve(ctx, evalContext)

				if profile.Params[key] == nil {
					if key == "CRD" {
						// Special case for CRD
						profile.Params[key] = ""

						if log.IsEnabled(zerolog.TraceLevel) {
							log.Trace(ctx).
								WithMethod("ResolveClonedProfileAndReferences").
								Str("key", key).
								Msg(
									"CRD is nil, special case -> delete params:CRD, otherwise it will return an error",
								)
						}

						delete(profile.Params, key)
						continue
					}

					return nil, cberror.NewCbErrorfWithProps(
						ctx.Service(), 1, nil,
						map[string]any{"pn": ctx.Provider()},
						"Error evaluating global parameter '%s' in "+
							"profile '%s' - it resolved to nil",
						key,
						profileExpression,
					)
				}

				if resolveError != nil {
					return nil, cberror.NewCbErrorfWithProps(
						ctx.Service(), 2, resolveError,
						map[string]any{"pn": ctx.Provider()},
						"Error evaluating global parameter '%s' in profile '%s'",
						key, profileExpression,
					)
				}

			}
		}
	}

	return profile, nil
}

// ChooseProfile will process the profile chooser and return the profile name.
//
// The _evalContext_ is the context to use when evaluating the profile chooser.
//
// The _profileChoice_ is a map of profile paths or expressions that resolves to
// a profile as keys. The value are the expressions to evaluate to true or false.
// The first expression that evaluates to true will be returned.
//
// NOTE: It will not unwrap any expression in the returned `string`.
func (resolver *ProfileResolverImpl) ChooseProfile(ctx ifcore.CbContext,
	profileChoice map[string]string,
	evalContext map[string]any,
) (string, cberror.Error) {

	for profile, expression := range profileChoice {

		if !cbeval.IsCbEvalExpression(expression) {
			if expression == "true" {
				return profile, nil
			}

			continue
		}

		res, err := evaluateSearchExpression(
			ctx, cbeval.UnwrapExpression(expression), evalContext,
		)

		if err != nil {
			return "", err
		}

		// We may have a true/false to assign the value or not
		if r, ok := res.(bool); ok {
			if r {
				return profile, nil
			}
		} else {
			return "", cberror.NewCbErrorf(
				ctx.Service(), 1, nil, "Profile expression '%s' did not evaluate to a boolean", expression,
			)
		}
	}

	return "", nil
}

func ResolveProfilePointer(ptr string) (file string, path string) {
	parts := strings.Split(ptr, "#/")
	if len(parts) == 1 {
		return "", parts[0]
	}

	return parts[0], parts[1]
}
