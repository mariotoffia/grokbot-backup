package providertest

import (
	"encoding/json"
)

// SensorShadowState holds all sensor values in a device shadow.
type SensorShadowState map[string]any

func (st SensorShadowState) ToShadow() []byte {
	bs, err := json.Marshal(map[string]any{
		"sensors": st,
	})

	if err != nil {
		panic(err)
	}

	return bs
}

// AreEqual compares _st_ and the _other_ and expect them to be equal.
func (st SensorShadowState) AreEqual(other SensorShadowState) bool {
	if len(st) != len(other) {
		return false
	}

	for k, v := range st {
		if v != other[k] {
			return false
		}
	}

	for k, v := range other {
		if v != st[k] {
			return false
		}
	}

	return true
}

// HasState will check if _state_ is contained in _st_.
func (st SensorShadowState) HasState(state SensorShadowState) bool {
	for k, v := range state {
		if st[k] != v {
			return false
		}
	}

	return true
}

// ShadowState contains states for either reported or desired.
type ShadowState struct {
	Sensors SensorShadowState `json:"sensors"`
}

// DeviceShadow represents the device shadow in AWS IoT.
type DeviceShadow struct {
	State struct {
		Reported ShadowState `json:"reported"`
		Desired  ShadowState `json:"desired"`
	} `json:"state"`
}

func ToDeviceShadow(data []byte) *DeviceShadow {
	var shadow DeviceShadow

	if err := json.Unmarshal(data, &shadow); err != nil {
		panic(err)
	}

	return &shadow
}
