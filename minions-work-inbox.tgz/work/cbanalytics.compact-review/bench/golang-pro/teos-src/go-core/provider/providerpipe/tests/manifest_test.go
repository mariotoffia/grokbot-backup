package tests

import (
	"bytes"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"
	"text/template"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

// Almost no provider writes a pipeline by hand. A provider configuration file
// holds a "--pipe=<operation>" section, which is a Go template; filling it in
// produces the pipeline that runs. There are well over a hundred of them across
// this repository, and a provider test suite only runs the ones it happens to
// name.
//
// The list beside this file names every one of them. The test below fills each in
// and compiles the result, so a configuration written in an older grammar fails
// here even if no other test ever loads it. The list is checked against the
// repository in both directions: an entry naming a file that is gone fails, and a
// configuration file the list does not name fails.
//
// What this does not cover, and what does: the four Go functions that produce the
// step bodies for all of these files are covered by their own unit tests in
// go-core/provider/providerconfig; pipelines written inline in Go test files are
// covered by the tests they belong to; and the example pipelines inside Go
// comments are read and rewritten by hand, because a comment cannot be compiled.

const manifestFile = "manifest.txt"

// repoRoot returns the directory holding the whole repository, found by walking
// up from this test until the file that lists the Go modules is found.
func repoRoot(t testing.TB) string {
	t.Helper()

	dir, err := os.Getwd()
	require.NoError(t, err)
	for i := 0; i < 8; i++ {
		if _, statErr := os.Stat(filepath.Join(dir, "go.work")); statErr == nil {
			return dir
		}
		dir = filepath.Dir(dir)
	}
	t.Fatal("could not find the repository root: no go.work above this test")
	return ""
}

// manifestEntries reads the list of provider configuration files.
func manifestEntries(t testing.TB) []string {
	t.Helper()

	data, err := os.ReadFile(manifestFile)
	require.NoError(t, err)

	var out []string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		out = append(out, line)
	}
	require.NotEmpty(t, out)
	return out
}

// configFilesInRepository finds every provider configuration file that holds a
// pipeline, by looking for the section marker rather than by guessing from the
// path.
//
// The search is rooted at the repository directory and reads through that root,
// so a symbolic link inside the tree cannot lead it outside.
func configFilesInRepository(t testing.TB) []string {
	t.Helper()

	root, err := os.OpenRoot(repoRoot(t))
	require.NoError(t, err)
	defer func() { require.NoError(t, root.Close()) }()

	tree := root.FS()
	var out []string

	for _, start := range []string{"go-core", "go-services", "cmd"} {
		walkErr := fs.WalkDir(tree, start, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() || filepath.Ext(path) != ".json" {
				return nil
			}
			if !strings.Contains(path, "/provider-config/") {
				return nil
			}
			data, readErr := fs.ReadFile(tree, path)
			if readErr != nil {
				return readErr
			}
			if bytes.Contains(data, []byte("\n--pipe=")) {
				out = append(out, path)
			}
			return nil
		})
		require.NoError(t, walkErr)
	}

	sort.Strings(out)
	return out
}

// TestManifest_NamesEveryProviderConfigurationInTheRepository keeps the list and
// the repository in step. Without it a configuration file added later would never
// be compiled by any test, and a grammar change would leave it behind.
func TestManifest_NamesEveryProviderConfigurationInTheRepository(t *testing.T) {
	listed := manifestEntries(t)
	found := configFilesInRepository(t)

	sort.Strings(listed)
	require.Equal(t, found, listed,
		"the list beside this test and the repository disagree; add or remove entries in %s",
		manifestFile)
}

// TestManifest_EveryConfigurationRendersAndCompiles fills in every pipeline in
// the list and compiles it. A file written in an older grammar fails here.
func TestManifest_EveryConfigurationRendersAndCompiles(t *testing.T) {
	root := repoRoot(t)
	cbCtx := newCtx(t, zerolog.ErrorLevel)
	steps := providerpipe.StepTypes()

	for _, entry := range manifestEntries(t) {
		t.Run(entry, func(t *testing.T) {
			data, err := os.ReadFile(filepath.Join(root, entry))
			require.NoError(t, err)

			items, readErr := providerconfig.ReadConfig(cbCtx, string(data))
			require.Nil(t, readErr, "reading the provider configuration")

			cfg, cfgErr := providerconfig.CreateConfig(items...)
			require.Nil(t, cfgErr, "building the provider configuration")

			pipes := cfg.GetPipes()
			require.NotEmpty(t, pipes, "the file must hold at least one pipeline")

			for operation, pipeText := range pipes {
				t.Run(operation, func(t *testing.T) {
					compileRenderedPipeline(t, cbCtx, cfg, operation, pipeText, steps)
				})
			}
		})
	}
}

// compileRenderedPipeline fills one pipeline in the way providerpipe does and
// compiles what comes out.
func compileRenderedPipeline(
	t testing.TB,
	cbCtx ifcore.CbContext,
	cfg *providermodel.ProviderConfigImpl,
	operation, pipeText string,
	steps *cbpipeline.Registry,
) {
	t.Helper()

	// The name of the variable holding the generator template is decided per run
	// by the provider. Any name will do here: what is being checked is that the
	// pipeline this file describes is written in the grammar the reader accepts.
	tmpl, parseErr := providerconfig.ResolveTemplate(
		cfg,
		operation,
		"generate",
		"fail",
		providermodel.MappingDirectionLeftAssign,
		false, /*delayedGeneratorTemplate*/
		template.FuncMap{},
		map[string]any{},
	).Parse(pipeText)
	require.NoError(t, parseErr, "reading the Go template around the pipeline")

	var filled bytes.Buffer
	require.NoError(t, tmpl.Execute(&filled, cfg), "filling the pipeline in")

	doc, readErr := cbpipeline.Read(cbCtx, filled.Bytes(), cbpipeline.WithRegistry(steps))
	require.Nil(t, readErr, "reading the pipeline:\n%s", filled.String())

	_, compileErr := cbpipeline.Compile(cbCtx, doc, steps)
	require.Nil(t, compileErr, "compiling the pipeline:\n%s", filled.String())
}
