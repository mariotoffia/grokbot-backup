package providercontext

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// UserProviderConfigLoader is a function that will load the user config for the provider.
//
// If no configuration is found but the system is correctly setup, it will return _empty_ `string` and no error.
type UserProviderConfigLoader func(ctx ifcore.CbContext, locationID string) (string, cberror.Error)

// loadConfig will load the configuration, if is available. If not available or no loader
// it will return the _userConfig_ parameter instead.
//
// It will also check the _configUsage_ to see if it should load the configuration or not.
func loadUserConfig(
	ctx ifcore.CbContext,
	loader []UserProviderConfigLoader,
	userConfig, locationID string,
	configUsage ProviderUserConfigUsage,
) (string, cberror.Error) {
	if loader == nil {
		return userConfig, nil
	}

	// Iterate all loaders to find the user configuration.
	find := func() (string, cberror.Error) {
		if locationID == "" {
			return "", cberror.NewCbErrorfWithProps(
				ctx.Service(), 1, nil,
				map[string]any{cberror.PropertyProvider: ctx.Provider()},
				"Location ID is empty",
			)
		}

		for _, l := range loader {
			if cfg, err := l(ctx, locationID); err != nil {
				return "", err
			} else if cfg != "" {
				return cfg, nil
			}
		}

		return userConfig, nil
	}

	switch configUsage {
	case ProviderUserConfigUsageNone, ProviderUserConfigUsageManual:
		if userConfig == "" {
			return "", cberror.NewCbErrorfWithProps(ctx.Service(), 1, nil, map[string]any{
				cberror.PropertyProvider: ctx.Provider(),
			}, "User config is required but not provided (set it to ProviderUserConfigUsageLoaderPerLocationID to load it automatically)")
		}

		return userConfig, nil
	case ProviderUserConfigUsageLoaderPerLocationID:
		return find()
	}

	return "", cberror.NewCbErrorfWithProps(ctx.Service(), 1, nil, map[string]any{
		cberror.PropertyProvider: ctx.Provider(),
	}, "Unknown config usage: %s", configUsage)
}
