package providerpipe

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestIsSourceMapping_True(t *testing.T) {
	tests := []struct {
		name     string
		id       string
		expected bool
	}{
		{"simple id mapping", "{{ID}}", true},
		{"keyed mapping", "{{IDT:ID}}", true},
		{"with prefix", "prefix{{ID}}", true},
		{"with suffix", "{{ID}}suffix", true},
		{"nested", "pre{{key:ID}}post", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.expected, IsSourceMapping(tt.id))
		})
	}
}

func TestIsSourceMapping_False(t *testing.T) {
	tests := []struct {
		name string
		id   string
	}{
		{"plain string", "IDT_O1"},
		{"only open braces", "{{ID"},
		{"only close braces", "ID}}"},
		{"empty", ""},
		{"single braces", "{ID}"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.False(t, IsSourceMapping(tt.id))
		})
	}
}

func TestGetSourceMappingKey_WithKey(t *testing.T) {
	key, ok := GetSourceMappingKey("{{IDT:ID}}")
	assert.True(t, ok)
	assert.Equal(t, "IDT", key)
}

func TestGetSourceMappingKey_WithoutKey(t *testing.T) {
	key, ok := GetSourceMappingKey("{{ID}}")
	assert.True(t, ok)
	assert.Equal(t, "", key)
}

func TestGetSourceMappingKey_NotSourceMapping(t *testing.T) {
	key, ok := GetSourceMappingKey("IDT_O1")
	assert.False(t, ok)
	assert.Equal(t, "", key)
}

func TestGetSourceMappingKey_NestedWithKey(t *testing.T) {
	// Note: GetSourceMappingKey extracts based on position, so prefix affects the result
	// For "prefix{{ODT:ID}}suffix", it will extract "efix{{ODT" due to [2:] slice
	// This tests the actual behavior - only use without prefixes
	key, ok := GetSourceMappingKey("{{ODT:ID}}suffix")
	assert.True(t, ok)
	assert.Equal(t, "ODT", key)
}

func TestToSourceMappingAndRemoteIDs_Mixed(t *testing.T) {
	input := []string{"{{IDT:ID}}", "remote1", "{{ODT:ID}}", "remote2", "{{ID}}"}
	sm, rids := ToSourceMappingAndRemoteIDs(input)

	assert.Equal(t, []string{"IDT", "ODT", ""}, sm)
	assert.Equal(t, []string{"remote1", "remote2"}, rids)
}

func TestToSourceMappingAndRemoteIDs_OnlyRemoteIDs(t *testing.T) {
	input := []string{"remote1", "remote2", "remote3"}
	sm, rids := ToSourceMappingAndRemoteIDs(input)

	assert.Nil(t, sm)
	assert.Equal(t, input, rids)
}

func TestToSourceMappingAndRemoteIDs_OnlySourceMappings(t *testing.T) {
	input := []string{"{{IDT:ID}}", "{{ODT:ID}}"}
	sm, rids := ToSourceMappingAndRemoteIDs(input)

	assert.Equal(t, []string{"IDT", "ODT"}, sm)
	assert.Nil(t, rids)
}

func TestToSourceMappingAndRemoteIDs_Empty(t *testing.T) {
	sm, rids := ToSourceMappingAndRemoteIDs([]string{})
	assert.Nil(t, sm)
	assert.Nil(t, rids)
}

// Tests for unexported macroSubstitution
func TestMacroSubstitution_PlainID(t *testing.T) {
	result := macroSubstitution("IDT", "IDT_O1_C2_Z3", "prefix_{{ID}}_suffix")
	assert.Equal(t, "prefix_IDT_O1_C2_Z3_suffix", result)
}

func TestMacroSubstitution_WithOrdo(t *testing.T) {
	result := macroSubstitution("IDT_", "IDT_O1", "prefix_{{IDT:ID:O}}_suffix")
	assert.Equal(t, "prefix_1_suffix", result)
}

func TestMacroSubstitution_WithCircuit(t *testing.T) {
	result := macroSubstitution("IDT_", "IDT_O1_C2", "value_{{IDT:ID:C}}")
	assert.Equal(t, "value_2", result)
}

func TestMacroSubstitution_WithZone(t *testing.T) {
	result := macroSubstitution("IDT_", "IDT_O1_C2_Zhello", "value_{{IDT:ID:Z}}")
	assert.Equal(t, "value_hello", result)
}

func TestMacroSubstitution_WithPostFix(t *testing.T) {
	// PostFix() extracts the suffix after the zone identifier
	// For sensor "IDT_O1_C2", PostFix() returns "_O1_C2" based on SensorType implementation
	result := macroSubstitution("IDT_", "IDT_O1_C2", "value_{{IDT:ID:PF}}")
	// Verifying actual behavior - the postfix is the suffix part
	assert.Equal(t, "value__O1_C2", result)
}

func TestMacroSubstitution_WithFullKey(t *testing.T) {
	result := macroSubstitution("IDT_", "IDT_O1_C2", "prefix_{{IDT:ID}}_suffix")
	assert.Equal(t, "prefix_IDT_O1_C2_suffix", result)
}
