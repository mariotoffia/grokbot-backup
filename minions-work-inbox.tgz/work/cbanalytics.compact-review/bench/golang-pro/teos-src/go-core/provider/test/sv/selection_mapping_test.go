package sv

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

var (
	tzEuropeStockholm = "Europe/Stockholm"
	pathSvProvider    = "/provider/test/sv"
	selMappingPoint0  = "c1154ad0-3023-58c7-b726-2cdb529ddee2"
	selMappingPoint1  = "82f3dbc7-592f-5beb-afa4-b305177f8ba8"
	selMappingPoint2  = "def4829f-deca-5241-9478-be6977bf4897"
	selMappingPoint3  = "def4829f-deca-5241-9478-be6977bf489A"
	selMappingPoint4  = "def4829f-deca-5241-9478-be6977bf489B"
	selMappingPoints  = []eqmodel.CbDataPoint{
		&RemoteDataPoint{
			ID: selMappingPoint0,
			Attributes: &RemoteAttributes{
				Label: "B_01'H'Hcr(CB03)'Hcrv'CB'ComFltStrgy(ComT)",
			},
			PointValue: &RemoteDataValue{Value: "45", TimeStamp: time.Now().UTC()},
		},
		&RemoteDataPoint{
			ID: selMappingPoint1,
			Attributes: &RemoteAttributes{
				Label: "B_01'H'Hcr(CB03)'Hcrv'TOa1HCrv(HCTODT_1)",
			},
			PointValue: &RemoteDataValue{Value: "-30", TimeStamp: time.Now().UTC()},
		},
		&RemoteDataPoint{
			ID: selMappingPoint2,
			Attributes: &RemoteAttributes{
				Label: "B_01'H'Hcr(CB03)'Hcrv'TOa2HCrv(HCTODT_2)",
			},
			PointValue: &RemoteDataValue{Value: "-20", TimeStamp: time.Now().UTC()},
		},
		&RemoteDataPoint{
			ID: selMappingPoint3,
			Attributes: &RemoteAttributes{
				Label: "B_01'H'Hcr(CB03)'Hcrv'Test",
			},
			PointValue: &RemoteDataValue{Value: "999", TimeStamp: time.Now().UTC()},
		},
		&RemoteDataPoint{
			ID: selMappingPoint4,
			Attributes: &RemoteAttributes{
				Label: "B_01'H'Hcr(CB03)'Hcrv'Test2",
			},
			PointValue: &RemoteDataValue{Value: "888", TimeStamp: time.Now().UTC()},
		},
	}
)

// TestSelectionMappingModeUsingSrc tests the selection mapping mode using source map. It uses the "src" mode
// and should really use "source" (sourceMap) but it works automatically with "src" as well (as long as it is a CbDataPoint).
func TestSelectionMappingModeUsingSrc(t *testing.T) {
	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			return selMappingPoints, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationSensorValueIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(pathSvProvider, builder))

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			`{
				"profile": "single-plant/mmo-selection",
				"prms": {
					"BID": "Siemens Building 01",
					"PID": "37191663-a7d6-46bd-aa58-2c046962953f",
					"TID": "0387c703-0cea-4a80-8749-d241e4bc6812"
				}
			}`,
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	dsb := cbevent.ExtractResult[map[string]dsmodel.DsBuilding](res, 0)

	assert.Equal(t, tzEuropeStockholm, dsb["target"].TimeZone)
	assert.Equal(t, float64(45), dsb["target"].Sensors["COMT"])
	assert.Equal(t, float64(-30), dsb["target"].Sensors["HCTODT_O1"])
	assert.Equal(t, float64(-20), dsb["target"].Sensors["HCTODT_O2"])
}

// TestSelectionMappingModeUsingSourceMap is just a a test to show that it supports returning a "source".
func TestSelectionMappingModeUsingSourceMap(t *testing.T) {
	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(
			ctx ifcore.CbContext, pipeCtx map[string]any, operation string, op *providermodel.Operation, pc *providermodel.ProviderConfigImpl, rid []string,
			cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error) {
			return map[string]eqmodel.CbDataPoint{
				selMappingPoint0: selMappingPoints[0],
				selMappingPoint1: selMappingPoints[1],
				selMappingPoint2: selMappingPoints[2],
				selMappingPoint3: selMappingPoints[3],
				selMappingPoint4: selMappingPoints[4],
			}, nil /*body*/, nil /*src*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationSensorValueIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(pathSvProvider, builder))

	pctx := builder.Build()

	// It is possible to override or add to the source map (but not remove).
	// NOTE: When changing a regex or datasource name -> ADD!!
	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			`{
				"profile": "single-plant/mmo-selection",
				"prms": {
					"BID": "Siemens Building 01",
					"PID": "37191663-a7d6-46bd-aa58-2c046962953f",
					"TID": "0387c703-0cea-4a80-8749-d241e4bc6812"
				},
				"src": {
					"select": {
						"['Device-' + PID]": {
							"dstype": "device-group",
							"sel": {
								"^.*'Hcrv'TOa(?<O>[1-9][0-9]*)HCrv.*$": { "teos": "HCTSTS_O{{.O}}", "expr": "[Attributes.Label]" },
								"^.*'Hcrv'CB'ComFltStrgy.*$": {	"teos": "COMT", "expr": "[Attributes.Label]" },
								"^.*'Hcrv'CB'NotFound.*$": {	"teos": "NOTFOUND", "expr": "[Attributes.Label]" },
								"'Hcrv'Test$": {	"teos": "MY_ID_{{.MyID}}", "expr": "[Attributes.Label]", "custom": { "MyID": "[id('hash',5,$.ID)]"} },
								"'Hcrv'Test2$": {	"teos": "MY_ID_{{.MyID}}", "expr": "[Attributes.Label]", "custom": { "MyID": "[id('hash',$.ID)]"} }
							}
						}
					}
				}
			}`,
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Status))
	require.Equal(t, "", res.Status[0])
	require.Equal(t, 1, len(res.Result))

	dsb := cbevent.ExtractResult[map[string]dsmodel.DsBuilding](res, 0)

	assert.Equal(t, tzEuropeStockholm, dsb["target"].TimeZone)
	assert.Equal(t, float64(45), dsb["target"].Sensors["COMT"])
	assert.Equal(t, float64(-30), dsb["target"].Sensors["HCTSTS_O1"])
	assert.Equal(t, float64(-20), dsb["target"].Sensors["HCTSTS_O2"])
	assert.Equal(t, float64(999), dsb["target"].Sensors["MY_ID_96404"])
	assert.Equal(t, float64(888), dsb["target"].Sensors["MY_ID_10368588534039482194"])
	assert.NotContains(t, dsb["target"].Sensors, "NOTFOUND")
}

// TestSelectionMappingUsedAsPureLoadMechanism test the src load ability.
// That is, it will not produce any mappings, instead it just directs the provider
// to load stuff.
//
// This test will then have a strict mapping of the data points to the target.
func TestSelectionMappingUsedAsPureLoadMechanism(t *testing.T) {
	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(
			ctx ifcore.CbContext, pipeCtx map[string]any, operation string, op *providermodel.Operation, pc *providermodel.ProviderConfigImpl, rid []string,
			cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error) {
			if sel, ok := pipeCtx[string(ifprovider.ParameterSelectGroupings)].(providermodel.SelectorWithDataSet); !ok ||
				sel.DataSetType != providermodel.DataSetTypePointGroup {
				return nil, nil, nil, cberror.NewCbErrorf(
					ctx.Service(), 400, nil, "Expecting a selection with device groupings",
				)
			}

			return map[string]eqmodel.CbDataPoint{
				selMappingPoint0: selMappingPoints[0],
				selMappingPoint1: selMappingPoints[1],
				selMappingPoint2: selMappingPoints[2],
			}, nil /*body*/, nil /*src*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationSensorValueIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(pathSvProvider, builder))

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			`{
				"profile": "single-plant/selection-load",
				"prms": {
					"MID": "COMT HCTODT_O1 HCTODT_O2",
					"BID": "Siemens Building 01",
					"PID": "37191663-a7d6-46bd-aa58-2c046962953f",
					"TID": "0387c703-0cea-4a80-8749-d241e4bc6812"
				}
			}`,
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	dsb := cbevent.ExtractResult[map[string]dsmodel.DsBuilding](res, 0)

	assert.Equal(t, tzEuropeStockholm, dsb["target"].TimeZone)
	assert.Equal(t, float64(45), dsb["target"].Sensors["COMT"])
	assert.Equal(t, float64(-30), dsb["target"].Sensors["HCTODT_O1"])
	assert.Equal(t, float64(-20), dsb["target"].Sensors["HCTODT_O2"])
}

// TestSelectionMappingWithAGlobalEntryToSelectOnAllLoadedData will have one or more entries that loads data.
// The $global entry will always be executed last and on all data gathered.
func TestSelectionMappingWithAGlobalEntryToSelectOnAllLoadedData(t *testing.T) {
	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(
			ctx ifcore.CbContext, pipeCtx map[string]any, operation string, op *providermodel.Operation, pc *providermodel.ProviderConfigImpl, rid []string,
			cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error) {
			if sel, ok := pipeCtx[string(ifprovider.ParameterSelectGroupings)].(providermodel.SelectorWithDataSet); !ok ||
				sel.DataSetType != providermodel.DataSetTypePointGroup {
				return nil, nil, nil, cberror.NewCbErrorf(
					ctx.Service(), 400, nil, "Expecting a selection with device groupings",
				)
			}

			return map[string]eqmodel.CbDataPoint{
				selMappingPoint0: selMappingPoints[0],
				selMappingPoint1: selMappingPoints[1],
				selMappingPoint2: selMappingPoints[2],
			}, nil /*body*/, nil /*src*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationSensorValueIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(pathSvProvider, builder))

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			`{
				"profile": "single-plant/mmo-selection-global",
				"prms": {
					"MID": "COMT HCTODT_O1 HCTODT_O2",
					"BID": "Siemens Building 01",
					"PID": "37191663-a7d6-46bd-aa58-2c046962953f",
					"TID": "0387c703-0cea-4a80-8749-d241e4bc6812"
				}
			}`,
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	dsb := cbevent.ExtractResult[map[string]dsmodel.DsBuilding](res, 0)

	assert.Equal(t, tzEuropeStockholm, dsb["target"].TimeZone)
	assert.Equal(t, float64(45), dsb["target"].Sensors["COMT"])
	assert.Equal(t, float64(-30), dsb["target"].Sensors["HCTODT_O1"])
	assert.Equal(t, float64(-20), dsb["target"].Sensors["HCTODT_O2"])
}

func BenchmarkSelectionMappingModeUsingSourceMap(t *testing.B) {
	srcData := map[string]eqmodel.CbDataPoint{
		selMappingPoint0: selMappingPoints[0],
		selMappingPoint1: selMappingPoints[1],
		selMappingPoint2: selMappingPoints[2],
	}

	source :=
		func(
			ctx ifcore.CbContext, pipeCtx map[string]any, operation string, op *providermodel.Operation, pc *providermodel.ProviderConfigImpl, rid []string,
			cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error) {
			return srcData, nil /*body*/, nil /*src*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationSensorValueIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(pathSvProvider, builder))

	pctx := builder.Build()

	payload := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			`{
				"profile": "single-plant/mmo-selection",
				"prms": {
					"BID": "Siemens Building 01",
					"PID": "37191663-a7d6-46bd-aa58-2c046962953f",
					"TID": "0387c703-0cea-4a80-8749-d241e4bc6812"
				}
			}`,
		},
	})

	for i := 0; i < t.N; i++ {
		_, _ = pctx.Invoker().InvokeRaw(ctx, payload)
	}
}

func BenchmarkSelectionMappingModeUsingSourceMap2(t *testing.B) {
	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(
			ctx ifcore.CbContext, pipeCtx map[string]any, operation string, op *providermodel.Operation, pc *providermodel.ProviderConfigImpl, rid []string,
			cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error) {
			return map[string]eqmodel.CbDataPoint{
				selMappingPoint0: selMappingPoints[0],
				selMappingPoint1: selMappingPoints[1],
				selMappingPoint2: selMappingPoints[2],
				selMappingPoint3: selMappingPoints[3],
				selMappingPoint4: selMappingPoints[4],
			}, nil /*body*/, nil /*src*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, testProvider, string(locationmodel.ProviderOperationSensorValueIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(pathSvProvider, builder))

	pctx := builder.Build()

	payload := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: testProvider,
		Result:   true,
		Config: []any{
			`{
				"profile": "single-plant/mmo-selection",
				"prms": {
					"BID": "Siemens Building 01",
					"PID": "37191663-a7d6-46bd-aa58-2c046962953f",
					"TID": "0387c703-0cea-4a80-8749-d241e4bc6812"
				},
				"src": {
					"select": {
						"['Device-' + PID]": {
							"dstype": "device-group",
							"sel": {
								"^.*'Hcrv'TOa(?<O>[1-9][0-9]*)HCrv.*$": { "teos": "HCTSTS_O{{.O}}", "expr": "[Attributes.Label]" },
								"^.*'Hcrv'CB'ComFltStrgy.*$": {	"teos": "COMT", "expr": "[Attributes.Label]" },
								"^.*'Hcrv'CB'NotFound.*$": {	"teos": "NOTFOUND", "expr": "[Attributes.Label]" },
								"'Hcrv'Test$": {	"teos": "MY_ID_{{.MyID}}", "expr": "[Attributes.Label]", "custom": { "MyID": "[id('hash',5,$.ID)]"} },
								"'Hcrv'Test2$": {	"teos": "MY_ID_{{.MyID}}", "expr": "[Attributes.Label]", "custom": { "MyID": "[id('hash',$.ID)]"} }
							}
						}
					}
				}
			}`,
		},
	})

	for i := 0; i < t.N; i++ {
		_, _ = pctx.Invoker().InvokeRaw(ctx, payload)
	}
}
