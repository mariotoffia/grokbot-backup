package cfgchgsrc

import (
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils/jsondiffutil"
	"github.com/Thiink-LLC/teos/go-core/utils/maputils"
)

// ConfigUpdate will perform the config update operation on the _found_ diff.
func ConfigUpdate(
	m map[string]any,
	selector Selector,
	found []jsondiffutil.Operation,
) map[string]any {
	if selector.LeafExpandIndex < 1 {
		for _, v := range found {
			if v.Type == jsondiffutil.OperationAdd ||
				v.Type == jsondiffutil.OperationCopy ||
				v.Type == jsondiffutil.OperationReplace {
				m[v.Name()] = v.Value
			}
		}

		return m
	}

	for _, v := range found {
		if v.Type == jsondiffutil.OperationAdd ||
			v.Type == jsondiffutil.OperationCopy ||
			v.Type == jsondiffutil.OperationReplace {
			if v.Length() > selector.LeafExpandIndex {
				// Leaf is after the expand index -> expand the leaf.
				m = maputils.EnsurePath(m, v.SubPath(selector.LeafExpandIndex-1), v.Value, "/")
			} else {
				m[v.Name()] = v.Value
			}
		}
	}

	return m
}
