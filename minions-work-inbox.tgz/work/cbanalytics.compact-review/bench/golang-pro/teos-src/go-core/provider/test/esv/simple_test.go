package esv

import (
	"fmt"
	"testing"

	"github.com/ahmetb/go-linq/v3"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSimpleExportProvider(t *testing.T) {
	type UpdateDataPointList struct {
		Values []*eqmodel.CbDataPointImpl `json:"values"`
	}

	// Received in the target function
	var toTransmit *UpdateDataPointList

	targetFunc := func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		// Extract the target
		toTransmit = providerutils.ExtractTarget[UpdateDataPointList](target)
		return nil
	}

	afterInvoked := false

	after := func(
		ctx ifcore.CbContext,
		pipeCtx map[string]any,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		target map[string]any) cberror.Error {
		//
		afterInvoked = true
		return nil
	}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider-2", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", &UpdateDataPointList{}).
				UseSource(providerpipe.DefaultDsFullBuildingSourceFunc()).
				UseTarget(targetFunc).
				UseAfter(after).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	// Bind the dispatcher to provider context.
	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(simpleTestPath, builder))

	pctx := builder.Build()

	conf := `{
		"profile": "generic",
			"prms": {
				"LOG": "off","MID": "IDT_O1 IDT_O2 COMT OFFODT",
				"CRD": "", "BID": "Måssmyren 18", "PID": "1234", "TID": "1"				
			}}`

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider:    "test-provider-2",
		Result:      true,
		Config:      []any{conf},
		PayloadType: cbevent.PayloadBuildingDeviceShadow,
		Payload: jsonutils.ToJSONRawMessage(&dsmodel.DsFullBuilding{
			BuildingID: "Måssmyren 18",
			State: &dsmodel.DsFullBuildingState{
				Desired: &dsmodel.DsBuilding{
					TimeZone:   "Europe/Stockholm",
					ReportType: string(providerutils.ReportDsBuildingAcknowledge),
					Sensors: map[string]any{
						"IDT_O1":  20.5,
						"IDT_O2":  21.5,
						"OFFODT":  2.46,
						"COMTALG": 14,
					},
				},
			},
		}),
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))
	require.Equal(t, "", res.Status[0])

	require.NotNil(t, toTransmit, "The target function was not invoked")
	assert.True(t, afterInvoked, "The after function was not invoked")

	target := cbevent.ExtractResult[map[string]UpdateDataPointList](res, 0)

	verifyValues := func(list []*eqmodel.CbDataPointImpl) {
		require.Equal(t, 4, len(list))

		v := linq.From(list).Where(func(i interface{}) bool {
			return i.(*eqmodel.CbDataPointImpl).ID == "1234;climatixic:IDT_O1"
		}).First().(*eqmodel.CbDataPointImpl)

		assert.Equal(t, float64(20.5), v.Value)

		v = linq.From(list).Where(func(i interface{}) bool {
			return i.(*eqmodel.CbDataPointImpl).ID == "1234;climatixic:IDT_O2"
		}).First().(*eqmodel.CbDataPointImpl)

		assert.Equal(t, float64(21.5), v.Value)

		// 		"OFFODT": "climatixic:OFFODT",
		//	"COMT": "climatixic:COMT"
		v = linq.From(list).Where(func(i interface{}) bool {
			return i.(*eqmodel.CbDataPointImpl).ID == "1234;climatixic:OFFODT"
		}).First().(*eqmodel.CbDataPointImpl)

		assert.Equal(t, float64(2.46), v.Value)

		v = linq.From(list).Where(func(i interface{}) bool {
			return i.(*eqmodel.CbDataPointImpl).ID == "1234;climatixic:COMT"
		}).First().(*eqmodel.CbDataPointImpl)

		assert.Equal(t, float64(14), v.Value)
	}

	verifyValues(toTransmit.Values)
	verifyValues(target["target"].Values)

}

func BenchmarkSimpleExportProvider(t *testing.B) {
	t.Run("generic", func(b *testing.B) {
		benchmarkSimpleExportProvider(b, "generic")
	})

	t.Run("generic-no-policy", func(b *testing.B) {
		benchmarkSimpleExportProvider(b, "generic-no-policy")
	})
}

func benchmarkSimpleExportProvider(t *testing.B, profile string) {
	type UpdateDataPointList struct {
		Values []*eqmodel.CbDataPointImpl `json:"values"`
	}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", &UpdateDataPointList{}).
				UseSource(providerpipe.DefaultDsFullBuildingSourceFunc()).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent(simpleTestPath, builder))

	pctx := builder.Build()

	conf := fmt.Sprintf(`{
		"profile": "%s",
			"prms": {
				"LOG": "off","MID": "IDT_O1 IDT_O2 COMT OFFODT",
				"CRD": "", "BID": "Måssmyren 18", "PID": "1234", "TID": "1"
			}}`, profile)

	payload := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider:    "test-provider",
		Result:      true,
		Config:      []any{conf},
		PayloadType: cbevent.PayloadBuildingDeviceShadow,
		Payload: jsonutils.ToJSONRawMessage(&dsmodel.DsFullBuilding{
			BuildingID: "Måssmyren 18",
			State: &dsmodel.DsFullBuildingState{
				Desired: &dsmodel.DsBuilding{
					TimeZone:   "Europe/Stockholm",
					ReportType: "silent",
					Sensors: map[string]any{
						"IDT_O1": 20.5,
						"IDT_O2": 21.5,
						"OFFODT": 2.46,
					},
				},
			},
		}),
	})

	invoker := pctx.Invoker()

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		_, _ = invoker.InvokeRaw(ctx, payload)
	}
}
