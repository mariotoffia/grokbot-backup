package svprovider

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// cSpell: disable

func TestPolicyRemovesOutsideOfRangeSensors(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	// ODT and IDT_03 is out of range, filtered out and reported in log.
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}`

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(-40), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(-669), nil).
		Value("IDT_O4", float64(40), nil)

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	assert.Equal(t, "Europe/Stockholm", targetLocation.TimeZone)

	assert.Equal(
		t,
		4,
		len(targetLocation.Sensors),
		"two is outside of range and hence policy shall remove them",
	)

	assert.Equal(t, float64(-1.2), targetLocation.Sensors["OFFODT"])
	assert.Equal(t, float64(20), targetLocation.Sensors["IDT_O1"])
	assert.Equal(t, float64(15), targetLocation.Sensors["IDT_O2"])
	assert.Equal(t, float64(40), targetLocation.Sensors["IDT_O4"])

}

func TestSamplePluginConfiguredToSilentlyDroppedfMissing(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel}

	// IDT_O14 do not exist, filtered out and silently dropped.
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT IDT_O14",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}`

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(25), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(32), nil).
		Value("IDT_O4", float64(40), nil)

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	assert.Equal(t, "Europe/Stockholm", targetLocation.TimeZone)

	assert.Equal(
		t,
		6,
		len(targetLocation.Sensors),
		"IDT_O14 has no datapoint, it will be removed by policy",
	)

	assert.Equal(t, float64(25), targetLocation.Sensors["ODT"])
	assert.Equal(t, float64(-1.2), targetLocation.Sensors["OFFODT"])
	assert.Equal(t, float64(20), targetLocation.Sensors["IDT_O1"])
	assert.Equal(t, float64(15), targetLocation.Sensors["IDT_O2"])
	assert.Equal(t, float64(32), targetLocation.Sensors["IDT_O3"])
	assert.Equal(t, float64(40), targetLocation.Sensors["IDT_O4"])
	assert.Equal(t, nil, targetLocation.Sensors["IDT_O14"])

}

func TestSamplePluginSensorConfiguredToFailIfMissing(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel}

	// URG_01 is not configured in policydata=sv, hence default is to fail (deny)
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT URG_O1",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}`

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(-40), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(-669), nil).
		Value("IDT_O4", float64(40), nil)

	assert.Panics(t, func() {
		NewDsBuildingPlugin(
			testProvider(0), "unit-test", "test-provider",
			bufio.NewReader(strings.NewReader(data)),
		).Execute()
	})
}

func TestSamplePluginOverridePolicyData(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel}

	// ODT is now included since override do allow for bigger range
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}
--policydata=sv
{
	"range": {"IDT**": [-100, 100], "ODT**": [-40, 200]},
	"report": ["ODT", "IDT_O3**"],
	"skip": ["IDT", "IDT_**"]
}
`

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(-40), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(-669), nil).
		Value("IDT_O4", float64(40), nil)

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	assert.Equal(t, "Europe/Stockholm", targetLocation.TimeZone)

	assert.Equal(
		t,
		5,
		len(targetLocation.Sensors),
		"IDT_O3 is removed by policy",
	)

	assert.Equal(t, float64(-40), targetLocation.Sensors["ODT"], "policy accepts ODT -40 to 100")
	assert.Equal(t, float64(-1.2), targetLocation.Sensors["OFFODT"])
	assert.Equal(t, float64(20), targetLocation.Sensors["IDT_O1"])
	assert.Equal(t, float64(15), targetLocation.Sensors["IDT_O2"])
	assert.Equal(t, nil, targetLocation.Sensors["IDT_O3"])
	assert.Equal(t, float64(40), targetLocation.Sensors["IDT_O4"])
	assert.Equal(t, nil, targetLocation.Sensors["IDT_O14"])
}

func TestFredrik(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	smallConf := `{
    "profile": "fredrik",
    "prms": {
			"LOG": "on",
      "BID": "unittest-891107228729577642",
      "CRD": "",
      "LOG": "on",
      "MID": "IDT",
      "NBR": true,
      "PID": "27gt3th3",
      "REP": "http://127.0.0.1:61858",
      "TID": "",
      "TS": true
    },
    "map": {
      "HUM": "asset_one;humidity",
      "IDT": "asset_one;temperature"
    }
  }`

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("IDT", float64(20), nil).
		Value("HUM", float64(80.0), nil)

	wanted = []string{"IDT", "HUM" /*since part of mapping in smallConf*/}

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	assert.Equal(t, "Europe/Stockholm", targetLocation.TimeZone)

	assert.Equal(
		t,
		2,
		len(targetLocation.Sensors),
		"we should have both IDT and HUM",
	)

	assert.Equal(t, float64(20), targetLocation.Sensors["IDT"])
	// When provider config - mapping section will not contriubte to MID but
	// in config (that will be merged with the provider profile) will contribute
	// to mid (hence the MID: "IDT" is redundant in the smallConf)
	assert.Equal(t, 80.0, targetLocation.Sensors["HUM"])
}
