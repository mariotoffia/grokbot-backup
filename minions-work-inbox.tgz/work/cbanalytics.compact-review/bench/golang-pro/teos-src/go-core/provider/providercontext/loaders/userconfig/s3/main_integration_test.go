//go:build integration

package s3_test

import (
	"os"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestMain points every test in this package at the AWS backend the build tags
// select: the local emulator with the floci tag, real AWS without it. The tests
// create and remove their own resources and need no deployed TEOS system.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvUsingManualAWSResources))
}
