package providertest

import (
	"os"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot/awsmgriot"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/rs/zerolog"
)

// ProviderTestRunner is a runner to run  `ProviderTestCase` instances.
type ProviderTestRunner struct {
	ctx   ifcore.CbContext
	pctx  providercontext.ProviderContext
	level zerolog.Level
	env   *testenv.Environment
}

// Cleanup gives back what NewRunner took: the IoT endpoint it published and
// the environment it attached to. Use it with `defer` in your test.
func (runner *ProviderTestRunner) Cleanup() {
	cbenv.CB_REP.UnSet()

	if runner.env != nil {
		_ = runner.env.Close()
		runner.env = nil
	}
}

// NewRunner will setup the test runner for executing one or more `Provider`.
//
// The runner calls AWS: it asks AWS IoT for the endpoint the device shadows of
// this account live on, and the providers it runs then read and write those
// shadows. It creates the things it needs itself and must remove them again.
//
// If `CB_TEST_LOG_LEVEL` environment variable is set it will override _level_.
// If neither is set it defaults to `zerolog.FatalLevel`.
//
// Anything that stops the runner from reaching AWS panics, so that
// NewRunnerOrSkip can turn it into a skipped test.
func NewRunner(
	serve func(dryRun bool) (providercontext.ProviderContext, ifcore.CbContext),
	level ...zerolog.Level,
) *ProviderTestRunner {
	if serve == nil {
		panic("serve function must be set")
	}

	l := GetTestLogLevel()

	if l == zerolog.NoLevel {
		if len(level) > 0 {
			l = level[0]
		} else {
			l = zerolog.FatalLevel
		}
	}

	env, err := testenv.EnvUsingManualAWSResources(testenv.Options{LogLevel: &l})

	if err != nil {
		panic(err)
	}

	var runner *ProviderTestRunner

	// The runner is what gives the environment back, in Cleanup. Until one
	// exists, nothing else can, so close the environment on every other way
	// out of this function. Each step below stops it by panicking, and one of
	// the steps is the caller's own serve function, so a deferred close is the
	// only thing that covers all of them. NewRunnerOrSkip turns such a panic
	// into a skipped test and carries on running the rest of the package.
	defer func() {
		if runner == nil {
			_ = env.Close()
		}
	}()

	pctx, ctx := serve(false /*dryRun*/)

	if pctx == nil {
		panic("serve function must return a valid providercontext.ProviderContext")
	}

	iotmgr := awsmgriot.NewAWSDSManager(ctx).
		DiscoverEndpoint()

	if iotmgr.Error() != nil {
		panic(iotmgr.Error())
	}

	_, _ = cbenv.CB_REP.SetString(iotmgr.Endpoint().String())
	ctx.SetValue(provider.ProviderCtxEndpoint, iotmgr.Endpoint())

	runner = &ProviderTestRunner{
		ctx:   ctx,
		pctx:  pctx,
		level: l,
		env:   env,
	}

	return runner
}

// NewRunnerOrSkip is a wrapper around NewRunner that gracefully skips
// the test when the surrounding environment cannot satisfy the runner's
// hard prerequisite of a real AWS IoT control-plane endpoint.
//
// Call sites use this when they want a test that is functionally an
// e2e test (it depends on real IoT discovery and shadow operations)
// but should not crash `make test-integration` runs that lack AWS
// credentials.
//
// Skip semantics (in order):
//
//  1. If `RUN_PROVIDER_E2E` is not set to "true", t.Skip is called.
//
//  2. Otherwise, the regular NewRunner is invoked. If it cannot reach
//     AWS - no usable credentials, or IoT endpoint discovery fails - it
//     panics, and the panic is recovered and translated into t.Skip,
//     keeping the test binary alive.
//
// The returned runner is nil when the test is skipped; callers must
// not dereference it after a skip - testing.T's Skip immediately
// terminates the goroutine via runtime.Goexit, so practical use is:
//
//	runner := providertest.NewRunnerOrSkip(t, sv.Serve, zerolog.FatalLevel)
//	defer runner.Cleanup()
//	// ... rest of test
func NewRunnerOrSkip(
	t *testing.T,
	serve func(dryRun bool) (providercontext.ProviderContext, ifcore.CbContext),
	level ...zerolog.Level,
) *ProviderTestRunner {
	t.Helper()

	if os.Getenv("RUN_PROVIDER_E2E") != "true" {
		t.Skip(
			"e2e: requires real AWS IoT discovery (DescribeEndpoint); set RUN_PROVIDER_E2E=true to run",
		)
		return nil
	}

	var runner *ProviderTestRunner
	defer func() {
		if r := recover(); r != nil {
			t.Skipf(
				"e2e: provider runner setup failed (likely missing AWS creds for IoT): %v", r,
			)
		}
	}()

	runner = NewRunner(serve, level...)
	return runner
}
