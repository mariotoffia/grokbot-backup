package tests

import (
	"testing"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// newCtx creates a new context for testing with the specified log level.
func newCtx(tb testing.TB, level zerolog.Level) ifcore.CbContext {
	tb.Helper()
	c := testenv.DefaultContext(tb, "unit-test")
	zerolog.SetGlobalLevel(level)
	return c
}
