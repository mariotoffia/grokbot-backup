package esv

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/aws/aws-sdk-go-v2/aws"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/rtc"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"

	"github.com/Thiink-LLC/teos/go-core/provider/providercontext/dispatcher/patterns"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cblambda"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestParallelSourceAndMultiFrameTargetBatched test to have multiple frames that are
// parallelized into provider pipelines, but the target is a single function that accepts
// a batch of results that in its turn emits two frames.
//
// This tests shows how to efficiently pipe multiple payloads and then create a fewer payloads
// that is aggregate of the input payloads.
//
// It also demonstrates how to use a source to target in separate go routines and if there are
// more events than parallelism it will segment those into batches.
//
// TIP: This shows off two different pattern in same test and is just for testing purposes only.
// In the real world, use a single pattern makes more sense per provider.
func TestParallelSourceAndMultiFrameTargetBatched(t *testing.T) {
	// ------------ SAMPLE PAYLOAD ------------
	type ServiceCall struct {
		Subscriptions []*rtc.RtcServiceSubscriptionItem `json:"subs"`
		Actuations    []*rtc.RtcServiceActuationItem    `json:"act"`
	}

	var actuations []*rtc.RtcServiceActuationItem
	var subscriptions []*rtc.RtcServiceSubscriptionItem

	// Will be 4 frames with 10 items each
	for i := 0; i < 20; i++ {
		actuations = append(actuations, &rtc.RtcServiceActuationItem{
			Lid: fmt.Sprintf("Måssmyren %d", i),
			Pid: aws.String("myPlantID"),
			Tid: aws.String("myTenantID"),
			Dp: map[string]rtc.RtcValue{
				"OFFODT":    rtc.Float32AsRtcValue(aws.Float32(float32(i) + 0.5)),
				"custom_id": rtc.StringAsRtcValue(aws.String("custom value")),
			},
		})

		subscriptions = append(subscriptions, &rtc.RtcServiceSubscriptionItem{
			Lid:  fmt.Sprintf("Måssmyren %d", i),
			Pid:  aws.String("myPlantID"),
			Tid:  aws.String("myTenantID"),
			Mode: "full",
			Dp: &map[string]int32{
				"OFFODT":    900000, /*15min*/
				"custom_id": 900000,
			},
		})
	}

	// ------------  ROOT SERVICE CONTEXT ------------
	ctx := newProviderContext(t, "test-provider", "test-service")

	// ------------  PIPELINE ------------
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				// NOTE: We're not setting source and target since we're doing it on the
				//       provider context instead. This can be done either way you want :).
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("SimpleActuationFrame", &rtc.SimpleActuationFrame{}).
				WithMarshalPrototype("SimpleSubscriptionFrame", &rtc.SimpleSubscriptionFrame{}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// ------------ PROVIDER CONTEXT ------------
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	// ------------ DISPATCHER OBJECT ------------

	// Used to assert on the result (these emulates those being sent in the target function)
	var frames []*rtc.RtcChannelFrame

	// dispatcher is the one receiving the http request and applies a user config and runs
	// the provider pipeline.
	h := cblambda.JSONWithRoute("/path/to/endpoint", ctx,
		func(ctx ifcore.CbContext, sc *ServiceCall) (any, error) {
			// Actuations
			actuations := patterns.ParallelSourceBatchTargetExecute(
				ctx,
				sc.Actuations,
				patterns.ParallelSourceSingleBatchTargetOptions[rtc.RtcServiceActuationItem, rtc.SimpleActuationFrame]{
					// This config *REQUIRES* that LID, PID, and TID is present in the event!
					// TIP: This allows for one config for all LID and still address PID, TID
					Config:          `{ "profile": "parallel_aggregated", "prms": { "LOG": "off", "MID": "", "CRD": "" } }`,
					ProviderContext: builder.ProviderContext(),
					BatchTarget: func(ctx ifcore.CbContext, items []*rtc.SimpleActuationFrame) []patterns.BatchTargetError {
						frame := rtc.RtcChannelFrame{}
						for _, item := range items {
							item := item
							frame.Frames = append(frame.Frames, rtc.RtChannelMessage{
								SimpleActuationFrame: item,
							})
						}

						// Send the frame to e.g. SQS or other
						frames = append(frames, &frame)
						return nil
					},
					Source: func(ctx ifcore.CbContext, item *rtc.RtcServiceActuationItem) (map[string]any, cberror.Error) {
						return item.ToPipeSource(*coremodel.NewTimeUTC32Now())
					},
				},
			)

			subscriptions := patterns.ParallelSourceToTarget(
				ctx,
				sc.Subscriptions,
				patterns.ParallelSourceToTargetOptions[rtc.RtcServiceSubscriptionItem, rtc.SimpleSubscriptionFrame]{
					Config:          `{ "profile": "parallel_aggregated", "prms": { "LOG": "off", "MID": "", "CRD": "" } }`,
					ProviderContext: builder.ProviderContext(),
					BatchTarget: func(ctx ifcore.CbContext, items []*rtc.SimpleSubscriptionFrame) []patterns.BatchTargetError {
						frame := rtc.RtcChannelFrame{
							Meta: &rtc.RtcChannelFrameMeta{
								Source:    "test-service",
								Target:    []string{"rest"},
								Mode:      rtc.TRANSPORT,
								Canonical: rtc.TEOS_DATAPOINTS.Ptr(),
							},
						}

						for _, item := range items {
							item := item
							frame.Frames = append(frame.Frames, rtc.RtChannelMessage{
								SimpleSubscriptionFrame: item,
							})
						}

						// Send the frame to e.g. SQS or other
						frames = append(frames, &frame)
						return nil
					},
					Source: func(ctx ifcore.CbContext, item *rtc.RtcServiceSubscriptionItem) (map[string]any, cberror.Error) {
						return item.ToPipeSource(*coremodel.NewTimeUTC32Now())
					},
				},
			)

			if err := actuations.CreateOrGetErrorIfExists(); err != nil {
				return nil, err // Re-try if e.g. SQS
			}

			return nil, subscriptions.CreateOrGetErrorIfExists() // Re-try ...
		},
	)

	builder.UseHandler(h)

	pctx := builder.Build()

	// Invoke the service
	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(
		&ServiceCall{
			Actuations:    actuations,
			Subscriptions: subscriptions,
		},
	))

	// Assert the result
	require.NoError(t, invokeError)
	require.Nil(t, result)
	require.True(t, len(frames) > 0)

	assert.Equal(t, 21, len(frames), "Expected 1 actuation frames and 20 subscription frames")

	// Iterate the frames and the messages and match against actuations so at least lid matches.
	var count int

	for _, frame := range frames {
		for _, msg := range frame.Frames {
			found := false

			if msg.SimpleSubscriptionFrame != nil {
				for _, subscription := range subscriptions {
					if subscription.Lid == msg.SimpleSubscriptionFrame.Lid {
						found = true
						break
					}
				}
			} else if msg.SimpleActuationFrame != nil {
				for _, actuation := range actuations {
					if actuation.Lid == msg.SimpleActuationFrame.Lid {
						found = true
						break
					}
				}
			}

			if found {
				count++
			}

			require.True(t, found)
		}
	}

	assert.Equal(t, len(actuations)+len(subscriptions), count)
}
