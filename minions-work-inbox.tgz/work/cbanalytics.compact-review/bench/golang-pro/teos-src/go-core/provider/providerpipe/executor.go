package providerpipe

import (
	"bytes"
	"strings"
	"text/template"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// ProviderPipelineExecutor represents one execution instance.
//
// This is created from the `ProviderPipeline` and may be additionally
// configured before performing its `Execution` of the actual pipeline.
type ProviderPipelineExecutor struct {
	pipe *ProviderPipeline
	// err contains the last error.
	err cberror.Error
	// operation is the operation to perform.
	operation string
	// logging when set to `true` it will log a verbose logging in pipe and pipe builders.
	// This property is automatically set out of current `ifcore.CbContext` or if optional from the LOG parameter in config.
	logging bool
	// config is the configuration for the `operation` that will be executed.
	config *providermodel.ProviderConfigImpl
	// profile is set when `config` is processed (it contains the profile to use)
	profile string
	// crd is the fq prefix to all variables for authentication / communication with remote peer.
	//
	// If _crd_ is empty it will be extracted from the `ParameterCredentials` in the `ProviderConfig.Parameter`
	// section and placed here before executing.
	crd string
	// mergedProviderCtx contains the data to be merged with the provider context that is used as the main context
	// in the pipeline. This is merged just before execution.
	mergedProviderCtx map[string]interface{}
	// sourceFunc is the function to populate the pipe with data in order to process.
	sourceFunc SourceFunction
	// targetFunc is the function that receives the resulting data after pipeline has processed
	targetFunc TargetFunction
	// filters are optional filters to be applied in the pipeline or otherwise used in the provider.
	// Those are registered in the `ProviderFilterFunctionContributor` implementations. Otherwise
	// this is `nil`.
	filters map[string]ifprovider.OperationFilters
}

// NewProviderPipelineExecutor creates a new executor for a single pipeline.
func (pipe *ProviderPipeline) NewProviderPipelineExecutor() *ProviderPipelineExecutor {
	return &ProviderPipelineExecutor{
		pipe: pipe,
	}
}

// Error returns an error if such has occurred.
//
// NOTE: The `ProviderPipelineExecutor` methods will stop function when it is in error state!
func (p *ProviderPipelineExecutor) Error() cberror.Error {
	return p.err
}

// ClearError clears any possible errors in the `ProviderPProviderPipelineExecutorPipeline`.
func (p *ProviderPipelineExecutor) ClearError() *ProviderPipelineExecutor {
	p.err = nil
	return p
}

// UseOperation will specify the operation to be used when executing.
//
// The operation will control which `ProviderConfig` to use from the `ProviderConfRepository`.
// That is, which templates, pipeline to use. To use strongly typed use `PipeOperationTypes` types such
// as `locationmodel.PipeOperationSensorValueIn` in form `string(locationmodel.PipeOperationSensorValueIn)`.
func (p *ProviderPipelineExecutor) UseOperation(operation string) *ProviderPipelineExecutor {
	p.operation = operation
	return p
}

// UseDefaultOperation is _exactly_ the same function as `UseOperation`, _except_ that it will check
// if an operation is already set (e.g. from `UseConfig`). If such is the case, it is not changed. If
// no operation is set it is put into `ProviderPipelineExecutor` to be performed.
func (p *ProviderPipelineExecutor) UseDefaultOperation(operation string) *ProviderPipelineExecutor {
	if p.operation == "" {
		p.operation = operation
	}

	return p
}

// Operation gets the current operation. If no operation is set, it returns an empty string.
func (p *ProviderPipelineExecutor) Operation() string {
	return p.operation
}

// Config is the cloned and merged `providermodel.ProviderConfig` that will be used in the pipeline execution.
//
// The `UseConfig()` must first been successfully invoked before this property will return the config.
// If not set or an error state, `nil` is returned.
func (p *ProviderPipelineExecutor) Config() *providermodel.ProviderConfigImpl {
	if p.pipe.lasterr != nil {
		return nil
	}

	return p.config
}

// UseFilter sets the filters to be registered in the pipeline.
func (p *ProviderPipelineExecutor) UseFilter(
	filter map[string]ifprovider.OperationFilters,
) *ProviderPipelineExecutor {
	p.filters = filter
	return p
}

// UseConfig will provision the config element that is used to execute the pipeline.
//
// Minimum requirements for the _conf_ parameter is to declare a profile. If an operation
// (key _OP_ in params) is set. This function will automatically set the operation to
// that. It is possible to change that using `UseOperation()`.
//
// .Minimum Configuration
// [source,json]
// ----
//
//	{
//	  "profile": "default"
//	}
//
// ----
//
// The _conf_ parameter is either a pure _JSON_ parameter or a set of _JSON_ payloads
// (_see `providerconfig.ReadConfig()` for more information_). If an error occurs it will
// set this `ProviderPipelineExecutor` in error state.
//
// The _conf_ parameter is merged with the profile referred from _conf_ and then executed.
// Hence, the _conf_ parameter acts as a override for a certain profile. The repository
// may contain several profiles to be references. Each provider must specify which profile
// names they support and what they contain.
func (p *ProviderPipelineExecutor) UseConfig(conf string) *ProviderPipelineExecutor {
	if p.err != nil {
		return p
	}

	// Merge user configuration with local profile
	p.config, p.err = p.pipe.repository.MergeFromConfigString(p.pipe.context, conf)
	if p.err != nil {
		return p
	}

	// Set the profile name
	p.profile = p.config.Profile

	// set custom operation (rather than the default operation specified by the provider)
	if oper, ok := p.config.Params[string(ifprovider.ParameterOperation)]; ok && oper != nil {
		if str, ok := oper.(string); ok {
			p.operation = str
		}
	}

	p.logging = p.pipe.context.PipeLogging() == cbenv.PipeLoggingOn

	if p.pipe.context.PipeLogging() == cbenv.PipeLoggingOptional {
		if pipelog := p.config.GetParamAsStringWithDefault(string(ifprovider.ParameterLogging), ""); pipelog != "" {
			p.logging = cbenv.PipeLogging(strings.ToLower(pipelog)) == cbenv.PipeLoggingOn
		}
	}

	return p
}

// UseCredentials sets the name of the object in the `SessionStore` to be retrieved.
// If no such exist in the `SessionStore` it will invoke a callback function to obtain
// such. This overrides the `ParameterCredentials` in the params section of the `ProviderConfig.Params`.
//
// .Examples of ParameterCredentials
// |===
// |Example |Comment
//
// |/provider/climatix/nordvestor
// |This is a global prefix where nordvestor auth params in beneath the _nordvestor_ node. In prod environment,
// password is rendered as /prod/provider/climatix/nordvestor/password.
//
// |climatix/nordvestor
// |This is a local prefix. In prod, service test-svc, user is rendered as /prod/test-svc/climatix/nordvestor.
//
// |===
//
// _See `ParameterCredentials` for more information.
func (p *ProviderPipelineExecutor) UseCredentials(crd string) *ProviderPipelineExecutor {
	p.crd = crd
	return p
}

// UseSource will set the function that is used to populate the pipe with _source_ data. This data is
// then processed in the pipeline.
//
// .Example Source Function
// [source,go]
// ----
// func(eop *providermodel.Operation, cred interface{}) (map[string]interface{}, cberror.Error) {
//
//	  myCreds, ok := cred.(*ClimatixIC)
//	  if !ok {
//		   // return error
//	  }
//	  // Call Remote rest endpoint specified in eop.Operation and parameters
//	  // eop.Parameters + cred object
//	  return map[string]interface{} {
//	    "source": restResult, <1>
//	  }, nil
//	}
//
// ----
// <1> Default pipes expects to be loaded with data named _"source"_.
func (p *ProviderPipelineExecutor) UseSource(
	sourcefunc SourceFunction,
) *ProviderPipelineExecutor {
	p.sourceFunc = sourcefunc
	return p
}

// UseTarget will set the function that is used to receive the resulting _target_ data from the pipeline.
// This data may e.g. be emitted to the thing shadow or if outgoing to a remote peer. If omitted, it will
// do nothing.
//
// .Example Target Function
// [source,go]
// ----
// func(eop *providermodel.Operation, target map[string]interface{}) cberror.Error {
//
//		// Call Remote rest endpoint specified in eop.Operation and parameters
//	   // eop.Parameters + auth in eop.Authentication
//	   // with target data.
//
// }
// ----
func (p *ProviderPipelineExecutor) UseTarget(
	targetfunc TargetFunction,
) *ProviderPipelineExecutor {
	p.targetFunc = targetfunc
	return p
}

// OverrideContext will be applied just before execution of the pipeline. This context is overrides on the main
// provider pipeline context. Thus, it may be used to register new things such as types, in the \_ts sub-map or
// top level overrides such as _source_.
//
// This may be used for a provider to do custom overrides.
func (p *ProviderPipelineExecutor) OverrideContext(
	overrides map[string]interface{},
) *ProviderPipelineExecutor {
	p.mergedProviderCtx = overrides
	return p
}

// Execute will create the context, pipeline, and execute it. If successful, it will return the result, otherwise `nil` is returned.
//
// If any object is marshalled, it is be written into _target_ of the returned `map`. In order to extract the _struct_, use the _target_ key.
//
// .Example Extracting DsBuilding
// [source,go]
// ----
//
//	func extractTarget(res map[string]interface{}) *dsmodel.DsBuilding {
//		errorMessage := ""
//		var target *dsmodel.DsBuilding
//
//		if trg, ok := res["target"]; ok {
//			if tempTarget, ok := trg.(*dsmodel.DsBuilding); ok {
//				return nil
//	     }
//	 }
//
//	 return nil
//	}
//
// ----
//
// TIP: Therefore there exists a utility function to provide this functionality `providerpipe.ExtractDsBuilding()`.
//
// The _mappingDirection_ specifies how the sensor parameters are mapped to and from the _TEOS_ canonical sensor and
// data point IDs.
func (p *ProviderPipelineExecutor) Execute(
	mappingDirection providermodel.MappingDirection,
) map[string]interface{} {
	if p.err != nil {
		if l, ok := logger.ClsLog(zerolog.WarnLevel, "ProviderPipelineExecutor::Execute", logger.LDTUntyped, logger.LISUnclassified, p.pipe.context); ok {
			l.Msgf("Cannot execute since error state: %s", p.err.Error())
		}

		return map[string]interface{}{}
	}

	// If disabled config, do nothing
	pst := ifprovider.ProvisionedState(p.config.GetParamAsStringWithDefault(
		string(ifprovider.ParameterProvisionedState),
		string(ifprovider.ProvisionedStateProvisioned),
	))

	if pst == ifprovider.ProvisionedStateDisabled {
		lid := p.config.GetParamAsStringWithDefault(
			string(ifprovider.ParameterLocationID),
			"unknown",
		)

		log.InfoWithLocationID(p.pipe.context, lid).
			Msg("Configuration is disabled, skipping execution")

		return map[string]interface{}{}
	}

	providerCtx, goTemplate := p.prepare(mappingDirection)
	if p.err != nil {
		return nil
	}

	prog := p.createPipe(providerCtx, goTemplate)
	if p.err != nil {
		return nil
	}

	return p.execute(providerCtx, prog)
}

// createPipe will create a build pipeline to execute. The _providerCtx_ and _goTemplate_ is created by `prepare` function.
//
// If it fails to generate the _JSON_ pipeline from the go template, it will set the error to code _1814_. If it does not
// have a generate section in the _JSON_ pipe it will set an error with error code of _1815_.
func (p *ProviderPipelineExecutor) createPipe(
	providerCtx map[string]interface{},
	goTemplate *template.Template,
) *cbpipeline.Program {
	var writer bytes.Buffer
	if terr := goTemplate.Execute(&writer, p.config); terr != nil {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(),
			cberror.ErrorProviderUnableToGeneratePipeFromTemplate,
			terr,
			"Failed to generate the JSON pipe from go template: %#v, error: %s",
			goTemplate.Root,
			terr.Error(),
		)
		return nil
	}

	if p.logging {
		if l, ok := logger.ClsLog(zerolog.TraceLevel, "createPipe", logger.LDTUntyped, logger.LISUnclassified, p.pipe.context); ok {
			l.Msgf("Wrote template: \n%s", writer.String())
		}
	}

	if !p.config.HasGenerate(p.operation) {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(),
			cberror.ErrorProviderUnableToGeneratePipeFromTemplate,
			nil,
			"config: %#v do not specify a generator template, hence impossible to generate",
			p.config,
		)

		return nil
	}

	// The compiled form is kept and reused. The same pipeline text is compiled
	// once and then run on every collection, so compiling it again each time
	// would be work thrown away. The set of step types is part of what the
	// compiled form is stored under, so a caller with different step types never
	// gets one built for someone else.
	prog, compileErr := compilePipeline(p.pipe.context, StepTypes(), writer.Bytes())
	if compileErr != nil {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(),
			cberror.ErrorProviderUnableToGeneratePipeFromTemplate,
			compileErr,
			"Failed to compile pipeline JSON: %s",
			compileErr.Error(),
		)
		return nil
	}

	return prog
}
