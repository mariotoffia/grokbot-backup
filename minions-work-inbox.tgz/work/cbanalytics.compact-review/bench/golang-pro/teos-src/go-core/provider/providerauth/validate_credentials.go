package providerauth

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
)

// ValidateCredentials will validate the credentials and ensure that the `securitymodel.CredentialConfig.Required`
// parameters are set accordingly.
//
// If it fails to validate the credentials it will return an `cberror.ConfigurationError` with info about the problem.
func ValidateCredentials(
	context ifcore.CbContext,
	op ifprovider.ConfigOperationErrors,
	cred interface{},
	config *securitymodel.CredentialConfig,
) cberror.Error {
	if cred == nil {
		return cberror.NewCbErrorConfigurationValidationErrorf(
			context.Service(),
			cberror.ConfigurationErrorTypeMissingSecurityMaterials,
			ErrorCredentialsMissing,
			nil, /*configuration*/
			nil, /*err*/
			op.GetErrorPropertyMapFromOperation(),
			"credentials-missing",
		)
	}

	switch t := cred.(type) {
	case *securitymodel.TokenCredentialsImpl:
		if err := validateStandardCredentials(context, op, &t.Credentials, config); err != nil {
			return err
		}
		if securitymodel.HasCredentialItemType(config.Required, securitymodel.CredentialItemTypeToken) && len(t.Token) == 0 {
			return cberror.NewCbErrorConfigurationValidationErrorf(
				context.Service(),
				cberror.ConfigurationErrorTypeMissingSecurityMaterials,
				ErrorCredentialsMissingToken, nil /*configuration*/, nil /*err*/, op.GetErrorPropertyMapFromOperation(),
				"missing-token",
			)
		}
	case *securitymodel.StandardCredentialsImpl:
		return validateStandardCredentials(context, op, t, config)
	default:
		return cberror.NewCbErrorConfigurationValidationErrorf(
			context.Service(),
			cberror.ConfigurationErrorTypeInvalidSecurityMaterials,
			ErrorCredentialsUnknownType, nil /*configuration*/, nil /*err*/, op.GetErrorPropertyMapFromOperation(),
			"credentials-unknown-type",
		)
	}

	return nil
}

// validateStandardCredentials verifies the `securitymodel.StandardCredentialsImpl`
func validateStandardCredentials(
	context ifcore.CbContext,
	op ifprovider.ConfigOperationErrors,
	cred *securitymodel.StandardCredentialsImpl,
	config *securitymodel.CredentialConfig) cberror.Error {
	for _, r := range config.Required {
		if r == securitymodel.CredentialItemTypeAPIKey && cred.APIKey == "" {
			return cberror.NewCbErrorConfigurationValidationErrorf(
				context.Service(),
				cberror.ConfigurationErrorTypeMissingSecurityMaterials,
				ErrorCredentialsMissingAPIKey,
				nil /*configuration*/, nil /*err*/, op.GetErrorPropertyMapFromOperation(),
				"missing-api-key",
			)
		}

		if r == securitymodel.CredentialItemTypeUsername && cred.User == "" {
			return cberror.NewCbErrorConfigurationValidationErrorf(
				context.Service(),
				cberror.ConfigurationErrorTypeMissingSecurityMaterials,
				ErrorCredentialsMissingUsername,
				nil /*configuration*/, nil /*err*/, op.GetErrorPropertyMapFromOperation(),
				"missing-username",
			)
		}

		if r == securitymodel.CredentialItemTypePassword && cred.Password == "" {
			return cberror.NewCbErrorConfigurationValidationErrorf(
				context.Service(),
				cberror.ConfigurationErrorTypeMissingSecurityMaterials,
				ErrorCredentialsMissingPassword,
				nil /*configuration*/, nil /*err*/, op.GetErrorPropertyMapFromOperation(),
				"missing-password",
			)
		}
	}

	return nil

}
