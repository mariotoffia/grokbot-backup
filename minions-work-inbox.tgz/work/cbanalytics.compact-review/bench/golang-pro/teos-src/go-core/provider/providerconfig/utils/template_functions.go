package utils

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/timeutils"
)

func Add(a, b any) any {
	if s, ok := a.(string); ok {
		return s + utils.ConvertToString(b, "" /*default*/)
	}

	if s, ok := b.(string); ok {
		return utils.ConvertToString(a, "" /*default*/) + s
	}

	if f, ok := a.(float64); ok {
		return f + utils.ConvertToFloat64(b, 0)
	}

	if f, ok := b.(float64); ok {
		return utils.ConvertToFloat64(a, 0) + f
	}

	if f, ok := a.(float32); ok {
		return float64(f) + utils.ConvertToFloat64(b, 0)
	}

	if f, ok := b.(float32); ok {
		return utils.ConvertToFloat64(a, 0) + float64(f)
	}

	return utils.ConvertToInt64(a, 0) + utils.ConvertToInt64(b, 0)
}

func Mul(a, b any) any {
	if a == nil || b == nil {
		return 0
	}

	if f, ok := a.(float64); ok {
		return f * utils.ConvertToFloat64(b, 0)
	}

	if f, ok := b.(float64); ok {
		return utils.ConvertToFloat64(a, 0) * f
	}

	if f, ok := a.(float32); ok {
		return float64(f) * utils.ConvertToFloat64(b, 0)
	}

	if f, ok := b.(float32); ok {
		return utils.ConvertToFloat64(a, 0) * float64(f)
	}

	return utils.ConvertToInt64(a, 0) * utils.ConvertToInt64(b, 0)
}

// First will select the keys using glob ('_') pattern in the referenced variable.
// If the expression is enclosed /.../ it will be treated as a regular expression instead.
//
// It returns the first value in the list of keys that matched the expression.
//
// If the optional flag "-v" is set, it will return the first value in the array of values.
//
// Multiple expressions are space separated. Thi is only supported for glob expressions.
//
// If noting is found, it will return `nil`.
func First(v map[string]any, expr string, flags ...string) (any, error) {
	val, err := Keys(v, expr, flags...)

	if err != nil {
		return nil, err
	}

	if v, ok := val.([]any); ok {
		if len(v) > 0 {
			return v[0], nil
		}

		return nil, nil
	}

	if v, ok := val.([]string); ok {
		if len(v) > 0 {
			return v[0], nil
		}
	}

	return nil, nil
}

// Keys will select the keys using glob ('_') pattern in the referenced variable.
// If the expression is enclosed /.../ it will be treated as a regular expression instead.
//
// It returns a list of keys that matched the expression.
//
// If the optional flag "-v" is set, it will return an array values.
//
// Multiple expressions are space separated. Thi is only supported for glob expressions.
func Keys(v map[string]any, expr string, flags ...string) (any, error) {
	keys := []string{}
	var values []any

	if slices.Contains(flags, "-v") {
		values = []any{}
	}

	err := Matcher(expr, v, func(key string, value any) {
		if values != nil {
			values = append(values, value)
		} else {
			keys = append(keys, key)
		}
	}, '_')

	if values != nil {
		return values, err
	}

	return keys, err
}

// MatchCallback is called each time a match was found in _Matcher_ function.
type MatchCallback func(key string, value any)

// Matcher will match using either regexp or glob. When glob it will default _ as
// separator but may be altered by the optional _sep_ parameter.
//
// When the _expr_ is enclosed in /.../ it will be treated as a regular expression.
//
// Multiple expressions are space separated. Thi is only supported for glob expressions.
func Matcher(expr string, m map[string]any, cb MatchCallback, sep ...rune) error { /* NOSONAR */
	if cb == nil {
		return fmt.Errorf("callback is nil")
	}

	if expr[0] == '/' && expr[len(expr)-1] == '/' {
		re, err := ProviderCache.RegExp(expr[1 : len(expr)-1])

		if err != nil {
			return err
		}

		for k, val := range m {
			if re.MatchString(k) {
				cb(k, val)
			}
		}

		return nil
	}

	globSep := '_'

	if len(sep) > 0 {
		globSep = sep[0]
	}

	for _, ex := range strings.Split(expr, " ") {
		glb, err := ProviderCache.Glob(ex, globSep)

		if err != nil {
			return err
		}

		for k, val := range m {
			if glb.Match(k) {
				cb(k, val)
			}
		}
	}

	return nil
}

// Iterate will iterate using the expression to resolve which ceIDs to include in each iteration.
//
// A iteration is a map[string]any where the key is all the found ceID (in it's raw form) for this iteration and the
// value is either the full ceID (the original key) or the actual value.
//
// Internally it uses the `InputEnumeratorImpl` to enumerate.
func Iterate(
	ctx ifcore.CbContext,
	expression string,
	data map[string]any,
	value ...bool,
) []map[string]any {
	var value2 bool

	if len(value) > 0 {
		value2 = value[0]
	}

	enumerator := NewInputEnumeratorImpl(ctx, expression)

	enumerator.Resolve(data)

	var result []map[string]any

	for {
		next, ok := enumerator.Next()
		if !ok {
			break
		}

		it := map[string]any{}
		for k, v := range next {
			raw := eqmodel.SensorType(k).RawID()

			if value2 {
				it[raw] = v
			} else {
				it[raw] = k
			}
		}

		if len(it) > 0 {
			result = append(result, it)
		}
	}

	return result
}

// GetValue will return the value based on the key. The key can either reference a map or a slice key/index.
//
// If found, it will return the value. If not found, it will return the default value or nil if not provided.
func GetValue(src any, key any, d ...any) any { /* NOSONAR */
	var def any

	if len(d) > 0 {
		def = d[0]
	}

	if src == nil {
		return def
	}

	if k, ok := key.(string); ok {
		if m, ok := src.(map[string]any); ok {
			if v, ok := m[k]; ok {
				return v
			} else {
				return def
			}
		}

		if m, ok := src.(map[string]string); ok {
			if v, ok := m[k]; ok {
				return v
			} else {
				return def
			}
		}

		return def
	}

	if k, ok := key.(int); ok {
		if s, ok := src.([]any); ok {
			if k < 0 || k >= len(s) {
				return def
			}

			return s[k]
		}

		if s, ok := src.([]string); ok {
			if k < 0 || k >= len(s) {
				return def
			}

			return s[k]
		}

		return def
	}

	return def
}

type ParseResult struct {
	Ok      bool
	ID      string
	Ordinal int
	Circuit int
	Zone    string
	Area    string
	Tags    map[string]any
}

// Parse calls the `eqmodel.SensorType.Parse` to parse the teosID and returns the id, ordinal, circuit, zone and area.
func Parse(teosID string) ParseResult {
	_, ok, id, ordinal, circuit, zone, area, tags := eqmodel.SensorType(teosID).Parse()

	return ParseResult{
		Ok:      ok,
		ID:      id,
		Ordinal: ordinal,
		Circuit: circuit,
		Zone:    zone,
		Area:    area,
		Tags:    tags,
	}
}

// IsType checks if the _v_ is of type _name_.
func IsType(name string, v any) bool {
	if v == nil {
		return false
	}

	switch v.(type) {
	case string:
		return name == "string"
	case int64, int32, int:
		return name == "int"
	case float64, float32:
		return name == "float"
	case bool:
		return name == "bool"
	}

	return false
}

// Circuit will return the circuit in a _TeosID_ (e.g. HCT_C2 -> Circuit 2),
// if it is a number it will return the number.
func Circuit(id any) int {
	if n := utils.ConvertToInt(id, -1); n != -1 {
		return n
	}

	var s string

	if s1, ok := id.(string); ok {
		s = s1
	} else {
		s = fmt.Sprintf("%v", id)
	}

	if idx := strings.Index(s, "_C"); idx > 0 {
		// Get numbers after _C until end or non-number
		num := ""

		for i := idx + 2; i < len(s); i++ {
			if s[i] < '0' || s[i] > '9' {
				break
			}

			num += string(s[i])
		}

		return utils.ConvertToInt(num, -1)
	}

	return -1
}

// Time will convert _v_ from a string, int or float to a time.Time object.
//
// .Valid Flags
// - "-tz <tz>" - Set the timezone to use. Default is the current system timezone.
// - "-unix <s|ms|ns>" - The value is a unix second,millisecond or nanosecond timestamp. Default is _s_ of omitted (not always needed).
//
// When the time is a `string`, it will try to parse it using _RFC3339_ format. If
// it is a integer or float it will try use it as a unix timestamp.
//
// If the value is a `time.Time` or `*time.Time` it will return the value as is. If `time.Time.IsZero()` it failed.
//
// If _v_ is a string an "$now", it will return the current time in the timezone.
func Time(v any, flags ...string) time.Time {
	if v == nil {
		return time.Time{}
	}

	var (
		tz   string
		unix string
	)

	for _, flag := range flags {
		if strings.HasPrefix(flag, "-tz") {
			tz = strings.TrimSpace(strings.TrimPrefix(flag, "-tz"))
		}

		if strings.HasPrefix(flag, "-unix") {
			unix = strings.TrimSpace(strings.TrimPrefix(flag, "-unix"))
		}
	}

	if tz == "" {
		tz = time.Now().Location().String()
	}

	if unix == "" {
		unix = "s"
	}

	digits := func(s string) bool {
		for i := 0; i < len(s); i++ {
			if s[i] < '0' || s[i] > '9' {
				return false
			}
		}
		return true
	}

	if s, ok := v.(string); ok {
		if s == "$now" {
			return time.Now().In(time.FixedZone(tz, 0))
		}

		if digits(s) {
			v, _ = strconv.ParseInt(s, 10, 64)
		}
	}

	switch t := v.(type) {
	case time.Time:
		return t
	case *time.Time:
		return *t
	case string:
		if t, err := timeutils.ParseDateTime(t); err == nil {
			return t
		} else {
			return time.Time{}
		}
	case int:
		v = int64(t)
	case int32:
		v = int64(t)
	case float64:
		v = int64(t)
	case float32:
		v = int64(t)
	}

	if n, ok := v.(int64); ok {
		switch unix {
		case "s":
			return time.Unix(n, 0).In(time.FixedZone(tz, 0))
		case "ms":
			return time.Unix(n/1e3, (n%1e3)*1e6).In(time.FixedZone(tz, 0))
		case "ns":
			return time.Unix(n/1e9, n%1e9).In(time.FixedZone(tz, 0))
		}
	}

	return time.Time{}
}
