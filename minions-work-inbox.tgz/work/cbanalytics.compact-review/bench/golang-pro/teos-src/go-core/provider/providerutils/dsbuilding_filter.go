package providerutils

import (
	"encoding/json"
	"time"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/reportmodel"
)

// filterUsingDeviceShadow will filter out sensors that have older or equal timestamp as in the device shadow.
//
// If the diff between remote timestamp and current os time are greater than _secondsDiff_ it will
// log an entry in order for the system to detect that a sensor value is getting *very* old.
// If set to zero or negative, it will discarded.
func filterUsingDeviceShadow(context ifcore.CbContext,
	checker *PolicyTimeStampChecker,
	lid string,
	ds *dsmodel.DsBuilding,
	dm *mgriot.DSManager,
) cberror.Error {
	// Get the device shadow to compare against
	if dm.GetShadowState().Error() != nil {
		return cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToLoadBuildingShadow, dm.Error(),
			"Failed to load the ds  for building: '%s' error: %s",
			lid, dm.Error())
	}

	var building dsmodel.DsFullBuilding
	if err := json.Unmarshal(dm.ReceivedStatePayload(), &building); err != nil {
		return cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToCreateBuildingFromShadow, dm.Error(),
			"Failed create dsBuilding from device shadow: building  for building: '%s' error: %s",
			lid, err.Error())
	}

	if l, ok := logger.ClsLog(
		zerolog.TraceLevel, "ReportDsBuilding", logger.LDTDevOps, logger.LISUnclassified, context,
	); ok {
		logger.LogObjectf(
			l,
			"body",
			dm.ReceivedStatePayload(),
			"Fetched device shadow for building %s to compare timestamps from remote endpoint",
			lid,
		)
	}

	body := &reportmodel.DataPointThresholdReport{
		TotalCount: len(ds.Sensors),
		Dropped:    map[string]*reportmodel.DataPointThresholdItem{},
		Reported:   map[string]*reportmodel.DataPointThresholdItem{},
	}

	emit := false
	dropCount := 0
	reportCount := 0

	// deviceShadowTimeStampExtractor prefers sensorts over metadata timestamps
	// since it preserves the device timestamp whereas the metadata timestamp
	// is when the value was recieved by _TEOS_.
	deviceShadowTimeStampExtractor := func(sensorID string) (coremodel.CbTime32, TimeStampType, bool) {

		if building.State != nil && building.State.Reported != nil &&
			len(building.State.Reported.SensorTimestamps) > 0 {
			if ts, ok := building.State.Reported.SensorTimestamps[sensorID]; ok {
				return ts, TimeStampDeviceShadowPreservedRemoteTimeStamp, true
			}
		}

		if building.Metadata != nil && building.Metadata.Reported != nil {
			if ts, ok := building.Metadata.Reported.Sensors[sensorID]; ok {
				return ts.Timestamp, TimeStampDeviceShadow, true
			}
		}

		return coremodel.CbTime32{}, TimeStampIllegal, false
	}

	// Iterate sensors and check if they should be dropped/reported or not
	for sensorID := range ds.Sensors {
		if sensorTimeStamp, ok := ds.SensorTimestamps[sensorID]; ok {
			if deviceShadowTimeStamp, tsType, ok := deviceShadowTimeStampExtractor(sensorID); ok {
				dropped, reported := checkDeleteAndReport(
					context,
					checker,
					sensorID,
					lid,
					ds,
					deviceShadowTimeStamp,
					tsType,
					sensorTimeStamp,
				)

				if dropped != nil {
					dropCount++
					emit = true
					body.Dropped[sensorID] = dropped

				}
				if reported != nil {
					reportCount++
					emit = true
					body.Reported[sensorID] = reported
				}
			}
		}
	}

	if emit {
		body.AllDropped = dropCount == body.TotalCount && dropCount > 0
		body.CountDropped = dropCount
		body.AllReported = reportCount == body.TotalCount && reportCount > 0
		body.CountReported = reportCount

		log.InfoWithLocationID(context, lid).
			WithMethod(string(reportmodel.ReportTypeDataPointThresholdReport)).
			WithBody(body).
			Msgf("DeviceShadow Compare timeout breached")
	}

	return nil
}

func checkDeleteAndReport(
	context ifcore.CbContext,
	checker *PolicyTimeStampChecker,
	sensorID, lid string,
	ds *dsmodel.DsBuilding,
	cbTimeStamp coremodel.CbTime32,
	cbTimeStampType TimeStampType,
	remoteSensorTimeStamp coremodel.CbTime32,
) (
	dropped *reportmodel.DataPointThresholdItem,
	reported *reportmodel.DataPointThresholdItem,
) {
	// handle remote preservation of timestamp
	remoteTimeStampPreserved := cbTimeStampType == TimeStampDeviceShadowPreservedRemoteTimeStamp

	drop, report, ts := checker.Check(
		sensorID,
		remoteSensorTimeStamp,
		cbTimeStamp,
		remoteTimeStampPreserved,
	)

	if drop || report {
		if log.IsEnabledWithLocationID(zerolog.DebugLevel, lid) {
			l := log.DebugWithLocationID(context, lid).
				WithMethod("SensorReportDropItem").
				WithDataType(logger.LDTDeveloper).
				Str("sensor", sensorID).
				Str("cb-timestamp", cbTimeStamp.RFC3339()).
				Str("cb-stamp-type", string(cbTimeStampType)).
				Str("remote-timestamp", remoteSensorTimeStamp.RFC3339())

			if drop {
				l.Int64("drop-offset", ts.Drop).
					Str("remotets-with-drop-offset", remoteSensorTimeStamp.Add(
						time.Second*time.Duration(ts.Drop)).RFC3339())
			}

			if report {
				l.Int64("report-offset", ts.Drop).
					Str("remotets-with-report-offset", remoteSensorTimeStamp.Add(
						time.Second*time.Duration(ts.Drop)).RFC3339())
			}

			l.Msgf(
				"Timestamp (type: %s) on Thiink Energy OS is same or newer than remote timestamp + drop|report offset.",
				string(cbTimeStampType),
			)
		}
	}

	var diff int64
	if remoteTimeStampPreserved {
		// Since remote timestamp is preserved, we need to calculate the difference
		// using the local timestamp - otherwise it will always be 0
		diff = coremodel.NewTime32Now().CbTime32UTC().Unix() - remoteSensorTimeStamp.Unix()
	} else {
		diff = cbTimeStamp.Unix() - remoteSensorTimeStamp.Unix()
	}

	if drop {
		// Remove sensor since older or equal in deviceshadow or local time
		delete(ds.Sensors, sensorID)
		// Delete the `sensorts` if present
		delete(ds.SensorTimestamps, sensorID)

		// Set drop reason based on if preservation of remote timestamp is enabled or not
		drop_reason := reportmodel.DataPointReportReasonTime
		if remoteTimeStampPreserved {
			drop_reason = reportmodel.DataPointReportReasonNotNewer
		}

		dropped = &reportmodel.DataPointThresholdItem{
			Timestamp: remoteSensorTimeStamp.Unix(),
			DateTime:  remoteSensorTimeStamp.RFC3339(),
			Diff:      diff,
			Limit:     ts.Drop,
			Reason:    drop_reason,
			Action:    reportmodel.DataPointActionDrop,
		}
	}

	if report {
		reported = &reportmodel.DataPointThresholdItem{
			Timestamp: remoteSensorTimeStamp.Unix(),
			DateTime:  remoteSensorTimeStamp.RFC3339(),
			Diff:      diff,
			Limit:     ts.Report,
			Reason:    reportmodel.DataPointReportReasonTime,
			Action:    reportmodel.DataPointActionReport,
		}
	}

	return
}

func filterUsingLocalTimestamps(
	context ifcore.CbContext,
	checker *PolicyTimeStampChecker,
	ds *dsmodel.DsBuilding,
	lid string) {
	body := &reportmodel.DataPointThresholdReport{
		TotalCount: len(ds.Sensors),
		Dropped:    map[string]*reportmodel.DataPointThresholdItem{},
		Reported:   map[string]*reportmodel.DataPointThresholdItem{},
	}

	now := coremodel.NewTime32Now().CbTime32UTC()
	emit := false
	dropCount := 0
	reportCount := 0
	for sensorID := range ds.Sensors {
		if sensorTimeStamp, ok := ds.SensorTimestamps[sensorID]; ok {
			dropped, reported := checkDeleteAndReport(
				context,
				checker,
				sensorID,
				lid,
				ds,
				now,
				TimeStampLocal,
				sensorTimeStamp,
			)

			if dropped != nil {
				dropCount++
				emit = true
				body.Dropped[sensorID] = dropped
			}
			if reported != nil {
				reportCount++
				emit = true
				body.Reported[sensorID] = reported
			}
		}
	}

	if emit {
		body.AllDropped = dropCount == body.TotalCount && dropCount > 0
		body.CountDropped = dropCount
		body.AllReported = reportCount == body.TotalCount && reportCount > 0
		body.CountReported = reportCount

		log.InfoWithLocationID(context, lid).
			WithMethod(string(reportmodel.ReportTypeDataPointThresholdReport)).
			WithBody(body).
			Msgf("Local TimeStamp Check breached")
	}
}
