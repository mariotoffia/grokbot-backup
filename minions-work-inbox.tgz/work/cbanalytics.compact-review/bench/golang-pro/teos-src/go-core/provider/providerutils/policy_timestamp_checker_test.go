package providerutils

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

func TestPolicyDoubleAsteriskMatchesAnyExpression(t *testing.T) {
	data := []byte(`{
		"range": {"IDT**": [-100, 100], "ODT**": [20, 200]},
		"ts": {"IDT**": { "drop": 3600, "report": 14400}, "ODT": {"drop": 43200, "report": 21600} },
		"report": ["ODT", "IDT_O3**"],
		"skip": ["IDT", "IDT_**"]
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	drop, report, ts := checker.Check("IDT_C1_O1",
		coremodel.NewTime32Now().Add(-3800*time.Second),
		*coremodel.NewZeroTime32(),
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, false, report)
	assert.Equal(t, int64(3600), ts.Drop)
	assert.Equal(t, int64(14400), ts.Report)

	drop, report, _ = checker.Check("IDT_C1_O1_ZMyZone",
		coremodel.NewTime32Now().Add(-15000*time.Second),
		*coremodel.NewZeroTime32(),
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, true, report)

	drop, report, _ = checker.Check("IDT_O1",
		coremodel.NewTime32Now().Add(-100*time.Second),
		*coremodel.NewZeroTime32(),
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, false, drop)
	assert.Equal(t, false, report)

	local := coremodel.NewTime32Now()
	drop, report, _ = checker.Check("IDT",
		*local,
		*local,
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, false, drop)
	assert.Equal(t, false, report)
}

func TestPolicyDoubleWildcardIsCatchAll(t *testing.T) {
	data := []byte(`{
		"ts": {"IDT**": { "drop": 3600, "report": 14400}, "**": {"drop": 43200, "report": 68000} }
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	drop, report, ts := checker.Check("IDT_C1_O1",
		coremodel.NewTime32Now().Add(-3800*time.Second),
		*coremodel.NewZeroTime32(),
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, false, report)
	assert.Equal(t, int64(3600), ts.Drop)
	assert.Equal(t, int64(14400), ts.Report)

	drop, report, ts = checker.Check("AEUPS_C1_O1",
		coremodel.NewTime32Now().Add(-44000*time.Second),
		*coremodel.NewZeroTime32(),
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, false, report)
	assert.Equal(t, int64(43200), ts.Drop)
	assert.Equal(t, int64(68000), ts.Report)

}

func TestPolicyReportButNotDropped(t *testing.T) {
	data := []byte(`{
		"ts": {"IDT**": { "drop": 14400, "report": 3600} }
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	drop, report, ts := checker.Check("IDT_C1_O1",
		coremodel.NewTime32Now().Add(-3800*time.Second),
		*coremodel.NewZeroTime32(),
		false, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, false, drop)
	assert.Equal(t, true, report)
	assert.Equal(t, int64(14400), ts.Drop)
	assert.Equal(t, int64(3600), ts.Report)
}

// TestPreserveRemoteTimeStampWillAlwaysDropIfEqual tests
// that if a remote timestamp is checked and it is equal to
// the local timestamp, it will always be dropped.
//
// This is when _TEOS_ is used to preserve the original device timestamp.
//
// Drop offset in config is always ignored.
func TestPreserveRemoteTimeStampWillAlwaysDropIfEqual(t *testing.T) {
	data := []byte(`{
		"ts": {"IDT**": { "drop": 14400, "report": 3600} }
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	now := *coremodel.NewTime32Now()
	drop, report, _ := checker.Check("IDT_C1_O1",
		now,  /*remoteSensor*/
		now,  /*cbTimeStamp*/
		true, /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, false, report)
}

func TestPreserveRemoteTimeStampWillAlwaysDropIfLess(t *testing.T) {
	data := []byte(`{
		"ts": {"IDT**": { "drop": 14400, "report": 3600} }
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	now := *coremodel.NewTime32Now()
	drop, report, _ := checker.Check("IDT_C1_O1",
		now.Add(-1*time.Second), /*remoteSensor*/
		now,                     /*cbTimeStamp*/
		true,                    /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, false, report)
}

func TestPreserveRemoteTimeStampWillNotDropIfNewer(t *testing.T) {
	data := []byte(`{
		"ts": {"IDT**": { "drop": 14400, "report": 3600} }
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	now := *coremodel.NewTime32Now()
	drop, report, _ := checker.Check("IDT_C1_O1",
		now.Add(1*time.Second), /*remoteSensor*/
		now,                    /*cbTimeStamp*/
		true,                   /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, false, drop)
	assert.Equal(t, false, report)
}

func TestPreserveRemoteTimeStampWillAdhereToReportFromLocalTimeStamp(t *testing.T) {
	data := []byte(`{
		"ts": {"IDT**": { "drop": 14400, "report": 3600} }
	}`)

	checker, err := NewPolicyTimeStampChecker("test", data)
	assert.Equal(t, nil, err)
	assert.Equal(t, "test", checker.id)

	now := *coremodel.NewTime32Now()
	drop, report, ts := checker.Check("IDT_C1_O1",
		now.Add(-3601*time.Second), /*remoteSensor*/
		now.Add(-3601*time.Second), /*cbTimeStamp*/
		true,                       /*remoteTimeStampPreserved*/
	)

	assert.Equal(t, true, drop)
	assert.Equal(t, true, report)
	assert.Equal(t, int64(14400), ts.Drop)
	assert.Equal(t, int64(3600), ts.Report)
}
