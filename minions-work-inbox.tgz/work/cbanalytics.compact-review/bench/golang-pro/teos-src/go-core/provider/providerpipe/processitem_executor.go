package providerpipe

import (
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	cbutils "github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/procutils"
)

// ProcessItemExecutorImpl will execute a single `providermodel.ProcessItemImpl`.
type ProcessItemExecutorImpl struct {
	item *providermodel.ProcessItemImpl
	// currentProfile is the profile that is used for resolving local profiles and
	// other references.
	rootProfile ifprovider.ConfigFull
	// currentProfile is the current profile used for the execution.
	//
	// NOTE: This is `nil` when only the `rootProfile` is used.
	currentProfile          ifprovider.ConfigFull
	pipeline                *ProviderPipelineImpl
	allowMutateGlobalParams bool
}

// IterationExecutionResult is the result of a single iteration.
type IterationExecutionResult struct {
	// Exports is the variables that are exported from the process item.
	Exports map[string]any
	// Result is the result of the pipe pipe execution (target).
	Result map[string]any
	// Error denotes that an error has occurred.
	Error cberror.Error
	// Operation is the operation that was executed in this iteration.
	Operation locationmodel.ProviderOperation
}

// IterationExecutionResults is a slice of `IterationExecutionResult`.
type IterationExecutionResults []*IterationExecutionResult

// HasResults returns true if the array is not `nil` and not _empty_.
func (results IterationExecutionResults) HasResults() bool {
	return len(results) > 0
}

// HasError returns true if any of the results has an error.
func (results IterationExecutionResults) HasError() bool {
	for _, result := range results {
		if result.Error != nil {
			return true
		}
	}
	return false
}

// ForOperation returns all results that matches the given operation.
func (results IterationExecutionResults) ForOperation(
	operation locationmodel.ProviderOperation,
) IterationExecutionResults {
	var filteredResults IterationExecutionResults
	for _, result := range results {
		if result.Operation == operation {
			filteredResults = append(filteredResults, result)
		}
	}

	return filteredResults
}

// GetErrors returns a slice of errors from the results. It will only
// return errors that are not nil and hence may be different length
// than the _results_ parameter. When no error - it is `nil`.
func (results IterationExecutionResults) GetErrors() []cberror.Error {
	var errors []cberror.Error
	for _, result := range results {
		if result.Error != nil {
			errors = append(errors, result.Error)
		}
	}

	return errors
}

// GetCompositeError will return a `CompositeError` if any of the results
// has an error. If no error - it will return `nil`.
//
// CAUTION: If only one error is present, it will return that error.
func (results IterationExecutionResults) GetCompositeError() cberror.Error {
	if !results.HasError() {
		return nil
	}

	errors := results.GetErrors()

	if len(errors) == 1 {
		return errors[0]
	}

	return cberror.NewCbCompositeErrorf(
		errors[0].Service(),
		1, cberror.FromCbErrorsToErrors(errors),
		map[string]any{
			cberror.PropertyProvider: results[0].Error.Service(),
		},
		"Multiple Errors, check the errors for more details")
}

// NewProcessItemExecutorImpl creates a new `ProcessExecutorImpl`.
//
// When _parallelThreshold_ is set to something above 0, it will execute the
// iterations in parallel if the number of iterations is above the threshold.
// If set to 0, it will *never* execute in parallel. The _batchSize_ is the
// amount of iterations to execute in parallel. If set to below 1, it will use the
// default batch size of 5.
//
// The _timeout_ is the timeout, in seconds, for the batcher to cancel the execution.
// If set to zero, the default timeout is 30 seconds.
//
// NOTE: The _requestor_ is mandatory since it is used to execute the iterations and will
// `panic` if not provided.
//
// The _currentProfile_ is used to resolve local profiles and other local references. All other
// references are resolved using the _repository_.
//
// The _requestor_ is used when a new `ProviderPipeExecutorImpl` is needed in order to execute.
func NewProcessItemExecutorImpl( /*  NOSONAR */
	ctx ifcore.CbContext,
	pipeline *ProviderPipelineImpl,
	item *providermodel.ProcessItemImpl,
	rootProfile ifprovider.ConfigFull,
	currentProfile ifprovider.ConfigFull,
	allowMutateGlobalParams bool,
) *ProcessItemExecutorImpl {

	if pipeline.batchSize < 1 {
		pipeline.batchSize = 5
	}

	if pipeline.parallelThreshold < 1 {
		pipeline.parallelThreshold = 0
	}

	if pipeline.timeout == 0 {
		pipeline.timeout = 30 * time.Second
	}

	if pipeline.pipeExecutorCreatorFunc == nil {
		panic("requestor is mandatory")
	}

	return &ProcessItemExecutorImpl{
		item:                    item,
		pipeline:                pipeline,
		rootProfile:             rootProfile,
		currentProfile:          currentProfile,
		allowMutateGlobalParams: allowMutateGlobalParams,
	}
}

// Execute will execute all iterations (based on the input) for this single process item.
//
// NOTE: It will not execute nested process items. This has to be done by the _caller_!
//
// If any data from another run or base setup from static profile is needed will be
// passed in the _data_ argument. Those are needed in order to resolve the input.
//
// Depending on how the `ProcessItemExecutorImpl` is configured, the iterations will be
// executed in parallel or sequentially.
//
// NOTE: It will always execute on same thread if only one iteration is encountered.
//
// The returned array is has the length of the executed iterations. Use the _Error_ field
// to determine if there was an error.
func (pe *ProcessItemExecutorImpl) Execute(
	ctx ifcore.CbContext,
	data map[string]any) IterationExecutionResults {
	// Enumerate the input
	enumerator := utils.NewInputEnumeratorImpl(ctx, pe.item.In).Resolve(data)

	if enumerator.Error() != nil {
		return IterationExecutionResults{{Error: enumerator.Error()}}
	}

	resolver := providerconfig.NewProfileResolver(pe.pipeline.repository)

	if pe.pipeline.parallelThreshold > 0 && enumerator.Count() >= pe.pipeline.parallelThreshold {
		return pe.executeParallel(ctx, resolver, enumerator, data)
	}

	// Execute on same thread
	var results IterationExecutionResults

	for {
		input, ok := enumerator.Next()

		if !ok {
			break
		}

		// Always set the base profile as the current (for local resolve).
		input[ifprovider.PipeContextKeyProviderConfig] = pe.rootProfile

		res := pe.executeProcessItem(ctx, resolver, input)
		results = append(results, res...)
	}

	return results
}

// executeParallel is same as `Execute` but will execute all iterations in parallel.
//
// NOTE: This should *never* be directly called, unless you know what you are doing. It
// is called automatically by `Execute` if _batchSize > 1_ is set.
func (pe *ProcessItemExecutorImpl) executeParallel(
	ctx ifcore.CbContext,
	resolver *providerconfig.ProfileResolverImpl,
	enumerator *utils.InputEnumeratorImpl,
	data map[string]any,
) IterationExecutionResults {
	// Execute in parallel
	count := enumerator.Count()

	results := procutils.ParallelizerWithItemFunc(
		ctx,
		pe.pipeline.batchSize,
		pe.pipeline.timeout,
		count,
		func(idx int) map[string]any {
			args, _ := enumerator.Next()
			return args
		},
		func(c ifcore.CbContext, idx int, item map[string]any) (IterationExecutionResults, cberror.Error) {
			// Execute in thread
			if item == nil {
				return nil, cberror.NewCbErrorfWithProps(
					ctx.Service(), 1, nil,
					map[string]any{"pn": ctx.Provider()},
					"No input for index %d", idx,
				)
			}

			// Always set the base profile as the current (for local resolve).
			item[ifprovider.PipeContextKeyProviderConfig] = pe.rootProfile

			return pe.executeProcessItem(ctx, resolver, item), nil
		},
	)

	var res IterationExecutionResults //nolint:prealloc // length unknown at declaration time

	for i := range results {
		res = append(res, results[i].Result...)
	}

	return res
}

// executeProcessItem will actually execute the process item based on the
// provided _args_. If no profile section is found, it will clone the
// current profile and use that.
func (pe *ProcessItemExecutorImpl) executeProcessItem(
	ctx ifcore.CbContext,
	resolver *providerconfig.ProfileResolverImpl,
	args map[string]any,
) IterationExecutionResults {
	// Check if profile section is set
	var pc *providermodel.ProviderConfigImpl

	if len(pe.item.Profile) == 0 {
		// Use current (if currentProfile is set - prefer that)
		if pe.currentProfile != nil {
			pc = utils.ToProviderConfigImpl(pe.currentProfile).Clone()
		} else {
			pc = utils.ToProviderConfigImpl(pe.rootProfile).Clone()
		}
	} else {
		// Get the profile expression
		profileExpression, err := resolver.ChooseProfile(ctx, pe.item.Profile, args)

		if err != nil {
			return []*IterationExecutionResult{{Error: err}}
		}

		// No Expression was resolved?
		if profileExpression == "" {
			return []*IterationExecutionResult{{Error: cberror.NewCbErrorfWithProps(
				ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
				"Failed to choose profile",
			)}}
		}

		var resolved ifprovider.ConfigFull
		resolved, err = resolver.ResolveClonedProfileAndReferences(
			ctx, profileExpression, args, false, /*overwrite*/
		)

		if err != nil {
			return []*IterationExecutionResult{{Error: err}}
		}

		pc = utils.ToProviderConfigImpl(resolved)
	}

	// Do we have a nested profile process?
	if pe.currentProfile == nil && len(pc.Process) > 0 {
		var results IterationExecutionResults
		for i := range pc.Process {
			executor := NewProcessItemExecutorImpl(
				ctx,
				pe.pipeline,
				pc.Process[i],
				pe.rootProfile,
				pc, /*currentProfile*/
				pe.allowMutateGlobalParams,
			)

			res := executor.Execute(ctx, args)
			if len(res) > 0 {
				results = append(results, res...)
			}
		}

		return results
	}

	// Set the current profile (since it has been changed/cloned)
	args[ifprovider.PipeContextKeyProviderConfig] = pc
	// No Process - run it inside this item.

	// Run any filter expressions
	if len(pe.item.Filter) > 0 {
		resolver, err := providerconfig.NewFilterResolver(ctx, pe.item.Filter)
		if err != nil {
			return []*IterationExecutionResult{{Error: err}}
		}

		if _, ok := args["map"]; !ok {
			args["map"] = pc.Map
		}

		filter, err := resolver.ProcessFilter(ctx, args)
		if err != nil {
			return []*IterationExecutionResult{{Error: err}}
		}

		if mid, ok := filter[string(ifprovider.ParameterMappingIDs)]; ok {
			if mid, ok := mid.(string); ok {
				pc.Params[string(ifprovider.ParameterMappingIDs)] = mid
			}
		}

		if mapping, ok := filter["map"]; ok {
			if mapping, ok := mapping.(map[string]string); ok {
				pc.Map = mapping
				// Allow for export the map as well (MID and others are exportable when running pipe)
				args["map"] = mapping
			}
		}
	}

	// Filter map from MID global param
	merger := providerconfig.ProfileMerger(0)
	pc.Map = merger.FilterMappingSection(false /*all*/, pc.Map, merger.EnabledSensorMappings(pc))

	// Get the operation to execute
	operation, ok := pc.GetParamAsString(string(ifprovider.ParameterOperation))
	if !ok {
		return []*IterationExecutionResult{{Error: cberror.NewCbErrorfWithProps(
			ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
			"Failed to get operation from profile: %s", pc.Profile,
		)}}
	}

	// Execute the pipe
	executor, err := pe.pipeline.pipeExecutorCreatorFunc(
		ctx,
		pe.pipeline,
		operation,
		args,
		pc,
		pe.allowMutateGlobalParams,
	)

	if err != nil {
		return []*IterationExecutionResult{
			{Error: err, Operation: locationmodel.ProviderOperation(operation)},
		}
	}

	executor.Execute()

	if executor.Error() != nil {
		return []*IterationExecutionResult{
			{Error: executor.Error(), Operation: locationmodel.ProviderOperation(operation)},
		}
	}

	var result map[string]any
	var export map[string]any

	if executor.HasGetResult() {
		result = executor.GetResult()
	}

	// Export the result
	if len(pe.item.Export) > 0 {
		exporter := providerconfig.NewExportResolver(ctx, pe.item.Export)
		export, err = exporter.ProcessExports(ctx, cbutils.ShallowCopyMap(args, result))
	}

	return []*IterationExecutionResult{
		{
			Result:    result,
			Exports:   export,
			Error:     err,
			Operation: locationmodel.ProviderOperation(operation),
		},
	}
}
