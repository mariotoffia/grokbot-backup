package providerconfig

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// cSpell: disable

func TestCreateGeneratorTemplateFromGeneratorPrototypesNoMID_PR_GPID_GPID(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "true"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}].Value",
			"IDT_O1": `generate["IDT_O1"].Value`,
			"*":      "float64(generate[{{ID}}].Value)",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"*": "generate[{{ID}}].TimeStamp",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}, "sensorts": {{GENPROTO_TS}}`,
	}

	result, _, err := CreateGeneratorTemplate(
		newCtx(t),
		&pc,
		"sv",
		"sv",
		true, /*log*/
		map[string]any{},
	)

	assert.Equal(t, nil, err)
	assert.Equal(t, strings.Index(result, "{{GENPROTO}}"), -1)
	assert.Equal(t, strings.Index(result, "{{GENPROTO_TS}}"), -1)
	assert.NotEqual(t, strings.Index(result, "generate[IDT].Value"), -1)
	assert.NotEqual(t, strings.Index(result, "generate[IDT].TimeStamp"), -1)
}

func TestCreateGeneratorTemplateFromGeneratorObjectsOnlyPrototypesOutboundProvider(t *testing.T) {
	pc := genProviderConfig()

	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "true"
	pc.Params[string(ifprovider.ParameterMappingIDs)] = "IDT IDT_O1 IDT_O2 OFFODT"

	pc.Map["IDT_O1"] = "Room temp.1"
	pc.Map["IDT_O2"] = "Room temp.2"
	pc.Map["OFFODT"] = "Outside temp.offset"

	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"esv": {
			"-IDT":    `{"n": PID+";{{:ID}}", "v": generate["Room temp.most-narrow"].Value}`,
			"-IDT_O1": `{"n": PID+";{{:ID}}", "v": generate["can.use-{{ID}}"].Value}`,
			"-*":      `{"n": PID+";{{:ID}}", "v": generate["{{:ID}}"].Value}`,
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"esv": `{ "values": [{{GENPROTO}}] }`,
	}

	result, _, err := CreateGeneratorTemplate(
		newCtx(t),
		&pc,
		"esv",
		"esv",
		true, /*log*/
		map[string]any{},
	)

	assert.Equal(t, nil, err)
	assert.Equal(t, strings.Index(result, "{{GENPROTO}}"), -1)
	assert.NotEqual(t, strings.Index(result, `generate["Room temp.most-narrow"].Value`), -1)
	assert.NotEqual(t, strings.Index(result, `generate["can.use-IDT_O1"].Value`), -1)
	assert.NotEqual(t, strings.Index(result, `generate["Outside temp.offset"].Value`), -1)

	assert.NotEqual(t, strings.Index(result, `"n": PID+";Room temp.comf.",`), -1)
	assert.NotEqual(t, strings.Index(result, `"n": PID+";Outside temp.offset",`), -1)
	assert.NotEqual(t, strings.Index(result, `"n": PID+";Room temp.1",`), -1)
	assert.NotEqual(t, strings.Index(result, `"n": PID+";Room temp.2",`), -1)

	assert.Equal(
		t,
		strings.Index(result, `generate["MY_IDT_O2"].Value`),
		-1,
		"Since this will fall into narrow IDT",
	)
}

func TestCreateGeneratorTemplateFromGeneratorMapKeyExpressionsOnlyPrototypesOutboundProvider(
	t *testing.T,
) {
	pc := genProviderConfig()

	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "true"
	pc.Params[string(ifprovider.ParameterMappingIDs)] = "IDT IDT_O1 IDT_O2 OFFODT"

	pc.Map["IDT_O1"] = "Room temp.1"
	pc.Map["IDT_O2"] = "Room temp.2"
	pc.Map["OFFODT"] = "Outside temp.offset"

	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"esv": {
			":OFFODT": `generate["but-can-do-this-{{ID}}"].Value`,
			":*":      `generate["{{:ID}}"].Value`,
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"esv": `{ {{GENPROTO}} }`,
	}

	result, _, err := CreateGeneratorTemplate(
		newCtx(t),
		&pc,
		"esv",
		"esv",
		true, /*log*/
		map[string]any{},
	)

	assert.Equal(t, nil, err)
	assert.Equal(t, strings.Index(result, "{{GENPROTO}}"), -1)

	assert.True(
		t,
		strings.Contains(result, `"Room temp.comf.": generate["Room temp.comf."].Value`),
	)

	assert.True(t, strings.Contains(result, `"Room temp.1": generate["Room temp.1"].Value`))
	assert.True(t, strings.Contains(result, `"Room temp.2": generate["Room temp.2"].Value`))

	assert.True(
		t,
		strings.Contains(
			result,
			`"Outside temp.offset": generate["but-can-do-this-OFFODT"].Value`,
		),
	)
}

func BenchmarkCreateGeneratorTemplateFromGeneratorPrototypesNoMID_PR_GPID_GPID(t *testing.B) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "true"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}].Value",
			"IDT_O1": `generate["IDT_O1"].Value`,
			"*":      "float64(generate[{{ID}}].Value)",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"*": "generate[{{ID}}].TimeStamp",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}, "sensorts": {{GENPROTO_TS}}`,
	}

	for i := 0; i < t.N; i++ {
		_, _, _ = CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})
	}
}
