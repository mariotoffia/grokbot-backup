package providerutils

import (
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/interfaces/iftarget"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// GetDsFullBuildingTargets extracts all `iftarget.TargetDataTypeDsBuilding`
//
// If none is found, it will return the _defaultTarget_ if provided.
func GetDsFullBuildingTargets(
	pc *providermodel.ProviderConfigImpl,
	op *providermodel.Operation,
	defaultTarget *providermodel.Target,
) ([]providermodel.Target, error) {

	var trg string
	if op != nil {
		trg = op.GetParamAsStringWithDefault(string(ifprovider.ParameterTarget), "")
	}

	if trg != "" {
		trg = pc.GetParamAsStringWithDefault(string(ifprovider.ParameterTarget), "")
	}

	if trg == "" {
		if defaultTarget == nil {
			return nil, nil
		}

		return []providermodel.Target{*defaultTarget}, nil
	}

	// Filter all _dsbld_ and either not set target name or _ds_.
	return providermodel.ParseFilterTargetParameter(
		trg,
		string(iftarget.TargetDataTypeDsBuilding),
		"",
		string(iftarget.TargetTypeDeviceShadow),
	)
}
