package providerconfig

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// cSpell:disable
func TestExtractSensorFromMapping(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Map: map[string]string{
					"IDT": "1!6WHH6DKHICVDSS",
				},
			},
		},
	}

	sensors := pc.ExtractMappingSensors()
	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "IDT", sensors[0])

	mappedTo, _ := pc.GetMappedTo(sensors[0])
	assert.Equal(t, "1!6WHH6DKHICVDSS", mappedTo)

	oper := pc.GetOperation(string(locationmodel.ProviderOperationSensorValueIn))
	sensors = pc.ExtractSensors(oper)

	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "IDT", sensors[0])
}

func TestSensorsThatAreGlobbedOptional(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Params: map[string]interface{}{
					string(ifprovider.ParameterOptionalSensors): "IDT**",
				},
				Map: map[string]string{
					"IDT_O1": "1!6WHH6DKHICVDSS",
					"IDT_O2": "1!6WHH6DKHICVDS2",
					"ODT":    "1!6WHH6DKHICVDSA",
				},
			},
		},
	}

	sensors := pc.ExtractMappingSensors()
	assert.Equal(t, 3, len(sensors))

	optional, err := pc.GetOptionalSensors(nil /*operation*/, sensors)
	assert.Nil(t, err)
	assert.Equal(t, 2, len(optional))

}

func TestExtractSensorFromFilter(t *testing.T) {
	pc := providermodel.ProfileImpl{
		BaseProfile: providermodel.BaseProfile{
			Filter: map[string]string{
				"IDT": "1!6WHH6DKHICVDSS",
			},
		},
	}

	sensors := pc.ExtractFilterSensors()
	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "IDT", sensors[0])

	sensors = pc.ExtractSensors(
		pc.GetOperation(string(locationmodel.ProviderOperationSensorValueIn)),
	)
	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "IDT", sensors[0])

}

func TestExtractSensorFromOperation(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorIDs): "IDT ODTOFF",
						},
					},
				},
			},
		},
	}

	op := pc.Operation[string(locationmodel.ProviderOperationSensorValueIn)]
	sensors := (&op).ExtractOperationSensors()
	assert.Equal(t, 2, len(sensors))
	assert.Equal(t, "IDT", sensors[0])
	assert.Equal(t, "ODTOFF", sensors[1])

	sensors = pc.ExtractSensors(
		pc.GetOperation(string(locationmodel.ProviderOperationSensorValueIn)),
	)
	assert.Equal(t, 2, len(sensors))
	assert.Equal(t, "IDT", sensors[0])
	assert.Equal(t, "ODTOFF", sensors[1])
}

func TestNonExistantOperationReturnsZeroSensors(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorIDs): "IDT ODTOFF",
						},
					},
				},
			},
		},
	}

	sensors := pc.ExtractSensors(
		pc.GetOperation(string(locationmodel.ProviderOperationSensorValueOut)),
	)
	assert.Equal(t, 0, len(sensors))
}

func TestExtractSensorFromFilterMappingOperation(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Map: map[string]string{
					"IDT_O2": "1!6WHH6DKHICVDSS",
				},
				Filter: map[string]string{
					"IDT_O1": "1!6WHH6DKHICVDSA",
				},
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorIDs): "ODTOFF",
						},
					},
				},
			},
		},
	}

	sensors := pc.ExtractSensors(
		pc.GetOperation(string(locationmodel.ProviderOperationSensorValueIn)),
	)
	assert.Equal(t, 3, len(sensors))
	assert.Equal(t, "IDT_O1", sensors[0])
	assert.Equal(t, "IDT_O2", sensors[1])
	assert.Equal(t, "ODTOFF", sensors[2])

	sensors = pc.ExtractSensors(
		pc.GetOperation(string(locationmodel.ProviderOperationSensorValueIn)),
	)
	assert.Equal(t, 3, len(sensors))
	assert.Equal(t, "IDT_O1", sensors[0])
	assert.Equal(t, "IDT_O2", sensors[1])
	assert.Equal(t, "ODTOFF", sensors[2])

	mappedTo, _ := pc.GetMappedTo(sensors[0])
	assert.Equal(t, "", mappedTo)

	mappedTo, _ = pc.GetMappedTo(sensors[1])
	assert.Equal(t, "1!6WHH6DKHICVDSS", mappedTo)
}

func TestOverlappingIsFilterredOut(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Map: map[string]string{
					"IDT": "1!6WHH6DKHICVDSS",
				},
				Filter: map[string]string{
					"IDT": "1!6WHH6DKHICVDSA",
				},
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorIDs): "IDT",
						},
					},
				},
			},
		},
	}

	sensors := pc.ExtractSensors(
		pc.GetOperation(string(locationmodel.ProviderOperationSensorValueIn)),
	)
	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "IDT", sensors[0])
}

func TestGetLayersReturnsMappingLayerOnly(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorLayer): string(
								ifprovider.FilterExtractLayerMapping,
							),
						},
					},
				},
			},
		},
	}

	op := pc.Operation[string(locationmodel.ProviderOperationSensorValueIn)]
	layers := (&op).GetLayers()
	assert.Equal(t, 1, len(layers))
	assert.Equal(t, ifprovider.FilterExtractLayerMapping, layers[0])
}

func TestGetLayersReturnsMappingAndFilter(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorLayer): fmt.Sprintf(
								"%s,%s",
								ifprovider.FilterExtractLayerMapping,
								ifprovider.FilterExtractLayerFilter,
							),
						},
					},
				},
			},
		},
	}

	op := pc.Operation[string(locationmodel.ProviderOperationSensorValueIn)]
	layers := (&op).GetLayers()
	assert.Equal(t, 2, len(layers))
	assert.Equal(t, ifprovider.FilterExtractLayerMapping, layers[0])
	assert.Equal(t, ifprovider.FilterExtractLayerFilter, layers[1])
}

func TestGetLayersReturnsMappingAndOperationFilter(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorLayer): fmt.Sprintf(
								"%s,%s,%s",
								ifprovider.FilterExtractLayerMapping,
								ifprovider.FilterExtractLayerFilter,
								ifprovider.FilterExtractLayerOperation,
							),
						},
					},
				},
			},
		},
	}

	op := pc.Operation[string(locationmodel.ProviderOperationSensorValueIn)]
	layers := (&op).GetLayers()
	assert.Equal(t, 3, len(layers))
	assert.Equal(t, ifprovider.FilterExtractLayerMapping, layers[0])
	assert.Equal(t, ifprovider.FilterExtractLayerFilter, layers[1])
	assert.Equal(t, ifprovider.FilterExtractLayerOperation, layers[2])
}

func TestGetLayersReturnsMappingAndOperationFilterIfSLIsOmitted(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{},
					},
				},
			},
		},
	}

	op := pc.Operation[string(locationmodel.ProviderOperationSensorValueIn)]
	layers := (&op).GetLayers()
	assert.Equal(t, 3, len(layers))
	assert.Equal(t, ifprovider.FilterExtractLayerFilter, layers[0])
	assert.Equal(t, ifprovider.FilterExtractLayerMapping, layers[1])
	assert.Equal(t, ifprovider.FilterExtractLayerOperation, layers[2])
}

func TestGetLayersReturnsEmptyLayerArrayIfNoneSpecified(t *testing.T) {
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Operation: map[string]providermodel.Operation{
					string(locationmodel.ProviderOperationSensorValueIn): {
						Params: map[string]interface{}{
							string(ifprovider.ParameterSensorLayer): string(
								ifprovider.FilterExtractLayerNone,
							),
						},
					},
				},
			},
		},
	}

	op := pc.Operation[string(locationmodel.ProviderOperationSensorValueIn)]
	layers := (&op).GetLayers()
	assert.Equal(t, 0, len(layers))
}

// TestUnexpandedWildcardWithoutOPT verifies that an unexpanded wildcard pattern
// (e.g., HCT**) extracted from mapping is NOT optional when OPT is not set.
//
// Scenario:
// ─────────────────────────────────────────────────────────────────────────────
//
//	map: {"HCT**": "{{ID}}"}  +  OPT: <not set>  +  no source data
//	→ Extract sensors returns ["HCT**"]
//	→ GetOptionalSensors returns [] (none are optional)
//
// ─────────────────────────────────────────────────────────────────────────────
func TestUnexpandedWildcardWithoutOPT(t *testing.T) {
	// Config with wildcard mapping but NO OPT parameter
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Params: map[string]interface{}{
					// No OPT parameter set
				},
				Map: map[string]string{
					"HCT**": "{{ID}}", // Unexpanded wildcard pattern
				},
			},
		},
	}

	// Extract sensors - should include the unexpanded wildcard
	sensors := pc.ExtractMappingSensors()
	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "HCT**", sensors[0])

	// Without OPT, no sensors should be optional
	optional, err := pc.GetOptionalSensors(nil /*operation*/, sensors)
	assert.Nil(t, err)
	assert.Equal(t, 0, len(optional), "Without OPT, unexpanded wildcard should NOT be optional")
}

// TestUnexpandedWildcardWithOPTSuperGlob verifies that an unexpanded wildcard pattern
// (e.g., HCT**) is correctly marked as optional when OPT="**" is set.
//
// Scenario:
// ─────────────────────────────────────────────────────────────────────────────
//
//	map: {"HCT**": "{{ID}}"}  +  OPT: "**"  +  no source data
//	→ Extract sensors returns ["HCT**"]
//	→ GetOptionalSensors returns ["HCT**"] (glob ** matches literal HCT**)
//
// ─────────────────────────────────────────────────────────────────────────────
func TestUnexpandedWildcardWithOPTSuperGlob(t *testing.T) {
	// Config with wildcard mapping AND OPT="**" (super glob)
	pc := providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Params: map[string]interface{}{
					string(ifprovider.ParameterOptionalSensors): "**", // Super glob - all optional
				},
				Map: map[string]string{
					"HCT**": "{{ID}}", // Unexpanded wildcard pattern
				},
			},
		},
	}

	// Extract sensors - should include the unexpanded wildcard
	sensors := pc.ExtractMappingSensors()
	assert.Equal(t, 1, len(sensors))
	assert.Equal(t, "HCT**", sensors[0])

	// With OPT="**", the unexpanded HCT** should be marked as optional
	// because glob ** matches any string including "HCT**"
	optional, err := pc.GetOptionalSensors(nil /*operation*/, sensors)
	assert.Nil(t, err)
	assert.Equal(t, 1, len(optional), "With OPT='**', unexpanded wildcard SHOULD be optional")
	assert.Equal(t, "HCT**", optional[0])
}

//cSpell:enable
