package providerpipe

import (
	"container/list"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sync"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// This file holds the store of compiled pipelines that provider pipelines share.
//
// Compiling a pipeline reads its JSON, checks every step's settings and parses
// every expression. A provider runs the same pipeline over and over — once per
// collection, once per building — and the JSON is identical every time, so
// compiling it again on each run is work thrown away. A compiled pipeline never
// changes once built and can be run by many goroutines at once, so one can be
// kept and reused.
//
// The store lives here rather than in the pipeline library because it is the
// provider code that knows a pipeline will be run repeatedly. The library
// compiles when asked and keeps nothing.

// maxCachedPipelines is how many compiled pipelines are kept. Beyond this the one
// used longest ago is dropped.
//
// The number is a guess with a reason rather than a measurement. A provider
// installation has one pipeline per operation per configuration, and the largest
// in this repository has well under a hundred. Two hundred therefore holds
// everything a real installation compiles, while still being a fixed ceiling so
// that a caller generating pipelines in a loop cannot grow this without limit.
const maxCachedPipelines = 200

// pipelineCache keeps compiled pipelines, dropping the one used longest ago when
// it is full. It is safe to use from more than one goroutine.
type pipelineCache struct {
	mu      sync.Mutex
	entries map[string]*list.Element
	order   *list.List
}

type cacheEntry struct {
	key  string
	prog *cbpipeline.Program
}

func newPipelineCache() *pipelineCache {
	return &pipelineCache{
		entries: make(map[string]*list.Element, maxCachedPipelines),
		order:   list.New(),
	}
}

// compiledPipelines is the store every provider pipeline shares.
var compiledPipelines = newPipelineCache()

// cacheKey identifies one compiled pipeline.
//
// It is built from two things and needs both. The pipeline's text decides what
// the pipeline does. The set of step types decides what each step in that text
// means: the same text compiled against two different sets gives two different
// pipelines, and handing one caller the other's would run code it never asked
// for.
func cacheKey(reg *cbpipeline.Registry, text []byte) string {
	sum := sha256.Sum256(text)
	return fmt.Sprintf("%d:%s", reg.ID(), hex.EncodeToString(sum[:]))
}

// compilePipeline returns the compiled form of a pipeline, compiling it the first
// time and reusing it afterwards.
//
// A pipeline holding Go functions is never kept. Such a pipeline has no text to
// identify it, so two of them with identical steps and different functions would
// look the same to the store and either could be handed back. The provider code
// never builds one, and this check is what makes that impossible to get wrong
// later.
func compilePipeline(
	cbCtx ifcore.CbContext, reg *cbpipeline.Registry, text []byte,
) (*cbpipeline.Program, cberror.Error) {
	key := cacheKey(reg, text)

	if prog := compiledPipelines.get(key); prog != nil {
		return prog, nil
	}

	doc, err := cbpipeline.Read(cbCtx, text, cbpipeline.WithRegistry(reg))
	if err != nil {
		return nil, err
	}
	prog, err := cbpipeline.Compile(cbCtx, doc, reg)
	if err != nil {
		return nil, err
	}

	if !prog.HoldsGoFunctions() {
		compiledPipelines.put(key, prog)
	}
	return prog, nil
}

func (c *pipelineCache) get(key string) *cbpipeline.Program {
	c.mu.Lock()
	defer c.mu.Unlock()

	element, found := c.entries[key]
	if !found {
		return nil
	}
	c.order.MoveToFront(element)

	entry, ok := element.Value.(*cacheEntry)
	if !ok {
		return nil
	}
	return entry.prog
}

func (c *pipelineCache) put(key string, prog *cbpipeline.Program) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if element, found := c.entries[key]; found {
		c.order.MoveToFront(element)
		if entry, ok := element.Value.(*cacheEntry); ok {
			entry.prog = prog
		}
		return
	}

	c.entries[key] = c.order.PushFront(&cacheEntry{key: key, prog: prog})

	for c.order.Len() > maxCachedPipelines {
		oldest := c.order.Back()
		if oldest == nil {
			return
		}
		c.order.Remove(oldest)
		if entry, ok := oldest.Value.(*cacheEntry); ok {
			delete(c.entries, entry.key)
		}
	}
}
