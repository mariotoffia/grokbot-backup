package tests

import (
	"net/url"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

func TestExecutionOfImportPipe(t *testing.T) {
	conf := `{
	"profile": "generic",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Måssmyren 14", "PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TZ": "Europe/Stockholm" 
	},
	"map": { 
		"IDT": "1!6WHH75YIZH3STB", "SHCT_C1": "1!6WHH75YIXHSYVE", "SHCT_C2": "1!6WHH75YIRL4ZZI", 
		"ODT": "1!6WHH75YIU4NUCO" 
	}
}
--gen=sv
{   "tz": TZ,
	"sensors": {
		"IDT": float64(generate["IDT"].Value), "SHCT_C1": float64(generate["SHCT_C1"].Value),
		"SHCT_C2": float64(generate["SHCT_C2"].Value), "ODT": float64(generate["ODT"].Value)
	}
}`

	type Credentials struct {
		User     string `json:"user"     env:"CREDENTIALS_USER"`
		Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
		APIKey   string `json:"key"      env:"CREDENTIALS_KEY"`
	}
	type ClimatixIC struct {
		Endpoint    string      `json:"ep"          pms:"endpoint"                   env:"ENDPOINT"`
		Token       string      `json:"token"`
		Credentials Credentials `json:"credentials" pms:"credentials, keyid=default"`
	}

	// Build the provider pipe
	var operationCredentials *ClimatixIC
	var remoteID []string

	ctx := newCtx(t, zerolog.FatalLevel)

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &ClimatixIC{
					Endpoint: "api.climatixic.com",
					Token:    "a token from the auth (that did never take place here since unittest)",
					Credentials: Credentials{
						User:     "nisse@nordvestor.com",
						Password: "PassWord",
						APIKey:   "123-abc-123",
					}}, 3600 /*1h*/, nil
			}).
		UseVerifyConnectFunction(
			func(ctx ifcore.CbContext, cred string, credentials any, eop *providermodel.Operation) bool {
				if nil == credentials {
					return false
				}

				if c, ok := credentials.(*ClimatixIC); ok {
					if u, err := url.Parse(eop.Operation); err == nil {
						return u.Host == c.Endpoint
					}
				}

				return false
			}).
		UseSourceWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
				// Simulate call to remote endpoint
				operationCredentials = cred.(*ClimatixIC)
				remoteID = rid

				return []eqmodel.CbDataPoint{
					&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIZH3STB", Value: 22.0},
					&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIXHSYVE", Value: 89.0},
					&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIRL4ZZI", Value: 76.0},
					&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIU4NUCO", Value: -17.0},
				}, nil /*body*/, nil /*err*/
			}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	// Build the executor
	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	// Execute
	res := exec.Execute().GetResult()

	assert.Equal(t, nil, exec.Error())
	assert.NotNil(t, res)
	require.NotNil(t, operationCredentials)

	ds := res["target"].(*dsmodel.DsBuilding)
	assert.Equal(t, "nisse@nordvestor.com", operationCredentials.Credentials.User)
	assert.Equal(t, "PassWord", operationCredentials.Credentials.Password)
	assert.Equal(t, "123-abc-123", operationCredentials.Credentials.APIKey)
	assert.Equal(t, "api.climatixic.com", operationCredentials.Endpoint)
	assert.Equal(
		t,
		"a token from the auth (that did never take place here since unittest)",
		operationCredentials.Token,
	)
	assert.Equal(t, "Europe/Stockholm", ds.TimeZone)
	assert.Equal(t, float64(22.0), ds.Sensors["IDT"])
	assert.Equal(t, float64(89.0), ds.Sensors["SHCT_C1"])
	assert.Equal(t, float64(76.0), ds.Sensors["SHCT_C2"])
	assert.Equal(t, float64(-17.0), ds.Sensors["ODT"])

	// Check the remote ID is correct
	assert.Equal(t, 4, len(remoteID))
	assert.Contains(t, remoteID, "1!6WHH75YIZH3STB")
	assert.Contains(t, remoteID, "1!6WHH75YIXHSYVE")
	assert.Contains(t, remoteID, "1!6WHH75YIRL4ZZI")
	assert.Contains(t, remoteID, "1!6WHH75YIU4NUCO")
}

func TestExecutionWithMapSourceFunction(t *testing.T) {
	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Måssmyren 14", "PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TZ": "Europe/Stockholm" 
	},
	"map": { 
		"IDT": "1!N3ASTFSZHI2WD0F", "SHCT_C1": "1!N3ASTFSZH7ZS23P", "SHCT_C2": "1!6WHH6DKHICVDSS", 
		"ODT": "1!N3ASTG10KWTFCMU"
	}
}
--gen=sv
{   "tz": TZ,
	"sensors": {
		"IDT": float64(generate["IDT"].Value), "SHCT_C1": float64(generate["SHCT_C1"].Value),
		"SHCT_C2": float64(generate["SHCT_C2"].Value), "ODT": float64(generate["ODT"].Value)
	}
}`

	ctx := newCtx(t, zerolog.FatalLevel)

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600 /*1h*/, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				// Simulate call to remote endpoint
				return map[string]eqmodel.CbDataPoint{
					"1!N3ASTFSZHI2WD0F": &eqmodel.CbDataPointImpl{
						ID: "1!N3ASTFSZHI2WD0F", Value: 22.0,
					},
					"1!N3ASTFSZH7ZS23P": &eqmodel.CbDataPointImpl{
						ID: "1!N3ASTFSZH7ZS23P", Value: 89.0,
					},
					"1!6WHH6DKHICVDSS": &eqmodel.CbDataPointImpl{
						ID: "1!6WHH6DKHICVDSS", Value: 76.0,
					},
					"1!N3ASTG10KWTFCMU": &eqmodel.CbDataPointImpl{
						ID: "1!N3ASTG10KWTFCMU", Value: -17.0,
					},
				}, nil /*src*/, nil /*body*/, nil /*err*/
			}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	// Build the executor
	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	// Execute
	res := exec.Execute().GetResult()

	require.NoError(t, exec.Error())
	require.NotNil(t, res)

	ds := res["target"].(*dsmodel.DsBuilding)

	assert.Equal(t, "Europe/Stockholm", ds.TimeZone)
	assert.Equal(t, float64(22.0), ds.Sensors["IDT"])
	assert.Equal(t, float64(89.0), ds.Sensors["SHCT_C1"])
	assert.Equal(t, float64(76.0), ds.Sensors["SHCT_C2"])
	assert.Equal(t, float64(-17.0), ds.Sensors["ODT"])
}

func TestBrokenJSONShallLogUnderstandableMessage(t *testing.T) {
	// REP is broken since do not start with double quotes
	esvConfig := `{
	"profile": "generic",
	"prms": { 
		"CRD": "", "BID": "Måssmyren 18", REP": "api.climatixic.com", "PID": "P49b5721b-be72-4d56-9537-c98ad0ea2e1c", 
		"TID": "T1bc4a232-5924-4476-bcd7-dd53157e5657" 
	},
	"map": { "1!6WHH6DKHICVDSS": "OFFODT" }
}
--gen=esv
{ "list": [	{"n": PID + ";1!6WHH6DKH3CCVW-", "v": 1 }, {"n": PID + ";1!6WHH6DKHICVDSS", "v": float64(generate["1!6WHH6DKHICVDSS"])}	] }`

	ctx := newCtx(t, zerolog.FatalLevel)

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/log-understandable-messages/",
					),
				),
			).Build(),
	).
		UseMappingDirection(providermodel.MappingDirectionRightAssign).
		AsOperation(string(locationmodel.ProviderOperationSensorValueOut))

	// Build the executor & execute
	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(esvConfig)

	assert.True(t, exec.Error() != nil)
	assert.Contains(
		t,
		exec.Error().Error(),
		`Failed to unmarshal provider config: invalid character 'R' looking for beginning of object key string`,
	)
}

func BenchmarkBuildingAndExecutionOfImportPipe(t *testing.B) {
	conf := `{
	"profile": "generic",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Måssmyren 14", "PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TZ": "Europe/Stockholm" 
	},
	"map": { 
		"IDT": "1!6WHH75YIZH3STB", "SHCT_C1": "1!6WHH75YIXHSYVE", "SHCT_C2": "1!6WHH75YIRL4ZZI", 
		"ODT": "1!6WHH75YIU4NUCO" 
	}
}
--gen=sv
{   "tz": TZ,
	"sensors": {
		"IDT": float64(generate["IDT"].Value), "SHCT_C1": float64(generate["SHCT_C1"].Value),
		"SHCT_C2": float64(generate["SHCT_C2"].Value), "ODT": float64(generate["ODT"].Value)
	}
}`

	type Credentials struct {
		User     string `json:"user"     env:"CREDENTIALS_USER"`
		Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
		APIKey   string `json:"key"      env:"CREDENTIALS_KEY"`
	}
	type ClimatixIC struct {
		Endpoint    string      `json:"ep"          pms:"endpoint"                   env:"ENDPOINT"`
		Token       string      `json:"token"`
		Credentials Credentials `json:"credentials" pms:"credentials, keyid=default"`
	}

	ctx := newCtx(t, zerolog.FatalLevel)

	creds := &ClimatixIC{
		Endpoint: "api.climatixic.com",
		Token:    "a token from the auth (that did never take place here since unittest)",
		Credentials: Credentials{
			User:     "nisse@nordvestor.com",
			Password: "PassWord",
			APIKey:   "123-abc-123",
		}}

	data := []eqmodel.CbDataPoint{
		&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIZH3STB", Value: 22.0},
		&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIXHSYVE", Value: 89.0},
		&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIRL4ZZI", Value: 76.0},
		&eqmodel.CbDataPointImpl{ID: "1!6WHH75YIU4NUCO", Value: -17.0},
	}

	for i := 0; i < t.N; i++ {
		pipeBuilder := providerpipe.NewPipeBuilder(ctx,
			providerpipe.NewPipelineBuilder(ctx).
				WithSessionStore(config.NewSessionStore(ctx)).
				WithConfigRepository(
					providerconfig.NewProviderConfigRepository(
						ctx,
						providerconfig.NewFsProviderConfigLoaderFromPath(
							"./testdata/without-generator-template/",
						),
					),
				).Build(),
		).
			MapSectionIsWithoutPartition().
			HasPartitionIDSeparator(";").
			UseMappingDirection(providermodel.MappingDirectionLeftAssign).
			WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
			UseCredentialsFunction(
				func(
					context ifcore.CbContext,
					cred string,
					pipeCtx map[string]any,
					eop *providermodel.Operation) (any, int64, cberror.Error) {
					return creds, 3600 /*1h*/, nil
				}).
			UseVerifyConnectFunction(
				func(ctx ifcore.CbContext, cred string, credentials any, eop *providermodel.Operation) bool {
					if nil == credentials {
						return false
					}

					if c, ok := credentials.(*ClimatixIC); ok {
						if u, err := url.Parse(eop.Operation); err == nil {
							return u.Host == c.Endpoint
						}
					}

					return false
				}).
			UseSourceWithReport(
				func(
					ctx ifcore.CbContext,
					pipeCtx map[string]any,
					operation string,
					eop *providermodel.Operation,
					pc *providermodel.ProviderConfigImpl,
					rid []string,
					cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {

					return data, nil /*body*/, nil /*err*/
				}).
			AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

		// Build the executor
		exec := providerpipe.NewExecutorBuilder(ctx).
			UsePipe(*pipeBuilder.Build()).
			FromUserConfig(conf).
			Build()

		// Execute
		exec.Execute().GetResult()
	}
}

func BenchmarkExecutionWithMapSourceFunction(t *testing.B) {
	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Måssmyren 14", "PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TZ": "Europe/Stockholm" 
	},
	"map": { 
		"IDT": "1!N3ASTFSZHI2WD0F", "SHCT_C1": "1!N3ASTFSZH7ZS23P", "SHCT_C2": "1!6WHH6DKHICVDSS", 
		"ODT": "1!N3ASTG10KWTFCMU"
	}
}
--gen=sv
{   "tz": TZ,
	"sensors": {
		"IDT": float64(generate["IDT"].Value), "SHCT_C1": float64(generate["SHCT_C1"].Value),
		"SHCT_C2": float64(generate["SHCT_C2"].Value), "ODT": float64(generate["ODT"].Value)
	}
}`

	ctx := newCtx(t, zerolog.FatalLevel)

	for i := 0; i < t.N; i++ {
		pipeBuilder := providerpipe.NewPipeBuilder(ctx,
			providerpipe.NewPipelineBuilder(ctx).
				WithSessionStore(config.NewSessionStore(ctx)).
				WithConfigRepository(
					providerconfig.NewProviderConfigRepository(
						ctx,
						providerconfig.NewFsProviderConfigLoaderFromPath(
							"./testdata/without-generator-template/",
						),
					),
				).Build(),
		).
			MapSectionIsWithoutPartition().
			HasPartitionIDSeparator(";").
			UseMappingDirection(providermodel.MappingDirectionLeftAssign).
			WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
			UseCredentialsFunction(
				func(
					context ifcore.CbContext,
					cred string,
					pipeCtx map[string]any,
					eop *providermodel.Operation) (any, int64, cberror.Error) {
					return &securitymodel.TokenCredentialsImpl{
						Credentials: securitymodel.StandardCredentialsImpl{
							Endpoint: "api.climatixic.com",
						},
					}, 3600 /*1h*/, nil
				}).
			UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
			UseSourceMapWithReport(
				func(
					ctx ifcore.CbContext,
					pipeCtx map[string]any,
					operation string,
					eop *providermodel.Operation,
					pc *providermodel.ProviderConfigImpl,
					rid []string,
					cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
					// Simulate call to remote endpoint
					return map[string]eqmodel.CbDataPoint{
						"1!N3ASTFSZHI2WD0F": &eqmodel.CbDataPointImpl{
							ID: "1!N3ASTFSZHI2WD0F", Value: 22.0,
						},
						"1!N3ASTFSZH7ZS23P": &eqmodel.CbDataPointImpl{
							ID: "1!N3ASTFSZH7ZS23P", Value: 89.0,
						},
						"1!6WHH6DKHICVDSS": &eqmodel.CbDataPointImpl{
							ID: "1!6WHH6DKHICVDSS", Value: 76.0,
						},
						"1!N3ASTG10KWTFCMU": &eqmodel.CbDataPointImpl{
							ID: "1!N3ASTG10KWTFCMU", Value: -17.0,
						},
					}, nil /*src*/, nil /*body*/, nil /*err*/
				}).
			AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

		providerpipe.NewExecutorBuilder(ctx).
			UsePipe(*pipeBuilder.Build()).
			FromUserConfig(conf).
			Build().
			Execute()
	}
}
