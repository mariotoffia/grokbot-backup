# Provider Pipe Test Index

This document indexes all tests in the `providerpipe` package.

## Test Files in `tests/` Directory

| File | Description | Category |
|------|-------------|----------|
| `helpers_test.go` | Shared test utilities (newCtx, etc.) | Support |
| `sourcefunction_test.go` | SourceFunctionInvoker tests | Unit |
| `pipe_executor_test.go` | Pipe execution tests | Integration |
| `pipeline_executor_test.go` | Pipeline execution tests | Integration |
| `finally_function_test.go` | FinallyFunction behavior tests | Unit |
| `iteration_results_test.go` | IterationExecutionResults helper tests | Unit |
| `builder_test.go` | Builder validation tests | Unit |

## Test Files in Parent Directory (non-exported function tests)

| File | Description | Category |
|------|-------------|----------|
| `source_mapping_test.go` | Source mapping function tests | Unit |
| `defaults_test.go` | Default function tests | Unit |
| `pipe_utils_test.go` | expandCbID and utility tests | Unit |

## Test Data

Test data files are located in `tests/testdata/`:

- `without-generator-template/` - Basic provider configurations
- `log-understandable-messages/` - Error message test configurations
- `pipeline-executor-tests/` - Pipeline execution test configurations

## FinallyFunction Tests

The FinallyFunction feature enables unconditional callbacks after pipe execution:

| Test | Scenario |
|------|----------|
| `TestFinallyFunctionCalledOnSuccess` | Verifies finally is called on success |
| `TestFinallyFunctionCalledOnError` | Verifies finally is called on failure |
| `TestFinallyFunctionCanSuppressError` | Verifies error can be suppressed |
| `TestFinallyFunctionCanWrapError` | Verifies error can be wrapped |
| `TestFinallyFunctionCanReplaceError` | Verifies error can be replaced |
| `TestFinallyFunctionReceivesPipeContext` | Verifies pipe context is passed |
| `TestFinallyFunctionNotCalledWhenNotRegistered` | Verifies no panic without registration |

## Running Tests

```bash
# Run all tests
go test ./go-core/provider/providerpipe/...

# Run only unit tests in tests/ folder
go test ./go-core/provider/providerpipe/tests/...

# Run with verbose output
go test -v ./go-core/provider/providerpipe/...

# Run benchmarks
go test -bench=. ./go-core/provider/providerpipe/...
```
