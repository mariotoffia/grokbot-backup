package providerpipe

import (
	"text/template"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// ProviderPipelineImpl is the complete pipeline that will be executed.
// It may consist of several `ProviderPipeImpl` that will be executed
// in order or in parallel or both.
//
// NOTE: Some `ProviderPipeImpl` may not be executed due to a constraint
// or stipulated in the `ProviderConfiguration`.
//
// A `ProviderPipelineImpl` is `ProviderConfiguration` agnostic
// in the sense that it takes it as a input and is not joined to it.
type ProviderPipelineImpl struct {
	// operations holds `ProviderPipeImpl` that is to be executed based on a
	// certain `Operations`.
	operations map[string]ProviderPipeImpl
	// sessionStore is used to dig out secrets or other sensitive data locally
	sessionStore *config.SessionStore
	// obtainCredentials is a function that is used if it is not explicitly set
	// on the `ProviderPipeImpl`.
	obtainCredentials ObtainCredentialsFunction
	// verifyConnect is a function that is used if it is not explicitly set
	// on the `ProviderPipeImpl`.
	verifyConnect VerifyConnectFunction
	// repository is the one and only repository that is used to query for provider
	// configurations.
	repository *providerconfig.ProviderConfRepository
	// overrideContext is an optional map that may be used to override the context
	// that is used in the pipeline when starting execution in the `ProviderPipeImpl`.
	//
	// NOTE: A provider may choose to use the `OnPrepare` instead of using this and
	// thus allow for specific context and input data to be used instead of this static.
	//
	// If this is set, it will be applied on each element that has not been set.
	overrideContext map[string]any
	// parallelThreshold is the threshold that is used to determine if a pipe should fork-out
	// into multiple parallel executions. A value of less than _1_ will disable parallelization.
	parallelThreshold int
	// batchSize is tha number of pipes that may execute simultaneously.
	batchSize int
	// timeout is the time that the execution is allowed to take before it is aborted (when parallel)
	timeout time.Duration
	// pipeExecutorCreatorFunc is the function to create a new `PipelineExecutorImpl` when needed.
	// If not set, the `DefaultPipelineExecutorForOperationRequest` will be used.
	pipeExecutorCreatorFunc PipelineExecutorForOperationRequest
}

// HasOperation checks if the operation is present in the pipeline.
func (p *ProviderPipelineImpl) HasOperation(operation string) bool {
	_, ok := p.operations[operation]
	return ok
}

// Clone clones the `ProviderPipelineImpl` and all it's `ProviderPipeImpl`.
func (p *ProviderPipelineImpl) Clone() *ProviderPipelineImpl {
	clone := *p

	clone.operations = make(map[string]ProviderPipeImpl, len(p.operations))
	for k, v := range p.operations {
		clone.operations[k] = *v.Clone(&clone)
	}

	return &clone
}

// ProviderPipeImpl is a single pipe that can be executed using a
// `ProviderConfiguration` as the input.
//
// CAUTION: That the `ProviderConfiguration` must be fully resolved
// and not result in a another or a set of other `ProviderConfiguration`.
//
// The above stipulates that the it only may use parts of the `process` section of the
// configuration such as _filter_ and _assign_ but not _profiles_ etc.
type ProviderPipeImpl struct {
	// Owner is the owning `ProviderPipelineImpl`.
	Owner *ProviderPipelineImpl
	// operation is the operation that this pipe is to be executed for.
	operation string
	// mapperWithoutPartition is set to true when mapping section is do not
	// carry partition information. This is used for reporting.
	mapperWithoutPartition bool
	// mappingDirection is the direction of the mapping. This is used to determine how the mapping
	// of _CbID_ to _RemoteID_ should be done.
	mappingDirection providermodel.MappingDirection
	// SplitPartitionAndIDFunc is optional but when submitted it will be used
	// to determine the ID and partition by submitting the `eqmodel.CbDataPoint.GetID()`
	// to the function.
	//
	// CAUTION: If `nil` the _ID_ is _REQUIRED_ to be a _ID_ without any partition.
	//
	// This is used for reporting.
	splitPartitionAndIDFunc providerutils.SplitPartitionAndID
	// toTeosID is a custom function to translate a datapoint into a _TEOS_ id.
	toTeosID providerutils.ToTeosIDFunc
	// source is the function to populate the pipe with data to process.
	source SourceFunction
	// sourceWithSelection is a function that takes over the source, selection of the provider pipe
	// and is done completely custom.
	//
	// CAUTION: It is not allowed to register both a `source` and a `sourceWithSelection`!
	sourceWithSelection SourceFunctionWithSelection
	// target is the function that gets executed when the pipeline has successfully
	// executed and there's a target data generated.
	target TargetFunction
	// After is a function that is invoked after the pipe has been executed.
	//
	// NOTE: This may be used to acknowledge the data that has been processed.
	after AfterFunction
	// finally is always invoked after pipe execution completes, regardless of outcome.
	// It can wrap, replace, or suppress the original error.
	finally FinallyFunction
	// prepareProfile is an optional callback that is invoked just before the `source` function and
	// can be used to modify profile, parameters, or even replace profile. Since the system
	// has authenticated the function may call the remote endpoint here.
	prepareProfile map[string]PrepareProfile
	// credentials is the function when the pipe needs to obtain credentials.
	//
	// If not set use `ProviderPipelineImpl.obtainCredentials`.
	credentials ObtainCredentialsFunction
	// verifyConnect is used when the credentials obtained, it's endpoint part
	// needs to be verified that it may be used to the endpoint that the provider is
	// configured to use via the `ifprovider.ParameterRemoteEndpoint` parameter.
	//
	// If not set use `ProviderPipelineImpl.verifyConnect`.
	verifyConnect VerifyConnectFunction
	// filters are optional filters to be applied in the pipeline or otherwise used in the provider.
	// Those may be registered via the `ProviderFilterFunctionContributor` implementations.
	filters map[string]ifprovider.OperationFilters
	// prototypes are types that are used for marshalling e.g `dsmodel.DsBuilding`
	prototypes map[string]any
}

func (p *ProviderPipeImpl) Clone(owner *ProviderPipelineImpl) *ProviderPipeImpl {
	clone := *p
	clone.Owner = owner

	clone.filters = make(map[string]ifprovider.OperationFilters, len(p.filters))
	for k, v := range p.filters {
		clone.filters[k] = v
	}

	clone.prototypes = make(map[string]any, len(p.prototypes))
	for k, v := range p.prototypes {
		clone.prototypes[k] = v
	}

	return &clone
}

// ProviderPipelineExecutorImpl will execute one or more `ProviderPipeImpl` based on
// the `ifprovider.ConfigFull` and user configuration provided.
//
// It can only invoke the operations specified in the `ProviderPipeImpl`. Depending
// on the operations and amount, it may parallelize the execution.
type ProviderPipelineExecutorImpl struct {
	// ctx is the context that the execution is to be done in.
	ctx ifcore.CbContext
	// pipeline is the pipeline that will be executed.
	pipeline *ProviderPipelineImpl
	// operation is the _main/initial_ operation that is to be executed.
	// It must exist in the _pipeline_.
	operation locationmodel.ProviderOperation
	// config is the main configuration that is to be executed
	//
	// NOTE: This configuration may diverge into several based on the _profile_ section
	// in combination with _process_ section.
	config ifprovider.ConfigFull
	// input is optional input parameters that may be used when resolving pipe context
	// for the first time.
	//
	// NOTE: This is a shallow copy of the input map. In addition, they are only used
	// when resolving the "static" profile and is not passed along to other profiles
	// under the _profile_ section.
	//
	// Providers may use this to allow for e.g. global parameters to be evaluated in
	// the profile.
	input map[string]any
	// allowMutateGlobalParams dictates if the global parameters may be mutated or not.
	// CAUTION: It is of *essence* that each profile must be cloned before it is used!
	allowMutateGlobalParams bool
	// err is the last error that occurred.
	err cberror.Error
	// overrideSourceFunc is set on all operations
	overrideSourceFunc SourceFunction
	// overrideSourceWithSelectionFunc is set on all operations
	overrideSourceWithSelectionFunc SourceFunctionWithSelection
	// overrideTargetFunc is set on all operations
	overrideTargetFunc TargetFunction
}

// ProviderPipeExecutorImpl is a executor to execute a single `ProviderPipeImpl` instance.
//
// When execution is done, it is possible to check the result but the instance cannot be reset
// for another round. Instead create a new and use it.
type ProviderPipeExecutorImpl struct {
	// pipeConfig is the pipe config that is to be executed.
	pipeConfig *ProviderPipeImpl
	// config is the configuration that is to be used when executing.
	config ifprovider.ConfigFull
	// input is input parameters that are either from bootstrap or from previous pipe.
	//
	// NOTE: This is a shallow copy of the input map.
	input map[string]any
	// allowMutateGlobalParams dictates if the global parameters may be mutated or not.
	// CAUTION: It is of *essence* that each profile must be cloned before it is used!
	allowMutateGlobalParams bool
	// pipeContext is the context that is sent to the pipe and can later be queried when
	// the pipe has executed.
	pipeContext map[string]any
	// logging dictates if pipe should be logged or not.
	logging bool
	// ctx is the context that the execution is to be done in.
	ctx ifcore.CbContext
	// onPrepare is an optional callback that is invoked when the pipe is about to be executed.
	onPrepare OnPrepare
	// prepareProfile is an optional callback that is invoked just before the source function and
	// can be used to modify profile, parameters, or even replace profile. Since the system
	// has authenticated the function may call the remote endpoint here.
	prepareProfile map[string]PrepareProfile
	// onSource is an optional callback that is invoked after any invocation of source function.
	onSource OnSource
	// onTarget is an optional callback that is invoked after any invocation of target function.
	onTarget OnTarget
	// extractTargetFunc is an callback that is invoked when the target data is to be extracted
	extractTargetFunc ExtractTargetFunc
	// err is the last error that occurred.
	err cberror.Error
	// cancelReason is set when the pipeline is cancelled gracefully (not an error).
	// Check `cberror.IsCancelPipelineError()` for details on cancel reasons.
	cancelReason cberror.CancelPipelineReason
	// goTemplate is the generated Go template that is used to render the JSON pipeline.
	// This allows for plain golang template engine functionality when rendering the pipeline.
	goTemplate *template.Template
	// prog is the compiled pipeline. It never changes once built, so it is kept
	// and run as often as needed, including from more than one goroutine.
	prog *cbpipeline.Program
	// lastResult holds the variables the most recent run finished with. It is
	// what the target is taken out of, and what a "finally" function is shown.
	lastResult map[string]any
	// operation is the operation that been resolved and evaluated to be used
	// when executing the pipe.
	//
	// This is resolved using `pipeConfig.operation` as the operation name.
	operation *providermodel.Operation
	// targetKey is the default key to use when extracting the data from the source.
	// Default is: _target_.
	targetKey string
	// result is set when a successful execution has been done.
	result map[string]any
	// hasCompleted is set to true when the pipe has completed and either failed or succeeded.
	hasCompleted bool
}
