package providercontext

import (
	"encoding/json"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cblambda"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// ProviderHandlerFunc creates a HandlerInvoker for a ProviderContext.
// The returned handler is used both for Lambda runtime execution (via StartLambda)
// and for in-process test invocation (via Invoker).
type ProviderHandlerFunc func(pc ProviderContext) dispruntime.HandlerInvoker

// SourceNoArgFunction is a wrapper for `providerpipe.SourceFunction` that do not accept any arguments
// and only return a map of the source. The return have the same semantics.
//
// TIP: This is useful if embedding the source in a dispatcher function.
type SourceNoArgFunction func() (map[string]any, cberror.Error)

// SimpleTargetFunction is a simplified `providerpipe.TargetFunction` that only accepts a map of
// the target and returns an error.
type SimpleTargetFunction func(target map[string]any) cberror.Error

type ProviderUserConfigUsage string

const (
	// ProviderUserConfigUsageNone is when it is not specified. This is used in the `OptExecute` function
	// to denote that it has no effect. Hence, the provider is the one determining the usage (if configured).
	ProviderUserConfigUsageNone ProviderUserConfigUsage = ""
	// ProviderUserConfigUsageManual is when the user configuration must be specified manually and
	// nothing is loaded.
	ProviderUserConfigUsageManual ProviderUserConfigUsage = "manual"
	// ProviderUserConfigUsageLoaderPerLocationID is when the user configuration is loaded per location ID.
	//
	// TIP: If a configuration is passed and no configuration is found/no loader set for the _LocationID_ it
	// will default to the passed configuration as a fallback.
	ProviderUserConfigUsageLoaderPerLocationID ProviderUserConfigUsage = "location_id"
)

func ProviderUserConfigUsageFromString(s string) ProviderUserConfigUsage {
	switch strings.ToLower(s) {
	case "none", "":
		return ProviderUserConfigUsageNone
	case "manual":
		return ProviderUserConfigUsageManual
	case "location_id", "locationid":
		return ProviderUserConfigUsageLoaderPerLocationID
	default:
		return ProviderUserConfigUsageNone
	}
}

// ProviderDispatcherSourceFunc extends the pipe source function with the event that was passed into
// the `ProviderContext.Execute` or `ProviderContext.OnProviderEvent` function.
//
// NOTE: This is used to captured in a handler for each request.
type ProviderDispatcherSourceFunc func(
	ctx ifcore.CbContext,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	event any,
	cred any) (map[string]any, cberror.Error)

// ProviderContext is the execution of the provider service.
type ProviderContext interface {
	// Context will return the root context for the provider service.
	Context() ifcore.CbContext
	// Invoker returns the RawInvoker set via UseInvoker or UseProviderDispatcher on the builder.
	// Returns nil when no invoker is configured.
	Invoker() dispruntime.RawInvoker
	// Type is the type of provider this is.
	Type() locationmodel.ProviderOperation
	// Execute is a generic execute function of which will execute the pipeline using the provided provider user
	// configuration.
	//
	// The provider is responsible for parsing the return and take appropriate action.
	//
	// TIP: Set `ctx.SetValue(provider.ProviderCtxDryRun, true)` to execute the pipeline in dry-run mode.
	//
	// This will set the `ifprovider.PipeContextKeyEvent` key in the context so the _event_ is reachable
	// within the pipe. The _input_ parameter is optional.
	//
	// CAUTION: Only one `OptExecute` is allowed.
	//
	// The _locationID_ is optional and is used when the `UserProviderConfigLoader` are used to load the user config. It may
	// be empty otherwise.
	Execute(
		ctx ifcore.CbContext,
		locationID, userConfig string,
		event any,
		input map[string]any,
		extra ...*OptExecute,
	) (providerpipe.IterationExecutionResults, cberror.Error)
	// OnProviderEvent invoke this function when a providers receives an `cbevent.ProviderEvent`.
	//
	// It will pick the event dry-run and endpoint and set if any of them is set to override the
	// context values.
	//
	// This will set the `ifprovider.PipeContextKeyEvent` key in the context so the _event_ is reachable
	// within the pipe. The _input_ parameter is optional.
	OnProviderEvent(
		ctx ifcore.CbContext,
		event *cbevent.ProviderEvent,
		input map[string]any,
	) (*cbevent.ProviderResultEvent, cberror.Error)
}

// ProviderContextImpl is the execution of the provider service.
type ProviderContextImpl struct {
	// rootContext is the context to use as the root context
	rootContext ifcore.CbContext
	// invoker is the RawInvoker set via UseInvoker or UseProviderDispatcher.
	invoker dispruntime.RawInvoker
	// pipeline is the pipeline to execute the requests with.
	pipeline *providerpipe.ProviderPipelineImpl
	// providerType is the type of provider this is.
	providerType locationmodel.ProviderOperation
	// allowMutateGlobalParams if set to `true` it will allow for the provider configuration
	// to be mutated (in the global params).
	allowMutateGlobalParams bool
	// userConfigLoader is an optional loader to load user config inside the `Execute` function.
	userConfigLoader []UserProviderConfigLoader
	// configUsage specifies how to use/handle the user configuration.
	userConfigUsage ProviderUserConfigUsage
}

// StartLambda starts the Lambda runtime using the handler from pctx.Invoker().
// In test mode (CB_DISPATCHER_FEED=inproc), this is a no-op.
func StartLambda(pctx ProviderContext) {
	if cbenv.CB_DISPATCHER_FEED.String("lambda") == "inproc" {
		return
	}

	if h, ok := pctx.Invoker().(dispruntime.HandlerInvoker); ok {
		cblambda.StartWithContext(h, pctx.Context())
	}
}

// Context will return the root context for the provider service.
func (pc *ProviderContextImpl) Context() ifcore.CbContext {
	return pc.rootContext
}

// Invoker returns the RawInvoker set via UseInvoker or UseProviderDispatcher.
func (pc *ProviderContextImpl) Invoker() dispruntime.RawInvoker {
	return pc.invoker
}

// Type is the type of provider this is.
func (pc *ProviderContextImpl) Type() locationmodel.ProviderOperation {
	return pc.providerType
}

// OptExecute is optional execute options.
type OptExecute struct {
	// Source will replace all operations source functions with this one.
	Source providerpipe.SourceFunction
	// NoArgSource will replace all operations source functions with this one.
	//
	// This is useful using as a closure to capture the event and input and feed
	// it as a source instead of putting it as event key in context.
	//
	// CAUTION: This overrides the `Source` option.
	NoArgSource SourceNoArgFunction
	// Target will replace all operations target functions with this one.
	Target providerpipe.TargetFunction
	// SimpleTarget is a very simple target function that allows for extraction and signal errors if encountered any.
	SimpleTarget SimpleTargetFunction
	// ConfigUsage will override the set config usage for the provider context. Default is `ProviderUserConfigUsageNone`.
	ConfigUsage ProviderUserConfigUsage
	// UserConfigLoader is an array of user config loaders to load user config inside the `Execute` function that overrides
	// the ones set in the provider context.
	UserConfigLoader []UserProviderConfigLoader
}

func (pc *ProviderContextImpl) Execute(
	ctx ifcore.CbContext,
	locationID, userConfig string,
	event any,
	input map[string]any,
	extra ...*OptExecute,
) (providerpipe.IterationExecutionResults, cberror.Error) {
	// Setup for execution
	if !pc.pipeline.HasOperation(string(pc.providerType)) {
		return nil, cberror.NewCbErrorfWithProps(ctx.Service(), 500, nil, map[string]any{
			cberror.PropertyProvider: ctx.Provider(),
		}, "pipeline do not contain operation: %s", pc.providerType)
	}

	builder := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(pc.providerType).
		UsePipeline(*pc.pipeline.Clone()).
		WithContextVariable(ifprovider.PipeContextKeyEvent, event)

	if locationID != "" {
		builder.WithContextVariable(string(ifprovider.ParameterLocationID), locationID)
	}

	// These parameters may be overridden by the `extra` parameter.
	userConfigUsage := pc.userConfigUsage
	userConfigLoader := pc.userConfigLoader

	if len(extra) > 0 {
		if extra[0].Source != nil {
			builder.OverrideSourceFunction(extra[0].Source)
		}

		if extra[0].Target != nil {
			builder.OverrideTargetFunction(extra[0].Target)
		}

		if extra[0].NoArgSource != nil {
			builder.OverrideSourceFunction(func(
				ctx ifcore.CbContext,
				operation string,
				op *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				pipeCtx map[string]any,
				cred any) (map[string]any, cberror.Error) {
				return extra[0].NoArgSource()
			})
		}

		if extra[0].SimpleTarget != nil {
			builder.OverrideTargetFunction(func(
				ctx ifcore.CbContext,
				operation string,
				op *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				pipeCtx map[string]any,
				cred any, target map[string]any) cberror.Error {
				return extra[0].SimpleTarget(target)
			})
		}

		if extra[0].ConfigUsage != ProviderUserConfigUsageNone {
			userConfigUsage = extra[0].ConfigUsage
		}

		if len(extra[0].UserConfigLoader) > 0 {
			userConfigLoader = extra[0].UserConfigLoader
		}
	}

	// load the user config if needed
	var err cberror.Error
	if userConfig, err = loadUserConfig(
		ctx, userConfigLoader, userConfig, locationID, userConfigUsage,
	); err != nil {
		return nil, err
	}

	// Set the userConfig
	builder.FromUserConfig(userConfig)

	if pc.allowMutateGlobalParams {
		builder.AllowGlobalParameterMutation()
	}

	if input != nil {
		builder.WithInput(input)
	}

	executor := builder.Build()

	if builder.Error() != nil {
		return nil, builder.Error()
	}

	// Execute the pipeline
	res := executor.Execute()

	if executor.Error() != nil {
		return nil, executor.Error()
	}

	return res, nil
}

func (pc *ProviderContextImpl) OnProviderEvent(
	ctx ifcore.CbContext,
	event *cbevent.ProviderEvent,
	input map[string]any,
) (*cbevent.ProviderResultEvent, cberror.Error) {
	// Setup for execution
	cfgLen := len(event.Config)
	var errors []cberror.Error

	result := &cbevent.ProviderResultEvent{
		Status: make([]string, cfgLen),
		Result: make([]any, cfgLen),
	}

	if event.DryRun {
		ctx.SetValue(provider.ProviderCtxDryRun, true)
	}

	if event.Endpoint != "" {
		if ep := utils.CreateURLFromString(event.Endpoint); ep != nil {
			ctx.SetValue(provider.ProviderCtxEndpoint, ep)
		}
	}

	// Is there any credentials passed inline to use instead of CRD in profile/user config?
	var (
		clientCreds   *securitymodel.ClientCredentialsMaterial
		crd, mockdata string
	)

	if len(event.Params) > 0 {
		if m, ok := event.Params[string(cbevent.ProviderParamCRD)]; ok {
			crd, _ = m.(string)
		}

		if m, ok := event.Params[string(cbevent.ProviderParamMockData)]; ok {
			mockdata, _ = m.(string)
		}

		if m, ok := event.Params[string(cbevent.ProviderParamCredentials)]; ok {
			if cc, ok := m.(*securitymodel.ClientCredentialsMaterial); ok {
				clientCreds = cc
			} else if cc, ok := m.(map[string]any); ok {
				if _, ok := cc["credentials"]; ok {
					if crd, err := jsonutils.FromMapToObject[*securitymodel.TokenCredentialsImpl](ctx, cc); err == nil {
						clientCreds = &securitymodel.ClientCredentialsMaterial{
							User:         crd.Credentials.User,
							Password:     crd.Credentials.Password,
							Key:          crd.Credentials.APIKey,
							Endpoint:     crd.Credentials.Endpoint,
							ClientId:     crd.Credentials.ClientID,
							ClientSecret: crd.Credentials.ClientSecret,
						}
					} else {
						errors = append(errors, err)
					}
				} else if crd, err := jsonutils.FromMapToObject[*securitymodel.ClientCredentialsMaterial](ctx, cc); err == nil {
					clientCreds = crd
				}
			} else if cc, ok := m.(string); ok {
				_ = json.Unmarshal([]byte(cc), &clientCreds)
			}
		}
	}

	for i := range event.Config {
		config := event.ToConfigString(i)

		builder := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
			AsOperation(pc.providerType).
			UsePipeline(*pc.pipeline.Clone()).
			FromUserConfig(config).
			WithContextVariable(ifprovider.PipeContextKeyEvent, event)

		if pc.allowMutateGlobalParams {
			builder.AllowGlobalParameterMutation()
		}

		// Provide with inline credentials if any
		if clientCreds != nil {
			builder.WithContextVariable(ifprovider.PipeContextCredentials, clientCreds)
		}

		// Provide with mock data if any
		if mockdata != "" {
			builder.WithContextVariable(string(ifprovider.PipeContextMockData), mockdata)
		}

		// Provide with override CRD if any
		if crd != "" {
			if input == nil {
				input = make(map[string]any)
			}

			input[string(cbevent.ProviderParamCRD)] = crd
		}

		if input != nil {
			builder.WithInput(input)
		}

		executor := builder.Build()

		if builder.Error() != nil {
			errors = append(errors, builder.Error())
			result.Status[i] = builder.Error().Error()

			continue
		}

		// Execute the pipeline
		res := executor.Execute()

		if executor.Error() != nil {
			errors = append(errors, executor.Error())
			result.Status[i] = executor.Error().Error()
		}

		if len(res) == 0 {
			continue
		}

		for j := range res {
			res := res[j]
			if res.Error != nil {
				errors = append(errors, res.Error)
				result.Status[i] = res.Error.Error()
			}

			if event.Result && res.Result != nil {
				result.Result[i] = res.Result
			}

		}
	}

	if len(errors) == 0 {
		return result, nil
	}

	if len(errors) == 1 {
		return result, errors[0]
	}

	return result, cberror.NewCbCompositeErrorf(
		ctx.Service(), 1, cberror.FromCbErrorsToErrors(errors),
		map[string]any{cberror.PropertyProvider: ctx.Provider()},
		"multiple errors",
	)
}
