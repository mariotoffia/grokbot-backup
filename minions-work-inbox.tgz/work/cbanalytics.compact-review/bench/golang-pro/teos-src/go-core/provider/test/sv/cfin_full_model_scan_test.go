package sv

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/cfgmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestCFINScanFullModelIDT will do a scan of IDT returning `eqmodel.InstalledSensor` as indoor temperature sensors.
func TestCFINScanFullModelIDT(t *testing.T) {
	pid := "myPlantID"
	lid := "Måssmyren 18"
	sensorModel := "strip-v2"
	modelName := "sensative"

	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			// A real provider would extract sm and rids and use them to fetch data from remote endpoint.
			// sm, rids := providerpipe.ToSourceMappingAndRemoteIDs(rid)

			oid, _ := pc.GetParamAsString(string(ifprovider.ParameterOwnerID))

			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{ID: "virtualCNTIDT", Value: 4},
				&eqmodel.CbDataPointImpl{ID: "virtualBRAND", Value: "siemens"},
				&eqmodel.CbDataPointImpl{ID: "virtualMODELID", Value: "POL348"},
				&eqmodel.CbDataPointImpl{ID: "virtualSERIAL", Value: "serial-123"},
				&eqmodel.CbDataPointImpl{ID: "virtualSTATE", Value: 1},
				// Fake scan of IDT (should be inside sm as 'IDT')
				&eqmodel.CbDataPointImpl{
					ID: "IDT_O1",
					Value: eqmodel.InstalledSensor{
						SensorID:     "sensor-1",
						OwnerID:      oid,
						EquipmentID:  pid,
						ProviderName: "thiink",
						LocationID:   lid,
						ModelID:      sensorModel,
						ModelName:    modelName,
						Serial:       "serial-777",
						RemoteID:     "remote-1",
						TeosID:       "",
						Type:         eqmodel.SensorIndoorTemp,
						Params: map[string]any{
							"test": "test-1",
						},
					},
				},
				&eqmodel.CbDataPointImpl{
					ID: "IDT_O2",
					Value: eqmodel.InstalledSensor{
						SensorID:     "sensor-2",
						OwnerID:      oid,
						EquipmentID:  pid,
						LocationID:   lid,
						ProviderName: "thiink",
						ModelID:      sensorModel,
						ModelName:    modelName,
						Serial:       "serial-888",
						Type:         eqmodel.SensorIndoorTemp,
						Params: map[string]any{
							"test": "test-2",
						},
					},
				},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "thiink", string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/idt-scan",
				 "prms": {
					 "LOG": true,
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default"
				}
		}`, pid, lid),
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	m := cbevent.ExtractResult[map[string]cfgmodel.ImportConfigEvent](res, 0)
	require.Equal(t, 1, len(m))

	ie := m["target"]
	assert.Equal(t, lid, ie.LocationID)
	assert.Equal(t, "cfin/idt-scan", ie.Profile)
	assert.Equal(t, "thiink", ie.ProviderName)
	require.Len(t, ie.Params, 0)
	require.Len(t, ie.Equipment, 1)

	eq := ie.Equipment[0]

	assert.Equal(t, lid, eq.LocationID)
	assert.Equal(t, pid, eq.EquipmentID)
	assert.Equal(t, "POL348", eq.ModelID)
	assert.Equal(t, "siemens", eq.ModelName)
	assert.Equal(t, "serial-123", eq.Serial)
	assert.Equal(t, "default", eq.OwnerID)
	require.Len(t, eq.Location, 0)
	require.Len(t, eq.Params, 6)
	assert.Equal(t, "virtualSERIAL", eq.Params["RID_SERIAL"])
	assert.Len(t, eq.Params["sensor_names"], 2)
	assert.Contains(t, eq.Params["sensor_names"], "sensor-1")
	assert.Contains(t, eq.Params["sensor_names"], "sensor-2")
	assert.Equal(t, "online", eq.Params[string(eqmodel.EqState)])
	assert.Equal(t, float64(4), eq.Params["CNTIDT"])

	require.Len(t, ie.Sensors, 2)

	s1 := ie.Sensors[0]
	s2 := ie.Sensors[1]

	if s1.SensorID == "sensor-2" {
		s1, s2 = s2, s1
	}

	assert.Equal(t, lid, s1.LocationID)
	assert.Equal(t, pid, s1.EquipmentID)
	assert.Equal(t, sensorModel, s1.ModelID)
	assert.Equal(t, modelName, s1.ModelName)
	assert.Equal(t, "sensor-1", s1.SensorID)
	assert.Equal(t, "serial-777", s1.Serial)
	assert.Equal(t, "default", s1.OwnerID)
	require.Len(t, s1.Location, 0)
	require.Len(t, s1.Params, 1)
	assert.Equal(t, "test-1", s1.Params["test"])
	assert.Equal(t, eqmodel.SensorIndoorTemp, s1.Type)

	assert.Equal(t, lid, s2.LocationID)
	assert.Equal(t, pid, s2.EquipmentID)
	assert.Equal(t, sensorModel, s2.ModelID)
	assert.Equal(t, modelName, s2.ModelName)
	assert.Equal(t, "sensor-2", s2.SensorID)
	assert.Equal(t, "serial-888", s2.Serial)
	assert.Equal(t, "default", s2.OwnerID)
	require.Len(t, s2.Location, 0)
	require.Len(t, s2.Params, 1)
	assert.Equal(t, "test-2", s2.Params["test"])
	assert.Equal(t, eqmodel.SensorIndoorTemp, s2.Type)
}

func BenchmarkCFINScanIDT(t *testing.B) {
	testData := []eqmodel.CbDataPoint{
		&eqmodel.CbDataPointImpl{ID: "virtualCNTIDT", Value: 4},
		&eqmodel.CbDataPointImpl{ID: "virtualBRAND", Value: "siemens"},
		&eqmodel.CbDataPointImpl{ID: "virtualMODELID", Value: "POL348"},
		&eqmodel.CbDataPointImpl{ID: "virtualSERIAL", Value: "serial-123"},
		&eqmodel.CbDataPointImpl{ID: "virtualSTATE", Value: 1},
		// Fake scan of IDT (should be inside sm as 'IDT')
		&eqmodel.CbDataPointImpl{
			ID:    "IDT_O1",
			Value: eqmodel.InstalledSensor{},
		},
	}

	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			return testData, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "thiink", string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	evt := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			`{ "profile": "cfin/idt-scan",
				 "prms": {
					 "LOG": false,
					 "PID": "POL348",
					 "TID": "abc-123",
					 "BID": "Måssmyren 14",
					 "OID": "default"
				}
		}`,
		},
	})

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		result, invokeError := pctx.Invoker().InvokeRaw(ctx, evt)

		require.NoError(t, invokeError)
		require.NotNil(t, result)

		res := result.(*cbevent.ProviderResultEvent)
		require.Equal(t, 1, len(res.Result))

		m := cbevent.ExtractResult[map[string]cfgmodel.ImportConfigEvent](res, 0)
		require.Equal(t, 1, len(m))
	}
}
