package utils

import (
	"strings"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
)

// RenderGeneratorPrototypeByName will render a generator prototype template for the given name.
//
// The _ID_ is the name of the prototype generator template to use. If the _ID_ is not found, it will
// look for the _genProtoFallbackID_ and use that instead if found.
//
// The _pid_ is an array of sensor IDs to use for the prototype. Those can be used to control what
// get's rendered onto the prototype template.
func RenderGeneratorPrototypeByName(
	ctx ifcore.CbContext,
	cfg ifprovider.ConfigFull,
	templateID, genProtoFallbackID string,
	pid []string,
) (string, cberror.Error) {
	protoTemplate, ok := cfg.GetGenProtoTemplates()[templateID]

	if !ok {
		return "", cberror.NewCbErrorf(
			ctx.Service(), 1, nil,
			"failed to get full generator template and no prototype template found for ID: %s", templateID,
		)
	}

	var cfgAsInterface interface{} = cfg
	var sb strings.Builder
	var result string

	p, ok := cfg.GetGenProto(templateID)
	if !ok {
		p, ok = cfg.GetGenProto(genProtoFallbackID)
	}

	if !ok {
		if strings.Contains(protoTemplate, "{{GENPROTO}}") {
			return "", cberror.NewCbErrorf(
				ctx.Service(),
				4,
				nil,
				"no GenProto mappings found, instead the (GENPROTO) was found (which is incorrect) on template ID: %s",
				templateID,
			)
		}
	}

	sensors := RenderGeneratorPrototype(
		cfgAsInterface.(ifprovider.ConfigMapping), p, sb, pid, ctx, templateID,
	)

	result = strings.Replace(protoTemplate, "{{GENPROTO}}", sensors, 1)

	didGenerateTS := false

	p, ok = cfg.GetGenProtoTs(templateID)
	if !ok {
		p, ok = cfg.GetGenProtoTs(genProtoFallbackID)
	}
	if ok && len(p.GetTable()) > 0 {
		if HasTimeStampCheckEnabled(cfgAsInterface.(ifprovider.ConfigGlobalParams)) {
			sensorts := RenderGeneratorPrototype(
				cfgAsInterface.(ifprovider.ConfigMapping), p, sb, pid, ctx, templateID,
			)

			result = strings.Replace(result, "{{GENPROTO_TS}}", sensorts, 1)
			didGenerateTS = true
		}
	}

	if !didGenerateTS {
		// Remove either comma before the {{GENPROTO_TS}} so the JSON still render ok
		genprotoIndex := strings.Index(result, "{{GENPROTO_TS}}")

		if genprotoIndex != -1 {
			var i int
			for i = genprotoIndex; i >= 0; i-- {
				if result[i] == ',' {
					break
				}
			}

			if i != -1 {
				result = result[0:i] + result[genprotoIndex+15:]
			}

			if l, ok := logger.ClsLog(zerolog.DebugLevel, "CreateGeneratorTemplate", logger.LDTUntyped, logger.LISUnclassified, ctx); ok {
				l.Msgf(
					"GenProtoTs is present but the global param %s or %s is not "+
						" set to true, skipping GENPROTO_TS rendering for operation: %s (removed genproto = %t)",
					ifprovider.ParameterCheckTimeStampOnUpdate,
					ifprovider.ParameterLocalCheckAndReportTimeStamp,
					templateID,
					genprotoIndex != -1,
				)
			}
		}
	}

	return result, nil
}

// RenderGeneratorPrototype renders the generator prototype template for the given ID.
//
// The resulting string is a complete JSON object wrapped with {}.
func RenderGeneratorPrototype(cfg ifprovider.ConfigMapping,
	p ifprovider.ConfigGeneratorPrototype,
	sb strings.Builder,
	pid []string,
	ctx ifcore.CbContext,
	_ string) string {
	closeEnd := []byte("}")
	openStart := []byte("{")

	prototypeBody := p.HasBodyPrototype()

	if !prototypeBody {
		sb.Write(openStart)
	}

	first := true

	for _, id := range pid {
		if RenderSingleID(ctx, cfg, p, &sb, id, first, false /*onlyExpression*/) {
			first = false
		}
	}

	if !prototypeBody {
		sb.Write(closeEnd)
	}

	return sb.String()
}

func RenderSingleID(
	ctx ifcore.CbContext,
	cfg ifprovider.ConfigMapping,
	p ifprovider.ConfigGeneratorPrototype,
	sb *strings.Builder,
	id string,
	first, onlyExpression bool,
) bool {
	startID := []byte(" \"")
	startWithoutID := []byte(" ")
	middleID := []byte("\": ")
	commaCR := []byte(",")

	prototype, body, found, mappedTo := p.PrototypeFromID(id)

	if !found {
		log.Warn(ctx).
			WithMethod("CreateGeneratorTemplate").
			Str("id", id).
			Msg("Could not find generator prototype for id")

		return false
	}

	rightID, hasRightID := cfg.GetMappedTo(id)

	// If we don't have a right ID, but proto template want's it - we silently
	// skip those entries (may be optional IDs)
	if !hasRightID && strings.Contains(prototype, RightHandMappingID) {
		return false
	}

	// Resolve the right hand expression
	rhe := strings.ReplaceAll(prototype, LeftHandMappingID, id)

	if hasRightID && strings.Contains(rhe, RightHandMappingID) {
		rhe = strings.ReplaceAll(rhe, RightHandMappingID, strings.Trim(rightID, "\""))
	}

	// Only expression is wanted -> write to buffer and return
	if onlyExpression && !body {
		sb.WriteString(rhe)

		return true
	}

	if !first {
		sb.Write(commaCR)
	}

	switch {
	// "ID":{expr} or { obj } mode (objects in a list) is the prototype -> just write it and return
	case body:
		sb.Write(startWithoutID)
		sb.WriteString(rhe)
	default:
		// "{ID}": "{expr}" mode (key value pair)
		sb.Write(startID)

		if mappedTo && hasRightID {
			// The RightID is requested and we have a mapping to it
			sb.WriteString(rightID)
		} else {
			sb.WriteString(id)
		}

		sb.Write(middleID)
		sb.WriteString(rhe)
	}

	return true
}
