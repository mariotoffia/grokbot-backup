package providerpipe

import (
	"bytes"
	"fmt"
	"maps"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/enumutils"
	"github.com/Thiink-LLC/teos/go-core/utils/regexutils"
	"github.com/Thiink-LLC/teos/go-core/utils/templateutils/templatecache"
	"github.com/Thiink-LLC/teos/go-core/utils/templateutils/teostemplate"
)

// Select will iterate the _source_ data and render `Selection` objects based on the `SelectorObject`(s) provided.
func (sfi *SourceFunctionInvoker) Select(
	pipeCtx, src map[string]any,
	selectors map[string]providermodel.SelectObject,
) ([]providermodel.Selection, cberror.Error) {
	if len(selectors) == 0 {
		return nil, nil
	}

	const method = "SourceFunctionInvoker::Select"

	// If all expressions are the same, let's evaluate them once
	globalExpr := ""
	same := true

	selection := make([]providermodel.Selection, 0, len(selectors))

	for _, sel := range selectors {
		if globalExpr == "" {
			globalExpr = sel.Expression
		} else if globalExpr != sel.Expression {
			same = false
			break
		}
	}

	if !same {
		globalExpr = ""
	}

	var idValueMap map[string]any

	if globalExpr != "" {
		if vm, err := sfi.ExtractValuesFromExpression(globalExpr, src); err != nil {
			return nil, err
		} else {
			idValueMap = vm
		}
	}

	for regEx, sel := range selectors {
		if sel.Expression == "" {
			log.Warn(sfi.Ctx).
				WithBody(sel).
				WithMethod(method).
				Msg("Empty expression in selector, skipping")

			continue
		}

		idv := idValueMap

		if idv == nil {
			// Different expressions -> need to evaluate each time
			if vm, err := sfi.ExtractValuesFromExpression(sel.Expression, src); err != nil {
				return nil, err
			} else {
				// All expressions are same -> use single
				idv = vm
			}
		}

		var enumExpr map[string]string

		// If no match in switch-case -> assume regexp
		switch {
		case cbeval.IsCbEvalExpression(regEx):
			if re, err := cbeval.Evaluate[string](sfi.Ctx, cbeval.UnwrapExpression(regEx), sfi.PipeContext, true /*cache*/, cbeval.EvalCacheLangFullCB); err != nil {
				return nil, cberror.NewCbErrorf(
					sfi.Ctx.Service(), 1, err,
					"Failed to evaluate regex expression: %s, err: %s", regEx, err.Error(),
				)
			} else {
				regEx = re
			}
		case cbeval.IsTemplateExpression(regEx):
			regEx = cbeval.UnwrapTemplateExpression(regEx)

			if tmpl, err := templatecache.GlobalTemplateCache.GetOrCompile(regEx, regEx); err != nil {
				return nil, cberror.FromError(
					sfi.Ctx.Service(), 400, err,
				)
			} else {
				var buf bytes.Buffer

				if err := tmpl.Execute(&buf, sfi.PipeContext); err != nil {
					return nil, cberror.FromError(
						sfi.Ctx.Service(), 400, err,
					)
				}

				regEx = buf.String()
			}
		case enumutils.IsEnumExpression(regEx):
			enumExpr = enumutils.UnwrapEnumExpression(regEx)
		case cbeval.IsRegexpExpression(regEx):
			regEx = cbeval.UnwrapRegexpExpression(regEx)
		}

		for remoteId, v := range idv {
			var (
				res map[string]string
				err error
			)

			if enumExpr != nil {
				if m, ok := v.(map[string]string); ok {
					res, err = enumutils.EnumMatch(enumExpr, m, enumutils.EnumMatchOptions{
						IncludeValues: false,
						ConvertValues: false,
					})

					if err != nil {
						return nil, cberror.NewCbErrorf(
							sfi.Ctx.Service(), 1, err,
							"Failed execute match enum expression: %s", err.Error(),
						)
					}
				} else {
					log.Warn(sfi.Ctx).
						WithBody(sel).
						WithMethod(method).
						Msg("Expected map[string]string when enum expression, skipping")

					continue
				}
			} else {
				if s, ok := v.(string); ok {
					// Run regex on the value
					res, err = regexutils.CachedGroupMatcher(regEx, s)

					if err != nil {
						return nil, cberror.NewCbErrorf(
							sfi.Ctx.Service(), 1, err,
							"Failed to match regex: %s on value: %s", regEx, v,
						)
					}
				}
			}

			if len(res) == 0 {
				continue
			}

			var pc map[string]any

			if pipeCtx == nil {
				pc = map[string]any{}
			} else {
				pc = maps.Clone(pipeCtx)
			}

			for k, v := range res {
				pc[k] = v
			}

			// If we have custom data -> to pc
			if srcVal, ok := src[remoteId]; ok {
				pc["srcsel"] = srcVal
			}

			if len(sel.Custom) > 0 {
				for ck, cv := range sel.Custom {
					if s, ok := cv.(string); ok {
						if cbeval.IsCbEvalExpression(s) {
							// Evaluate the expression
							re, err := cbeval.Evaluate[any](
								sfi.Ctx, cbeval.UnwrapExpression(s),
								pc, true, /*cache*/
								cbeval.EvalCacheLangFullCB,
							)

							if err != nil {
								return nil, cberror.NewCbErrorf(
									sfi.Ctx.Service(), 1, err,
									"Failed to evaluate cbEval expression: %s, err: %s",
									s, err.Error(),
								)
							} else {
								pc[ck] = re
							}
						} else if cv != nil {
							pc[ck] = cv
						}
					}
				}
			}

			if teosID, err := sfi.RenderIdString(sel, pc); err != nil {
				return nil, cberror.FromError(
					sfi.Ctx.Service(), 400, err,
				)
			} else {
				selection = append(selection, providermodel.Selection{
					TeosId:   teosID,
					RemoteId: remoteId,
				})
			}
		}
	}

	return selection, nil
}

// ExtractValuesFromExpression will take an _expr_ whose aim is to extract values from the _src_ map.
//
// The returned map is keyed with the _src_ keys and the value is either a `string` or a `map[string]string`.
//
// Each value can then be used in order to be matched using a regular expression or enum expression.
func (sfi *SourceFunctionInvoker) ExtractValuesFromExpression(
	expr string,
	src map[string]any,
) (map[string]any, cberror.Error) {
	//
	sel, err := cbeval.GlobalEvalCache.GetEval(
		sfi.Ctx, cbeval.UnwrapExpression(expr), cbeval.EvalCacheLangBase,
	)

	if err != nil {
		return nil, err
	}

	result := make(map[string]any, len(src))

	for k, v := range src {
		res, selError := sel(sfi.Ctx, v)

		if selError != nil {
			return nil, cberror.NewCbErrorf(
				sfi.Ctx.Service(), 1, selError,
				"Failed to evaluate filter expression: %s on value: %#v", expr, v,
			)
		}

		if res == nil {
			continue
		}
		if s, ok := res.(string); ok {
			result[k] = s
		} else if m, ok := res.(map[string]any); ok {
			m2 := make(map[string]string, len(m))

			for k, v := range m {
				if v == nil {
					m2[k] = ""
				}

				if s, ok := v.(string); ok {
					m2[k] = s
				} else {
					m2[k] = fmt.Sprintf("%v", v)
				}
			}

			result[k] = m2
		}
	}

	return result, nil
}

func (sfi *SourceFunctionInvoker) RenderIdString(
	sel providermodel.SelectObject,
	captured map[string]any,
) (string, error) {
	if sel.Lang == providermodel.LangTeos || sel.Lang == "" {
		teosID := sel.TeosId

		return teostemplate.RenderTemplate(teosID, captured)
	}

	tmpl, err := templatecache.GlobalTemplateCache.GetOrCompile(sel.TeosId, sel.TeosId)

	if err != nil {
		log.Error(sfi.Ctx).
			WithBody(sel).
			WithMethod("SourceFunctionInvoker::RenderIdString").
			WithError(err).
			Msg("Could not compile template, skipping")

		return "", err
	}

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, captured); err != nil {
		log.Error(sfi.Ctx).
			WithBody(sel).
			WithMethod("SourceFunctionInvoker::RenderIdString").
			WithError(err).
			Msg("Could not execute template, skipping")

		return "", err
	}

	return buf.String(), nil
}
