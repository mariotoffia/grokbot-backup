package providerutils

import (
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// SafeLogPipeContext will remove data that should not be logged from the pipe context.
//
// It sanitizes provider-specific keys (pc, _filter) that contain
// large or sensitive objects before logging.
//
// Use `Msg` or `Msgf` to add a message to the log entry.
func SafeLogPipeContext(event *log.EventWrapper, pipeCtx map[string]any) *log.EventWrapper {
	if !event.IsEnabled() || len(pipeCtx) == 0 {
		return event
	}

	pipeCtx = utils.ShallowCopyMap(map[string]any{}, pipeCtx)
	pipeCtx["pc"] = "**ProviderConfig**"
	pipeCtx["_filter"] = "**Filter**"

	return event.WithBody(pipeCtx)
}
