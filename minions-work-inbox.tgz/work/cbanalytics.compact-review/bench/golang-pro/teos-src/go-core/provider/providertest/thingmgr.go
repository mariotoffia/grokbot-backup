package providertest

import (
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// ProviderTestThingManager encapsulates both device management
// and device shadow management.
//
// The thing and its shadow live in AWS IoT, so the test that uses this needs
// an environment that reaches AWS. Set one up with
// `testenv.Use(t, testenv.EnvUsingManualAWSResources)` before calling `Create`.
type ProviderTestThingManager struct {
	// LID is the lid of the device.
	LID string
	// DeviceManager is the device manager.
	DeviceManager *mgriot.DeviceManagerImpl
	// DSManager is the device shadow manager.
	ShadowManager *mgriot.DSManager
}

// NewProviderTestThingManager creates a new `ProviderTestThingManager` with the
// specified _lid_. If _lid_ is empty, it will generate a random one.
func NewProviderTestThingManager(lid string) *ProviderTestThingManager {
	if lid == "" {
		lid = utils.RandomPostfix("unittest")
	}

	return &ProviderTestThingManager{LID: lid}
}

// Create will create the device and device shadow.
func (ptm *ProviderTestThingManager) Create(ctx ifcore.CbContext) cberror.Error {
	dsmgr, err := CreateDeviceManagerWithThingName(ctx, ptm.LID)

	if err != nil {
		return err
	}

	ptm.DeviceManager = dsmgr

	iotmgr, err := CreateIoTManager(ctx, ptm.LID)

	if err != nil {
		return err
	}

	ptm.ShadowManager = iotmgr

	return ClearDeviceShadow(ctx, ptm.ShadowManager, true /*wait*/)
}

// Destroy will delete the device and device shadow.
func (ptm *ProviderTestThingManager) Destroy() cberror.Error {
	if ptm.ShadowManager != nil {
		_ = ptm.ShadowManager.ClearError().DeleteShadow().Error()
	}

	if ptm.DeviceManager != nil {
		err := ptm.DeviceManager.ClearError().
			DeleteDevice("" /*any version*/, true /*force*/).
			Error()

		if err != nil {
			return err
		}
	}

	return nil
}

// Clear will clear the device shadow. If _wait_ is set to `true`
// it will wait until the shadow is cleared.
func (ptm *ProviderTestThingManager) Clear(ctx ifcore.CbContext, wait bool) cberror.Error {
	return ClearDeviceShadow(ctx, ptm.ShadowManager, wait)
}

// ReportBuilding will report a building payload. If _wait_ is set to `true`, it
// will wait (up to _60 seconds_) until the sensors reported are updated into the device shadow.
func (ptm *ProviderTestThingManager) ReportBuilding(
	ctx ifcore.CbContext,
	ds dsmodel.DsBuilding,
	wait bool,
) cberror.Error {
	//
	payload := jsonutils.ToJSON(ds)

	err := ptm.ShadowManager.ClearError().
		UseReportedStatePayload(payload, "ingest", false /*includeClientToken*/).Error()

	if err != nil {
		return err
	}

	if wait {
		_, _, err = WaitUntilShadowIsUpdated(
			ctx,
			ptm.ShadowManager,
			-1, /*currentVersion*/
			60*time.Second,
			SensorShadowState(ds.Sensors),
			false, /*exactMatch*/
		)
	}

	return err
}

// Report will upsert the deviceshadow as reported state.
// `{ "state": { "reported": <payload> } }`. If _includeClientToken_ is set to
// `true`, it will include the client token with the specified _action_.
func (ptm *ProviderTestThingManager) Report(
	ctx ifcore.CbContext,
	payload []byte,
	action string,
	includeClientToken bool,
) cberror.Error {
	return ptm.ShadowManager.ClearError().
		UseReportedStatePayload(payload, action, includeClientToken).Error()
}

// WaitForStates will wait up to _60 seconds_ to match the specified
// _states_. If timeout, it will return an error. If _exactMatch_ is set
// to `true`, it will check if the _state_ are a exact match. Otherwise
// it will just check that the _states_ are contained in the shadow.
//
// It will return the _version_ of the shadow and nil or error depending
// if it matched or not.
func (ptm *ProviderTestThingManager) WaitForStates(
	ctx ifcore.CbContext,
	states SensorShadowState,
	exactMatch bool,
) (int64, cberror.Error) {
	version, _, err := WaitUntilShadowIsUpdated(
		ctx,
		ptm.ShadowManager,
		-1, /*currentVersion*/
		60*time.Second,
		states,
		exactMatch,
	)

	return version, err
}
