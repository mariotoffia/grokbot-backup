package esvprovider

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"io/fs"
	"net/url"
	"os"
	"strings"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/lambdasupport"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerexecutors"
	"github.com/Thiink-LLC/teos/go-core/pubsub"
	dispatcher "github.com/Thiink-LLC/teos/go-core/tkdisp/cbprovider"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// ESVPlugin drives a `SensorValuesOutboundPlugin`.
type ESVPlugin struct {
	plugin       SensorValuesOutboundPlugin
	pluginCaps   *coremodel.Capabilities
	sessionStore *config.SessionStore
	contextName  string
	provider     string
	reader       *bufio.Reader
}

// NewPlugin creates a new plugin ready for execution.
//
// This accepts the minimal interface `provider.SensorValuesOutboundPlugin` but
// is not usable with that interface. Currently, all plugins must implement `PipelineAwareProvider`
// interface method. Below table outlines the interfaces and their functions.
//
// .Interfaces & Functions
// |===
// |Interface |Functionality
// |PipelineAwareProviderEx
// |Bypasses all functionality around credentials and pipe management. Instead it's own pipe is used
//
// |PipelineCredentialsProvider
// |When the default mechanism is not enough to get and validate credentials.
//
// |PipelineAwareProvider
// |Base functionality for pipeline execution, get templates and target type is a _REQUIREMENT_ to  use `ESVPlugin`.
//
// |InitializationProvider
// |If process initialization and context / session store management is wanted
//
// |Provider
// |Base interface that only provides with capability exposure and the name of the provider / plugin.
//
// |SensorValuesOutboundPluginDsBuilding
// |Handles `dsmodel.DsFullBuilding` sensor value export (includes `PipelineAwareProvider`). If you implement this interface you're good to go.
//
// |===
func NewPlugin(
	plugin SensorValuesOutboundPlugin,
	contextName, provider string,
	reader *bufio.Reader) *ESVPlugin {
	caps := plugin.GetCapabilities()

	return &ESVPlugin{
		contextName: contextName,
		provider:    provider,
		reader:      reader,
		plugin:      plugin,
		pluginCaps:  &caps,
	}

}

// NewDsBuildingPlugin creates an *explicit* `dsmodel.DsBuilding` device shadow based
// export sensor value provider.
//
// Se `NewPlugin` for more details about usage / implementation.
func NewDsBuildingPlugin(
	plugin SensorValuesOutboundPluginDsBuilding,
	contextName, provider string,
	reader *bufio.Reader) *ESVPlugin {
	return NewPlugin(plugin, contextName, provider, reader)

}

// Execute will start the execution. It will in it's turn call `ProviderExecutor`
// and return the error code.
//
// See `ProviderExecutor` for more details.
func (esv *ESVPlugin) Execute() int {
	return providerexecutors.ProviderExecutor(esv, esv.contextName, esv.provider, esv.reader)

}

// endpoint is holder for command line switch _ep_ that may express a *deviceshadow Data-ATS endpoint*.
var endpoint string

// InitFlags adds _ep_ as a `StringVar` to set a remote endpoint with help text
// "Set the device shadow Data-ATS endpoint to be used. Otherwise it is picket up by env CB_REP"
func (esv *ESVPlugin) InitFlags(flagSet *flag.FlagSet) bool {
	add := true
	if esv.pluginCaps.BooleanByName(provider.CapsProviderInitFlags, false) {
		if pb, ok := esv.plugin.(provider.InitializationProvider); ok {
			add = !pb.InitFlags(flagSet)
		}
	}

	if add {
		flagSet.StringVar(
			&endpoint,
			"ep",
			"",
			"Set the device shadow Data-ATS endpoint to be used. Otherwise it is picket up by env CB_REP",
		)
	}

	return true /* allow caller to have own flags */
}

// ContextInitialized resolves any endpoint set in _ep_ switch or overrides using environment variable `CB_REP`
func (esv *ESVPlugin) ContextInitialized(
	context ifcore.CbContext,
	sessionStore *config.SessionStore,
) {
	esv.sessionStore = sessionStore

	if endpoint == "" {
		endpoint = os.Getenv("CB_REP")
	}

	if endpoint != "" {
		if ep, err := url.Parse(endpoint); nil == err {
			context.SetValue(provider.ProviderCtxEndpoint, ep)
		} else {
			panic(fmt.Sprintf("Failed to parse endpoint: %s", endpoint))
		}
	}

	if pb, ok := esv.plugin.(provider.InitializationProvider); ok {
		pb.ContextInitialized(context, sessionStore)
	}
}

// ContextOptions returns the augmented options or the complete replacement of options that will create
// the initial, _static_, `ifcore.CbContext`.
//
// The _current_ is the ones intended to be used to initialize the new `ifcore.CbContext`.
func (sv *ESVPlugin) ContextOptions(
	current []ifcore.CbContextOption,
) (options []ifcore.CbContextOption, replace bool) {
	if pb, ok := sv.plugin.(provider.StaticContextInitializerProvider); ok {
		return pb.ContextOptions(current)
	}

	return nil, false
}

// GetPolicyRetrievalPoints is expected to return zero or more
// `ifcore.PolicyRetrievalPoint` that will be added to the `ifcore.PolicyContext`.
func (sv *ESVPlugin) GetPolicyRetrievalPoints() []ifcore.PolicyRetrievalPoint {
	if pb, ok := sv.plugin.(provider.StaticPRPContributingProvider); ok {
		return pb.GetPolicyRetrievalPoints()
	}

	return nil

}

// GetPDPConfigFSys is expected to return zero or more `fs.FS` that will be scanned
// for _"**-pdp.json"_ object. All other files are ignored.
func (sv *ESVPlugin) GetPDPConfigFSys() []fs.FS {
	if pb, ok := sv.plugin.(provider.StaticPDPContributingProvider); ok {
		return pb.GetPDPConfigFSys()
	}

	return nil

}

// BuildPublishSubscribeManager implements the `provider.PublishSubscribeContributingProvider`
// interface.
func (sv *ESVPlugin) BuildPublishSubscribeManager(builder *pubsub.ManagerBuilder) {
	if pb, ok := sv.plugin.(provider.PublishSubscribeManagerContributingProvider); ok {
		pb.BuildPublishSubscribeManager(builder)
	}

}

// GetPEPConfig gets the `ifcore.PolicyEnforcementPoint` registration for this provider.
func (sv *ESVPlugin) GetPEPConfig() *provider.PEPConfig {
	if pb, ok := sv.plugin.(provider.StaticPEPContributingProvider); ok {
		return pb.GetPEPConfig()
	}

	return nil
}

// SetupDispatchers set up the deispatcher to handle `cbevent.EventTransport`, `apiv1 events.APIGatewayProxyRequest`,
// `apiv2 events.APIGatewayV2HTTPRequest`, and `cbevent.NativeTransport` as `events.SQSEvent`. All of them are
// realized as one `cbevent.SensorValueOutboundEvent` except for _SQSEvent_ of which has a batch of those.
//
// If _provider.ProviderCtxDryRun_ has been set to `true` in _context_, it wil set `SensorValueOutboundEvent.DryRun` to `true`. It
// also tries to extract the _provider.ProviderCtxEndpoint_ as a `*url.URL` (endpoint).
func (esv *ESVPlugin) SetupDispatchers(
	context ifcore.CbContext,
	lambdaType, path string,
) dispatcher.Dispatcher {
	dryrun := utils.GetBoolFromContext(context, provider.ProviderCtxDryRun)
	ep := utils.GetURLFromContext(context, provider.ProviderCtxEndpoint)

	endpoint := ""

	if ep != nil {
		endpoint = ep.String()
	}

	return dispatcher.SetupDispatcher(context, lambdaType, path,
		func(c ifcore.CbContext,
			et cbevent.EventTransport,
			ds cbevent.SensorValueOutboundEvent) error {
			ds.DryRun = dryrun

			if ds.Endpoint == "" {
				ds.Endpoint = endpoint
			}

			return esv.exportSensorValues(c, &ds)
		},
		func(c ifcore.CbContext,
			apiv1 events.APIGatewayProxyRequest,
			ds cbevent.SensorValueOutboundEvent) error {
			ds.DryRun = dryrun

			if ds.Endpoint == "" {
				ds.Endpoint = endpoint
			}

			return esv.exportSensorValues(c, &ds)
		},
		func(c ifcore.CbContext,
			apiv2 events.APIGatewayV2HTTPRequest,
			ds cbevent.SensorValueOutboundEvent) error {
			ds.DryRun = dryrun

			if ds.Endpoint == "" {
				ds.Endpoint = endpoint
			}

			return esv.exportSensorValues(c, &ds)
		},
		func(c ifcore.CbContext,
			native cbevent.NativeTransport,
			ds events.SQSEvent) error {
			return esv.processSQSEvent(c, &ds, endpoint, dryrun)
		},
	)

}

// DoCommand dispatches the `cbevent.SensorValueOutboundEvent` through a _shell_ command.
func (esv *ESVPlugin) DoCommand(context ifcore.CbContext, reader *bufio.Reader) int {
	str, err := lambdasupport.ReadStringFromReader(reader)

	if nil != err {
		fmt.Fprintf(os.Stderr, "Failed to read from stdin error: %s", err.Error()) //nolint:gosec // G705: writing to stderr, not HTTP response
		return -1
	}

	dryrun := utils.GetBoolFromContext(context, provider.ProviderCtxDryRun)

	endpoint := ""

	if ep := utils.GetURLFromContext(context, provider.ProviderCtxEndpoint); ep != nil {
		endpoint = ep.String()
	}

	if strings.Contains(str, `"receiptHandle"`) {
		var ds events.SQSEvent
		if err = json.Unmarshal([]byte(str), &ds); err != nil {
			panic(err.Error())
		}

		err = esv.processSQSEvent(context, &ds, endpoint, dryrun)
		if err != nil {
			panic(err.Error())
		}

		return 0
	}

	var ds cbevent.SensorValueOutboundEvent
	if err := json.Unmarshal([]byte(str), &ds); err != nil {
		panic(err)
	}

	ds.DryRun = dryrun

	if ds.Endpoint == "" {
		ds.Endpoint = endpoint
	}

	err = esv.exportSensorValues(context, &ds)

	if err != nil {
		panic(err.Error())
	}

	return 0
}
