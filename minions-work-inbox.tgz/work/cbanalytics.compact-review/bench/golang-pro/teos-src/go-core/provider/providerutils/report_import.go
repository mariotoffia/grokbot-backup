package providerutils

import (
	"encoding/json"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/reportmodel"
)

// generateImportDataPointReport creates a report from a set of imported data points.
//
// If nothing was imported, `false` is returned.
func generateImportDataPointReport(
	c ifcore.CbContext,
	config *ReportContext,
) *reportmodel.ReportContainerImpl[reportmodel.ImportDataPointReport] {
	includeBody := strings.ToLower(
		config.ProviderConfig.GetParamAsStringWithDefault(
			string(ifprovider.ParameterIncludeBodyInReports),
			"false",
		),
	) == "true"

	if config.Err != nil {
		// If error always output the body
		includeBody = true
	}

	var rm json.RawMessage
	if len(config.Body) > 0 && includeBody {
		rm = json.RawMessage(config.Body)
	}

	var profile string

	if config.ProviderConfig != nil {
		profile = config.ProviderConfig.Profile
	}

	report := reportmodel.ReportContainerImpl[reportmodel.ImportDataPointReport]{
		LocationID: config.ProviderConfig.GetParamAsStringWithDefault(
			string(ifprovider.ParameterLocationID),
			"",
		),
		Provider:   c.Provider(),
		Profile:    profile,
		ReportType: reportmodel.ReportTypeImportDataPointReport,
		Error:      config.Err,
		Body: reportmodel.ImportDataPointReport{
			DataPoints: map[string]reportmodel.RemoteDataPointInfo{},
			Body:       &rm,
		},
	}

	if len(config.DataPoints) > 0 {
		for i := range config.DataPoints {
			dp := config.DataPoints[i]
			cbSensor := toTEOSID(config, dp)

			report.Body.DataPoints[cbSensor] = reportmodel.NewFromCbDataPoint(
				dp,
				config.IsOptional(cbSensor),
			)
		}
	}

	report.Body.Count = len(report.Body.DataPoints)

	return &report
}
