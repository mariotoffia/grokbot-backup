package providerconfig

import (
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
)

// profileFromExpression will use the _pc_ or load a providerconfig from the
// repository and optionally search the profile section for the profile.
//
// If _clone_ is set, the returned profile will be cloned. The _profileExpression_
// may include navigation inside the profile and hence is returned in the _restPath_
// variable.
func (resolver *ProfileResolverImpl) profileFromExpression(
	ctx ifcore.CbContext,
	pc ifprovider.ConfigFull,
	profileExpression string,
	clone bool,
) (foundProfile ifprovider.ConfigProfile, restPath string, err cberror.Error) {
	// Resolve the expression
	var rest string

	file, path := ResolveProfilePointer(profileExpression)

	if file == "" {
		// Local profile - get it from pc variable
		if !strings.HasPrefix(path, "profiles/") {
			// Reference to "static" profile
			return pc, path, nil
		}

		name := strings.TrimPrefix(path, "profiles/")
		parts := strings.SplitN(name, "/", 2)

		if len(parts) == 2 {
			name = parts[0]
			rest = parts[1]
		}

		profile, ok := pc.GetConfigProfile(name)

		if !ok {
			return nil, rest, cberror.NewCbErrorf(
				ctx.Service(), 1, nil, "Profile '%s' not found", profileExpression,
			)
		}

		if clone {
			return utils.ToProfileImpl(profile).Clone(), "", nil
		}

		return profile, rest, nil
	}

	var ok bool
	var providerConfig *providermodel.ProviderConfigImpl

	if clone {
		providerConfig, ok = resolver.repository.GetClone(file)
	} else {
		providerConfig, ok = resolver.repository.GetOriginal(file)
	}

	if !ok {
		return nil, "", cberror.NewCbErrorf(
			ctx.Service(), 1, nil, "Profile '%s' not found", profileExpression,
		)
	}

	if providerConfig == nil {
		return nil, "", cberror.NewCbErrorf(
			ctx.Service(), 1, nil, "Profile '%s' not found", profileExpression,
		)
	}

	if path == "" {
		return providerConfig, rest, nil
	}

	if !strings.HasPrefix(path, "profiles/") {
		// The path is the rest
		return providerConfig, path, nil
	}

	name := strings.TrimPrefix(path, "profiles/")
	parts := strings.SplitN(name, "/", 2)

	if len(parts) == 2 {
		name = parts[0]
		rest = parts[1]
	}

	profile, ok := providerConfig.GetConfigProfile(name)

	if !ok {
		return nil, rest, cberror.NewCbErrorf(
			ctx.Service(), 1, nil, "Profile '%s' not found", profileExpression,
		)
	}

	return profile, rest, nil
}

// resolveReference will resolve a $ref that results in a `map[string]any`.
//
// The _evalContext_ is used when evaluating the expression.
func (resolver *ProfileResolverImpl) resolveReference(ctx ifcore.CbContext,
	pc ifprovider.ConfigFull,
	profileExpression string,
	evalContext map[string]any,
) (map[string]any, cberror.Error) {

	// Check if not expression -> expect on format "profile-name#/path(prms|operation[op].prms|map"
	if !cbeval.IsCbEvalExpression(profileExpression) {
		profile, nav, err := resolver.profileFromExpression(
			ctx, pc, profileExpression, false, /*clone*/
		)

		if err != nil {
			return nil, err
		}

		if nav == "" {
			return nil, cberror.NewCbCompositeErrorf(
				ctx.Service(), 1, nil,
				map[string]any{"pn": ctx.Provider()},
				"Could not resolve '%s' is not a map",
				profileExpression,
			)
		}

		if nav == "map" {
			m := profile.GetMapping()
			res := make(map[string]any, len(m))

			for k, v := range m {
				res[k] = v
			}

			return res, nil
		}

		if nav == "prms" {
			return profile.GetGlobalParams(), nil
		}

		if strings.HasPrefix(nav, "operations/") {
			operation := strings.TrimSuffix(
				strings.TrimPrefix(nav, "operations/"), "/prms",
			)

			if op, ok := profile.GetConfigOperation(operation); !ok {
				return nil, cberror.NewCbCompositeErrorf(
					ctx.Service(), 2, nil,
					map[string]any{"pn": ctx.Provider()},
					"Could not resolve '%s' operation '%s' not found",
					profileExpression, operation,
				)
			} else {
				return op.GetParams(), nil
			}
		}

		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), 2, nil,
			map[string]any{"pn": ctx.Provider()},
			"Failed to use navigation '%s' since it contains unsupported navigation parameters",
			profileExpression,
		)
	}

	if evalContext == nil {
		evalContext = map[string]any{}
	}

	// Make sure that the current eval context contains the provider config
	evalContext[string(ifprovider.PipeContextKeyProviderConfig)] = pc

	// Evaluate the expression
	resolve, err := ToResolverEvaluable(
		ctx,
		resolver.repository,
		cbeval.UnwrapExpression(profileExpression),
	)

	if err != nil {
		return nil, err
	}

	resolvedData, resolveError := resolve(ctx, evalContext)
	if resolveError != nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(),
			2,
			resolveError,
			map[string]any{"pn": ctx.Provider()},
			"Failed to resolve $ref expression '%s' err: %s",
			profileExpression,
			resolveError.Error(),
		)
	}

	if resolvedData == nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), 3, nil, map[string]any{"pn": ctx.Provider()},
			"$ref '%s' not found", profileExpression,
		)
	}

	if resolvedDataMap, ok := resolvedData.(map[string]any); ok {
		return resolvedDataMap, nil
	}

	return nil, cberror.NewCbErrorfWithProps(
		ctx.Service(), 4, nil, map[string]any{"pn": ctx.Provider()},
		"$ref '%s' is not a map[string]any", profileExpression,
	)
}
