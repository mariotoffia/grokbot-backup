package utils_test

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
)

func TestCircuit(t *testing.T) {
	tests := []struct {
		input    any
		expected int
	}{
		// Direct integer values
		{123, 123},
		{0, 0},
		{-5, -5},

		// String containing an integer
		{"42", 42},
		{"0007", 7},

		// TeosID formats
		{"HCT_C1", 1},
		{"HCT_C25", 25},
		{"X_C99", 99},
		{"TEST_C1001", 1001},
		{"PREFIX_C9876", 9876},

		// Incorrect formats
		{"HCT_1C2", -1},  // _C must be followed by a number
		{"HCT_CABC", -1}, // Non-numeric after _C
		{"HCT_C_42", -1}, // _C_ is invalid
		{"HCT_C", -1},    // No number after _C
		{"C5", -1},       // No prefix before _C
		{"_C5", -1},      // Leading underscore invalid

		// Non-string, non-integer inputs
		{nil, -1},
		{true, -1},
		{3.14, 3},
		{[]string{"HCT_C3"}, 3}, // Unsupported type
	}

	for _, test := range tests {
		t.Run("Input: "+fmt.Sprint(test.input), func(t *testing.T) {
			result := utils.Circuit(test.input)
			assert.Equal(t, test.expected, result)
		})
	}
}
