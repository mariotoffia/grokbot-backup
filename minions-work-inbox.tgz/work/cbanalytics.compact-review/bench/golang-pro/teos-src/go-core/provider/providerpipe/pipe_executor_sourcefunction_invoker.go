package providerpipe

import (
	"maps"
	"slices"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// InvokeAndSelectOnSourceFunction will invoke the _source_ and return the loaded data along with (optional) selection.
//
// If it fails it will set the error state and return `nil`.
//
// When selection has been done, the returned src will be filtered to only include the selected items. This may be overridden by
// supplying a _noFilter_ parameter set to `true`.
func InvokeAndSelectOnSourceFunction( /* NOSONAR */
	ctx ifcore.CbContext,
	source SourceFunction,
	pipeContext map[string]any,
	pc *providermodel.ProviderConfigImpl,
	operationName string,
	op *providermodel.Operation,
	credentials any,
	noFilter bool,
) (map[string]any, []providermodel.Selection, []*providerutils.ReportContext, cberror.Error) {
	//
	if source == nil {
		return nil, nil, nil, cberror.NewCbErrorf(
			ctx.Service(), 400, nil,
			"No source function registered",
		)
	}

	if pc == nil {
		return nil, nil, nil, cberror.NewCbErrorf(
			ctx.Service(), cberror.ErrorProviderUnableExecutePipeline, nil,
			"No provider config supplied",
		)
	}

	sfi := SourceFunctionInvoker{
		PipeContext:    pipeContext,
		ProviderConfig: pc,
		OperationName:  operationName,
		Operation:      op,
		Ctx:            ctx,
		Credentials:    credentials,
		SourceFunction: source,
	}

	selectors := pc.GetSelectors()

	// No selection (we don't need key handling since no selector no expansion of map)
	if len(selectors) == 0 {
		if src, _, err := sfi.Invoke(pipeContext, "" /*dataSet*/, nil /*selector*/); err != nil {
			return nil, nil, nil, err
		} else {
			return src, nil, sfi.DelayedReportContexts, nil
		}
	}

	// Run selector(s)
	toMap := func(src map[string]any, key string, selection []providermodel.Selection) map[string]any {
		if len(selection) > 0 {
			src = sfi.Include(src, selection)
		}

		if key == "" {
			return src
		}

		if key == "src" {
			return map[string]any{"src": slices.Collect(maps.Values(src)), "source": src}
		}

		return map[string]any{key: src}
	}

	// Single selector -> optimized route
	if len(selectors) == 1 {
		if src, key, selection, err := sfi.InvokeWithSingleSelector(selectors, pipeContext); err != nil {
			return nil, nil, nil, err
		} else {
			if noFilter {
				return toMap(src, key, nil), selection, sfi.DelayedReportContexts, nil
			}

			return toMap(src, key, selection), selection, sfi.DelayedReportContexts, nil
		}
	}

	// Multiple selection -> run in parallel
	if src, key, selection, err := sfi.InvokeParallel(selectors, pipeContext); err != nil {
		return nil, nil, nil, err
	} else {
		if noFilter {
			return toMap(src, key, nil), selection, sfi.DelayedReportContexts, nil
		}

		return toMap(src, key, selection), selection, sfi.DelayedReportContexts, nil
	}
}
