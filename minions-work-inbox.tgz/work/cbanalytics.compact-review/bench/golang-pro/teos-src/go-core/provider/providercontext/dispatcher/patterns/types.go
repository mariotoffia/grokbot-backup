package patterns

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// BatchTargetError represents an error that happened in the batch target function.
type BatchTargetError struct {
	// Index is the zero based index matching the item.
	Index int
	// Err is the error that happened.
	Err cberror.Error
}

// BatchTargetFunc is the function that will be invoked when a each batch is done. If any errors, return
// those as a slice of `BatchTargetError`.
//
// CAUTION: The errors needs to be returned in a `BatchTargetError.Index` sorted order.
type BatchTargetFunc[TOutput any] func(ctx ifcore.CbContext, items []*TOutput) []BatchTargetError

// SourceFunc is a function that is used by the patterns when a source function that accepts a item
// is needed footnote:[For example, capture the current item in a closure.] instead of extracting
// it from the pipe context event key.
//
// This function is mostly used by providers that are receiving the data from a external source instead
// of the "standard" fetching. In that case, the standard pipeline source function is sufficient.
type SourceFunc[TInput any] func(ctx ifcore.CbContext, item *TInput) (map[string]any, cberror.Error)

// ExecuteOnError specifies what to do when an error happens during pattern execution.
type ExecuteOnError int

const (
	// ExecuteOnErrorUnknown is a unknown state and the default should be used.
	ExecuteOnErrorUnknown ExecuteOnError = 0
	// ExecuteOnErrorContinue will continue the execution. This is equal to _best effort_.
	ExecuteOnErrorContinue ExecuteOnError = 1
	// ExecuteOnErrorStop will stop the execution when the main error happens but not one any
	// of the each individual pipe execution. This is more severe error since this means that the
	// execution of the pipeline(s) was not possible to do at all.
	//
	// NOTE: This will also stop when any of the pipe executions fails.
	ExecuteOnErrorStop ExecuteOnError = 2
	// ExecuteOnErrorPipeExecutionErrorStop will stop the execution when any of the pipe
	// executions fails.
	ExecuteOnErrorPipeExecutionErrorStop ExecuteOnError = 3
)
