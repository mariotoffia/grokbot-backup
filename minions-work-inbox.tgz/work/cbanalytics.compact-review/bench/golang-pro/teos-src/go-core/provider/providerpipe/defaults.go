package providerpipe

import (
	"strconv"
	"strings"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/httputil"
)

// DefaultPartition is a function that splits a string into two parts using a separator.
// If the string is just one part, then the original string is returned.
func DefaultPartition(sep string) providerutils.SplitPartitionAndID {
	return func(s string) (id string, partition string) {
		sq := strings.SplitN(s, sep, 2)
		if len(sq) > 1 {
			return sq[1], sq[0]
		}

		return s, ""
	}
}

// NoopObtainCredentials is a credentials obtainer that does not obtain anything.
// It will just return a dummy.
func NoopObtainCredentials(
	user, pass, apiKey, endpoint string,
	token []byte,
) ObtainCredentialsFunction {
	return func(
		context ifcore.CbContext,
		cred string,
		pipeCtx map[string]any,
		op *providermodel.Operation) (any, int64, cberror.Error) {
		return &securitymodel.TokenCredentialsImpl{
			Credentials: securitymodel.StandardCredentialsImpl{
				Endpoint: endpoint,
				User:     user,
				Password: pass,
				APIKey:   apiKey,
			},
			Token: token,
		}, int64(3600), nil
	}
}

// DefaultObtainCredentials is a common function to obtain credentials using the
// `TokenCredentialsProviderConfig` in conjunction with `ServiceConfig`.
func DefaultObtainCredentials(
	context ifcore.CbContext,
	cred string,
	pipeCtx map[string]any,
	op *providermodel.Operation) (any, int64, cberror.Error) {
	ptr, ttl, ephemeral := cbtransportutils.ParseCredString(cred)

	var cfg securitymodel.TokenCredentialsImpl

	if !ephemeral {
		s := config.New(context).UsePrefix(ptr).GetConfig(&cfg)

		if s.Error() != nil {
			return nil, 0, s.Error()
		}
	} else {
		if cc := cbtransportutils.GetClientCredentialsFromPipeContext(pipeCtx); cc != nil {
			cfg = securitymodel.TokenCredentialsImpl{
				Credentials: *securitymodel.FromClientCredentials(cc),
			}
		}
	}

	if len(cfg.Token) == 0 &&
		len(cfg.Credentials.User) == 0 &&
		len(cfg.Credentials.Password) == 0 &&
		len(cfg.Credentials.ClientID) == 0 &&
		len(cfg.Credentials.ClientSecret) == 0 &&
		len(cfg.Credentials.APIKey) == 0 {
		//
		return nil, 0, cberror.NewCbErrorf(
			context.Service(), cberror.ErrCredentialNotFoundFromCRD,
			nil, "Credentials not found on CRD: %s", ptr,
		)
	}

	var ttl2 int64
	var err error
	switch ttl {
	case "":
		ttl2 = int64(3600) /*default to 1h*/
	default:
		{
			if ttl2, err = strconv.ParseInt(ttl, 10, 64); err != nil {
				return nil, 0, cberror.NewCbErrorf(
					context.Service(), cberror.ErrorProviderUnableToParseTtl, err,
					"Failed to parse ttl string: '%s' to integer, err: %s", ttl, err.Error(),
				)
			}
		}
	}

	return &cfg, ttl2, nil
}

// DefaultVerifyConnect is a common function to verify that the `securitymodel.StandardCredentialsImpl.Endpoint`
// is same as the Operation.Operation Host _DNS_ name.
func DefaultVerifyConnect(
	ctx ifcore.CbContext,
	cred string,
	credentials any,
	op *providermodel.Operation,
) bool {
	if nil == credentials {
		return false
	}

	if op.Operation == "" {
		log.Debug(ctx).
			WithMethod("VerifyConnect").
			WithBody(op).
			Msg("Cannot Verify Connection since operation is empty string, expecting a endpoint address")
	}

	var verify *securitymodel.StandardCredentialsImpl

	if tc, ok := credentials.(*securitymodel.TokenCredentialsImpl); ok {
		verify = &tc.Credentials
	} else if sc, ok := credentials.(*securitymodel.StandardCredentialsImpl); ok {
		verify = sc
	} else {
		log.Warn(ctx).
			WithMethod("VerifyConnect").
			Str("crd", cred).
			Msgf("Expecting TokenCredentialsImpl or StandardCredentialsImpl, got: %T", credentials)

		return false
	}

	verifyEndpoint := httputil.OnlyDNSName(verify.Endpoint)
	operationEndpoint := httputil.OnlyDNSName(op.Operation)
	match := verifyEndpoint == operationEndpoint

	if log.IsEnabled(zerolog.TraceLevel) {
		log.Trace(ctx).
			WithMethod("VerifyConnect").
			Str("crd", cred).
			Str("rep-dns", verifyEndpoint).
			Str("op-dns", operationEndpoint).
			Bool("match", match).
			Msg("Result of verify connect matching")
	}

	return match
}
