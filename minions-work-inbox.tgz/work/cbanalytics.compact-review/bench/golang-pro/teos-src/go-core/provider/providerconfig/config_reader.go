package providerconfig

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
	"github.com/Thiink-LLC/teos/go-core/utils/textutils"
)

// ConfType is the supported config types
type ConfType string

const (
	// ConfTypeUnknown not known or could not be determined
	ConfTypeUnknown ConfType = "unknown"
	// ConfTypeProviderConfig specifies that this is the
	// JSON portion of the ProviderConfiguration
	ConfTypeProviderConfig ConfType = "pcfg"
	// ConfTypeGeneratorTemplate specifies that this is the
	// JSON alike generator template config (named)
	ConfTypeGeneratorTemplate ConfType = "gen"
	// ConfTypeGeneratorPrototype specifies that this is one or more generator prototypes.
	ConfTypeGeneratorPrototype ConfType = "genproto"
	// ConfTypeGeneratorPrototypeTemplate is the template that is used to emit the `ConfTypeGeneratorPrototype` data on.
	ConfTypeGeneratorPrototypeTemplate ConfType = "genprototemplate"
	// ConfTypePipeDefinition specifies that this is the complete
	// pipe JSON definition.
	ConfTypePipeDefinition ConfType = "pipe"
	// ConfTypePolicyData a policy data document that may be loaded into
	// the `pipe.ScopeCtx`.
	ConfTypePolicyData ConfType = "policydata"
	// ConfTypeScript is a script that may be loaded into the `pipe.ScopeCtx` or referenced otherwise in the
	// provider.
	ConfTypeScript ConfType = "script"
)

func (ct ConfType) String() string {
	return string(ct)
}

// ConfTypeFromString converts a string to a ConfType.
func ConfTypeFromString(s string) ConfType {
	switch strings.ToLower(s) {
	case "pcfg":
		return ConfTypeProviderConfig
	case "gen":
		return ConfTypeGeneratorTemplate
	case "genproto":
		return ConfTypeGeneratorPrototype
	case "genprototemplate":
		return ConfTypeGeneratorPrototypeTemplate
	case "pipe":
		return ConfTypePipeDefinition
	case "policydata":
		return ConfTypePolicyData
	case "script":
		return ConfTypeScript
	default:
		return ConfTypeUnknown
	}
}

// CfgItem is a single item of a certain configuration
type CfgItem struct {
	context ifcore.CbContext
	cft     ConfType
	name    string
	buffer  *bytes.Buffer
}

// CreateConfig will assemble a ProviderConfig from the input
// configuration array.
func CreateConfig(items ...*CfgItem) (*providermodel.ProviderConfigImpl, cberror.Error) {
	var pcb *providermodel.ProviderConfigImpl

	for _, itm := range items {
		if itm.cft == ConfTypeProviderConfig {
			i, err := itm.toStruct()
			if nil != err {
				return nil, err
			}
			pcb = i.(*providermodel.ProviderConfigImpl)
			break
		}
	}

	if nil == pcb {
		pcb = &providermodel.ProviderConfigImpl{}
	}

	if nil == pcb.Filter {
		pcb.Filter = map[string]string{}
	}
	if nil == pcb.Generate {
		pcb.Generate = map[string]string{}
		pcb.GenProto = map[string]providermodel.GeneratorPrototypeImpl{}
		pcb.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{}
		pcb.GenProtoTemplates = map[string]string{}
	}
	if nil == pcb.Map {
		pcb.Map = map[string]string{}
	}
	if nil == pcb.Operation {
		pcb.Operation = map[string]providermodel.Operation{}
	}
	if nil == pcb.Params {
		pcb.Params = map[string]interface{}{}
	}
	if nil == pcb.Pipe {
		pcb.Pipe = map[string]string{}
	}
	if pcb.PolicyData == nil {
		pcb.PolicyData = map[string]string{}
	}
	if pcb.Script == nil {
		pcb.Script = map[string][]byte{}
	}

	for _, itm := range items {
		switch itm.cft {
		case ConfTypeProviderConfig:
			continue /* already handled, duplicate skipped */
		case ConfTypeGeneratorTemplate:
			pcb.Generate[itm.name] = itm.buffer.String()
		case ConfTypeGeneratorPrototypeTemplate:
			pcb.GenProtoTemplates[itm.name] = itm.buffer.String()
		case ConfTypeGeneratorPrototype:

			p, pts, err := itm.unmarshalGeneratorPrototype()

			if err != nil {
				return nil, err
			}

			if len(p) > 0 {
				pcb.GenProto[itm.name] = p
			}
			if len(pts) > 0 {
				pcb.GenProtoTs[itm.name] = pts
			}

		case ConfTypePipeDefinition:
			pcb.Pipe[itm.name] = itm.buffer.String()
		case ConfTypePolicyData:
			pcb.PolicyData[itm.name] = itm.buffer.String()
		case ConfTypeScript:
			pcb.Script[itm.name] = itm.buffer.Bytes()
		default:
			return nil, cberror.NewCbErrorf(
				itm.context.Service(),
				cberror.ErrorProviderUnknownCfg,
				nil,
				"unknown config type: '%s'",
				itm.cft,
			)
		}
	}

	return pcb, nil
}

// unmarshalGeneratorPrototype will parse a block of generator prototypes and create `GeneratorPrototype`
// of which is returned.
//
// If the _item_ is not a `ConfTypeGeneratorPrototype` it will return an empty `GeneratorPrototype`.
//
// It will use the `CfgItem.buffer` to parse the segment where the format _"ID: genexpr"_ where first
// colon is the separator between the _ID_ and generator expression.
//
// If the Row starts with :TS: it is treated as a sensor timestamp expression instead. This can be used
// in the genproto template as _sensorts_ section.
//
// CAUTION: No support for multiline generator expressions. Each ID and expression *must* be on same line!
//
// If any errors occurs, it is returned.
//
// .Sample Generator Prototypes
// ====
// * IDT: float64(generate[{{ID}}].Value)
// * IDT_O1: float64(generate["IDT_O1"].Value)
// * *: float64(generate[{{ID}}].Value)
// * :TS:IDT: generate[{{ID}}].TimeStamp
// * :TS:IDT_O1: generate["IDT_O1"].TimeStamp
// * :TS:*: generate[{{ID}}].TimeStamp
// ====
func (item *CfgItem) unmarshalGeneratorPrototype() (
	providermodel.GeneratorPrototypeImpl, /*value*/
	providermodel.GeneratorPrototypeImpl, /*ts*/
	cberror.Error) {
	proto := providermodel.GeneratorPrototypeImpl{}
	protots := providermodel.GeneratorPrototypeImpl{}

	r := bufio.NewReader(item.buffer)

	var err error
	var ln []byte
	var ists bool
	var parts [][]byte

	separator := []byte(":")
	tsprefix := []byte(":TS:")
	gentrim := " \r\n"

	for {
		ln, _, err = r.ReadLine()

		if err != nil {
			break
		}

		ists = false
		if bytes.HasPrefix(ln, tsprefix) {
			ists = true
			parts = bytes.SplitN(ln[4:], separator, 2)
		} else {
			parts = bytes.SplitN(ln, separator, 2)
		}

		// Empty Line?
		if len(parts) == 1 && len(parts[0]) == 0 {
			continue
		}

		if len(parts) != 2 {
			return nil, nil, cberror.NewCbErrorf(
				item.context.Service(),
				1,
				nil,
				"invalid generator prototype: '%s' expecting format ID: expr (e.g. '*: generate[\"{{ID}}\"].Value')",
				string(ln),
			)
		}

		id := bytes.TrimSpace(parts[0])

		if ists {
			protots[string(id)] = string(bytes.Trim(parts[1], gentrim))
		} else {
			proto[string(id)] = string(bytes.Trim(parts[1], gentrim))
		}
	}

	return proto, protots, nil
}

// ReadConfig reads the in param configuration string on the configuration format
// and returns an array of `CfgItems`.
//
// The format is
// |===
// |Command |Comment
//
// |--<config type>[=<name>]
// |New Line via LF or CR LF
//
// |{ JSON config }
// |
//
// |--<config type>[=<name>]
// |New Line via LF or CR LF
//
// | ...
// | Until EOF
// |===
//
// .Example
// ****
// --gen=device-shadow +
// { ... } +
// EOF
// ****
//
// When the first item is just a _JSON_ payload, it is regarded as `ProviderConfiguration`
// hence it is possible to only provide with a _JSON_ payload and no other directives if
// the generator templates etc are stringified.
func ReadConfig(context ifcore.CbContext, cfg string) ([]*CfgItem, cberror.Error) {
	r := bufio.NewReader(strings.NewReader(cfg))

	// Overcome the 4096 max buffer size
	read := func() ([]byte, error) {
		var res []byte

		for {
			tmp, err := r.ReadSlice('\n')

			if errors.Is(err, bufio.ErrBufferFull) {
				res = append(res, tmp...)
				continue
			}

			if len(res) == 0 {
				if len(tmp) > 0 && tmp[len(tmp)-1] == '\n' {
					tmp = tmp[:len(tmp)-1]
				}
				return tmp, err
			}

			res = append(res, tmp...)
			if res[len(res)-1] == '\n' {
				res = res[:len(res)-1]
			}
			return res, err
		}
	}

	items := []*CfgItem{}

	var buff *CfgItem
	var err error
	var ln []byte

	allowComments := true

	for {
		ln, err = read()

		if allowComments && len(ln) > 1 && ln[0] == '/' && ln[1] == '/' {
			// Skip comments in the beginning of the profile, then it is verboten!
			continue
		} else {
			allowComments = false
		}

		if len(ln) == 0 && err != nil {
			if nil != buff {
				items = append(items, buff)
			}

			break
		}

		if len(ln) == 0 && nil == buff {
			continue
		}

		ct, name := commandParser(ln)

		if nil == buff && ct == ConfTypeUnknown {
			// Special case where no directive == one ProviderConfiguration only
			ct = ConfTypeProviderConfig
			buff = newConfigItem(context, name, ct)
			buff.buffer.Write(ln)
			buff.buffer.WriteByte('\n')
			continue
		}

		if ct != ConfTypeUnknown {
			if nil != buff {
				items = append(items, buff)
			}

			buff = newConfigItem(context, name, ct)
			continue
		}

		buff.buffer.Write(ln)
		buff.buffer.WriteByte('\n')
	}

	if !errors.Is(err, io.EOF) {
		if l, ok := logger.ClsLog(zerolog.WarnLevel, "ReadConfig", logger.LDTUntyped, logger.LISUnclassified, context); ok {
			l.Msgf("Error while reading config '%s', error: %s", cfg, err.Error())
		}

		return nil, cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToReadCfg, err,
			"Error while reading config '%s', err: %s", cfg, err.Error(),
		)
	}

	return items, nil
}

// ReadConfigAny will use the `ReadConfig` but first it will ensure that the
// _cfg_ is a string or can be converted to a string.
func ReadConfigAny(context ifcore.CbContext, cfg any) ([]*CfgItem, cberror.Error) {
	if cfg == nil {
		return nil, cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToReadCfg, nil,
			"Unable to read config, got nil",
		)
	}

	switch v := cfg.(type) {
	case string:
		return ReadConfig(context, v)
	case *string:
		return ReadConfig(context, *v)
	case []byte:
		return ReadConfig(context, string(v))
	case *[]byte:
		return ReadConfig(context, string(*v))
	case json.RawMessage:
		return ReadConfig(context, string(v))
	case *json.RawMessage:
		return ReadConfig(context, string(*v))
	case map[string]any:
		if data, err := json.Marshal(v); err != nil {
			return nil, cberror.NewCbErrorf(
				context.Service(), cberror.ErrorProviderUnableToReadCfg, err,
				"Unable to marshal config, err: %s", err.Error(),
			)
		} else {
			return ReadConfig(context, string(data))
		}
	default:
		return nil, cberror.NewCbErrorf(
			context.Service(), cberror.ErrorProviderUnableToReadCfg, nil,
			"Unable to read config, expected string, []byte, map[string]any, got: %T", v,
		)
	}
}

// LoadConfigByOperation will load the provider configuration specified by the operation.
// If not found it will return `nil`, `nil` since it is not considered as an error.
func LoadConfigByOperation(
	ctx ifcore.CbContext,
	op string,
	m map[string]any,
) (*providermodel.ProviderConfigImpl, cberror.Error) {
	if op, ok := m[string(op)]; ok && op != nil {
		if cfg, err := ReadConfigAny(ctx, op); err != nil {
			return nil, cberror.NewCbErrorf(
				ctx.Service(), http.StatusInternalServerError, err,
				"LoadConfigByOperation::failed to read provider config, err: %s", err.Error(),
			)
		} else {
			if pc, err := CreateConfig(cfg...); err != nil {
				return nil, err
			} else {
				return pc, nil
			}
		}
	}

	return nil, nil
}

// WriteConfigByOperation will write to _m_ with key _op_ by using config writer.
//
// It will first try to make a map of it, if it fails, it will make the config to
// a string.
func WriteConfigByOperation(
	ctx ifcore.CbContext,
	pc *providermodel.ProviderConfigImpl,
	op string,
	m map[string]any,
) cberror.Error {
	//
	s := NewConfigWriter(ctx).
		AddProviderConfig(pc).
		Write().
		Buffer.String()

	if s == "" {
		return cberror.NewCbErrorf(
			ctx.Service(), http.StatusInternalServerError, nil,
			"WriteConfigByOperation::failed to write provider config, empty result",
		)
	}

	data, err := jsonutils.FromJSONToMap(s)

	if err != nil {
		return cberror.FromError(ctx.Service(), 400, err)
	}

	if data != nil {
		m[op] = data
	} else {
		m[op] = s
	}

	return nil
}

func commandParser(ln []byte) (ConfType, string) {
	if len(ln) < 2 {
		return ConfTypeUnknown, ""
	}

	if ln[0] == '-' && ln[1] == '-' {
		parts := bytes.SplitN(ln[2:], []byte("="), 2)

		if len(parts) == 0 {
			return ConfTypeUnknown, ""
		}

		var name string
		if len(parts) == 2 {
			name = string(parts[1])
		}

		return ConfTypeFromString(string(parts[0])), name
	}

	return ConfTypeUnknown, ""
}

// postInitProviderConfigImpl will perform post initialization of the provider config
func postInitProviderConfigImpl(
	context ifcore.CbContext,
	pcb *providermodel.ProviderConfigImpl,
) *providermodel.ProviderConfigImpl {
	// Expand MID
	if mid, ok := pcb.GetParamAsString("MID"); ok {
		if s, err := textutils.ExpandJoin(mid, " "); err == nil {
			pcb.Params["MID"] = s
		} else {
			if l, ok := logger.ClsLog(
				zerolog.WarnLevel, "ProviderConfig", logger.LDTDevOps, logger.LISUnclassified, context,
			); ok {
				logger.LogObjectf(l, "err", err, "Error while expanding mid: %s", mid)
			}
		}
	}

	return pcb
}

// toStruct converts the byte buffer to it's corresponding
// struct.
func (cfg *CfgItem) toStruct() (interface{}, cberror.Error) {
	switch cfg.cft {
	case ConfTypeGeneratorTemplate:
		return cfg.buffer.String(), nil
	case ConfTypePipeDefinition:
		return cfg.buffer.String(), nil
	case ConfTypeProviderConfig:

		var pcb providermodel.ProviderConfigImpl
		if err := json.Unmarshal(cfg.buffer.Bytes(), &pcb); nil != err {
			data := cfg.buffer.Bytes()

			return nil, cberror.NewCbErrorConfigurationValidationErrorf(
				cfg.context.Service(),
				cberror.ConfigurationErrorTypeUnknown,
				cberror.ErrorProviderUnableToUnmarshalCfg,
				data,
				err,
				map[string]any{
					cberror.PropertyProvider: cfg.context.Provider(),
				},
				"Failed to unmarshal provider config: %s, detailed problem:'%s'",
				err.Error(),
				jsonutils.ToSpecificJSONErrorText(data, err),
			)
		}

		return postInitProviderConfigImpl(cfg.context, &pcb), nil
	case ConfTypePolicyData:
		return cfg.buffer.String(), nil
	case ConfTypeScript:
		return cfg.buffer.Bytes(), nil
	}

	return nil, cberror.NewCbErrorf(
		cfg.context.Service(), cberror.ErrorProviderUnableToCreateCfg, nil,
		"Failed to create struct from a '%s' config type", cfg.cft)
}

func newConfigItem(context ifcore.CbContext, name string, cft ConfType) *CfgItem {
	return &CfgItem{
		context: context,
		cft:     cft,
		name:    name,
		buffer:  bytes.NewBufferString(""),
	}
}
