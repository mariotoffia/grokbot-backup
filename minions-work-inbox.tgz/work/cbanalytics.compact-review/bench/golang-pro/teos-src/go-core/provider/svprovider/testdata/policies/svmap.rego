# Worked example: translating sensor readings with a policy.
#
# Every rule below produces an "obligation". An obligation names a path in the
# document the pipeline built and either deletes what is there or writes a new
# value in its place. That is the same mechanism the range check has always used
# to drop a bad reading -- writing a value uses it in the other direction.
#
# Two things are worth knowing before reading on:
#
#   * A rule that does not fire writes nothing and fails nothing. Missing input
#     is not an error.
#   * Every rule reads the document exactly as it arrived. A rule never sees the
#     edits another rule made, so a rule that must ignore a bad reading has to
#     say so itself. That is why the averaging rule at the bottom repeats the
#     range check rather than assuming the dropping rule ran first.

package svmap

# ---------------------------------------------------------------------------
# 1. Drop a reading that is outside the range configured for it.
#
#    This is the long-standing job of the policy step. The ranges live in the
#    provider configuration under --policydata, not in this file, so a building
#    can be given different limits without changing any code.
# ---------------------------------------------------------------------------
obligation[sensor] := ob if {
	some sensor, value in input.sensors

	not usable(sensor, value)

	ob := {
		"deny": $"{sensor}: {value} is outside its configured range",
		"remove": $"sensors.[{sensor}]",
		"report": "report",
		"infosec": "plc",
	}
}

# ---------------------------------------------------------------------------
# 2. Correct a reading by the calibration offset configured for it.
#
#    A sensor that reads consistently high or low is corrected here rather than
#    in the generator expressions, because the offset belongs to the building
#    and not to the provider.
# ---------------------------------------------------------------------------
obligation[key] := ob if {
	some sensor, value in input.sensors

	usable(sensor, value)

	offset := data.calibrate[sensor]

	key := $"calibrate-{sensor}"

	ob := {
		"deny": $"{sensor} corrected by {offset}",
		"remove": $"sensors.{sensor}",
		"alter": value + offset,
		"report": "silent",
		"infosec": "plc",
	}
}

# ---------------------------------------------------------------------------
# 3. Derive the temperature drop across the heat exchanger.
#
#    A generator expression cannot do this. It sees one reading at a time and
#    has no way to reach the neighbouring reading.
#
#    A return line warmer than the flow line is a sensor fault, not a negative
#    drop, so the result is never allowed below zero.
# ---------------------------------------------------------------------------
obligation["derive-delta"] := ob if {
	flow := input.sensors.MPST

	usable("MPST", flow)

	return_line := input.sensors.MPRT
	usable("MPRT", return_line)

	ob := {
		"deny": "DELTA derived from the flow and return temperatures",
		"remove": "sensors.DELTA",
		"alter": max([flow - return_line, 0]),
		"report": "silent",
		"infosec": "plc",
	}
}

# ---------------------------------------------------------------------------
# 4. Derive the building indoor temperature from every indoor reading.
#
#    The rule does not know in advance how many indoor sensors a building has
#    or what they are called. It selects them by the shape of their name and
#    averages whatever it finds, ignoring any reading the range check would
#    have dropped.
# ---------------------------------------------------------------------------
indoor[sensor] := value if {
	some sensor, value in input.sensors

	startswith(sensor, "IDT_")

	usable(sensor, value)
}

obligation["derive-idt"] := ob if {
	readings := [value | some value in indoor]

	count(readings) > 0

	average := sum(readings) / count(readings)

	ob := {
		"deny": sprintf("IDT averaged from %d indoor readings", [count(readings)]),
		"remove": "sensors.IDT",
		"alter": round(average * 10) / 10,
		"report": "silent",
		"infosec": "plc",
	}
}

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

# usable holds when the reading is a number and, if a range is configured for
# it, the number falls inside that range. A reading the provider could not
# collect arrives as the text "$error" and is never usable.
usable(sensor, value) if {
	is_number(value)

	limits := range_for(sensor)

	value >= limits[0]
	value <= limits[1]
}

usable(sensor, value) if {
	is_number(value)

	not range_for(sensor)
}

range_for(sensor) := limits if {
	some pattern, limits in data.range

	glob.match(pattern, ["_"], sensor)
}
