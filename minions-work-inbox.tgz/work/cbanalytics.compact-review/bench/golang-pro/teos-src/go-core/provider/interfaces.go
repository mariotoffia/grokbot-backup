package provider

import (
	"bufio"
	"flag"
	"io/fs"

	"github.com/Thiink-LLC/teos/go-core/cbpolicy/pep"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	dispatcher "github.com/Thiink-LLC/teos/go-core/tkdisp/cbprovider"
)

const (
	// CapsProviderInitFlags denotes that the provider or plugin supports `InitFlags` function.
	CapsProviderInitFlags string = "provider.InitFlags"
	// CapsProviderCreatePipeLine specifies that the provider or plugin supports a custom pipeline
	// creation instead of the default.
	CapsProviderCreatePipeLine string = "provider.CreatePipeLine"
	// CapsProviderObtainCredentials specifies that the provider or plugin has its own function to obtain credentials
	CapsProviderObtainCredentials string = "provider.ObtainCredentials"
	// CapsProviderVerifyCredentialUsage specifies that the provider do has its own function to verify that
	// the credentials may be used.
	CapsProviderVerifyCredentialUsage string = "provider.VerifyCredentialUsage"
	// CapsProviderPipelineOverrideContext is exposed by providers / plugins that take care of all context management
	// when setup the pipe.
	CapsProviderPipelineOverrideContext string = "provider.pipe.PipelineOverrideContext"
	// CapsProviderVerifyConfig specifies that the provider supports static verification of configuration.
	CapsProviderVerifyConfig string = "provider.VerifyConfig"
	// CapsProviderVerifyConfigEx is exposed by providers / plugins override CapsProviderVerifyConfig.
	// The provider take care of all static verification of configuration by itself.
	CapsProviderVerifyConfigEx string = "provider.VerifyConfigEx"
)

const (
	// ProviderCtxEndpoint is the `url.URL`, if set, contained in the `ifcore.CbContext` set by
	// _ep_ command switch or `CB_REP` environment variable.
	ProviderCtxEndpoint string = "endpoint"
	// ProviderCtxDryRun is set using the command switch _dryrun_. This means that the code
	// should execute but not alter any state such as changing device shadow or posting data
	// from external endpoint. Instead it should get data from data sources and output the
	// process including log the state changes it should have done.
	ProviderCtxDryRun string = "dryrun"

	// ProviderVerifyConfigStatic if set, the provider configuration will be statically verified
	// using a schema provider by the provider. Mandatory attributes values will be checked.
	// TZ - has to be present and of iana timezone format.
	// OID - has to be set to an owner ID: "all" or an organization ID such as "skebo" or
	// "thiink.us" (see coremodel.ValidateOwnerID).
	ProviderVerifyConfigStatic string = "verifyconfigstatic"
)

// Provider is a base interface for all provider / plugins in order to query the provider plugin for it's capabilities
// and the provider name.
//
// A `DispatcherProvider` is not required to implement this interface but should as a good convention.
type Provider interface {
	// Caps is to let a plugin expose its capabilities and hence how it is invoked.
	ifcore.Caps
	// Name exposes the name of the provider or plugin.
	Name() string
}

// PipelineAwareProvider handles pipeline creation
type PipelineAwareProvider interface {
	// OverrideContext can be overridden if the _CapsProviderPipelineOverrideContext_ is specified.
	//
	// If the provider do not specify _CapsProviderPipelineOverrideContext_ it will get the `GetTargetType()` invoked instead.
	//
	// .Sample Context Override
	// [source,go]
	// ----
	// return map[string]interface{}{ // <1>
	//		"_ts": map[string]interface{}{"esv": &UpdateDataPointList{}}, <2>
	//	}
	// ----
	// <1> This is the main context and you may add any key value pair.
	// <2> This is the pre-defined _types_ where it expects to find a type based on the operation to marshal the target as.
	OverrideContext() map[string]interface{}
	// GetTargetType shall return an instance of the target to marshal at the end of the pipeline.
	//
	// .Sample Target
	// [source,go]
	// ----
	// return &UpdateDataPointList{} <1>
	// ----
	// <1> Note, that you *SHOULD* return a pointer to your instance!
	//
	// The instance will be keyed in the pipeline context, under key \_ts and named as the operation e.g. _esv_ or _sv_ (
	// _see `OverrideContext()` for more information_).
	GetTargetType() interface{}
}

// ProviderPipelineTypeContributor is a provider that adds types that will be will be keyed in the `pipe.ScopeCtx`, as
// a sub-key under \_ts.
type ProviderPipelineTypeContributor interface {
	// GetTypes expects a plain name of the type, that will be registered as subkey under \_ts in `pipe.ScopeCtx`
	// and the value is a pointer to the type.
	//
	// .Sample Registration
	// [source,go]
	// ----
	// return map[string]interface{}{
	// 	"esv": &UpdateDataPointList{},
	// 	"ds": &dsmodel.DsFullBuilding{},
	// }
	// ----
	//
	// In the above example the `pipe.ScopeCtx` will contain _esv_ and _ds_ as sub-keys to \_ts and hence can be referenced
	// both in code or in _JSON_ pipelines.
	//
	// .Example Usage
	// [source,json]
	// ----
	// {
	// 	"test-pipe": {
	// 		"set-src": {
	// 			"sensorvalues": "=asmap(src.Sensors, 'ID')"
	// 		},
	// 		"marshal-ds": {
	// 			"filtered": "=marshal(_ts.ds, filtered)" // <1>
	// 		},
	// 		"gen-out": {
	// 			"key": "target",
	// 			"from": "=gen_template"
	// 		}
	// 	}
	// }
	// ----
	// <1> In here _marshal_ references a type registered under \_ts.ds.
	GetTypes() map[string]interface{}
}

// ProviderFilterFunctionContributor is when a provider can contribute with
// filter functions to be used in the provider and the provider pipeline.
//
// From the pipeline `filter` function do take a name parameter that is used
// to lookup the filter function to use to filter the data.
//
// .Sample Usage
// [source,json]
//
//	"set-filtered": { "target": "=filterf(_filter['my-filter'], target)" }
//
// The above will take the object in the pipe context _target_ property and
// submit it to the `filter` function that uses the operation stored in
// the _config.operation key and the filter function named _my-filter_.
// It will then assign it to the context property _target_ (hence replace it).
type ProviderFilterFunctionContributor interface {
	// GetFilterFunctions returns all filter functions that has a specific name.
	//
	// Each `OperationFilters` are keyed by the operation name. If unnamed, filters
	// may apply to any operation.
	GetFilterFunctions() map[string]ifprovider.OperationFilters
}

// ProviderConfigurationFileSystemProvider is implemented by providers want
// to expose a filesystem to be queried for templates.
//
// This configuration expects the object on the filesystem be of type `providermodel.ProviderConfigImpl`.
type ProviderConfigurationFileSystemProvider interface {
	// GetProviderConfigurationFileSystemObject is implemented to return a `fs.FS` object that may work during
	// the lifetime of the provider.
	GetProviderConfigurationFileSystemObject() fs.FS
}

// StaticPRPContributingProvider is a provider that will contribute a set of `ifcore.PolicyRetrievalPoint`
// instances to build up a `ifcore.PolicyContext`.
//
// This is invoked at startup time, just before `StaticContextInitializerProvider` operations are invoked to add `cbpolicy.OptSubContext`
// for these _PRP_.
type StaticPRPContributingProvider interface {
	// GetPolicyRetrievalPoints is expected to return zero or more
	// `ifcore.PolicyRetrievalPoint` that will be added to the `ifcore.PolicyContext`.
	GetPolicyRetrievalPoints() []ifcore.PolicyRetrievalPoint
}

// StaticPDPContributingProvider is a provider that will contribute `pdp.PDPConfig` via `fs.FS` objects.
//
// This is invoked at startup time, just before `StaticContextInitializerProvider` operations are invoked to add `cbpolicy.OptSubContext`
// for these `pdp.PDPConfig` objects.
type StaticPDPContributingProvider interface {
	// GetPDPConfigFSys is expected to return zero or more `fs.FS` that will be scanned
	// for _"**-pdp.json"_ object. All other files are ignored.
	GetPDPConfigFSys() []fs.FS
}

// PEPConfig is used in `StaticPEPContributingProvider` to do registration
type PEPConfig struct {
	// Category can be set if different types of _PEP_ is wanted.
	//
	// Leave it for default registration.
	Category string
	// IsWrapper is by default disabled. Set this to `true` to use wrapper capability in the `PolicyEnforcementPoint`
	IsWrapper bool
	// Registration of enforcement points.
	//
	// At minimum the registration needs a path, method, function, in and out parameters.
	//
	// .Example Registration
	// [source,go]
	// ----
	// map[string]PEPRegistration{
	// 	"path/to/MyFunc": {
	// 		Operation:  coremodel.OperationPost,
	// 		Function:   myFunc,
	// 		Parameters: []string{"c", "name", "dir", "oid"}, // <1>
	// 		Returns:    []string{"output", "err"}, // <2>
	// 	},
	// }
	// ----
	// <1> If wrapper generation is enabled, the first parameter needs to be `ifcore.CbContext`.
	// If wrapper generation is enabled and you wish to get invoked when needs to solve obligations,
	// second parameter needs to be `*policymodel.PDPResponse`.
	// <2> If wrapper generation is enabled, the last parameter needs to be `error` in order for the interceptor to return errors.
	Registration map[string]pep.PEPRegistration
}
type StaticPEPContributingProvider interface {
	// GetPEPConfig gets the `ifcore.PolicyEnforcementPoint` registration for this provider.
	GetPEPConfig() *PEPConfig
}

// StaticContextInitializerProvider can be exposed by a provider that want to augment `ifcore.CbContext` initialization
// or completely replace those.
type StaticContextInitializerProvider interface {
	// ContextOptions returns the augmented options or the complete replacement of options that will create
	// the initial, _static_, `ifcore.CbContext`.
	//
	// The _current_ is the ones intended to be used to initialize the new `ifcore.CbContext`.
	ContextOptions(
		current []ifcore.CbContextOption,
	) (options []ifcore.CbContextOption, replace bool)
}

// InitializationProvider is when a provider or plugin wishes to participate in the static initialization of the provider.
type InitializationProvider interface {
	// InitFlags gets invoked when provider / plugin has _CapsProviderInitFlags_.
	//
	// A provider / plugin may add flags to the _flagSet_. If it return false, the plugin states that the
	// executor shall not add any flags on its own.
	//
	// .Example Adding a Bucket Parameter
	// [source,go]
	// ----
	// var bucket // <1>
	// func (my *MyProvider) InitFlags(flagSet *flag.FlagSet) bool { // <2>
	//
	//   	flagSet.StringVar(&bucket, "bucket", "", "Config Bucket") // <3>
	//
	//      return false // <4>
	// }
	// ----
	// <1> You must declare a variable as receiver
	// <2> The `InitFlags` gets called after initialization of standard flags
	// <3> Adding *additional* flags to the existing set.
	// <4> By returning `false`, no other flags is added to the system (some providers may have default flags otherwise).
	//
	// Since this function is invoked early when the system initializes, this allows a plugin / provider
	// to initialize on it's own.
	InitFlags(flagSet *flag.FlagSet) bool
	// ContextInitialized is invoked when the Thiink Context has successfully
	// been initialized to perform some setup logic that requires the context.
	//
	// Providers that do not make use of _sessionStore_ will receive `nil` instead
	// of a valid session store.
	//
	// .Context Variables From Initialization
	// |===
	// |Name |Type |Comment
	// |ProviderCtxEndpoint |*url.URL |If set in ep switch or `CB_REP` environment variable
	// |ProviderCtxDryRun |bool |It is set to _true_ if dry run, otherwise missing or _false_.
	//
	// |===
	//
	// This function is called after the _flagSet_ in `InitFlags()` has been called, thus it is
	// a good time to store switches into the _context_.
	ContextInitialized(context ifcore.CbContext, sessionStore *config.SessionStore)
}

// InstanceProvider represents a provider instance where it can initialize and dispatch to plugins, plain lambdas
// via command line or via thiink dispatcher.
type InstanceProvider interface {
	// InitializationProvider has functions that most providers need. If not used, just use empty function bodies.
	InitializationProvider
	// SetupDispatchers request the provider to register the lambda receiver function(s) and
	// return the dispatcher.
	//
	// This is only invoked when the _lambdaType_ is not equal an empty string. If no dispatcher
	// is returned, the runtime will register its own lambdas and dispatch on a plugin interface.
	//
	// This is to override the main functionality and skip plugin interfaces all together. When
	// a dispatcher is returned, it will not invoke the `DoCommand` function instead it will invoke
	// the lambda start function that locks and dispatches.
	SetupDispatchers(context ifcore.CbContext, lambdaType, path string) dispatcher.Dispatcher
	// DoCommand should execute as a _shell_ command.
	//
	// In order to get the data, if any, from the _reader_ use the `lambdasupport.ReadStringFromReader(reader)`
	// to get it as a complete string.
	//
	// This function is expected to run and return an error code, where zero is _OK_.
	DoCommand(context ifcore.CbContext, reader *bufio.Reader) int
}
