package providerpipe

import (
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
)

// AuthenticateFunction is a function that recieves a context and the credentials gotten from _AWS_ via the _CRD_ pointer
// in the configuration. It should return the credentials to be used for the provider along with any _TTL_ that the auth
// function passes.
type AuthenticateFunction func(ctx ifcore.CbContext, authCredentials any) (credentials any, ttl int64, err cberror.Error)

// PipelineBuilder will build a provider pipeline that later can be executed to perform the
// actual work.
type PipelineBuilder struct {
	ctx      ifcore.CbContext
	err      cberror.Error
	pipeline ProviderPipelineImpl
	auth     AuthenticateFunction
	hasBuilt bool
}

// NewPipelineBuilder returns a new `PipelineBuilder` instance.
func NewPipelineBuilder(ctx ifcore.CbContext) *PipelineBuilder {
	pb := &PipelineBuilder{
		ctx: ctx,
		pipeline: ProviderPipelineImpl{
			operations:        make(map[string]ProviderPipeImpl),
			batchSize:         10,
			timeout:           30 * time.Second,
			parallelThreshold: 0,
		},
	}

	// Defaults
	pb.pipeline.pipeExecutorCreatorFunc = DefaultPipelineExecutorForOperationRequest()

	return pb
}

// Clone creates a copy of the builder. However, it creates a shallow copy
// of most of the data. However, it will deep clone the operations map.
func (b *PipelineBuilder) Clone() *PipelineBuilder {
	pb := &PipelineBuilder{
		ctx:      b.ctx,
		err:      b.err,
		pipeline: b.pipeline,
		auth:     b.auth,
		hasBuilt: b.hasBuilt,
	}

	if len(pb.pipeline.operations) > 0 {
		pb.pipeline.operations = make(map[string]ProviderPipeImpl, len(b.pipeline.operations))

		for k, v := range b.pipeline.operations {
			pb.pipeline.operations[k] = *(&v).Clone(&pb.pipeline)
		}
	}

	return pb
}

// Error implements the `ifcore.ErrorHandler` interface
func (b *PipelineBuilder) Error() cberror.Error {
	return b.err
}

// ClearError implements the `ifcore.ErrorHandler` interface
func (b *PipelineBuilder) ClearError() {
	b.err = nil
}

func (b *PipelineBuilder) Build() *ProviderPipelineImpl {
	// Check if in error state
	if b.err != nil {
		return nil
	}

	// Check if already built
	if b.hasBuilt {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), 1, nil, map[string]any{"pn": b.ctx.Provider()},
			"Builder::Build already built",
		)

		return nil
	}

	// Check so a repository is set
	if b.pipeline.repository == nil {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), 1, nil, map[string]any{"pn": b.ctx.Provider()},
			"Builder::Build no repository set",
		)

		return nil
	}

	// Check if auth function is set -> Use it via the `ObtainCredentialsFunction`
	if b.auth != nil {
		if b.pipeline.obtainCredentials == nil {
			b.pipeline.obtainCredentials = DefaultObtainCredentials
		}

		b.pipeline.obtainCredentials = func(
			context ifcore.CbContext,
			cred string,
			pipeCtx map[string]any,
			op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
			// Get credentials from AWS parameter store
			credentials, ttl, err = b.pipeline.obtainCredentials(context, cred, pipeCtx, op)
			if err != nil {
				return
			}

			// Authenticate
			return b.auth(context, credentials)
		}
	}

	return &b.pipeline
}

// WithBatchSize is tha number of pipes that may execute simultaneously.
// Default is set to _10_.
func (b *PipelineBuilder) WithBatchSize(batchSize int) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipeline.batchSize = batchSize
	return b
}

// WithParallelThreshold is the threshold that is used to determine if a pipe should fork-out
// into multiple parallel executions. A value of less than _1_ will disable parallelization.
//
// Default is set to _0_ (disabled).
func (b *PipelineBuilder) WithParallelThreshold(threshold int) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipeline.parallelThreshold = threshold
	return b
}

// WithTimeout is the time that the execution is allowed to take before it is aborted (when parallel).
//
// Default is _30_ seconds.
func (b *PipelineBuilder) WithTimeout(timeout time.Duration) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipeline.timeout = timeout
	return b
}

// UsePipeExecutorCreatorFunction is the function to create a new `PipelineExecutorImpl` when needed.
// If not set, the default `DefaultPipelineExecutorForOperationRequest` will be used.
func (b *PipelineBuilder) UsePipeExecutorCreatorFunction(
	f PipelineExecutorForOperationRequest,
) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipeline.pipeExecutorCreatorFunc = f
	return b
}

// WithConfigRepository will set the repository that will be used to retrieve
// provider configurations.
//
// NOTE: This may only be set once. Subsequent calls is ignored.
func (b *PipelineBuilder) WithConfigRepository(
	repository *providerconfig.ProviderConfRepository,
) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	if b.pipeline.repository == nil {
		b.pipeline.repository = repository
	}

	return b
}

// UseAuthenticateFunction is a function that authenticates and returns a token
// to be used as credentials for the provider.
//
// NOTE: If no `ObtainCredentialsFunction` is registered, the `DefaultObtainCredentials`
// is used to obtain credentials from _AWS_ parameter store.
//
// If already set, the subsequent calls are ignored.
func (b *PipelineBuilder) UseAuthenticateFunction(
	auth AuthenticateFunction,
) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	if b.auth == nil {
		b.auth = auth
	}

	return b
}

// UseCredentialsFunction will set the function that will be used to obtain credentials
// as backup if it is not provided in the `ProviderPipeImpl`.
//
// If already set, the subsequent calls are ignored.
func (b *PipelineBuilder) UseCredentialsFunction(
	obtainCredentials ObtainCredentialsFunction,
) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	if b.pipeline.obtainCredentials == nil {
		b.pipeline.obtainCredentials = obtainCredentials
	}

	return b
}

// UseVerifyConnectFunction will set the function that will be used to verify the connection
// as backup if it is not provided in the `ProviderPipeImpl`.
//
// If already set, the subsequent calls are ignored.
func (b *PipelineBuilder) UseVerifyConnectFunction(
	verifyConnect VerifyConnectFunction,
) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	if b.pipeline.verifyConnect == nil {
		b.pipeline.verifyConnect = verifyConnect
	}

	return b
}

// CreateNestedPipeBuilder creates a new `PipeBuilder` instance that can be used to build a pipe.
// It will automatically add the pipeline when the `PipeBuilderImpl.AddPipe` method is called.
func (b *PipelineBuilder) CreateNestedPipeBuilder() *PipeBuilderImpl {
	return newNestedPipeBuilder(b.ctx, b)
}

// WithPipe will add a pipe by using a inner function as builder.
//
// This is the _recommended_ way to add pipes to the pipeline.
func (b *PipelineBuilder) WithPipe(
	builder func(pb *PipeBuilderImpl) *PipeBuilderImpl,
) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	bld := builder(b.CreateNestedPipeBuilder())
	if bld.Error() != nil {
		b.err = bld.Error()
	}

	pipe := bld.Build()
	if bld.Error() != nil {
		b.err = bld.Error()
	}

	return b.AddPipe(*pipe)
}

// AddPipe will add a pipe based on the operation to the repository.
//
// If any error occurs it wil set the builder into an error state
func (b *PipelineBuilder) AddPipe(pipe ProviderPipeImpl) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	if pipe.operation == "" {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), 1, nil, map[string]any{"pn": b.ctx.Provider()},
			"Builder::AddPipe operation must be set on pipe",
		)

		return b
	}

	if _, ok := b.pipeline.operations[pipe.operation]; ok {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), 1, nil, map[string]any{"pn": b.ctx.Provider()},
			"Builder::AddPipe operation [%s] already exists", pipe.operation,
		)

		return b
	}

	pipe.Owner = &b.pipeline
	b.pipeline.operations[pipe.operation] = pipe

	return b
}

// WithSessionStore will set the session store that will be used to store and retrieve
// session data.
func (b *PipelineBuilder) WithSessionStore(store *config.SessionStore) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}
	b.pipeline.sessionStore = store
	return b
}

// WithOverrideContext will set the override context that will be used to override
// the pipe context with.
//
// NOTE: This will only set the values that are not already set.
func (b *PipelineBuilder) WithOverrideContext(overrides map[string]any) *PipelineBuilder {
	// Check if in error state
	if b.err != nil {
		return b
	}

	for k, v := range overrides {
		if _, ok := b.pipeline.overrideContext[k]; !ok {
			b.pipeline.overrideContext[k] = v
		}
	}

	return b
}
