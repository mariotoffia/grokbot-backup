package provider

import "github.com/Thiink-LLC/teos/go-core/pubsub"

// DispatchProvider is a provider that supports subscriptions, transformations
// and filtering of payloads including sending those to targets.
//
// The payloads may be from external events or internal "events" or data. It
// relies heavily on the `ifpubsub.PublishSubscribeManager` and associated
// functionality to realize the functionality.
//
// A `DispatchProvider` may use parts or full support of this functionality
// to perform it's work. It _SHOULD_ try to use less flexibility in order to
// perform better.
//
// To be part of the `ifpubsub.PublishSubscribeManager`, either implement the
// `PublishSubscribeManagerContributingProvider` interface (preferred) or alternatively
// implement the `StaticContextInitializerProvider` and forcibly add it to the
// context.
type DispatchProvider interface {
}

// PublishSubscribeManagerContributingProvider should be implemented by providers that
// wishes to participate in creation of `ifpubsub.PublishSubscribeManager` into
// the `ifcore.CbContext`.
//
// This is done during static initialization of the `ifcore.CbContext` and hence, only
// executed once.
type PublishSubscribeManagerContributingProvider interface {
	// BuildPublishSubscribeManager will be called to when building the
	// `ifpubsub.PublishSubscribeManager` and then sent to the context using
	// the `pubsub.OptServicePublishSubscribeManager`.
	BuildPublishSubscribeManager(builder *pubsub.ManagerBuilder)
}
