package providerconfig

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// ExportResolverImpl will handle the `export` section in the `process` section
// of the provider configuration.
//
// .Example Export Assignments
// [source,json]
// ----
//
//	"export": {
//		"PTP": [ <1>
//			{ "bravida-idt": "['bravida-idt' in :target.PTD_**:]" },
//			{ "bravida-optimizer": "['app-opt' in :target.PTD_**:]" },
//			{ "bravida-wds1100": "['r/*.wds1100/' in :target.PTD_**:]" },
//		],
//		"CNTIDT": "[:-f -e 'Value > 0' target.CNTIDT_**:]", <2>
//		"PID": "[PID]",
//		"TID": "[TID]",
//		"ORD": "[ORD]",
//	 	"MID": "[MID]"
//		"map": "[filter(map, MID)]"
//	}
//
// ----
// <1> Choice, first `true` will assign _PT_ the value of the key.
// <2> Scalar, the value of the variable is the result of the expression.
type ExportResolverImpl struct {
	ctx    ifcore.CbContext
	export map[string]*providermodel.ExportImpl
}

// NewExportResolver creates a new `ExportResolverImpl`.
func NewExportResolver(
	ctx ifcore.CbContext,
	export map[string]*providermodel.ExportImpl,
) *ExportResolverImpl {
	return &ExportResolverImpl{
		ctx:    ctx,
		export: export,
	}
}

// ProcessExports will process the exports and return them in a map.
//
// The _data_ is used to resolve the expressions.
//
// The _vars_ will contain all exports as variables whereas the _globals_ will
// contain all exports that should be set as globals or sections (such as map) in the profile.
func (resolver *ExportResolverImpl) ProcessExports(
	ctx ifcore.CbContext,
	data map[string]any,
) (vars map[string]any, err cberror.Error) {

	vars = map[string]any{}

	for exportName := range resolver.export {
		var res any
		item := resolver.export[exportName]

		if item.IsScalar() {
			res, err = processScalar(ctx, &item.Assignments[0], data)
			if err != nil {
				return
			}

			if res != nil {
				vars[exportName] = res
			}

			continue
		}

		for _, assignment := range item.Assignments {
			// First one that succeeds will be assigned
			res, err = processScalar(ctx, &assignment, data)
			if err != nil {
				return
			}

			if res != nil {
				vars[exportName] = res
				break
			}
		}
	}

	return
}

// processScalar will process a single _item_ and return the value if succeeded.
//
// If it is conditional and fails the _value_ will be `nil`.
func processScalar(
	ctx ifcore.CbContext,
	item ifprovider.ProcessExportItem,
	data map[string]any,
) (value any, err cberror.Error) {

	if cbeval.IsCbEvalExpression(item.GetExpression()) {
		// Fast track - single variable name expression
		if v, ok := data[item.GetExpression()[1:len(item.GetExpression())-1]]; ok {
			return v, nil
		}

		// Evaluate expression
		var res any
		res, err = evaluateSearchExpression(
			ctx,
			cbeval.UnwrapExpression(item.GetExpression()),
			data,
		)

		if err != nil {
			expr := item.GetExpression()
			if expr == "[CRD]" || expr == "[ORD]" || expr == "[CRC]" {
				// Special case for CRD, ORD, CRC
				value = ""
				err = nil
			}

			return
		}

		// We may have a true/false to assign the value or not
		if r, ok := res.(bool); ok && item.GetValue() != "" {
			// Conditional assignment -> failed
			if !r {
				return
			}
			//  Conditional assignment -> succeeded
			return item.GetValue(), nil
		}

		return res, nil
	}

	// No Expression evaluation -> just plain values
	if item.GetValue() == "" {
		value = item.GetExpression() // Plain string assignment!
	} else {
		value = item.GetValue()
	}

	return
}
