package providerpipe

import (
	"fmt"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline/event"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/observability/metrics"
)

// This file decides what watches a provider's pipelines while they run.
//
// A provider configuration contains a pipeline. When the provider collects data
// it fills that pipeline in, compiles it and runs it. Everything an operator
// would want to see about that run — how long it took, which step failed, where
// the time went — comes out of the pipeline as events, and something has to be
// attached to the run to receive them.
//
// What is attached comes from the service the provider is running inside. A
// service that was built with a tracer and a meter registers them on its request
// context, under the name ifcore.ServiceRegistryInstrumentation. A service that
// was not registers nothing, and then a pipeline run costs exactly what it cost
// before any of this existed: no listeners, no clock reads, no allocations.

// instrumentationFrom returns the tracer and meter the service registered, and
// false when it registered none.
//
// The entry has to be a metrics.InstrumentationConfig value. Anything else —
// including a pointer to one — is treated as nothing registered, and says so in
// the log, because a service that meant to be observed and silently is not would
// otherwise have no way to find out.
//
// Note what this does *not* do. It does not set the instrumentation scope, which
// is the name of the library a signal came from. A scope is attached by the
// tracer or meter itself, when the service asks its OpenTelemetry provider for
// one (metrics/otel.NewTracerForScope). By the time a tracer reaches this
// function it is already named, and nothing here can rename it. So the spans a
// pipeline produces carry the name the service chose for its tracer.
func instrumentationFrom(cbCtx ifcore.CbContext) (metrics.InstrumentationConfig, bool) {
	registry := cbCtx.ServiceRegistry()
	if registry == nil {
		return metrics.InstrumentationConfig{}, false
	}

	entry := registry.Get(string(ifcore.ServiceRegistryInstrumentation))
	if entry == nil {
		return metrics.InstrumentationConfig{}, false
	}

	cfg, ok := entry.(metrics.InstrumentationConfig)
	if !ok {
		log.Warn(cbCtx).WithMethod("providerpipe.instrumentationFrom").
			Str("registered.type", fmt.Sprintf("%T", entry)).
			Msg("this service's pipelines will not be traced or counted: what is " +
				"registered as its instrumentation is not a " +
				"metrics.InstrumentationConfig value")

		return metrics.InstrumentationConfig{}, false
	}

	return cfg, true
}

// runOptions builds the options one pipeline run is started with: the variables
// it starts from, and the listeners that watch it.
//
// The location identifier says which building or site the data belongs to, and
// may be empty. When it is given, the log lines the run produces go through the
// location-aware logger, which is how an operator filters a busy service's log
// down to one building.
//
// The listeners are built for each run. The tracing one has to be, because it
// keeps track of which span is open and one shared between two runs at once
// would nest their spans inside each other. The counting one need not be, and
// building it costs six lookups inside the meter; that is nothing beside the
// calls to the remote system the pipeline is about to make. If it ever shows up
// in a measurement, keep one per meter instead.
func runOptions(
	cbCtx ifcore.CbContext, locationID string, vars map[string]any,
) []cbpipeline.RunOption {
	opts := []cbpipeline.RunOption{cbpipeline.WithVars(vars)}

	cfg, ok := instrumentationFrom(cbCtx)
	if !ok {
		return opts
	}

	opts = append(opts, cbpipeline.WithListener(event.Tracing(cfg)))

	counters, err := event.Metrics(cfg)
	if err != nil {
		// The run goes ahead without measurements rather than failing. A meter
		// that will not create an instrument is a problem with how the service
		// was set up, and stopping the collection of data because of it would
		// turn a reporting fault into a loss of readings.
		log.Warn(cbCtx).WithMethod("providerpipe.runOptions").
			WithError(err).
			Msg("pipeline runs will not be counted: the meter refused an instrument")
	} else {
		opts = append(opts, cbpipeline.WithListener(counters))
	}

	return append(opts, loggingListeners(locationID)...)
}

// loggingListeners returns the log-writing listener, or nothing at all when the
// logger would discard every line it wrote.
//
// The listener asks to be told about every kind of event, which means the runner
// produces every kind. A service running at information level would pay for all
// of them and write none, so the decision is made once here, when the run starts,
// rather than once per event.
//
// The cost of deciding here is that a log level changed while a pipeline is
// running takes effect on the next run rather than on the next step. Nothing
// changes a log level mid-run.
func loggingListeners(locationID string) []cbpipeline.RunOption {
	if locationID == "" {
		if !log.IsEnabled(zerolog.DebugLevel) {
			return nil
		}

		return []cbpipeline.RunOption{cbpipeline.WithListener(event.Logging())}
	}

	if !log.IsEnabledWithLocationID(zerolog.DebugLevel, locationID) {
		return nil
	}

	return []cbpipeline.RunOption{
		cbpipeline.WithListener(event.LoggingForLocation(locationID)),
	}
}
