package esvprovider

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

const (
	// CapsProviderSVOPluginExportSensorValues denotes that the plugin will completely take over
	// the `ExportSensorValues` function and hence expects to get invoked on that function only.
	CapsProviderSVOPluginExportSensorValues string = "provider.svop.ExportSensorValues"
)

const (
	// SensorValueTargetFuncShallUpdateDsBuilding is the key where the `SensorValuesOutboundPluginDsBuilding.TargetFunc`
	// can return a `bool` if it want the provider to update the device shadow, building, with the desired values as
	// reported.
	SensorValueTargetFuncShallUpdateDsBuilding string = "provider.svop.UpdateDsBuilding"
)

// SensorValuesOutboundPlugin is a plugin exports data from crossbred to an remote endpoint.
//
// This is the base interface where different types of sub plugins for sensor values export implement.
type SensorValuesOutboundPlugin interface {
	// CapsProvider implementation since this is a requirement for any plugin.
	provider.Provider
}

// SensorValuesOutboundPluginExt is for advanced scenarios where most of the work is manual
// in the plugin.
type SensorValuesOutboundPluginExt interface {
	// ExportSensorValues is for plugins that do want to handle the process from A - Z
	// for them selves.
	//
	// This requires that the plugin exposes the _CapsProviderSVOPluginExportSensorValues_ capability.
	// This function will be invoked either if it run as a shell _command_ or as a standard lambda, including
	// as a queue trigger lambda. If lambda is batched, the plugin will get one event at the time.
	//
	// If the function returns error and there are still events in queue, those will be sent before returning
	// the error to invoker of lambda / shell.
	//
	// NOTE: Make sure that `ExportSensorValues` is idempotent since it may be invoked at least once!
	//
	// The _context_ is the fresh context for this invocation, or batch of invocations. The _evt_ is the
	// `cbevent.SensorValueOutboundEvent` that needs to be processed. The `cbevent.SensorValueOutboundEvent.Endpoint`
	// is set with the provided one for the process. Either by flags or environment variable if the event is missing
	// an endpoint. Plugins that do not make use of a endpoint can safely omit this property.
	//
	// If any error occur that shall make this event to be *re-submitted* should be returned. Otherwise if
	// error but do not want to receive the event again, return `nil`. But as stated above, it might get
	// invoked again with the same event anyway and should be prepared for it.
	ExportSensorValues(context ifcore.CbContext,
		evt *cbevent.SensorValueOutboundEvent) cberror.Error
}

// SensorValuesOutboundPluginDsBuilding is a plugin exports data from crossbred to an remote endpoint.
type SensorValuesOutboundPluginDsBuilding interface {
	// SensorValuesOutboundPlugin is always the base type for `SensorValuesOutboundPlugin`(s).
	SensorValuesOutboundPlugin
	// PipelineAwareProvider since a plugin is always aware of the pipeline (except if custom `ExportSensorValues`)
	provider.PipelineAwareProvider
	// SourceFunc is the complete source function in the pipeline.
	//
	// If this do not return nil, it will be used, otherwise the provider default is used (_see `providerpipe.SourceFunction`
	// for more information how to write a source function_).
	//
	// The default sourceFunction will load the `dsmodel.DsFullBuilding.State.Desired` into _src_ and
	// the `dsmodel.DsFullBuilding.State.Desired.Sensors` into _source_.
	//
	// .Sample Source Function
	// [source,go]
	// ----
	// func(
	// 	 eop *providermodel.OperationImpl,
	// 	 pc *providermodel.ProviderConfigImpl,
	// 	 cred interface{}) (map[string]interface{}, cberror.Error) {
	//
	// 	 return map[string]interface{}{
	// 		"src":    evt.BuildingData.State.Desired,
	// 		"source": evt.BuildingData.State.Desired.Sensors,
	// 	 }, nil
	//
	// }
	// ----
	//
	// Depending on the provider, some parameters may not be valid, such as _ep_ may not be needed. The _exec_ is the
	// executor where the `SourceFunc` is part of. It has been initialized with the user config, hence the
	// `providermodel.ProviderConfigImpl` is available.
	SourceFunc(context ifcore.CbContext,
		exec *providerpipe.ProviderPipelineExecutor,
		evt *cbevent.SensorValueOutboundEvent) providerpipe.SourceFunction
	// TargetFunc is the function invoked when the pipeline is at the end and the target operation is to occur
	// Here you export the values that may be obtained in the _target_ parameter. If the `evt.DryRun` is set
	// to `true`. The plugin _MUST_ not write any state data to the provider but log the sequences.
	//
	// .Example Extract the Target Data
	// [source, go]
	// ----
	// func(eop *providermodel.OperationImpl, pc *providermodel.ProviderConfigImpl,
	//	    cred interface{}, target map[string]interface{}) cberror.Error {
	//
	//   if trg, ok := target["target"]; ok {
	//     if target, ok := trg.(*UpdateDataPointList); ok {
	// 	     // Use target instance here to do the export of the
	//       // values to remote endpoint and update device shadow
	//     }
	//   }
	// }
	// ----
	//
	// When the _TargetFunc_ has been executed and a error is returned, the execution stops and the error is propagated back.
	// If the plugin wishes to update the device shadow as reported, set return hash key `SensorValueTargetFuncShallUpdateDsBuilding`
	// to true. If `false` is returned (or not set the key at all), the device shadow is not updated and assumed that
	// the _TargetFunc_ has done it's own update. The returned value is keyed in the _target_ map parameter.
	//
	// The _evt_ parameter contains if this is a `DryRun` operation or not.
	//
	// .Example Use Automatic Device Shadow Update
	// [source, go]
	// ----
	// func(eop *providermodel.OperationImpl, pc *providermodel.ProviderConfigImpl,
	//	    cred interface{}, target map[string]interface{}) cberror.Error {
	//
	//   target[provider.SensorValueTargetFuncShallUpdateDsBuilding] = true // <1>
	//	 return nil
	//
	// }
	// ----
	// <1> This will make the provider to update the `evt.BuildingData.State.Desired` automatically.
	//
	// The plugin author may update the device shadow by itself, either by the manager or use the utility function
	// `providerutils.ReportDsBuilding()`.
	TargetFunc(context ifcore.CbContext,
		exec *providerpipe.ProviderPipelineExecutor,
		evt *cbevent.SensorValueOutboundEvent) providerpipe.TargetFunction
}
