package utils

import (
	"fmt"
	"sort"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// InputEnumeratorImpl is a default implementation of the `InputEnumerator`
// interface.
//
// This searches the map provided with data and which parameters to enumerate and
// assign. The input argument is a space separated list of parameters to enumerate
// on the form "_ID=<glob> <ID> <glob>_". Where the assignment will assign the
// value of the glob to the ID for each round and the glob will just carry the value
// of the glob for each round. If only ID is specified it will just be carried each
// time iterating (can be seen as globals).
type InputEnumeratorImpl struct {
	ctx ifcore.CbContext
	// arguments is the list of arguments to enumerate
	arguments []InputArgument
	// err is the error state of the enumerator
	err cberror.Error
	// iterable contains all the iterations that the enumerator will do
	iterable []*iterable
	// ptr is the pointer to the current iteration to execute
	ptr int
}

// InputArgument represents an argument in a input expression.
type InputArgument struct {
	// IsGlob is `true` if the argument is a glob expression. If
	// set to false it is a precise argument e.g. _IDT*_ vs _IDT_.
	IsGlob bool
	// The actual argument name such as "REP", "IDT_O1_C1" or glob
	// expression such as "PID_**".
	Argument string
	// Assignment is the ID to assign the non-/glob to. If this is empty
	// it is not an assignment. E.g. "PID=PID_**".
	Assignment string
}

// idValueTuple is a container for a single id and a value.
type idValueTuple struct {
	id    string
	value any
}

// iterable is a struct that contains the state of one iteration
type iterable struct {
	// circuit 0 is no circuit
	circuit int
	// ordinal 1 - n
	ordinal int
	// The IDs that follows the circuit and ordinal
	id []idValueTuple
	// IDs that are not ordinal and circuit bound
	staticID []idValueTuple
}

// NewInputEnumeratorImpl creates a new enumerator
//
// Use `Resolve` to resolve the arguments in the enumerator.
//
// NOTE: This is not thread safe due to the state management in the
// enumerator. It is intended to be used in a single thread.
func NewInputEnumeratorImpl(
	ctx ifcore.CbContext,
	expression ...string,
) *InputEnumeratorImpl {
	// Parse the expressions and setup the enumerator

	var expr string
	if len(expression) > 1 {
		expr = strings.Join(expression, " ")
	} else if len(expression) == 1 {
		expr = expression[0]
	}

	i := &InputEnumeratorImpl{
		ctx:       ctx,
		arguments: ParseInputExpression(expr),
	}

	return i
}

// Error will return the error state of the enumerator.
func (i *InputEnumeratorImpl) Error() cberror.Error {
	return i.err
}

// ClearError will clear the error state of the enumerator.
func (i *InputEnumeratorImpl) ClearError() {
	i.err = nil
}

// Count returns the number of iterations that the enumerator will do.
//
// NOTE: You must call `Resolve` before this will return a valid value.
func (i *InputEnumeratorImpl) Count() int {
	return len(i.iterable)
}

// HasArgument checks if the argument exists in the enumerator.
//
// NOTE: This is useful to check arguments exists (such as "map" or "PID")
// to perform special handling.
func (i *InputEnumeratorImpl) HasArgument(id string) bool {
	for _, arg := range i.arguments {
		if arg.Argument == id {
			return true
		}
	}

	return false
}

// Next will step one step per invocation and return the data map with the
// arguments enumerated.
//
// When the enumerator is done it will return `false` in _ok_ and the _args_ will be
// `nil`.
func (i *InputEnumeratorImpl) Next() (args map[string]any, ok bool) {
	// Check if in error state
	if i.err != nil {
		return nil, false
	}

	// Finished iteration?
	if i.ptr >= len(i.iterable) {
		return nil, false
	}

	// Get the current iteration
	iter := i.iterable[i.ptr]
	i.ptr++

	args = map[string]any{}

	for _, id := range iter.id {
		args[id.id] = id.value
	}

	for _, id := range iter.staticID {
		args[id.id] = id.value
	}

	// Add the circuit and ordinal (if not already present)
	if iter.ordinal > 0 {
		if _, ok := args[string(ifprovider.ParameterOrdinal)]; !ok {
			args[string(ifprovider.ParameterOrdinal)] = iter.ordinal
		}
	}

	if iter.circuit > 0 {
		if _, ok := args[string(ifprovider.ParameterCircuit)]; !ok {
			args[string(ifprovider.ParameterCircuit)] = iter.circuit
		}
	}

	return args, true
}

// Reset will restart the enumerator from the beginning.
func (i *InputEnumeratorImpl) Reset() {
	i.ptr = 0
}

// Resolve will resolve the arguments in the enumerator.
//
// If it fails, it will set an error state of the enumerator.
//
// When this is invoked it will reset the enumerator, independent
// if it succeeds or not.
func (i *InputEnumeratorImpl) Resolve(data map[string]any) *InputEnumeratorImpl {
	i.ptr = 0
	i.iterable = nil

	// work is used to keep track of circuit and ordinal iterables
	work := map[string]*iterable{}

	// staticIDs is used to keep track of IDs that are not ordinal and circuit bound
	var staticIDs []idValueTuple

	// contains is a helper to check if _id_ is in _idv_
	contains := func(id string, idv []idValueTuple) bool {
		for _, i := range idv {
			if i.id == id {
				return true
			}
		}

		return false
	}

	// Iterate the InputArguments and match the ID from the data map
	// create the circuit and ordinal for each ID and add it to the work map
	// as a iterable struct.
	for _, arg := range i.arguments {
		if !arg.IsGlob {
			// Static match
			if _, ok := data[arg.Argument]; ok {

				if arg.Assignment != "" {
					staticIDs = append(staticIDs, idValueTuple{
						id:    arg.Assignment,
						value: data[arg.Argument],
					})
				} else {
					staticIDs = append(staticIDs, idValueTuple{
						id:    arg.Argument,
						value: data[arg.Argument],
					})
				}

				continue
			}
		}

		// Glob match
		glb, err := ProviderCache.Glob(arg.Argument, '_')

		if err != nil {
			i.err = cberror.NewCbErrorfWithProps(
				i.ctx.Service(), 1, err, map[string]any{"pn": i.ctx.Provider()},
				"Failed to parse glob expression: %s", arg.Argument,
			)

			return i
		}

		for id, value := range data {
			if glb.Match(id) {
				// Parse the ID
				pos, ok, plainID, o, c, _, _, _ := eqmodel.SensorType(id).Parse()
				if !ok {
					i.err = cberror.NewCbErrorfWithProps(
						i.ctx.Service(), 1, nil, map[string]any{"pn": i.ctx.Provider()},
						"Failed to parse glob expression: %s at position %d", arg.Argument, pos,
					)

					return i
				}

				if arg.Assignment == plainID {
					id = arg.Assignment
				}

				// Render work map ID
				work_id := fmt.Sprintf("%d_%d", o, c)

				wi := work[work_id]
				if nil == wi {
					wi = &iterable{
						circuit: c,
						ordinal: o,
					}

					work[work_id] = wi
				}

				// only add if not already added
				if !contains(id, wi.id) {
					wi.id = append(wi.id, idValueTuple{
						id:    id,
						value: value,
					})
				}
			}
		}
	}

	// No circuit or ordinal bound IDs
	if len(work) == 0 {
		// nothing to iterate
		if len(staticIDs) == 0 {
			return i
		}
		// only static IDs
		i.iterable = []*iterable{{
			circuit:  0,
			ordinal:  0,
			staticID: staticIDs,
		}}

		return i
	}

	// Add the static IDs to the work map
	for k := range work {
		work[k].staticID = staticIDs
	}

	// Add the work map to the iterable slice and sort it
	// by circuit first and secondary ordinal
	for _, v := range work {
		i.iterable = append(i.iterable, v)
	}

	sort.Slice(i.iterable, func(k, j int) bool {
		if i.iterable[k].circuit == i.iterable[j].circuit {
			return i.iterable[k].ordinal < i.iterable[j].ordinal
		}

		return i.iterable[k].circuit < i.iterable[j].circuit
	})

	return i
}

// ParseInputExpression will parse an _input_ expression and produce a list of
// `InputArgument` that can be used to enumerate the input.
func ParseInputExpression(expression string) []InputArgument {
	var args []InputArgument

	for _, arg := range strings.Split(expression, " ") {
		if arg == "" {
			continue
		}

		if idx := strings.Index(arg, "="); idx != -1 {
			args = append(args, InputArgument{
				IsGlob:     strings.ContainsAny(arg, "*?[{"),
				Argument:   arg[idx+1:],
				Assignment: arg[:idx],
			})

			continue
		}

		args = append(args, InputArgument{
			IsGlob:   strings.ContainsAny(arg, "*?[]"),
			Argument: arg,
		})
	}

	return args
}
