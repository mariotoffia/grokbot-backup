package providerutils

import (
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
)

// GetParamAsStringWithDefaultExpr will retrieve the _param_ value and use _defaultValue_ if not found.
//
// It will, then check if the parameter value is an expression and evaluate it. If it fails, it will return
// the default value.
func GetParamAsStringWithDefaultExpr(
	ctx ifcore.CbContext,
	pc ifprovider.ConfigGlobalParams,
	param, defaultValue string,
	resolveContext map[string]any,
) string {

	str, ok := pc.GetParamAsString(param)
	if !ok || str == "" || cbeval.IsCbEvalExpression(str) {
		return defaultValue
	}

	if s, err := cbeval.Evaluate[string](ctx, str, resolveContext, true /*cache*/); err != nil {
		log.Warn(ctx).
			WithError(err).
			Str("expr", str).
			Msg("Failed to evaluate expression")
	} else {
		return s
	}

	return defaultValue
}
