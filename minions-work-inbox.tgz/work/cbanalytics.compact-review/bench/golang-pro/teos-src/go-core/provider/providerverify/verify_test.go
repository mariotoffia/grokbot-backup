package providerverify

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

func makeContext(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	c := testenv.DefaultContext(tb, "unit-test")
	zerolog.SetGlobalLevel(zerolog.FatalLevel)
	return c
}

func convertStatusToStruct(s string) verifyError {
	result := verifyError{}
	_ = json.Unmarshal([]byte(s), &result)
	return result

}

func TestEmptyMandatoryRootItems(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{})
	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyMandatoryParamMissing {
		t.Fail()
	}
}

func TestMandatoryRootItemOid(t *testing.T) {
	tests := []struct {
		name  string
		owner string
		code  int // zero when the owner ID is accepted
	}{
		{"one segment", "skebo", 0},
		{"dotted", "thiink.us", 0},
		{"digits", "12346", 0},
		{"all, which covers every organization", "all", 0},
		{"uppercase", "Werw", cberror.ErrorProviderVerifyMandatoryParamValue},
		{"a dollar sign", "x$y", cberror.ErrorProviderVerifyMandatoryParamValue},
		{"digits then a hyphen", "123abc-x", cberror.ErrorProviderVerifyMandatoryParamValue},
		{"129 characters", strings.Repeat("a", 129), cberror.ErrorProviderVerifyMandatoryParamValue},
		{"empty", "", cberror.ErrorProviderVerifyMandatoryParamMissing},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			c := makeContext(t)
			verifier := NewStaticVerifier(c)
			require.NoError(t, verifier.Setup(c, []ConfigParam{}))

			result := verifier.VerifyConfig(
				&providermodel.ProviderConfigImpl{
					ProfileImpl: providermodel.ProfileImpl{
						BaseProfile: providermodel.BaseProfile{Profile: "generic", Owner: tc.owner},
					},
				},
			)

			if tc.code == 0 {
				require.Empty(t, result.Status)
				return
			}

			require.Len(t, result.Status, 1)
			status := convertStatusToStruct(result.Status[0])
			require.Equal(t, tc.code, status.Code)
			require.Equal(t, "oid", status.Cfg.ID)
		})
	}
}

func TestMandatoryRootItemOidStatusNamesTheValueAndTheFormat(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	require.NoError(t, verifier.Setup(c, []ConfigParam{}))

	result := verifier.VerifyConfig(
		&providermodel.ProviderConfigImpl{
			ProfileImpl: providermodel.ProfileImpl{
				BaseProfile: providermodel.BaseProfile{Profile: "generic", Owner: "umea-energi"},
			},
		},
	)

	require.Len(t, result.Status, 1)
	status := convertStatusToStruct(result.Status[0])
	require.Contains(t, status.Msg, `"umea-energi"`)
	require.Contains(t, status.Msg, "lowercase letters")
	require.Equal(t, `^(all|[a-z0-9]+(\.[a-z0-9]+)*)$`, status.Cfg.Value)
}

func TestGlobalParamsMandatoryParamMissing(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"T": "Europe/Stockholm"},
			}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyMandatoryParamMissing {
		t.Fail()
	}
}

func TestGlobalParamsMandatoryParamValueMissmatched(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params:  map[string]interface{}{"TZ": "123"}}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyMandatoryParamValue {
		t.Fail()
	}
}

func TestGlobalParamsMandatoryParamValid(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params:  map[string]interface{}{"TZ": "Europe/Stockholm"}}}})

	if len(result.Status) != 0 {
		t.Fail()
	}
}

func TestGlobalParamsOptionalInvalid(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
		{GlobalParams, "", `TD`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"TZ": "Europe/Stockholm",
					"TD": "unamtched",
				}}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyOptionalParamValue {
		t.Fail()
	}
}

func TestGlobalParamsOptionalValid(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
		{GlobalParams, "", `TD`, `valid`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"TZ": "Europe/Stockholm",
					"TD": "valid",
				}}}})

	if len(result.Status) != 0 {
		t.Fail()
	}
}

func TestGlobalParamsUnmatchedItems(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"TZ": "Europe/Stockholm",
					"TD": "unamtched",
					"XY": "unamtched",
				}}}})

	if len(result.Status) != 2 ||
		convertStatusToStruct(result.Status[0]).Code != cberror.ErrorProviderVerifyNoMatch ||
		convertStatusToStruct(result.Status[1]).Code != cberror.ErrorProviderVerifyNoMatch {
		t.Fail()
	}
}

func TestGlobalParamsOptionalItems(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
		{GlobalParams, "", `*`, `*`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"TZ": "Europe/Stockholm",
					"TD": "unamtched",
				}}}})

	if len(result.Status) != 0 {
		t.Fail()
	}
}

func TestMappingMandatoryAllMatch(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "IDT_02": "14704;PT=0"},
			}}})

	if len(result.Status) != 0 {
		t.Fail()
	}
}

func TestMappingMandatoryValueFail(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "IDT_02": "14704;PT=4"},
			}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyMandatoryParamValue {
		t.Fail()
	}
}

func TestMappingMandatoryAllMatchFail(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "ODT_02": "14704;PT=0"},
			}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(result.Status[0]).Code != cberror.ErrorProviderVerifyNoMatch {
		t.Fail()
	}
}

func TestMappingMandatoryOptional(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
		{Mapping, "", `ODT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "ODT_02": "14704;PT=0"},
			}}})

	if len(result.Status) != 0 {
		t.Fail()
	}
}

func TestMappingMandatoryOptionalValueFail(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
		{Mapping, "", `ODT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "ODT_02": "14704;PT=4"},
			}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyOptionalParamValue {
		t.Fail()
	}
}

func TestMappingMandatoryOptionals(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
		{Mapping, "", `*`, `[0-9]+;PT=[0-1]`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "ODT_02": "14704;PT=0"},
			}}})

	if len(result.Status) != 0 {
		t.Fail()
	}
}

func TestMappingMandatoryOptionalsValueFailed(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
		{Mapping, "", `*`, `[0-9]+;PT=[0-1]`, Optional},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Map:     map[string]string{"IDT_01": "14703;PT=0", "ODT_02": "14704;PT=5"},
			}}})

	if len(result.Status) != 1 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyOptionalParamValue {
		t.Fail()
	}
}

func TestNumericBool(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	_ = verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `BoolValOk`, true, Mandatory},
		{GlobalParams, "", `BoolValFail`, true, Mandatory},
		{GlobalParams, "", `IntValOk`, 1, Mandatory},
		{GlobalParams, "", `IntValFail`, 3, Mandatory},
		{GlobalParams, "", `FloatValOk`, 1.3, Mandatory},
		{GlobalParams, "", `FloatValFail`, 3.8, Mandatory},
	})
	result := verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "generic",
				Owner:   "default",
				Params: map[string]interface{}{
					"BoolValOk":    true,
					"BoolValFail":  false,
					"IntValOk":     1,
					"IntValFail":   2,
					"FloatValOk":   1.3,
					"FloatValFail": 3,
				}}}})

	if len(result.Status) != 3 ||
		convertStatusToStruct(
			result.Status[0],
		).Code != cberror.ErrorProviderVerifyMandatoryParamValue ||
		convertStatusToStruct(
			result.Status[1],
		).Code != cberror.ErrorProviderVerifyMandatoryParamValue ||
		convertStatusToStruct(
			result.Status[2],
		).Code != cberror.ErrorProviderVerifyMandatoryParamValue {
		t.Fail()
	}
}

func TestConfigurationError(t *testing.T) {
	c := makeContext(t)
	verifier := NewStaticVerifier(c)
	err := verifier.Setup(c, []ConfigParam{
		{GlobalParams, "", `TZ`, `^[A-Z][a-z]+\/[A-Z][a-z]+$`, Mandatory},
		{GlobalParams, "", `*`, `*`, Mandatory},
	})
	if err == nil {
		t.Fail()
	}
}

func BenchmarkMappingMandatoryOptionals(t *testing.B) {
	for i := 0; i < t.N; i++ {
		c := makeContext(t)
		verifier := NewStaticVerifier(c)
		_ = verifier.Setup(c, []ConfigParam{
			{Mapping, "", `IDT_[0-9]+_?[0-9]*`, `[0-9]+;PT=[0-1]`, Mandatory},
			{Mapping, "", `*`, `[0-9]+;PT=[0-1]`, Optional},
		})
		verifier.VerifyConfig(&providermodel.ProviderConfigImpl{
			ProfileImpl: providermodel.ProfileImpl{
				BaseProfile: providermodel.BaseProfile{
					Profile: "generic",
					Owner:   "default",
					Map:     map[string]string{"IDT_01": "14703;PT=0", "ODT_02": "14704;PT=0"},
				}}})
	}
}
