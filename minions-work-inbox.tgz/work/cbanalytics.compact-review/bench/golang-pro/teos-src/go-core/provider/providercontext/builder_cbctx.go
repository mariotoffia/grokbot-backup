package providercontext

import (
	"fmt"
	"io/fs"
	"net/url"

	"github.com/aws/aws-sdk-go-v2/aws"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy/pep"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/pubsub"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// CbContextBuilder is a builder to build up a `ifcore.CbContext` to be used
// when creating a provider _TEOS_ service.
type CbContextBuilder struct {
	ep           *url.URL
	dryRun       bool
	staticVerify bool
	providerName string
	serviceName  string
	deployEnv    cbenv.DeployEnv
	options      []ifcore.CbContextOption
}

func NewContextBuilder() *CbContextBuilder {
	return &CbContextBuilder{}
}

// Build will build the context. If any error, it will `panic`.
func (b *CbContextBuilder) Build() ifcore.CbContext {
	if cbenv.CB_PROVIDER_NAME.IsDefined() {
		b.providerName = cbenv.CB_PROVIDER_NAME.String("")
	}

	if b.ep == nil {
		endpoint := cbenv.CB_REP.String("")
		if endpoint != "" {
			if b.ep = utils.CreateSchemeURL("https", endpoint); b.ep == nil {
				panic(fmt.Sprintf("Failed to parse endpoint: %s", endpoint))
			}
		}
	}

	if b.deployEnv == cbenv.DeployEnvUnknown {
		b.options = ctx.AddOptionIfCategoryNotExists(
			ctx.OptDeployEnvFromEnvironment(),
			b.options,
			ifcore.CbOptCategoryNewDeployEnv,
		)
	}

	context, err := ctx.NewContext(
		b.serviceName, b.providerName, b.deployEnv, true /*sort*/, b.options...,
	)

	if err != nil {
		panic(err)
	}

	if b.ep != nil {
		context.SetValue(provider.ProviderCtxEndpoint, b.ep)
	}
	context.SetValue(provider.ProviderCtxDryRun, b.dryRun)
	context.SetValue(provider.ProviderVerifyConfigStatic, b.staticVerify)

	logger.SetLogLevelFromContext(context)

	return context

}

// EnableStaticConfigVerification configures the provider to static verify the configuration
func (b *CbContextBuilder) EnableStaticConfigVerification() *CbContextBuilder {
	b.staticVerify = true
	return b
}

// InProvider will set the provider name. If the `cbenv.CB_PROVIDER_NAME`
// is set, it will use that instead.
func (b *CbContextBuilder) InProvider(name string) *CbContextBuilder {
	b.providerName = name
	return b
}

// AsService is the name of the actual service whereas the provider name
// is a a set of services that are grouped together.
func (b *CbContextBuilder) AsService(name string) *CbContextBuilder {
	b.serviceName = name
	return b
}

// WithDeploymentEnvironment configures the provider to use the given deployment environment.
//
// If omitted, it will detect it from the `cbenv.CB_DEPLOY_ENV` environment variable.
func (b *CbContextBuilder) WithDeploymentEnvironment(deployEnv cbenv.DeployEnv) *CbContextBuilder {
	b.deployEnv = deployEnv
	return b
}

// WithEndpoint configures the provider to use the given endpoint.
//
// This may be overridden by `cbenv.CB_REP` environment variable.
func (b *CbContextBuilder) WithEndpoint(ep *url.URL) *CbContextBuilder {
	b.ep = ep
	return b
}

// EnableDryRun sets the provider in dry run mode.
func (b *CbContextBuilder) EnableDryRun() *CbContextBuilder {
	b.dryRun = true
	return b
}

// AddOptions adds any custom options wanted into the `ifcore.CbContext` object.
func (b *CbContextBuilder) AddOptions(options ...ifcore.CbContextOption) *CbContextBuilder {
	for i := range options {
		b.options = ctx.AddOptionIfCategoryNotExists(
			options[i],
			b.options,
			ifcore.CbOptCategoryNewDeployEnv,
		)
	}

	return b
}

// EnableLogging setups both console and pipe logging.
func (b *CbContextBuilder) EnableLogging() *CbContextBuilder {
	return b.EnableConsoleLogging().EnablePipeLogging()
}

// EnableConsoleLogging setups logging for console.
func (b *CbContextBuilder) EnableConsoleLogging() *CbContextBuilder {
	return b.AddOptions(ctx.OptionPackLogging...)
}

// EnablePipeLogging setups logging for pipe.
func (b *CbContextBuilder) EnablePipeLogging() *CbContextBuilder {
	return b.AddOptions(ctx.OptionPackPipeLogging...)
}

// WithDefaultAWSConfiguration setups the default _AWS_ config to be able to communicate
// with the environment.
func (b *CbContextBuilder) WithDefaultAWSConfiguration() *CbContextBuilder {
	return b.AddOptions(ctx.OptAWSConfigLoadDefault())
}

// WithAWSConfig sets a custom AWS configuration instead of loading defaults.
// Use this for testing with local AWS services (DynamoDB Local, SQS Local, etc.).
//
// This replaces WithDefaultAWSConfiguration() - do not call both.
func (b *CbContextBuilder) WithAWSConfig(cfg aws.Config) *CbContextBuilder {
	return b.AddOptions(ctx.OptAWSSetConfig(cfg, true /*force*/))
}

// LoadPolicyFromEnvironment will check if the `cbenv.CB_POLICY` environment
// variable is defined. If it is it will add the `cbpolicy.OptNamedPolicyContext`
// option to the `ifcore.CbContext` object.
func (b *CbContextBuilder) LoadPolicyFromEnvironment() *CbContextBuilder {
	if cbenv.CB_POLICY.IsDefined() {
		return b.AddOptions(cbpolicy.OptNamedPolicyContext(false /*noForce*/, nil /*defaultKey*/))
	}

	return b
}

// AddPolicies will add the `pep.OptPolicyRetrievals` option to the
// `ifcore.CbContext` object. An example is `cbpolicy.ImmutablePRP` which will load
// policies from the initialized `fs.FS` object. It will then form a _PDP_ from
// the policies.  It may be used in conjunction with `UsePDPFromFS` to load
// policies from multiple sources.
func (b *CbContextBuilder) AddPolicies(prp ...ifcore.PolicyRetrievalPoint) *CbContextBuilder {
	if len(prp) > 0 {
		b.options = append(b.options, cbpolicy.OptSubContext(true /*force*/, prp...))
	}

	return b
}

func (b *CbContextBuilder) LoadPoliciesFromFileSystem(fs ...fs.FS) *CbContextBuilder {
	if len(fs) > 0 {
		prp := make([]ifcore.PolicyRetrievalPoint, len(fs))

		for i := range fs {
			prp[i] = cbpolicy.NewImmutablePRP(nil /*noKey*/).RegisterFsModules(fs[i])
		}

		return b.AddPolicies(prp...)
	}

	return b
}

// WithPolicyDecisionPoint will add the `cbpolicy.OptPDPFromFSConfig` option to the
// `ifcore.CbContext` object. This will load policy decision points, _PDP_, from the initialized
// `fs.FS` object. The _PDP_ is the one who actually run the policy via requests from _PEPs_.
//
// This method may be used in conjunction of `UsePDPFromPRP` to load policies from
// multiple sources.
func (b *CbContextBuilder) WithPolicyDecisionPoint(fsys ...fs.FS) *CbContextBuilder {
	if len(fsys) > 0 {
		return b.AddOptions(cbpolicy.OptPDPFromFSConfig(fsys...))
	}

	return b
}

// AddPEPConfiguration will map operation path, e.g. "/provider/climatixic/sv", method
// e.g. "POST" to a set of polices to be evaluated by the _PDP_.
//
// NOTE: It is the pep that actually enforces the policy. The _PDP_ is the one who
// actually run the policy via requests from _PEPs_.
func (b *CbContextBuilder) AddPEPConfiguration(reg *provider.PEPConfig) *CbContextBuilder {
	return b.AddOptions(
		pep.OptPEPRegistration(reg.Category, reg.Registration, reg.IsWrapper),
	)
}

// WithPubSubSystem will add a pubsub system to the `ifcore.CbContext` object.
//
// The _ps_ function will receive a `pubsub.ManagerBuilder` object that can be
// used to configure the pubsub system.
//
// CAUTION: It is not allowed to execute the `pubsub.ManagerBuilder.Build` method
// in the _ps_ function. This is done by the system itself.
func (b *CbContextBuilder) WithPubSubSystem(
	builder func(ps *pubsub.ManagerBuilder),
) *CbContextBuilder {
	opt := pubsub.OptServicePublishSubscribeManager(
		func(c ifcore.CbContext) *pubsub.ManagerBuilder {
			bld := pubsub.NewBuilder(c)
			// Let function build it's pubsub system.
			builder(bld)
			return bld
		})

	return b.AddOptions(opt)
}
