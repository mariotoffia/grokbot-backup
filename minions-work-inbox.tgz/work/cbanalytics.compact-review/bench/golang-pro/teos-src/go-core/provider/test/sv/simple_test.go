package sv

import (
	"embed"
	"slices"
	"testing"

	"github.com/aws/aws-sdk-go-v2/aws"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy"
	teosctx "github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

//cSpell: disable

//go:embed testdata/provider-config/**/*.*
var providerConfig embed.FS

//go:embed testdata/policies/*.*
var policies embed.FS

//go:embed testdata/pdp-config/*.*
var pdpConfig embed.FS

// newProviderContext builds the root context a provider pipeline in this
// package runs under: the unit-test environment, console and pipeline logging,
// the policies and policy decision point embedded beside these tests, and an
// empty AWS configuration. It is closed when the test ends.
func newProviderContext(tb testing.TB, provider, service string) ifcore.CbContext {
	tb.Helper()
	testenv.Use(tb, testenv.EnvDefaults)

	c, err := teosctx.NewContext(service, provider, cbenv.DevLocal, true, /*sort*/
		slices.Concat(teosctx.OptionPackLogging, teosctx.OptionPackPipeLogging, []ifcore.CbContextOption{
			teosctx.OptAWSSetConfig(aws.Config{}, true /*force*/),
			cbpolicy.OptSubContext(true /*force*/, cbpolicy.NewImmutablePRP(nil /*noKey*/).RegisterFsModules(policies)),
			cbpolicy.OptPDPFromFSConfig(pdpConfig),
		})...)
	require.Nil(tb, err)
	tb.Cleanup(c.Close)

	return c
}

func TestSimpleImportProvider(t *testing.T) {
	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.7},
				&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZH7ZS23P", Value: 18.5},
				&eqmodel.CbDataPointImpl{ID: "1!6WHH6DKHICVDSS", Value: 2.46},
				&eqmodel.CbDataPointImpl{ID: "1!N3ASTG10KWTFCMU", Value: -17.0},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/sv", builder))

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			`{"profile": "single-plant/generic"}`,
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	dsb := cbevent.ExtractResult[map[string]dsmodel.DsBuilding](res, 0)

	assert.Equal(t, "Europe/Stockholm", dsb["target"].TimeZone)
	assert.Equal(t, float64(-17), dsb["target"].Sensors["ODT"])
	assert.Equal(t, 2.46, dsb["target"].Sensors["OFFODT"])
}

func BenchmarkSimpleImportProvider(t *testing.B) {
	// Root Service Context
	ctx := newProviderContext(t, "test-provider", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Simulate call to remote endpoint for fetching sensor values
						return []eqmodel.CbDataPoint{
							&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.7},
							&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZH7ZS23P", Value: 18.5},
							&eqmodel.CbDataPointImpl{ID: "1!6WHH6DKHICVDSS", Value: 2.46},
							&eqmodel.CbDataPointImpl{ID: "1!N3ASTG10KWTFCMU", Value: -17.0},
						}, nil /*body*/, nil /*err*/
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/sv", builder))

	pctx := builder.Build()

	invoker := pctx.Invoker()
	payload := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			`{"profile": "single-plant/generic"}`,
		},
	})

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		_, _ = invoker.InvokeRaw(ctx, payload)
	}
}
