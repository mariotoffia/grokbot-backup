package tests

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestFinallyFunctionCalledOnSuccess verifies FinallyFunction is called on successful execution.
func TestFinallyFunctionCalledOnSuccess(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	var finallyCalled bool
	var finallyPipeErr cberror.Error

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				return map[string]eqmodel.CbDataPoint{
					"1!N3ASTFSZHI2WD0F": &eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.0},
				}, nil, nil, nil
			}).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			finallyCalled = true
			finallyPipeErr = pipeErr
			return pipeErr
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	exec.Execute()

	require.NoError(t, exec.Error())
	assert.True(t, finallyCalled, "FinallyFunction should be called on success")
	assert.Nil(t, finallyPipeErr, "pipeErr should be nil on success")
}

// TestFinallyFunctionCalledOnError verifies FinallyFunction is called when pipe fails.
func TestFinallyFunctionCalledOnError(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	var finallyCalled bool
	var finallyPipeErr cberror.Error

	expectedErr := cberror.NewCbErrorf(ctx.Service(), 500, nil, "source function error")

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				// Return an error from source function
				return nil, nil, nil, expectedErr
			}).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			finallyCalled = true
			finallyPipeErr = pipeErr
			return pipeErr // propagate error
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	exec.Execute()

	require.Error(t, exec.Error())
	assert.True(t, finallyCalled, "FinallyFunction should be called on error")
	require.NotNil(t, finallyPipeErr, "pipeErr should not be nil on error")
	assert.Contains(t, finallyPipeErr.Error(), "source function error")
}

// TestFinallyFunctionCanSuppressError verifies FinallyFunction can suppress errors.
func TestFinallyFunctionCanSuppressError(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				// Return an error
				return nil, nil, nil, cberror.NewCbErrorf(ctx.Service(), 500, nil, "original error")
			}).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			// Suppress the error by returning nil
			return nil
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	exec.Execute()

	// Error should be suppressed
	assert.NoError(t, exec.Error(), "FinallyFunction should suppress error")
}

// TestFinallyFunctionCanWrapError verifies FinallyFunction can wrap errors.
func TestFinallyFunctionCanWrapError(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				return nil, nil, nil, cberror.NewCbErrorf(ctx.Service(), 500, nil, "original error")
			}).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			// Wrap the error
			return cberror.NewCbErrorf(ctx.Service(), 500, pipeErr, "wrapped: %s", pipeErr.Error())
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	exec.Execute()

	require.Error(t, exec.Error())
	assert.Contains(t, exec.Error().Error(), "wrapped:")
	assert.Contains(t, exec.Error().Error(), "original error")
}

// TestFinallyFunctionCanReplaceError verifies FinallyFunction can replace errors.
func TestFinallyFunctionCanReplaceError(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				return nil, nil, nil, cberror.NewCbErrorf(ctx.Service(), 500, nil, "original error")
			}).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			// Replace with a completely new error
			return cberror.NewCbErrorf(ctx.Service(), 503, nil, "replaced error")
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	exec.Execute()

	require.Error(t, exec.Error())
	assert.Contains(t, exec.Error().Error(), "replaced error")
	assert.NotContains(t, exec.Error().Error(), "original error")
}

// TestFinallyFunctionReceivesPipeContext verifies FinallyFunction receives pipe context.
func TestFinallyFunctionReceivesPipeContext(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	var receivedPipeCtx map[string]any

	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				return map[string]eqmodel.CbDataPoint{
					"1!N3ASTFSZHI2WD0F": &eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.0},
				}, nil, nil, nil
			}).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			receivedPipeCtx = pipeCtx
			return pipeErr
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	exec.Execute()

	require.NoError(t, exec.Error())
	require.NotNil(t, receivedPipeCtx, "FinallyFunction should receive pipe context")
	assert.Contains(t, receivedPipeCtx, "TZ")
	assert.Equal(t, "Europe/Stockholm", receivedPipeCtx["TZ"])
}

// TestFinallyFunctionNotCalledWhenNotRegistered verifies no panic when FinallyFunction is not set.
func TestFinallyFunctionNotCalledWhenNotRegistered(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	// Build pipe WITHOUT UseFinally
	pipeBuilder := providerpipe.NewPipeBuilder(ctx,
		providerpipe.NewPipelineBuilder(ctx).
			WithSessionStore(config.NewSessionStore(ctx)).
			WithConfigRepository(
				providerconfig.NewProviderConfigRepository(
					ctx,
					providerconfig.NewFsProviderConfigLoaderFromPath(
						"./testdata/without-generator-template/",
					),
				),
			).Build(),
	).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				eop *providermodel.Operation) (any, int64, cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		UseSourceMapWithReport(
			func(
				ctx ifcore.CbContext,
				pipeCtx map[string]any,
				operation string,
				eop *providermodel.Operation,
				pc *providermodel.ProviderConfigImpl,
				rid []string,
				cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
				return map[string]eqmodel.CbDataPoint{
					"1!N3ASTFSZHI2WD0F": &eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.0},
				}, nil, nil, nil
			}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn))

	conf := `{
	"profile": "generic-no-src-asmap",
	"prms": { 
		"REP": "api.climatixic.com", "BID": "Test", "PID": "P123",
		"TZ": "Europe/Stockholm" 
	},
	"map": { "IDT": "1!N3ASTFSZHI2WD0F" }
}
--gen=sv
{ "tz": TZ, "sensors": { "IDT": float64(generate["IDT"].Value) } }`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipeBuilder.Build()).
		FromUserConfig(conf).
		Build()

	// Should not panic
	exec.Execute()

	assert.NoError(t, exec.Error())
}
