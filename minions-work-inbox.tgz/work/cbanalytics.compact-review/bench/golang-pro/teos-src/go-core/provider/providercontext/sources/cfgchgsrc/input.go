package cfgchgsrc

import (
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
)

// DefaultConfigInput converts a config change event into a configuration input to be used when doing execute.
//
// This is a simple default, that only adds the operation type.
//
// It matches the `configchange.ConfigInput` signature.
func DefaultConfigInput(ctx ifcore.CbContext, item *cbevent.ConfigChangeEventImpl) map[string]any {
	return map[string]any{
		string(ifprovider.ParameterConfigOperationType): string(item.Oper),
	}
}
