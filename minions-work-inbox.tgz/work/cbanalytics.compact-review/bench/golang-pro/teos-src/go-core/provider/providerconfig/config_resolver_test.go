package providerconfig

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// cSpell: disable
func TestLoadContextLiteral(t *testing.T) {
	ctx := newCtx(t)
	pctx := map[string]any{}
	p := genProviderConfig()

	pc := &p

	_ = ResolvePipeContextFromGlobals(ctx, pc, pctx, nil /*input*/, false /*allowMutate*/)
	assert.Equal(t, "Månstenen 9", pctx["BID"])
	assert.Equal(t, "Månstenen 9", pctx["LID"], "It must have a copy of BID in LID")
}

func TestLoadContextEvaluate(t *testing.T) {
	ctx := newCtx(t)

	pctx := map[string]any{
		"myprop": 42,
	}

	p := genProviderConfig()
	p.Params["linger"] = "[myprop * 4]"

	pc := &p

	_ = ResolvePipeContextFromGlobals(ctx, pc, pctx, nil /*input*/, false /*allowMutate*/)
	assert.Equal(t, float64(168), pctx["linger"])
}

func TestResolveOperation(t *testing.T) {
	ctx := newCtx(t)

	pctx := map[string]any{}

	p := genProviderConfig()
	oper := p.Operation["sv"]

	oper.Params["BID"] = "[BID]"
	oper.Params["SL"] = "[SL]"
	p.Params["SL"] = ""
	p.Params["BID"] = "Måssmyren 18"

	pc := &p

	err := ResolvePipeContextFromGlobals(
		ctx,
		pc,
		pctx,
		nil,   /*input*/
		false, /*allowMutate*/
	)
	assert.Equal(t, nil, err)

	op, err := ResolveOperation(ctx, pc, "sv", pctx, nil /*input*/)

	assert.Equal(t, nil, err)
	assert.Equal(t, "https://climatixic.se/DataPoints/Values/", op.Operation)
	assert.Equal(t, "", op.Params["SL"])
	assert.Equal(t, "Måssmyren 18", op.Params["BID"])
}

func TestHasMapping(t *testing.T) {
	p := genProviderConfig()

	assert.True(t, p.HasMapping())
	delete(p.Map, "IDT")
	assert.False(t, p.HasMapping())
}

func TestHasFilter(t *testing.T) {
	p := genProviderConfig()

	assert.True(t, p.HasFilter())
	delete(p.Filter, "IDT")
	assert.False(t, p.HasFilter())
}

func TestCreateMappingWithNoMapping(t *testing.T) {
	p := genProviderConfig()

	delete(p.Map, "IDT")
	m := CreateMapping(&p, providermodel.MappingDirectionLeftAssign)
	assert.Equal(t, "", m)
}

func TestCreateMappingLeftAssign(t *testing.T) {
	p := genProviderConfig()

	m := CreateMapping(&p, providermodel.MappingDirectionLeftAssign)
	assert.True(
		t,
		strings.Contains(m, `"mapped.IDT": "=source['Room temp.comf.']"`),
	)
}

func TestCreateMappingRightAssign(t *testing.T) {
	p := genProviderConfig()

	m := CreateMapping(&p, providermodel.MappingDirectionRightAssign)
	assert.True(
		t,
		strings.Contains(m, `"mapped.Room temp.comf.": "=source['IDT']"`),
	)
}

func TestCreateMappingWhenFilterNotExistant(t *testing.T) {
	p := genProviderConfig()

	delete(p.Filter, "IDT")

	m := CreateMapping(&p, providermodel.MappingDirectionLeftAssign)
	assert.Equal(
		t,
		"\"set-mapping\": {\n\"generate.IDT\": \"=source['Room temp.comf.']\"\n}",
		m,
	)
}

func TestCreateMappingWhenFilterExists(t *testing.T) {
	p := genProviderConfig()

	m := CreateMapping(&p, providermodel.MappingDirectionLeftAssign)
	assert.Equal(
		t,
		"\"set-mapping\": {\n\"mapped.IDT\": \"=source['Room temp.comf.']\"\n}",
		m,
	)
}

func TestCreateMappingWithSomeOptionals(t *testing.T) {
	p := genProviderConfig()

	delete(p.Filter, "IDT")
	p.Map["IDT_O1"] = "other:IDT_O1"
	p.Map["IDT_O2"] = "other:IDT_O2"
	p.Map["OFFODT"] = "other:OFFODT"
	p.Params[string(ifprovider.ParameterOptionalSensors)] = "IDT**"

	m := CreateMapping(&p, providermodel.MappingDirectionLeftAssign)
	assert.True(
		t,
		strings.Contains(
			m,
			`"generate.IDT": { "if": "=exist(source['Room temp.comf.'])", "value": "=source['Room temp.comf.']" }`,
		),
	)
	assert.True(
		t,
		strings.Contains(
			m,
			`"generate.IDT_O1": { "if": "=exist(source['other:IDT_O1'])", "value": "=source['other:IDT_O1']" }`,
		),
	)
	assert.True(
		t,
		strings.Contains(
			m,
			`"generate.IDT_O2": { "if": "=exist(source['other:IDT_O2'])", "value": "=source['other:IDT_O2']" }`,
		),
	)
	assert.True(
		t,
		strings.Contains(m, `"generate.OFFODT": "=source['other:OFFODT']"`),
	)
}

func TestCreateFilterWithNoFilters(t *testing.T) {
	p := genProviderConfig()

	delete(p.Filter, "IDT")
	m := CreateFilter(&p, providermodel.MappingDirectionLeftAssign)
	assert.Equal(t, "", m)
}

func TestCreateFilterWithNoMapping(t *testing.T) {
	p := genProviderConfig()

	delete(p.Map, "IDT")
	m := CreateFilter(&p, providermodel.MappingDirectionLeftAssign)
	assert.Equal(
		t,
		"\"set-filter\": {\n\"generate.IDT\": { \"if\": \"=V > -100 && V < 100\", \"value\": \"=source['IDT']\" }\n}",
		m,
	)
}

func TestCreateFilterWithMapping(t *testing.T) {
	p := genProviderConfig()

	m := CreateFilter(&p, providermodel.MappingDirectionLeftAssign)
	assert.Equal(
		t,
		"\"set-filter\": {\n\"generate.IDT\": { \"if\": \"=V > -100 && V < 100\", \"value\": \"=mapped['IDT']\" }\n}",
		m,
	)
}

func TestCreateGeneratorTemplateThatDoNotExist(t *testing.T) {
	p := genProviderConfig()
	p.Generate = map[string]string{
		"genref": `{"myprop": max(:-k ID src.Sensors.IDT**:) }`,
		"sv":     `{"gen":"this"}`,
	}
	m, _, _ := CreateGeneratorTemplate(
		newCtx(t),
		&p,
		"non-existant",
		"non-existant",
		true, /*log*/
		map[string]any{},
	)
	assert.Equal(t, "", m)
}

func TestCreateGeneratorTemplateWithNoInProviderConfig(t *testing.T) {
	p := genProviderConfig()

	m, _, _ := CreateGeneratorTemplate(
		newCtx(t),
		&p,
		"non-existant",
		"non-existant",
		true, /*log*/
		map[string]any{},
	)
	assert.Equal(t, "", m)
}

func TestCreateGeneratorTemplate(t *testing.T) {
	p := genProviderConfig()

	template := `{ "IDTAVG": { "ID": "//baah/IDTAVG", "Name": "IDTAVG", "V": round(avg(:-k ID -v V sensorvalues.IDT**:), 1)	} }`

	p.Generate = map[string]string{"genref": template}

	m, _, _ := CreateGeneratorTemplate(
		newCtx(t),
		&p,
		"genref",
		"genref",
		true, /*log*/
		map[string]any{},
	)
	assert.Equal(
		t,
		`{ "IDTAVG": { "ID": "//baah/IDTAVG", "Name": "IDTAVG", "V": round(avg(:-k ID -v V sensorvalues.IDT**:), 1)	} }`,
		m,
	)
}

func TestCreateGeneratorTemplateFromGeneratorPrototypesAllInMID(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterMappingIDs)] = "IDT IDT_O1 ODT"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}}`,
	}

	_, _, err := CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})

	assert.Equal(t, nil, err)
}

func TestCreateGeneratorTemplateFromGeneratorPrototypesOnlyPR_GPID(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterProviderRequiredGeneratorProtoTypeIDs)] = "IDT_O2 ODT"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}}`,
	}

	_, _, err := CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})

	assert.Equal(t, nil, err)
}

// tag::generator-prototypes-mid-gpid[]

func TestCreateGeneratorTemplateFromGeneratorPrototypesMIDandPR_GPID(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterMappingIDs)] = "IDT_O1 OFFODT"                         // <1>
	pc.Params[string(ifprovider.ParameterProviderRequiredGeneratorProtoTypeIDs)] = "IDT_O2 ODT" // <2>
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{                              // <3>
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}}`,
	}

	_, _, err := CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})

	assert.Equal(t, nil, err)
}

// end::generator-prototypes-mid-gpid[]

func TestCreateGeneratorTemplateFromGeneratorPrototypesGPID_excludesMIDincludesPR_GPID(
	t *testing.T,
) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterMappingIDs)] = "IDT_O1 OFFODT"
	pc.Params[string(ifprovider.ParameterGeneratorProtoTypeIDs)] = "RHCS"
	pc.Params[string(ifprovider.ParameterProviderRequiredGeneratorProtoTypeIDs)] = "IDT_O2 ODT"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}}`,
	}

	_, _, err := CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})

	assert.Equal(t, nil, err)
}

func TestCreateGeneratorTemplateFromGeneratorPrototypesOnlyNoID_PR_GPID(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterProviderRequiredGeneratorProtoTypeIDs)] = "1!6WHH6DKHICVDSS"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"-*": `{"n": PID + ";{{ID}}", "v": float64(generate["{{ID}}"])}`,
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "list": [ {"n": PID + ";1!6WHH6DKH3CCVW-", "v": 1 },
{{GENPROTO}}]
}`,
	}

	_, _, err := CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})

	assert.Equal(t, nil, err)
}

func TestCreateGeneratorInstruction(t *testing.T) {
	m := CreateGeneratorInstruction(
		"the-ref",
		// "error-silent" tells the generator step to put a marker in place of a
		// value it could not produce, and to say nothing about it in the log.
		"error-silent",
		false, /*delayedGeneratorTemplate*/
		ifprovider.GeneratorTemplateTypeNative,
		providermodel.MappingDirectionLeftAssign,
	)

	assert.Equal(
		t,
		`{ "key": "target", "from": "=the-ref", "mode": "error-silent" }`,
		m,
	)
}

func TestCreateMarshalInstruction(t *testing.T) {
	m := CreateMarshalInstruction("marshal(_types.ds)")
	assert.Equal(t, `{ "target": "=marshal(_types.ds)" }`, m)
}

//cSpell: enable
