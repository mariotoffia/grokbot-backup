package querysettings_test

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/querysettings"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSimple(t *testing.T) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**",
			"1h14m59s": "ESHG ESHL"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	ts, ok := res.ToResolution("ESHG")

	require.True(t, ok)
	assert.Equal(t, time.Hour+time.Minute*14+time.Second*59, ts)
}

func TestMatchResolutionExactMatch(t *testing.T) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	duration, matched := res.ToResolution("WWS")
	assert.True(t, matched)
	assert.Equal(t, time.Hour, duration)
}

func TestMatchResolutionGlobMatch(t *testing.T) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	duration, matched := res.ToResolution("IDT_O123")
	assert.True(t, matched)
	assert.Equal(t, time.Hour, duration)
}

func TestMatchResolutionRootMatch(t *testing.T) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	duration, matched := res.ToResolution("ODT")

	assert.True(t, matched)
	assert.Equal(t, time.Minute*10+time.Second*30, duration)
}

func TestMatchResolutionMostPreciseMatch(t *testing.T) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**",
			"1h10m": "IDT_C3_O1_ZLgh999"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	duration, matched := res.ToResolution("IDT_C3_O1_ZLgh999")

	assert.True(t, matched)
	assert.Equal(t, time.Hour+time.Minute*10, duration)

	duration, matched = res.ToResolution("IDT_O1")

	assert.True(t, matched)
	assert.Equal(t, time.Hour, duration)
}

func TestMatchResolutionNoMatch(t *testing.T) {
	data := `{
		"resolution": {
			"1h": "WWS IDT_**"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	duration, matched := res.ToResolution("ODT")

	assert.False(t, matched)
	assert.Equal(t, time.Duration(0), duration)
}

func BenchmarkMatchResolutionMostPreciseMatch(t *testing.B) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**",
			"1h10m": "IDT_C3_O1_ZLgh999"
		}
	}`

	var m map[string]any
	require.NoError(t, json.Unmarshal([]byte(data), &m))

	qs, err := querysettings.FromParams(m)
	require.NoError(t, err)

	res, err := qs.ToResolutionMap()
	require.NoError(t, err)

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		res.ToResolution("IDT_C3_O1_ZLgh999")
	}
}

func BenchmarkParseCompileAndMatch(t *testing.B) {
	data := `{
		"resolution": {
			"10m30s": "**",
			"1h": "WWS IDT_**",
			"1h10m": "IDT_C3_O1_ZLgh999"
		}
	}`

	for i := 0; i < t.N; i++ {
		var m map[string]any
		require.NoError(t, json.Unmarshal([]byte(data), &m))

		qs, _ := querysettings.FromParams(m)
		res, _ := qs.ToResolutionMap()

		res.ToResolution("IDT_C3_O1_ZLgh999")
	}
}
