package svprovider

import (
	"net/url"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providercommon"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

// createPipeLine will create a pipeline either by invoking the plugin `CreatePipeline` (if the
// plugin has the _CapsProviderCreatePipeLine_ capability).
//
// If the plugin do not have the _CapsProviderCreatePipeLine_, it will Invoke `GetProfiles` to get the
// available profiles and add it to the default `providerpipe.ProviderPipeline`.
//
// If the plugin has  the capability _CapsProviderObtainCredentials_ it will get the _ObtainCredentials_
// function on the plugin, otherwise it will use the default mechanism to get the `TokenCredentialsProviderConfig`
// from the config system. The plugin may override the default verify mechanism where if it exposes the
// capability _CapsProviderVerifyCredentialUsage_. See the `provider.PipelineAwareProvider` for examples on how to implement
// respective credential, verify and template functions.
//
// TIP: Also see `providerpipe.ObtainCredentialsFunction` and `providerpipe.VerifyConnectFunction` for more samples.
func (sv *SVPlugin) createPipeLine(
	context ifcore.CbContext) (*providerpipe.ProviderPipeline, cberror.Error) {
	return providercommon.CreatePipeLine(context, sv.plugin, sv.sessionStore)

}

// importValues will execute a single instruction to import values.
func (sv *SVPlugin) importValues(
	c ifcore.CbContext,
	ep *url.URL,
	p *providerpipe.ProviderPipeline,
	evt *cbevent.SensorValueInboundEvent) cberror.Error {
	pbx, ok := sv.plugin.(SensorValuesInboundPluginDsBuilding)
	if !ok {
		return cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderImplementationMissing, nil,
			"The plugin do not implement interface: SensorValuesInboundPluginDsBuilding",
		)
	}

	exec := p.NewProviderPipelineExecutor()

	var overrideContext map[string]interface{}

	if sv.pluginCaps.BooleanByName(provider.CapsProviderPipelineOverrideContext, false) {
		if pbx, ok := sv.plugin.(provider.PipelineAwareProvider); ok {
			overrideContext = pbx.OverrideContext()
		} else {
			return cberror.NewCbErrorf(
				c.Service(), cberror.ErrorProviderImplementationMissing, nil,
				"The plugin do not implement interface: PipelineAwareProvider",
			)
		}
	}

	if filterContributor, ok := sv.plugin.(provider.ProviderFilterFunctionContributor); ok {
		exec.UseFilter(filterContributor.GetFilterFunctions())
	}

	c.SetValue(provider.ProviderCtxEndpoint, ep)
	c.SetValue(provider.ProviderCtxDryRun, evt.DryRun)

	exec.UseConfig(evt.ToConfigString(0)).
		UseOperation(string(locationmodel.ProviderOperationSensorValueIn))

	exec.UseSource(pbx.SourceFunc(c, exec, evt))

	if targetFunc := pbx.TargetFunc(c, exec, evt); targetFunc != nil {
		exec.UseTarget(targetFunc)
	} else {
		exec.UseTarget(providerpipe.DefaultDsBuildingImportTargetFunction())
	}

	if overrideContext != nil {
		exec.OverrideContext(overrideContext)
	}

	exec.Execute(providermodel.MappingDirectionLeftAssign)

	return exec.Error()
}
