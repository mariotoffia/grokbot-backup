package evb

import (
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/reportmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/rs/zerolog"
)

// emitCoreToTargetReport emits a core to target report.
//
// When _suppressError_ is `true`, it will not return any errors.
func emitCoreToTargetReport(
	ctx ifcore.CbContext,
	lid string,
	evt cbevent.CloudEvent,
	res []cbevent.CloudEmittedResultEvent,
	suppressError bool,
) cberror.Error {
	var (
		success = reportmodel.CoreTargetDataPointReportOk
		err     cberror.Error
		level   = zerolog.InfoLevel
		message string
		eventId string
	)

	m := map[string]*reportmodel.CoreDataPointInfo{}

	if len(res) == 0 {
		err = cberror.NewCbErrorf(
			ctx.Service(), 500, nil, "Event is empty, no event sent to event bridge",
		)
	} else {
		eventId = res[0].EventID

		if res[0].ErrorCode != "" || res[0].ErrorMessage != "" {
			err = cberror.NewCbErrorf(
				ctx.Service(), 500, nil, "Failed to send event to event bridge: %s (%s)",
				res[0].ErrorMessage, res[0].ErrorCode,
			)
		}
	}

	if err != nil {
		level = zerolog.WarnLevel
		message = "Failed to send event to event bridge"
		success = reportmodel.CoreTargetDataPointReportFail
	} else {
		message = "Event sent to event bridge"
	}

	report := &reportmodel.CoreTargetDataPointReport{
		Operation: string(locationmodel.ProviderOperationSensorValueIn),
		Success:   success,
		Body:      jsonutils.ToJSONMessagePtr(evt),
		Info: &reportmodel.CoreTargetDataPointReportInfo{
			Target:    reportmodel.CoreTargetDataPointReportTargetEventBridge,
			TargetID:  "default",
			SubTarget: evt.GetDataType(),
		},
		DataPoints: &reportmodel.CoreTargetDataPointReportBody{},
	}

	var stats bool

	if data := evt.GetData(); data != nil {
		stats = true

		switch t := data.(type) {
		case map[string]any:
			now := time.Now().UTC().Format(time.RFC3339)

			for k := range t {
				info := &reportmodel.CoreDataPointInfo{
					Value:     k,
					TimeStamp: now,
					Error:     err,
				}

				m[k] = info
			}
		case map[string]eqmodel.CbDataPoint:
			for k, v := range t {
				info := &reportmodel.CoreDataPointInfo{
					Value:     v.GetValue(),
					TimeStamp: v.GetTimeStamp().Format(time.RFC3339),
					Error:     err,
				}

				m[k] = info
			}
		case cbevent.DataPointData:
			for k, v := range t.Data {
				for _, dp := range v {
					info := &reportmodel.CoreDataPointInfo{
						Value:     dp.GetValue(),
						TimeStamp: dp.GetTimeStamp().Format(time.RFC3339),
						Error:     err,
					}

					m[k] = info
				}
			}
		case map[string][]eqmodel.CbDataPoint:
			for k, v := range t {
				for _, dp := range v {
					info := &reportmodel.CoreDataPointInfo{
						Value:     dp.GetValue(),
						TimeStamp: dp.GetTimeStamp().Format(time.RFC3339),
						Error:     err,
					}

					m[k] = info
				}
			}
		default:
			stats = false
		}
	}

	if stats {
		if success == reportmodel.CoreTargetDataPointReportOk {
			report.DataPoints.Success = m
			report.DataPoints.CountSuccess = len(m)
		} else {
			report.DataPoints.Failed = m
			report.DataPoints.CountFailed = len(m)
		}
	}

	log.Level(ctx, level, lid).
		WithMethod(string(reportmodel.ReportTypeCoreTargetDataPointReport)).
		WithError(err).
		WithDataType(logger.LDTDevOps).
		WithBody(report).
		WithError(err).
		Str("id", eventId).
		Msg(message)

	if suppressError {
		return nil
	}

	return err
}
