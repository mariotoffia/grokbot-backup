package providerconfig

import (
	"github.com/PaesslerAG/gval"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/pipeutils"

	util "github.com/Thiink-LLC/teos/go-core/utils"
)

// ResolveOperation gets the operation by _name_, clones the instance and
// evaluates the expressions before returning it. If not found `nil` is returned.
//
// If no _lang_ is provided, both `gval.Full()` and `cbeval.FullLanguage()` will be used.
// The provided _pipeContext_ is used while evaluating the Operation but it is not populated with
// the values. Instead the cloned `Operation` is returned (if no error).
//
// If any failures occurs during evaluation, an error is returned.
//
// .Operation Sample
// [source, go]
// ----
//
//	Operation: map[string]Operation{
//	  "sv": { // <1>
//	    Operation:      "['https://' + REP + '/DataPoints/Values/']", // <2>
//	    Params: map[string]interface{}{ // <3>
//	      "parentId": `['[{"Plants":"[{"Plants":"' + PID + '"}]"}]']`,
//	    },
//	  },
//	}
//
// ----
// <1> The operation sv stands for SensorValue (inbound collection), "esv": Export Sensor Value etc.
// <2> The operation itself, depending on provider, this may look differently, this example wants a full URL
// <3> Params is where e.g. query or other parameters are rendered (provider specific).
//
// NOTE: If string is not wrapped with brackets [], it will be treated as a standard string, otherwise it is
// treated as a expression and hence evaluated in `ResolveOperation`. *only* strings is allowed!
//
// This function will also check if _PDA_ is present in the parameters and do a policy data lookup
// and copy those to the _pipeContext_ provided to be used in execution.
//
// When _globals_ is set, it will be used as the input to the expression evaluation along with _pipeContext_.
// However, it will not modify the _pipeContext_ instead use a shallow copy of it.
func ResolveOperation(
	context ifcore.CbContext,
	cfg ifprovider.ConfigFull,
	name string,
	pipeContext map[string]interface{},
	globals map[string]any,
	lang ...gval.Language) (*providermodel.Operation, cberror.Error) {
	if len(cfg.GetOperations()) == 0 {
		return nil, nil
	}

	// evalMap is used when evaluating expressions
	evalMap := util.ShallowCopyMap(map[string]any{}, pipeContext)

	if nil != globals {
		evalMap = util.ShallowCopyMap(evalMap, globals)
	}

	if oper, ok := cfg.GetConfigOperation(name); ok {

		op, ok := oper.(*providermodel.Operation)
		if !ok {
			return nil, cberror.NewCbErrorf(
				context.Service(), 1, nil,
				"failed to cast operation to OperationImpl",
			)
		}

		clone := op.Clone()
		l := prepareLang(lang)

		if clone.GetOperation() != "" {
			if operationExpression, ok := pipeutils.GetStringExpression(clone.GetOperation()); ok {
				res, err := evaluate(
					context, "Operation", operationExpression, l, evalMap,
				)

				if nil != err {
					return nil, err
				}

				if nil != res {
					clone.Operation = res.(string)
				}
			}
		}

		if nil != clone.Params {
			for key, value := range clone.Params {
				if v, ok := value.(string); ok {
					if valueExpression, ok := pipeutils.GetStringExpression(v); ok {
						res, err := evaluate(context, key, valueExpression, l, evalMap)
						if nil != err {
							return nil, err
						}

						if nil != res {
							clone.Params[key] = res
							evalMap[key] = res
						} else {
							delete(clone.Params, key)
							delete(evalMap, key)
						}
					}

					if key == string(ifprovider.ParameterPolicyData) {
						_ = extractPDALoadPolicyData(
							context,
							cfg,
							clone.Params[key].(string),
							pipeContext,
						)
					}
				}
			}
		}

		return clone, nil
	}

	return nil, nil
}
