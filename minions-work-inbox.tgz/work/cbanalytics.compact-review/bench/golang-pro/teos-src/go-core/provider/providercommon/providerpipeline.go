package providercommon

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

// CreatePipeLine will create a pipeline either by invoking the plugin `CreatePipeline` (if the
// plugin has the _CapsProviderCreatePipeLine_ capability).
//
// If the plugin do not have the _CapsProviderCreatePipeLine_, it will Invoke `GetProfiles` to get the
// available profiles and add it to the default `providerpipe.ProviderPipeline`.
//
// If the plugin has  the capability _CapsProviderObtainCredentials_ it will get the _ObtainCredentials_
// function on the plugin, otherwise it will use the default mechanism to get the `TokenCredentialsProviderConfig`
// from the config system. The plugin may override the default verify mechanism where if it exposes the
// capability _CapsProviderVerifyCredentialUsage_. See the `provider.PipelineAwareProvider` for examples on how to implement
// respective credential, verify and template functions.
//
// TIP: Also see `providerpipe.ObtainCredentialsFunction` and `providerpipe.VerifyConnectFunction` for more samples.
func CreatePipeLine(
	context ifcore.CbContext,
	sv provider.Provider,
	sessionStore *config.SessionStore,
) (*providerpipe.ProviderPipeline, cberror.Error) {
	caps := sv.GetCapabilities()

	if caps.BooleanByName(provider.CapsProviderCreatePipeLine, false) {
		if pex, ok := sv.(providerpipe.PipelineAwareProviderEx); ok {
			return pex.CreatePipeLine(context, sessionStore)
		}

		panic(
			"Misconfigured provider, expected to implement PipelineAwareProviderEx",
		)
	}

	var obtainCredentials providerpipe.ObtainCredentialsFunction
	if pex, ok := sv.(providerpipe.PipelineCredentialsProvider); ok {
		obtainCredentials = pex.ObtainCredentialsFunc(context, sessionStore)
	} else {
		obtainCredentials = providerpipe.DefaultObtainCredentials
	}

	var verifyConnect providerpipe.VerifyConnectFunction
	if caps.BooleanByName(provider.CapsProviderVerifyCredentialUsage, false) {
		if pex, ok := sv.(providerpipe.PipelineCredentialsProvider); ok {
			verifyConnect = pex.VerifyConnectFunc(context, sessionStore)
		} else {
			panic(
				"Misconfigured provider, need to implement interface: provider.PipelineCredentialsProvider",
			)
		}
	} else {
		verifyConnect = providerpipe.DefaultVerifyConnect
	}

	p := providerpipe.NewProviderPipeline(
		context,
		sv.Name(),
		sessionStore,
		obtainCredentials,
		verifyConnect,
	)

	providerConfigFS, ok := sv.(provider.ProviderConfigurationFileSystemProvider)
	if !ok {
		panic(
			"Provider must implement the interface: provider.ProviderConfigurationFileSystemProvider",
		)
	}

	p.AddProviderConfigLoader(
		providerconfig.NewFsProviderConfigLoader(
			providerConfigFS.GetProviderConfigurationFileSystemObject(),
		),
	)

	return p, p.Error()
}
