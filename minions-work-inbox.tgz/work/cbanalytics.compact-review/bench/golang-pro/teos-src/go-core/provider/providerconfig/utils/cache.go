package utils

import (
	"fmt"
	"regexp"
	"sync"

	"github.com/gobwas/glob"
)

// ProviderExpressionCache is an glob/regexp expression cache.
type ProviderExpressionCache struct {
	cache sync.Map
}

// Glob will get or compile and cache a glob expression.
func (r *ProviderExpressionCache) Glob(expr string, sep rune) (glob.Glob, error) {
	id := fmt.Sprintf("%s:%s", expr, string(sep))

	glb, ok := r.cache.Load(id)

	if !ok {
		// Create new glob and cache it
		var err error
		glb, err = glob.Compile(expr, sep)

		if err != nil {
			return nil, err
		}

		r.cache.Store(id, glb)
	}

	if matcher, ok := glb.(glob.Glob); ok {
		return matcher, nil
	}

	return nil, fmt.Errorf("the id: %s is not a glob", id)
}

// RegExp will get or compile and cache a regexp expression.
func (r *ProviderExpressionCache) RegExp(expr string) (*regexp.Regexp, error) {
	id := fmt.Sprintf("regexp:%s", expr)

	re, ok := r.cache.Load(id)

	if !ok {
		// Create new regexp and cache it
		var err error
		re, err = regexp.Compile(expr)

		if err != nil {
			return nil, err
		}

		r.cache.Store(id, re)
	}

	if matcher, ok := re.(*regexp.Regexp); ok {
		return matcher, nil
	}

	return nil, fmt.Errorf("the id: %s is not a regexp", id)
}

// ProviderCache contains all the regexp and glob expressions that has been
// compiled and cached. This is global for all providers and instances of
// pipelines in the system.
var ProviderCache *ProviderExpressionCache = &ProviderExpressionCache{}
