package providerutils

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/reportmodel"
)

// generateMissingDataPointReport will create a report of missing data points if any
// such was found.
//
// If not found, it will return `false` and no valid report is generated.
//
// NOTE: Any error in the datapoint is regarded as missing and hence part of the report!
func generateMissingDataPointReport(
	c ifcore.CbContext,
	config *ReportContext,
) (report *reportmodel.ReportContainerImpl[reportmodel.MissingDataPointReport], ok bool) {
	noBody := strings.ToLower(
		config.ProviderConfig.GetParamAsStringWithDefault(
			string(ifprovider.ParameterNoBodyInMissingDataPointReport), "false",
		),
	) == "true"

	if config.Err != nil {
		// If error always output the body
		noBody = false
	}

	var rm json.RawMessage
	if len(config.Body) > 0 && !noBody {
		rm = json.RawMessage(config.Body)
	}

	var profile string

	if config.ProviderConfig != nil {
		profile = config.ProviderConfig.Profile
	}

	report = &reportmodel.ReportContainerImpl[reportmodel.MissingDataPointReport]{
		LocationID: config.ProviderConfig.GetParamAsStringWithDefault(
			string(ifprovider.ParameterLocationID),
			"",
		),
		Provider:   c.Provider(),
		Profile:    profile,
		ReportType: reportmodel.ReportTypeMissingDataPointReport,
		Error:      config.Err,
		Body: reportmodel.MissingDataPointReport{
			Wanted:    map[string]reportmodel.RemoteDataPointInfo{},
			Missing:   map[string]reportmodel.RemoteDataPointInfo{},
			Operation: string(config.ProviderOperation),
			Body:      &rm,
		},
	}

	processedWanted := map[string]bool{}
	for _, sensor := range config.WantedSensors {
		processedWanted[sensor] = false
	}

	// Process the datapoints
	var partition string
	for i := range config.DataPoints {
		dp := config.DataPoints[i]

		if config.SplitPartitionAndIDFunc != nil {
			_, partition = config.SplitPartitionAndIDFunc(dp.GetID())
		} else {
			partition = dp.GetPartition()
		}

		teosID := toTEOSID(config, dp)
		optional := config.IsOptional(teosID)
		processedWanted[teosID] = true

		report.Body.Wanted[teosID] = reportmodel.NewFromCbDataPoint(dp, optional)
		if dp.GetError() != nil {
			report.Body.Missing[teosID] = reportmodel.NewFromCbDataPoint(dp, optional)
		}
	}

	// Process those wanted but never found
	for teosID, processed := range processedWanted {
		if !processed {
			var remoteID string
			if r, ok := config.ProviderConfig.GetMappedTo(teosID); ok {
				remoteID = r
			} else {
				remoteID = fmt.Sprintf("could not find mapping for teosID: %s", teosID)
			}

			report.Body.Wanted[teosID] = reportmodel.RemoteDataPointInfo{
				RemoteID:        remoteID,
				RemotePartition: partition,
				Optional:        config.IsOptional(teosID),
			}

			report.Body.Missing[teosID] = reportmodel.RemoteDataPointInfo{
				RemoteID:        remoteID,
				RemotePartition: partition,
				Optional:        config.IsOptional(teosID),
			}
		}
	}

	// Count missing
	var mandatoryMissing, optionalMissing int
	for _, dp := range report.Body.Missing {
		if dp.Optional {
			optionalMissing++
			ok = true
		} else {
			mandatoryMissing++
			ok = true
		}
	}

	report.Body.MandatoryWantedCount = len(config.mandatoryID)
	report.Body.MandatoryMissingCount = mandatoryMissing

	report.Body.OptionalWantedCount = len(config.optionalID)
	report.Body.OptionalMissingCount = optionalMissing

	totalMissing := mandatoryMissing + optionalMissing

	report.Body.AllAreMissing = totalMissing == len(config.WantedSensors) &&
		(mandatoryMissing > 0 || optionalMissing > 0)

	return
}
