package providerpipe

import (
	"testing"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/observability/metrics"
	"github.com/Thiink-LLC/teos/go-core/observability/metrics/metricstest"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// The tests in this file are about what watches a provider's pipelines while
// they run.
//
// A provider configuration contains a pipeline, and the provider runs it every
// time it collects data. What is attached to those runs comes from the service
// the provider runs inside: a service built with a tracer and a meter registers
// them on its request context. A service that registers nothing gets nothing
// attached, and its pipelines cost what they cost with no observability at all.

// contextWithInstrumentation builds a request context that carries a tracer and
// a meter, the way a service that wants its pipelines observed would.
func contextWithInstrumentation(t *testing.T) (ifcore.CbContext, *metricstest.Tracer) {
	t.Helper()

	cbCtx := testenv.DefaultContext(t, "test-service")

	tracer := metricstest.NewTracer()
	cbCtx.ServiceRegistry().Set(
		string(ifcore.ServiceRegistryInstrumentation),
		metrics.InstrumentationConfig{Tracer: tracer, Meter: metricstest.New()},
	)

	return cbCtx, tracer
}

// TestProviderObservability_AServiceThatRegistersNothingGetsNoListeners is the
// rule that keeps a pipeline costing nothing when nobody is watching.
func TestProviderObservability_AServiceThatRegistersNothingGetsNoListeners(t *testing.T) {
	cbCtx := testenv.DefaultContext(t, "test-service")

	opts := runOptions(cbCtx, "", map[string]any{"a": 1})

	assert.Len(t, opts, 1, "only the starting variables, and nothing watching")
}

// TestProviderObservability_ATracerAndMeterOnTheContextAreAttachedToTheRun is
// the other half: a service that registered them gets its pipelines traced and
// counted without passing anything through the calls in between.
func TestProviderObservability_ATracerAndMeterOnTheContextAreAttachedToTheRun(t *testing.T) {
	cbCtx, _ := contextWithInstrumentation(t)

	previous := zerolog.GlobalLevel()
	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	t.Cleanup(func() { zerolog.SetGlobalLevel(previous) })

	opts := runOptions(cbCtx, "", map[string]any{"a": 1})

	assert.Len(t, opts, 3,
		"three run options: the starting variables, the tracing listener and the "+
			"counting listener")
}

// TestProviderObservability_NothingLogsWhenTheLoggerWouldDiscardTheLines checks
// the decision made once per run rather than once per event.
//
// The log-writing listener asks to be told about every kind of event, which
// means the runner produces every kind. A service running at information level
// would pay for all of them and write none, so it is not attached at all.
func TestProviderObservability_NothingLogsWhenTheLoggerWouldDiscardTheLines(t *testing.T) {
	cbCtx, _ := contextWithInstrumentation(t)

	previous := zerolog.GlobalLevel()
	t.Cleanup(func() { zerolog.SetGlobalLevel(previous) })

	zerolog.SetGlobalLevel(zerolog.InfoLevel)
	quiet := runOptions(cbCtx, "building-42", map[string]any{})

	zerolog.SetGlobalLevel(zerolog.DebugLevel)
	loud := runOptions(cbCtx, "building-42", map[string]any{})

	assert.Len(t, quiet, 3,
		"three run options at information level: the variables, the tracing "+
			"listener and the counting listener")
	assert.Len(t, loud, 4,
		"and a fourth at debug level: the listener that writes log lines")
}

// TestProviderObservability_TheNameOnASpanComesFromTheTracerNotFromTheEntry
// pins down where the name of the library producing a signal actually comes
// from, because it is easy to assume the wrong thing.
//
// A tracer is named when the service asks its OpenTelemetry provider for one
// (metrics/otel.NewTracerForScope). By the time it is registered it is already
// named, and nothing on the way to a pipeline can rename it. The name written
// beside a tracer in the registry entry is therefore not what a span carries —
// the tracer's own name is.
func TestProviderObservability_TheNameOnASpanComesFromTheTracerNotFromTheEntry(
	t *testing.T,
) {
	cbCtx := testenv.DefaultContext(t, "test-service")

	namedTracer := metricstest.NewTracerForScope(
		metrics.InstrumentationScope{Name: "example/service", Version: "1.0.0"},
	)

	cbCtx.ServiceRegistry().Set(
		string(ifcore.ServiceRegistryInstrumentation),
		metrics.InstrumentationConfig{
			Tracer: namedTracer,
			// A different name written here reaches nothing.
			Scope: metrics.InstrumentationScope{Name: "written/on/the/entry"},
		},
	)

	opts := runOptions(cbCtx, "", nil)
	require.NotEmpty(t, opts)

	_, span := namedTracer.Start(cbCtx.BackingContext(), "cbpipeline.run")
	assert.Equal(t, "example/service", span.(*metricstest.Span).Scope().Name,
		"the span carries the name the tracer was built with")
}

// TestProviderObservability_SomethingElseUnderThatNameIsIgnoredAndSaidSo checks
// that a service which meant to be observed and is not can find out why.
func TestProviderObservability_SomethingElseUnderThatNameIsIgnoredAndSaidSo(t *testing.T) {
	cbCtx := testenv.DefaultContext(t, "test-service")

	// A pointer to the configuration rather than the configuration itself is the
	// mistake this guards against, and it looks right at the call site.
	cbCtx.ServiceRegistry().Set(
		string(ifcore.ServiceRegistryInstrumentation),
		&metrics.InstrumentationConfig{Tracer: metricstest.NewTracer()},
	)

	_, found := instrumentationFrom(cbCtx)
	assert.False(t, found, "only the configuration itself is accepted")

	opts := runOptions(cbCtx, "", nil)
	assert.Len(t, opts, 1, "the pipeline runs, watched by nothing")
}

// TestProviderObservability_NothingRegisteredIsNotAFailure checks that the
// registry, which anything may write to, cannot make a pipeline fail.
func TestProviderObservability_NothingRegisteredIsNotAFailure(t *testing.T) {
	cbCtx := testenv.DefaultContext(t, "test-service")

	cbCtx.ServiceRegistry().Set(
		string(ifcore.ServiceRegistryInstrumentation), "not an instrumentation config",
	)

	_, found := instrumentationFrom(cbCtx)

	assert.False(t, found)
}
