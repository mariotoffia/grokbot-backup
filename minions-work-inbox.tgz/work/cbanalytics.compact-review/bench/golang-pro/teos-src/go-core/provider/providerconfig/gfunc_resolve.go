package providerconfig

import (
	"fmt"
	"strings"

	"github.com/PaesslerAG/gval"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// Resolve takes a profile name and returns the profile. The
// returned profile is cloned footnote:[Internally it uses
// `ProviderConfRepository.GetClone` to get the profile.] if
// the _clone_ parameter is `true`.
//
// If a additional parameter _path_ is given, it will lookup
// the path into the profile and create a new profile based
// on the path using the `providermodel.ProviderConfigImpl.CloneWithProfile`.
//
// NOTE: If the _clone_ is set to `false` it is not possible to use _path_ since
// that requires a clone.
//
// If the profile is not found, it will return `nil` and the error is set.
// .Function Signature
// [source,go]
// ----
// func resolve(clone bool, profile string, path ...string) ifprovider.ConfigFull // <1>
// ----
// <1> A single path parameter may be supplied.
//
// Example: `resolve(true, 'cetetherm/sv')`
//
// The above example will return 19 since 19.5 is higher than ceiling of 19.
func Resolve(repository *ProviderConfRepository) gval.Language {
	return gval.Function(
		"resolve",
		func(clone bool, profile string, path ...string) (ifprovider.ConfigFull, error) {

			var ok bool
			var full *providermodel.ProviderConfigImpl

			if clone {
				full, ok = repository.GetClone(profile)
			} else {
				full, ok = repository.GetOriginal(profile)
			}

			if !ok {
				return nil, fmt.Errorf("profile %s not found", profile)
			}

			if len(path) == 0 {
				return full, nil
			}

			if !clone {
				return nil, fmt.Errorf("path is not allowed when clone is false")
			}

			if len(path) > 1 {
				return nil, fmt.Errorf("only one path parameter is allowed")
			}

			name := strings.TrimPrefix(path[0], "#/profiles/")
			p, ok := full.Profiles[name]

			if !ok {
				return nil, fmt.Errorf("profile %s not found", name)
			}

			return full.CloneWithProfile(p), nil
		},
	)
}

// ToResolverEvaluable returns an Evaluable that can be used to resolve
// profiles or $ref.
func ToResolverEvaluable(
	ctx ifcore.CbContext,
	repository *ProviderConfRepository,
	expr string,
) (gval.Evaluable, cberror.Error) {

	resolve := Resolve(repository)

	eval, err := cbeval.Language(
		gval.Base(),
		gval.Arithmetic(),
		gval.Text(),
		cbeval.NewSearchLanguage(resolve /*additional*/),
		resolve,
	).NewEvaluableWithContext(ctx, expr)

	if err != nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), 1, err, "Failed to create Evaluable from expression '%s'", expr,
		)
	}

	return eval, nil
}
