package providerconfig

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
)

func TestSingleChoiceNoExpressionProfileSelection(t *testing.T) {
	ctx := newCtx(t)

	profiles := map[string]string{"#/profiles/plant-b": "true"}

	data := map[string]any{
		"PTP": "bravida-idt",
	}

	profileResolver := NewProfileResolver(nil /*repository*/)

	profile, err := profileResolver.ChooseProfile(ctx, profiles, data)
	require.NoError(t, err)
	require.Equal(t, "#/profiles/plant-b", profile)
}

func TestSingleChoiceProfileSelection(t *testing.T) {
	ctx := newCtx(t)

	profiles := map[string]string{"#/profiles/plant-b": "[true]"}

	data := map[string]any{
		"PTP": "bravida-idt",
	}

	profileResolver := NewProfileResolver(nil /*repository*/)

	profile, err := profileResolver.ChooseProfile(ctx, profiles, data)
	require.NoError(t, err)
	require.Equal(t, "#/profiles/plant-b", profile)
}

func TestMultiChoiceProfileSelection(t *testing.T) {
	ctx := newCtx(t)

	profiles := map[string]string{
		"#/profiles/plant-b": "['*.-wds1100$' =~ PTP]",
		"#/profiles/plant-a": "['bravida-idt' == PTP]",
	}

	data := map[string]any{
		"PTP": "bravida-idt",
	}

	profileResolver := NewProfileResolver(nil /*repository*/)

	profile, err := profileResolver.ChooseProfile(ctx, profiles, data)
	require.NoError(t, err)
	require.Equal(t, "#/profiles/plant-a", profile)
}

func TestResolveGlobals(t *testing.T) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)
	result, err := resolver.resolveReference(
		ctx,
		profile,
		"[:-m pc.Params.{GTM,PID**}:]",
		map[string]any{},
	)

	require.NoError(t, err)
	assert.Equal(t, 3, len(result))
	assert.Equal(t, "error-report", result["GTM"])
	assert.Equal(t, "plant-1", result["PID_O1"])
	assert.Equal(t, "plant-2", result["PID_O2"])

	result, err = resolver.resolveReference(
		ctx,
		profile,
		"[:-m -o resolve(false, 'multi-plant/1') Params.{GTM,PID**}:]",
		map[string]any{},
	)

	require.NoError(t, err)
	assert.Equal(t, 3, len(result))
	assert.Equal(t, "error-report", result["GTM"])
	assert.Equal(t, "mylink-1", result["PID_O1"])
	assert.Equal(t, "mylink-2", result["PID_O2"])

	result, err = resolver.resolveReference(
		ctx,
		profile,
		"multi-plant/1#/prms",
		map[string]any{},
	)

	require.NoError(t, err)
	assert.Equal(t, 12, len(result))
	assert.Equal(t, "error-report", result["GTM"])
	assert.Equal(t, "", result["MID"])
	assert.Equal(t, "", result["OID"])
	assert.Equal(t, "sv", result["OP"])
	assert.Equal(t, "mylink-1", result["PID_O1"])
	assert.Equal(t, "mylink-2", result["PID_O2"])
	assert.Equal(t, "api.climatixic.com", result["REP"])
	assert.Equal(t, "", result["SL"])
	assert.Equal(t, "", result["TID"])
	assert.Equal(t, "building", result["TRG"])
	assert.Equal(t, false, result["TS"])
	assert.Equal(t, "Europe/Stockholm", result["TZ"])

	result, err = resolver.resolveReference(
		ctx,
		profile,
		"#/profiles/plant-a/prms",
		map[string]any{},
	)

	require.NoError(t, err)
	assert.Equal(t, 7, len(result))
	assert.Equal(t, "[filter(:-m pc.Params.**:,'{PID,PTP}_**')]", result["$ref"])
	assert.Equal(t, "sv", result["OP"])
	assert.Equal(t, "[ORD]", result["ORD"])
	assert.Equal(t, "[PID]", result["PID"])
	assert.Equal(t, "[PTP]", result["PTP"])
	assert.Equal(t, "[TID]", result["TID"])
	assert.Equal(t, "building", result["TRG"])
}

func TestResolveOperationSVParams(t *testing.T) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)

	result, err := resolver.resolveReference(
		ctx,
		profile,
		"[:-m pc.Operation.sv.Params.{BID,DTS,PDA,PID}:]",
		map[string]any{},
	)
	require.NoError(t, err)
	assert.Equal(t, 3, len(result))
	assert.Equal(t, "[BID]", result["BID"])
	assert.Equal(t, "sv", result["PDA"])
	assert.Equal(t, "[PID]", result["PID"])

	result, err = resolver.resolveReference(
		ctx,
		profile,
		"multi-plant/1#/operations/sv/prms",
		map[string]any{},
	)

	require.NoError(t, err)
	assert.Equal(t, 6, len(result))
	assert.Equal(t, "[BID]", result["BID"])
	assert.Equal(t, "sv", result["PDA"])
	assert.Equal(t, "[PID]", result["PID"])
	assert.Equal(t, "[SL]", result["SL"])
	assert.Equal(t, "[TID]", result["TID"])
	assert.Equal(t, "[TS]", result["TS"])

	result, err = resolver.resolveReference(
		ctx,
		profile,
		"#/profiles/plant-a/operations/sv/prms",
		map[string]any{},
	)

	require.NoError(t, err)
	assert.Equal(t, 1, len(result))
	assert.Equal(t, "#/operations/sv/prms", result["$ref"])
}

func TestCreateNewProfileFromProfilesSection(t *testing.T) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)

	evalContext := map[string]any{
		string(ifprovider.PipeContextKeyProviderConfig): profile,
		"TID": "the-tenantID",
		"PTP": "the-plantType",
		"TZ":  "Europe/Stockholm",
		"PID": "the-plantID",
		"REP": "api.climatixic.com",
	}
	pc, err := resolver.ResolveClonedProfileAndReferences(
		ctx,
		"#/profiles/dpdisc",
		evalContext,
		false, /*overwrite*/
	)

	require.NoError(t, err)
	assert.Equal(t, "multi-plant/generic", pc.GetProfile())
	assert.Equal(
		t,
		"dpdisc",
		pc.GetParamAsStringWithDefault(string(ifprovider.ParameterOperation), ""),
	)
	assert.Equal(
		t,
		"default",
		pc.GetParamAsStringWithDefault(string(ifprovider.ParameterOwnerID), ""),
	)

	assert.Equal(
		t,
		"the-plantID",
		pc.GetParamAsStringWithDefault(string(ifprovider.ParameterPlantID), ""),
	)
}

func TestCreateNewProfileWithRefThatHasARefShouldBeCompletelyResolved(t *testing.T) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)

	evalContext := map[string]any{
		string(ifprovider.PipeContextKeyProviderConfig): profile,
		"TID": "the-tenantID",
		"PTP": "the-plantType",
		"TZ":  "Europe/Stockholm",
		"PID": "the-plantID",
		"REP": "api.climatixic.com",
		"ORD": "the-ordinal-1",
	}

	// plant-a.map -> plant-b.map -> "static profile (generic)"->map
	pc, err := resolver.ResolveClonedProfileAndReferences(
		ctx,
		"#/profiles/plant-a",
		evalContext,
		false, /*overwrite*/
	)

	require.NoError(t, err)
	assert.Equal(t, "multi-plant/generic", pc.GetProfile())
	/*
	   fmt.Println(

	   	NewConfigWriter(
	   		newCtx(t),
	   	).Pretty().
	   		AddProviderConfig(utils.ToProviderConfigImpl(pc)).
	   		Write().
	   		Buffer.String(),

	   )
	*/
}

func BenchmarkSingleChoiceNoExpressionProfileSelection(t *testing.B) {
	ctx := newCtx(t)

	profiles := map[string]string{"#/profiles/plant-b": "true"}

	data := map[string]any{
		"PTP": "bravida-idt",
	}

	profileResolver := NewProfileResolver(nil /*repository*/)

	for i := 0; i < t.N; i++ {
		_, _ = profileResolver.ChooseProfile(ctx, profiles, data)
	}
}

func BenchmarkSingleChoiceProfileSelection(t *testing.B) {
	ctx := newCtx(t)

	profiles := map[string]string{"#/profiles/plant-b": "[true]"}

	data := map[string]any{
		"PTP": "bravida-idt",
	}

	profileResolver := NewProfileResolver(nil /*repository*/)

	for i := 0; i < t.N; i++ {
		_, _ = profileResolver.ChooseProfile(ctx, profiles, data)
	}
}

func BenchmarkMultiChoiceProfileSelection(t *testing.B) {
	ctx := newCtx(t)

	profiles := map[string]string{
		"#/profiles/plant-b": "['*.-wds1100$' =~ PTP]",
		"#/profiles/plant-a": "['bravida-idt' == PTP]",
	}

	data := map[string]any{
		"PTP": "bravida-idt",
	}

	profileResolver := NewProfileResolver(nil /*repository*/)

	for i := 0; i < t.N; i++ {
		_, _ = profileResolver.ChooseProfile(ctx, profiles, data)
	}
}

func BenchmarkResolveOperationSVParamsExpression(t *testing.B) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)
	evalContext := map[string]any{}

	for i := 0; i < t.N; i++ {
		_, _ = resolver.resolveReference(
			ctx,
			profile,
			"[:-m pc.Operation.sv.Params.{BID,DTS,PDA,PID}:]",
			evalContext,
		)
	}
}

func BenchmarkResolveOperationSVParamsStringForm(t *testing.B) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)
	evalContext := map[string]any{}

	for i := 0; i < t.N; i++ {
		_, _ = resolver.resolveReference(
			ctx,
			profile,
			"multi-plant/1#/operations/sv/prms",
			evalContext,
		)
	}
}

func BenchmarkCreateNewProfileFromProfilesSection(t *testing.B) {
	ctx := newCtx(t)
	repository := NewProviderConfigRepository(
		ctx, NewFsProviderConfigLoaderFromPath("./testdata/standard/"),
	)

	profile, ok := repository.GetOriginal("multi-plant/generic")
	require.True(t, ok)

	resolver := NewProfileResolver(repository)

	evalContext := map[string]any{
		string(ifprovider.PipeContextKeyProviderConfig): profile,
	}

	for i := 0; i < t.N; i++ {
		_, _ = resolver.ResolveClonedProfileAndReferences(
			ctx,
			"#/profiles/dpdisc",
			evalContext,
			false, /*overwrite*/
		)
	}
}
