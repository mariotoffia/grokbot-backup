package svprovider

import (
	"bufio"
	"embed"
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"strings"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// TestMain applies the unit-test settings to every test in this package. The
// plugins the tests run build their own context the way a provider does.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvDefaults))
}

// cSpell: disable

// Simulation Support for Testing

// DatapointList is the fake response from a figurative API
type DatapointList struct {
	Partition  string                              `json:"-"`
	TotalCount int                                 `json:"totalCount"`
	Values     map[string]*eqmodel.CbDataPointImpl `json:"values"`
}

func NewDataPointList(partition string) *DatapointList {
	return &DatapointList{
		Partition: partition,
		Values:    map[string]*eqmodel.CbDataPointImpl{},
	}
}

func (dpl *DatapointList) Mappings() map[string]string {
	return map[string]string{
		"COMT":   "1!6WHH6DKH3CCVW-",
		"ECR":    "1!6WHH6DKHADPZ1N",
		"OFFODT": "1!6WHH6DKHICVDSS",
		"ODT":    "1!N3ASTG10KWTFCMU",
		"MPST":   "1!N3ASTHC-BG7OKIN",
		"MPRT":   "1!N3ASTHC-B1QKZ6J",
		"HDPS":   "1!N3ASTHC-BLP-OKR",
		"AMFPS":  "1!N3ASTHC-C326ZSV",
		"ACTODT": "1!N3ASTG10LK6MFV-",
		"MFPS":   "1!N3ASTHC-C85KKKB",
		"AEUPS":  "1!N3ASTHC-BQUOFIR",
		"SSHCT":  "1!N3ASTGK-9Y3HFMR",
		"RSHCT":  "1!N3ASTGK-A032Z1H",
		"IDT_O1": "1!N3ASTFSZHI2WD0F",
		"IDT_O2": "1!N3ASTFSZH7ZS23P",
		"IDT_O3": "1!N3ASTFSZHBDH467",
		"IDT_O4": "1!N3ASTFSZH183A6F",
		"IDT_O5": "1!N3ASTFSZH4NUC8Z",
		// Fredrik
		"HUM": "asset_one;humidity",
		"IDT": "asset_one;temperature",
	}
}
func (dpl *DatapointList) Value(
	key string,
	value interface{},
	ts *coremodel.CbTime32,
) *DatapointList {
	if ts == nil {
		ts = coremodel.NewTime32Now()
	}

	mappings := dpl.Mappings()
	dpl.Values[dpl.Partition+";"+mappings[key]] = &eqmodel.CbDataPointImpl{
		ID:        mappings[key],
		Partition: dpl.Partition,
		Value:     value,
		TimeStamp: *ts,
	}

	dpl.TotalCount++

	return dpl
}
func (dpl *DatapointList) Error(
	key string,
	err cberror.Error,
	ts *coremodel.CbTime32,
) *DatapointList {
	if ts == nil {
		ts = coremodel.NewTime32Now()
	}

	mappings := dpl.Mappings()
	dpl.Values[dpl.Partition+";"+mappings[key]] = &eqmodel.CbDataPointImpl{
		ID:        mappings[key],
		Partition: dpl.Partition,
		Value:     nil,
		Error:     err,
		TimeStamp: *ts,
	}

	dpl.TotalCount++

	return dpl

}

// BELOW IS THE ACTUAL PROVIDER

//go:embed testdata/provider-config/*.*
var providerConfig embed.FS

//go:embed testdata/policies/*.*
var policies embed.FS

//go:embed testdata/pdp-config/*.*
var pdpConfig embed.FS

type testProvider int

func (tp testProvider) Name() string {
	return "climatixic"
}
func (tp testProvider) GetCapabilities() coremodel.Capabilities {
	return coremodel.Capabilities{
		Caps: []coremodel.Capability{},
	}

}

func (sb testProvider) GetProviderConfigurationFileSystemObject() fs.FS {
	return providerConfig // Only Served from embedded resources
}

func (tp testProvider) GetTemplates() []string {
	return []string{} // Not used!
}

func (tp testProvider) GetTargetType() interface{} {
	return nil // Not used since DsBuilding device shadow
}

func (tp testProvider) OverrideContext() map[string]interface{} {
	return nil // Not used
}

var datapointList *DatapointList
var wanted []string
var obtainCredentialsError cberror.Error

// cSpell: disable
func (tp testProvider) SourceFunc(context ifcore.CbContext,
	exec *providerpipe.ProviderPipelineExecutor,
	evt *cbevent.SensorValueInboundEvent) providerpipe.SourceFunction {
	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}) (map[string]interface{}, cberror.Error) {
		if err := providerutils.DataPointReport(context,
			&providerutils.ReportContext{
				Operation:              op,
				ProviderConfig:         pc,
				WantedSensors:          wanted,
				ProviderOperation:      locationmodel.ProviderOperationSensorValueIn,
				DataPoints:             eqmodel.ToCbDataPointSliceFromMap(datapointList.Values),
				MapperWithoutPartition: true, /*we dont use PID in mapping segment*/
			}); err != nil {
			return nil, err
		}

		return map[string]interface{}{"src": datapointList}, nil
	}
}

func (tp testProvider) ObtainCredentialsFunc(
	context ifcore.CbContext,
	store *config.SessionStore,
) providerpipe.ObtainCredentialsFunction {
	return func(context ifcore.CbContext,
		cred string,
		pipeCtx map[string]any,
		op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
		return nil, 0, obtainCredentialsError
	}
}

func (tp testProvider) VerifyConnectFunc(
	context ifcore.CbContext,
	store *config.SessionStore,
) providerpipe.VerifyConnectFunction {
	return func(ctx ifcore.CbContext, cred string, credentials any, op *providermodel.Operation) bool {
		return true
	}
}

// cSpell: disable
var targetLocation *dsmodel.DsBuilding

func (tp testProvider) TargetFunc(context ifcore.CbContext,
	exec *providerpipe.ProviderPipelineExecutor,
	evt *cbevent.SensorValueInboundEvent) providerpipe.TargetFunction {
	return func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{},
		target map[string]interface{}) cberror.Error {
		data, err := json.Marshal(target["target"])
		if err != nil {
			return cberror.NewCbErrorf("test", 1, err, "failed to marshal target")
		}

		if err := json.Unmarshal(data, &targetLocation); err != nil {
			return cberror.NewCbErrorf("test", 1, err, "failed to unmarshal target")
		}

		return nil
	}

}

// GetPolicyRetrievalPoints implements `StaticPolicyRetrievalPointContributingProvider` interface.
func (tp testProvider) GetPolicyRetrievalPoints() []ifcore.PolicyRetrievalPoint {
	return []ifcore.PolicyRetrievalPoint{
		cbpolicy.NewImmutablePRP(nil /*noKey*/).RegisterFsModules(policies),
	}

}

// GetPDPConfigFSys implements `StaticPolicyDecisionPointContributingProvider` interface.
func (tp testProvider) GetPDPConfigFSys() []fs.FS {
	return []fs.FS{pdpConfig}

}

var logLevel = "fatal"

func BenchmarkSamplePluginSuccess(t *testing.B) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel}

	// ODT and IDT_03 is out of range, filtered out and reported in log.
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}`

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	// This is misleading since it is the same as running lambda at cold startup
	// on each iteration. Hence *really* slow!!

	defer cbenv.CB_REP.UnSet()

	// Otherwise calls to AWS will be 99% of the total time
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(-40), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(-669), nil).
		Value("IDT_O4", float64(40), nil)

	for i := 0; i < t.N; i++ {
		NewDsBuildingPlugin(
			testProvider(0), "unit-test", "test-provider",
			bufio.NewReader(strings.NewReader(data)),
		).Execute()
	}
}
