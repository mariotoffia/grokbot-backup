package svprovider

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/url"

	"github.com/aws/aws-lambda-go/events"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

func (sv *SVPlugin) importSensorValues(
	c ifcore.CbContext,
	ep *url.URL,
	dryrun bool,
	evt *cbevent.SensorValueInboundEvent) (cbevent.ProviderResultEvent, error) {
	// Endpoint override
	if nil != ep {
		evt.Endpoint = ep.String()
	} else {
		ep := utils.GetURLFromContext(c, provider.ProviderCtxEndpoint)

		if evt.Endpoint != "" && ep == nil {
			ep = utils.CreateSchemeURL("https://", evt.Endpoint)
			c.SetValue(provider.ProviderCtxEndpoint, ep)
		}
	}

	// Dryrun override
	if dryrun {
		evt.DryRun = dryrun
	}

	empty := cbevent.ProviderResultEvent{}

	if len(evt.Config) == 0 {
		if l, ok := logger.ClsLog(zerolog.WarnLevel, "importSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
			logger.LogObject(l, "err", cberror.NewCbErrorConfigurationErrorf(
				c.Service(),
				cberror.ConfigurationErrorMissingConfiguration,
				cberror.ErrorProviderCfgMissingForEvent,
				nil, nil, nil, "No configuration provided for event: %#v", evt,
			))
		}

		// Do not retry since this needs to be fixed before execute import pipeline
		return empty, nil
	}

	// Plugin takes *all* responsibilities to process this event.
	if sv.pluginCaps.BooleanByName(CapsProviderSVIPluginImportSensorValues, false) {
		if pex, ok := sv.plugin.(SensorValuesInboundPluginExt); ok {
			return empty, pex.ImportSensorValues(c, evt)
		}

		return empty, cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderImplementationMissing, nil,
			"Misconfigured provider, expected to implement SensorValuesOutboundPluginExt",
		)
	}

	// Verify in event
	if evt.Verify == cbevent.VerifyConfigStatic {
		return sv.verifyConfigStatic(c, evt), nil
	}

	p, err := sv.createPipeLine(c)

	if err != nil {
		return empty, err
	}

	r := cbevent.ProviderResultEvent{Status: []string{}}
	r.CorrID = evt.CorrID

	if evt.Result {
		r.Result = []any{}
	}

	var importError cberror.Error
	returnError := true

	if importError = sv.importValues(c, ep, p, evt); importError != nil {
		r.Status = append(r.Status, importError.Error())

		var PreProvisionError *cberror.CbErrorInPreProvisionedMode
		var ConfigError *cberror.CbConfigurationError

		logLevel := zerolog.InfoLevel
		var msg string

		if errors.As(importError, &PreProvisionError) {
			// Do not return these errors since, they are expected
			returnError = false
			msg = fmt.Sprintf(
				"Configuration is in pre-provision mode failed - config %v",
				evt.Config[0],
			)
		} else if errors.As(importError, &ConfigError) {
			// If validate, the config needs to be fixed before retrying.
			returnError = false
			logLevel = zerolog.WarnLevel
			msg = fmt.Sprintf("Configuration is not valid - config %v", evt.Config[0])
		} else {
			msg = fmt.Sprintf("Failed to execute config %v", evt.Config[0])
		}

		if l, ok := logger.ClsLog(logLevel, "importSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
			logger.LogObject(l, "err", importError).Msg(msg)
		}
	} else {
		r.Status = append(r.Status, "")
	}

	if returnError {
		return r, importError
	}

	return r, nil
}

// processSQSEvent iterates the records and `Unmarshal` to `cbevent.SensorValueInboundEvent` that is sent to the
// `exportSensorValues` function.
//
// It will return the last error encountered but will process all records regardless.
func (sv *SVPlugin) processSQSEvent(
	c ifcore.CbContext,
	ds *events.SQSEvent,
	ep *url.URL,
	dryrun bool) error {
	var err error
	var importErrors []error

	for _, record := range ds.Records {
		if record.Body != "" {
			var evt cbevent.SensorValueInboundEvent
			err = json.Unmarshal([]byte(record.Body), &evt)

			if err != nil {
				if l, ok := logger.ClsLog(zerolog.ErrorLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
					l.Msgf(
						"Failed to create SensorValueOutboundEvent from body: %s (skipping)",
						record.Body,
					)
				}
			} else {
				if dryrun {
					evt.DryRun = dryrun
				}

				if evt.Endpoint == "" && nil != ep {
					evt.Endpoint = ep.String()
				}

				_, err = sv.importSensorValues(c, ep, dryrun, &evt)
				if nil != err {
					importErrors = append(importErrors, err)
				}
			}
		}
	}

	if len(importErrors) > 0 {
		return cberror.NewCbCompositeErrorf(
			c.Service(),
			cberror.ErrorProviderFailToProcessEvent,
			importErrors, nil,
			"Errors while processing import instructions [errcnt: %d, num-records: %d]",
			len(importErrors), len(ds.Records),
		)
	}

	if len(importErrors) == 1 {
		return importErrors[0]
	}

	return nil
}
