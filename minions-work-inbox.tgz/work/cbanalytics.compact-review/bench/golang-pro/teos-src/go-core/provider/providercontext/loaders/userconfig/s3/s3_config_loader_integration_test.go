//go:build integration

package s3_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	cbctx "github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/awamgrstore"
	s3loader "github.com/Thiink-LLC/teos/go-core/provider/providercontext/loaders/userconfig/s3"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

var testBucketName = "test-bucket"
var bucketKeyPrefix = "rtcingest/sv/v1.0.0"
var locationID = "Måssmyren 18"

// newTestContext returns a context on the local development environment. The
// test settings and the AWS backend come from TestMain, so the context loads its
// AWS configuration from the environment TestMain prepared.
func newTestContext(t *testing.T) ifcore.CbContext {
	t.Helper()

	c, err := cbctx.NewContextWithDefaultOptions("s3-loader-integration", "test", cbenv.DevLocal)
	require.Nil(t, err)
	t.Cleanup(c.Close)

	return c
}

func TestLoadS3BucketWithKeyThatDoExist(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestLoadS3BucketWithKeyThatDoExist in short mode")
	}

	ctx := newTestContext(t)

	mgr := awamgrstore.NewStorageManagerS3(ctx).UseBucket(utils.RandomPostfix(testBucketName)).
		CreatePrivateBucket()

	require.Equal(t, nil, mgr.Error())

	t.Cleanup(func() {
		if err := mgr.ClearError().DeleteBucket(true /*force*/).Error(); err != nil {
			t.Errorf("cleanup: delete bucket %s: %v", mgr.Bucket(), err)
		}
	})

	// use the S3ProviderConfigLoader and do load.
	// It should return the buffer as a string and no error

	mgr.UploadBuffer(
		"rtcingest/sv/v1.0.0/Måssmyren 18.json",
		[]byte(`{"profile":"test-profile"}`),
	)

	require.NoError(t, mgr.Error())

	loader := s3loader.NewS3ProviderConfigLoader(
		ctx,
		mgr.Bucket(),
		bucketKeyPrefix,
		true, /*optional*/
	)

	userConfig, err := loader.Load(ctx, locationID)
	assert.NoError(t, err)

	assert.Equal(t, `{"profile":"test-profile"}`, userConfig)
}

func TestLoadS3BucketWithKeyThatDoNotShallGiveNoErrorButEmptyUserConfig(t *testing.T) {
	if testing.Short() {
		t.Skip(
			"Skipping integration test TestLoadS3BucketWithKeyThatDoNotShallGiveNoErrorButEmptyUserConfig in short mode",
		)
	}

	ctx := newTestContext(t)

	mgr := awamgrstore.NewStorageManagerS3(ctx).UseBucket(utils.RandomPostfix(testBucketName)).
		CreatePrivateBucket()

	require.Equal(t, nil, mgr.Error())

	t.Cleanup(func() {
		if err := mgr.ClearError().DeleteBucket(true /*force*/).Error(); err != nil {
			t.Errorf("cleanup: delete bucket %s: %v", mgr.Bucket(), err)
		}
	})

	loader := s3loader.NewS3ProviderConfigLoader(
		ctx,
		mgr.Bucket(),
		bucketKeyPrefix,
		true, /*optional*/
	)

	userConfig, err := loader.Load(ctx, locationID)
	assert.NoError(t, err)

	assert.Equal(t, "", userConfig)
}

func TestLoadS3BucketWithBucketThatDoNotExistShallGiveError(t *testing.T) {
	if testing.Short() {
		t.Skip(
			"Skipping integration test TestLoadS3BucketWithBucketThatDoNotExistShallGiveError in short mode",
		)
	}

	ctx := newTestContext(t)

	loader := s3loader.NewS3ProviderConfigLoader(
		ctx,
		utils.RandomPostfix(testBucketName),
		bucketKeyPrefix,
		true, /*optional*/
	)

	_, err := loader.Load(ctx, locationID)
	assert.Error(t, err)
}
