package providerpipe

import (
	"errors"
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"

	"github.com/rs/zerolog"
)

// NewPipelineExecutorImpl creates a new instance of the provider pipeline executor.
//
// This is then used to execute the complete provider pipeline whereas it may be a single pipe execution
// or multiple depending on the provider configuration (profile) and pipeline configuration.
func NewPipelineExecutorImpl(ctx ifcore.CbContext) *ProviderPipelineExecutorImpl {
	return &ProviderPipelineExecutorImpl{
		ctx:   ctx,
		input: map[string]any{},
	}
}

// Execute the provider pipeline and returns the result.
//
// NOTE: Since the pipeline and the config may result in multiple iterations (of profile invocations),
// the result is a slice of `IterationExecutionResult`.
//
// Each iteration will have a result, but may also have an error. If an error occurs, the iteration
// will be aborted and the next iteration will be executed. In essence, it is _best effort_.
func (e *ProviderPipelineExecutorImpl) Execute() IterationExecutionResults {
	pc := utils.ToProviderConfigImpl(e.config)

	// If disabled config, do nothing
	pst := ifprovider.ProvisionedState(pc.GetParamAsStringWithDefault(
		string(ifprovider.ParameterProvisionedState),
		string(ifprovider.ProvisionedStateProvisioned),
	))

	if pst == ifprovider.ProvisionedStateDisabled {
		lid := pc.GetParamAsStringWithDefault(
			string(ifprovider.ParameterLocationID),
			"unknown",
		)

		log.InfoWithLocationID(e.ctx, lid).
			Msg("Configuration is disabled, skipping execution")

		return IterationExecutionResults{
			{
				Result:    map[string]any{},
				Operation: locationmodel.ProviderOperation(e.operation),
			},
		}
	}

	if len(pc.Process) > 0 {
		// Provider Config Process Execution
		if e.input == nil {
			e.input = map[string]any{}
		}

		return e.processItemExecutor(e.input, pc.Process)
	}

	// Has Operation?
	if e.operation == "" {
		return IterationExecutionResults{
			{
				Operation: locationmodel.ProviderOperation(e.operation),
				Error: cberror.NewCbErrorfWithProps(
					e.ctx.Service(), cberror.ErrProviderOperationNotFound, nil,
					map[string]any{"pn": e.ctx.Provider()},
					"no operation (empty string) is set in the builder",
				),
			},
		}
	}

	// Plain Provider Config Execution
	pipe := e.pipeline.operations[string(e.operation)]
	pipe.Owner = e.pipeline

	builder := NewExecutorBuilder(e.ctx).
		UsePipe(pipe).
		UseConfig(e.config).
		UseInput(e.input).
		UsePrepareProfile(pipe.prepareProfile).
		UseAutoLogging()

	if e.allowMutateGlobalParams {
		builder.AllowMutateGlobalParams()
	}

	exec := builder.Build().Execute()

	// Return the result as a single iteration
	res := IterationExecutionResults{
		{
			Result:    exec.GetResult(),
			Error:     exec.Error(),
			Operation: locationmodel.ProviderOperation(e.operation),
		},
	}

	// log the result
	e.logResult(res[0])

	return res
}

func (e *ProviderPipelineExecutorImpl) logResult(res *IterationExecutionResult) {
	// Success?
	if res.Error == nil {
		log.Info(e.ctx).
			WithMethod("PipelineExecutor").
			WithBody(res.Result).
			Bool("success", true).
			Msg("Provider execution completed successfully")

		return
	}

	var PreProvisionError *cberror.CbErrorInPreProvisionedMode
	var ConfigError *cberror.CbConfigurationError

	logLevel := zerolog.InfoLevel

	var msg string

	if errors.As(res.Error, &PreProvisionError) {
		msg = fmt.Sprintf(
			"Configuration is in pre-provision mode profile: %s",
			e.config.GetProfile(),
		)
	} else if errors.As(res.Error, &ConfigError) {
		logLevel = zerolog.WarnLevel
		msg = fmt.Sprintf("Configuration is not valid - profile %s", e.config.GetProfile())
	} else {
		msg = fmt.Sprintf("Failed to execute config - profile: %s", e.config.GetProfile())
	}

	lid, _ := e.config.GetParamAsString(string(ifprovider.ParameterLocationID))

	if log.IsEnabled(logLevel) {
		log.Level(e.ctx, logLevel, lid).
			WithMethod("PipelineExecutor").
			WithError(res.Error).
			WithBody(res.Result).
			Bool("success", false).
			Msg(msg)
	}
}

// processItemExecutor invokes the process items.
//
// This will recurse into sub-processes if found.
func (e *ProviderPipelineExecutorImpl) processItemExecutor(
	args map[string]any,
	items []*providermodel.ProcessItemImpl,
) IterationExecutionResults {
	var results IterationExecutionResults
	for i := range items {
		processItem := items[i]

		executor := NewProcessItemExecutorImpl(
			e.ctx,
			e.pipeline,
			processItem,
			e.config,
			nil, /*currentProfile*/
			e.allowMutateGlobalParams,
		)

		result := executor.Execute(e.ctx, args)

		if len(result) > 0 {
			results = append(results, result...)
		}

		// Recurse into sub-processes
		if len(processItem.Process) > 0 {
			// ForEach result, invoke the sub-process
			for i := range result {
				res := result[i]

				// Only non-error results are processed
				if res.Error != nil {
					continue
				}

				result := e.processItemExecutor(res.Exports, processItem.Process)
				results = append(results, result...)
			}
		}
	}

	return results
}
