package cfgchgsrc

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils/jsondiffutil"
)

func ToSelectors(selector ...string) []Selector {
	s := make([]Selector, len(selector))

	for i, v := range selector {
		s[i] = Selector{Select: v}
	}

	return s
}

type Selector struct {
	// Select is the expression to match the diff with. e.g. _/Config/*_ will match all
	// changes under _Config_ node.
	//
	// The select expression will result in a list of `jsondiffutil.Operation` that will be
	// added to the `map[string]any` where the key is the `jsondiffutil.Operation.Name()` by
	// default.
	Select string
	// LeafExpandIndex is a index to expand into map[string]any, recursively, until the leaf.
	// If leaf index is greater than this index. If this is set to _zero_ it will just take
	// the `jsondiffutil.Operation.Name()` as the key and `jsondiffutil.Operation.Value` as the
	// value.
	//
	// Thus this index is _one_ based.
	//
	// NOTE: This is only done in `cbevent.ConfigOperationUpdated` operations.
	LeafExpandIndex int
}

type ConfigPipeSourceOptions struct {
	// CreateOnUpdate will treat update as create.
	CreateOnUpdate bool
}

// DefaultConfigPipeSource will convert a config change event into a configuration source.
//
// The _selectors_ are used to do a glob match on the diff to capture the changed values wanted
// to be populated in the returned map (under the source key). If any of the _selectors_ fails,
// the whole operation will fail.
//
// 1. When new config is created, it will add all parameters to source that was created.
// 2. When a config is deleted, it will add all parameters that was deleted to source.
// 3. When a config is updated, it will add all parameters that was changed to source.
//
// CAUTION: Even though selectors is optional, it will panic!!
func DefaultConfigPipeSource(
	opt ConfigPipeSourceOptions,
	selectors ...Selector,
) providerpipe.SourceFunction {
	//
	if len(selectors) == 0 {
		panic("selectors for config source are MANDATORY!!")
	}

	return func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		cfgChange, err := extractEventFromPayload(ctx, pipeCtx)

		if err != nil {
			return nil, err
		}

		createOnUpdate := pc.GetParamAsBoolWithDefault(
			string(ifprovider.ParameterCfgCreateOnUpdate),
			opt.CreateOnUpdate,
		)

		m, err := SelectorDiffConfigChange(
			ctx,
			cfgChange,
			createOnUpdate,
			selectors...,
		)

		if err != nil {
			return nil, err
		} else {
			return map[string]any{
				"src":    cfgChange,
				"source": m,
			}, nil
		}
	}
}

// SelectorDiffConfigChange will select data in a config change event and produce a map of the diff.
func SelectorDiffConfigChange( /* NOSONAR */
	ctx ifcore.CbContext,
	cfgChange *cbevent.ConfigChangeEventImpl,
	createOnUpdate bool,
	selectors ...Selector,
) (map[string]any, cberror.Error) {
	patch, err := diff(cfgChange, createOnUpdate)

	if err != nil {
		return nil, err
	}

	// Populate with the changed values.
	m := map[string]any{}

	for _, selector := range selectors {
		found, err := patch.SelectGlob(ctx, selector.Select)

		if err != nil {
			return nil, err
		}

		if len(found) == 0 {
			found, err = patch.SelectExpandPatch(ctx, selector.Select)
		}

		if err != nil {
			return nil, err
		}

		switch cfgChange.Oper {
		case cbevent.ConfigOperationCreated:
			for _, v := range found {
				if v.Type == jsondiffutil.OperationAdd ||
					v.Type == jsondiffutil.OperationCopy ||
					v.Type == jsondiffutil.OperationReplace {
					m[v.Name()] = v.Value
				}
			}
		case cbevent.ConfigOperationDeleted:
			for _, v := range found {
				if v.Type == jsondiffutil.OperationRemove {
					m[v.Name()] = v.OldValue
				}
			}
		case cbevent.ConfigOperationUpdated:
			m = ConfigUpdate(m, selector, found)
		default:
			return nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), 400, nil,
				map[string]any{cberror.PropertyProvider: ctx.Provider()},
				"Unexpected config operation: %s", string(cfgChange.Oper),
			)
		}
	}

	return m, nil
}

// diff handles diff for create, update and delete.
//
// NOTE: When delete it will make sure that the source is the config being deleted and
// target is empty object. Hence, all will be delete operations.
//
// When the caller wants to treat update as create, set the flag _createOnUpdate_ to `true`.
func diff(
	evt *cbevent.ConfigChangeEventImpl,
	createOnUpdate bool,
) (jsondiffutil.Patch, cberror.Error) {
	var source, target []byte

	if evt.Old != nil {
		source = []byte(*evt.Old)
	} else {
		source = []byte(`{}`)
	}

	if evt.Data != nil {
		target = []byte(*evt.Data)
	} else {
		target = []byte(`{}`)
	}

	// Swap source and target if the operation is deleted.
	if evt.Oper == cbevent.ConfigOperationDeleted {
		source, target = target, source
	} else if evt.Oper == cbevent.ConfigOperationUpdated && createOnUpdate {
		source = []byte(`{}`)
	}

	return jsondiffutil.Diff(nil, []byte(source), []byte(target))
}

func extractEventFromPayload(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
) (*cbevent.ConfigChangeEventImpl, cberror.Error) {
	//
	evt, ok := pipeCtx[ifprovider.PipeContextKeyEvent]

	if !ok {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorFailToFindEventInPipeContext, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Missing event in pipe context",
		)
	}

	event, ok := evt.(*cbevent.ProviderEvent)

	if !ok {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting *cbevent.ProviderEvent, got %T", evt,
		)
	}

	if event.PayloadType != cbevent.PayloadConfigChangeEvent {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting %s, got %s", cbevent.PayloadConfigChangeEvent, event.PayloadType,
		)
	}

	var cfgChanged *cbevent.ConfigChangeEventImpl

	if err := json.Unmarshal(*event.Payload, &cfgChanged); err != nil {
		return nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, err,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Failed to unmarshal payload",
		)
	}

	return cfgChanged, nil
}
