package s3sqs

import (
	"runtime"
	"time"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cbsqs"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
)

// DispatchSQSwithS3Events is a dispatcher that will dispatch the `*events.S3Event` to the
// provider by extracting them from the `*events.SQSEvent` and feed them to
// a provider in the `providercontext.ProviderContext.Execute()`.
//
// NOTE: This dispatcher *REQUIRES* that a _SQS_ queue is receiving the `s3.EventType.OBJECT_CREATED`
// events and this dispatcher is the target for that _SQS_ queue. Make sure that the _SQS_ queue
// has a proper visibility timeout since this may take some considerable time to process. At least
// _120 seconds_ is recommended.
//
// The _S3Event_ will contains one or more S3 keys that has been uploaded to the S3 bucket that
// may be loaded by the receiver.
//
// The parallelism for sqs dispatch messages is set to `10` and timeout is set to _240s_.
// The total max parallelism is defaulted to `runtime.NumCPU*64`. It is possible override
// the parallelism by `CB_PROV_DISP_PARALLELISM` and the timeout by `CB_PROV_DISP_PARALLELISM_TIMEOUT`.
//
// Each `*events.SQSRecord` may contain multiple `*events.S3EventRecord` and each of those
// may contain one or more location ID (LID) to be exported. Thus, parallelism is consumed
// to parallelize as many LID "records" as possible.
//
// If there are any parallelism left, it will be spread out over each LID to internally parallelize
// if needed. This is set as input to the profile (`ifprovider.ParameterMaxParallelism`). Thus
// it is possible to bind it into the prms part as e.g. _"MXP": "[MXP ? MXP : 1]"_.
//
// The _defaultProfile_ is used when no profile was found for a certain LocationID in the loaded JSON data object.
// It is possible to override the default profile by setting the `CB_PROV_DEFAULT_PROFILE` environment variable.
func DispatchSQSwithS3Events(
	path string,
	builder *providercontext.ProviderContextBuilderImpl,
	defaultProfile string,
	jsonLoader JSONLoaderFunc,
) providercontext.ProviderHandlerFunc {
	//
	parallelism := int(cbenv.CB_PROV_DISP_PARALLELISM.Integer(int64(64 * runtime.NumCPU())))

	timeout := time.Duration(
		cbenv.CB_PROV_DISP_PARALLELISM_TIMEOUT.Integer(240) * int64(time.Second),
	)

	defaultProfile = cbenv.CB_PROV_DEFAULT_PROFILE.String(defaultProfile)

	return func(pc providercontext.ProviderContext) dispruntime.HandlerInvoker {
		return cbsqs.JSONWithRoute(
			path,
			pc.Context(),
			func(ctx ifcore.CbContext, event *events.S3Event) error {
				return processS3Events(
					ctx,
					pc,
					event,
					defaultProfile,
					parallelism-len(event.Records),
					timeout,
					jsonLoader,
				)
			},
			cbsqs.WithParallelism(10),
			cbsqs.WithTimeout(timeout),
		)
	}
}
