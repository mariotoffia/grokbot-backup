package providerpipe

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// PipelineAwareProviderEx is for more advanced providers / plugins to be able to do more customizations.
type PipelineAwareProviderEx interface {
	// CreatePipeLine is invoked *only* if the plugin has the _CapsProviderCreatePipeLine_
	//
	// The `CreatePipeLine` recieves a invocation Thiink _context_. If _sessionStore_ is supported by the
	// provider it is passed, otherwise `nil`. The function shall construct a fully initialized
	// `providerpipe.ProviderPipeline` that may be extended with configuration, functions.
	//
	// NOTE: If provider or plugin specify _CapsProviderCreatePipeLine_ the runtime will not call any other
	// methods specified in `PipelineAwareProvider` interface.
	//
	// .Example Pipe Initialization
	// [source,go]
	// ----
	// var genericProfile = `{}` // A profile (see GetTemplates for sample)
	//
	// func createPipeLine(context ifcore.CbContext, sessionStore *sc.SessionStore) *providerpipe.ProviderPipeline {
	//
	// 	p := providerpipe.NewProviderPipeline(
	// 		context, "myProvider", sessionStore,
	// 		ObtainCredentials,
	// 		VerifyConnect).
	// 		CreateConfigFromString(genericProfile)
	//
	// 	if p.Error() != nil {
	// 		fmt.Println(p.Error().Error())
	// 	}
	//
	// 	return p
	// }
	// ----
	CreatePipeLine(
		context ifcore.CbContext,
		sessionStore *config.SessionStore) (*ProviderPipeline, cberror.Error)
}

// PipelineCredentialsProvider is for providers / plugins that have custom handling on retrieving / verifying credentials.
type PipelineCredentialsProvider interface {
	// ObtainCredentialsFunc returns a function that will retrieve and configure credentials to be used in the pipeline.
	//
	// This function is invoked when the provider / plugin has the _CapsProviderObtainCredentials_ capability. If not
	// the default mechanism, that is fetch the `securitymodel.TokenCredentialsImpl` and try parse the _TTL_.
	//
	// TIP: Also see `providerpipe.ObtainCredentialsFunction` for more information.
	//
	// .Example Obtain Credential Function
	// [source,go]
	// ----
	// func ObtainCredentials(
	// 	 context ifcore.CbContext,
	// 	 cred string,
	// 	 eop *config.Operation) (interface{}, int64, cberror.Error) { // <1>
	//
	// 	  ptr, ttl := providerpipe.ParseCredString(cred) // <2>
	//
	// 	  var cfg securitymodel.TokenCredentialsImpl
	// 	  s := config.New(context).UsePrefix(ptr).GetConfig(&cfg) // <3>
	//
	// 	  if s.Error() != nil {
	// 		  return nil, 0, s.Error()
	// 	  }
	//
	// 	  client.Authenticate(cfg.Credentials.User, cfg.Credentials.Password) // <4>
	//
	//    cfg.Token = client.JWT() // <5>
	//
	//    ttl2, err := providerpipe.ExtractTTL(
	//					context, ttl,
	//					int64(3600) /*default to 1h*/, // <6>
	//					client.ExpiresUTC().Unix() - time.Now().Unix() - 60 /*1min*/)
	//
	//   return &cfg, ttl2, err
	// }
	// ----
	// <1> Gets invoked when executing the pipeline with the specific operation defined in the profile returned / used by the plugin
	// <2> Use the utility parse the credential string since it has a path and an optional _TTL_ component
	// <3> Retrieve the configuration stored in _JSON_, _Parameter Store / Secrets Manager_, and overridden by environment variables
	// <4> This plugin authenticates and obtains a token from remote OAuth 2 token server
	// <5> Cache the JWT - since stored in sessionStore it will be available during the lambda lifetime
	// <6> Parse any _TTL_ or set a default (client contains when the _JWT_ expires).
	ObtainCredentialsFunc(
		context ifcore.CbContext,
		store *config.SessionStore,
	) ObtainCredentialsFunction
	// VerifyConnectFunc returns a function that gets invoked before the provider / plugin makes use of the credentials.
	// This is to avoid that credentials gets posted to malicious sites. It gets invoked when the provider has the
	// _CapsProviderVerifyCredentialUsage_ capability. Otherwise the default check operation _Host DNS_ against the
	// `securitymodel.TokenCredentialsImpl.Endpoint`.
	//
	// TIP: Also see `providerpipe.VerifyConnectFunction` for more information.
	//
	// .Example Verify Function
	// [source, go]
	// ----
	// func VerifyConnect(cred string, credentials interface{}, eop *config.Operation) bool {
	//
	// 	if nil == credentials {
	// 		return false
	// 	}
	//
	// 	if c, ok := credentials.(*securitymodel.TokenCredentialsImpl); ok {
	//
	// 		if u, err := url.Parse(eop.Operation); err == nil { // <1>
	// 			return u.Host == c.Endpoint
	// 		}
	// 	}
	//
	// 	return false
	// }
	// ----
	// <1> In this case *only* allow credential passed where the configured endpoint matches (e.g. from parameter store)
	VerifyConnectFunc(
		context ifcore.CbContext,
		store *config.SessionStore,
	) VerifyConnectFunction
}
