package providerpipe

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"

	"github.com/rs/zerolog"
)

// NewProviderPipelineExecutorBuilder creates a new `ProviderPipelineExecutorBuilder`.
func NewProviderPipelineExecutorBuilder(ctx ifcore.CbContext) *ProviderPipelineExecutorImpl {
	return &ProviderPipelineExecutorImpl{
		ctx: ctx,
	}
}

func (b *ProviderPipelineExecutorImpl) Error() cberror.Error {
	return b.err
}

func (b *ProviderPipelineExecutorImpl) ClearError() *ProviderPipelineExecutorImpl {
	b.err = nil

	return b
}

func (b *ProviderPipelineExecutorImpl) Build() *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return nil
	}

	if b.config == nil {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), cberror.ErrorExecutorBuilderNoProviderConfigProvided, nil,
			map[string]any{"pn": b.ctx.Provider()},
			"no configuration is set in the builder",
		)

		return nil
	}

	if b.pipeline == nil {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), cberror.ErrorExecutorBuilderNoPipelineProvided, nil,
			map[string]any{"pn": b.ctx.Provider()},
			"no pipeline is set in the builder",
		)

		return nil
	}

	if _, ok := b.pipeline.operations[string(b.operation)]; !ok {
		b.err = cberror.NewCbErrorfWithProps(
			b.ctx.Service(), cberror.ErrorExecutorBuilderNoOperation, nil,
			map[string]any{"pn": b.ctx.Provider()},
			"the operation '%s' does not exist in the pipeline", b.operation,
		)

		return nil
	}

	if b.overrideSourceFunc != nil || b.overrideTargetFunc != nil ||
		b.overrideSourceWithSelectionFunc != nil {
		for key := range b.pipeline.operations {
			op := b.pipeline.operations[key]

			if b.overrideSourceWithSelectionFunc != nil {
				op.sourceWithSelection = b.overrideSourceWithSelectionFunc
			}

			if b.overrideSourceFunc != nil {
				op.source = b.overrideSourceFunc
			}

			if b.overrideTargetFunc != nil {
				op.target = b.overrideTargetFunc
			}

			b.pipeline.operations[key] = op
		}
	}

	executor := NewPipelineExecutorImpl(b.ctx)
	executor.config = b.config
	executor.pipeline = b.pipeline
	executor.operation = b.operation
	executor.input = b.input
	executor.allowMutateGlobalParams = b.allowMutateGlobalParams

	pipeCtx := map[string]any{}
	b.err = providerconfig.ResolvePipeContextFromGlobals(
		b.ctx, b.config, pipeCtx, executor.input, b.allowMutateGlobalParams,
	)

	if b.err != nil {
		return nil
	}

	if len(executor.input) > 0 {
		for k, v := range pipeCtx {
			executor.input[k] = v
		}
	} else {
		executor.input = pipeCtx
	}

	return executor
}

func (b *ProviderPipelineExecutorImpl) AllowGlobalParameterMutation() *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	b.allowMutateGlobalParams = true

	return b
}

// OverrideSourceFunction will replace all source functions in the pipeline with the provided one.
func (b *ProviderPipelineExecutorImpl) OverrideSourceFunction(
	source SourceFunction,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	if b.overrideSourceWithSelectionFunc != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			400,
			nil,
			"Cannot override source function when source with selection function is already overridden",
		)

		return b
	}

	b.overrideSourceFunc = source

	return b
}

// OverrideSourceWithSelectionFunc will replace all source functions in the pipeline with the provided one.
func (b *ProviderPipelineExecutorImpl) OverrideSourceWithSelectionFunc(
	sourceWithSelection SourceFunctionWithSelection,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	if b.overrideSourceFunc != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			400,
			nil,
			"Cannot override source with selection function when source function is already overridden",
		)

		return b
	}

	b.overrideSourceWithSelectionFunc = sourceWithSelection

	return b
}

// OverrideTargetFunction will replace all target functions in the pipeline with the provided one.
func (b *ProviderPipelineExecutorImpl) OverrideTargetFunction(
	target TargetFunction,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	b.overrideTargetFunc = target
	return b
}

// WithInput assign a initial input to be fed into the global parameter resolver and it wil be transferred into the
// `*ProviderPipelineExecutorImpl` merged with the _providerContext_.
func (b *ProviderPipelineExecutorImpl) WithInput(
	input map[string]any,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	b.input = input

	return b
}

// AsOperation is the _main/initial_ operation that is to be executed.
// It must exist in the _pipeline_.
func (b *ProviderPipelineExecutorImpl) AsOperation(
	operation locationmodel.ProviderOperation,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	b.operation = operation

	return b
}

// UsePipeline will set the pipeline to use when executing the pipe.
//
// NOTE: Set this first before any other method!
func (b *ProviderPipelineExecutorImpl) UsePipeline(
	pipeline ProviderPipelineImpl,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	b.pipeline = &pipeline

	return b
}

// WithContextVariable will add to the pipelines override config. If not set, it will create a new one.
func (b *ProviderPipelineExecutorImpl) WithContextVariable(
	key string, value any,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	if b.pipeline.overrideContext == nil {
		b.pipeline.overrideContext = map[string]any{}
	}

	b.pipeline.overrideContext[key] = value

	return b
}

// UseConfig will set the configuration to use when executing the pipe.
//
// NOTE: If using override user configuration, use the `FromUserConfig` method instead.
func (b *ProviderPipelineExecutorImpl) UseConfig(
	config ifprovider.ConfigFull,
) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	b.config = config

	return b
}

// FromUserConfig will merge the provided user _config_ with a local profile.
// The _config_ is a _JSON_ object that at-least have a _"profile": "profile-name"_ to be
// used to lookup a local profile.
//
// CAUTION: This method assumes that `UsePipeline` has been called first.
func (b *ProviderPipelineExecutorImpl) FromUserConfig(config string) *ProviderPipelineExecutorImpl {
	// Check if error
	if b.err != nil {
		return b
	}

	var err cberror.Error
	// Merge user configuration with local profile
	cfg, err := b.pipeline.repository.MergeFromConfigString(b.ctx, config)
	if err != nil {
		b.err = err

		if l, ok := logger.ClsLog(
			zerolog.ErrorLevel, "pipeline-executor-builder", logger.LDTUntyped, logger.LISUnclassified, b.ctx,
		); ok {
			logger.LogObjectf(
				l, "err", err,
				"Failed to merge user configuration with local profile",
			)
		}
	} else {
		b.config = cfg
	}
	return b
}
