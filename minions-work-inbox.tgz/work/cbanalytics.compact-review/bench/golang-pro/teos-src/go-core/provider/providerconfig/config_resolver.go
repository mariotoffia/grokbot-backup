package providerconfig

// Typically provider flow is to use the LoadContext to resolve the ProviderConfig.Params
// section into a context that should be used to do ResolveOperation and later may be loaded
// into a flow.
//
// Next the provider should invoke ResolveOperation and provide with the context populated by the
// LoadContext method. This will get the Operation struct that handles the operation parameters and
// authentication towards the remote end. Depending on the provider operation different operation name
// may be used. The names is up to each provider to dictate. For example sd could be get the sensor data
// and may have HTTP POST as method and some parameters to control the query. It also may have operations
// to post data towards the remote endpoint to e.g. actuate a outdoor temperature.
//
// This data is then used (if fetch operation) to run a flow. The flow may be configured using CreateMapping
// that creates a JSON SetInstruction to be part of a JSON flow. Next up is to create a filter using the
// CreateFilter method. It will generate a SetInstruction to filter out / in data. Lastly a CreateGeneratorTemplate
// will create a JSON block to handle generation in a flow.
//
// The last three methods are all returning a JSON payload that is meant to be part in constructing a JSON flow for
// the provider. This is to have short-hand configuration instead of specifying the complete flow. The provider should
// enable to do a complete flow in order to completely override all provider flow functionality.
import (
	"strings"

	"github.com/PaesslerAG/gval"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"

	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	util "github.com/Thiink-LLC/teos/go-core/utils"
)

var (
	targetGenerate = "generate."
)

// ResolvePipeContextFromGlobals will evaluate & copy parameters (`ProviderConfig.Param` map)
// from the `ProviderConfig` to provided _pipeContext_ parameter. It will also load
// policy data (if any present in the `ProviderConfiguration`) under the
// _policydata_ pipeline variable (a `cbpipeline.Scope` name). Which are loaded, is determined by the
// _PDA_ located in the `ProviderConfig.Param` map.
//
// It will read the "LOG" parameter in the global params and if it is set to `true` or "on" in will log.
//
// The context may later e.g. be used in a pipeline to do evaluation.
// It is essential that the provider has loaded the _src_ property before
// invoking this function since expressions in `ProviderConfig.Params` may depend on it.
//
// Each provider decides which lang support it needs to do the initialization.
// If none is provided, both gval.Full() and cbeval.FullLanguage() will be used.
//
// If any failures occurs during evaluation, an error is returned.
//
// Note that the `ProviderConfig.Params` is treated as values and not expressions.
// If expression is wanted wrap the expression in brackets e.g. _[REP + ':883']_
// (assuming REP = "www.climatix.com" the result is _www.climatix.com:883:).
//
// .Supported values in Params
// |===
// |Name |Comment
//
// |string
// |Plain string
//
// |[string]
// |Treated as an expression and is evaluated directly in `ResolvePipeContextFromGlobals`
//
// |bool
// |Boolean value
//
// |float64
// |Floating point value
// |===
//
// The _globals_ parameter is overlays on top of the _pipeContext_ parameter to allow for parameters
// that do not exist in the _pipeContext_ to be used in the expressions. This allows for expressions
// in the global parameters.
//
// If the _allowMutate_, it will mutate the global params that are expressions. This may have side effects
// if the profile is not cloned each time it will be manipulated. *Be careful!!*
func ResolvePipeContextFromGlobals(
	context ifcore.CbContext,
	cfg ifprovider.ConfigFull,
	pipeContext map[string]any,
	globals map[string]any,
	allowMutate bool) cberror.Error {
	// Get the global parameters
	globalParams := cfg.GetGlobalParams()

	if len(globalParams) == 0 {
		log.Info(context).
			Msgf("No global parameters to resolve on profile: %s", cfg.GetProfile())

		return nil
	}

	// Is log enabled -> log before and after resolving
	logConfig := strings.ToLower(
		cfg.GetParamAsStringWithDefault(string(ifprovider.ParameterLogging), "false"),
	)

	logEnabled := logConfig == "on" || logConfig == "true"

	if logEnabled {
		providerutils.SafeLogPipeContext(log.Info(context), globalParams).
			Msg("Global Parameters")

		providerutils.SafeLogPipeContext(log.Info(context), pipeContext).
			Msg("PipeContext before resolving global parameters")

		providerutils.SafeLogPipeContext(log.Info(context), globals).
			Msg("Globals before resolving global parameters")
	}

	// evalMap is used when evaluating expressions
	var (
		evalMap    map[string]any
		wasMutated bool
	)

	// Set the `ifprovider.Config` into the pipe context
	pipeContext[string(ifprovider.PipeContextKeyProviderConfig)] = cfg

	setPipeContext := func(key string, value any) {
		pipeContext[key] = value

		if nil != evalMap {
			evalMap[key] = value
		}
	}

	for key, value := range globalParams {
		// All non-strings are a plain copy
		if _, ok := value.(string); !ok {
			setPipeContext(key, value)

			continue
		}

		strValue, _ := value.(string)

		// It is a string, check if it is an expression
		if !cbeval.IsCbEvalExpression(strValue) {
			setPipeContext(key, strValue)

			if key == string(ifprovider.ParameterPolicyData) {
				_ = extractPDALoadPolicyData(context, cfg, pipeContext[key].(string), pipeContext)
			}

			continue
		}

		valueExpression := cbeval.UnwrapExpression(strValue)

		if nil == evalMap {
			evalMap = util.ShallowCopyMap(map[string]any{}, pipeContext)

			if nil != globals {
				evalMap = util.ShallowCopyMap(evalMap, globals)
			}

			// Copy all from globalParams to evalMap (not already present)
			for k, v := range globalParams {
				if _, ok := evalMap[k]; !ok {
					if s, ok := v.(string); ok {
						if !cbeval.IsCbEvalExpression(s) {
							evalMap[k] = v
						}
					} else {
						evalMap[k] = v
					}
				}
			}
		}

		eval, err := cbeval.GlobalEvalCache.GetEval(
			context,
			valueExpression,
			cbeval.EvalCacheLangFullCB,
		)

		if err != nil {
			return err
		}

		res, err2 := eval(context, evalMap)

		if err2 != nil {
			return cberror.NewCbErrorf(
				context.Service(),
				cberror.ErrorProviderUnableEvaluateExpression, err2,
				"failed to evaluate param '%s' = '%s', err: %s", key, strValue, err2.Error(),
			)
		}

		pipeContext[key] = res

		if nil != evalMap {
			evalMap[key] = strValue
		}

		if allowMutate {
			globalParams[key] = res
			wasMutated = true
		}

		if key == string(ifprovider.ParameterPolicyData) {
			_ = extractPDALoadPolicyData(context, cfg, pipeContext[key].(string), pipeContext)
		}
	}

	// Special handling with CFGGEN since it may contain many [expr] expressions
	// that needs to be resolved.
	if v, ok := pipeContext[string(ifprovider.ParameterConfigGeneration)]; ok &&
		!utils.IsConfigGenerationApplyDelayed(cfg) {
		if nil == evalMap {
			evalMap = util.ShallowCopyMap(map[string]any{}, pipeContext)

			if nil != globals {
				evalMap = util.ShallowCopyMap(evalMap, globals)
			}
		}

		var resolveMap func(m map[string]any) cberror.Error

		resolveMap = func(m map[string]any) cberror.Error {
			for k, v := range m {
				if m, ok := v.(map[string]any); ok {
					if err := resolveMap(m); nil != err {
						return err
					}

					continue
				}

				if arr, ok := v.([]any); ok {
					for i, v := range arr {
						if m, ok := v.(map[string]any); ok {
							if err := resolveMap(m); nil != err {
								return err
							} else {
								arr[i] = m
							}
						}
					}

					continue
				}

				if _, ok := v.(string); !ok {
					continue
				}

				sv, _ := v.(string)

				if !cbeval.IsCbEvalExpression(sv) {
					continue
				}

				// We have an eval expression, resolve and evaluate
				valueExpression := cbeval.UnwrapExpression(sv)

				eval, err := cbeval.GlobalEvalCache.GetEval(
					context, valueExpression, cbeval.EvalCacheLangFullCB,
				)

				if err != nil {
					return err
				}

				res, err2 := eval(context, evalMap)

				if err2 != nil {
					return cberror.NewCbErrorf(
						context.Service(),
						cberror.ErrorProviderUnableEvaluateExpression, err,
						"failed to evaluate param '%s' = '%s', err: %s", k, sv, err2.Error(),
					)
				}

				m[k] = res
			}

			return nil
		}

		// Iterate recursively and resolve all expressions
		if m, ok := v.(map[string]any); ok {
			if err := resolveMap(m); err != nil {
				return err
			}
		} else {
			return cberror.NewCbErrorf(
				context.Service(),
				cberror.ErrorProviderUnableEvaluateExpression, nil,
				"failed to resolve config generation expressions (CFGGEN in global params), not a map[string]any",
			)
		}
	}

	// Until BID has been purged -> copy it to LID
	if lid, ok := pipeContext["BID"].(string); ok {
		if _, ok := pipeContext["LID"]; !ok {
			pipeContext["LID"] = lid
		}
	}

	if logEnabled {
		if wasMutated {
			providerutils.SafeLogPipeContext(log.Info(context), globalParams).
				Msg("Global Parameters (mutated after resolving)")

		}
		providerutils.SafeLogPipeContext(log.Info(context), pipeContext).
			Msg("PipeContext after resolving global parameters")
	}

	return nil
}

// extractPDALoadPolicyData will check the `ParameterPolicyData` in the pda string and make sure
// that the policy data is present under _policydata_.
func extractPDALoadPolicyData(
	c ifcore.CbContext,
	cfg ifprovider.ConfigFull,
	pda string,
	pipeContext map[string]interface{}) cberror.Error {
	if pda == "" {
		return nil
	}

	var policydata map[string]interface{}
	if _, ok := pipeContext["policydata"]; ok {
		if m, ok := pipeContext["policydata"].(map[string]interface{}); ok {
			policydata = m
		} else {
			return cberror.NewCbErrorf(
				c.Service(), 1, nil,
				"found policydata in pipeContext but it is not of map[string]interface{} type",
			)
		}
	} else {
		policydata = map[string]interface{}{}
	}

	for _, pd := range strings.Split(pda, " ") {
		if data, ok := cfg.GetPolicyData(pd); ok {
			policydata[pd] = data
			continue
		}

		return cberror.NewCbErrorf(
			c.Service(), 2, nil,
			"configured for policydata: %s in PDA but not found in providerconfig", pd,
		)
	}

	pipeContext["policydata"] = policydata

	return nil
}

func evaluate(
	context ifcore.CbContext,
	name string,
	s interface{},
	l gval.Language,
	ctx map[string]interface{}) (interface{}, cberror.Error) {
	if expr, ok := s.(string); ok {
		res, err := l.Evaluate(expr, ctx)

		if err != nil {
			return nil, cberror.NewCbErrorf(
				context.Service(), cberror.ErrorProviderUnableEvaluateExpression, err,
				"failed to evaluate %s param '%v'", name, s)
		}

		return res, nil
	}

	return s, nil
}

func prepareLang(lang []gval.Language) gval.Language {
	var l gval.Language

	if len(lang) > 0 {
		l = gval.NewLanguage(lang...)
	} else {
		l = gval.Full(cbeval.FullLanguage())
	}

	return l
}
