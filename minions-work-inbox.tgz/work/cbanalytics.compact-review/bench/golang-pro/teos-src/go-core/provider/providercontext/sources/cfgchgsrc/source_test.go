package cfgchgsrc_test

import (
	"encoding/json"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/Thiink-LLC/teos/go-core/provider/providercontext/sources/cfgchgsrc"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	c := testenv.DefaultContext(tb, "test")
	return c
}

func TestConfigChangeCreated(t *testing.T) {
	data := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21.5,
										"OBT": 17.5,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	objType := "providermodel.Building"

	cfgChange := &cbevent.ConfigChangeEventImpl{
		EventTransportImpl: cbevent.EventTransportImpl{
			Func: "/" + objType,
			Data: &data,
		},
		ID:   "BLD#Måssmyren 18#BLD",
		Oper: cbevent.ConfigOperationCreated,
		Type: objType,
		Old:  nil,
	}

	source, err := cfgchgsrc.SelectorDiffConfigChange(
		newCtx(t),
		cfgChange,
		false, /*createOnUpdate*/
		cfgchgsrc.Selector{Select: "/**/services/*/prms/{ITT,ITL,OBT}"},
	)

	require.NoError(t, err)
	require.Contains(t, source, "ITT")
	require.Contains(t, source, "ITL")
	require.Contains(t, source, "OBT")

	assert.Equal(t, 21.5, source["ITT"])
	assert.Equal(t, 17.0, source["ITL"])
	assert.Equal(t, 17.5, source["OBT"])
}

func TestConfigChangeDeleted(t *testing.T) {
	data := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21.5,
										"OBT": 17.5,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	objType := "providermodel.Building"

	cfgChange := &cbevent.ConfigChangeEventImpl{
		EventTransportImpl: cbevent.EventTransportImpl{
			Func: "/" + objType,
			Data: &data,
		},
		ID:   "BLD#Måssmyren 18#BLD",
		Oper: cbevent.ConfigOperationDeleted,
		Type: objType,
		Old:  nil,
	}

	source, err := cfgchgsrc.SelectorDiffConfigChange(
		newCtx(t),
		cfgChange,
		false, /*createOnUpdate*/
		cfgchgsrc.Selector{Select: "/**/services/*/prms/{ITT,ITL,OBT}"},
	)

	require.NoError(t, err)
	require.Contains(t, source, "ITT")
	require.Contains(t, source, "ITL")
	require.Contains(t, source, "OBT")

	assert.Equal(t, 21.5, source["ITT"])
	assert.Equal(t, 17.0, source["ITL"])
	assert.Equal(t, 17.5, source["OBT"])
}

func TestConfigChanged(t *testing.T) {
	old := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21.5,
										"OBT": 17.5,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	data := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21,
										"OBT": 18,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	objType := "providermodel.Building"

	cfgChange := &cbevent.ConfigChangeEventImpl{
		EventTransportImpl: cbevent.EventTransportImpl{
			Func: "/" + objType,
			Data: &data,
		},
		ID:   "BLD#Måssmyren 18#BLD",
		Oper: cbevent.ConfigOperationUpdated,
		Type: objType,
		Old:  &old,
	}

	source, err := cfgchgsrc.SelectorDiffConfigChange(
		newCtx(t),
		cfgChange,
		false, /*createOnUpdate*/
		cfgchgsrc.Selector{Select: "/**/services/*/prms/{ITT,ITL,OBT}"},
	)

	require.NoError(t, err)
	require.Contains(t, source, "ITT")
	require.NotContains(t, source, "ITL")
	require.Contains(t, source, "OBT")

	assert.Equal(t, 21.0, source["ITT"])
	assert.Equal(t, 18.0, source["OBT"])
}

func TestConfigChangedFlagCreateOnUpdate(t *testing.T) {
	old := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21.5,
										"OBT": 17.5,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	data := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21,
										"OBT": 18,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	objType := "providermodel.Building"

	cfgChange := &cbevent.ConfigChangeEventImpl{
		EventTransportImpl: cbevent.EventTransportImpl{
			Func: "/" + objType,
			Data: &data,
		},
		ID:   "BLD#Måssmyren 18#BLD",
		Oper: cbevent.ConfigOperationUpdated,
		Type: objType,
		Old:  &old,
	}

	source, err := cfgchgsrc.SelectorDiffConfigChange(
		newCtx(t),
		cfgChange,
		true, /*createOnUpdate*/
		cfgchgsrc.Selector{Select: "/**/services/*/prms/{ITT,ITL,OBT}"},
	)

	require.NoError(t, err)
	require.Contains(t, source, "ITT")
	require.Contains(t, source, "ITL", "Since createOnUpdate is true, ITL should be included")
	require.Contains(t, source, "OBT")

	assert.Equal(t, 21.0, source["ITT"])
	assert.Equal(t, 18.0, source["OBT"])
	assert.Equal(t, 17.0, source["ITL"])
}

func TestConfigNotChanged(t *testing.T) {
	data := json.RawMessage([]byte(`{
		"meta": {
				"services": {
						"dh-service": {
								"prms": {
										"ITL": 17,
										"ITT": 21.5,
										"OBT": 17.5,
										"ESL": "Medium (101 - 250 kW)"
								},
								"type": "noda-building"
						}
				}
		}
	}`))

	objType := "providermodel.Building"

	cfgChange := &cbevent.ConfigChangeEventImpl{
		EventTransportImpl: cbevent.EventTransportImpl{
			Func: "/" + objType,
			Data: &data,
		},
		ID:   "BLD#Måssmyren 18#BLD",
		Oper: cbevent.ConfigOperationUpdated,
		Type: objType,
		Old:  &data,
	}

	source, err := cfgchgsrc.SelectorDiffConfigChange(
		newCtx(t),
		cfgChange,
		false, /*createOnUpdate*/
		cfgchgsrc.Selector{Select: "/**/services/*/prms/{ITT,ITL,OBT}"},
	)

	require.NoError(t, err)
	assert.Equal(t, 0, len(source))
}
