package sqsrtc

import (
	"fmt"
	"runtime"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/rtc"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cbsqs"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
	"github.com/Thiink-LLC/teos/go-core/utils/procutils"
)

// DispatchRtcMessages is a dispatcher that will dispatch the `*rtc.RtcChannelFrame` to the
// provider by extracting the frames from the the `RtcChannelMessage` and executes
// a provider in the `providercontext.ProviderContext.Execute()`.
//
// CAUTION: It does a first match on which frame to feed. That is, the first one
// that is not `nil` will be used. All others will be discarded.
//
// The parallelism is set to `runtime.NumCPU()*64` and timeout is set to _120s_. It is
// possible override the parallelism by `CB_PROV_DISP_PARALLELISM` and the timeout by
// `CB_PROV_DISP_PARALLELISM_TIMEOUT`.
//
// TIP: Use one of the companion source functions under `providercontext/sources/rtc` to
// populate the pipe context _source_ properly. For example `rtc.SimpleCollectionFrameSource`.
//
// If _defaultProfile_ is set to an empty string, this will require the `rtc.RtcChannelFrame.Meta.Profile`
// to be set. If the _defaultProfile_ is set, it is used as default if nothing is set in the meta profile.
//
// It is possible to override the default profile by setting the `CB_PROV_DEFAULT_PROFILE` environment variable.
func DispatchRtcMessages(
	path string,
	builder *providercontext.ProviderContextBuilderImpl,
	defaultProfile string,
) providercontext.ProviderHandlerFunc {

	parallelism := cbenv.CB_PROV_DISP_PARALLELISM.Integer(int64(64 * runtime.NumCPU()))

	timeout := time.Duration(
		cbenv.CB_PROV_DISP_PARALLELISM_TIMEOUT.Integer(120) * int64(time.Second),
	)

	return func(pc providercontext.ProviderContext) dispruntime.HandlerInvoker {
		return cbsqs.JSONWithRoute(
			path,
			pc.Context(),
			func(ctx ifcore.CbContext, event *rtc.RtcChannelFrame) error {
				// Check if override default profile is set
				profile := cbenv.CB_PROV_DEFAULT_PROFILE.String(defaultProfile)

				// Per Location
				if event.Meta != nil && event.Meta.ProfileType != nil &&
					*event.Meta.ProfileType == rtc.PER_LOCATION {
					return rtcMessageHandler(ctx, pc, event)
				}

				// No -> Ensure profile name is set if no default
				if (event.Meta == nil || event.Meta.Profile == nil) || *event.Meta.Profile == "" {

					if profile == "" {
						return cberror.NewCbErrorfWithProps(
							ctx.Service(),
							cberror.ErrorProviderRTCFrameMissingRequiredProviderName,
							nil,
							map[string]any{cberror.PropertyProvider: ctx.Provider()},
							"Expecting meta with a valid profile name in event but no avail",
						)
					}

					if event.Meta == nil {
						event.Meta = &rtc.RtcChannelFrameMeta{}
					}

					event.Meta.Profile = &profile
					event.Meta.ProfileType = rtc.STATIC.Ptr()
				}

				return rtcMessageHandler(ctx, pc, event)
			},
			cbsqs.WithParallelism(int(parallelism)),
			cbsqs.WithTimeout(timeout),
		)
	}
}

// rtcMessageHandler is the actual rtcMessageHandler that will dispatch the frames to the provider.
func rtcMessageHandler(
	ctx ifcore.CbContext,
	pc providercontext.ProviderContext,
	event *rtc.RtcChannelFrame,
) cberror.Error {
	// Get provider config from the event.
	profile := ""

	if event.Meta.Profile != nil && *event.Meta.Profile != "" {
		profile = *event.Meta.Profile
	}

	userConfig := fmt.Sprintf(`{"profile": "%s"}`, profile)

	// process the frames in parallel.
	process := func(
		ctx ifcore.CbContext, idx int, msg rtc.RtChannelMessage,
	) (providerpipe.IterationExecutionResults, cberror.Error) {
		// Extract the frame
		frame, locationID, err := msg.ExtractRtcMessageFrame(ctx)

		if err != nil {
			return nil, err
		}

		result, err := pc.Execute(
			ctx, locationID, userConfig, frame,
			msg.GetPipelineInputParametersFromRtcMessage(),
			&providercontext.OptExecute{
				ConfigUsage: profileTypeToUserConfigUsage(event.Meta.ProfileType),
			},
		)

		if err != nil {
			return nil, err
		}

		errors := result.GetErrors()
		if len(errors) == 1 {
			return nil, errors[0]
		}

		if len(errors) > 1 {
			return nil, cberror.NewCbCompositeErrorf(
				ctx.Service(),
				cberror.ErrorProviderUnableExecutePipeline,
				cberror.AsPlainError(errors...),
				map[string]any{cberror.PropertyProvider: ctx.Provider()},
				"Multiple errors occurred during execution of config %s",
				userConfig,
			)
		}

		return result, nil

	}

	result := procutils.Parallelizer(
		ctx, event.Frames, 128, 120*time.Second, process,
	)

	return result.CreateOrGetErrorIfExists()
}

func profileTypeToUserConfigUsage(pt *rtc.ProfileType) providercontext.ProviderUserConfigUsage {
	if pt == nil {
		return providercontext.ProviderUserConfigUsageNone
	}

	switch *pt {
	case rtc.PER_LOCATION:
		return providercontext.ProviderUserConfigUsageLoaderPerLocationID
	case rtc.STATIC:
		return providercontext.ProviderUserConfigUsageManual
	default:
		return providercontext.ProviderUserConfigUsageNone
	}
}
