package providerconfig

import (
	"errors"
	"io/fs"
	"os"
	"path/filepath"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
)

// FsProviderConfigLoader will use `fs.FS` to walk the file system to list
// and find `providermodel.ProviderConfigImpl` instances.
//
// It implements the `ProviderConfigLoader` interface.
type FsProviderConfigLoader struct {
	fs fs.FS
}

// NewFsProviderConfigLoader will create a new instance of the loader
// based on the `fs.FS` interface.
func NewFsProviderConfigLoader(fs fs.FS) *FsProviderConfigLoader {
	return &FsProviderConfigLoader{fs: fs}
}

// NewFsProviderConfigLoaderFromPath will create a new instance of the loader
// based on the path on local filesystem.
func NewFsProviderConfigLoaderFromPath(path string) *FsProviderConfigLoader {
	return &FsProviderConfigLoader{fs: os.DirFS(path)}
}

// Find will find a profile by name. If not found, `nil` is returned.
func (ld *FsProviderConfigLoader) Find(
	c ifcore.CbContext,
	profile string,
) (*providermodel.ProviderConfigImpl, cberror.Error) {
	//
	var cfg *providermodel.ProviderConfigImpl

	err := fileutils.FSWalker(
		ld.fs,
		"" /*from root*/, "**.json", false, /*load*/
		func(f fs.FS, fqPath string, _ []byte) cberror.Error {
			// If already loaded config -> skip
			if cfg != nil {
				return nil
			}

			// Profile name is path without extension
			profileName := filepath.Join(
				filepath.Dir(fqPath),
				fileutils.FileNameWithoutExtension(filepath.Base(fqPath)),
			)

			// set root after 'provider-config'
			if idx := strings.Index(profileName, "provider-config/"); idx >= 0 {
				profileName = profileName[idx+len("provider-config/"):]
			}

			if profileName != profile {
				return nil
			}

			// Read profile
			data, err := fileutils.FSysFileToBytes(f, fqPath)
			if err != nil {
				return cberror.NewCbErrorfWithProps(c.Service(), 1, err,
					map[string]interface{}{"pn": c.Provider()},
					"failed to read file: %s error: %s", fqPath, err.Error(),
				)
			}

			// We have a match -> load the profile
			items, err := ReadConfig(c, string(data))
			if err != nil {
				return cberror.NewCbErrorConfigurationErrorf(c.Service(),
					cberror.ConfigurationErrorTypeUnknown, 2, nil, err,
					map[string]interface{}{"pn": c.Provider()},
					"failed read config file: %s error: %s", fqPath, err.Error(),
				)
			}

			cfg, err = CreateConfig(items...)
			if err != nil {
				return cberror.NewCbErrorfWithProps(c.Service(), 3, err,
					map[string]interface{}{"pn": c.Provider()},
					"failed create config from file: %s error: %s", fqPath, err.Error(),
				)
			}

			cfg.Profile = profileName

			return nil
		},
	)

	if err != nil {
		var cerr cberror.Error
		if errors.As(err, &cerr) {
			return nil, cerr
		}

		return nil, cberror.NewCbErrorConfigurationErrorf(
			c.Service(),
			cberror.ConfigurationErrorMissingConfiguration,
			1, nil /*config*/, err, map[string]interface{}{
				"pn": c.Provider(),
			},
			"Error iterating provider configuration")
	}

	return cfg, nil
}
