package utils

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"text/template"
	"time"

	"github.com/google/uuid"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/idutils"
)

// DefaultGeneratorMode specifies what the GetTemplateGeneratorMode shall return when
// no mode is specified in the config.
const DefaultGeneratorMode = ifprovider.GeneratorTemplateGenerationStatic

const RightHandMappingID = "{{:ID}}"
const LeftHandMappingID = "{{ID}}"

// ToProfileImpl is a ugly hack to use until I again move everything in providermodel
// and ifprovider to providerconfig and refactor the interfaces to return structs instead
// of interfaces.
func ToProfileImpl(profile ifprovider.ConfigProfile) *providermodel.ProfileImpl {
	if p, ok := profile.(*providermodel.ProfileImpl); ok {
		return p
	}

	return nil
}

// ToProviderConfigImpl is a ugly hack to use until I again move everything in providermodel
// and ifprovider to providerconfig and refactor the interfaces to return structs instead
// of interfaces.
func ToProviderConfigImpl(pc ifprovider.ConfigFull) *providermodel.ProviderConfigImpl {
	if p, ok := pc.(*providermodel.ProviderConfigImpl); ok {
		return p
	}

	return nil
}

// GetGeneratorTemplateType returns the generator template type from the _cfg_.
//
// If none is found _d_ is returned.
func GetGeneratorTemplateType(
	cfg ifprovider.ConfigFull,
	d ifprovider.GeneratorTemplateType,
) ifprovider.GeneratorTemplateType {
	if templateType, ok := cfg.GetParamAsString(string(ifprovider.ParameterGeneratorTemplateType)); ok {
		return ifprovider.GeneratorTemplateType(templateType)
	}

	return d
}

// IsGoGeneratorTemplate checks if the _cfg_ specifies that the generator template is a go template
// instead of a native template.
//
// This is done by examining the global params `ifprovider.ParameterGeneratorTemplateType` if it is
// set to `ifprovider.GeneratorTemplateTypeGoTemplate`.
func IsGoGeneratorTemplate(cfg ifprovider.ConfigFull) bool {
	return GetGeneratorTemplateType(
		cfg,
		ifprovider.GeneratorTemplateTypeNative,
	) == ifprovider.GeneratorTemplateTypeGoTemplate
}

// RenderGeneratorGoTemplateByName is same as `RenderGeneratorPrototypeByName` but instead of automatically rendering
// the template _GENPROTO_ and GENPROTO_TS_ it will render the template by using the go template system.
//
// It accepts an optional _src_ and is set when the `gfunc_gentemplate` is used. When static generation is used
// it will not be populated. The src parameter will contain the values keyed by the _ceID_ that the mapping has concluded.
//
// TIP: When _GTG_ is set to _dynamic_ in the profile global params, the template will have access to mapped (generated) values.
// Otherwise it will only have access to source values.
//
// The return is a string that represents the generator template that is then used to render the result using the standard
// generator.
//
// There are standard functions available in the template:
//
//   - proto _ID_  Will render the genproto by ID of which it does a standard lookup.
//     This is how the standard genproto mechanism work. It will operate as right expression proto only.
//
//   - mapped _ID_ Will render the left hand side of the mapping. If additional argument "right" is provided it
//     will render the right hand side instead.
//
//   - keys see `Keys` for documentation.
//
//   - iterate main id, expression, data will iterate over the data and allow for using a single master e.g. IDT to iterate
//     on it's ordinal/circuit values and get other mappings in the same iteration.
func RenderGeneratorGoTemplateByName(
	ctx ifcore.CbContext,
	cfg ifprovider.ConfigFull,
	templateID, genProtoFallbackID string,
	ceID []string,
	src map[string]any,
	logEnabled bool,
) (string, cberror.Error) {
	protoTemplate, ok := cfg.GetGenProtoTemplates()[templateID]

	if !ok {
		return "", cberror.NewCbErrorf(
			ctx.Service(), 1, nil,
			"failed to get full generator template and no prototype template found for ID: %s", templateID,
		)
	}

	p, ok := cfg.GetGenProto(templateID)
	if !ok {
		p, ok = cfg.GetGenProto(genProtoFallbackID)

		if !ok {
			return "", cberror.NewCbErrorf(
				ctx.Service(), 1, nil,
				"failed to get genproto for ID: %s", templateID,
			)
		}
	}

	// Do we have Timestamp Prototype Templates?
	pts, ok := cfg.GetGenProtoTs(templateID)
	if !ok {
		pts, _ = cfg.GetGenProtoTs(genProtoFallbackID)
	}

	type IdAndPartition struct {
		Id        string
		Partition string
	}

	funcs := template.FuncMap{
		"exists": func(v any) bool {
			return v != nil
		},
		"now": time.Now,
		"starts_with": func(id any, prefix string) bool {
			if id == nil {
				return false
			}

			return strings.HasPrefix(fmt.Sprintf("%v", id), prefix)
		},
		"trim_prefix": func(id any, prefix string) string {
			if id == nil {
				return ""
			}

			return strings.TrimPrefix(fmt.Sprintf("%v", id), prefix)
		},
		"parse":   Parse,
		"is_type": IsType,
		"circuit": Circuit,
		"int": func(id any) int {
			return utils.ConvertToInt(id, 0)
		},
		"mapped": func(id string, dir ...string) string {
			if len(dir) == 0 {
				dir = []string{"to"}
			}
			if dir[0] == "to" {
				if mappedTo, ok := cfg.GetMappedTo(id); ok {
					return mappedTo
				}
			}

			mappedFrom, _ := cfg.GetMappedFrom(id)

			return mappedFrom
		},
		"marshal": func(v any) (string, error) {
			if data, err := json.Marshal(&v); err != nil {
				return "", err
			} else {
				return string(data), nil
			}
		},
		"proto": func(id string) string {
			var sb strings.Builder

			if RenderSingleID(ctx, cfg, p, &sb, id, true, true /*onlyExpression*/) {
				return sb.String()
			}

			return ""
		},
		"protots": func(id string) string {
			if len(pts.GetTable()) > 0 {
				var sb strings.Builder

				if RenderSingleID(ctx, cfg, pts, &sb, id, true, true /*onlyExpression*/) {
					return sb.String()
				}
			}

			return ""
		},
		"iterate": func(data any, expr string, value ...bool) []map[string]any {
			var m map[string]any

			if k, ok := data.(map[string]any); ok {
				m = k
			} else if k, ok := data.(map[string]string); ok {
				m = map[string]any{}
				for k, v := range k {
					m[k] = v
				}
			} else {
				return nil
			}

			return Iterate(ctx, expr, m, value...)
		},
		"raw_id": func(id string) string {
			if strings.Contains(id, "_") {
				return strings.Split(id, "_")[0]
			}

			return id
		},
		"first": func(v any, expr string, flags ...string) (any, error) {
			if v == nil {
				return nil, nil
			}

			var m map[string]any

			if k, ok := v.(map[string]any); ok {
				m = k
			} else if k, ok := v.(map[string]string); ok {
				m = map[string]any{}
				for k, v := range k {
					m[k] = v
				}
			} else {
				return nil, fmt.Errorf(
					"invalid type for first function, expected map[string]any or map[string]string, got %T", v,
				)
			}

			return First(m, expr, flags...)
		},
		"keys": Keys,
		"get":  GetValue,
		"add":  Add,
		"mul":  Mul,
		"time": Time,
		"test": func(v any) string {
			if v == nil {
				fmt.Println("nil")
			} else {
				fmt.Printf("%#v\n", v)
			}

			return ""
		},
		"uuid": func() string {
			return uuid.New().String()
		},
		"rsid": func(id string) string {
			_, rsid := idutils.RSIDDecodeLocationID(id)

			return rsid
		},
		"svc_level": func(t string, value any) (string, error) {
			if t == "esl" {
				l, err := ToEffectServiceLevel(value)

				return string(l), err
			}

			return "", fmt.Errorf("unknown service level type: %s, supported: esl", t)
		},
		// Creates a Teos Sensor ID from a `ingestionmodel.CbSensorReportItem` in map[string]any format.
		"report_to_teos_id": func(m map[string]any) string {
			return (&ingestionmodel.CbSensorReportItem{
				Sensor:  utils.ConvertToString(m["sn"], ""),
				Ordinal: utils.ConvertToInt(m["o"], -1),
				Circuit: utils.ConvertToInt(m["c"], -1),
				Zone:    utils.ConvertToString(m["z"], ""),
			}).GetID()
		},
		"id_partition": func(id string, sep ...string) IdAndPartition {
			if len(sep) == 0 {
				sep = []string{";"}
			}

			s := strings.SplitN(id, sep[0], 2)

			if len(s) == 2 {
				return IdAndPartition{Id: s[1], Partition: s[0]}
			}

			return IdAndPartition{Id: id}
		},
	}

	t, err := template.New(templateID).Funcs(funcs).Parse(protoTemplate)

	if err != nil {
		return "", cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, err,
			"failed to parse template for ID: %s, err: %s",
			templateID, err.Error(),
		)
	}

	var writer bytes.Buffer

	if err := t.Execute(&writer, src); err != nil {
		return "", cberror.NewCbErrorf(
			ctx.Service(), http.StatusBadRequest, err,
			"failed to execute template for ID: %s, err: %s",
			templateID, err.Error(),
		)
	}

	s := writer.String()

	if logEnabled && log.IsEnabled(zerolog.InfoLevel) {
		log.Info(ctx).
			WithBody(s).
			Msg("Rendered generator template")
	}

	return s, nil
}
