package s3sqs_test

import (
	"fmt"
	"testing"
	"testing/fstest"
	"time"

	"github.com/ahmetb/go-linq/v3"
	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext/dispatcher/s3sqs"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSingleSQSEventSingleS3FileEventSingleLID(t *testing.T) {
	// Target Struct
	type targetStruct struct {
		List []*eqmodel.CbDataPointImpl `json:"items"`
	}

	// ------------ CONFIG ------------
	lid := "Måssmyren 18"

	providerConfig := fstest.MapFS{
		"provider-config/teos/source.json": &fstest.MapFile{
			Data: srcProfile,
			Mode: 0666,
		},
	}

	userConfigLoader := func(ctx ifcore.CbContext, locationID string) (string, cberror.Error) {
		return fmt.Sprintf(`{
			"profile": "teos/source",
			"prms": {
				"BID": "%s", 
				"REP": "example.com",
				"CRD": "/provider/test/massmyren-18",
				"TID": "[TID]",
				"MXP": "[MXP]"
			}
		}`, lid), nil
	}

	jsonLoader := func(
		ctx ifcore.CbContext,
		location, key string,
	) ([]*s3sqs.PayloadData, cberror.Error) {
		return []*s3sqs.PayloadData{
			s3sqs.Payload(
				lid,
				s3sqs.Itm(lid, "IDT_O1", 22.7),
				s3sqs.Itm(lid, "HUM_O14", 80.2),
				s3sqs.Itm(lid, "OFFODT", -1.2),
			),
		}, nil
	}

	// ------------- TARGET ---------------
	var trg *targetStruct

	target := func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		//
		trg = providerutils.ExtractTarget[targetStruct](target)

		if nil == trg {
			return cberror.NewCbErrorf(ctx.Service(), 500, nil, "no target found")
		}

		return nil
	}

	// Root Service Context
	ctx := testenv.DefaultContext(t, "esv")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", &targetStruct{}).
				UseTarget(target).
				UseCredentialsFunction(
					providerpipe.NoopObtainCredentials(
						"user", "pass", "apiKey", "example.com", nil, /*token*/
					)).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder()

	builder.
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		UseLoaders(userConfigLoader).
		UsePipeline(pipeline).
		WithProviderConfiguration(providerConfig).
		AllowGlobalParameterMutation().
		UserConfigUsage(providercontext.ProviderUserConfigUsageLoaderPerLocationID).
		UseProviderDispatcher(
			s3sqs.DispatchSQSwithS3Events(
				fmt.Sprintf("/provider/westbound/%s/%s", ctx.Provider(), ctx.Service()),
				builder, "teos/source", jsonLoader,
			),
		)

	pctx := builder.Build()

	// Payload
	payload := events.SQSEvent{
		Records: []events.SQSMessage{
			{
				MessageId:   "1",
				EventSource: "aws:sqs",
				Body: string(jsonutils.ToJSON(
					events.S3Event{Records: s3sqs.Recs("mem", "/path/to/data.json")})),
			},
		},
	}

	// Invoke the service
	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(payload))

	// Assert the result
	require.NoError(t, invokeError)
	require.Nil(t, result)
	require.NotNil(t, trg)
	require.Len(t, trg.List, 3)

	idt01any := linq.From(trg.List).Where(func(i any) bool {
		return i.(eqmodel.CbDataPoint).GetID() == "2;indoor_temperature"
	}).First()

	hum14any := linq.From(trg.List).Where(func(i any) bool {
		return i.(eqmodel.CbDataPoint).GetID() == "14;indoor_humidity"
	}).First()

	offodtAny := linq.From(trg.List).Where(func(i any) bool {
		return i.(eqmodel.CbDataPoint).GetID() == "OFFODT"
	}).First()

	require.NotNil(t, idt01any)
	require.NotNil(t, hum14any)
	require.NotNil(t, offodtAny)

	idt01 := idt01any.(eqmodel.CbDataPoint)
	hum14 := hum14any.(eqmodel.CbDataPoint)
	offodt := offodtAny.(eqmodel.CbDataPoint)

	assert.True(t, idt01.GetTimeStamp().BeforeTime(time.Now()))
	assert.Equal(t, 22.7, idt01.GetValue())

	assert.True(t, hum14.GetTimeStamp().BeforeTime(time.Now()))
	assert.Equal(t, 80.2, hum14.GetValue())

	assert.True(t, offodt.GetTimeStamp().BeforeTime(time.Now()))
	assert.Equal(t, -1.2, offodt.GetValue())
}

// srcProfile emulates the teos/source profile
var srcProfile = []byte(`
{
	"prms": {
	  "TZ": "[TZ]",
		"MMO": "source",
	  "OID": "",
	  "GTM": "error-report"
	},
	"operations": {
	  "esv": {
			"oper": "[REP]",
			"prms": {
				"TID": "[TID]",
				"TS": "[TS]"
			}
	  }
	},
	"map": {
		"IDT_O1": "2;indoor_temperature",
		"HUM_**": "{{ID:O}};indoor_humidity"
	}
}
--genproto=esv
-*: { "n": "{{:ID}}", "v": round(float64(generate["{{:ID}}"].Value),2), "ts": generate["{{:ID}}"].TimeStamp }
--genprototemplate=esv
{ "items": [ {{GENPROTO}} ] }
--pipe=esv
{
	"sensor-values": {
		{{if has_mapping}}
			{{mapping}},
		{{end}}
		"gen-ds": {{generate}},
		"marshal-ds": {{marshal "marshal(_ts.esv, target)"}}
	}
}
`)
