package providerpipe

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/regexutils"
)

// IsSourceMapping returns `true` if the _id_ is a source mapping.
// For example if _id_ is "{{IDT:ID}}" it will return `true`.
func IsSourceMapping(id string) bool {
	return strings.Contains(id, "{{") && strings.Contains(id, "}}")
}

// GetSourceMappingKey will check if it is a source mapping and if so return the key.
//
// The key is extracted in such way that the {{key:ID}} (or {{ID}}) is returning _key_.
//
// NOTE: If the source mapping do not contain a key, it will return an empty string.
func GetSourceMappingKey(id string) (string, bool) {
	if IsSourceMapping(id) {
		if strings.Contains(id, ":") {
			// {{key:ID}} mapping
			return strings.Split(id, ":")[0][2:], true
		} else {
			// Just a plain {{ID}} mapping
			return "", true
		}
	}

	return "", false
}

// ToSourceMappingAndRemoteIDs will examine all _rid_ and split them into source mappings and remote IDs.
//
// When _sm_ is set, the provider must do a scan of the source data.
func ToSourceMappingAndRemoteIDs(rid []string) (sm []string, rids []string) {
	for _, id := range rid {
		if sk, ok := GetSourceMappingKey(id); ok {
			sm = append(sm, sk)
		} else {
			rids = append(rids, id)
		}
	}

	return
}

// macroSubstitution will do a macro substitution if present in _v_.
func macroSubstitution(rawSensorID, sk, v string) string {
	cnt := strings.Count(v, ":")

	var prefix string

	sensor := eqmodel.SensorType(sk)

	if strings.Contains(v, "{{ID:") {
		prefix = "{{ID"
	} else {
		prefix = fmt.Sprintf("{{%s:ID", strings.TrimSuffix(rawSensorID, "_"))
	}

	if cnt == 0 {
		// plain {{ID}} mapping
		return strings.Replace(v, "{{ID}}", sk, 1)
	}

	value := strings.Replace(v, prefix+":O}}", sensor.OrdoString(), 1)
	value = strings.Replace(value, prefix+":C}}", sensor.CircuitString(), 1)
	value = strings.Replace(value, prefix+":Z}}", sensor.ZoneString(), 1)
	value = strings.Replace(value, prefix+":PF}}", sensor.PostFix(), 1)

	return strings.Replace(value, prefix+"}}", sk, 1)
}

// sourceMap is when the _MMO_ is set to _source_ or _src_. This will delay the
// rendering of the _map_ segment in the profile and instead it will be done here
// where the source data is available.
//
// It is then possible:
//
//  1. Allow source data to populate the map section.
//
//  2. Allow for static mapping and source mapping at the same time.
//
//  3. Simple template mapping of {{ID}} when wildcard key is used (e.g. IDT**)
//
//  3. Searchable template mapping e.g. "IDT**"" : "{{IDT:ID}}" is allowed to be rendered.
//     Where {{IDT:ID}} will be replaced with the actual source key e.g. IDT_O1_C1_ZHello.
//     The {{key:ID}} -> key is later searchable using the `GetSourceMappingKey()` function.
//
//     NOTE: This is useful when having multiple wildcard mappings and you want to distinguish between them.
//
// It will automatically populate the _MID_ parameter with the source data keys that where added
// to the mapping.
//
// Providers shall check tha parameters to identify the {{X:ID}} macros and make sure to populate
// with the corresponding key-value using a discovery mechanism. This is typically used in the
// _cfin_ operations where e.g. indoor sensors are discovered.
func sourceMap(
	config ifprovider.ConfigFull,
	sourceData map[string]any,
) error {
	// workset is the working set of mappings -> new mapping
	workset := map[string]string{}
	mapping := config.GetMapping()
	src := maps.Clone(sourceData)

	// 1. Add static mappings to workset
	for k, v := range mapping {
		if src[k] != nil {
			workset[k] = v
			delete(src, k)
		}
	}

	// 2. Expand any wildcard mappings
	for k, v := range mapping {
		if !strings.HasSuffix(k, "**") {
			continue
		}

		// Wildcard mapping -> check all source data keys that
		// has the prefix (substring to '*' of k) and add them to the mapping
		rawSensorID := k[:len(k)-2]

		for sk := range src {
			if strings.HasPrefix(sk, rawSensorID) {
				// If already exist -> skip
				if _, ok := workset[sk]; !ok {
					// Allow for substitution right hand side mapping using macros.
					workset[sk] = macroSubstitution(rawSensorID, sk, v)
				}
			}
		}

		// Remove the wildcard mapping from the mapping
		delete(mapping, k)
	}

	// 3. Add any extra source data that is not part of map section
	for k := range src {
		// Ensure mapping exist, if none is specified
		if _, ok := workset[k]; !ok {
			workset[k] = k
		}
	}

	// 4. workset + mapping -> new mapping
	for k, v := range workset {
		mapping[k] = v
	}

	// 5. if mid empty or '*'/'**' -> mid = all mappings that do have a source match.
	mid := config.GetParamAsStringWithDefault(string(ifprovider.ParameterMappingIDs), "")

	if mid == "" || mid == "*" || mid == "**" {
		mid = ""

		for k := range mapping {
			// Only include IDs into MID that has a source data match
			if _, ok := sourceData[k]; ok {
				mid += k + " "
			}
		}

		mid = strings.TrimSpace(mid)
	} else {
		// Filter out mappings from MID string
		// NOTE: This is the delayed filtering that where deferred in the repository.go::Merge() function!
		mids, err := expandMidsFromKeys(mid, slices.Collect(maps.Keys(mapping)))

		if err != nil {
			return err
		}

		mid = strings.Join(mids, " ")

		for k := range mapping {
			if !slices.Contains(mids, k) {
				delete(mapping, k)
			}
		}
	}

	// 6. Update mapping in config
	utils.ToProviderConfigImpl(config).Params[string(ifprovider.ParameterMappingIDs)] = mid

	return nil
}

// expandMidsFromKeys will examine all _mid_ that have a regexp operator and select on the key. The key is then added
// to the whole pool fo mids.
func expandMidsFromKeys(mid string, keys []string) ([]string, error) {
	mids := strings.Split(mid, " ")
	res := make(map[string]struct{}, len(keys))

	for _, m := range mids {
		if !regexutils.IsRegex(m) {
			res[m] = struct{}{}
			continue
		}

		if re, err := cbeval.GlobalGlobRegExpCache.Glob(m, '_'); err != nil {
			return nil, err
		} else {
			for _, k := range keys {
				if re.Match(k) {
					res[k] = struct{}{}
				}
			}
		}
	}

	return slices.Collect(maps.Keys(res)), nil
}

// sourceMapViaSelection will use the _selection_ to create a _map_ section using the `providermodel.Selection.TeosId` as key
// and the `providermodel.Selection.RemoteId` as value.
//
// It will update the MID to contain all the keys that where added to the mapping. If mid already contains items, it will not be touched
// and selection will only populate mapping section.
func sourceMapViaSelection(
	config ifprovider.ConfigFull,
	sourceData map[string]any,
	selection []providermodel.Selection,
) {
	mid := config.GetParamAsStringWithDefault(string(ifprovider.ParameterMappingIDs), "")
	mapping := config.GetMapping()

	if mid == "" || mid == "*" || mid == "**" {
		mid = ""

		var ok bool

		for _, sel := range selection {
			if _, ok = sourceData[sel.RemoteId]; !ok {
				_, ok = sourceData[sel.TeosId]
			}

			if ok {
				mid += sel.TeosId + " "
				mapping[sel.TeosId] = sel.RemoteId
			}
		}
	} else {
		for _, sel := range selection {
			if _, ok := sourceData[sel.RemoteId]; ok {
				mapping[sel.TeosId] = sel.RemoteId
			} else if _, ok := sourceData[sel.TeosId]; ok {
				mapping[sel.TeosId] = sel.RemoteId
			}
		}
	}

	utils.ToProviderConfigImpl(config).Params[string(ifprovider.ParameterMappingIDs)] = strings.TrimSpace(
		mid,
	)
}
