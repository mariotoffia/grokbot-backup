package esv

import (
	"embed"
	"slices"
	"testing"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy"
	teosctx "github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

//go:embed testdata/provider-config/*.* testdata/provider-config/*/*.*
var providerConfig embed.FS

//go:embed testdata/policies/*.*
var policies embed.FS

//go:embed testdata/pdp-config/*.*
var pdpConfig embed.FS

var simpleTestPath = "/provider/test/sv"

// newProviderContext builds the root context a provider pipeline in this
// package runs under: the unit-test environment, console and pipeline logging,
// the policies and policy decision point embedded beside these tests, and an
// empty AWS configuration. It is closed when the test ends.
func newProviderContext(tb testing.TB, provider, service string) ifcore.CbContext {
	tb.Helper()
	testenv.Use(tb, testenv.EnvDefaults)

	c, err := teosctx.NewContext(service, provider, cbenv.DevLocal, true, /*sort*/
		slices.Concat(teosctx.OptionPackLogging, teosctx.OptionPackPipeLogging, []ifcore.CbContextOption{
			teosctx.OptAWSSetConfig(aws.Config{}, true /*force*/),
			cbpolicy.OptSubContext(true /*force*/, cbpolicy.NewImmutablePRP(nil /*noKey*/).RegisterFsModules(policies)),
			cbpolicy.OptPDPFromFSConfig(pdpConfig),
		})...)
	require.Nil(tb, err)
	tb.Cleanup(c.Close)

	return c
}
