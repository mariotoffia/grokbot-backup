package sv

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/cfgmodel"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestCFINBootstrapMap tests bootstrapping creation of cfin configuration creation
// (by sending a event that allows for one or more cfin to be created).
//
// Basically this will do a discovery of which profile to use when doing the *real*
// config discovery.
func TestCFINBootstrapMap(t *testing.T) {
	pid := "myPlantID"
	lid := "Måssmyren 44"

	now := *coremodel.NewTime32Now()

	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			if len(rid) == 0 {
				return nil, nil, nil
			}

			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{
					ID:        "virtualPTD_O1",
					Value:     "Cetetherm DHC",
					TimeStamp: now,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualPTD_O2", Value: "v3.96.3", TimeStamp: now},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "thiink", string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		UseCredentialsFunction(
			func(context ifcore.CbContext, cred string, pipeCtx map[string]any, op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
						Credentials: securitymodel.StandardCredentialsImpl{
							Endpoint: "api.climatixic.com",
						}},
					360, nil
			},
		).
		WithPipe(
			func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
				return pb.
					MapSectionIsWithoutPartition().
					HasPartitionIDSeparator(";").
					UseMappingDirection(providermodel.MappingDirectionLeftAssign).
					WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
					UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
					AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
			},
		).WithPipe(
		func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationDataPointDiscovery))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/bootstrap-map",
				 "prms": {
					 "LOG": "true",
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default",
					 "CRD": "ptr/to/my/credentials",
					 "CFGGEN_RES": "240min"
				}
		}`, pid, lid),
		},
	}))

	require.NoError(t, invokeError)
	require.NotNil(t, result)

	res := result.(*cbevent.ProviderResultEvent)
	require.Equal(t, 1, len(res.Result))

	m := cbevent.ExtractResult[map[string]cfgmodel.ImportConfigEvent](res, 0)
	require.Equal(t, 1, len(m))

	ie := m["target"]

	assert.Equal(t, lid, ie.LocationID)
	assert.Equal(t, "thiink", ie.ProviderName)
	assert.Equal(t, "cfin/bootstrap-map", ie.Profile)
	assert.Equal(t, true, ie.Params["bootstrap"])
	assert.Len(t, ie.Conf.Targets, 1)

	target := ie.Conf.Targets[0]

	assert.Equal(t, true, target.Enabled)
	assert.Equal(t, cfgmodel.ConfigTargetModes(""), target.Mode.Mapping)
	assert.Equal(t, cfgmodel.ConfigTargetModes(""), target.Mode.Prms)
	assert.Equal(t, cfgmodel.ConfigTargetModeCreateOnly, target.Mode.Target)
	assert.Equal(t, cfgmodel.ProviderOperationConfigurationInbound, target.Operation)
	assert.Equal(t, "thiink", target.Provider)
	assert.Equal(
		t,
		"!['grp' + trg.op]",
		target.Group,
		"Since '!' delays until merge service handling",
	)
	assert.Equal(t, "cetetherm/sv", target.Profile, "since override in input params")
	assert.Equal(t, "240min", *target.Resolution, "since override in input params")
	assert.Equal(t, lid, target.Params["BID"])
	assert.Equal(t, "ptr/to/my/credentials", target.Params["CRD"])
	assert.Equal(t, pid, target.Params["PID"])
	assert.Equal(t, "abc-123", target.Params["TID"])
	assert.Equal(t, "Europe/Stockholm", target.Params["TZ"])
}

func BenchmarkCFINBootstrapMap(t *testing.B) {
	pid := "myPlantID"
	lid := "Måssmyren 44"

	now := *coremodel.NewTime32Now()

	// Simulate call to remote endpoint for fetching sensor values
	source :=
		func(ctx ifcore.CbContext, pipeCtx map[string]any, operation string, eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl, rid []string, cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
			if len(rid) == 0 {
				return nil, nil, nil
			}

			return []eqmodel.CbDataPoint{
				&eqmodel.CbDataPointImpl{
					ID:        "virtualPTD_O1",
					Value:     "Cetetherm DHC",
					TimeStamp: now,
				},
				&eqmodel.CbDataPointImpl{ID: "virtualPTD_O2", Value: "v3.96.3", TimeStamp: now},
			}, nil /*body*/, nil /*err*/
		}

	// Root Service Context
	ctx := newProviderContext(t, "thiink", string(locationmodel.ProviderOperationConfigurationIn))

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		UseCredentialsFunction(
			func(context ifcore.CbContext, cred string, pipeCtx map[string]any, op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
						Credentials: securitymodel.StandardCredentialsImpl{
							Endpoint: "api.climatixic.com",
						}},
					360, nil
			},
		).
		WithPipe(
			func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
				return pb.
					MapSectionIsWithoutPartition().
					HasPartitionIDSeparator(";").
					UseMappingDirection(providermodel.MappingDirectionLeftAssign).
					WithMarshalPrototype("cfg", &cfgmodel.ImportConfigEvent{}).
					UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
					AsOperation(string(locationmodel.ProviderOperationConfigurationIn))
			},
		).WithPipe(
		func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				UseSourceMapWithReport(providerpipe.ToSourceMapFromSrc(source)).
				AsOperation(string(locationmodel.ProviderOperationDataPointDiscovery))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationConfigurationIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	builder.UseProviderDispatcher(
		providercontext.DefaultNativeDispatcherProviderEvent("/provider/test/cfin", builder),
	)

	pctx := builder.Build()

	payload := jsonutils.ToJSON(&cbevent.ProviderEvent{
		Provider: "test-provider",
		Result:   true,
		Config: []any{
			fmt.Sprintf(`{ "profile": "cfin/bootstrap-map",
				 "prms": {
					 "LOG": "true",
					 "PID": "%s",
					 "TID": "abc-123",
					 "BID": "%s",
					 "OID": "default",
					 "CRD": "ptr/to/my/credentials",
					 "CFGGEN_GRP": "default",
					 "CFGGEN_RES": "240min"
				}
		}`, pid, lid),
		},
	})

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		result, invokeError := pctx.Invoker().InvokeRaw(ctx, payload)

		require.NoError(t, invokeError)
		require.NotNil(t, result)
	}
}
