package providerpipe

import (
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"

	"github.com/rs/zerolog"
)

// PipeExecutorBuilder will build a provider pipe executor that later can be executed to perform the
// actual work.
type PipeExecutorBuilder struct {
	ctx      ifcore.CbContext
	executor *ProviderPipeExecutorImpl
	built    bool
	err      cberror.Error
}

// NewExecutorBuilder creates new instance of the executor builder.
func NewExecutorBuilder(ctx ifcore.CbContext) *PipeExecutorBuilder {
	return &PipeExecutorBuilder{
		ctx:      ctx,
		executor: NewProviderPipeExecutor(ctx),
	}
}

// Error returns an error if any error did occur during the build process.
func (e *PipeExecutorBuilder) Error() cberror.Error {
	return e.err
}

// Build will return the built executor.
func (e *PipeExecutorBuilder) Build() *ProviderPipeExecutorImpl {
	if e.built {
		panic("ExecutorBuilder.Build() called more than once")
	}

	if e.err != nil {
		return nil
	}

	if e.executor.pipeConfig == nil {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(), cberror.ErrorExecutorBuilderNoPipeProvided, nil,
			"ExecutorBuilder.Build() called without pipe",
		)

		return nil
	}

	if e.executor.config == nil {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(), cberror.ErrorExecutorBuilderNoConfig, nil,
			"ExecutorBuilder.Build() called without config",
		)

		return nil
	}

	if e.executor.extractTargetFunc == nil {
		// Default function to extract target from the executed pipeline.
		e.executor.extractTargetFunc = func(
			ctx ifcore.CbContext,
			vars map[string]any,
			targetKey string,
			config ifprovider.ConfigFull) (target map[string]any, err cberror.Error) {

			trg, exists := vars[targetKey]
			if !exists || trg == nil {
				return nil, cberror.NewCbErrorf(
					ctx.Service(), cberror.ErrorProviderUnableToExtractTarget, nil,
					"Failed to extract target, config %#v", config,
				)
			}

			if tm, ok := trg.(map[string]any); ok {
				return tm, nil
			}

			return map[string]any{targetKey: trg}, nil
		}
	}

	e.built = true
	return e.executor
}

// AllowMutateGlobalParams will mutate any expression in global params in the provider configuration and
// hence mutate it. Please make sure that the configuration being used is cloned and not used anywhere else.
func (e *PipeExecutorBuilder) AllowMutateGlobalParams() *PipeExecutorBuilder {
	e.executor.allowMutateGlobalParams = true

	return e
}

// UsePipe will set the pipe to executed
func (e *PipeExecutorBuilder) UsePipe(providerPipe ProviderPipeImpl) *PipeExecutorBuilder {
	e.executor.pipeConfig = &providerPipe

	return e
}

// UseConfig will set the configuration to use when executing the pipe.
//
// NOTE: If using the `NewProviderPipelineExecutorBuilder`, do not use this function directly, instead
// use the `UseConfig` function on the `NewProviderPipelineExecutorBuilder` instance instead.
func (e *PipeExecutorBuilder) UseConfig(config ifprovider.ConfigFull) *PipeExecutorBuilder {
	e.executor.config = config

	return e
}

// FromUserConfig will merge the provided user _config_ with a local profile.
// The _config_ is a _JSON_ object that at-least have a _"profile": "profile-name"_ to be
// used to lookup a local profile.
//
// NOTE: If using the `NewProviderPipelineExecutorBuilder`, do not use this function directly, instead
// use the `FromUserConfig` function on the `NewProviderPipelineExecutorBuilder` instance instead.
func (e *PipeExecutorBuilder) FromUserConfig(config string) *PipeExecutorBuilder {
	var err cberror.Error
	// Merge user configuration with local profile
	cfg, err := e.executor.pipeConfig.Owner.repository.MergeFromConfigString(e.ctx, config)
	if err != nil {
		e.err = err

		if l, ok := logger.ClsLog(
			zerolog.ErrorLevel, "pipe-executor-builder", logger.LDTUntyped, logger.LISUnclassified, e.ctx,
		); ok {
			logger.LogObjectf(
				l, "err", err,
				"Failed to merge user configuration with local profile",
			)
		}
	} else {
		e.executor.config = cfg
	}
	return e
}

// UseTargetKey will change the key to extract the result when pipe has executed. The default
// is: _target_.
func (e *PipeExecutorBuilder) UseTargetKey(target string) *PipeExecutorBuilder {
	e.executor.targetKey = target

	return e
}

// UseInput will copy the input data into the executor input. It will then be used
// when constructing the pipe context
func (e *PipeExecutorBuilder) UseInput(input map[string]any) *PipeExecutorBuilder {
	for k, v := range input {
		e.executor.input[k] = v
	}

	return e
}

// UseAutoLogging will set the logging flag according to the context setting and the
// `ifprovider.ParameterLogging` parameter.
func (e *PipeExecutorBuilder) UseAutoLogging() *PipeExecutorBuilder {
	e.executor.logging = e.ctx.PipeLogging() == cbenv.PipeLoggingOn

	if e.ctx.PipeLogging() == cbenv.PipeLoggingOptional {
		if pipelog := e.executor.config.GetParamAsStringWithDefault(string(ifprovider.ParameterLogging), ""); pipelog != "" {
			e.executor.logging = cbenv.PipeLogging(strings.ToLower(pipelog)) == cbenv.PipeLoggingOn
		} else if e.executor.input != nil {
			if pipelog, ok := e.executor.input[string(ifprovider.ParameterLogging)]; ok {
				e.executor.logging = cbenv.PipeLogging(strings.ToLower(pipelog.(string))) == cbenv.PipeLoggingOn
			}
		}
	}

	return e
}

// WhenPrepare sets the callback that is invoked when the pipe is about to be executed.
//
// This can be used to provide data into the pipe context or input data.
//
// NOTE: This is invoked before the pipe is prepared and hence may influence the input as well.
func (e *PipeExecutorBuilder) WhenPrepare(onPrepare OnPrepare) *PipeExecutorBuilder {
	e.executor.onPrepare = onPrepare

	return e
}

// UsePrepareProfile sets the callback that is invoked just before the source function is called. This function
// can be used to do discovery on a remote endpoint and modify/replace profile or parameters. It is named
// so the user may set the _PPF_ (ParameterPrepareProfile) variable in globals to denote which function it should call.
//
// NOTE: If PPF refers to a function that is not set, it will be ignored.
func (e *PipeExecutorBuilder) UsePrepareProfile(m map[string]PrepareProfile,
) *PipeExecutorBuilder {
	e.executor.prepareProfile = m

	return e
}

// WhenSource sets the callback to be invoked after a call to source function.
func (e *PipeExecutorBuilder) WhenSource(onSource OnSource) *PipeExecutorBuilder {
	e.executor.onSource = onSource

	return e
}

// WhenTarget sets the callback to be invoked after a call to target function and just before
// returning the result.
func (e *PipeExecutorBuilder) WhenTarget(onTarget OnTarget) *PipeExecutorBuilder {
	e.executor.onTarget = onTarget

	return e
}

// UseExtractTarget will replace the default function to extract the target from the executed pipe.
func (e *PipeExecutorBuilder) UseExtractTarget(
	onExtractTarget ExtractTargetFunc,
) *PipeExecutorBuilder {
	e.executor.extractTargetFunc = onExtractTarget

	return e
}
