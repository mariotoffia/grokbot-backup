package providertest

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"time"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot/awsmgriot"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// GetTestLogLevel will extract the value from `CB_TEST_LOG_LEVEL` environment variable.
//
// If not set `zerolog.NoLevel` will be returned.
func GetTestLogLevel() zerolog.Level {
	if level, err := zerolog.ParseLevel(os.Getenv("CB_TEST_LOG_LEVEL")); err != nil {
		return zerolog.NoLevel
	} else {
		return level
	}
}

// CreateDeviceManagerWithThingName will create a new device of unit-test type and return it.
//
// CAUTION: Make sure to delete the thing after using it.
func CreateDeviceManagerWithThingName(
	ctx ifcore.CbContext,
	lid string,
) (*mgriot.DeviceManagerImpl, cberror.Error) {
	//
	mgr := awsmgriot.NewAWSDeviceManager(ctx).
		UseDeviceName(lid).
		UseDeviceType("unit-test")

	mgr.CreateDeviceType(
		"Device type for use in unit testing",
		nil,
		coremodel.Tag{Name: "actor", Value: "unit-test"},
	)

	mgr.ClearError().CreateDevice(map[string]interface{}{"provider": "unittest"})

	return mgr, mgr.Error()
}

// CreateAndWaitForDeviceShadow will create a device shadow and wait until it is created.
func CreateAndWaitForDeviceShadow(mgr *mgriot.DSManager, lid string) error {
	mgr.ClearError().UseReportedStatePayload([]byte(`{}`), "", false).UpsertReported()

	if mgr.Error() != nil {
		return mgr.Error()
	}

	for i := 0; i < 10; i++ {
		if mgr.ClearError().GetShadowState().Error() == nil {
			break
		}

		time.Sleep(1 * time.Second)
	}

	return fmt.Errorf("failed to create device shadow for: %s", lid)
}

// CreateIoTManager will create a new IoT manager by extracting the endpoint from the context
// using the `provider.ProviderCtxEndpoint` key. If not provided, it will try to auto detect
// the endpoint from AWS.
//
// It configures the manager to use device _lid_ and _"building"_ shadow name.
func CreateIoTManager(ctx ifcore.CbContext, lid string) (*mgriot.DSManager, cberror.Error) {
	mgr := awsmgriot.NewAWSDSManager(ctx).
		UseDeviceName(lid).
		UseShadowName("building")

	epv := ctx.Value(provider.ProviderCtxEndpoint)

	if epv != nil {
		if ep, ok := epv.(*url.URL); !ok {
			mgr.DiscoverEndpoint()
		} else {
			mgr.UseEndpoint(ep)
		}
	} else {
		mgr.DiscoverEndpoint()
	}

	return mgr, nil
}

// GetDeviceShadow will retrieve the device shadow.
func GetDeviceShadow(mgr *mgriot.DSManager) (*dsmodel.DsFullBuilding, error) {
	var building dsmodel.DsFullBuilding

	err := json.Unmarshal(mgr.ReceivedStatePayload(), &building)

	if err != nil {
		return nil, err
	}

	return &building, jsonutils.ToVerboseJSONError(mgr.ReceivedStatePayload(), err, nil)
}

// ClearDeviceShadow will clear the device shadow. If _wait_ is set to `true`
// it will wait until the shadow is updated.
func ClearDeviceShadow(ctx ifcore.CbContext, mgr *mgriot.DSManager, wait bool) cberror.Error {
	version, _ := GetShadowVersion(ctx, mgr)

	mgr.ClearError().Upsert([]byte(`{"state": { "desired": null, "reported": null }}`))

	if mgr.Error() != nil {
		return mgr.Error()
	}

	if wait {
		_, _, err := WaitUntilShadowIsUpdated(
			ctx,
			mgr,
			version,
			20*time.Second,
			SensorShadowState{},
			true, /*exactMatch*/
		)

		return err
	}

	return nil
}

// GetShadowVersion will retrieve the shadow version.
func GetShadowVersion(ctx ifcore.CbContext, mgr *mgriot.DSManager) (int64, cberror.Error) {
	_, version, _ := mgr.WhenChangedShadowState(ctx, -1, 0)

	if mgr.Error() != nil {
		return 0, mgr.Error()
	}

	return version, nil
}

// WaitUntilShadowIsUpdated will wait until the shadow is updated.
//
// If shadow was updated, it returns `true` and the version, otherwise `false` (and the version).
//
// Default timeout is 10 seconds (if _timeout_ is zero or less). If _states_ are provided, it will
// wait until the shadow is updated to all of the states or timeout.
//
// If it timeout, it will return an error.
//
// The _currentVersion_ is the current version of the device shadow and _states_ is the expected
// shadow state to wait for. If _currentVersion_ is -1, it will automatically fetch the current
// version and do a wait. If _exactMatch_ is set to `true`, it will check if the _state_ are a
// exact match. Otherwise it will just check that the _states_ are contained in the shadow.
func WaitUntilShadowIsUpdated(
	ctx ifcore.CbContext,
	mgr *mgriot.DSManager,
	currentVersion int64,
	timeout time.Duration,
	states SensorShadowState,
	exactMatch bool,
) (int64, bool, cberror.Error) {
	//
	if timeout <= 0 {
		timeout = 10 * time.Second
	}

	if states == nil {
		states = SensorShadowState{}
	}

	var (
		newVersion int64
		changed    bool
		matched    bool
		now        = time.Now()
		timeLeft   = timeout
	)

	for timeLeft > 0 {
		changed, newVersion, _ = mgr.WhenChangedShadowState(ctx, currentVersion, timeLeft)
		timeLeft = timeout - time.Since(now)

		if mgr.Error() != nil {
			return 0, false, mgr.Error()
		}

		ds := ToDeviceShadow(mgr.ReceivedStatePayload())

		if exactMatch {
			matched = ds.State.Reported.Sensors.AreEqual(states)
		} else {
			matched = ds.State.Reported.Sensors.HasState(states)
		}

		if matched {
			break
		}

		time.Sleep(1 * time.Second)
	}

	if !matched {
		return 0, false, cberror.NewCbErrorf(
			ctx.Service(), http.StatusRequestTimeout, nil,
			"failed to match shadow state, exactMatch: %t, expected: %v, got: %v, waited for: %s",
			exactMatch, states,
			ToDeviceShadow(mgr.ReceivedStatePayload()).State.Reported.Sensors, timeout.String(),
		)
	}

	return newVersion, changed, nil
}
