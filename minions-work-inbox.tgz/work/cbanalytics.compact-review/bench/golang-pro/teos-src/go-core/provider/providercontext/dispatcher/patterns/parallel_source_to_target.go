package patterns

import (
	"runtime"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/procutils"
)

// ParallelSourceToTargetOptions is the options that are passed to the
// `ParallelSourceToTargetBatched()` function.
type ParallelSourceToTargetOptions[TInput any, TOutput any] struct {
	// ExecuteOptions that are passed to the `providercontext.ProviderContext.Execute()` function.
	//
	// TIP: If no target function is set it will install a default one that will verify that the target
	// is of the correct type.
	ExecuteOptions providercontext.OptExecute
	// ProviderContext is *MANDATORY*
	ProviderContext providercontext.ProviderContext
	// Config is the provider config that will be used as either default or the configuration to use.
	//
	// NOTE: The usage depends on the `providercontext.ProviderUserConfigUsage` setting either in the
	// `providercontext.ProviderContext` or in the `providercontext.OptExecute`.
	Config string
	// LocationID is an optional _LocationID_ that will be passed when loading user config. Thus it is
	// only applicable when user config loader are used.
	LocationID string
	// Input is the input that will be passed to the provider pipeline. It may be `nil`.
	Input map[string]any
	// MaxParallelization is the number of parallel executions that will be done. If not set it will be set
	// to `runtime.NumCPU()*32`.
	//
	// TIP: If no parallelism is wanted, use _1_.
	MaxParallelization int
	// Timeout is the main timeout for the processing, default is _120_ seconds.
	Timeout time.Duration
	// OnError specifies what to do when an error happens. Default is `ExecuteOnErrorStop`.
	OnError ExecuteOnError
	// BatchTarget is a function that gets called when a pipeline has executed.
	//
	// NOTE: This is an optional function and if not set, the `providercontext.OptExecute.BatchTarget` functions are used.
	// If not set in the `providercontext.OptExecute.BatchTarget` functions, it will use the target set in the pipeline.
	//
	// If this function is set, it will use the same go routine that source and pipeline is using and hence it is the same
	// as with a "standard" pipeline target function but this function is, high-level, and more simple since it will get
	// an already unmarshalled struct if there's one to be emitted.
	//
	// TIP: It may recieve several items at once, *if* the pipeline is configured to do so. But it is _usually_ the result
	// of a single source item. If the `BatchSize` is greater than _1_, it will be result of a batch of source items.
	BatchTarget BatchTargetFunc[TOutput]
	// Source is the source function that will be used instead of the `providercontext.OptExecute.Source` functions.
	//
	// NOTE: It is an optional function and if not set, the `providercontext.OptExecute.Source` functions will be used.
	// If none in the `providercontext.OptExecute.Source` functions are set, it will use the source set in the pipeline.
	Source SourceFunc[TInput]
	// BatchSize alters the behavior so it will create batches of the source items and then parallelize the batches.
	//
	// Each batch items is iterated in the same go routine sequentially and then the `Target` is invoked *after* all
	// items in the batch has been processed. This defaults to _1_ in order to process each item individually.
	BatchSize int
}

// ParallelSourceToTarget will do a parallel execution from source to target in a single
// go routine. It uses up to _maxParallelization_ go routines to process the _events_. When
// there are more _events_ than _maxParallelization_, it will wait for the first batch to
// finish before starting the next batch.
//
// TIP: This is useful when a provider recieves a set of events that needs to be processed
// in parallel but within limits and all the way from source to target runs in a separate
// go routine.
//
// If the source function is a calling an external service, use the "standard" pipeline source
// function instead. In that case, use the "standard" pipeline target function as well and
// just run the pipelines in parallel using the `package procutils` functions.
//
// NOTE: If the `BatchSize` is set to anything else than _1_, the `Target` function will be
// called with a slice of the results instead of one item at a time. It will support the use-case
// where calling a source is relative cheap and the target is effectively batched in a single invocation.
func ParallelSourceToTarget[TInput any, TOutput any](
	ctx ifcore.CbContext,
	events []*TInput,
	options ParallelSourceToTargetOptions[TInput, TOutput],
) procutils.ParallelizerResults[[]*TOutput] {
	// Handle defaults
	if options.ExecuteOptions.SimpleTarget == nil && options.ExecuteOptions.Target == nil {
		options.ExecuteOptions.SimpleTarget = func(target map[string]any) cberror.Error {
			// Verify that target do exist, and that it's of the correct type.
			return providerutils.VerifyTarget[TOutput](ctx, target)
		}
	}

	if options.ProviderContext == nil {
		panic("providercontext.ProviderContext is mandatory")
	}

	if options.Source != nil {
		// Clear the source functions
		options.ExecuteOptions.Source = nil
		options.ExecuteOptions.NoArgSource = nil
	}

	if options.MaxParallelization == 0 {
		options.MaxParallelization = runtime.NumCPU() * 32
	}

	if options.Timeout == 0 {
		options.Timeout = time.Duration(120 * time.Second)
	}

	if options.OnError == ExecuteOnErrorUnknown {
		options.OnError = ExecuteOnErrorStop
	}

	if options.BatchSize < 1 {
		options.BatchSize = 1
	}

	execute := procutils.BatchParallelizer(
		ctx,
		events,
		options.BatchSize,
		options.MaxParallelization,
		options.Timeout,
		func(ctx ifcore.CbContext, idx int, item *TInput) ([]*TOutput, cberror.Error) {
			opt := options.ExecuteOptions

			if options.Source != nil {
				opt.NoArgSource = func() (map[string]any, cberror.Error) {
					return options.Source(ctx, item)
				}
			}

			// Execute the provider pipeline
			res, err := options.ProviderContext.Execute(
				ctx,
				options.LocationID,
				options.Config,
				item,
				options.Input,
				&opt,
			)

			switch options.OnError {
			case ExecuteOnErrorContinue:
				break
			case ExecuteOnErrorStop:
				if err != nil {
					return nil, err
				}

				// This case also includes the case below
				fallthrough
			case ExecuteOnErrorPipeExecutionErrorStop:
				if res.HasError() {
					return nil, res.GetCompositeError()
				}
			}

			var frames []*TOutput

			for i := range res {
				frame, err := providerutils.ExtractTargetError[TOutput](
					ctx,
					res[i].Result,
				)

				if err != nil {
					return nil, err
				}

				frames = append(frames, frame)
			}

			return frames, nil
		},
		func(start, end int, items []*procutils.ParallelizerResult[[]*TOutput]) []procutils.ParallelizerErrors {
			process := []*TOutput{}

			for i := range items {
				if items[i].Error == nil && len(items[i].Result) > 0 {
					for _, item := range items[i].Result {
						item := item
						process = append(process, item)
					}
				}
			}

			// No Callback set, just return or len i zero
			if options.BatchTarget == nil || len(process) == 0 {
				return nil
			}

			// Call target func with process
			errors := options.BatchTarget(ctx, process)

			if len(errors) == 0 {
				return nil
			}

			var (
				result  []procutils.ParallelizerErrors
				offset  int
				current int
			)

			// Remap errors so they have correct ParallelizerErrors.Index.
			for i := range items {
				if items[i].Error != nil {
					offset++
				}

				if errors[current].Index == (i - offset) {
					result = append(result, procutils.ParallelizerErrors{
						Index: i,
						Error: errors[current].Err,
					})

					current++

					if current == len(errors) {
						break
					}
				}
			}

			return result
		},
	)

	return execute
}
