package querysettings

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// FromParams will parse the `params` map and look for either QS. resolution or stateful.
// It will then parse the resolution and prepare the `QuerySettings`
// struct for use. If no resolution or stateful is found it will still return a `QuerySettings`.
func FromParams(params map[string]any) (*providermodel.QuerySettings, error) {
	qs := &providermodel.QuerySettings{}

	// resolution
	if resolution := findQSTable("resolution", params); len(resolution) > 0 {
		qs.Resolution = make(map[string]string, len(resolution))

		for k, v := range resolution {
			if s, ok := v.(string); ok {
				qs.Resolution[k] = s
			} else {
				return nil, fmt.Errorf("stateful value for key: %s is not a string", k)
			}
		}
	}

	// stateful
	if stateful := findQSTable("stateful", params); len(stateful) > 0 {
		qs.Stateful = make(map[string]string, len(stateful))

		for k, v := range stateful {
			if s, ok := v.(string); ok {
				qs.Stateful[k] = s
			} else {
				return nil, fmt.Errorf("stateful value for key: %s is not a string", k)
			}
		}
	}

	return qs, nil
}

// findQSTable will search for the _name_ key in the
// params map either directly or under "QS".
// It will return the map that is the value of the _name_ key.
func findQSTable(name string, params map[string]any) map[string]any {
	var tbl map[string]any

	if v, ok := params["QS"]; ok {
		if tbl, ok = v.(map[string]any); !ok {
			return nil
		}
	} else {
		tbl = params
	}

	if v, ok := tbl[name]; ok {
		if tbl, ok = v.(map[string]any); !ok {
			return nil
		}

		return tbl
	}

	return nil
}
