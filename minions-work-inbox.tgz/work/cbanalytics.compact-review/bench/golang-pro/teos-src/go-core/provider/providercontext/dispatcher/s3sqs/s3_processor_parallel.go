package s3sqs

import (
	"net/url"
	"time"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/procutils"
)

// processRecordsParallel will process the records in parallel.
//
// The function will do best effort. If all fails, it will return an error.
// Otherwise, it will log the errors and continue.
func processRecordsParallel(
	parallelism int,
	event *events.S3Event,
	ctx ifcore.CbContext,
	timeout time.Duration,
	defaultProfile string,
	pc providercontext.ProviderContext,
	jsonLoader JSONLoaderFunc,
) cberror.Error {
	// Calculate the max parallelism for the processor.
	procParallelism := parallelism - len(event.Records)

	if procParallelism <= 0 {
		procParallelism = 1
	}

	parallelism = len(event.Records)

	res := procutils.Parallelizer(
		ctx, event.Records, procParallelism, timeout,
		processBatchFunc(parallelism, timeout, defaultProfile, pc, jsonLoader),
	)

	if res.AllError() {
		err := res.CreateOrGetErrorIfExists()

		log.Warn(ctx).
			WithMethod("processRecordsParallel").
			WithBody(event).
			WithError(err).
			Msg("All S3 event records failed")

		return err
	}

	for i, r := range res {
		if r.Error != nil {
			log.Warn(ctx).
				WithMethod("processS3Events").
				WithBody(event.Records[i]).
				WithError(r.Error).
				Int("index", i).
				Msg("Error while processing S3 event record")
		}
	}
	return nil
}

// processBatchFunc will return a function that  `procutils.Parallelizer` can use to process
// each record in parallel.
func processBatchFunc(
	procParallelism int,
	timeout time.Duration,
	defaultProfile string,
	pc providercontext.ProviderContext,
	jsonLoader JSONLoaderFunc,
) func(ctx ifcore.CbContext, idx int, record events.S3EventRecord) (map[string][]providerpipe.IterationExecutionResults, cberror.Error) {
	// This function is used by the `procutils.Parallelizer` to process each record in parallel.
	return func(ctx ifcore.CbContext, idx int, record events.S3EventRecord) (map[string][]providerpipe.IterationExecutionResults, cberror.Error) {
		//
		key := record.S3.Object.Key
		if decoded, err := url.QueryUnescape(key); err == nil {
			key = decoded
		}

		payloads, err := jsonLoader(
			ctx, record.S3.Bucket.Name, key,
		)

		if err != nil {
			return nil, err
		}

		results := map[string][]providerpipe.IterationExecutionResults{}

		// Provider Parallelism is the allowed parallelism internally for each provider.
		provParallelism := 1

		if len(payloads) < (procParallelism + 1) {
			provParallelism = (procParallelism - len(payloads)) / len(payloads)
			procParallelism = len(payloads)
		}

		res := procutils.Parallelizer(
			ctx,
			payloads,
			procParallelism,
			timeout,
			func(ctx ifcore.CbContext, idx int, payload *PayloadData) (providerpipe.IterationExecutionResults, cberror.Error) {
				return executeJSON(
					ctx, pc, payload, defaultProfile, provParallelism,
				)
			},
		)

		for i := range res {
			results[payloads[i].LocationID] = append(
				results[payloads[i].LocationID], res[i].Result,
			)
		}

		return results, res.CreateOrGetErrorIfExists()
	}
}
