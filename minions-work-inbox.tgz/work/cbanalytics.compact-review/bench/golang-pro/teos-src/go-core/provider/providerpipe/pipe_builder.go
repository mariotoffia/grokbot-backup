package providerpipe

import (
	"slices"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// PipeBuilderImpl will build a single `ProviderPipe` instance.
// This may be added to the `ProviderPipelineImpl` into the operations map.
type PipeBuilderImpl struct {
	ctx           ifcore.CbContext
	err           cberror.Error
	pipe          ProviderPipeImpl
	parentBuilder *PipelineBuilder
	hasBuilt      bool
}

// NewPipeBuilder returns a new `PipeBuilderImpl` instance.
func NewPipeBuilder(ctx ifcore.CbContext, owner *ProviderPipelineImpl) *PipeBuilderImpl {
	builder := &PipeBuilderImpl{
		ctx: ctx,
	}

	builder.pipe.prototypes = map[string]any{}
	builder.pipe.Owner = owner
	builder.pipe.mappingDirection = providermodel.MappingDirectionLeftAssign

	return builder
}

// newNestedPipeBuilder is used by the `PipelineBuilder` to automatically add the new pipe to the parent pipeline
// when the `AddToPipeline()` method is called.
func newNestedPipeBuilder(ctx ifcore.CbContext, parent *PipelineBuilder) *PipeBuilderImpl {
	builder := NewPipeBuilder(ctx, &parent.pipeline)
	builder.parentBuilder = parent

	return builder
}

// Error implements the `ifcore.ErrorHandler` interface
func (b *PipeBuilderImpl) Error() cberror.Error {
	return b.err
}

// ClearError implements the `ifcore.ErrorHandler` interface
func (b *PipeBuilderImpl) ClearError() {
	b.err = nil
}

// AddToPipeline is used to add the pipe to the parent pipeline.
//
// CAUTION: Thus function will panic if the `PipeBuilderImpl` was not created by the `PipelineBuilder`.
func (b *PipeBuilderImpl) AddToPipeline() *PipelineBuilder {

	if b.parentBuilder == nil {
		panic("PipeBuilderImpl.AddToPipeline() called on a non-nested pipe builder")
	}

	pipe := b.Build()
	b.parentBuilder.AddPipe(*pipe)

	return b.parentBuilder
}

func (b *PipeBuilderImpl) Build() *ProviderPipeImpl {
	if b.hasBuilt {
		panic("PipeBuilderImpl.Build() called more than once")
	}

	if b.err != nil {
		return nil
	}

	b.hasBuilt = true

	return &b.pipe
}

// AsOperation sets the operation that this pipe will perform.
func (b *PipeBuilderImpl) AsOperation(name string) *PipeBuilderImpl {
	b.pipe.operation = name

	return b
}

// WithMarshalPrototype registers prototypes to use when marshalling. Those are registered under the
// key "_ts" in the pipe context and thus may be referred by the pipe functions.
//
// NOTE: It is possible to register multiple prototypes to be used in the pipe.
func (b *PipeBuilderImpl) WithMarshalPrototype(name string, prototype any) *PipeBuilderImpl {
	if b.err != nil {
		return b
	}

	b.pipe.prototypes[name] = prototype
	return b
}

// UseFilters registers a set of filters.
func (b *PipeBuilderImpl) UseFilters(
	filters map[string]ifprovider.OperationFilters,
) *PipeBuilderImpl {
	if b.err != nil {
		return b
	}

	for k := range filters {
		b.pipe.filters[k] = filters[k]
	}
	return b
}

// UseFilter registers a single filter.
func (b *PipeBuilderImpl) UseFilter(
	name string,
	filter ifprovider.OperationFilters,
) *PipeBuilderImpl {
	if b.err != nil {
		return b
	}

	b.pipe.filters[name] = filter
	return b
}

// UseFilterFromProvider will register all filters from the provider (if any).
func (b *PipeBuilderImpl) UseFilterFromProvider(p provider.Provider) *PipeBuilderImpl {
	if b.err != nil {
		return b
	}

	if filterContributor, ok := p.(provider.ProviderFilterFunctionContributor); ok {
		return b.UseFilters(filterContributor.GetFilterFunctions())
	}

	return b
}

// MapSectionIsWithoutPartition should be set to true when the `map` segment of the configuration
// do not carry any partition information.
//
// NOTE: Partition information is optional and may not even be present in the provider at all.
//
// This is used for reporting.
func (b *PipeBuilderImpl) MapSectionIsWithoutPartition() *PipeBuilderImpl {
	b.pipe.mapperWithoutPartition = true
	return b
}

// UseSplitPartitionID is optional but when submitted it will be used
// to determine the ID and partition by submitting the `eqmodel.CbDataPoint.GetID()`
// to the function.
//
// CAUTION: If `nil` the _ID_ is _REQUIRED_ to be a _ID_ without any partition.
//
// This is used for reporting.
func (b *PipeBuilderImpl) UseSplitPartitionID(
	f providerutils.SplitPartitionAndID,
) *PipeBuilderImpl {
	b.pipe.splitPartitionAndIDFunc = f
	return b
}

// UseToTeosID will set the function that will be used to determine the _TEOS_ id when do reporting.
//
// If not set, it will use a default function for this translation. This is useful when macro based
// mapping is done and the the value of the id, partition is not the same as in the mapping file etc.
func (b *PipeBuilderImpl) UseToTeosID(
	f providerutils.ToTeosIDFunc,
) *PipeBuilderImpl {
	b.pipe.toTeosID = f
	return b
}

// HasPartitionIDSeparator is optional but when submitted it will be used
// to determine the ID and partition by submitting the `eqmodel.CbDataPoint.GetID()`
// to the function.
//
// CAUTION: If `nil` the _ID_ is _REQUIRED_ to be a _ID_ without any partition.
//
// This is used for reporting.
func (b *PipeBuilderImpl) HasPartitionIDSeparator(separator string) *PipeBuilderImpl {
	b.pipe.splitPartitionAndIDFunc = DefaultPartition(separator)
	return b
}

// UseMappingDirection will set the direction where mapping will be performed.
//
// For inbound the mapping is `providermodel.MappingDirectionLeftAssign` and
// for outbound the mapping is `providermodel.MappingDirectionRightAssign`.
//
// TIP: If not specified, it will default to `providermodel.MappingDirectionLeftAssign`.
func (b *PipeBuilderImpl) UseMappingDirection(
	mappingDirection providermodel.MappingDirection,
) *PipeBuilderImpl {
	b.pipe.mappingDirection = mappingDirection

	return b
}

// UseTargetWithReport is the same as the `UseTarget` function, but it will also
// produce a report using the `providerutils.DataPointReport` function.
//
// NOTE: `MapSectionIsWithoutPartition`, `HasPartitionIDSeparator` or `UseSplitPartitionID` may be
// needed to be set in order to properly report.
func (b *PipeBuilderImpl) UseTargetWithReport( /* NOSONAR */
	target ReportableTargetFunction,
) *PipeBuilderImpl { /* NOSONAR */
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipe.target = func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any, targetMap map[string]interface{}) cberror.Error {
		// Extract cbid and remote ids

		var cbid []string
		mapping := CbIDToRidMap{}

		// for cbid: If nothing is set in MID -> use from mapping instead
		mid := strings.Split(
			pc.GetParamAsStringWithDefault(string(ifprovider.ParameterMappingIDs), ""), " ",
		)

		for _, id := range pc.ExtractSensors(op) {
			if n, ok := pc.GetMappedTo(id); ok {
				// If MID -> only add mappings from mid (otherwise all)
				if len(mid) == 0 || slices.Contains(mid, id) {

					mapping[id] = n

					if !providerutils.IsSyntheticID(id, pc) {
						cbid = append(cbid, id)
					}
				}
			} else {
				return cberror.NewCbErrorfWithProps(
					b.ctx.Service(), 1, nil, map[string]any{
						"pn": b.ctx.Provider(),
					}, "sensor %s is not mapped", id,
				)
			}
		}

		dp, body, err := target(ctx, pipeCtx, operation, op, pc, mapping, cred, targetMap)

		if ids, er := expandCbID(cbid, pc, dp); er != nil {
			err = cberror.FromError(b.ctx.Service(), 500, er)
		} else {
			cbid = ids
		}

		// Create the report context
		rc := &providerutils.ReportContext{
			WantedSensors:           cbid,
			DataPoints:              dp,
			Err:                     err,
			Body:                    body,
			Operation:               op,
			ProviderConfig:          pc,
			ProviderOperation:       locationmodel.ProviderOperation(b.pipe.operation),
			MapperWithoutPartition:  b.pipe.mapperWithoutPartition,
			SplitPartitionAndIDFunc: b.pipe.splitPartitionAndIDFunc,
			ToTeosID:                b.pipe.toTeosID,
		}

		return providerutils.DataPointReport(b.ctx, rc)
	}

	return b
}

func (b *PipeBuilderImpl) RegisterPrepareProfile(name string, pf PrepareProfile) *PipeBuilderImpl {
	if b.pipe.prepareProfile == nil {
		b.pipe.prepareProfile = map[string]PrepareProfile{}
	}

	b.pipe.prepareProfile[name] = pf
	return b
}

func (b *PipeBuilderImpl) UsePrepareProfile(m map[string]PrepareProfile) *PipeBuilderImpl {
	if m == nil {
		return b
	}

	b.pipe.prepareProfile = m
	return b
}

// UseTarget sets the target function that is invoked when the pipe has been executed.
func (b *PipeBuilderImpl) UseTarget(target TargetFunction) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipe.target = target
	return b
}

// UseAfter sets the `AfterFunction` that is invoked after the pipe has been executed.
//
// This is executed, directly after a successful target function execution.
func (b *PipeBuilderImpl) UseAfter(target AfterFunction) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipe.after = target

	return b
}

// UseFinally sets a FinallyFunction that is always invoked after pipe execution completes.
//
// Unlike UseAfter (success-only), this runs regardless of outcome and can modify the error.
// The function receives any error that occurred and can wrap, replace, or suppress it.
func (b *PipeBuilderImpl) UseFinally(finally FinallyFunction) *PipeBuilderImpl {
	if b.err != nil {
		return b
	}

	b.pipe.finally = finally

	return b
}

// UseCredentialsFunction will set the function that will be used to obtain credentials.
// If it is not provided it will use the one provided in the `ProviderPipelineImpl`.
func (b *PipeBuilderImpl) UseCredentialsFunction(
	obtainCredentials ObtainCredentialsFunction,
) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipe.credentials = obtainCredentials
	return b
}

// UseVerifyConnectFunction will set the function that will be used to verify the connection.
// If it is not provided it will use the one provided in the `ProviderPipelineImpl`.
func (b *PipeBuilderImpl) UseVerifyConnectFunction(
	verifyConnect VerifyConnectFunction,
) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}
	b.pipe.verifyConnect = verifyConnect
	return b
}
