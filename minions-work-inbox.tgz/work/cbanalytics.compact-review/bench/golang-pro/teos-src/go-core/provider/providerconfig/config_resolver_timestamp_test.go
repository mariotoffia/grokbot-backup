package providerconfig

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// cSpell: disable

func TestMissingTsProtypeWithTsGenerateTemplateInstructionShouldRemoveGenerateTS(t *testing.T) {
	pc := genProviderConfig()
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}, "sensorts": {{GENPROTO_TS}}`,
	}

	result, _, err := CreateGeneratorTemplate(
		newCtx(t),
		&pc,
		"sv",
		"sv",
		true, /*log*/
		map[string]any{},
	)
	assert.Equal(t, nil, err)
	assert.Equal(t, strings.Index(result, "{{GENPROTO}}"), -1)
	assert.Equal(t, strings.Index(result, "{{GENPROTO_TS}}"), -1)

}

func TestSetTStoFalseWillCompletelyRemoveGenProtoTSandMapKey(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "false"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}].Value",
			"IDT_O1": `generate["IDT_O1"].Value`,
			"*":      "float64(generate[{{ID}}].Value)",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"*": "generate[{{ID}}].TimeStamp",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}, "sensorts": {{GENPROTO_TS}}`,
	}

	result, _, err := CreateGeneratorTemplate(
		newCtx(t),
		&pc,
		"sv",
		"sv",
		true, /*log*/
		map[string]any{},
	)

	assert.Equal(t, nil, err)
	assert.Equal(t, -1, strings.Index(result, "{{GENPROTO}}"))
	assert.Equal(t, -1, strings.Index(result, "{{GENPROTO_TS}}"))
	assert.Equal(t, -1, strings.Index(result, "sensorts"))
}

func BenchmarkSetTStoFalseWillCompletelyRemoveGenProtoTSandMapKey(t *testing.B) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "false"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}].Value",
			"IDT_O1": `generate["IDT_O1"].Value`,
			"*":      "float64(generate[{{ID}}].Value)",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"*": "generate[{{ID}}].TimeStamp",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}, "sensorts": {{GENPROTO_TS}}`,
	}

	for i := 0; i < t.N; i++ {
		_, _, _ = CreateGeneratorTemplate(newCtx(t), &pc, "sv", "sv", true /*log*/, map[string]any{})
	}
}

func TestSetTStoFalseWillCompletelyRemoveGenProtoTSandToFirstCommanWhenInArry(t *testing.T) {
	pc := genProviderConfig()
	pc.Params[string(ifprovider.ParameterCheckTimeStampOnUpdate)] = "false"
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}].Value",
			"IDT_O1": `generate["IDT_O1"].Value`,
			"*":      "float64(generate[{{ID}}].Value)",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"*": "generate[{{ID}}].TimeStamp",
		},
	}

	pc.GenProtoTemplates = map[string]string{
		"sv": `{ "tz": TZ, "sensors": {{GENPROTO}}, "sensorts": ["pelle",{{GENPROTO_TS}}]`,
	}

	result, _, err := CreateGeneratorTemplate(
		newCtx(t),
		&pc,
		"sv",
		"sv",
		true, /*log*/
		map[string]any{},
	)

	assert.Equal(t, nil, err)
	assert.Equal(t, -1, strings.Index(result, "{{GENPROTO}}"))
	assert.Equal(t, -1, strings.Index(result, "{{GENPROTO_TS}}"))
	assert.Equal(t, true, strings.Index(result, "sensorts") > 0)
}
