package esvprovider

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/interfaces/iftarget"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot/awsmgriot"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providercommon"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// defaultTarget is used when an error occurred or no target was specified.
//
// It default to building and `iftarget.TargetDataTypeDsBuilding`.
var defaultTarget = &providermodel.Target{
	Names:          []string{"building"},
	TargetDataType: string(iftarget.TargetDataTypeDsBuilding),
	TargetName:     "",
}

// createPipeLine will create a pipeline either by invoking the plugin `CreatePipeline` (if the
// plugin has the _CapsProviderCreatePipeLine_ capability).
//
// If the plugin do not have the _CapsProviderCreatePipeLine_, it will Invoke `GetProfiles` to get the
// available profiles and add it to the default `providerpipe.ProviderPipeline`.
//
// If the plugin has  the capability _CapsProviderObtainCredentials_ it will get the _ObtainCredentials_
// function on the plugin, otherwise it will use the default mechanism to get the `TokenCredentialsProviderConfig`
// from the config system. The plugin may override the default verify mechanism where if it exposes the
// capability _CapsProviderVerifyCredentialUsage_. See the `provider.PipelineAwareProvider` for examples on how to implement
// respective credential, verify and template functions.
//
// TIP: Also see `providerpipe.ObtainCredentialsFunction` and `providerpipe.VerifyConnectFunction` for more samples.
func (esv *ESVPlugin) createPipeLine(
	context ifcore.CbContext) (*providerpipe.ProviderPipeline, cberror.Error) {
	return providercommon.CreatePipeLine(context, esv.plugin, esv.sessionStore)

}

func (esv *ESVPlugin) executeExport(
	c ifcore.CbContext,
	p *providerpipe.ProviderPipeline,
	userConfig string,
	evt *cbevent.SensorValueOutboundEvent) cberror.Error {
	svds, ok := esv.plugin.(SensorValuesOutboundPluginDsBuilding)

	if !ok {
		return cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderInterfaceMissing, nil,
			"The plugin do not implement interface: SensorValuesOutboundPluginDsBuilding",
		)
	}

	pbx, ok := esv.plugin.(provider.PipelineAwareProvider)

	if !ok {
		return cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderInterfaceMissing, nil,
			"The plugin do not implement interface: PipelineAwareProvider",
		)
	}

	dryrun := utils.GetBoolFromContext(c, provider.ProviderCtxDryRun)
	exec := p.NewProviderPipelineExecutor()

	var overrideContext map[string]interface{}

	if esv.pluginCaps.BooleanByName(provider.CapsProviderPipelineOverrideContext, false) {
		overrideContext = pbx.OverrideContext()
	} else {
		overrideContext = map[string]interface{}{
			"_ts": map[string]interface{}{"esv": pbx.GetTargetType()},
		}
	}

	if filterContributor, ok := esv.plugin.(provider.ProviderFilterFunctionContributor); ok {
		exec.UseFilter(filterContributor.GetFilterFunctions())
	}

	exec.UseConfig(userConfig).
		UseDefaultOperation(string(locationmodel.ProviderOperationSensorValueOut)).
		OverrideContext(overrideContext)

	if sourceFunction := svds.SourceFunc(c, exec, evt); sourceFunction != nil {
		exec.UseSource(sourceFunction)
	} else {
		exec.UseSource(func(
			ctx ifcore.CbContext,
			operation string,
			eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			pipeCtx map[string]any,
			cred interface{}) (map[string]interface{}, cberror.Error) {
			if evt.BuildingData.State != nil && evt.BuildingData.State.Desired != nil {
				return map[string]interface{}{
					"src":    evt.BuildingData.State.Desired,
					"source": evt.BuildingData.State.Desired.Sensors,
				}, nil
			}
			return map[string]interface{}{}, nil
		})
	}

	targetFunc := svds.TargetFunc(c, exec, evt)

	if targetFunc == nil {
		return cberror.NewCbErrorf(
			c.Service(),
			cberror.ErrorProviderInterfaceMissing,
			nil,
			"The plugin do not implement function 'TargetFunc in interface: SensorValuesOutboundPluginDsBuilding",
		)
	}

	exec.UseTarget(
		func(
			ctx ifcore.CbContext,
			operation string,
			eop *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			pipeCtx map[string]any,
			cred interface{}, target map[string]interface{}) cberror.Error {
			var opDryRun bool
			dryRunOp := eop.GetParamsAsBool("dryrun") || dryrun

			if dryRunOp {
				opDryRun = true
			} else {
				opDryRun = evt.DryRun
			}

			oldDryRun := evt.DryRun

			if opDryRun {
				evt.DryRun = true
			}

			var err cberror.Error

			err = targetFunc(ctx, operation, eop, pc, pipeCtx, cred, target)

			evt.DryRun = oldDryRun

			if err != nil {
				return err
			}

			if utils.ExtractBoolFromMap(
				SensorValueTargetFuncShallUpdateDsBuilding,
				target,
				false,
			) {
				pst := ifprovider.ProvisionedState(pc.GetParamAsStringWithDefault(
					string(ifprovider.ParameterProvisionedState),
					string(ifprovider.ProvisionedStateProvisioned),
				))

				// Set the report type from _RPT_ config or default
				reportType := providerutils.ReportDsBuildingType(pc.GetParamAsStringWithDefault(
					string(ifprovider.ParameterReportType),
					string(providerutils.ReportDsBuildingAcknowledge),
				))

				// If payload contains _rpt_ use that instead
				if evt.BuildingData.State != nil && evt.BuildingData.State.Desired != nil && evt.BuildingData.State.Desired.ReportType != "" {
					reportType = providerutils.ReportDsBuildingType(
						evt.BuildingData.State.Desired.ReportType,
					)
				}

				targets, _ := providerutils.GetDsFullBuildingTargets(pc, eop, defaultTarget)

				if len(target) == 0 {
					targets = []providermodel.Target{*defaultTarget}
				}

				targetDeviceShadowName := targets[0].Names

				// Guard: State and Desired must be present to report
				if evt.BuildingData.State == nil || evt.BuildingData.State.Desired == nil {
					return nil
				}

				_, err = providerutils.ReportDsBuilding(c,
					nil, /*timestampPolicy*/
					reportType,
					esv.plugin.Name(),
					evt.BuildingData.BuildingID,
					false, /*checkDeviceShadowTimeStamp*/
					false, /*checkLocalTimeStamp*/
					false, /*uploadSensorTsToTarget*/
					pst,
					targetDeviceShadowName[0],
					utils.CreateSchemeURL("https", evt.Endpoint),
					awsmgriot.NewAWSDSManager(c),
					evt.BuildingData.State.Desired,
					evt.DryRun,
				)
			}

			return err
		},
	)

	exec.Execute(providermodel.MappingDirectionRightAssign)

	if exec.Error() != nil {
		if l, ok := logger.ClsLog(zerolog.WarnLevel, "exportSensorValues", logger.LDTUntyped, logger.LISUnclassified, c); ok {
			l.Msgf(
				"failed to execute pipeline, buildingID: %s, error: %s",
				evt.BuildingData.BuildingID, exec.Error().Error(),
			)
		}
	}

	return exec.Error()
}
