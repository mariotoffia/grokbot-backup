package evb

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifstate"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrevent/awsmgrevent"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

func HandleDataPointCloudEvent(
	ctx ifcore.CbContext,
	evt *cbevent.DataPointCloudEventImpl,
	committer ifstate.StatefulCommitter,
	prms map[string]any,
	opt Options,
) cberror.Error {
	//
	const method = "HandleDataPointCloudEvent"

	mgr := awsmgrevent.NewAWSEventManager(ctx.Config())
	// Copy the original (we modify in the emit function minimize allocations)
	m := evt.Data.Data

	m2 := make(map[string]eqmodel.CbDataPoint, len(m))

	for teosid, dp := range m {
		if len(dp) == 0 {
			log.WarnWithLocationID(ctx, evt.Data.LocationID).
				WithMethod("HandleDataPointCloudEvent").
				WithBody(evt).
				Msg("Empty data point")
		} else {
			m2[teosid] = dp[0]
		}
	}

	emitResult := make([]cbevent.CloudEmittedResultEvent, 0, 5)

	emit := func(ctx ifcore.CbContext, event ifstate.ValuesEvent, info map[string]any) cberror.Error {
		evt.Data.Data = make(map[string][]eqmodel.CbDataPoint, len(event))

		// We cleanse the ID, Partition so only value and timestamp are transmitted in event.
		for teosid, dp := range event {
			if opt.OnlyTimeStampAndValueOnDataPoint {
				evt.Data.Data[teosid] = []eqmodel.CbDataPoint{
					&eqmodel.CbDataPointImpl{
						Value:     dp.GetValue(),
						TimeStamp: dp.GetTimeStamp(),
					},
				}
			} else {
				evt.Data.Data[teosid] = []eqmodel.CbDataPoint{dp}
			}
		}

		// Remove keys that we don't want to send
		for _, key := range opt.RemoveKeys {
			delete(evt.Data.Data, key)
		}

		if len(evt.Data.Data) == 0 && !opt.AllowEmptyDetails {
			log.InfoWithLocationID(ctx, evt.Data.LocationID).
				WithMethod(method).
				WithBody(evt).
				Msg("Event has no details (skipping send)")

			return nil
		}

		res, err := mgr.PutEvents(ctx, evt)

		log.InfoWithLocationID(ctx, evt.Data.LocationID).
			WithMethod("EventEmissionToCore").
			WithError(err).
			WithBody(evt).
			AsJSON("result", res).
			Bool("success", err == nil).
			Msg("Event Emission")

		emitResult = append(emitResult, res...)

		if err != nil {
			log.WarnWithLocationID(ctx, evt.Data.LocationID).
				WithMethod(method).
				WithBody(evt).
				WithError(err).
				Msg("Failed to send event")

			return cberror.NewCbErrorf(
				ctx.Service(), 500, err, "Failed to emit event to EventBridge",
			)
		}

		return nil
	}

	if committer == nil {
		// No commit -> push all data manually
		_ = emit(ctx, m2, prms)
	} else {
		_ = committer.Commit(ctx, m2, ifstate.CommitOptions{
			EmitEvent: emit,
			Info:      prms,
		})
	}

	// Restore the original data
	evt.Data.Data = m

	return emitCoreToTargetReport(ctx, evt.Data.LocationID, evt, emitResult, true /*suppressError*/)
}
