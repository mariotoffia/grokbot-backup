package tests

import (
	"maps"
	"slices"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/maputils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

const (
	attributeLabelExpression = "[Attributes.Label]"
)

func TestAdvancedCbEvalRegexpExpression(t *testing.T) {
	expr := `"(?i)H'Hcr\\(CB" + CIRCUIT + "\\)'Hcrv'CB'PrSpTFl\\(ACTSPSSHCT\\)$"`
	pipeCtx := map[string]any{
		"CIRCUIT": "02",
	}

	ctx := testenv.DefaultContext(t, "test")
	re, err := cbeval.Evaluate[string](
		ctx,
		expr,
		pipeCtx,
		true, /*cache*/
		cbeval.EvalCacheLangFullCB,
	)
	require.NoError(t, err)
	assert.Equal(t, "(?i)H'Hcr\\(CB02\\)'Hcrv'CB'PrSpTFl\\(ACTSPSSHCT\\)$", re)
}

func TestInvokeWithSingleSelectorSuccess(t *testing.T) {
	type providerValue struct {
		Attributes map[string]any
	}

	expectedSource := map[string]any{
		"123-456": providerValue{Attributes: map[string]any{"Label": "Rumsgivare 1"}},
		"1228":    providerValue{Attributes: map[string]any{"Label": "Rumsgivare 14"}},
	}

	notExpectedSource := map[string]any{
		"998": providerValue{Attributes: map[string]any{"Label": "Utomhusgivare"}},
		"997": providerValue{},
	}

	expectedSelections := []providermodel.Selection{
		{TeosId: "IDT_O1", RemoteId: "123-456"},
		{TeosId: "IDT_O14", RemoteId: "1228"},
	}

	allSource := maputils.MergeNew(expectedSource, notExpectedSource)

	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		return allSource, nil
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{"PID": "myPlantId"},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "test-op",
		Ctx:            ctx,
		Credentials:    "mock-credentials",
		SourceFunction: sf,
	}

	selector := map[string]providermodel.Selector{
		"['Device-'+PID]": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				`(?i)Rumsgivare\s*(?<O>[1-9][0-9]*)`: {
					TeosId:     "IDT_O{{.O}}",
					Expression: attributeLabelExpression,
					Lang:       providermodel.LangTeos,
				},
			},
		},
	}

	// Invoke using the existing method
	src, _, selection, err := invoker.InvokeWithSingleSelector(selector, nil)

	// Assertions
	require.NoError(t, err)
	assert.Equal(t, allSource, src, "Source data mismatch")
	assert.Equal(t, expectedSource, invoker.Include(src, selection))
	assert.Equal(t, notExpectedSource, invoker.Exclude(src, selection))
	assert.ElementsMatch(t, expectedSelections, selection, "Selections mismatch")
}

func TestInvokeWithTagsMapping(t *testing.T) {
	type providerValue struct {
		Attributes map[string]any
	}

	allSource := map[string]any{
		"B_01'H'Hcr(VS01)'Hcrv'AIOpt'TOa": providerValue{
			Attributes: map[string]any{
				"point":                true,
				"sensor":               true,
				"outside":              true,
				"air":                  true,
				"temp":                 true,
				"hasPhenomenon":        "Air",
				"hasQuantityKind":      "Temperature",
				"hasPointFunctionType": "sensor",
				"hasLocality":          "Outside",
			},
		},
		"B_01'H'Hcr(VS01)'Hcrv'AIOpt'TRtPrim": providerValue{
			Attributes: map[string]any{
				"point":       true,
				"primaryLoop": true,
				"hot-water":   true,
				"entering":    true,
				"sensor":      true,
				"temp":        true,
				"ordinal":     "Ord14",
			},
		},
		"B_01'H'Hcr(VS01)'Hcrv'AIOpt'PrSpTFlCorr": providerValue{
			Attributes: map[string]any{
				"sp":          true,
				"temp":        true,
				"effective":   true,
				"hot-water":   true,
				"leaving":     true,
				"point":       true,
				"primaryLoop": true,
			},
		},
	}

	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		return allSource, nil
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{"PID": "myPlantId", "CIRCUIT": "2"},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "test-op",
		Ctx:            ctx,
		Credentials:    "mock-credentials",
		SourceFunction: sf,
	}

	selector := map[string]providermodel.Selector{
		"['Device-'+PID]": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				`en[point,sensor=true,outside,air,temp]`: {
					TeosId:     "ODT",
					Expression: "[Attributes]",
					Lang:       providermodel.LangTeos,
				},
				`en[sp,temp,effective,hot-water,leaving,point,primaryLoop]`: {
					TeosId: "ACTSPSSHCT_C{{.CIRCUIT}}", Expression: "[Attributes]", Lang: providermodel.LangTeos,
				},
				`en[point,primaryLoop,hot-water,entering,sensor,temp,ordinal=/^Ord(?<O>[1-9][0-9]*)$/]`: {
					TeosId:     "MPRT_O{{.O}}",
					Expression: "[Attributes]",
					Lang:       providermodel.LangTeos,
				},
			},
		},
	}

	src, _, selection, err := invoker.InvokeWithSingleSelector(selector, nil)

	require.NoError(t, err)

	m := map[string]string{}

	for _, v := range selection {
		m[v.TeosId] = v.RemoteId
	}

	assert.Contains(t, src, "B_01'H'Hcr(VS01)'Hcrv'AIOpt'TOa")
	assert.Contains(t, src, "B_01'H'Hcr(VS01)'Hcrv'AIOpt'TRtPrim")
	assert.Contains(t, src, "B_01'H'Hcr(VS01)'Hcrv'AIOpt'PrSpTFlCorr")

	assert.Contains(t, m, "ODT")
	assert.Equal(t, "B_01'H'Hcr(VS01)'Hcrv'AIOpt'TOa", m["ODT"])
	assert.Contains(t, m, "MPRT_O14")
	assert.Equal(t, "B_01'H'Hcr(VS01)'Hcrv'AIOpt'TRtPrim", m["MPRT_O14"])
	assert.Contains(t, m, "ACTSPSSHCT_C2")
	assert.Equal(t, "B_01'H'Hcr(VS01)'Hcrv'AIOpt'PrSpTFlCorr", m["ACTSPSSHCT_C2"])
}

func TestInvokeWithSingleSelectorEmptySelector(t *testing.T) {
	type providerValue struct {
		Attributes map[string]any
	}

	allSource := map[string]any{
		"100": providerValue{Attributes: map[string]any{"Name": "Sensor A"}},
		"101": providerValue{Attributes: map[string]any{"Name": "Sensor B"}},
	}

	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		return allSource, nil
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "empty-selector-op",
		Ctx:            ctx,
		Credentials:    nil,
		SourceFunction: sf,
	}

	selector := map[string]providermodel.Selector{}

	src, _, selection, err := invoker.InvokeWithSingleSelector(selector, nil)

	require.NoError(t, err)
	assert.Len(t, src, 0, "Source data should be empty")
	assert.Nil(t, selection, "Selection should be nil for empty selector")
}

func TestInvokeWithSingleSelectorInvalidDataSet(t *testing.T) {
	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		return nil, nil
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{"Key": "Value"},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "invalid-dataset-op",
		Ctx:            ctx,
		Credentials:    nil,
		SourceFunction: sf,
	}

	selector := map[string]providermodel.Selector{
		"[invalid expression]": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
		},
	}

	_, _, _, err := invoker.InvokeWithSingleSelector(selector, nil)

	require.Error(t, err)
	assert.Contains(
		t,
		err.Error(),
		"Failed to evaluate selector dataSet expression: [invalid expression]",
	)
}

func TestInvokeParallelSuccess(t *testing.T) {
	type providerValue struct {
		Attributes map[string]any
	}

	allSources := []map[string]any{
		{
			"300": providerValue{Attributes: map[string]any{"Label": "Device A"}},
			"301": providerValue{Attributes: map[string]any{"Label": "Device B"}},
		},
		{
			"302": providerValue{Attributes: map[string]any{"Label": "Device C"}},
			"303": providerValue{Attributes: map[string]any{"Label": "Device D"}},
		},
	}

	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		if s, ok := pipeCtx[string(ifprovider.ParameterSelectGroupings)]; ok {
			if sel, ok := s.(providermodel.SelectorWithDataSet); ok {
				if sel.DataSet == "DataSet1" { //nolint:staticcheck // QF1003: if/else is clearer than switch
					return allSources[0], nil
				} else if sel.DataSet == "DataSet2" {
					return allSources[1], nil
				}
			}
		}

		return nil, cberror.NewCbErrorf(ctx.Service(), 400, nil, "expecting a SELECT parameter")
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "parallel-op",
		Ctx:            ctx,
		Credentials:    nil,
		SourceFunction: sf,
	}

	selectors := map[string]providermodel.Selector{
		"DataSet1": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				"Device\\s*(?<ID>[A|B])": {
					TeosId:     "ID_A{{.ID}}",
					Expression: attributeLabelExpression,
				},
			},
		},
		"DataSet2": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				"Device\\s*(?<ID>[C|D])": {
					TeosId:     "ID_B{{.ID}}",
					Expression: attributeLabelExpression,
				},
			},
		},
	}

	src, _, selection, err := invoker.InvokeParallel(selectors, nil)

	require.NoError(t, err)
	assert.Len(t, src, 4, "Source data should contain 4 entries")
	assert.ElementsMatch(t, slices.Collect(maps.Keys(src)), []string{"300", "301", "302", "303"})
	assert.Len(t, selection, 4, "Should have 4 selections")
}

func BenchmarkInvokeWithSingleSelectorSuccess(t *testing.B) {
	type providerValue struct {
		Attributes map[string]any
	}

	allSource := map[string]any{
		"123-456": providerValue{Attributes: map[string]any{"Label": "Rumsgivare 1"}},
		"1228":    providerValue{Attributes: map[string]any{"Label": "Rumsgivare 14"}},
		"998":     providerValue{Attributes: map[string]any{"Label": "Utomhusgivare"}},
		"997":     providerValue{},
	}

	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		return allSource, nil
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{"PID": "myPlantId"},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "test-op",
		Ctx:            ctx,
		Credentials:    "mock-credentials",
		SourceFunction: sf,
	}

	selector := map[string]providermodel.Selector{
		"['Device-'+PID]": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				`(?i)Rumsgivare\s*(?<O>[1-9][0-9]*)`: {
					TeosId:     "IDT_O{{.O}}",
					Expression: attributeLabelExpression,
					Lang:       providermodel.LangTeos,
				},
			},
		},
	}

	t.ResetTimer()

	// Invoke using the existing method
	for i := 0; i < t.N; i++ {
		_, _, _, _ = invoker.InvokeWithSingleSelector(selector, nil)
	}
}

func BenchmarkInvokeParallelSuccess(t *testing.B) {
	type providerValue struct {
		Attributes map[string]any
	}

	allSources := []map[string]any{
		{
			"300": providerValue{Attributes: map[string]any{"Label": "Device A"}},
			"301": providerValue{Attributes: map[string]any{"Label": "Device B"}},
		},
		{
			"302": providerValue{Attributes: map[string]any{"Label": "Device C"}},
			"303": providerValue{Attributes: map[string]any{"Label": "Device D"}},
		},
	}

	sf := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		if s, ok := pipeCtx[string(ifprovider.ParameterSelectGroupings)]; ok {
			if sel, ok := s.(providermodel.SelectorWithDataSet); ok {
				if sel.DataSet == "DataSet1" { //nolint:staticcheck // QF1003: if/else is clearer than switch
					return allSources[0], nil
				} else if sel.DataSet == "DataSet2" {
					return allSources[1], nil
				}
			}
		}

		return nil, cberror.NewCbErrorf(ctx.Service(), 400, nil, "expecting a SELECT parameter")
	}

	ctx := testenv.DefaultContext(t, "test")

	invoker := providerpipe.SourceFunctionInvoker{
		PipeContext:    map[string]any{},
		ProviderConfig: &providermodel.ProviderConfigImpl{},
		Operation:      &providermodel.Operation{},
		OperationName:  "parallel-op",
		Ctx:            ctx,
		Credentials:    nil,
		SourceFunction: sf,
	}

	selectors := map[string]providermodel.Selector{
		"DataSet1": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				"Device\\s*(?<ID>[A|B])": {
					TeosId:     "ID_A{{.ID}}",
					Expression: attributeLabelExpression,
				},
			},
		},
		"DataSet2": {
			DataSetType: providermodel.DataSetTypeDeviceGroup,
			Selectors: map[string]providermodel.SelectObject{
				"Device\\s*(?<ID>[C|D])": {
					TeosId:     "ID_B{{.ID}}",
					Expression: attributeLabelExpression,
				},
			},
		},
	}

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		_, _, _, _ = invoker.InvokeParallel(selectors, nil)
	}
}
