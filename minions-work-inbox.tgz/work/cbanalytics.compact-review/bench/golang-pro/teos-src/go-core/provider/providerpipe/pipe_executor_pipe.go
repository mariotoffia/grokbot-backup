package providerpipe

import (
	"text/template"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/textutils"
)

// executePipe will execute the pipe and return the result.
//
// If any error occurs it will the error state and return `nil`.
//
// NOTE: If the result is a `map[string]any` it will returned as is.
// otherwise the result will be returned inside a map keyed with `DefaultTargetKey` (_"target"_).
//
// It is possible to override the key by setting the key `UseTargetKey` in the
// executor.
func (e *ProviderPipeExecutorImpl) executePipe(credentials any) map[string]any {
	// Check if in error state
	if e.err != nil {
		return nil
	}

	locationID, _ := e.config.GetParamAsString(string(ifprovider.ParameterLocationID))

	runResult, err := e.prog.Run(e.ctx, runOptions(e.ctx, locationID, e.pipeContext)...)
	e.lastResult = runResult.Vars
	if nil != err {
		e.err = err

		return nil
	}

	// A pipeline that finished without an error has run every step it holds:
	// a pipeline either finishes or returns an error.

	// Extract the result of the generator
	var result map[string]any
	result, err = e.extractTargetFunc(e.ctx, e.lastResult, e.targetKey, e.config)

	if err != nil {
		e.err = err
		return nil
	}

	if e.logging {
		log.Trace(e.ctx).
			WithMethod("executor").
			WithBody(result).
			Str("oper", e.pipeConfig.operation).
			Msgf("Got result, check if target function is set, pipe profile: %s execution", e.config.GetProfile())
	}

	if e.pipeConfig.target != nil {
		e.err = e.pipeConfig.target(
			e.ctx,
			e.pipeConfig.operation,
			e.operation,
			utils.ToProviderConfigImpl(e.config),
			e.lastResult,
			credentials,
			result,
		)

		if e.err != nil {
			return result
		}
	}

	if e.onTarget != nil {
		if replaceTarget, err := e.onTarget(e.ctx, e.pipeConfig, e.config, result); err != nil {
			e.err = err
			return nil
		} else if replaceTarget != nil {
			result = replaceTarget
		}
	}

	// Invoke the after function
	if e.pipeConfig.after != nil {
		e.err = e.pipeConfig.after(
			e.ctx,
			e.lastResult,
			e.pipeConfig.operation,
			e.operation,
			utils.ToProviderConfigImpl(e.config),
			result,
		)
	}

	return result
}

// initializePipeContext is invoked before the pipe is executed.
//
// It will invoke the `OnPrepare` callback if registered and setup the pipe context
// for execution. Some context variables will be set during the `prepareGeneratorTemplate`
// phase.
func (e *ProviderPipeExecutorImpl) initializePipeContext() *ProviderPipeExecutorImpl {
	// Check if in error state
	if e.err != nil {
		return e
	}

	if e.onPrepare != nil {
		_ = e.onPrepare(e.ctx, e.pipeConfig, e.config, e.input, e.pipeContext)
	}

	// Register the types (if omitted)
	tsm, ok := e.pipeContext[string(PipeContextNavigationKeyTypes)].(map[string]any)
	if !ok {
		tsm = map[string]any{}
		e.pipeContext[string(PipeContextNavigationKeyTypes)] = tsm
	}

	// Add the override context (if any) with only values not set
	for k, v := range e.pipeConfig.Owner.overrideContext {
		// Special handling to merge _ts registrations
		if k == string(PipeContextNavigationKeyTypes) {
			for tk, tv := range e.pipeConfig.Owner.overrideContext[k].(map[string]interface{}) {
				tsm[tk] = tv
			}
		} else {

			if _, ok := e.pipeContext[k]; !ok {
				e.pipeContext[k] = v
			}
		}
	}

	// Register marshal prototypes
	for k := range e.pipeConfig.prototypes {
		if _, ok := tsm[k]; !ok {
			tsm[k] = e.pipeConfig.prototypes[k]
		}
	}

	// Register filters (if any)
	if e.pipeConfig.filters != nil {
		if filters, ok := e.pipeConfig.filters[e.pipeConfig.operation]; ok {
			// Only update when not set
			if _, ok := e.pipeContext["_filter"]; !ok {
				e.pipeContext["_filter"] = filters
			}
		}
	}

	var c map[string]any
	if c, ok = e.pipeContext["_cfg"].(map[string]any); !ok {
		c = map[string]any{}
		e.pipeContext["_cfg"] = c
	}

	c["mappingDirection"] = e.pipeConfig.mappingDirection
	c["operation"] = e.pipeConfig.operation

	// Prepare & Evaluate the global parameters from config to the pipe context
	e.err = providerconfig.ResolvePipeContextFromGlobals(
		e.ctx, e.config, e.pipeContext, e.input, e.allowMutateGlobalParams,
	)

	return e
}

// prepareGeneratorTemplate will prepare the generator template for execution.
//
// The generator template is the one responsible for rendering the target data (if used).
// This may be dynamic or static depending on the `ifprovider.ConfigFull` settings.
//
// It will register (under _cfg) the following
// - _cfg.delayedGeneratorTemplate: If it is dynamic rendering or not
func (e *ProviderPipeExecutorImpl) prepareGeneratorTemplate() *ProviderPipeExecutorImpl {
	// Check if in error state
	if e.err != nil {
		return e
	}

	// Register any additional templates
	templates := e.config.GetParamAsStringWithDefault(
		string(ifprovider.ParameterRegisterGeneratorTemplates),
		"",
	)

	var register []string

	if templates != "" {
		all := templates == "*"
		for k := range e.config.GetGenProtoTemplates() {
			if all || textutils.FindSpaceSeparatedValue(templates, k) != -1 {
				register = append(register, k)
			}
		}

		for k := range e.config.GetGenerate() {
			if all || textutils.FindSpaceSeparatedValue(templates, k) != -1 {
				register = append(register, k)
			}
		}
	}

	var (
		delayedGeneratorTemplate bool
		generatorTemplate        string
		err                      cberror.Error
		// If no register is specified, then we will use the current operation
		registerOperationTemplate = len(register) == 0
	)

	for _, k := range register {
		if k == e.pipeConfig.operation {
			registerOperationTemplate = true
			continue
		}

		generatorTemplate, delayedGeneratorTemplate, err = providerconfig.CreateGeneratorTemplate(
			e.ctx,
			e.config,
			k,
			e.pipeConfig.operation,
			e.logging,
			e.pipeContext,
		)

		if err != nil {
			e.err = err
			return e
		}

		if delayedGeneratorTemplate {
			e.err = cberror.NewCbErrorfWithProps(e.ctx.Service(), 1, nil, map[string]any{
				cberror.PropertyProvider: e.ctx.Provider(),
			}, "Generator template '%s' is not supported for delayed rendering", k)
		}

		if generatorTemplate == "" {
			e.err = cberror.NewCbErrorfWithProps(e.ctx.Service(), 2, nil, map[string]any{
				cberror.PropertyProvider: e.ctx.Provider(),
			}, "Generator template '%s' is empty", k)
		}

		e.pipeContext[k] = generatorTemplate
	}

	c, _ := e.pipeContext["_cfg"].(map[string]any)

	if registerOperationTemplate {
		generatorTemplate, delayedGeneratorTemplate, err = providerconfig.CreateGeneratorTemplate(
			e.ctx,
			e.config,
			e.pipeConfig.operation, e.pipeConfig.operation,
			e.logging,
			e.pipeContext,
		)

		if err != nil {
			// Check if this is a cancel pipeline error (not a real error)
			if cberror.IsCancelPipelineError(err) {
				e.cancelReason = cberror.GetCancelPipelineReason(err)
				// Not a real error - pipeline should be cancelled gracefully
			} else if len(register) == 0 {
				e.err = err
				return e
			}
		}

		if generatorTemplate != "" {
			e.pipeContext[e.pipeConfig.operation] = generatorTemplate
			c["delayedGeneratorTemplate"] = delayedGeneratorTemplate
			c["generatorTemplates"] = []string{e.pipeConfig.operation}
		}
	} else {
		c["generatorTemplates"] = register
	}

	mode := e.config.GetParamAsStringWithDefault(
		string(ifprovider.ParameterGeneratorTemplateMode),
		"",
	)

	if mode == "" {
		// Default to fail
		mode = "fail"
	}

	var terr error

	pipeTemplateText := e.config.GetPipes()[e.pipeConfig.operation]
	if pipeTemplateText == "" {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(),
			cberror.ErrorProviderUnableToSetupTemplate,
			nil,
			"Failed to find pipe template for operation %s (check your template)",
			e.pipeConfig.operation,
		)

		return e
	}

	e.goTemplate, terr = providerconfig.ResolveTemplate(
		e.config,
		e.pipeConfig.operation, /*name*/
		e.pipeConfig.operation, /*genref*/
		mode,
		e.pipeConfig.mappingDirection,
		delayedGeneratorTemplate,
		template.FuncMap{},
		e.pipeContext,
	).Parse(pipeTemplateText)

	if nil != terr {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(),
			cberror.ErrorProviderUnableToSetupTemplate,
			terr,
			"Failed to setup template for config %#v, operation %s",
			e.config,
			e.pipeConfig.operation,
		)
	}

	return e
}

// resolveOperation will resolve the operation by evaluating all parameters as well as the operation itself.
// If successfully it will set the `ProviderPipeExecutorImpl.resolvedOperation` to the resolved operation.
func (e *ProviderPipeExecutorImpl) resolveOperation() *ProviderPipeExecutorImpl {
	// Check if in error state
	if e.err != nil {
		return e
	}

	// Resolve the operation
	var err cberror.Error

	e.operation, err = providerconfig.ResolveOperation(
		e.ctx,
		e.config,
		e.pipeConfig.operation,
		e.pipeContext,
		e.input,
	)

	if err != nil {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(), cberror.ErrorProviderUnableExecutePipeline, err,
			"Failed to resolve operation: %s, error: %s", e.pipeConfig.operation, err.Error(),
		)
	}

	return e
}
