package utils

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel"
)

func ToEffectServiceLevel(val any) (servicemodel.TeosEffectServiceLevels, error) {
	switch t := val.(type) {
	case eqmodel.CbDataPoint:
		return ToEffectServiceLevel(t.GetValue())
	case string:
		return servicemodel.ToServiceLevelFromString(t), nil
	case int:
		return servicemodel.ToServiceLevelFromKW(t), nil
	case int64:
		return servicemodel.ToServiceLevelFromKW(int(t)), nil
	case float64:
		return servicemodel.ToServiceLevelFromKW(int(t)), nil
	case int32:
		return servicemodel.ToServiceLevelFromKW(int(t)), nil
	case float32:
		return servicemodel.ToServiceLevelFromKW(int(t)), nil
	default:
		return "", fmt.Errorf("invalid service %v", val)
	}

}
