package providerconfig

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

func TestSingleSelectFilterNoMID(t *testing.T) {
	ctx := newCtx(t)

	processFilter := map[string][]*providermodel.FilterItemImpl{
		"MID": {
			{ID: "IDT", Select: "[:-v . map.IDT_O2[1-2]_C1:]"},
		},
	}

	var pipeCtx = map[string]interface{}{
		"map": map[string]interface{}{
			"IDT_O21_C1": "idt_o21_c1",
			"IDT_O22_C1": "idt_o22_c1",
			"IDT_O23_C1": "idt_o23_c1",
			"IDT_O1":     "idt_o1",
		},
	}

	resolver, err := NewFilterResolver(ctx, processFilter)
	require.NoError(t, err)

	result, err := resolver.ProcessFilter(ctx, pipeCtx)
	require.NoError(t, err)

	assert.Contains(t, result, "MID")
	assert.NotContains(t, result, "map")
	assert.Contains(t, result["MID"], "IDT_O21_C1")
	assert.Contains(t, result["MID"], "IDT_O22_C1")
	assert.NotContains(t, result["MID"], "IDT_O23_C1")
	assert.NotContains(t, result["MID"], "IDT_O1")
}

func TestSingleSelectFilterWithMID(t *testing.T) {
	ctx := newCtx(t)

	processFilter := map[string][]*providermodel.FilterItemImpl{
		"MID": {
			{ID: "IDT", Select: "[:-v . map.IDT_O2[1-2]_C1:]"},
		},
	}

	var pipeCtx = map[string]interface{}{
		"MID": "IDT_O26_C1 IDT_O26 OFFODT",
		"map": map[string]interface{}{
			"IDT_O21_C1": "idt_o21_c1",
			"IDT_O22_C1": "idt_o22_c1",
			"IDT_O23_C1": "idt_o23_c1",
			"IDT_O1":     "idt_o1",
		},
	}

	resolver, err := NewFilterResolver(ctx, processFilter)
	require.NoError(t, err)

	result, err := resolver.ProcessFilter(ctx, pipeCtx)
	require.NoError(t, err)

	assert.Contains(t, result, "MID")
	assert.NotContains(t, result, "map")
	assert.Contains(t, result["MID"], "IDT_O21_C1")
	assert.Contains(t, result["MID"], "IDT_O22_C1")
	assert.Contains(t, result["MID"], "OFFODT")
	assert.NotContains(t, result["MID"], "IDT_O23_C1")
	assert.NotContains(t, result["MID"], "IDT_O1")
	assert.NotContains(t, result["MID"], "IDT_O26")
	assert.NotContains(t, result["MID"], "IDT_O26_C1")
}

func TestEndExpressionFilterWithMID(t *testing.T) {
	ctx := newCtx(t)

	processFilter := map[string][]*providermodel.FilterItemImpl{
		"MID": {
			{ID: "IDT", End: "[ceil(CNT_IDT,24)]", Circuit: 1},
		},
	}

	var pipeCtx = map[string]interface{}{
		"CNT_IDT": 26,
		"MID":     "IDT_O26_C1 IDT_O26 OFFODT",
		"map": map[string]interface{}{
			"IDT_O21_C1": "idt_o21_c1",
			"IDT_O22_C1": "idt_o22_c1",
			"IDT_O23_C1": "idt_o23_c1",
			"IDT_O24_C1": "idt_o24_c1",
			"IDT_O25_C1": "idt_o25_c1",
			"IDT_O26_C1": "idt_o26_c1",
			"IDT_O1":     "idt_o1",
		},
	}

	resolver, err := NewFilterResolver(ctx, processFilter)
	require.NoError(t, err)

	result, err := resolver.ProcessFilter(ctx, pipeCtx)
	require.NoError(t, err)

	assert.Contains(t, result, "MID")
	assert.NotContains(t, result, "map")
	assert.Contains(t, result["MID"], "IDT_O21_C1")
	assert.Contains(t, result["MID"], "IDT_O22_C1")
	assert.Contains(t, result["MID"], "IDT_O23_C1")
	assert.Contains(t, result["MID"], "IDT_O24_C1")
	assert.Contains(t, result["MID"], "OFFODT")
	assert.NotContains(t, result["MID"], "IDT_O25_C1")
	assert.NotContains(t, result["MID"], "IDT_O26_C1")
	assert.NotContains(t, result["MID"], "IDT_O1")
	assert.NotContains(t, result["MID"], "IDT_O26")
}

func TestStartAndEndExpressionFilterWithMID(t *testing.T) {
	ctx := newCtx(t)

	processFilter := map[string][]*providermodel.FilterItemImpl{
		"MID": {
			{
				ID:      "IDT",
				Start:   "(DUC_NO-1)*100",
				End:     "[ceil(CNT_IDT,24)+((DUC_NO-1)*100)]",
				Circuit: 1,
			},
		},
	}

	var pipeCtx = map[string]interface{}{
		"CNT_IDT": 26,
		"DUC_NO":  2,
		"MID":     "IDT_O26_C1 IDT_O26 OFFODT",
		"map": map[string]interface{}{
			"IDT_O121_C1": "idt_o121_c1",
			"IDT_O122_C1": "idt_o122_c1",
			"IDT_O123_C1": "idt_o123_c1",
			"IDT_O124_C1": "idt_o124_c1",
			"IDT_O125_C1": "idt_o125_c1",
			"IDT_O126_C1": "idt_o126_c1",
			"IDT_O1":      "idt_o1",
		},
	}

	resolver, err := NewFilterResolver(ctx, processFilter)
	require.NoError(t, err)

	result, err := resolver.ProcessFilter(ctx, pipeCtx)
	require.NoError(t, err)

	assert.Contains(t, result, "MID")
	assert.NotContains(t, result, "map")
	assert.Contains(t, result["MID"], "IDT_O121_C1")
	assert.Contains(t, result["MID"], "IDT_O122_C1")
	assert.Contains(t, result["MID"], "IDT_O123_C1")
	assert.Contains(t, result["MID"], "IDT_O124_C1")
	assert.Contains(t, result["MID"], "OFFODT")
	assert.NotContains(t, result["MID"], "IDT_O125_C1")
	assert.NotContains(t, result["MID"], "IDT_O126_C1")
	assert.NotContains(t, result["MID"], "IDT_O126")
}

func BenchmarkStartAndEndExpressionFilterWithMID(t *testing.B) {
	ctx := newCtx(t)

	processFilter := map[string][]*providermodel.FilterItemImpl{
		"MID": {
			{
				ID:      "IDT",
				Start:   "(DUC_NO-1)*100",
				End:     "[ceil(CNT_IDT,24)+((DUC_NO-1)*100)]",
				Circuit: 1,
			},
		},
	}

	var pipeCtx = map[string]interface{}{
		"CNT_IDT": 26,
		"DUC_NO":  2,
		"MID":     "IDT_O26_C1 IDT_O26 OFFODT",
		"map": map[string]interface{}{
			"IDT_O121_C1": "idt_o121_c1",
			"IDT_O122_C1": "idt_o122_c1",
			"IDT_O123_C1": "idt_o123_c1",
			"IDT_O124_C1": "idt_o124_c1",
			"IDT_O125_C1": "idt_o125_c1",
			"IDT_O126_C1": "idt_o126_c1",
			"IDT_O1":      "idt_o1",
		},
	}

	resolver, err := NewFilterResolver(ctx, processFilter)
	require.NoError(t, err)

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		_, _ = resolver.ProcessFilter(ctx, pipeCtx)
	}
}
