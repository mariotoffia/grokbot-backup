package esv

import (
	"testing"

	"github.com/aws/aws-sdk-go-v2/aws"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/rtc"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"

	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cblambda"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// TestSourceMappingNoMIDIncludesAll tests a profile that uses `"MMO": "source"`. It does
// not include the MID and thus it should include all the data points.
func TestSourceMappingNoMIDIncludesAll(t *testing.T) {
	// ------------ CONFIG ------------

	// This config *REQUIRES* that LID, PID, and TID is present in the event!
	// TIP: This allows for one config for all LID and still address PID, TID
	config := `{ 
		"profile": "generic-source-mapping", "prms": {
				"LOG": "off", "MID": "", "CRD": "" 
			}
		}`

	// ------------- SOURCE -------------
	sourceFunc := func(e *rtc.RtcServiceActuationItem) providercontext.SourceNoArgFunction {
		return func() (map[string]any, cberror.Error) {
			//
			dp := map[string]any{}
			source := make(map[string]any, len(e.Dp))
			globals := map[string]any{}

			dp[string(ifprovider.WellKnownSourceTypeSource)] = source
			dp[string(ifprovider.WellKnownSourceTypeSrc)] = e
			dp[string(ifprovider.WellKnownSourceTypeGlobals)] = globals

			for k, v := range e.Dp {
				source[k] = v.ToDataPoint(
					k,  /*partition*/
					"", /*err*/
					nil,
					*coremodel.NewTime32Now(),
				)
			}

			if e.Pid != nil {
				globals["PID"] = *e.Pid
			}

			if e.Tid != nil {
				globals["TID"] = *e.Tid
			}

			globals["BID"] = e.Lid // BID until the old id is cleansed out of the system (then LID)!

			return dp, nil
		}
	}

	// ------------- TARGET -------------

	// Frame set in target func to be asserted later on
	var toTransmit *rtc.RtcChannelFrame

	targetFunc := func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		// Extract the target
		toTransmit = providerutils.ExtractTarget[rtc.RtcChannelFrame](target)
		return nil // no error
	}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				// NOTE: We're not setting source and target since we're doing it on the
				//       provider context instead. This can be done either way you want :).
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", &rtc.RtcChannelFrame{}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder().
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline)

	// dispatcher is the one receiving the http request and applies a user config and runs
	// the provider pipeline.
	h := cblambda.JSONWithRoute("/path/to/endpoint", ctx,
		func(ctx ifcore.CbContext, event []rtc.RtcServiceActuationItem) (any, error) {
			for _, e := range event {
				// Execute Event in Provider Pipe
				res, err := builder.ProviderContext().Execute(
					ctx, "" /*locationID*/, config, e, nil, /*input*/
					&providercontext.OptExecute{
						NoArgSource: sourceFunc(&e),
						Target:      targetFunc,
					},
				)

				if res.HasError() {
					return nil, res.GetCompositeError()
				}

				if err != nil {
					return nil, err
				}
			}

			return nil, nil
		},
	)

	builder.UseHandler(h)

	pctx := builder.Build()

	// Invoke the service
	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(
		[]rtc.RtcServiceActuationItem{
			{
				Lid: "Måssmyren 18",
				Pid: aws.String("myPlantID"),
				Tid: aws.String("myTenantID"),
				Dp: map[string]rtc.RtcValue{
					"OFFODT":    rtc.Float32AsRtcValue(aws.Float32(2.72)),
					"IDT_O1":    rtc.Float32AsRtcValue(aws.Float32(22.15)),
					"custom_id": rtc.StringAsRtcValue(aws.String("custom value")),
				},
			},
		},
	))

	// Assert the result
	require.NoError(t, invokeError)
	require.Nil(t, result)

	require.NotNil(t, toTransmit, "The target function was not invoked")
	require.Equal(t, 1, len(toTransmit.Frames))
	require.NotNil(t, toTransmit.Frames[0].SimpleActuationFrame)

	assert.Equal(t, "Måssmyren 18", toTransmit.Frames[0].SimpleActuationFrame.Lid)
	assert.Equal(t, "myPlantID", *toTransmit.Frames[0].SimpleActuationFrame.Pid)
	assert.Equal(t, "myTenantID", *toTransmit.Frames[0].SimpleActuationFrame.Tid)

	assert.Equal(t, float32(2.72), *toTransmit.Frames[0].SimpleActuationFrame.Dp["OFFODT"].Float32)
	assert.Equal(
		t,
		float32(22.15),
		*toTransmit.Frames[0].SimpleActuationFrame.Dp["static-mapped-idt01"].Float32,
	)
	assert.Equal(
		t,
		"custom value",
		*toTransmit.Frames[0].SimpleActuationFrame.Dp["custom_id"].String,
	)
}
