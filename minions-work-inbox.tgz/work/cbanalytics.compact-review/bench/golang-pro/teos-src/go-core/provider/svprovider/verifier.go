package svprovider

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerverify"
)

func (sv *SVPlugin) verifyConfigStatic(
	ctx ifcore.CbContext,
	evt *cbevent.SensorValueInboundEvent,
) cbevent.ProviderResultEvent {
	// Get the provider config file system provider
	verifier := providerverify.NewStaticVerifier(ctx)
	providerConfigFS, ok := sv.plugin.(provider.ProviderConfigurationFileSystemProvider)

	if !ok {
		return verifier.CreateError(
			ctx.Service(), cberror.ErrorProviderUnsupportedInterface, nil,
			"Plugin does not support PipelineAwareProvider interface",
		)
	}

	fsLoader := providerconfig.NewFsProviderConfigLoader(
		providerConfigFS.GetProviderConfigurationFileSystemObject(),
	)

	repository := providerconfig.NewProviderConfigRepository(ctx, fsLoader)

	// Merge provider with provider template if present
	items, err := providerconfig.ReadConfig(ctx, evt.ToConfigString(0))

	if err != nil {
		return verifier.CreateError(
			ctx.Service(), cberror.ErrorProviderUnableToReadCfg, nil, "",
		)
	}

	userConfig, err := providerconfig.CreateConfig(items...)

	if err != nil {
		return verifier.CreateError(
			ctx.Service(), cberror.ErrorProviderUnableToCreateCfg, nil, "",
		)
	}

	merged, err := repository.Merge(ctx, userConfig.Profile, userConfig)

	if err != nil {
		return verifier.CreateError(ctx.Service(), err.Code(), nil, "%s", err.Error())
	}

	if merged == nil {
		return verifier.CreateError(
			ctx.Service(),
			cberror.ErrorProviderUnableToMergeProfile,
			nil,
			"Failed to merge profile %s with config %v, unable to match with template",
			userConfig.Profile,
			userConfig,
		)
	}

	if sv.pluginCaps.BooleanByName(provider.CapsProviderVerifyConfigEx, false) {
		if pbx, ok := sv.plugin.(providerverify.VerifyConfigStaticEx); ok {
			verifyFunc := pbx.VerifyConfigEx()

			if errors := verifyFunc(userConfig); err != nil {
				resultEvent := cbevent.ProviderResultEvent{
					Status: []string{},
					Result: []any{},
				}

				for _, err := range errors {
					verifier.AppendError(
						&resultEvent, ctx.Service(), err.Code(), nil, "%s", err.Error(),
					)
				}

				return resultEvent
			}
		} else {
			verifier.CreateError(
				ctx.Service(), cberror.ErrorProviderImplementationMissing, nil,
				"VerifyConfigStaticEx interface is not implemented",
			)
		}
	}

	if sv.pluginCaps.BooleanByName(provider.CapsProviderVerifyConfig, false) {
		if pbx, ok := sv.plugin.(providerverify.VerifyConfigStatic); ok {
			err := verifier.Setup(ctx, pbx.GetVerifyConfig())

			if err != nil {
				return verifier.CreateError(
					ctx.Service(), err.Code(), nil, "%s", err.Error(),
				)
			}

			return verifier.VerifyConfig(merged)
		} else {
			return verifier.CreateError(
				ctx.Service(), cberror.ErrorProviderImplementationMissing, nil,
				"VerifyConfigStatic interface is not implemented",
			)
		}
	}

	return verifier.CreateError(
		ctx.Service(),
		cberror.ErrorProviderCapabilityMissing,
		nil,
		"Neither CapsProviderVerifyConfigEx or CapsProviderVerifyConfig capability set for static verification",
	)

}
