package sv

import (
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

type RemoteAttributes struct {
	Label string `json:"label"`
}

type RemoteDataValue struct {
	Value     string    `json:"value"`
	TimeStamp time.Time `json:"timestamp"`
}

type RemoteDataPoint struct {
	ID         string            `json:"id"`
	Attributes *RemoteAttributes `json:"attributes"`
	PointValue *RemoteDataValue  `json:"pointValue,omitempty"`
}

func (dp *RemoteDataPoint) GetID() string {
	return dp.ID
}

func (dp *RemoteDataPoint) GetValue() any {
	if dp.PointValue != nil {
		return dp.PointValue.Value
	}
	return nil
}

func (dp *RemoteDataPoint) GetTimeStamp() coremodel.CbTime32 {
	if dp.PointValue != nil {
		return *coremodel.NewTime32FromTime(dp.PointValue.TimeStamp)
	}
	return *coremodel.NewZeroTime32()
}

func (dp *RemoteDataPoint) GetError() cberror.Error {
	return nil
}

func (dp *RemoteDataPoint) GetPartition() string {
	return ""
}

func (dp *RemoteDataPoint) HasTimeStamp() bool {
	return dp.PointValue != nil && !dp.PointValue.TimeStamp.IsZero()
}
