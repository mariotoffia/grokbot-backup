package tests

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

// =============================================================================
// WILDCARD PATTERN TESTS WITH EMPTY SOURCE DATA
// =============================================================================
//
// These tests verify the behavior when:
//   - MID contains a wildcard pattern (e.g., "HCT**")
//   - MMO="source" is set (delayed mapping expansion)
//   - Source returns EMPTY data (no sensors found)
//
// The unexpanded wildcard pattern ends up in the WantedSensors list.
// The OPT parameter determines whether this is treated as mandatory or optional.
//
// =============================================================================

// TestWildcardMappingEmptySourceDataClearsWildcards verifies that when:
//   - MID="HCT**" with MMO="source"
//   - Source returns EMPTY data (empty map, but key exists)
//
// The sourceMap function clears the wildcards and MID becomes empty,
// resulting in NO wanted sensors and therefore NO missing datapoint error.
//
// Flow:
// ─────────────────────────────────────────────────────────────────────────────
//
//	Config: MID="HCT**", MMO="source", map={"HCT**":"{{ID}}"}, OPT=<not set>
//	Source: returns {} (empty map, but "source" key exists)
//	Result: sourceMap clears wildcard (no matching keys)
//	        MID is filtered to empty
//	        ExtractSensors() → []
//	        → Pipeline succeeds: no wanted sensors = nothing missing
//
// ─────────────────────────────────────────────────────────────────────────────
func TestWildcardMappingEmptySourceDataClearsWildcards(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
						// Return EMPTY source data - wildcard will be cleared
						return map[string]eqmodel.CbDataPoint{}, nil, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "wildcard-no-opt"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))

	// With empty source, sourceMap clears wildcards and MID becomes empty
	// No wanted sensors = no missing datapoints = no error
	assert.NoError(t, result[0].Error,
		"Empty source with MMO='source' clears wildcards, resulting in no wanted sensors")

	t.Log("VERIFIED: Empty source data with MMO='source' clears wildcards - no error")
}

// TestWildcardMappingEmptySourceWithOPTAlsoSucceeds verifies that when:
//   - MID="HCT**" with MMO="source"
//   - Source returns EMPTY data (empty map)
//   - OPT="**" is set (all sensors optional)
//
// Same as TestWildcardMappingEmptySourceDataClearsWildcards - wildcards are
// cleared, no wanted sensors, so OPT is irrelevant in this case.
//
// Flow:
// ─────────────────────────────────────────────────────────────────────────────
//
//	Config: MID="HCT**", MMO="source", map={"HCT**":"{{ID}}"}, OPT="**"
//	Source: returns {} (empty map)
//	Result: sourceMap clears wildcard (no matching keys)
//	        MID is filtered to empty
//	        ExtractSensors() → []
//	        → Pipeline succeeds: no wanted sensors = nothing missing
//
// ─────────────────────────────────────────────────────────────────────────────
func TestWildcardMappingEmptySourceWithOPTAlsoSucceeds(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
						// Return EMPTY source data - wildcard will be cleared
						return map[string]eqmodel.CbDataPoint{}, nil, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "wildcard-with-opt"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))

	// With OPT="**" and empty source, same as without OPT - wildcards cleared
	assert.NoError(t, result[0].Error,
		"Empty source with MMO='source' and OPT='**' should NOT cause pipeline error")

	t.Log("VERIFIED: Empty source with MMO='source' and OPT='**' succeeds (wildcards cleared)")
}

// TestWildcardMappingStrictModeNoSourceWithoutOPT verifies that when:
//   - map={"HCT**": "remote-hct"} with MMO="strict" (default)
//   - Source returns empty data
//   - OPT is NOT set
//
// In strict mode, the mapping is NOT processed dynamically. The wildcard "HCT**"
// remains in the map and becomes a wanted sensor. Since no data matches, it's
// reported as a MANDATORY missing sensor in the MissingDataPointReport.
//
// NOTE: The pipeline itself does NOT fail - it logs the missing datapoints but
// continues. The difference from OPT="**" is that the sensor is marked as
// mandatory (not optional) in the report.
//
// Expected log output (MissingDataPointReport):
//
//	"mc":1 (1 mandatory missing)
//	"wanted":{"HCT**":{"rid":"remote-hct"}} (no "opt":true)
//
// ─────────────────────────────────────────────────────────────────────────────
func TestWildcardMappingStrictModeNoSourceWithoutOPT(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Return EMPTY data - wildcard won't be resolved
						return []eqmodel.CbDataPoint{}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "wildcard-strict-no-opt"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))

	// Pipeline does NOT fail - it logs MissingDataPointReport but continues.
	// The difference is in the report: "HCT**" is marked as MANDATORY (not optional).
	// Check logs for: "mc":1, "wanted":{"HCT**":{"rid":"remote-hct"}} (no "opt":true)
	assert.NoError(t, result[0].Error,
		"Pipeline completes but logs MissingDataPointReport with mandatory sensor 'HCT**'")

	t.Log("VERIFIED: Strict mode with unexpanded wildcard 'HCT**' and NO OPT logs mandatory missing")
	t.Log("Check logs for MissingDataPointReport with 'mc':1 and 'HCT**' WITHOUT 'opt':true")
}

// TestWildcardMappingStrictModeNoSourceWithOPT verifies that when:
//   - map={"HCT**": "remote-hct"} with MMO="strict" (default)
//   - Source returns empty data
//   - OPT="**" is set (all sensors optional)
//
// In strict mode, the wildcard "HCT**" remains in the map. With OPT="**",
// the glob pattern matches the literal string "HCT**", marking it as OPTIONAL.
//
// The key difference from the test without OPT:
//   - WITHOUT OPT: "mc":1 (mandatory missing), no "opt":true in report
//   - WITH OPT:    "mc":0, "omc":1 (optional missing), "opt":true in report
//
// Expected log output (MissingDataPointReport):
//
//	"mc":0, "omc":1 (0 mandatory, 1 optional missing)
//	"wanted":{"HCT**":{"rid":"remote-hct","opt":true}} (HAS "opt":true)
//
// ─────────────────────────────────────────────────────────────────────────────
func TestWildcardMappingStrictModeNoSourceWithOPT(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Return EMPTY data - wildcard won't be resolved
						return []eqmodel.CbDataPoint{}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "wildcard-strict-with-opt"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))

	// Pipeline succeeds - logs MissingDataPointReport with "HCT**" marked OPTIONAL.
	// Key difference: "mc":0, "omc":1, and "opt":true in wanted/missing entries.
	assert.NoError(t, result[0].Error,
		"Pipeline completes with MissingDataPointReport showing 'HCT**' as optional")

	t.Log("VERIFIED: Strict mode with unexpanded wildcard 'HCT**' and OPT='**' logs optional missing")
	t.Log("Check logs for MissingDataPointReport with 'mc':0, 'omc':1 and 'HCT**' WITH 'opt':true")
}
