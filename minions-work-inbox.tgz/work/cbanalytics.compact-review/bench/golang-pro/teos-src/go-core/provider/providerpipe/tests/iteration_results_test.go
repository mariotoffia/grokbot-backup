package tests

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestIterationExecutionResults_HasResults_True(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Result: map[string]any{"key": "value"}},
	}

	assert.True(t, results.HasResults())
}

func TestIterationExecutionResults_HasResults_False(t *testing.T) {
	var results providerpipe.IterationExecutionResults
	assert.False(t, results.HasResults())

	results = providerpipe.IterationExecutionResults{}
	assert.False(t, results.HasResults())
}

func TestIterationExecutionResults_HasError_True(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Result: map[string]any{"key": "value"}},
		{Error: cberror.NewCbErrorf("test", 500, nil, "error")},
	}

	assert.True(t, results.HasError())
}

func TestIterationExecutionResults_HasError_False(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Result: map[string]any{"key": "value"}},
		{Result: map[string]any{"key2": "value2"}},
	}

	assert.False(t, results.HasError())
}

func TestIterationExecutionResults_HasError_Empty(t *testing.T) {
	var results providerpipe.IterationExecutionResults
	assert.False(t, results.HasError())
}

func TestIterationExecutionResults_ForOperation(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Operation: locationmodel.ProviderOperationSensorValueIn},
		{Operation: locationmodel.ProviderOperationDataPointDiscovery},
		{Operation: locationmodel.ProviderOperationSensorValueIn},
	}

	filtered := results.ForOperation(locationmodel.ProviderOperationSensorValueIn)

	assert.Len(t, filtered, 2)
	for _, r := range filtered {
		assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, r.Operation)
	}
}

func TestIterationExecutionResults_ForOperation_NoMatch(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Operation: locationmodel.ProviderOperationSensorValueIn},
	}

	filtered := results.ForOperation(locationmodel.ProviderOperationDataPointDiscovery)

	assert.Len(t, filtered, 0)
}

func TestIterationExecutionResults_GetErrors(t *testing.T) {
	err1 := cberror.NewCbErrorf("test", 500, nil, "error 1")
	err2 := cberror.NewCbErrorf("test", 400, nil, "error 2")

	results := providerpipe.IterationExecutionResults{
		{Error: err1},
		{Result: map[string]any{"key": "value"}},
		{Error: err2},
	}

	errors := results.GetErrors()

	require.Len(t, errors, 2)
	assert.Contains(t, errors[0].Error(), "error 1")
	assert.Contains(t, errors[1].Error(), "error 2")
}

func TestIterationExecutionResults_GetErrors_NoErrors(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Result: map[string]any{"key": "value"}},
	}

	errors := results.GetErrors()

	assert.Nil(t, errors)
}

func TestIterationExecutionResults_GetCompositeError_NoErrors(t *testing.T) {
	results := providerpipe.IterationExecutionResults{
		{Result: map[string]any{"key": "value"}},
	}

	err := results.GetCompositeError()

	assert.Nil(t, err)
}

func TestIterationExecutionResults_GetCompositeError_SingleError(t *testing.T) {
	singleErr := cberror.NewCbErrorf("test", 500, nil, "single error")

	results := providerpipe.IterationExecutionResults{
		{Error: singleErr},
	}

	err := results.GetCompositeError()

	require.NotNil(t, err)
	assert.Contains(t, err.Error(), "single error")
}

func TestIterationExecutionResults_GetCompositeError_MultipleErrors(t *testing.T) {
	err1 := cberror.NewCbErrorf("test", 500, nil, "error 1")
	err2 := cberror.NewCbErrorf("test", 400, nil, "error 2")

	results := providerpipe.IterationExecutionResults{
		{Error: err1},
		{Error: err2},
	}

	err := results.GetCompositeError()

	require.NotNil(t, err)
	// Composite error should be returned for multiple errors
}
