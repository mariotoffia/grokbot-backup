package providercontext

import (
	"runtime"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cblambda"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cbsqs"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
)

// DefaultSQSDispatcherProviderEvent setup a SQS dispatcher for `*ProviderEvent` events.
// The dispatcher runs with parallelism of `runtime.NumCPU() * 64` and batch size of 1.
//
// Default timeout is _120_ seconds.
func DefaultSQSDispatcherProviderEvent(
	path string,
	builder *ProviderContextBuilderImpl,
) ProviderHandlerFunc {
	return func(pc ProviderContext) dispruntime.HandlerInvoker {
		return cbsqs.JSONWithRoute(
			path,
			pc.Context(),
			func(ctx ifcore.CbContext, event *cbevent.ProviderEvent) error {
				_, err := pc.OnProviderEvent(ctx, event, nil)
				return err
			},
			cbsqs.WithParallelism(runtime.NumCPU()*64),
			cbsqs.WithTimeout(120*time.Second),
		)
	}
}

// DefaultNativeDispatcherProviderEvent setup a native dispatcher for `*ProviderEvent` events.
func DefaultNativeDispatcherProviderEvent(
	path string,
	builder *ProviderContextBuilderImpl,
) ProviderHandlerFunc {
	return func(pc ProviderContext) dispruntime.HandlerInvoker {
		return cblambda.JSONWithRoute(
			path,
			pc.Context(),
			func(ctx ifcore.CbContext, event *cbevent.ProviderEvent) (*cbevent.ProviderResultEvent, error) {
				return pc.OnProviderEvent(ctx, event, nil)
			},
		)
	}
}
