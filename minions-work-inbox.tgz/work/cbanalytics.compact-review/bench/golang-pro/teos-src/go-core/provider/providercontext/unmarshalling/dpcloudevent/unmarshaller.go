package dpcloudevent

import (
	"encoding/json"
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// DataPointCloudEventImpl is a struct that mimics the `cbevent.DataPointCloudEventImpl` struct
// but instead of the interface uses the `*eqmodel.CbDataPointImpl` struct and implements the
// `TeosCustomJSONUnmarshal` interface to allow a unmarshal from `dpcloudevent.DataPointCloudEventImpl`
// to `cbevent.DataPointCloudEventImpl`.
type DataPointCloudEventImpl struct {
	cbevent.CloudEventImpl
	Data MyDataPointData `json:"detail,omitempty"`
}

type MyDataPointData struct {
	cbevent.DataPointData
	// Data is overridden to use the `*eqmodel.CbDataPointImpl` struct instead of the interface.
	Data map[string][]*eqmodel.CbDataPointImpl `json:"dp,omitempty"`
}

// GetData overrides `DataPointCloudEventImpl.GetData` to return the shadowed Data field
// in `dpcloudevent.DataPointCloudEventImpl`
func (e *DataPointCloudEventImpl) GetData() any {
	return e.Data
}

// UnmarshalTeosJSON implements the `TeosCustomJSONUnmarshal` interface that allows
// switching the type to `cbevent.DataPointCloudEventImpl` from `dpcloudevent.DataPointCloudEventImpl`
func (e *DataPointCloudEventImpl) UnmarshalTeosJSON(data []byte) (any, error) {
	var tempEvent DataPointCloudEventImpl
	if err := json.Unmarshal(data, &tempEvent); err != nil {
		return nil, fmt.Errorf(
			"failed to unmarshal into dpcloudevent.DataPointCloudEventImpl: %w",
			err,
		)
	}

	convertedEvent := &cbevent.DataPointCloudEventImpl{
		CloudEventImpl: tempEvent.CloudEventImpl,
		Data: cbevent.DataPointData{
			LocationID: tempEvent.Data.LocationID,
			OwnerID:    tempEvent.Data.OwnerID,
			Provider:   tempEvent.Data.Provider,
			TimeZone:   tempEvent.Data.TimeZone,
			Data:       make(map[string][]eqmodel.CbDataPoint),
		},
	}

	for key, points := range tempEvent.Data.Data {
		for _, point := range points {
			convertedEvent.Data.Data[key] = append(convertedEvent.Data.Data[key], point)
		}
	}

	// Return the converted event
	return convertedEvent, nil
}
