//go:build integration

package s3sqs_test

import (
	"fmt"
	"testing"
	"testing/fstest"
	"time"

	"github.com/ahmetb/go-linq/v3"
	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	teosctx "github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/managers/mgrstore/awamgrstore"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext/dispatcher/s3sqs"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestITLoadProperDataSingleFileSingleS3Event(t *testing.T) {
	if testing.Short() {
		t.Skip(
			"Skipping integration test TestITLoadProperDataSingleFileSingleS3Event paging test in short mode",
		)
	}

	testenv.Use(t, testenv.EnvUsingManualAWSResources)

	// Target Struct
	type targetItem struct {
		ID        string    `json:"n"`
		TimeStamp time.Time `json:"ts"`
		Value     any       `json:"v"`
	}
	type targetStruct struct {
		List []targetItem `json:"items"`
	}

	// ------------ CONFIG ------------
	lid := "Måssmyren 18"

	providerConfig := fstest.MapFS{
		"provider-config/teos/source.json": &fstest.MapFile{
			Data: srcProfile,
			Mode: 0666,
		},
	}

	userConfigLoader := func(ctx ifcore.CbContext, locationID string) (string, cberror.Error) {
		return fmt.Sprintf(`{
				"profile": "teos/source",
				"prms": {
					"BID": "%s", 
					"REP": "example.com",
					"CRD": "/provider/test/massmyren-18",
					"TID": "[TID]",
					"MXP": "[MXP]"
				}
			}`, lid), nil
	}

	// ------------- TARGET ---------------
	var trg *targetStruct

	target := func(
		ctx ifcore.CbContext,
		operation string,
		eop *providermodel.Operation, pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		//
		trg = providerutils.ExtractTarget[targetStruct](target)

		if nil == trg {
			return cberror.NewCbErrorf(ctx.Service(), 500, nil, "no target found")
		}

		return nil
	}

	// Root Service Context
	ctx, cbErr := teosctx.NewContextWithDefaultOptions("esv", "test", cbenv.DevLocal)
	require.NoError(t, cbErr)
	t.Cleanup(ctx.Close)

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionRightAssign).
				WithMarshalPrototype("esv", &targetStruct{}).
				UseTarget(target).
				UseCredentialsFunction(
					providerpipe.NoopObtainCredentials(
						"user", "pass", "apiKey", "example.com", nil, /*token*/
					)).
				AsOperation(string(locationmodel.ProviderOperationSensorValueOut))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder()

	builder.
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueOut).
		UseLoaders(userConfigLoader).
		UsePipeline(pipeline).
		WithProviderConfiguration(providerConfig).
		AllowGlobalParameterMutation().
		UserConfigUsage(providercontext.ProviderUserConfigUsageLoaderPerLocationID).
		UseProviderDispatcher(
			s3sqs.DispatchSQSwithS3Events(
				fmt.Sprintf("/provider/westbound/%s/%s", ctx.Provider(), ctx.Service()),
				builder, "teos/source",
				s3sqs.S3JsonLoader,
			),
		)

	pctx := builder.Build()

	// Create bucket and put a JSON file in it
	mgr := awamgrstore.NewStorageManagerS3(ctx).
		UseBucket(utils.RandomPostfix("unittest")).
		CreatePrivateBucket()
	require.NoError(t, mgr.Error())

	t.Cleanup(func() {
		if err := mgr.ClearError().DeleteBucket(true /*force*/).Error(); err != nil {
			t.Errorf("cleanup: delete bucket %s: %v", mgr.Bucket(), err)
		}
	})

	// Add single file to bucket to use for testing
	_ = s3sqs.AddSamplesToBucket(
		t, mgr, "path/to/data.json",
		s3sqs.Itm(lid, "IDT_O1", 23.7),
		s3sqs.Itm(lid, "ODT", -2),
		s3sqs.Itm(lid, "HUM_O2", 24.7),
		s3sqs.Itm(lid, "HUM_O14", 25.7),
	)

	// Invoke the service
	result, invokeError := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(events.SQSEvent{
		Records: []events.SQSMessage{
			{
				MessageId:   "1",
				EventSource: "aws:sqs",
				Body: string(jsonutils.ToJSON(
					events.S3Event{Records: s3sqs.Recs(mgr.Bucket(), "path/to/data.json")})),
			},
		},
	}))

	// Assert the result
	require.NoError(t, invokeError)
	require.Nil(t, result)
	require.NotNil(t, trg)
	require.Len(t, trg.List, 4)

	odtAny := linq.From(trg.List).Where(func(i interface{}) bool {
		return i.(targetItem).ID == "ODT"
	}).First()

	idtAny := linq.From(trg.List).Where(func(i interface{}) bool {
		return i.(targetItem).ID == "2;indoor_temperature"
	}).First()

	hum02Any := linq.From(trg.List).Where(func(i interface{}) bool {
		return i.(targetItem).ID == "2;indoor_humidity"
	}).First()

	hum14Any := linq.From(trg.List).Where(func(i interface{}) bool {
		return i.(targetItem).ID == "14;indoor_humidity"
	}).First()

	require.IsType(t, targetItem{}, odtAny)
	require.IsType(t, targetItem{}, idtAny)
	require.IsType(t, targetItem{}, hum02Any)
	require.IsType(t, targetItem{}, hum14Any)

	odt := odtAny.(targetItem)
	idt := idtAny.(targetItem)
	hum02 := hum02Any.(targetItem)
	hum14 := hum14Any.(targetItem)

	assert.True(t, idt.TimeStamp.Before(time.Now()))
	assert.Equal(t, 23.7, idt.Value)

	assert.True(t, odt.TimeStamp.Before(time.Now()))
	assert.Equal(t, -2.0, odt.Value)

	assert.True(t, hum02.TimeStamp.Before(time.Now()))
	assert.Equal(t, 24.7, hum02.Value)

	assert.True(t, hum14.TimeStamp.Before(time.Now()))
	assert.Equal(t, 25.7, hum14.Value)
}
