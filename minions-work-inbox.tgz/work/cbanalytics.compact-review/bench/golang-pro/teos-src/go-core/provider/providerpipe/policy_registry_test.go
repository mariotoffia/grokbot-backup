package providerpipe

import (
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline/builtin"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestProviderStepTypes_ThePolicyStepCleansFailedSensorTimestamps checks the
// provider-side clean-up of failed sensor timestamps.
//
// Background: a provider payload carries a map called "sensorts" holding one
// timestamp per sensor. When a value could not be produced the generator writes
// the text "$error" instead of a timestamp. Those entries must not leave the
// service. The general pipeline library does not know this provider payload
// field, so the provider code attaches the clean-up to the policy step of its
// own pipelines.
func TestProviderStepTypes_ThePolicyStepCleansFailedSensorTimestamps(t *testing.T) {
	cbCtx := testenv.DefaultContext(t, "test")

	doc, readErr := cbpipeline.Read(cbCtx,
		[]byte(`{
		  "p": {
		    "policy-check": {"path": "x"}
		  }
		}`),
		cbpipeline.WithRegistry(StepTypes()))
	require.Nil(t, readErr)

	_, compileErr := cbpipeline.Compile(cbCtx, doc, StepTypes())
	require.Nil(t, compileErr)

	cfg, ok := doc.Steps[0].Config.(*builtin.PolicyConfig)
	require.True(t, ok, "the policy step must compile into a policy configuration")
	require.NotNil(t, cfg.PostProcessor,
		"provider pipelines must attach the sensor timestamp clean-up to the policy step")

	result := map[string]interface{}{
		"sensorts": map[string]interface{}{
			"T_SUPPLY": "2026-01-01T00:00:00Z",
			"T_RETURN": "$error",
		},
	}
	require.NoError(t, cfg.PostProcessor(result))

	require.Equal(t,
		map[string]interface{}{"T_SUPPLY": "2026-01-01T00:00:00Z"},
		result["sensorts"],
		"entries whose timestamp is the failure marker must be removed")
}

// TestProviderStepTypes_TheCleanUpIgnoresPayloadsWithoutSensorTimestamps checks that a payload
// with no "sensorts" map, or one of another shape, is left alone instead of
// failing the step.
func TestProviderStepTypes_TheCleanUpIgnoresPayloadsWithoutSensorTimestamps(t *testing.T) {
	for name, result := range map[string]map[string]interface{}{
		"no sensorts at all":    {"other": 1},
		"sensorts is not a map": {"sensorts": "not-a-map"},
		"sensorts is empty":     {"sensorts": map[string]interface{}{}},
		"nothing failed":        {"sensorts": map[string]interface{}{"a": "2026-01-01T00:00:00Z"}},
	} {
		t.Run(name, func(t *testing.T) {
			before := len(result)
			require.NoError(t, removeFailedSensorTimestamps(result))
			require.Len(t, result, before)
		})
	}
}

// TestProviderStepTypes_TheyAreBuiltOnce checks that provider pipelines always
// use the same set of step types. The compiled-pipeline cache keys on the
// identity of that set, so a new set per call would defeat the cache.
func TestProviderStepTypes_TheyAreBuiltOnce(t *testing.T) {
	require.Same(t, StepTypes(), StepTypes())
}

// TestProviderStepTypes_TheyAreTheOnlyOnesUsedToCompile is the check the test
// below cannot give.
//
// Running a pipeline proves the clean-up works when the provider's own set of
// step types is used. It cannot prove that the two places which compile a
// provider pipeline actually pass that set. Without this, a later edit could drop
// the argument, every other test would still pass, and provider payloads would
// go out carrying the failure marker again.
//
// It parses every non-test Go file of the package, so a call site may live in
// any of them.
func TestProviderStepTypes_TheyAreTheOnlyOnesUsedToCompile(t *testing.T) {
	entries, err := os.ReadDir(".")
	require.NoError(t, err)

	fset := token.NewFileSet()
	callSites := 0

	for _, entry := range entries {
		name := entry.Name()
		if entry.IsDir() || !strings.HasSuffix(name, ".go") || strings.HasSuffix(name, "_test.go") {
			continue
		}

		file, err := parser.ParseFile(fset, name, nil, 0)
		require.NoError(t, err)

		ast.Inspect(file, func(n ast.Node) bool {
			call, ok := n.(*ast.CallExpr)
			if !ok || !isIdent(call.Fun, "compilePipeline") {
				return true
			}

			callSites++

			registry, ok := call.Args[1].(*ast.CallExpr)
			require.True(t, ok && isIdent(registry.Fun, "StepTypes") && len(registry.Args) == 0,
				"%s compiles a provider pipeline without the provider's own set of step "+
					"types, so the sensor timestamp clean-up would be lost", fset.Position(call.Pos()))

			return true
		})
	}

	require.Equal(t, 2, callSites,
		"there are two places that compile a provider pipeline; if this number changed, "+
			"check the new one passes the provider's own set of step types")
}

// isIdent reports whether expr is the plain identifier name.
func isIdent(expr ast.Expr, name string) bool {
	ident, ok := expr.(*ast.Ident)

	return ok && ident.Name == name
}

// fixedPolicyEngine answers every policy question with the same result. The
// policy step uses this simple interface when it finds one in the pipeline
// variables, which lets a test run a real pipeline without a decision point.
type fixedPolicyEngine struct{ result any }

func (e *fixedPolicyEngine) Query(_, _ string, _ any, _ map[string]any) (any, error) {
	return e.result, nil
}

// TestProviderStepTypes_ARunCleansFailedSensorTimestamps runs a whole provider
// pipeline rather than looking at its compiled settings, and checks the value
// the pipeline actually leaves behind.
//
// This is the test that would catch the clean-up being lost: inspecting the
// compiled settings only proves that something was attached, while this proves
// that running the pipeline removes the failure markers from the payload.
func TestProviderStepTypes_ARunCleansFailedSensorTimestamps(t *testing.T) {
	cbCtx := testenv.DefaultContext(t, "test")

	doc, readErr := cbpipeline.Read(cbCtx,
		[]byte(`{
		  "p": {
		    "policy-check": {
		      "path": "x",
		      "input": "payload",
		      "result": "decided"
		    }
		  }
		}`),
		cbpipeline.WithRegistry(StepTypes()))
	require.Nil(t, readErr)

	prog, compileErr := cbpipeline.Compile(cbCtx, doc, StepTypes())
	require.Nil(t, compileErr)

	result, runErr := prog.Run(cbCtx, cbpipeline.WithVars(map[string]any{
		"policyengine": &fixedPolicyEngine{result: map[string]interface{}{
			"sensors": map[string]interface{}{"T_SUPPLY": 61.2, "T_RETURN": 41.8},
			"sensorts": map[string]interface{}{
				"T_SUPPLY": "2026-01-01T00:00:00Z",
				"T_RETURN": "$error",
			},
		}},
		"payload": map[string]interface{}{},
	}))
	require.Nil(t, runErr)

	decided, ok := result.Get("decided")
	require.True(t, ok, "the policy step must store its result")

	sensorts := decided.(map[string]interface{})["sensorts"].(map[string]interface{})
	require.Equal(t,
		map[string]interface{}{"T_SUPPLY": "2026-01-01T00:00:00Z"},
		sensorts,
		"a timestamp that is the failure marker must not leave the provider")
}
