package svprovider

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// cSpell: disable

func TestWantedMoreMandatoryThanRecievedShallGenerateMissingReport(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	// ODT and IDT_03 is out of range, filtered out and reported in log.
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}`

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(20), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(32), nil).
		Value("IDT_O4", float64(40), nil)

	wanted = []string{"ODT", "OFFODT", "IDT_O1", "IDT_O2", "IDT_O3", "IDT_O4"}

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	assert.Equal(t, "Europe/Stockholm", targetLocation.TimeZone)

	assert.Equal(
		t,
		5,
		len(targetLocation.Sensors),
		"two is outside of range and hence policy shall remove them",
	)

	assert.Equal(t, float64(20), targetLocation.Sensors["ODT"])
	assert.Equal(t, float64(-1.2), targetLocation.Sensors["OFFODT"])
	assert.Equal(t, nil, targetLocation.Sensors["IDT_O1"])
	assert.Equal(t, float64(15), targetLocation.Sensors["IDT_O2"])
	assert.Equal(t, float64(32), targetLocation.Sensors["IDT_O3"])
	assert.Equal(t, float64(40), targetLocation.Sensors["IDT_O4"])
}

func TestErrorInCredentialsFunctionShallRenderReport(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	// ODT and IDT_03 is out of range, filtered out and reported in log.
	smallConf := `{ "profile": "generic", "prms": { "LOG": "off", "CRD": "kalle", "BID": "Måssmyren 18" } }`

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	obtainCredentialsError = cberror.NewCbErrorf(
		"test",
		cberror.ErrorProviderEndPointConnection,
		nil,
		"failed to obtain credentials",
	)

	defer func() {
		obtainCredentialsError = nil
	}()

	assert.Panics(t, func() {
		NewDsBuildingPlugin(
			testProvider(0), "unit-test", "test-provider",
			bufio.NewReader(strings.NewReader(data)),
		).Execute()
	}, "shall panic since error when obtianing credentials")
}

func TestWantedMoreOprionalThanRecievedShallGenerateMissingReport(t *testing.T) {
	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	// ODT and IDT_03 is out of range, filtered out and reported in log.
	smallConf := `{
			"profile": "generic",
			"prms": {
				"LOG": "off",
				"MID": "IDT_O1 IDT_O2 IDT_O3 IDT_O4 OFFODT ODT",
				"OPT": "IDT**",
				"CRD": "", "BID": "Måssmyren 18",
				"PID": "1234",
				"TID": "1"
			}
		}`

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	data := fmt.Sprintf(`{
			"result": true,
			"config": [ "%s" ]
		}`, jsonutils.JSONEscape(smallConf))

	targetLocation = nil
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(20), nil).
		Value("OFFODT", float64(-1.2), nil).
		Value("IDT_O2", float64(15), nil).
		Value("IDT_O3", float64(32), nil).
		Value("IDT_O4", float64(40), nil)

	wanted = []string{"ODT", "OFFODT", "IDT_O1", "IDT_O2", "IDT_O3", "IDT_O4"}

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	assert.Equal(t, "Europe/Stockholm", targetLocation.TimeZone)

	assert.Equal(
		t,
		5,
		len(targetLocation.Sensors),
		"two is outside of range and hence policy shall remove them",
	)

	assert.Equal(t, float64(20), targetLocation.Sensors["ODT"])
	assert.Equal(t, float64(-1.2), targetLocation.Sensors["OFFODT"])
	assert.Equal(t, nil, targetLocation.Sensors["IDT_O1"])
	assert.Equal(t, float64(15), targetLocation.Sensors["IDT_O2"])
	assert.Equal(t, float64(32), targetLocation.Sensors["IDT_O3"])
	assert.Equal(t, float64(40), targetLocation.Sensors["IDT_O4"])

}
