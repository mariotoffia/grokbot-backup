package providerconfig

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// evaluateSearchExpression will do the evaluation of the _expr_ by a
// `cbeval.EvalCacheLangCompositeSearch` expression.
//
// It will also check if the result is `nil` and return an error if it is.
func evaluateSearchExpression(ctx ifcore.CbContext,
	expr string,
	data map[string]any) (any, cberror.Error) {
	sel, err := cbeval.GlobalEvalCache.GetEval(
		ctx,
		cbeval.UnwrapExpression(expr),
		cbeval.EvalCacheLangCompositeSearch,
	)

	if err != nil {
		return nil, err
	}

	res, selError := sel(ctx, data)
	if selError != nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), 1, selError,
			"Failed to evaluate filter expression: %s", expr,
		)
	}

	if res == nil {
		return nil, cberror.NewCbErrorf(
			ctx.Service(), 2, nil,
			"Filter expression returned nil: %s", expr,
		)
	}

	return res, nil
}
