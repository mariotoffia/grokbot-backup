package configchange

import (
	"encoding/json"
	"runtime"
	"strings"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/tkdisp/cbsqs"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"

	"github.com/gobwas/glob"
	"github.com/rs/zerolog"
)

// ConfigInput is a function that acts as an input for the pipeline.
type ConfigInput func(ctx ifcore.CbContext, item *cbevent.ConfigChangeEventImpl) map[string]any

// ConfigChangeProviderDispatcher builds the dispatcher for the cfo provider.
//
// It may parallelize up to `runtime.NumCPU()*64` and timeout after 120 seconds.
//
// The _selectors_ is used to select on `cbevent.ConfigChangeImpl.ID` to accept. Even though they are optional,
// it will panic if not provided. Selectors are glob patterns, e.g. 'BLD#*#BLD'.
//
// NOTE: Since location ID is required, it will automatically extract it from the `cbevent.ConfigChangeImpl.ID` and thus
// no config changes that do not have BLD#*#BLD**  can not be processed.
//
// There are default, `DefaultConfigSource` and `DefaultConfigInput` that can be used in the _cfgchgsrc package_.
//
// NOTE: It uses the `cbevent.ProviderEvent` and expects a `cbevent.ConfigChangeEventImpl` as payload.
func ConfigChangeProviderDispatcher( /* NOSONAR */
	path string,
	builder *providercontext.ProviderContextBuilderImpl,
	input ConfigInput,
	selectors ...string,
) providercontext.ProviderHandlerFunc {
	//
	const method = "ConfigChangeProviderDispatcher"

	if len(selectors) == 0 {
		panic("selectors for config source are MANDATORY!!")
	}

	selection := make([]glob.Glob, len(selectors))

	for i, selector := range selectors {
		glb, err := glob.Compile(selector, '#')

		if err != nil {
			panic(err)
		}

		selection[i] = glb
	}

	return func(pc providercontext.ProviderContext) dispruntime.HandlerInvoker {
		return cbsqs.JSONWithRoute(
			path,
			pc.Context(),
			func(ctx ifcore.CbContext, evt *cbevent.ProviderEvent) error {
				if log.IsEnabled(zerolog.TraceLevel) {
					log.Trace(ctx).
						WithMethod(method).
						WithBody(evt).
						Msg("Processing config change provider event")
				}

				if evt.PayloadType != cbevent.PayloadConfigChangeEvent {
					log.Warn(ctx).WithMethod(method).WithBody(evt).Msg("Invalid payload type")
					return nil
				}

				if evt.Payload == nil {
					log.Warn(ctx).WithMethod(method).WithBody(evt).Msg("Invalid payload (nil)")
					return nil
				}

				var cfgChange cbevent.ConfigChangeEventImpl

				if err := json.Unmarshal(*evt.Payload, &cfgChange); err != nil {
					log.Warn(ctx).
						WithMethod(method).
						WithBody(evt).
						WithError(err).
						Msg("Failed to unmarshal payload")
					return nil
				}

				// LID is BLD#{lid}#<whatever follows>
				if !strings.HasPrefix(cfgChange.ID, "BLD#") {
					log.Warn(ctx).
						WithMethod(method).
						WithBody(cfgChange).
						Msg("Invalid config change - not a building")
					return nil
				}

				lid := cfgChange.ID[4:]
				if idx := strings.Index(lid, "#"); idx != -1 {
					lid = lid[:idx]
				}

				var match bool

				for _, glb := range selection {
					if glb.Match(cfgChange.ID) {
						match = true
						break
					}
				}

				if !match {
					log.DebugWithLocationID(ctx, lid).
						WithMethod(method).
						WithBody(selectors).
						Str("id", cfgChange.ID).
						Msg("Config Change Not matching the selectors")

					return nil
				}

				_, err := builder.ProviderContext().
					OnProviderEvent(ctx, evt, input(ctx, &cfgChange))

				if err != nil {
					log.WarnWithLocationID(ctx, lid).
						WithMethod(method).
						WithBody(evt).
						WithError(err).
						Msg("Failed to execute pipeline")

					return err
				}

				log.InfoWithLocationID(ctx, lid).
					WithMethod(method).
					Str("id", cfgChange.ID).
					Msg("Successfully executed pipeline")

				return nil
			},
			cbsqs.WithParallelism(runtime.NumCPU()*64),
			cbsqs.WithTimeout(120*time.Second),
		)
	}
}
