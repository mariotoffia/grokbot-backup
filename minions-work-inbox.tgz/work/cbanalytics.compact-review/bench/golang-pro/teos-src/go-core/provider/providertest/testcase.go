package providertest

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/aws/aws-lambda-go/events"
	"github.com/mariotoffia/ssm"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/managers/mgriot"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	dispruntime "github.com/Thiink-LLC/teos/go-core/tkdisp/runtime"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/cbreflect"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

type ProviderTestCase struct {
	BuildingID          string
	DeviceID            string
	CredPath            string
	InitialShadowState  SensorShadowState
	ExpectedShadowState SensorShadowState

	ctx                        ifcore.CbContext
	currentDeviceShadowVersion int64
	serializer                 *ssm.Serializer
	expectRetrySQS             bool
	iotmgr                     *mgriot.DSManager
	devmgr                     *mgriot.DeviceManagerImpl
	Credentials                *securitymodel.TokenCredentialsImpl
	feeder                     dispruntime.RawInvoker
}

// ToExpectedFloat will return the expected float value for the data point.
func (tc *ProviderTestCase) ToExpectedFloat(dp string) float64 {
	return tc.ExpectedShadowState[dp].(float64)
}

// ToInitialFloat will return the initial float value for the data point.
func (tc *ProviderTestCase) ToInitialFloat(dp string) float64 {
	return tc.InitialShadowState[dp].(float64)
}

func (tc *ProviderTestCase) ToInitialFloatPtr(dp string) *float64 {
	value := tc.InitialShadowState[dp].(float64)
	return &value
}

func (tc *ProviderTestCase) ExpectRetry() *ProviderTestCase {
	tc.expectRetrySQS = true
	return tc
}

// AddFloat will add a float data point with it's initial value and the expected value.
//
// .Example
// [source,go]
// ----
// tc.Float("IDT_O1", 20.5, 22.5).
//
//	Float("AEUPS", 0, ti.RandFloat64(80, 1)).
//	Float("OFFODT", 2.11, 2.46)
//
// ----
func (tc *ProviderTestCase) Float(dp string, initial, expected float64) *ProviderTestCase {
	tc.InitialShadowState[dp] = initial
	tc.ExpectedShadowState[dp] = expected

	return tc
}

// Int is same as `Float` but for integer.
func (tc *ProviderTestCase) Int(dp string, initial, expected int) *ProviderTestCase {
	tc.InitialShadowState[dp] = initial
	tc.ExpectedShadowState[dp] = expected

	return tc
}

// Run will execute the provider testcase.
//
// It will create the device and device shadow in AWS IoT.
// It will upload potential credentials to SSM.
// It will upload the initial device shadow state.
// It will execute the runner.
// It will validate the expected shadow state against the actual shadow state.
//
// .Example Config for a sv Provider
// [source,json]
// ----
//
//	{ "profile": "generic", "prms": {
//					"LOG": "off","MID": "IDT_O1 IDT_O2 COMT OFFODT",
//					"CRD": "%s", "BID": "%s", "PID": "1234", "TID": "1"}}
//
// ----
//
// CAUTION: CRD must be before BID in the config string!!!
//
// .Example Data for sv Provider
// [source,go]
// ----
//
//	&dsmodel.DsFullBuildingState{
//		Desired: dsmodel.DsBuilding{
//			TimeZone:   "Europe/Stockholm",
//			ReportType: string(providerutils.ReportDsBuildingAcknowledge),
//			Sensors: map[string]any{
//				"IDT_O1": 20.5,
//				"IDT_O2": 21.5,
//				"OFFODT": 2.46,
//			},
//		},
//	}
//
// ----
func (tc *ProviderTestCase) Run(
	config *providermodel.ProviderConfigImpl,
	data *dsmodel.DsFullBuilding,
) error {
	// ** Set Building ID ** //
	if _, ok := config.Params[string(ifprovider.ParameterLocationID)]; !ok {
		config.Params[string(ifprovider.ParameterLocationID)] = tc.BuildingID
	}

	var err error
	// *** Create IoT Core Device *** //
	if tc.devmgr == nil {
		if tc.devmgr, err = CreateDeviceManagerWithThingName(tc.ctx, tc.BuildingID); err != nil {
			return err
		}

		// ** Wait for device shadow to be created ** //
		_ = CreateAndWaitForDeviceShadow(tc.iotmgr, tc.BuildingID)
	}

	// ** Get Shadow Version ** //
	if tc.currentDeviceShadowVersion, err = GetShadowVersion(tc.ctx, tc.iotmgr); err != nil {
		return err
	}

	// *** Upload Credentials to SSM *** //
	if tc.serializer == nil && tc.Credentials != nil {
		tc.serializer = ssm.NewSsmSerializer(cbenv.DevLocal.String(), utils.RandomPostfix("unit-test")).
			UsePrefix(tc.CredPath)

		fields := tc.serializer.Marshal(tc.Credentials)

		if len(fields) > 0 {
			return fmt.Errorf("failed to marshal credentials")
		}

		config.Params[string(ifprovider.ParameterCredentials)] = tc.CredPath
	}

	// *** Setup Initial Reported State *** //
	if len(tc.InitialShadowState) > 0 {
		tc.iotmgr.UseReportedStatePayload(tc.InitialShadowState.ToShadow(), "", true)
		tc.iotmgr.UpsertReported()

		if tc.iotmgr.Error() != nil {
			return fmt.Errorf("failed to update shadow: %s", tc.iotmgr.Error().Error())
		}

		var updated bool

		tc.currentDeviceShadowVersion, updated, err = WaitUntilShadowIsUpdated(
			tc.ctx,
			tc.iotmgr,
			tc.currentDeviceShadowVersion,
			20*time.Second,
			tc.InitialShadowState,
			true, /*exactMatch*/
		)

		if err != nil {
			return err
		}

		if !updated {
			return fmt.Errorf("failed to update shadow")
		}
	}

	// ** Create Provider Event ** //
	var building *json.RawMessage

	if data != nil {
		data.BuildingID = tc.BuildingID

		data.Topic = "$aws/things/" +
			utils.EncodeThingCompatibleName(tc.BuildingID) +
			"/shadow/name/building/update/accepted"

		building = jsonutils.ToJSONRawMessage(&data)
	}

	buff := providerconfig.NewConfigWriter(tc.ctx).
		AddProviderConfig(config).
		Write().Buffer.Bytes()

	event := &cbevent.ProviderEvent{
		Provider:    "test-provider-2",
		Result:      true,
		Config:      []any{string(buff)},
		PayloadType: cbevent.PayloadBuildingDeviceShadow,
		Payload:     building,
	}

	// *** Execute Provider *** //
	msgId := utils.RandomPostfix("msg")
	res, invokeError := tc.feeder.InvokeRaw(tc.ctx, jsonutils.ToJSON(events.SQSEvent{
		Records: []events.SQSMessage{
			{
				MessageId:   msgId,
				EventSource: "aws:sqs",
				Body:        string(jsonutils.ToJSON(event)),
			},
		},
	}))

	if invokeError != nil {
		return fmt.Errorf("failed to invoke provider: %s", invokeError.Error())
	}

	if !tc.expectRetrySQS {
		if !cbreflect.IsNilPointer(res) {
			return fmt.Errorf("expected nil response, got: %#v", res)
		}
	} else {
		sqsRes, ok := res.(*events.SQSEventResponse)

		if !ok {
			return fmt.Errorf("expected *events.SQSEventResponse, got: %#v", res)
		}

		if len(sqsRes.BatchItemFailures) != 1 {
			return fmt.Errorf("expected 1 BatchItemFailures, got: %d", len(sqsRes.BatchItemFailures))
		}

		if sqsRes.BatchItemFailures[0].ItemIdentifier != msgId {
			return fmt.Errorf("expected BatchItemFailures[0].ItemIdentifier to be: %s, got: %s",
				msgId, sqsRes.BatchItemFailures[0].ItemIdentifier)
		}

		return nil // Skip Validation of Device Shadow
	}

	// *** Validate Reported Data in IoT Core *** //
	var (
		updated            bool
		finalShadowVersion int64
	)

	finalShadowVersion, updated, err = WaitUntilShadowIsUpdated(
		tc.ctx,
		tc.iotmgr,
		tc.currentDeviceShadowVersion,
		10*time.Second,
		tc.ExpectedShadowState,
		true, /*exactMatch*/
	)

	if err != nil {
		return err
	}

	if !updated {
		return fmt.Errorf("failed to update shadow (when validating)")
	}
	if tc.currentDeviceShadowVersion == finalShadowVersion {
		return fmt.Errorf("expected shadow version to be less than: %d, got: %d",
			tc.currentDeviceShadowVersion, finalShadowVersion)
	}

	tc.currentDeviceShadowVersion = finalShadowVersion

	return nil // All good
}

// Use it within the single test scope `defer tc.Cleanup()`.
func (tc *ProviderTestCase) Cleanup() {
	if tc.devmgr != nil {
		err := tc.devmgr.ClearError().DeleteDevice("" /*any version*/, false /*force*/).Error()
		if err != nil {
			fmt.Printf(
				"Failed to clean up integration test, manually delete thing name: %s, error: %s",
				tc.devmgr.DeviceName(), tc.devmgr.Error().Error())
		}
	}

	if tc.serializer != nil {
		_, err := tc.serializer.Delete(tc.Credentials)
		if err != nil {
			fmt.Printf(
				"Failed to clean up integration test, manually delete credentials, error: %s",
				err.Error(),
			)
		}
	}
}

// New will setup the base testcase for executing a provider testcase.
//
// If `CB_TEST_LOG_LEVEL` environment variable is set it will override _level_.
// If neither is set it defaults to `zerolog.FatalLevel`.
func (runner *ProviderTestRunner) TestCase(
	providerName, deviceID string,
	creds *securitymodel.TokenCredentialsImpl,
) *ProviderTestCase {
	//
	lid := utils.RandomPostfix("unittest")
	iotmgr, err := CreateIoTManager(runner.ctx, lid)

	if err != nil {
		panic(err)
	}

	tc := &ProviderTestCase{
		ctx:                 runner.ctx,
		feeder:              runner.pctx.Invoker(),
		iotmgr:              iotmgr,
		BuildingID:          lid,
		DeviceID:            deviceID,
		InitialShadowState:  SensorShadowState{},
		ExpectedShadowState: SensorShadowState{},
	}

	if creds != nil {
		tc.Credentials = creds
		tc.CredPath = "/test/provider/" + providerName + "/" + utils.RandomPostfix("unittest")
	}

	return tc
}
