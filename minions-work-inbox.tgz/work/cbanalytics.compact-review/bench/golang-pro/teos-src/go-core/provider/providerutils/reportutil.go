package providerutils

import (
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/reportmodel"
)

// toMandatoryAndOptional will split the _dp_ data points
// into two slices, one for mandatory and one for optional data points. Those
// will be stored in the `ReportConfig` _mandatoryID_ and _optionalID_ fields.
//
// When successfully populated the ID fields, it will copy the _DataPoints_
// to the _mandatoryDP_ and _optionalDP_ fields.
//
// The _wanted_ sensors will be the constrain that this function will use
// to split and return the data points. Hence, it is the wanted sensors
// that the search for optional sensors is done.
func toMandatoryAndOptional(ctx ifcore.CbContext, config *ReportContext) cberror.Error {
	optSensors, err := config.ProviderConfig.GetOptionalSensors(
		config.Operation,
		config.WantedSensors,
	)

	if nil != err {
		return cberror.NewCbErrorf(ctx.Service(), 1, err, "Failed to resolve optional sensors")
	}

	if len(optSensors) == 0 {
		config.mandatoryDP = config.DataPoints
		config.mandatoryID = config.WantedSensors
		return nil
	}

	config.optionalSet = map[string]bool{}
	for _, s := range optSensors {
		config.optionalSet[s] = true
	}

	for _, s := range config.WantedSensors {
		if _, ok := config.optionalSet[s]; ok {
			config.optionalID = append(config.optionalID, s)
		} else {
			config.mandatoryID = append(config.mandatoryID, s)
		}
	}

	for _, dp := range config.DataPoints {
		cbSensor := toTEOSID(config, dp)
		if _, ok := config.optionalSet[cbSensor]; ok {
			config.optionalDP = append(config.optionalDP, dp)
		} else {
			config.mandatoryDP = append(config.mandatoryDP, dp)
		}
	}

	return nil
}

// toTEOSID will try to resolve the _TEOS_ ID for a certain `eqmodel.CbDataPoint`
// by using the ID of the `eqmodel.CbDataPoint` with or without a `SplitPartitionAndIDFunc`.
//
// It will use the `ReportContext.MapperWithoutPartition` to determine how to resolve
// the _TEOS_ ID using the `GetMappedTo` or `GetMappedFrom` function depending on the direction
// of the provider.
//
// If it fails to fetch the mapped to - it will just return the ID of the `eqmodel.CbDataPoint`.
func toTEOSID(config *ReportContext, dp eqmodel.CbDataPoint) string {
	var (
		id, mapper string
		teosID     string
		ok         bool
	)

	if config.ToTeosID != nil {
		teosID = config.ToTeosID(dp)
	}

	if teosID != "" {
		return teosID
	}

	if config.SplitPartitionAndIDFunc != nil {
		id, _ = config.SplitPartitionAndIDFunc(dp.GetID())
	} else {
		id = dp.GetID()
	}

	if config.MapperWithoutPartition {
		mapper = id
	} else {
		mapper = dp.GetID()
	}

	teosID, ok = config.ProviderConfig.GetMappedFrom(mapper)

	if !ok {
		teosID = dp.GetID()
	}

	return teosID
}

// logReport will log the `report` with `zerolog.InfoLevel`
func logReport(
	c ifcore.CbContext,
	level zerolog.Level,
	state ifprovider.ProvisionedState,
	report reportmodel.ReportContainer,
	message string) {
	if report.GetBody() == nil && report.GetError() == nil {
		return
	}

	log.Level(c, level, report.GetLocationID()).
		WithMethod(string(report.GetReportType())).
		WithError(report.GetError()).
		WithBody(report.GetBody()).
		Str("pst", string(state)).
		Str("profile", report.GetProfile()).
		Msg(message)
}
