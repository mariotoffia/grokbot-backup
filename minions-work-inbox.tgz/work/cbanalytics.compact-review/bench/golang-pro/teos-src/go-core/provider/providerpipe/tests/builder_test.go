package tests

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
)

func TestPipelineBuilder_ChainedMethods(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	// PipelineBuilder methods can be chained, but Build() may return nil
	// without all required configuration. This test verifies the fluent API works.
	builder := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(50).
		WithParallelThreshold(10)

	// The builder itself should not be nil
	assert.NotNil(t, builder)
}

func TestPipeBuilder_ChainedBuild(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).Build()

	// Build a pipe with an operation
	pipeBuilder := providerpipe.NewPipeBuilder(ctx, pipeline).
		AsOperation("test-op")

	pipe := pipeBuilder.Build()

	assert.NotNil(t, pipe)
}

func TestPipeBuilder_BuildWithoutOperation(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).Build()

	// Build a pipe without setting an operation
	pipeBuilder := providerpipe.NewPipeBuilder(ctx, pipeline)

	pipe := pipeBuilder.Build()

	// The pipe should still be created
	assert.NotNil(t, pipe)
}
