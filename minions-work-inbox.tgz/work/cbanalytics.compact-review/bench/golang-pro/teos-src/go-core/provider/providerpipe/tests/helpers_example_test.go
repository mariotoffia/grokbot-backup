package tests

import (
	"os"
	"testing"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	teosctx "github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// TestMain applies the unit-test settings to every test and example in this
// package. An example has no test to apply them to one at a time.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvDefaults))
}

// exampleCtx builds the request context the examples run under. Its AWS
// configuration is empty, so nothing reads the machine's AWS profile.
func exampleCtx(level zerolog.Level) ifcore.CbContext {
	c, err := teosctx.NewContext("unit-test", "test", cbenv.DevLocal, true,
		teosctx.OptAWSSetConfig(aws.Config{}, true /*force*/))
	if err != nil {
		panic(err)
	}

	zerolog.SetGlobalLevel(level)

	return c
}

// Example_pipelineBuild shows how to build a pipeline.
func Example_pipelineBuild() {
	ctx := exampleCtx(zerolog.InfoLevel)
	defer ctx.Close()

	// tag::pipeline-build[]
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(5).
		WithTimeout(30 * time.Second).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(
			providerconfig.NewProviderConfigRepository(
				ctx,
				providerconfig.NewFsProviderConfigLoaderFromPath("./config/"),
			),
		).
		UseCredentialsFunction(func(
			ctx ifcore.CbContext,
			cred string,
			pipeCtx map[string]any,
			op *providermodel.Operation,
		) (any, int64, cberror.Error) {
			return &securitymodel.TokenCredentialsImpl{
				Token: []byte("my-token"),
			}, 3600, nil
		}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		Build()
	// end::pipeline-build[]

	_ = pipeline
}

// Example_pipeBuild shows how to build a pipe.
func Example_pipeBuild() {
	ctx := exampleCtx(zerolog.InfoLevel)
	defer ctx.Close()
	pipeline := providerpipe.NewPipelineBuilder(ctx).Build()

	// tag::pipe-build[]
	pipe := providerpipe.NewPipeBuilder(ctx, pipeline).
		MapSectionIsWithoutPartition().
		HasPartitionIDSeparator(";").
		UseMappingDirection(providermodel.MappingDirectionLeftAssign).
		WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
		UseSourceMapWithReport(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			rid []string,
			cred any,
		) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
			// Fetch data from remote system
			return map[string]eqmodel.CbDataPoint{
				"remote-id-1": &eqmodel.CbDataPointImpl{ID: "remote-id-1", Value: 22.5},
			}, nil, nil, nil
		}).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn)).
		Build()
	// end::pipe-build[]

	_ = pipe
}

// Example_pipelineExecute shows how to execute a pipeline.
func Example_pipelineExecute() {
	ctx := exampleCtx(zerolog.InfoLevel)
	defer ctx.Close()

	// tag::pipeline-execute[]
	userConfig := `{
		"profile": "generic",
		"prms": {"TZ": "Europe/Stockholm"},
		"map": {"IDT": "remote-id-1"}
	}`

	pipeline := providerpipe.NewPipelineBuilder(ctx).Build()

	results := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(userConfig).
		Build().
		Execute()

	for _, result := range results {
		if result.Error != nil {
			// Handle error
			continue
		}
		// Process result.Result
		_ = result.Result
	}
	// end::pipeline-execute[]
}

// Example_finallyUsage shows how to use FinallyFunction.
func Example_finallyUsage() {
	ctx := exampleCtx(zerolog.InfoLevel)
	defer ctx.Close()
	pipeline := providerpipe.NewPipelineBuilder(ctx).Build()

	// tag::finally-usage[]
	pipe := providerpipe.NewPipeBuilder(ctx, pipeline).
		UseFinally(func(
			ctx ifcore.CbContext,
			pipeCtx map[string]any,
			operation string,
			op *providermodel.Operation,
			pc *providermodel.ProviderConfigImpl,
			target map[string]any,
			pipeErr cberror.Error,
		) cberror.Error {
			// Always runs - use for cleanup, logging, acknowledgment

			if pipeErr != nil {
				// Can suppress error by returning nil
				// Can wrap: return cberror.NewCbErrorf(..., pipeErr, ...)
				// Can replace: return newError
				return pipeErr // Propagate unchanged
			}

			return nil
		}).
		AsOperation("test").
		Build()
	// end::finally-usage[]

	_ = pipe
}

// Example_singlePipe shows single pipe execution.
func Example_singlePipe() {
	ctx := exampleCtx(zerolog.InfoLevel)
	defer ctx.Close()
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithSessionStore(config.NewSessionStore(ctx)).
		Build()

	pipe := providerpipe.NewPipeBuilder(ctx, pipeline).
		AsOperation(string(locationmodel.ProviderOperationSensorValueIn)).
		Build()

	// tag::single-pipe[]
	userConfig := `{"profile": "generic", "map": {"IDT": "1!ABC123"}}`

	exec := providerpipe.NewExecutorBuilder(ctx).
		UsePipe(*pipe).
		FromUserConfig(userConfig).
		Build()

	result := exec.Execute().GetResult()

	if exec.Error() != nil {
		// Handle error
	}

	// Use result["target"] for output data
	_ = result
	// end::single-pipe[]
}

// Example_errorHandling shows result error checking.
func Example_errorHandling() {
	ctx := exampleCtx(zerolog.InfoLevel)
	defer ctx.Close()
	pipeline := providerpipe.NewPipelineBuilder(ctx).Build()

	// tag::error-handling[]
	var results providerpipe.IterationExecutionResults
	// ... execute pipeline ...

	if results.HasError() {
		// At least one iteration failed
		errors := results.GetErrors()
		for _, err := range errors {
			_ = err // Log or handle each error
		}

		// Or get composite error
		compositeErr := results.GetCompositeError()
		_ = compositeErr
	}

	// Filter by operation
	svResults := results.ForOperation(locationmodel.ProviderOperationSensorValueIn)
	for _, r := range svResults {
		if r.Error == nil {
			_ = r.Result // Process successful result
		}
	}
	// end::error-handling[]

	_ = pipeline
}
