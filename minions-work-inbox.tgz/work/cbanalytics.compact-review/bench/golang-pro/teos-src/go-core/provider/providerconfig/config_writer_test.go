package providerconfig

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// cSpell: disable
func TestWriteProviderConfig(t *testing.T) {
	pc := genProviderConfig()

	cw := NewConfigWriter(newCtx(t)).AddProviderConfig(&pc).Write()
	s := cw.Buffer.String()

	assert.Equal(t, nil, cw.Error)
	assert.True(t, strings.Contains(s, `"profile":"test"`))
}

func TestWriteProviderConfigContainingNamedGeneratorTemplate(t *testing.T) {
	pc := genProviderConfig()
	pc.Generate = map[string]string{
		"genref": `{"myprop": max(:src.Sensors.IDT**:)`,
	}

	cw := NewConfigWriter(newCtx(t)).AddProviderConfig(&pc).Write()
	s := cw.Buffer.String()

	assert.Equal(t, nil, cw.Error)
	assert.True(t, strings.Contains(s, `"profile":"test"`))
	assert.True(t, strings.Contains(s, `,"prms":{`))
	assert.True(
		t,
		strings.Contains(
			s,
			"--gen=genref\n{\"myprop\": max(:src.Sensors.IDT**:)",
		),
	)
}

func TestWriteProviderConfigContainingNamedGeneratorPrototypes(t *testing.T) {
	pc := genProviderConfig()
	pc.GenProto = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}]",
			"IDT_O1": `generate["IDT_O1"]`,
			"*":      "float64(generate[{{ID}}])",
		},
	}

	pc.GenProtoTs = map[string]providermodel.GeneratorPrototypeImpl{
		"sv": {
			"IDT":    "generate[{{ID}}].TimeStamp",
			"IDT_O1": `generate["IDT_O1"].TimeStamp`,
			"*":      "generate[{{ID}}].TimeStamp",
		},
	}

	cw := NewConfigWriter(newCtx(t)).AddProviderConfig(&pc).Write()
	s := cw.Buffer.String()

	assert.Equal(t, nil, cw.Error)
	assert.True(t, strings.Contains(s, `"profile":"test"`))
	assert.True(t, strings.Contains(s, `"prms":{`))
	assert.True(t, strings.Contains(s, `--genproto=sv`))
	assert.True(t, strings.Contains(s, `IDT_O1: generate["IDT_O1"]`))
	assert.True(t, strings.Contains(s, `IDT: generate[{{ID}}]`))
	assert.True(t, strings.Contains(s, `*: float64(generate[{{ID}}])`))
	assert.True(t, strings.Contains(s, `:TS:IDT_O1: generate["IDT_O1"]`))
	assert.True(t, strings.Contains(s, `:TS:IDT: generate[{{ID}}]`))
	assert.True(t, strings.Contains(s, `:TS:*: float64(generate[{{ID}}])`))
}

func TestWriteProviderConfigAndTwoNamedGeneratorTemplate(t *testing.T) {
	pc := genProviderConfig()

	cw := NewConfigWriter(newCtx(t)).
		AddProviderConfig(&pc).
		AddGenerator("genref", `{"myprop": max(:src.Sensors.IDT**:)`).
		AddGenerator("sv", `{"gen":"this"}`).
		Write()

	s := cw.Buffer.String()

	assert.Equal(t, nil, cw.Error)
	assert.True(t, strings.Contains(s, `"profile":"test"`))
	assert.True(t, strings.Contains(s, `"prms":{`))
	assert.True(
		t,
		strings.Contains(
			s,
			"--gen=genref\n{\"myprop\": max(:src.Sensors.IDT**:)",
		),
	)
	assert.True(t, strings.Contains(s, "--gen=sv\n{\"gen\":\"this\"}"))
}

func TestWriteProviderConfigContainingTwoNamedGeneratorTemplateOnePipe(t *testing.T) {
	pc := genProviderConfig()
	pc.Generate = map[string]string{
		"genref": `{"myprop": max(:src.Sensors.IDT**:)`,
		"sv":     `{"gen":"this"}`,
	}
	pc.Pipe = map[string]string{
		"sv": `{"my-pipe": { "set-a": {"kalle":"nisse"}}}`,
	}

	cw := NewConfigWriter(newCtx(t)).AddProviderConfig(&pc).Write()
	s := cw.Buffer.String()

	assert.Equal(t, nil, cw.Error)
	assert.True(t, strings.Contains(s, `"profile":"test"`))
	assert.True(t, strings.Contains(s, `"prms":{`))
	assert.True(
		t,
		strings.Contains(
			s,
			"--gen=genref\n{\"myprop\": max(:src.Sensors.IDT**:)",
		),
	)
	assert.True(t, strings.Contains(s, "--gen=sv\n{\"gen\":\"this\"}"))
	assert.True(
		t,
		strings.Contains(s, "--pipe=sv\n{\"my-pipe\": { \"set-a\": {\"kalle\":\"nisse\"}}}"),
	)
}

func BenchmarkWriteProviderConfigContainingTwoNamedGeneratorTemplateOnePipe(t *testing.B) {
	pc := genProviderConfig()
	pc.Generate = map[string]string{
		"genref": `{"myprop": max(:src.Sensors.IDT**:)`,
		"sv":     `{"gen":"this"}`,
	}
	pc.Pipe = map[string]string{
		"sv": `{"my-pipe": { "set-a": {"kalle":"nisse"}}}`,
	}

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		cw := NewConfigWriter(newCtx(t)).AddProviderConfig(&pc).Write()
		if nil != cw.Error {
			assert.Equal(t, nil, cw.Error)
		}
	}
}

func genProviderConfig() providermodel.ProviderConfigImpl {
	return providermodel.ProviderConfigImpl{
		ProfileImpl: providermodel.ProfileImpl{
			BaseProfile: providermodel.BaseProfile{
				Profile: "test",
				Params: map[string]interface{}{
					"BID": "Månstenen 9",
					"MID": "IDT",
					"REP": "climatixic.se",
					"PID": "a129-122-99128-aff-122",
				},
				Map: map[string]string{
					"IDT": "Room temp.comf.",
				},
				Filter: map[string]string{
					"IDT": "V > -100 && V < 100",
				},
				Operation: map[string]providermodel.Operation{
					"sv": {
						Operation: "['https://' + REP + '/DataPoints/Values/']",
						Params: map[string]interface{}{
							"parentId": `['[{"Plants":"[{"Plants":"' + PID + '"}]"}]']`,
						},
					},
					"esv": {
						Operation: "['https://' + REP + '/DataPoints/Values/']",
						Params: map[string]interface{}{
							"PID": "the-plant-id",
						},
					},
				},
			},
		},
	}
}

//cSpell: enable
