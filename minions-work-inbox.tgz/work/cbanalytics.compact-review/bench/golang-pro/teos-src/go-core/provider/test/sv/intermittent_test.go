package sv

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/aws/aws-lambda-go/events"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSimpleImportProviderSQSOneSucceedOneFailIntermittent(t *testing.T) {
	var result any

	// Dummy target for testing purpose only
	target := func(ctx ifcore.CbContext, operation string, op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl, pipeCtx map[string]any,
		cred any, target map[string]any) cberror.Error {
		// Push to e.g. device shadow...
		result = target["target"]
		return nil
	}

	// Source func to simulate API call and errors
	source := func(
		ctx ifcore.CbContext,
		pipeCtx map[string]any,
		operation string,
		eop *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		rid []string,
		cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
		// Shall we simulate an intermittent error?
		if fail := pc.GetParamAsStringWithDefault("FAIL", "false"); fail == "true" {
			return nil, nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), 1, nil,
				map[string]any{cberror.PropertyRetryAfter: time.Second * 5},
				"Simulate intermittent error")
		}

		return []eqmodel.CbDataPoint{
			&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.7},
			&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZH7ZS23P", Value: 18.5},
			&eqmodel.CbDataPointImpl{ID: "1!6WHH6DKHICVDSS", Value: 2.46},
			&eqmodel.CbDataPointImpl{ID: "1!N3ASTG10KWTFCMU", Value: -17.0},
		}, nil /*body*/, nil /*err*/
	}

	// Root Service Context
	ctx := newProviderContext(t, "test-provider", "test-service")

	// Pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseTarget(target).
				UseSourceWithReport(source).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		})

	// Provider Context
	builder := providercontext.NewProviderContextBuilder()
	builder.
		WithRootContext(ctx).
		AsProviderType(locationmodel.ProviderOperationSensorValueIn).
		WithProviderConfiguration(providerConfig).
		UsePipeline(pipeline).
		UseProviderDispatcher(providercontext.DefaultSQSDispatcherProviderEvent("/provider/test/sv", builder))

	pctx := builder.Build()

	sqsResult, err2 := pctx.Invoker().InvokeRaw(ctx, jsonutils.ToJSON(&events.SQSEvent{
		Records: []events.SQSMessage{
			{
				MessageId:   "1",
				EventSource: "aws:sqs",
				Body: string(jsonutils.ToJSON(&cbevent.ProviderEvent{
					Provider: "test-provider",
					Result:   true,
					Config: []any{
						`{"profile": "single-plant/generic"}`,
					},
				})),
			},
			{
				MessageId:   "2",
				EventSource: "aws:sqs",
				Body: string(jsonutils.ToJSON(&cbevent.ProviderEvent{
					Provider: "test-provider",
					Result:   true,
					Config: []any{
						`{"profile": "single-plant/generic", "prms": {"FAIL": "true"} }`,
					},
				})),
			},
		},
	}))

	require.NoError(t, err2)

	require.NotNil(t, sqsResult)
	assert.Equal(t, 1, len(sqsResult.(*events.SQSEventResponse).BatchItemFailures))
	assert.Equal(t, "2", sqsResult.(*events.SQSEventResponse).BatchItemFailures[0].ItemIdentifier)

	require.NotNil(t, result)
	assert.Equal(t, "Europe/Stockholm", result.(*dsmodel.DsBuilding).TimeZone)
	assert.Equal(t, float64(-17), result.(*dsmodel.DsBuilding).Sensors["ODT"])
	assert.Equal(t, 2.46, result.(*dsmodel.DsBuilding).Sensors["OFFODT"])
}
