package utils

import (
	"strings"

	"github.com/Thiink-LLC/teos/go-core/utils/collection"
)

// CircuitAliasMID will replace a ID with ID:ID_C{circuit} for all IDs supplied in the mid.
func CircuitAliasMID(mid string, circuit string) string {
	if len(mid) == 0 {
		return ""
	}

	am := ""

	for _, m := range strings.Split(mid, " ") {
		am += m + ":" + m + "_C" + circuit + " "
	}

	return am[:len(am)-1]
}

// ConcatMID will concatenate two mids and ensure only one space is between each ID.
//
// It will also remove any duplicates. It is possible to have single IDs specified in _remove_
// that will not be included in the result.
func ConcatMID(a, b string, remove ...string) string {
	m := collection.NewSet[string](len(a) + len(b))
	aliases := make([]string, 0, len(a)+len(b))

	for _, id := range strings.Split(a, " ") {
		m.Add(id)

		if idx := strings.Index(id, ":"); idx != -1 {
			aliases = append(aliases, id[:idx])
		}
	}

	for _, id := range strings.Split(b, " ") {
		m.Add(id)

		if idx := strings.Index(id, ":"); idx != -1 {
			aliases = append(aliases, id[:idx])
		}
	}

	for _, alias := range aliases {
		delete(m, alias) // alias take precedence
	}

	for _, r := range remove {
		delete(m, r)
	}

	return strings.Join(m.All(), " ")
}
