package rtc

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/rtc"
	"github.com/Thiink-LLC/teos/go-core/provider"
)

// SimpleCollectionFrameSource is a function that extracts the `*SimpleCollectionFrame` from the pipe context
// and the datapoints in a map.
//
// It will also return the `TZ`, `PID`, `TID`, `LID` and `T` as datapoints.
func SimpleCollectionFrameSource(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	rid []string,
	cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error) {
	// Extract the event from the pipe context
	evt, ok := pipeCtx[ifprovider.PipeContextKeyEvent]
	if !ok {
		return nil, nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorFailToFindEventInPipeContext, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Missing event in pipe context",
		)
	}

	event, ok := evt.(*rtc.SimpleCollectionFrame)
	if !ok {
		return nil, nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorPipeContextEventUnexpectedType, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting *rtc.SimpleCollectionFrame, got %T", evt,
		)
	}

	if op.GetParamsAsBool("dryrun") {
		ctx.SetValue(provider.ProviderCtxDryRun, true)
	}

	if len(event.Dp) == 0 {
		return nil, nil, nil, cberror.NewCbErrorfWithProps(
			ctx.Service(), cberror.ErrorProviderEventPayloadNotFound, nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting datapoints in event but got none",
		)
	}

	source := rtc.ToDataPoints(event.Dp)

	return source, event, nil, nil
}
