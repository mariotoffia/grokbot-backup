package svprovider

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// This file is the worked example for translating sensor readings with a policy
// rather than with the mapping table and the generator expressions.
//
// It runs the real provider end to end against the profile
// testdata/provider-config/policy-mapping.json, whose pipeline calls the policy
// in testdata/policies/svmap.rego. Four things are demonstrated, in increasing
// order of difficulty:
//
//  1. dropping a reading that is outside its allowed range, which is what the
//     policy step has always done
//  2. correcting a reading by a calibration offset held in configuration
//  3. deriving a reading from two other readings
//  4. deriving a reading by aggregating every reading whose name matches a pattern
//
// Only the first is possible with the mapping table and the expressions. The
// other three need a rule, because they depend on more than the one reading
// being translated.

// runPolicyMappingProfile executes the provider against the policy-mapping
// profile and returns nothing -- the outcome is left in the package level
// targetLocation, which is how every test in this package reads the result.
func runPolicyMappingProfile(t *testing.T, wantedSensors string) {
	t.Helper()

	os.Args = []string{"svninbound",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	conf := fmt.Sprintf(`{
		"profile": "policy-mapping",
		"prms": {
			"LOG": "off",
			"MID": "%s",
			"CRD": "", "BID": "Policy Mapping Test",
			"PID": "1234",
			"TID": "1"
		}
	}`, wantedSensors)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	data := fmt.Sprintf(`{
		"result": true,
		"config": [ "%s" ]
	}`, jsonutils.JSONEscape(conf))

	targetLocation = nil

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	require.NotNil(t, targetLocation, "the provider produced no building document")
}

// TestPolicyMapping_DropsReadingOutsideItsRange is the capability the policy step
// already had before any of the derivation rules existed.
func TestPolicyMapping_DropsReadingOutsideItsRange(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(-40), nil).
		Value("MPST", float64(60), nil).
		Value("MPRT", float64(40), nil)

	runPolicyMappingProfile(t, "ODT MPST MPRT")

	assert.NotContains(t, targetLocation.Sensors, "ODT",
		"-40 is outside the configured range for ODT")
	assert.Contains(t, targetLocation.Sensors, "MPST")
}

// TestPolicyMapping_AppliesCalibrationOffset shows a rule correcting a value
// using a number held in the provider configuration rather than in the rule.
func TestPolicyMapping_AppliesCalibrationOffset(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("ODT", float64(10), nil).
		Value("MPST", float64(60), nil).
		Value("MPRT", float64(40), nil)

	runPolicyMappingProfile(t, "ODT MPST MPRT")

	assert.InDelta(t, 8.5, targetLocation.Sensors["ODT"], 0.0001,
		"ODT carries a calibration offset of -1.5 in the configuration")
	assert.InDelta(t, 60.0, targetLocation.Sensors["MPST"], 0.0001,
		"MPST has no calibration offset and must be untouched")
}

// TestPolicyMapping_DerivesReadingFromTwoOtherReadings is the case the generator
// expressions cannot express, because an expression sees one reading at a time.
func TestPolicyMapping_DerivesReadingFromTwoOtherReadings(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("MPST", float64(60), nil).
		Value("MPRT", float64(40), nil)

	runPolicyMappingProfile(t, "MPST MPRT")

	assert.InDelta(t, 20.0, targetLocation.Sensors["DELTA"], 0.0001,
		"DELTA is the flow temperature minus the return temperature")
}

// TestPolicyMapping_ClampsDerivedReadingAtZero shows a derived reading carrying a
// condition of its own.
func TestPolicyMapping_ClampsDerivedReadingAtZero(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("MPST", float64(40), nil).
		Value("MPRT", float64(60), nil)

	runPolicyMappingProfile(t, "MPST MPRT")

	assert.InDelta(t, 0.0, targetLocation.Sensors["DELTA"], 0.0001,
		"a return warmer than the flow must report zero, not a negative number")
}

// TestPolicyMapping_SkipsDerivationWhenAnInputIsMissing shows what happens when a
// rule cannot fire: nothing is written, and nothing fails.
func TestPolicyMapping_SkipsDerivationWhenAnInputIsMissing(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("MPST", float64(60), nil)

	runPolicyMappingProfile(t, "MPST")

	assert.NotContains(t, targetLocation.Sensors, "DELTA",
		"the return temperature was never reported, so there is nothing to derive from")
	assert.InDelta(t, 60.0, targetLocation.Sensors["MPST"], 0.0001)
}

// TestPolicyMapping_AveragesEveryIndoorReading is the most involved case: the rule
// walks the whole document, selects readings by the shape of their name, and
// reduces them to one number.
func TestPolicyMapping_AveragesEveryIndoorReading(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(21), nil).
		Value("IDT_O3", float64(22), nil)

	runPolicyMappingProfile(t, "IDT_O1 IDT_O2 IDT_O3")

	assert.InDelta(t, 21.0, targetLocation.Sensors["IDT"], 0.0001,
		"IDT is the average of the three indoor readings")
}

// TestPolicyMapping_AverageIgnoresOutOfRangeReadings pins the rule that every rule
// reads the document as it arrived. A rule does not see the edits another rule
// made, so a rule that must ignore a bad reading has to say so itself.
func TestPolicyMapping_AverageIgnoresOutOfRangeReadings(t *testing.T) {
	datapointList = NewDataPointList("1234").
		Value("IDT_O1", float64(20), nil).
		Value("IDT_O2", float64(22), nil).
		Value("IDT_O3", float64(-669), nil)

	runPolicyMappingProfile(t, "IDT_O1 IDT_O2 IDT_O3")

	assert.NotContains(t, targetLocation.Sensors, "IDT_O3",
		"-669 is outside the configured range and is dropped")
	assert.InDelta(t, 21.0, targetLocation.Sensors["IDT"], 0.0001,
		"the average must be of the two usable readings only")
}
