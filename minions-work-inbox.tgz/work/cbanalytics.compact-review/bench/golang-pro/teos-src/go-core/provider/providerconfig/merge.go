package providerconfig

import (
	"maps"
	"slices"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/maputils"
)

// ProfileMerger is a helper to merge profiles since it needs special handling while
// merging the mapping section and other parts of the profile.
type ProfileMerger int

// midkey is the key for the mapping section in the profile.
const midkey = string(ifprovider.ParameterMappingIDs)

// EnabledSensorMappings will extract the sensor mappings from the profile.
func (pfm ProfileMerger) EnabledSensorMappings(
	profile *providermodel.ProviderConfigImpl,
) []string {
	if profile == nil {
		return nil
	}

	mid, _ := profile.GetParamAsString(midkey)
	if len(mid) == 0 {
		return nil
	}

	return strings.Split(mid, " ")
}

// FilterMappingSection will filter the mapping section based on the list of sensor IDs.
//
// NOTE: The sensor IDs needs to be fully resolved and hence cannot include any glob or regexp patterns.
//
// The returned `map` contains all mappings that are valid base on the list of sensor IDs. This
// function will always return a valid `map` even if no mappings are found.
//
// If the _all_ is set to `true` and no _sensors_ are provided, the entire mapping section is returned.
func (pfm ProfileMerger) FilterMappingSection(
	all bool,
	mappings map[string]string,
	sensors []string,
) map[string]string {

	filtered := map[string]string{}
	if len(mappings) == 0 {
		return nil
	}

	if all && len(sensors) == 0 {
		return mappings
	}

	for _, sensor := range sensors {
		if v, ok := mappings[sensor]; ok {
			filtered[sensor] = v
		}
	}

	return filtered
}

// MergeFrom will merge data from the _from_ argument into the _to_ config of which is also
// returned.
//
// If the _to_ argument is `nil`, the _from_ argument is cloned and returned.
//
// CAUTION: The returned profile may need to be post processed to handle alias or filtering of _MID_ or _map_
// sections using the mapping resolver.
func (pfm ProfileMerger) MergeFrom(
	from, to /*cloned*/ *providermodel.ProviderConfigImpl,
) *providermodel.ProviderConfigImpl {
	if nil == to {
		return from.Clone()
	}

	to.Profile = from.Profile

	if from.Owner != "" {
		to.Owner = from.Owner
	}

	to.Params = pfm.mergeGlobalParams(from.Params, to.Params)

	// Resolve any MID aliases before handling MID and mapping sections.
	pfm.resolveMIDAliases(from, to)

	// If we have mapping in the incoming merge profile -> add those automatically
	// to the provider profile mid. This is avoid specifying both map and mid on
	// the incoming profile (configuration).
	mid, _ := to.GetParamAsString(string(ifprovider.ParameterMappingIDs))
	m := strings.Split(mid, " ")

	if len(m) > 0 {
		for k := range from.Map {
			if !slices.Contains(m, k) {
				if len(mid) > 0 {
					mid += " " + k
				} else {
					mid = k
				}
			}
		}

		if len(mid) > 0 {
			to.Params[string(ifprovider.ParameterMappingIDs)] = mid
		}
	}

	to.Map = utils.ShallowCopyStringMap(to.Map, from.Map)
	to.Filter = utils.ShallowCopyStringMap(to.Filter, from.Filter)
	to.PolicyData = utils.ShallowCopyStringMap(to.PolicyData, from.PolicyData)
	to.Generate = utils.ShallowCopyStringMap(to.Generate, from.Generate)
	to.GenProtoTemplates = utils.ShallowCopyStringMap(to.GenProtoTemplates, from.GenProtoTemplates)
	to.GenProto = pfm.mergeGeneratorPrototypes(from.GenProto, to.GenProto)
	to.GenProtoTs = pfm.mergeGeneratorPrototypes(from.GenProtoTs, to.GenProtoTs)
	to.Pipe = utils.ShallowCopyStringMap(to.Pipe, from.Pipe)
	to.SourceInstruction = pfm.mergeSourceInstruction(from.SourceInstruction, to.SourceInstruction)

	if nil != from.Operation {
		if nil == to.Operation {
			to.Operation = map[string]providermodel.Operation{}
		}

		for key, value := range from.Operation {
			if obj, ok := to.Operation[key]; ok {
				to.Operation[key] = *pfm.mergeOperations(&value, obj.Clone())
			} else {
				to.Operation[key] = *value.Clone()
			}
		}
	}

	return to
}

// mergeSourceInstruction will merge the `providermodel.BaseProfileImpl.SourceInstruction` from the _from_ into the _to_ (if any).
//
// It will allow the from to overwrite individual entries or even properties on object.
//
// NOTE: It will only shallow clone the maps.
func (pfm ProfileMerger) mergeSourceInstruction(
	from, to *providermodel.SourceInstruction,
) *providermodel.SourceInstruction {
	if nil == from {
		return to
	}

	if nil == to {
		return &providermodel.SourceInstruction{
			Select: maps.Clone(from.Select),
		}
	}

	for ds, fromSel := range from.Select {
		toSel, ok := to.Select[ds]

		if !ok {
			to.Select[ds] = fromSel
			continue
		}

		if fromSel.DataSetType != "" {
			toSel.DataSetType = fromSel.DataSetType
			to.Select[ds] = toSel
		}

		for re, fromSo := range fromSel.Selectors {
			toSo, ok := to.Select[ds].Selectors[re]

			if !ok {
				to.Select[ds].Selectors[re] = fromSo
				continue
			}

			if fromSo.TeosId != "" {
				toSo.TeosId = fromSo.TeosId
			}

			if fromSo.Expression != "" {
				toSo.Expression = fromSo.Expression
			}

			if fromSo.Lang != "" {
				toSo.Lang = fromSo.Lang
			}

			to.Select[ds].Selectors[re] = toSo
		}
	}

	return to
}

// mergeOperations will merge the _from_ into the _to_ and
// return the _to_ object.
func (pfm ProfileMerger) mergeOperations(
	from, to *providermodel.Operation,
) *providermodel.Operation {
	if nil == to {
		return from.Clone()
	}

	if from.Operation != "" {
		to.Operation = from.Operation
	}

	to.Params = utils.ShallowCopyMap(to.Params, from.Params)

	return to
}

// mergeGeneratorPrototypes do special handling
// since it will merge each instruction separately and do not
// overwrite completely the main key.
func (pfm ProfileMerger) mergeGeneratorPrototypes(
	from map[string]providermodel.GeneratorPrototypeImpl,
	to map[string]providermodel.GeneratorPrototypeImpl,
) map[string]providermodel.GeneratorPrototypeImpl {
	if nil == from {
		return to
	}

	if nil == to {
		to = map[string]providermodel.GeneratorPrototypeImpl{}
	}

	for key, value := range from {
		if _, ok := to[key]; !ok {
			to[key] = value
			continue
		}

		c := to[key]

		for id, prototype := range value {
			c[id] = prototype
		}
	}

	return to
}

func (pfm ProfileMerger) mergeGlobalParams(
	from map[string]interface{},
	to map[string]interface{}) map[string]interface{} {
	if nil == from {
		return to
	}

	if nil == to {
		to = map[string]interface{}{}
	}

	providerRequiredGPID := string(ifprovider.ParameterProviderRequiredGeneratorProtoTypeIDs)

	for key, value := range from {
		if key == providerRequiredGPID {
			// Cannot be overwritten by external configuration
			continue
		}

		// Special case where original, in this case cloned
		// may also have some default that needs to be kept
		if key == midkey {
			if midValue, ok := to[midkey]; ok {
				if mid, ok := midValue.(string); ok && len(mid) > 0 {
					if midMerged, ok := value.(string); ok {
						if len(midMerged) > 0 {
							to[key] = midMerged + " " + mid
						} else {
							to[key] = mid
						}

						continue
					}
				}
			}
		}

		if m, ok := to[key]; ok {
			if mt, ok := m.(map[string]any); ok {
				if mf, ok := value.(map[string]any); ok {
					to[key] = maputils.Merge(mf, mt)
					continue
				}
			}
		}

		to[key] = value
	}

	return to
}

// resolveMIDAliases will take mid from merge and pc and check if
// alias -> check merge.Map and pc.Map to replace the alias in mapping section
// in one or both of them and remove the alias value from the mapping section.
//
// An alias is <alias>:<TeosID> e.g. `MFPS:MFPS_C1_O1` or `MFPS:MFPS_C2_O14`
func (pfm ProfileMerger) resolveMIDAliases(from, to *providermodel.ProviderConfigImpl) {
	toMID, foundToMID := to.GetParamAsString(string(ifprovider.ParameterMappingIDs))
	fromMID, foundFromMID := from.GetParamAsString(string(ifprovider.ParameterMappingIDs))

	if !strings.Contains(toMID, ":") && !strings.Contains(fromMID, ":") {
		// No alias in MID
		return
	}

	// Create a map with all MID sensor IDs both from the from and to MID string
	toMidMap := map[string]string{}

	for _, sensorID := range strings.Split(toMID, " ") {
		toMidMap[sensorID] = sensorID
	}

	if len(fromMID) > 0 {
		for _, sensorID := range strings.Split(fromMID, " ") {
			toMidMap[sensorID] = sensorID
		}
	}

	// Extract all alias _TeosID_ from mapping section and replace them
	// in mapping section with the alias.
	for _, sensorID := range toMidMap {
		if strings.Contains(sensorID, ":") {
			// Alias
			alias := strings.Split(sensorID, ":")[0]
			teosID := strings.Split(sensorID, ":")[1]

			// Replace alias expression in the MID section with the alias
			if foundFromMID {
				fromMID = strings.Replace(fromMID, sensorID, alias, 1)
			}

			if foundToMID {
				toMID = strings.Replace(toMID, sensorID, alias, 1)
			}

			// Replace TeosID, in mapping section, with the alias instead
			if v, ok := from.Map[teosID]; ok {
				delete(from.Map, teosID)
				from.Map[alias] = v
			}

			if v, ok := to.Map[teosID]; ok {
				delete(to.Map, teosID)
				to.Map[alias] = v
			}
		}
	}

	if foundFromMID {
		from.Params[string(ifprovider.ParameterMappingIDs)] = fromMID
	}

	if foundToMID {
		to.Params[string(ifprovider.ParameterMappingIDs)] = toMID
	}
}
