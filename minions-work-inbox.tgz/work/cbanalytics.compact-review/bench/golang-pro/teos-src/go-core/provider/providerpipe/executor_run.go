package providerpipe

import (
	"text/template"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// prepare will create a new instance of the provider context to be used in the pipeline along with the _JSON_ pipeline template. This
// result is used to do a createPipe() call.
//
// Since the _JSON_ pipeline is rendered using go template, the `template.Template` is returned. If any errors parsing the template
// it will return an error with code _1813_. The provider context it created and merged with any `OverrideContext()` and registers
// default types (under context key \_ts). This may be used to be referenced under generator, _marshal_, section of the `ProviderConfig`.
//
// NOTE: It is possible to register custom types under \_ts using the `OverrideContext()` and provide a `map[string]interface{}` with root key \_ts
// and in this map register types e.g. `"dsv": dsmodel.DsBuilding{}`.
//
// .Default Type Registration
// |===
// |Type |Key Name
//
// |dsmodel.DsBuilding
// |dsv
//
// |===
//
// This function will `providerconfig.LoadContext()` to resolve the `ProviderConfig.Params` section and setup the template via
// `providerconfig.SetupTemplate()` before parsing the template with template taken from `ProviderConfig.Pipe` keyed with the
// `UseOperation()`.
//
// TIP: If a custom `pipe` is wanted, provide this in the `UseConfig()`, otherwise the provider default is used.
func (p *ProviderPipelineExecutor) prepare(
	mappingDirection providermodel.MappingDirection,
) (providerCtx map[string]interface{}, pipeTemplate *template.Template) {
	if p.err != nil {
		return
	}

	tsm := map[string]interface{}{
		"dsv": dsmodel.DsBuilding{},
	}

	providerCtx = map[string]interface{}{
		"_cfg": map[string]interface{}{},
		"_ts":  tsm,
	}

	if p.filters != nil {
		if filters, ok := p.filters[p.operation]; ok {
			providerCtx["_filter"] = filters
		}
	}

	if len(p.mergedProviderCtx) > 0 {
		for k, v := range p.mergedProviderCtx {
			if k == "_ts" {
				for tk, tv := range p.mergedProviderCtx[k].(map[string]interface{}) {
					tsm[tk] = tv
				}
			} else {
				providerCtx[k] = v
			}
		}
	}

	generatorTemplate, delayedGeneratorTemplate, err := providerconfig.CreateGeneratorTemplate(
		p.pipe.context,
		p.config,
		p.operation, p.operation,
		p.logging,
		providerCtx,
	)
	if err != nil {
		p.err = err
		return
	}

	c, _ := providerCtx["_cfg"].(map[string]interface{})
	c["delayedGeneratorTemplate"] = delayedGeneratorTemplate
	c["mappingDirection"] = mappingDirection
	c["operation"] = p.operation

	if generatorTemplate != "" {
		providerCtx[p.operation] = generatorTemplate
	}

	_ = providerconfig.ResolvePipeContextFromGlobals(
		p.pipe.context, p.config, providerCtx, nil /*input*/, false, /*allowMutate*/
	)

	mode := p.config.GetParamAsStringWithDefault(
		string(ifprovider.ParameterGeneratorTemplateMode),
		"",
	)

	if mode == "" {
		// Default to fail
		mode = "fail"
	}

	var terr error
	pipeTemplate, terr = providerconfig.ResolveTemplate(
		p.config,
		p.operation,
		p.operation,
		mode,
		mappingDirection,
		delayedGeneratorTemplate,
		template.FuncMap{},
		providerCtx,
	).Parse(p.config.Pipe[p.operation])

	if nil != terr {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(), cberror.ErrorProviderUnableToSetupTemplate, terr,
			"Failed to setup template for config %#v, operation %s", p.config, p.operation,
		)
	}

	return
}

// execute will invoke the `UseOperationFunction` and then the _executorPipe_.
//
// 1. This function will resolve the operation (and set  this instance to error if it fails to resolve it, error code _1899_ since
// it is a evaluation problem).
// 2. It then call the provider `ObtainCredentialsFunction` to obtain credentials that will be stored under context key _"cred"_.
// If fails, it errors this instance with code _1819_ (if CRED Param is not of string type) or custom code sent by provider.
// 3. If credentials was obtained successfully, it verifies that the DNS or IP that this operation is targeting is the same as the credential.
// If such is not the case, this will set error state with code _1820_.
// 4. Now, the Authentication part of the `Operation` is resolved (since we may have a credential object in context _cred_ key).
// 5. Then it invokes the operation function to populate the pipe context with source data. If it fails it will set the error state
// with the error returned from the operation function.
// 6. It will the execute the actual _executorPipe_. If it fails to resolve, e.g. pending executions, it sets the error state with code _1816_.
// 7. After a successful execution, it extracts the _target_ parameter in context and makes sure it is of `map[string]interface{}`. If no _target_
// is found it sets the error state with code _1817_ and if it is of wrong type, error code _1818_.
//
// If everything is ok, a `map[string]interface{}` with the processed result is returned.
//
// WARNING: `execute` will modify the _providerCtx_ and hence, if re-run, this needs to be re-created using `prepare`.
//
// The default behavior is to write a `map[string]interface{}` into key _target_, in pipe context, this is then extracted and returned. If
// any object is marshalled, it is also written into _target_ of the returned `map`. In order to extract the _struct_, use the _target_ key.
//
// .Example Extracting DsBuilding
// [source,go]
// ----
//
//	func extractTarget(res map[string]interface{}) *dsmodel.DsBuilding {
//		errorMessage := ""
//		var target *dsmodel.DsBuilding
//
//		if trg, ok := res["target"]; ok {
//			if tempTarget, ok := trg.(*dsmodel.DsBuilding); ok {
//				return nil
//	     }
//	 }
//
//	 return nil
//	}
//
// ----
//
// TIP: Therefore there exists a utility function to provide this functionality `providerpipe.ExtractDsBuilding()`.
//
// If a `UseTarget` function has been attached it will be invoked when a successful pipe execution and target extraction. If the `TargetFunction`
// returns an error, it will be set as the error state, *but* the resulting target `map` is still returned!
func (p *ProviderPipelineExecutor) execute(
	providerCtx map[string]interface{},
	prog *cbpipeline.Program,
) map[string]interface{} {
	if p.err != nil {
		return map[string]interface{}{}
	}

	op, err := providerconfig.ResolveOperation(
		p.pipe.context,
		p.config,
		p.operation,
		providerCtx,
		nil, /*input*/
	)
	if err != nil {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(), cberror.ErrorProviderUnableExecutePipeline, err,
			"Failed to resolve operation: %s, error: %s", p.operation, err.Error(),
		)

		return nil
	}

	credentials, err := p.pipe.obtainCredentialsInvocation(
		locationmodel.ProviderOperation(p.operation),
		p.config,
		providerCtx,
		op,
	)
	if err != nil {
		p.err = err
		return nil
	}

	if credentials != nil {
		if !p.pipe.verifyConnectInvocation(p.config, op, credentials) {
			if p.logging {
				if l, ok := logger.ClsLog(zerolog.WarnLevel, "pipe.execute", logger.LDTUntyped, logger.LISUnclassified, p.pipe.context); ok {
					l.Msgf(
						"The target: %s in item: %v, is not the same as in credentials (resolved by '%s') (fishing attempt?)",
						op.Operation,
						op,
						p.config.Params[string(ifprovider.ParameterCredentials)],
					)
				}
			}

			p.err = cberror.NewCbErrorf(
				p.pipe.context.Service(),
				cberror.ErrorProviderUnableExecutePipeline,
				nil,
				"The target: %s in item: %v, is not the same as in credentials (resolved by '%s') (fishing attempt?)",
				op.Operation,
				op,
				p.config.Params[string(ifprovider.ParameterCredentials)],
			)

			return nil
		}
	}

	operationResult, err := p.sourceFunc(
		p.pipe.context, op.Operation, op,
		p.config, providerCtx, credentials,
	)

	if err != nil {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(), cberror.ErrorProviderUnableExecutePipeline, err,
			"Could not obtain data from provider, error: %s", err.Error(),
		)

		return nil
	}

	// Copy result into the pipeline context
	for k, v := range operationResult {
		providerCtx[k] = v
	}

	locationID := p.config.GetParamAsStringWithDefault(
		string(ifprovider.ParameterLocationID), "")

	result, err := prog.Run(
		p.pipe.context, runOptions(p.pipe.context, locationID, providerCtx)...,
	)

	if p.logging && log.IsEnabled(zerolog.TraceLevel) {
		providerutils.SafeLogPipeContext(
			log.Trace(p.pipe.context), result.Vars,
		).
			Msg("Executed pipe, and the contents of the pipeCtx is in [body]")
	}

	if nil != err {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(), cberror.ErrorProviderUnableToCreatePipeRunner, err,
			"Failed to execute pipeline, error: %s", err.Error(),
		)

		return nil
	}

	// Extract the result of the generator
	pipeCtx := result.Vars
	trg := pipeCtx["target"]
	if nil == trg {
		p.err = cberror.NewCbErrorf(
			p.pipe.context.Service(), cberror.ErrorProviderUnableToExtractTarget, nil,
			"Failed to extract target, config %#v", p.config,
		)

		return nil
	}

	var targetResult map[string]interface{}
	if tm, ok := trg.(map[string]interface{}); ok {
		targetResult = tm
	} else {
		targetResult = map[string]interface{}{"target": trg}
	}

	if p.logging && log.IsEnabled(zerolog.TraceLevel) {
		log.Trace(p.pipe.context).
			WithBody(trg).
			Msgf("Get result (in context target property) of type: %T", trg)
	}

	if p.targetFunc != nil {
		err = p.targetFunc(
			p.pipe.context,
			p.operation,
			op,
			p.config,
			pipeCtx,
			credentials,
			targetResult,
		)

		if nil != err {
			p.err = cberror.NewCbErrorf(
				p.pipe.context.Service(), cberror.ErrorProviderTargetFunctionError, err,
				"Provider target function returned error, error: %s", err.Error(),
			)
		}
	}

	return targetResult
}
