package svprovider

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

const (
	// CapsProviderSVIPluginImportSensorValues denotes that the plugin will completely take over
	// the `ImportSensorValues` function and hence expects to get invoked on that function only.
	CapsProviderSVIPluginImportSensorValues string = "provider.svop.ImportSensorValues"
)

// SensorValuesInboundPlugin is a plugin imports data from a remote endpoint to to thiink.
//
// This is the base interface where different types of sub plugins for sensor values import implement.
type SensorValuesInboundPlugin interface {
	// CapsProvider implementation since this is a requirement for any plugin.
	provider.Provider
}

// SensorValuesInboundPluginDsBuilding is a imports data from a remote endpoint to to thiink device shadow building.
type SensorValuesInboundPluginDsBuilding interface {
	// SensorValuesInboundPlugin is always the base type for `SensorValuesInboundPlugin`(s).
	SensorValuesInboundPlugin
	// PipelineAwareProvider since a plugin is always aware of the pipeline (except if custom `TODO:!!`)
	provider.PipelineAwareProvider
	// SourceFunc is the one responsible to fetch the data that getting processed in the pipeline.
	//
	// .Sample Source Function
	// [source,go]
	// ----
	// data, _ := restClient.FetchSensorDataFromRemoteEndpoint(eop, cred) // <1>
	// return map[string]interface{}{"src": data}, nil // <2>
	// ----
	// <1> Fetch the data using the supplied credentials and operation data such as url, parameters.
	// <2> Return the data as list in _src_ since it shall always contains the raw data.
	//
	// It is possible also return directly a map in _source_ property. However, the sample above requires a template
	// that makes sure to populate the _source_ property.
	//
	// .Populate the Source Property
	// [source,json]
	// ----
	// "set-provider": {
	//		"source": "=asmap(src.Values, 'DatapointID')" // <1>
	//	},
	// ----
	// <1> This will copy the list values as a map into the _source_ context entry using the `DatapointID` as the key.
	//
	// Mock data is the extracted data that matches the instruction index.
	SourceFunc(context ifcore.CbContext,
		exec *providerpipe.ProviderPipelineExecutor,
		evt *cbevent.SensorValueInboundEvent) providerpipe.SourceFunction

	// TargetFunc gets invoked when the pipeline has executed on the `SourceFunc`, source, material and wished to update
	// the thiink platform with the information.
	//
	// The data shall reside in the _target_ map, and by convention, the _target_ *key* in the map. If no target function
	// is specified it will use the `providerpipe.ExtractDsBuilding(target)` to extract the `dsmodel.DsBuilding` and then
	// update the device shadow as reported.
	//
	// .Example Target Function
	// [source,go]
	// ----
	// func(eop *providermodel.OperationImpl, pc *providermodel.ProviderConfigImpl,
	//		cred interface{}, target map[string]interface{}) cberror.Error {
	//
	//   dryrun := utils.GetBoolFromContext(context, provider.ProviderCtxDryRun) // <1>
	//   ep := utils.GetURLFromContext(context, provider.ProviderCtxEndpoint)
	//
	//   buildingID := exec.Config().GetParamAsString(string(providermodel.ParameterLocationID)) // <2>
	//
	//   ds := providerpipe.ExtractDsBuilding(target) // <3>
	//
	//   providerpipe.ReportDsBuilding(context, "myProviderName", buildingID, ep,
	//                                 awsmgriot.NewAWSDSManager(context), ds, dryrun) // <3>
	// }
	// ----
	// <1> Extract the runtime well known parameters from the context such as _dryrun_ and the device shadow endpoint, _ep_.
	// <2> Extract the _buildingID_ either from main _Params_ or if provider uses "local" _Operation.Params_ instead.
	// <3> Reports the `dsmodel.DsBuilding` that was produced in the pipeline to as state: reported in the device shadow.
	//
	// If the providers maps the _BID_ Params to it's operation, it is possible to use extract the _buildingID_ via the
	// operation receiver `eop.GetParamAsString(string(providermodel.ParameterLocationID)`. Default function will use
	// the global _Params_ variable.
	TargetFunc(context ifcore.CbContext,
		exec *providerpipe.ProviderPipelineExecutor,
		evt *cbevent.SensorValueInboundEvent) providerpipe.TargetFunction
}

// SensorValuesInboundPluginExt is for advanced scenarios where most of the work is manual
// in the plugin.
type SensorValuesInboundPluginExt interface {
	// ImportSensorValues is for plugins that do want to handle the process from A - Z
	// for them selves.
	//
	// This requires that the plugin exposes the _CapsProviderSVIPluginImportSensorValues_ capability.
	// This function will be invoked either if it run as a shell _command_ or as a standard lambda, including
	// as a queue trigger lambda. If lambda is batched, the plugin will get one event at the time.
	//
	// If the function returns error and there are still events in queue, those will be sent before returning
	// the error to invoker of lambda / shell.
	//
	// NOTE: Make sure that `ImportSensorValues` is idempotent since it may be invoked at least once!
	//
	// The _context_ is the fresh context for this invocation, or batch of invocations. The _evt_ is the
	// `cbevent.SensorValueInboundEvent` that needs to be processed. If an endpoint is set, it is present
	// in the events _Endpoint_ property (even if set by environment variable or by flag).
	//
	// If any error occur that shall make this event to be *re-submitted* should be returned. Otherwise if
	// error but do not want to receive the event again, return `nil`. But as stated above, it might get
	// invoked again with the same event anyway and should be prepared for it.
	ImportSensorValues(context ifcore.CbContext,
		evt *cbevent.SensorValueInboundEvent) cberror.Error
}
