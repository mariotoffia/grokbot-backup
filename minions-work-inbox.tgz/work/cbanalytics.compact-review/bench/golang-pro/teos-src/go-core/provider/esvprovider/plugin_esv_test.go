package esvprovider

import (
	"bufio"
	"embed"
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"strings"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/ahmetb/go-linq/v3"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbevent"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// TestMain applies the unit-test settings to every test in this package. The
// plugins the tests run build their own context the way a provider does.
func TestMain(m *testing.M) {
	os.Exit(testenv.Run(m, testenv.EnvDefaults))
}

//go:embed testdata/provider-config/*.*
var providerConfig embed.FS

//go:embed testdata/policies/*.*
var policies embed.FS

//go:embed testdata/pdp-config/*.*
var pdpConfig embed.FS

type UpdateDataPointList struct {
	Values []*eqmodel.CbDataPointImpl `json:"values"`
}

type testProvider int

func (tp testProvider) Name() string {
	return "climatixic"
}
func (tp testProvider) GetCapabilities() coremodel.Capabilities {
	return coremodel.Capabilities{
		Caps: []coremodel.Capability{},
	}

}

func (sb testProvider) GetProviderConfigurationFileSystemObject() fs.FS {
	return providerConfig // Only Served from embedded resources
}

func (tp testProvider) OverrideContext() map[string]interface{} {
	return nil // Not used
}

func (tp testProvider) VerifyConnectFunc(
	context ifcore.CbContext,
	store *config.SessionStore) providerpipe.VerifyConnectFunction {
	return nil // use default
}

var filterFunc = func(data interface{}) (interface{}, error) {
	if upd, ok := data.(*UpdateDataPointList); ok {
		var list []*eqmodel.CbDataPointImpl
		for i, dp := range upd.Values {
			if dp.Value != nil {
				list = append(list, upd.Values[i])
			}
		}

		upd.Values = list
		return upd, nil
	}

	return nil, fmt.Errorf("expected UpdateDataPointList, got: %T", data)
}

// GetFilterFunctions implements the `provider.FilterFunctionContributor` interface.
func (tp testProvider) GetFilterFunctions() map[string]ifprovider.OperationFilters {
	return map[string]ifprovider.OperationFilters{
		"esv": {
			// Filters out all data points that this provider
			// considers to be invalid.
			"std": filterFunc,
		},
	}
}

var globalDatapointList *UpdateDataPointList
var StandardSplitPartitionAndIDFunc = func(id string) (string, string) {
	s := strings.Split(id, ";")
	return s[1] /*id*/, s[0] /*partition*/
}

var splitPartitionAndIDFunc providerutils.SplitPartitionAndID = StandardSplitPartitionAndIDFunc

// cSpell: disable
func (tp testProvider) TargetFunc(context ifcore.CbContext,
	exec *providerpipe.ProviderPipelineExecutor,
	evt *cbevent.SensorValueOutboundEvent) providerpipe.TargetFunction {
	return func(
		context ifcore.CbContext,
		operation string,
		eop *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred interface{}, target map[string]interface{}) cberror.Error {
		if trg, ok := target["target"]; ok {
			if target, ok := trg.(*UpdateDataPointList); ok {
				globalDatapointList = target

				if err := providerutils.DataPointReport(context,
					&providerutils.ReportContext{
						Operation:               eop,
						ProviderConfig:          pc,
						ProviderOperation:       locationmodel.ProviderOperationSensorValueOut,
						DataPoints:              eqmodel.ToCbDataPointSlice(target.Values),
						MapperWithoutPartition:  true, /*we dont use PID in mapping segment*/
						SplitPartitionAndIDFunc: splitPartitionAndIDFunc,
					}); err != nil {
					return err
				}
			}
		}

		target[SensorValueTargetFuncShallUpdateDsBuilding] = true // report to the device shadow

		return nil
	}
}

func (tp testProvider) GetTargetType() interface{} {
	return &UpdateDataPointList{}

}

func (tp testProvider) SourceFunc(context ifcore.CbContext,
	exec *providerpipe.ProviderPipelineExecutor,
	evt *cbevent.SensorValueOutboundEvent) providerpipe.SourceFunction {
	return nil // use default function
}

// cSpell: enable

// GetPolicyRetrievalPoints implements `StaticPolicyRetrievalPointContributingProvider` interface.
func (tp testProvider) GetPolicyRetrievalPoints() []ifcore.PolicyRetrievalPoint {
	return []ifcore.PolicyRetrievalPoint{
		cbpolicy.NewImmutablePRP(nil /*noKey*/).RegisterFsModules(policies),
	}

}

// GetPDPConfigFSys implements `StaticPolicyDecisionPointContributingProvider` interface.
func (tp testProvider) GetPDPConfigFSys() []fs.FS {
	return []fs.FS{pdpConfig}

}

var logLevel = "fatal"

func TestUnmarshalEgressEvent(t *testing.T) {
	data := "{\"corr\":\"\",\"provider\":\"rtc\",\"config\":[{\"loc\":{\"type\":\"actuation\"},\"map\":{\"ACTSPSSHCT\":\"ACTSPSSHCT\",\"COMT\":\"COMT\"},\"prms\":{\"BID\":\"Skråfsan 24 (bravidatest)\",\"OID\":\"Nordvestor\",\"OPT\":\"AVGIDC MINIDC MAXIDC\",\"TRG\":\"bravidatest:dps:sqsrtc building:dsbld:ds\"},\"profile\":\"generic\"}],\"payload\":{\"version\":2287,\"timestamp\":1718041315,\"clientToken\":\"climatecontrol:uhp7l7:cc-evt:outbound\",\"topic\":\"$aws/things/Skr_C3_A5fsan_2024_20_28bravidatest_29/shadow/name/building/update/accepted\",\"state\":{\"reported\":{},\"desired\":{\"sensors\":{\"ACTSPSSHCT\":30.2}},\"delta\":{}},\"metadata\":{\"reported\":{\"tz\":{\"timestamp\":-62135596800}},\"desired\":{\"tz\":{\"timestamp\":-62135596800},\"sensors\":{\"ACTSPSSHCT\":{\"timestamp\":1718041315}}}}},\"payloadtype\":\"dsbuilding\",\"ds\":{\"version\":2287,\"timestamp\":1718041315,\"clientToken\":\"climatecontrol:uhp7l7:cc-evt:outbound\",\"topic\":\"$aws/things/Skr_C3_A5fsan_2024_20_28bravidatest_29/shadow/name/building/update/accepted\",\"state\":{\"reported\":{},\"desired\":{\"sensors\":{\"ACTSPSSHCT\":30.2}},\"delta\":{}},\"metadata\":{\"reported\":{\"tz\":{\"timestamp\":-62135596800}},\"desired\":{\"tz\":{\"timestamp\":-62135596800},\"sensors\":{\"ACTSPSSHCT\":{\"timestamp\":1718041315}}}}}}"

	var evt cbevent.SensorValueOutboundEvent

	err := json.Unmarshal([]byte(data), &evt)

	require.NoError(t, err)
}
func TestSamplePluginSuccess(t *testing.T) {
	os.Args = []string{"esv",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	lid := "Måssmyren 18"

	smallConf := fmt.Sprintf(`{
			"profile": "proto",
			"prms": {
				"LOG": "on","MID": "IDT_O1 IDT_O2 COMT OFFODT",
				"CRD": "", "BID": "%s", "PID": "1234", "TID": "1"
			}
		}`, lid)

	var data = fmt.Sprintf(`{
			"provider": "climatixic-esv",
			"result": true,
			"config": ["%s"],
			"ds": { "state": { "desired": { "sensors": { "OFFODT":1.47, "IDT_O1": 10, "IDT_O2": 20 } } },
				"topic": "$aws/things/%s/shadow/name/building/update/accepted"
			}
		}`, jsonutils.JSONEscape(smallConf), lid)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	globalDatapointList = nil
	splitPartitionAndIDFunc = StandardSplitPartitionAndIDFunc

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	finder := func(id string) *eqmodel.CbDataPointImpl {
		value := linq.From(globalDatapointList.Values).FirstWith(func(v interface{}) bool {
			return v.(*eqmodel.CbDataPointImpl).ID == id
		}).(*eqmodel.CbDataPointImpl)

		return value
	}

	assert.Equal(t, 4, len(globalDatapointList.Values))
	assert.Equal(t, float64(10), finder("1234;climatixic:IDT_O1").Value)
	assert.Equal(t, float64(20), finder("1234;climatixic:IDT_O2").Value)
	assert.Equal(t, float64(2), finder("1234;climatixic:COMT").Value)
	assert.Equal(t, float64(1.47), finder("1234;climatixic:OFFODT").Value)
}

func TestSamplePluginMissingMandatorySensorsWillOnlyProduceNonNilSensorsWhenFilteredOut(
	t *testing.T,
) {
	os.Args = []string{"esv",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	lid := "Måssmyren 18"

	smallConf := fmt.Sprintf(`{
			"profile": "proto",
			"prms": {
				"LOG": "on","MID": "IDT_O1 IDT_O2 COMT OFFODT",
				"CRD": "", "BID": "%s", "PID": "1234", "TID": "1"
			}
		}`, lid)

	var data = fmt.Sprintf(`{
			"provider": "climatixic-esv",
			"result": true,
			"config": ["%s"],
			"ds": { "state": { "desired": { "sensors": { "OFFODT":1.47} } },
				"topic": "$aws/things/%s/shadow/name/building/update/accepted"
			}
		}`, jsonutils.JSONEscape(smallConf), lid)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	globalDatapointList = nil
	splitPartitionAndIDFunc = StandardSplitPartitionAndIDFunc

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	finder := func(id string) *eqmodel.CbDataPointImpl {
		value := linq.From(globalDatapointList.Values).FirstWith(func(v interface{}) bool {
			return v.(*eqmodel.CbDataPointImpl).ID == id
		})

		if value == nil {
			return nil
		}

		return value.(*eqmodel.CbDataPointImpl)
	}

	assert.Equal(t, 2, len(globalDatapointList.Values))

	assert.True(t, finder("1234;climatixic:IDT_O1") == nil)
	assert.True(t, finder("1234;climatixic:IDT_O2") == nil)

	assert.Equal(t, float64(2), finder("1234;climatixic:COMT").Value)
	assert.Equal(t, float64(1.47), finder("1234;climatixic:OFFODT").Value)
}

func TestSamplePluginMissingMandatorySensorsWillProduceAllSensorsWhenNoopFunc(t *testing.T) {
	os.Args = []string{"esv",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	lid := "Måssmyren 18"

	smallConf := fmt.Sprintf(`{
			"profile": "proto",
			"prms": {
				"LOG": "on","MID": "IDT_O1 IDT_O2 COMT OFFODT",
				"CRD": "", "BID": "%s", "PID": "1234", "TID": "1"
			}
		}`, lid)

	var data = fmt.Sprintf(`{
			"provider": "climatixic-esv",
			"result": true,
			"config": ["%s"],
			"ds": { "state": { "desired": { "sensors": { "OFFODT":1.47} } },
				"topic": "$aws/things/%s/shadow/name/building/update/accepted"
			}
		}`, jsonutils.JSONEscape(smallConf), lid)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	globalDatapointList = nil
	splitPartitionAndIDFunc = StandardSplitPartitionAndIDFunc

	// No Filter
	oldFilterFunc := filterFunc

	defer func() { filterFunc = oldFilterFunc }()

	filterFunc = func(data interface{}) (interface{}, error) { return data, nil }

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	finder := func(id string) *eqmodel.CbDataPointImpl {
		value := linq.From(globalDatapointList.Values).FirstWith(func(v interface{}) bool {
			return v.(*eqmodel.CbDataPointImpl).ID == id
		})

		if value == nil {
			return nil
		}

		return value.(*eqmodel.CbDataPointImpl)
	}

	assert.Equal(t, 4, len(globalDatapointList.Values))

	assert.Equal(t, nil, finder("1234;climatixic:IDT_O1").Value)
	assert.Equal(t, nil, finder("1234;climatixic:IDT_O2").Value)

	assert.Equal(t, float64(2), finder("1234;climatixic:COMT").Value)
	assert.Equal(t, float64(1.47), finder("1234;climatixic:OFFODT").Value)
}

func TestSamplePluginOptionalMissingWithDynamicGeneratorTemplateWillOnlyProduceExistingSensors(
	t *testing.T,
) {

	os.Args = []string{"esv",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	lid := "Måssmyren 20"

	// Set "GTG" is "auto" so this will result in dynamic generator
	smallConf := fmt.Sprintf(`{
			"profile": "proto",
			"prms": {
				"LOG": "on",
				"MID": "IDT_O1 IDT_O2 COMT OFFODT",
				"OPT": "IDT**",
				"CRD": "", "BID": "%s",
				"PID": "1234",
				"TID": "1"
			}
		}`, lid)

	data := fmt.Sprintf(`{
			"provider": "climatixic-esv",
			"result": true,
			"config": ["%s"],
			"ds": { "state": { "desired": { "sensors": { "OFFODT":1.47, "IDT_O1": 10 } } },
				"topic": "$aws/things/%s/shadow/name/building/update/accepted"
			}
		}`, jsonutils.JSONEscape(smallConf), lid)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	globalDatapointList = nil
	splitPartitionAndIDFunc = StandardSplitPartitionAndIDFunc

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	finder := func(id string) *eqmodel.CbDataPointImpl {
		value := linq.From(globalDatapointList.Values).FirstWith(func(v interface{}) bool {
			return v.(*eqmodel.CbDataPointImpl).ID == id
		})

		if value == nil {
			return nil
		}
		v := value.(*eqmodel.CbDataPointImpl)
		return v
	}

	assert.Equal(t, 3, len(globalDatapointList.Values))
	js, _ := json.Marshal(globalDatapointList.Values)
	t.Log(string(js))

	assert.Equal(t, float64(10), finder("1234;climatixic:IDT_O1").Value)
	assert.True(t, finder("1234;climatixic:IDT_O2") == nil)
	assert.Equal(t, float64(2), finder("1234;climatixic:COMT").Value)
	assert.Equal(t, float64(1.47), finder("1234;climatixic:OFFODT").Value)
}

func TestSamplePluginMissingOptionalSensorsWillOnlyBeReportedAsOptionalMissingSensors(
	t *testing.T,
) {
	os.Args = []string{"esv",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	lid := "Måssmyren 18"

	smallConf := fmt.Sprintf(`{
			"profile": "proto",
			"prms": {
				"LOG": "on","MID": "IDT_O1 IDT_O2 COMT OFFODT", "OPT": "IDT**",
				"CRD": "", "BID": "%s", "PID": "1234", "TID": "1"
			}
		}`, lid)

	var data = fmt.Sprintf(`{
			"provider": "climatixic-esv",
			"result": true,
			"config": ["%s"],
			"ds": { "state": { "desired": { "sensors": { "OFFODT":1.47} } },
				"topic": "$aws/things/%s/shadow/name/building/update/accepted"
			}
		}`, jsonutils.JSONEscape(smallConf), lid)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	globalDatapointList = nil
	splitPartitionAndIDFunc = StandardSplitPartitionAndIDFunc

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	finder := func(id string) *eqmodel.CbDataPointImpl {
		value := linq.From(globalDatapointList.Values).FirstWith(func(v interface{}) bool {
			return v.(*eqmodel.CbDataPointImpl).ID == id
		})

		if value == nil {
			return nil
		}

		return value.(*eqmodel.CbDataPointImpl)
	}

	assert.Equal(t, 2, len(globalDatapointList.Values))

	assert.True(t, finder("1234;climatixic:IDT_O1") == nil)
	assert.True(t, finder("1234;climatixic:IDT_O2") == nil)

	assert.Equal(t, float64(2), finder("1234;climatixic:COMT").Value)
	assert.Equal(t, float64(1.47), finder("1234;climatixic:OFFODT").Value)
}

func TestCloudigoMappingShallWork(
	t *testing.T,
) {
	os.Args = []string{"esv",
		"-console",
		"-deployenv", "devlocal",
		"-dryrun",
		"-log", logLevel,
	}

	lid := "Måssmyren 18"

	smallConf := fmt.Sprintf(`{
			"profile": "proto",
			"prms": {
				"LOG": "on","MID": "COMT OFFODT",
				"CRD": "", "BID": "%s", "PID": "1234", "TID": "1"
			},
			"map": {
				"OFFODT": "\"Cwl.Advise.A[20]\"",
  			"COMT": "\"Cwl.Advise.A[21]\""
			}
		}`, lid)

	var data = fmt.Sprintf(`{
			"provider": "climatixic-esv",
			"result": true,
			"config": ["%s"],
			"ds": { "state": { "desired": { "sensors": { "OFFODT":1.47} } },
				"topic": "$aws/things/%s/shadow/name/building/update/accepted"
			}
		}`, jsonutils.JSONEscape(smallConf), lid)

	defer cbenv.CB_REP.UnSet()
	_, _ = cbenv.CB_REP.SetString("https://blaha.com")

	globalDatapointList = nil

	NewDsBuildingPlugin(
		testProvider(0), "unit-test", "test-provider",
		bufio.NewReader(strings.NewReader(data)),
	).Execute()

	finder := func(id string) *eqmodel.CbDataPointImpl {
		value := linq.From(globalDatapointList.Values).FirstWith(func(v interface{}) bool {
			return v.(*eqmodel.CbDataPointImpl).ID == id
		})

		if value == nil {
			return nil
		}

		return value.(*eqmodel.CbDataPointImpl)
	}

	assert.Equal(t, len(globalDatapointList.Values), 2)

	if finder("1234;Cwl.Advise.A[21]") == nil {
		assert.FailNow(t, "Expected to find COMT")
	}

	if finder("1234;Cwl.Advise.A[20]") == nil {
		assert.FailNow(t, "Expected to find OFFODT")
	}

	assert.Equal(t, float64(2), finder("1234;Cwl.Advise.A[21]").Value)
	assert.Equal(t, float64(1.47), finder("1234;Cwl.Advise.A[20]").Value)
}
