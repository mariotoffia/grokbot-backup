package tests

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

// TestEmptySourceDataWithAllOptionalGracefulReturn verifies that when source
// returns empty data AND all sensors are optional (OPT="**"), the pipeline
// returns gracefully without error.
//
// EXPECTED BEHAVIOR:
//   - Pipeline completes without error
//   - No target is generated (empty template)
//   - No $error markers needed since there are no mandatory sensors
//
// This is the correct behavior for scenarios like:
//   - Empty message queue with OPT="**"
//   - Discovery operations where no data is found
func TestEmptySourceDataWithAllOptionalGracefulReturn(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Return EMPTY data points
						return []eqmodel.CbDataPoint{}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		// Use profile with OPT="**" (all optional) and empty MID/map
		FromUserConfig(`{"profile": "all-optional"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))

	// With OPT="**" and empty source, pipeline should complete without error
	assert.NoError(t, result[0].Error,
		"Empty source with all optional sensors should not cause pipeline error")

	t.Log("VERIFIED: Empty source data with OPT='**' returns gracefully without error")
}

// TestEmptySourceWithSensorsAllOptionalGracefulReturn verifies that when:
//   - MID has sensors (e.g., "IDT ODT")
//   - OPT covers all sensors (e.g., "**")
//   - Source returns empty data
//
// The pipeline should return gracefully without error.
func TestEmptySourceWithSensorsAllOptionalGracefulReturn(t *testing.T) {
	ctx := newCtx(t, zerolog.WarnLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("test-token"),
				}, 3600, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/mapping-direction-tests/",
			),
		)).
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Return EMPTY data points
						return []eqmodel.CbDataPoint{}, nil, nil
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		// Use profile with MID="IDT ODT" and OPT="**" (all optional)
		FromUserConfig(`{"profile": "sensors-all-optional"}`).
		Build()

	result := pe.Execute()

	require.Equal(t, 1, len(result))

	// With OPT="**" and empty source, pipeline should complete without error
	// even though MID has sensors defined
	assert.NoError(t, result[0].Error,
		"Empty source with all sensors marked optional should not cause pipeline error")

	t.Log("VERIFIED: Empty source data with MID='IDT ODT' and OPT='**' returns gracefully")
}
