package providerconfig

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	cbutils "github.com/Thiink-LLC/teos/go-core/utils"
)

// resolveProfileAndClone will use the _profileExpression_ to load the profile from
// repository or from the `profiles` section of the in-parameter if the _evalContext_
// contains a _pc_ key of which is a `ifprovider.ConfigFull` instance.
//
// The _evalContext_ may be used to resolve the profile if an `package cbeval` expression.
// The expression may be resolved as a profile or as a path expression to a profile.
//
// The _profileExpression_ may come from the `ChooseProfile` method or at least on
// the same format.
//
// The path expression is on the form '[profile]#/path/to/profile'.
// /
// .Example Profile Path Expression
// ---
// * _#/profiles/plant-a_ - will resolve the profile `plant-a` from the `profiles`
//
// * _siemens/master#/profiles/plant-a_ - will resolve the profile `plant-a` from
// the `profiles` section of the profile `siemens/master`.
//
// * _siemens/proto_ - will resolve the profile `siemens/proto`.
// ---
//
// NOTE: This function will *not* resolve any `$ref` in the profile.
func (resolver *ProfileResolverImpl) resolveProfileAndClone(ctx ifcore.CbContext,
	pc ifprovider.ConfigFull,
	profileExpression string,
	evalContext map[string]any,
) (ifprovider.ConfigFull, cberror.Error) {
	// Check if expression
	if cbeval.IsCbEvalExpression(profileExpression) {
		resolve, err := ToResolverEvaluable(
			ctx,
			resolver.repository,
			cbeval.UnwrapExpression(profileExpression),
		)
		if err != nil {
			return nil, err
		}

		profileOrExpression, resolveError := resolve(ctx, evalContext)
		if resolveError != nil {
			return nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), 1, resolveError, map[string]any{"pn": ctx.Provider()},
				"Failed to resolve profile expression '%s'", profileExpression,
			)
		}

		if profileOrExpression == nil {
			return nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
				"Profile '%s' not found", profileExpression,
			)
		}

		// Expression is resolved to a profile -> return it
		if profile, ok := profileOrExpression.(ifprovider.ConfigFull); ok {
			return profile, nil
		}

		// Expression is resolved to a profile name -> resolve it
		if pe, ok := profileOrExpression.(string); ok {
			profileExpression = pe
		} else {
			// Expression is resolved to something else -> error
			return nil, cberror.NewCbErrorfWithProps(
				ctx.Service(), 1, nil, map[string]any{"pn": ctx.Provider()},
				"Profile '%s' not found", profileExpression,
			)
		}
	}

	profile, _, err := resolver.profileFromExpression(
		ctx, pc, profileExpression, true, /*clone*/
	)

	if err != nil {
		return nil, err
	}

	// Provider Configuration?
	if providerConfig, ok := profile.(ifprovider.ConfigFull); ok {
		return providerConfig, nil
	}

	// No -> Use the _pc_ as base (local profile within that provider configuration)
	providerConfigImpl := utils.ToProviderConfigImpl(pc)
	profileImpl := utils.ToProfileImpl(profile)

	return providerConfigImpl.CloneWithProfile(profileImpl), nil
}

// resolveMap will resolve a map of properties.
//
// It will search for $ref and resolve them by resolving them and then
// copy the resolved properties into the map if not already exists.
// If the _overwrite_ flag is set, the existing properties will be overwritten.
//
// If no $ref is found, the map is returned as is. The _evalContext_ is used when
// evaluating the expression. The input _data_ is returned for chaining.
func (resolver *ProfileResolverImpl) resolveMap(ctx ifcore.CbContext,
	pc ifprovider.ConfigFull,
	evalContext map[string]any,
	data map[string]any,
	overwrite bool) (map[string]any, cberror.Error) {

	ref := cbutils.ExtractStringFromMap("$ref", data, "")
	if ref == "" {
		return data, nil
	}

	// Resolve the reference
	resolved, err := resolver.resolveReference(ctx, pc, ref, evalContext)
	if err != nil {
		return nil, err
	}

	// Resolve any $ref in the resolved properties (recursively)
	if ref, ok := resolved["$ref"]; ok && ref != "" {
		m, err := resolver.resolveMap(
			ctx, pc, evalContext,
			cbutils.ShallowCopyMap(map[string]any{}, resolved),
			overwrite,
		)

		if err != nil {
			return nil, err
		}

		for k, v := range m {
			resolved[k] = v
		}
	}

	// Copy the resolved properties into the map
	for k, v := range resolved {
		if _, ok := data[k]; !ok || overwrite {
			if k != "$ref" {
				data[k] = v
			}
		}
	}

	// Remove the $ref property
	delete(data, "$ref")

	return data, nil
}

// resolveStringMap will resolve a map of properties.
//
// It will search for $ref and resolve them by resolving them and then
// copy the resolved properties into the map if not already exists.
// If the _overwrite_ flag is set, the existing properties will be overwritten.
//
// If no $ref is found, the map is returned as is. The _evalContext_ is used when
// evaluating the expression.
func (resolver *ProfileResolverImpl) resolveStringMap(ctx ifcore.CbContext,
	pc ifprovider.ConfigFull,
	evalContext map[string]any,
	data map[string]string,
	overwrite bool) (map[string]string, cberror.Error) {

	ref := data["$ref"]
	if ref == "" {
		return data, nil
	}

	// Resolve the reference
	resolved, err := resolver.resolveReference(ctx, pc, ref, evalContext)
	if err != nil {
		return nil, err
	}

	// Resolve any reference before copying to data
	if ref, ok := resolved["$ref"]; ok && ref != "" {
		m, err := resolver.resolveStringMap(
			ctx, pc, evalContext, cbutils.ShallowCopyMapAnyToMapString(
				map[string]string{},
				resolved,
				false, /*force*/
			), overwrite,
		)

		if err != nil {
			return nil, err
		}

		for k, v := range m {
			if _, ok := resolved[k]; !ok || overwrite {
				resolved[k] = v
			}
		}
	}

	// Copy the resolved properties into the map
	for k, v := range resolved {
		if s, ok := v.(string); ok {
			if k != "$ref" {
				if _, ok := data[k]; !ok || overwrite {
					data[k] = s
				}
			}
		}
	}

	// Remove the $ref property
	delete(data, "$ref")

	return data, nil
}
