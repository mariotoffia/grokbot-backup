package providerpipe

import (
	"bytes"
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig/utils"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	ut "github.com/Thiink-LLC/teos/go-core/utils"
)

// DefaultTargetKey is the default key to use when extracting the data from the
// executed pipe.
const DefaultTargetKey = "target"

// PipeContextNavigationKey is well known keys for the pipe context.
type PipeContextNavigationKey string

const (
	// PipeContextNavigationKeyTypes is a key that all types are stored under.
	// Those may be used to be referenced when marshalling in the pipe
	PipeContextNavigationKeyTypes PipeContextNavigationKey = "_ts"
)

// NewProviderPipeExecutor creates a new executor for a pipe.
//
// The _input_ is optional, but if provided it will be shallow cloned and used as
// input when setting up the pipe to execute (both pipe context *and* pipeline).
func NewProviderPipeExecutor(
	ctx ifcore.CbContext,
) *ProviderPipeExecutorImpl {
	return &ProviderPipeExecutorImpl{
		ctx:         ctx,
		input:       map[string]any{},
		targetKey:   DefaultTargetKey,
		pipeContext: map[string]any{},
	}
}

// Error implements the `ifcore.ErrorHandler` interface
func (e *ProviderPipeExecutorImpl) Error() cberror.Error {
	return e.err
}

// ClearError implements the `ifcore.ErrorHandler` interface
func (e *ProviderPipeExecutorImpl) ClearError() {
	e.err = nil
}

// CancelReason returns the cancel reason if the pipeline was cancelled gracefully.
// Returns empty string if the pipeline was not cancelled.
//
// A cancelled pipeline is not an error - it indicates an expected condition where
// processing should stop (e.g., no mandatory sensors and no data to process).
func (e *ProviderPipeExecutorImpl) CancelReason() cberror.CancelPipelineReason {
	return e.cancelReason
}

// WasCancelled returns true if the pipeline was cancelled gracefully.
// A cancelled pipeline is not an error.
func (e *ProviderPipeExecutorImpl) WasCancelled() bool {
	return e.cancelReason != ""
}

// HasExecuteCompleted returns `true` when the `Execute()` has completed.
func (e *ProviderPipeExecutorImpl) HasExecuteCompleted() bool {
	return e.hasCompleted
}

// GetResult will return the result of the executed pipe (if any).
//
// If any errors did occur, or the pipe has not been executed, or
// it could not extract the target (result), this function will return `nil“.
//
// NOTE: If the result of the pipe execution is not a `map[string]any` it will
// return a `map[string]any` with a single key: _target_ where the object(s) resides.
// If the key has changed from the `DefaultTargetKey` it will be used instead.
func (e *ProviderPipeExecutorImpl) GetResult() map[string]any {
	// Check if in error state || completion
	if e.err != nil || !e.HasExecuteCompleted() {
		return nil
	}

	return e.result
}

// GetPipeContext will return the pipe context *after* the `Execute()` has completed.
func (e *ProviderPipeExecutorImpl) GetPipeContext() map[string]any {
	// Check if in error state || completion
	if e.err != nil || !e.HasExecuteCompleted() {
		return nil
	}

	return e.pipeContext
}

// HasGetResult will return true if the pipe has been executed and the result can be retrieved.
func (e *ProviderPipeExecutorImpl) HasGetResult() bool {
	return e.err == nil && len(e.result) > 0
}

// IsConfigDisabled checks if the config is disabled and hence
// should not be executed.
//
// This is done by checking the `ifprovider.ParameterProvisionedState` parameter
// and if it is set to `ifprovider.ProvisionedStateDisabled` it will return `true`.
func (e *ProviderPipeExecutorImpl) IsConfigDisabled() bool {
	return e.config.GetParamAsStringWithDefault(
		string(ifprovider.ParameterProvisionedState),
		string(ifprovider.ProvisionedStateProvisioned),
	) == string(ifprovider.ProvisionedStateDisabled)
}

// Execute will initialize the pipe and execute it. If successful the result can be retrieved
// by calling `Result()`. If an error occurs the error can be retrieved by calling `Error()`.
//
// If executed multiple times, it will set the error to `cberror.ErrorProviderPipeAlreadyExecuted`.
func (e *ProviderPipeExecutorImpl) Execute() *ProviderPipeExecutorImpl { /* NOSONAR */
	// Check if in error state
	if e.err != nil {
		return e
	}

	if e.hasCompleted {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(), cberror.ErrorProviderPipeAlreadyExecuted, nil,
			"Pipe has already been executed",
		)
		return e
	}

	// Make sure to set executed to true and invoke finally function in any case
	defer func() {
		e.hasCompleted = true

		// Invoke finally function if registered
		if e.pipeConfig.finally != nil {
			pipeCtx := e.lastResult
			if pipeCtx == nil {
				pipeCtx = e.pipeContext
			}

			e.err = e.pipeConfig.finally(
				e.ctx,
				pipeCtx,
				e.pipeConfig.operation,
				e.operation,
				utils.ToProviderConfigImpl(e.config),
				e.result,
				e.err,
			)
		}
	}()

	// Check if disabled configuration
	if e.IsConfigDisabled() {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(), http.StatusBadRequest, nil,
			"The provider configuration is disabled and hence shall not ever reach the provider!",
		)
	}

	// Initialization
	if e.initializePipeContext().
		resolveOperation().err != nil {
		return e
	}

	// Get credentials (if any)
	var credentials any
	var cred string

	if _, ok := e.pipeContext[string(ifprovider.PipeContextCredentials)]; ok {
		// We have temporary credentials
		credentials = e.getCredentials(ut.RandomPostfix("ephemeral"))
	} else if cred, _ = e.config.GetParamAsString(string(ifprovider.ParameterCredentials)); cred != "" {
		// Check if it is an expression
		if cbeval.IsCbEvalExpression(cred) {
			e.err = cberror.NewCbErrorf(
				e.ctx.Service(),
				cberror.ErrorGlobalParamsExpressionNotAllowed,
				nil,
				"Expression for CRD parameter in global prms is not supported",
			)

			return e
		}

		credentials = e.getCredentials(cred)
	}

	// Verify that credentials are allowed to be used to invoke the endpoint
	if e.verifyConnect(cred, credentials).err != nil {
		return e
	}

	// Prepare profile (if requested)
	if p, ok := e.pipeContext[string(ifprovider.ParameterPrepareProfile)]; ok {
		if ppf, ok := p.(string); ok {
			if f, ok := e.prepareProfile[ppf]; ok {
				if cfg, err := f(
					e.ctx, e.operation, e.config, e.pipeContext, credentials, e.pipeConfig.Owner.repository,
				); err != nil {
					e.err = err
					return e
				} else if cfg != nil {
					e.config = cfg
					e.pipeContext["pc"] = cfg

					// Re-initialize with the new config
					e.err = providerconfig.ResolvePipeContextFromGlobals(
						e.ctx, e.config, e.pipeContext, e.input, e.allowMutateGlobalParams,
					)

					if e.err != nil {
						return e
					} else if e.resolveOperation().err != nil {
						return e
					}
				}
			}
		}
	}

	// Prepare profile (if requested)
	if p, ok := e.pipeContext[string(ifprovider.ParameterPrepareProfile)]; ok {
		if ppf, ok := p.(string); ok {
			if f, ok := e.prepareProfile[ppf]; ok {
				if cfg, err := f(
					e.ctx, e.operation, e.config, e.pipeContext, credentials, e.pipeConfig.Owner.repository,
				); err != nil {
					e.err = err
					return e
				} else if cfg != nil {
					e.config = cfg
					e.pipeContext["pc"] = cfg

					// Re-initialize with the new config
					e.err = providerconfig.ResolvePipeContextFromGlobals(
						e.ctx, e.config, e.pipeContext, e.input, e.allowMutateGlobalParams,
					)

					if e.err != nil {
						return e
					} else if e.resolveOperation().err != nil {
						return e
					}
				}
			}
		}
	}

	// Invoke the source function (if any) if selections -> filter srcData
	sourceData, selection, drc := e.invokeSourceFunction(credentials, false /*noFilter*/)

	if lid, ok := e.config.GetParamAsString("BID"); ok {
		log.DebugWithLocationID(e.ctx, lid).
			WithMethod("ProviderPipeExecutorImpl::Execute").
			WithError(e.err).
			WithBody(sourceData).
			AsJSON("selection", selection).
			Msg("Source data loaded")
	} else {
		log.Debug(e.ctx).
			WithMethod("ProviderPipeExecutorImpl::Execute").
			WithError(e.err).
			WithBody(sourceData).
			AsJSON("selection", selection).
			Msg("Source data loaded")
	}

	if e.err != nil {
		return e
	}

	if e.onSource != nil {
		if replaceSource, err := e.onSource(e.ctx, e.pipeConfig, e.config, sourceData); err != nil {
			e.err = err
			return e
		} else if replaceSource != nil {
			sourceData = replaceSource
		}
	}

	// Handle any globals from source data
	e.handleGlobalParameterOverrides(sourceData)

	// Handle mapping mode (ifprovider.MappingMode)
	e.handleMappingMode(
		ifprovider.MappingMode(
			e.config.GetParamAsStringWithDefault(
				string(ifprovider.ParameterMappingMode),
				string(ifprovider.MappingModeStrict),
			)),
		selection,
		sourceData,
	)

	if e.err != nil {
		return e
	}

	// Handle mapping filter
	e.handleMappingFilter(
		e.config.GetParamAsStringWithDefault(string(ifprovider.ParameterMappingFilter), "none"),
		sourceData,
	)

	// Copy result into the pipeline context
	//
	// NOTE: This must be after handleMappingMode!!
	for k, v := range sourceData {
		e.pipeContext[k] = v
	}

	if e.err != nil {
		return e
	}

	// If we have one or more delayed report context, we do the report now since now we should
	// have a complete MID and mapping section.
	if len(drc) > 0 {
		pc, ok := e.config.(*providermodel.ProviderConfigImpl)
		if !ok {
			e.err = cberror.NewCbErrorf(
				e.ctx.Service(), 1, nil, "provider config is not of type ProviderConfigImpl",
			)

			return e
		}

		for _, rc := range drc {
			// Extract cbid
			cbid := e.config.ExtractSensors(e.operation)

			// Expand any cbid (if _MEX_ global parameter is set)
			if len(cbid) > 0 {
				if ids, er := expandCbID(cbid, pc, rc.DataPoints); er != nil {
					e.err = cberror.FromError(e.ctx.Service(), 500, er)
				} else {
					cbid = ids
				}
			}

			// If selection -> filter out any other that are not selected
			if len(selection) > 0 {
				dps := make([]eqmodel.CbDataPoint, 0, len(rc.DataPoints))

				for _, dp := range rc.DataPoints {
					for _, sel := range selection {
						if sel.TeosId != dp.GetID() && sel.RemoteId != dp.GetID() {
							continue
						}
						// Found
						dps = append(dps, dp)
					}
				}

				rc.DataPoints = dps
			}

			// Do report with the new profile
			rc.ProviderConfig = pc
			rc.WantedSensors = cbid

			if e.err = providerutils.DataPointReport(e.ctx, rc); e.err != nil {
				return e
			}
		}
	}

	// Create Pipe
	if e.prepareGeneratorTemplate().err != nil {
		return e
	}

	// Check if pipeline was cancelled (not an error, just no work to do)
	if e.cancelReason != "" {
		// Graceful return - pipeline cancelled (e.g., no mandatory sensors, no data)
		e.result = map[string]any{}
		return e
	}

	if e.createPipe().err != nil {
		return e
	}

	// Execute the pipe and extract the result
	e.result = e.executePipe(credentials)

	return e
}

// createPipe will create a build pipeline to execute. The _providerCtx_ and _goTemplate_ is created by `prepare` function.
//
// If it fails to generate the _JSON_ pipeline from the go template, it will set the error to code _1814_. If it does not
// have a generate section in the _JSON_ pipe it will set an error with error code of _1815_.
func (e *ProviderPipeExecutorImpl) createPipe() *ProviderPipeExecutorImpl {
	// Check if in error state
	if e.err != nil {
		return e
	}

	var writer bytes.Buffer
	if terr := e.goTemplate.Execute(&writer, e.config); terr != nil {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(),
			cberror.ErrorProviderUnableToGeneratePipeFromTemplate,
			terr,
			"Failed to generate the JSON pipe from go template: %#v, error: %s",
			e.goTemplate.Root,
			terr.Error(),
		)

		return e
	}

	if e.logging {
		log.Trace(e.ctx).WithMethod("executor").Msgf("Wrote template: \n%s", writer.String())
	}

	// The compiled form is kept and reused, because the same pipeline text is
	// run on every collection. The set of step types is part of what it is
	// stored under, so a caller with different step types never gets one built
	// for someone else.
	prog, compileErr := compilePipeline(e.ctx, StepTypes(), writer.Bytes())
	if compileErr != nil {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(),
			cberror.ErrorProviderUnableToGeneratePipeFromTemplate,
			compileErr,
			"Failed to compile pipeline JSON: %s",
			compileErr.Error(),
		)
		return e
	}
	e.prog = prog

	return e
}
