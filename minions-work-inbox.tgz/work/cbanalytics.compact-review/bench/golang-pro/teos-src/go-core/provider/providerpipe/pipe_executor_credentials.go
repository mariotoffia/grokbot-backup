package providerpipe

import (
	"net/http"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbtransport/cbtransportutils"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// verifyConnect will verify so the credentials may be used with the resolved operation
//
// If it fails to very that the credentials may be used with the endpoint specified in the
// resolved operation -> it will set the error in the `ProviderPipeExecutorImpl.err`.
func (e *ProviderPipeExecutorImpl) verifyConnect(
	cred string,
	credentials any,
) *ProviderPipeExecutorImpl {
	// Check if in error state
	if e.err != nil {
		return e
	}

	// Prefer pipe specific verification
	f := e.pipeConfig.verifyConnect

	if f == nil {
		f = e.pipeConfig.Owner.verifyConnect
	}

	if nil == f || credentials == nil {
		// No verification
		return e
	}

	if !f(e.ctx, cred, credentials, e.operation) {
		e.err = cberror.NewCbErrorf(
			e.ctx.Service(),
			cberror.ErrorProviderUnableExecutePipeline,
			nil,
			"The target: %s in item: %v, is not the same as in credentials (resolved by '%s') (fishing attempt?)",
			e.operation.Operation,
			e.operation,
			cred,
		)

		log.Warn(e.ctx).WithError(e.err).WithMethod("executor").Msg(e.err.Error())
	}

	return e
}

// getCredentials will lookup the _crd_ pointer in the session store, if not found, it
// will use the “ function to obtain the credentials and then cache them in the session store.
func (e *ProviderPipeExecutorImpl) getCredentials(crd string) any {
	// Check if in error state
	if e.err != nil {
		return nil
	}

	// Prefer the pipe credentials function
	f := e.pipeConfig.credentials

	if nil == e.pipeConfig.credentials {
		f = e.pipeConfig.Owner.obtainCredentials
	}

	if f == nil {
		return nil
	}

	ptr, _, ephemeral := cbtransportutils.ParseCredString(crd)

	if !ephemeral {
		item := e.pipeConfig.Owner.sessionStore.Get(ptr)

		if item != nil && nil != item.Object() {
			return item.Object()
		}
	}

	credentials, ttl, errCred := f(e.ctx, crd, e.pipeContext, e.operation)

	if credentials == nil {
		errCred = cberror.NewCbErrorf(
			e.ctx.Service(), http.StatusInternalServerError, errCred,
			"Failed to obtain credentials for CRD: %s (credentials = nil)", crd,
		)
	} else if errCred != nil {
		errCred = cberror.NewCbErrorf(
			e.ctx.Service(), cberror.ErrorProviderExtractCredentials, errCred,
			"Could not extract provider credentials: %s", errCred.Error(),
		)
	}

	if errCred != nil {
		e.err = providerutils.DataPointReport(e.ctx, &providerutils.ReportContext{
			Operation:         e.operation,
			ProviderConfig:    e.config.(*providermodel.ProviderConfigImpl),
			ProviderOperation: locationmodel.ProviderOperation(e.pipeConfig.operation),
			DataPoints:        nil,
			Body:              nil,
			Err:               errCred,
		})

		return nil
	}

	if ephemeral {
		return credentials
	}

	e.pipeConfig.Owner.sessionStore.PutExpire(
		ptr,
		credentials,
		time.Now().Unix()+ttl,
		false, /*no persist*/
		false, /*no encrypt*/
	)

	item := e.pipeConfig.Owner.sessionStore.Get(ptr)

	if item != nil && nil != item.Object() {
		return item.Object()
	}

	log.Warn(e.ctx).
		WithMethod("getCredentials").
		Str("crd", crd).
		Msgf("Failed to cache credentials for CRD (returning non cached credentials)")

	return credentials
}
