package s3sqs

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"
)

// PayloadData is a struct that holds the data associated with a locationID.
type PayloadData struct {
	// LocationID for the data.
	LocationID string
	// Data is the data that the providers e.g. *ingestionmodel.CbSensorReportItem
	Data map[string]any
}

// executePayloads iterates _payloads_ and perform `executeJSON` on each of them.
//
// NOTE: This is a best effort function and will not return any errors, it will just log them.
func executePayloads(
	payloads []*PayloadData,
	ctx ifcore.CbContext,
	pc providercontext.ProviderContext,
	defaultProfile string,
	parallelism int,
) {
	for j := range payloads {
		if res, err := executeJSON(ctx, pc, payloads[j], defaultProfile, parallelism); err != nil {
			log.Warn(ctx).
				WithMethod("executePayloads").
				WithBody(payloads[j]).
				WithError(err).
				Msg("Error while processing S3 event record, direct fail.")
		} else if res.HasError() {
			log.Warn(ctx).
				WithMethod("executePayloads").
				WithBody(payloads[j]).
				WithError(res.GetCompositeError()).
				Msg("Error while processing S3 event record, the result has errors.")
		}
	}
}

func executeJSON(
	ctx ifcore.CbContext,
	pc providercontext.ProviderContext,
	payload *PayloadData,
	defaultProfile string,
	parallelism int,
) (providerpipe.IterationExecutionResults, cberror.Error) {
	userConfig := ""

	if defaultProfile != "" {
		userConfig = fmt.Sprintf(`{"profile": "%s"}`, defaultProfile)
	}

	// Source function to provide with data.
	source := func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		return map[string]any{
			"source": payload.Data,
		}, nil
	}

	return pc.Execute(
		ctx,
		payload.LocationID,
		userConfig,
		payload.Data,
		map[string]any{
			string(ifprovider.ParameterMaxParallelism): parallelism,
			string(ifprovider.ParameterLocationID):     payload.LocationID,
		}, /*input*/
		&providercontext.OptExecute{
			ConfigUsage: providercontext.ProviderUserConfigUsageLoaderPerLocationID,
			Source:      source,
		},
	)
}
