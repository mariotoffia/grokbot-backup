package providerexecutors

import (
	"bufio"
	"flag"
	"os"
	"strings"

	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy"
	"github.com/Thiink-LLC/teos/go-core/cbpolicy/pep"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/lambdasupport"
	"github.com/Thiink-LLC/teos/go-core/logger"
	"github.com/Thiink-LLC/teos/go-core/provider"
	"github.com/Thiink-LLC/teos/go-core/pubsub"
)

// sessionStore contains the `SessionStore` to store local in-memory
// credentials and OAuth tokens.
var sessionStore *config.SessionStore

// ProviderExecutor will execute a single provider and return the error code.
func ProviderExecutor(
	p provider.InstanceProvider,
	contextName, pn string,
	reader *bufio.Reader,
) int {
	var dryrun bool
	var verifyConfig string

	flagSet := flag.NewFlagSet(os.Args[0], flag.ExitOnError)

	flagSet.BoolVar(
		&dryrun, "dryrun", false, "Set to true to not affect any state (not used when lambda mode)",
	)

	log, deployenv, console, lambdaType, lambdaPort, path := lambdasupport.SetupFlags(flagSet)

	p.InitFlags(flagSet)

	_ = flagSet.Parse(os.Args[1:])

	if *lambdaType == "" {
		*lambdaType = cbenv.CB_LAMBDA_TYPE.String("")
	}

	globalLogLevel := *log

	if globalLogLevel == "" {
		globalLogLevel = "info"
	}

	options := []ifcore.CbContextOption{ctx.OptAWSConfigLoadDefault()}

	if cbenv.CB_LOG_LEVEL.IsDefined() {
		options = append(options, ctx.OptLogLevelFromEnv())
	} else {
		options = append(options, ctx.OptSetLogLevelIfNotSet(false, globalLogLevel))
	}

	if cbenv.CB_PIPELINE_LOG.IsDefined() {
		options = append(options, ctx.OptPipelineLogLevelFromEnv())
	} else {
		options = append(options, ctx.OptSetPipelineLogLevelIfNotSet(false, cbenv.PipeLoggingOptional))
	}

	if *console {
		options = append(options, ctx.OptSetConsoleLogFormat(true))
	} else {
		options = append(options, ctx.OptConsoleLogFormatFromEnv())
	}

	if cbenv.CB_POLICY.IsDefined() {
		options = append(
			options,
			cbpolicy.OptNamedPolicyContext(false /*noForce*/, nil /*defaultKey*/),
		)
	}

	if prb, ok := p.(provider.StaticPRPContributingProvider); ok {
		prp := prb.GetPolicyRetrievalPoints()

		if len(prp) > 0 {
			options = append(options, cbpolicy.OptSubContext(true /*force*/, prp...))
		}
	}

	if pdb, ok := p.(provider.StaticPDPContributingProvider); ok {
		fsys := pdb.GetPDPConfigFSys()
		if len(fsys) > 0 {
			options = append(options, cbpolicy.OptPDPFromFSConfig(fsys...))
		}
	}

	if pdb, ok := p.(provider.StaticPEPContributingProvider); ok {
		reg := pdb.GetPEPConfig()
		if reg != nil {
			options = append(
				options,
				pep.OptPEPRegistration(reg.Category, reg.Registration, reg.IsWrapper),
			)
		}
	}

	var builder *pubsub.ManagerBuilder

	if pbs, ok := p.(provider.PublishSubscribeManagerContributingProvider); ok {
		pbs.BuildPublishSubscribeManager(builder)
	}

	if nil != builder {
		options = append(
			options,
			pubsub.OptServicePublishSubscribeManager(
				func(c ifcore.CbContext) *pubsub.ManagerBuilder {
					return builder
				},
			),
		)
	}

	if si, ok := p.(provider.StaticContextInitializerProvider); ok {
		opt, replace := si.ContextOptions(options)

		if nil != opt {
			if replace {
				options = opt
			} else {
				options = append(options, opt...)
			}
		}
	}

	c, err := lambdasupport.SetupContext(
		contextName,
		pn,
		*deployenv,
		*log,
		!*console,
		*lambdaPort,
		options...,
	)

	if nil != err {
		panic(err)
	}

	c.SetValue(provider.ProviderCtxDryRun, dryrun)

	if strings.ToLower(verifyConfig) == "static" {
		c.SetValue(provider.ProviderVerifyConfigStatic, true)
	} else {
		c.SetValue(provider.ProviderVerifyConfigStatic, false)
	}

	sessionStore = config.NewSessionStore(c)

	p.ContextInitialized(c, sessionStore)

	if *lambdaType != "" {
		disp := p.SetupDispatchers(c, *lambdaType, *path)

		if nil == disp {
			if l, ok := logger.ClsLog(zerolog.ErrorLevel, "main", logger.LDTUntyped, logger.LISUnclassified, c); ok {
				l.Msgf("Provider did not return any dispatcher for lambda type:%s", *lambdaType)
			}

			return -1
		}

		disp.Start()
		return 0
	}

	return p.DoCommand(c, reader)
}
