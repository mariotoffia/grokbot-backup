package providerconfig

import (
	"strings"
	"testing"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	c := testenv.DefaultContext(tb, "unit-test")
	zerolog.SetGlobalLevel(zerolog.FatalLevel)
	return c
}

func TestReadProviderConfig(t *testing.T) {
	s := `
--pcfg
{
	"profile": "cttherm-1",
	"prms": {
		"BID": "Månstenen 9",
		"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TID": "Tab9ffa07-7069-484c-b745-dca3ce11bb92",
		"REP": "climatixic.de/api"
	},
	"operations" : {
		"sv" : {
			"oper": "https://{{REP}}/DataPoints/Values/",
			"auth": "{{authprms}}",
			"prms": {
				"parentId":"[{\"Plants\":\"[{\"Plants\":\"{{PID}}\"}]\"}]"
			}
		}
	},
	"map": {
		"AHC_C3": "P3 Flow temp.",
		"IDT": "Room temp.comf."
	},
	"filter": {
		"IDT": "V > - 100 && V < 100"
	}
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "cttherm-1", cfg.Profile)
	assert.Equal(t, "Månstenen 9", cfg.Params["BID"])
	assert.Equal(t, "https://{{REP}}/DataPoints/Values/", cfg.Operation["sv"].Operation)
	assert.Equal(t, `[{"Plants":"[{"Plants":"{{PID}}"}]"}]`, cfg.Operation["sv"].Params["parentId"])
	assert.Equal(t, "P3 Flow temp.", cfg.Map["AHC_C3"])
	assert.Equal(t, "V > - 100 && V < 100", cfg.Filter["IDT"])

}

func TestExpandMIDConfig(t *testing.T) {
	s := `
--pcfg
{
	"profile": "cttherm-1",
	"prms": {
		"BID": "Månstenen 9",
		"MID": "ODT IDT_O[1-3] OFFODT COMT",
		"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TID": "Tab9ffa07-7069-484c-b745-dca3ce11bb92",
		"REP": "climatixic.de/api"
	},
	"operations" : {
		"sv" : {
			"oper": "https://{{REP}}/DataPoints/Values/",
			"auth": "{{authprms}}",
			"prms": {
				"parentId":"[{\"Plants\":\"[{\"Plants\":\"{{PID}}\"}]\"}]"
			}
		}
	},
	"map": {
		"IDT_O1": "Indoor temp. 1",
		"IDT_O2": "Indoor temp. 2",
		"IDT_O3": "Indoor temp. 3",
		"OFFODT": "Outdoor temp offset.",
		"COMT": "Compressor temp.",
		"ODT": "Outdoor temp."
	},
	"filter": {
		"IDT_O1": "V > - 100 && V < 100"
	}
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "ODT IDT_O1 IDT_O2 IDT_O3 OFFODT COMT", cfg.Params["MID"])
}

func TestReadProviderConfigImplicit(t *testing.T) {
	s := `
{
	"profile": "cttherm-1",
	"prms": {
		"BID": "Månstenen 9",
		"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
		"TID": "Tab9ffa07-7069-484c-b745-dca3ce11bb92",
		"REP": "climatixic.de/api"
	},
	"operations" : {
		"sv" : {
			"oper": "https://{{REP}}/DataPoints/Values/",
			"auth": "{{authprms}}",
			"prms": {
				"parentId":"[{\"Plants\":\"[{\"Plants\":\"{{PID}}\"}]\"}]"
			}
		}
	},
	"map": {
		"AHC_C3": "P3 Flow temp.",
		"IDT": "Room temp.comf."
	},
	"filter": {
		"IDT": "V > - 100 && V < 100"
	}
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "cttherm-1", cfg.Profile)
	assert.Equal(t, "Månstenen 9", cfg.Params["BID"])
	assert.Equal(t, "https://{{REP}}/DataPoints/Values/", cfg.Operation["sv"].Operation)
	assert.Equal(t, `[{"Plants":"[{"Plants":"{{PID}}"}]"}]`, cfg.Operation["sv"].Params["parentId"])
	assert.Equal(t, "P3 Flow temp.", cfg.Map["AHC_C3"])
	assert.Equal(t, "V > - 100 && V < 100", cfg.Filter["IDT"])

}

func TestReadNamedGeneratorTemplate(t *testing.T) {
	s := `
--gen=sv
{"BuildingID":src.ID,
					"sensors": {
						"MY": marshal(tsv, {"ts": utcnow(32), "v": 20.12}),
						"MY2": {"ts": utcnow(32), "v": 22.12},
						"ODT": {
							"ts": utcnow(32),
							"v" : floor(src.Sensors[src.Datapoint("ODT")].V,-12),
						},
						"IDT": {
							"ts": utcnow(32),
							"v": ceil(src.Sensors[1].V,22.8),
							"r" : range(src.Sensors[1].V, idtmin, idtmax)
						},
						"STR": {
							"ts": utcnow(32),
							"v": float64(src.Sensors[indexOf(src.Sensors, "ID === \"/STR\" && T == 2")].V)
						},
						"IDTAVG": {
							"ts": utcnow(32),
							"v": float64(src.SensorsInMap["IDTAVG"].V)
						},
						"IDTMIN": {
							"ts": utcnow(32),
							"v": src.SensorsInMap[indexOf(src.SensorsInMap, "ID === \"/IDTMIN\" && T == 8")].V,
						}
					}
				}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.Equal(t, s[10:]+"\n", cfg.Generate["sv"])
}

func TestReadGeneratorPrototypes(t *testing.T) {
	s := `
--genproto=sv
IDT: float64(generate[{{ID}}].Value)
IDT_O1: float64(generate["IDT_O1"].Value)
*: float64(generate[{{ID}}].Value)
:TS:IDT: generate[{{ID}}].TimeStamp
:TS:IDT_O1: generate["IDT_O1"].TimeStamp
:TS:*: generate[{{ID}}].TimeStamp`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.Equal(t, "float64(generate[{{ID}}].Value)", cfg.GenProto["sv"]["IDT"])
	assert.Equal(t, `float64(generate["IDT_O1"].Value)`, cfg.GenProto["sv"]["IDT_O1"])
	assert.Equal(t, "float64(generate[{{ID}}].Value)", cfg.GenProto["sv"]["*"])
	assert.Equal(t, "generate[{{ID}}].TimeStamp", cfg.GenProtoTs["sv"]["IDT"])
	assert.Equal(t, `generate["IDT_O1"].TimeStamp`, cfg.GenProtoTs["sv"]["IDT_O1"])
	assert.Equal(t, "generate[{{ID}}].TimeStamp", cfg.GenProtoTs["sv"]["*"])
}

func TestReadGeneratorPrototypesAllowWhiteEmptyLines(t *testing.T) {
	s := `
--genproto=sv
IDT: generate[{{ID}}]

IDT_O1: generate["IDT_O1"]
*: float64(generate[{{ID}}])
`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.Equal(t, "generate[{{ID}}]", cfg.GenProto["sv"]["IDT"])
	assert.Equal(t, `generate["IDT_O1"]`, cfg.GenProto["sv"]["IDT_O1"])
	assert.Equal(t, "float64(generate[{{ID}}])", cfg.GenProto["sv"]["*"])
}

func TestReadGeneratorPrototypesWithError(t *testing.T) {
	s := `
--genproto=sv
IDT generate[{{ID}}]
IDT_O1: generator["IDT_O1"]
*: float64(generate[{{ID}}])`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	_, err = CreateConfig(items...)
	assert.True(t, err != nil)
}

func TestReadUnNamedGeneratorTemplate(t *testing.T) {
	s := `
--gen
{"BuildingID":src.ID,
						"IDTMIN": {
							"ts": utcnow(32),
							"v": src.SensorsInMap[indexOf(src.SensorsInMap, "ID === \"/IDTMIN\" && T == 8")].V,
						}
					}
				}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.Equal(t, s[7:]+"\n", cfg.Generate[""])
}

func TestReadPipeWithGeneratorTemplate(t *testing.T) {
	s := `
--gen=sv
	{"BuildingID":src.ID,
						"sensors": {
							"MY": marshal(tsv, {"ts": utcnow(32), "v": 20.12}),
							"MY2": {"ts": utcnow(32), "v": 22.12},
							"ODT": {
								"ts": utcnow(32),
								"v" : floor(src.Sensors[src.Datapoint("ODT")].V,-12),
							},
							"IDT": {
								"ts": utcnow(32),
								"v": ceil(src.Sensors[1].V,22.8),
								"r" : range(src.Sensors[1].V, idtmin, idtmax)
							},
							"STR": {
								"ts": utcnow(32),
								"v": float64(src.Sensors[indexOf(src.Sensors, "ID === \"/STR\" && T == 2")].V)
							},
							"IDTAVG": {
								"ts": utcnow(32),
								"v": float64(src.SensorsInMap["IDTAVG"].V)
							},
							"IDTMIN": {
								"ts": utcnow(32),
								"v": src.SensorsInMap[indexOf(src.SensorsInMap, "ID === \"/IDTMIN\" && T == 8")].V,
							}
						}
					}
--pipe=sv
{
	"test-pipe": {
		"set-provider" : {
			"sensorvalues" : "=asmap(src.Sensors, 'ID')"
		},
		"set-init": {
			"sk": "=keys(sensorvalues)",
			"length": "=len(sensorvalues)"
		},
		"foreach-sensors": {
			"init" : { "i": 0, "c": "=sensorvalues[sk[0]]" },
			"cond" : "=i < length",
			"iter" : { "i": "=i + 1", "c": "=sensorvalues[sk[i + 1]]" },
			"steps" : {
				"set-filter-bad-readings" : {
					"root": {
						"=c.Name": { "if": "=c.V < 100 && c.V > -100", "value": "=c" }
					}
				}
			}
		},
		"gen-ds": {
			"_": "={ 'IDTAVG': { 'Name': 'IDTAVG', 'V': round(avg(:-v V -k ID -s / sensorvalues.**/IDT*:), 1) }}"
		},
		"marshal-ds": {
			"_": "=asmap(marshal(_types.dp, IDTAVG), 'Name')"
		}
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 2, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.True(t, strings.Contains(cfg.Pipe["sv"], "asmap(src.Sensors, 'ID')"))
	assert.True(t, strings.Contains(cfg.Generate["sv"], `float64(src.SensorsInMap["IDTAVG"].V)`))
}

func TestReadPipeWithTwoGeneratorTemplateImplicitProviderConfig(t *testing.T) {
	s := `
{ "profile": "ct-1" }
--gen=genref
	{"BuildingID":src.ID }
--gen=sv
	{"BuildingID":src.ID,
						"sensors": {
							"MY": marshal(tsv, {"ts": utcnow(32), "v": 20.12}),
							"MY2": {"ts": utcnow(32), "v": 22.12},
							"ODT": {
								"ts": utcnow(32),
								"v" : floor(src.Sensors[src.Datapoint("ODT")].V,-12),
							},
							"IDT": {
								"ts": utcnow(32),
								"v": ceil(src.Sensors[1].V,22.8),
								"r" : range(src.Sensors[1].V, idtmin, idtmax)
							},
							"STR": {
								"ts": utcnow(32),
								"v": float64(src.Sensors[indexOf(src.Sensors, "ID === \"/STR\" && T == 2")].V)
							},
							"IDTAVG": {
								"ts": utcnow(32),
								"v": float64(src.SensorsInMap["IDTAVG"].V)
							},
							"IDTMIN": {
								"ts": utcnow(32),
								"v": src.SensorsInMap[indexOf(src.SensorsInMap, "ID === \"/IDTMIN\" && T == 8")].V,
							}
						}
					}
--pipe=sv
{
	"test-pipe": {
		"set-provider" : {
			"sensorvalues" : "=asmap(src.Sensors, 'ID')"
		},
		"set-init": {
			"sk": "=keys(sensorvalues)",
			"length": "=len(sensorvalues)"
		},
		"foreach-sensors": {
			"init" : { "i": 0, "c": "=sensorvalues[sk[0]]" },
			"cond" : "=i < length",
			"iter" : { "i": "=i + 1", "c": "=sensorvalues[sk[i + 1]]" },
			"steps" : {
				"set-filter-bad-readings" : {
					"root": {
						"=c.Name": { "if": "=c.V < 100 && c.V > -100", "value": "=c" }
					}
				}
			}
		},
		"gen-ds": {
			"_": "={ 'IDTAVG': { 'Name': 'IDTAVG', 'V': round(avg(:-v V -k ID -s / sensorvalues.**/IDT*:), 1) }}"
		},
		"marshal-ds": {
			"_": "=asmap(marshal(_types.dp, IDTAVG), 'Name')"
		}
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 4, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "ct-1", cfg.Profile)
	assert.True(t, strings.Contains(cfg.Pipe["sv"], "asmap(src.Sensors, 'ID')"))
	assert.True(t, strings.Contains(cfg.Generate["sv"], `float64(src.SensorsInMap["IDTAVG"].V)`))
	assert.True(t, strings.Contains(cfg.Generate["genref"], `{"BuildingID":src.ID }`))
}

func TestReadPipe(t *testing.T) {
	s := `
--pipe=sv
{
	"test-pipe": {
		"set-provider" : {
			"sensorvalues" : "=asmap(src.Sensors, 'ID')"
		},
		"set-init": {
			"sk": "=keys(sensorvalues)",
			"length": "=len(sensorvalues)"
		},
		"foreach-sensors": {
			"init" : { "i": 0, "c": "=sensorvalues[sk[0]]" },
			"cond" : "=i < length",
			"iter" : { "i": "=i + 1", "c": "=sensorvalues[sk[i + 1]]" },
			"steps" : {
				"set-filter-bad-readings" : {
					"root": {
						"=c.Name": { "if": "=c.V < 100 && c.V > -100", "value": "=c" }
					}
				}
			}
		},
		"gen-ds": {
			"_": "={ 'IDTAVG': { 'Name': 'IDTAVG', 'V': round(avg(:-v V -k ID -s / sensorvalues.**/IDT*:), 1) }}"
		},
		"marshal-ds": {
			"_": "=asmap(marshal(_types.dp, IDTAVG), 'Name')"
		}
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.Equal(t, s[11:]+"\n", cfg.Pipe["sv"])
}

func TestReadScripts(t *testing.T) {
	s := `
--script=sv
const cbn = require("cb/native");
function toCbDataPoints(ctx, tz, payload) {

  const format = "2006-01-02T15:04:05";
  const result = [];

  payload = JSON.parse(payload);
  payload.forEach(unit => {
    if (unit.UnitDataAnalog && unit.UnitDataAnalog.length > 0) {
      unit.UnitDataAnalog.forEach(analog => {

        result.push({
          n: unit.UnitID + ";Analog=" + analog.AnalogIndex,
          v: analog.DataAnalogValue,
          ts: cbn.tryParseTimeStamp32(tz, analog.DataDateTime, format)
        });

      });
    }

    if (unit.UnitDataPT && unit.UnitDataPT.length > 0) {
      unit.UnitDataPT.forEach(pt => {
        result.push({
          n: unit.UnitID + ";PT=" + pt.PTIndex,
          v: pt.DataPTValue,
          ts: cbn.tryParseTimeStamp32(tz, pt.DataDateTime, format)
        });

      });
    }

  });

	cbn.log(ctx, "debug", "toCbDataPoints", result);
  return cbn.toDataPoint(result);
}`

	items, err := ReadConfig(newCtx(t), s)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)
	assert.Equal(t, "", cfg.Profile)
	assert.Equal(t, s[13:]+"\n", string(cfg.Script["sv"]))
}

func BenchmarkReadSingleConfigItem(t *testing.B) {
	s := `
	{
		"profile": "cttherm-1",
		"prms": {
			"BID": "Månstenen 9",
			"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
			"TID": "Tab9ffa07-7069-484c-b745-dca3ce11bb92",
			"REP": "climatixic.de/api"
		},
		"operations" : {
			"sv" : {
				"oper": "https://{{REP}}/DataPoints/Values/",
				"auth": "{{authprms}}",
				"prms": {
					"parentId":"[{\"Plants\":\"[{\"Plants\":\"{{PID}}\"}]\"}]"
				}
			}
		},
		"map": {
			"AHC_C3": "P3 Flow temp.",
			"IDT": "Room temp.comf."
		},
		"filter": {
			"IDT": "V > - 100 && V < 100"
		}
	}`

	for i := 0; i < t.N; i++ {
		items, err := ReadConfig(newCtx(t), s)
		if err != nil && len(items) != 1 {
			t.Fail()
		}
	}
}

func BenchmarkReadProviderConfigImplicit(t *testing.B) {
	s := `
	{
		"profile": "cttherm-1",
		"prms": {
			"BID": "Månstenen 9",
			"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92",
			"TID": "Tab9ffa07-7069-484c-b745-dca3ce11bb92",
			"REP": "climatixic.de/api"
		},
		"operations" : {
			"sv" : {
				"oper": "https://{{REP}}/DataPoints/Values/",
				"auth": "{{authprms}}",
				"prms": {
					"parentId":"[{\"Plants\":\"[{\"Plants\":\"{{PID}}\"}]\"}]"
				}
			}
		},
		"map": {
			"AHC_C3": "P3 Flow temp.",
			"IDT": "Room temp.comf."
		},
		"filter": {
			"IDT": "V > - 100 && V < 100"
		}
	}`

	for i := 0; i < t.N; i++ {
		items, err := ReadConfig(newCtx(t), s)
		if err != nil && len(items) != 1 {
			t.Fail()
		}

		_, err = CreateConfig(items...)
		if err != nil {
			t.Fail()
		}
	}
}
