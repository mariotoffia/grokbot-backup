package providerpipe

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestExpandCbID_NoMexParameter(t *testing.T) {
	cbid := []string{"IDT_O1", "IDT_O2"}
	pc := &providermodel.ProviderConfigImpl{}

	result, err := expandCbID(cbid, pc, nil)

	require.NoError(t, err)
	assert.Equal(t, cbid, result)
}

func TestExpandCbID_MexWithLiteralMatch(t *testing.T) {
	cbid := []string{"HCT_C1"}
	pc := &providermodel.ProviderConfigImpl{}
	pc.Params = map[string]interface{}{
		"MEX": map[string]interface{}{
			"HCT_C1": "HCTST_O1_C1 HCTST_O2_C1",
		},
	}

	dp := []eqmodel.CbDataPoint{
		&eqmodel.CbDataPointImpl{ID: "HCTST_O1_C1", Value: 1.0},
		&eqmodel.CbDataPointImpl{ID: "HCTST_O2_C1", Value: 2.0},
		&eqmodel.CbDataPointImpl{ID: "OTHER", Value: 3.0},
	}

	result, err := expandCbID(cbid, pc, dp)

	require.NoError(t, err)
	assert.Len(t, result, 2)
	assert.Contains(t, result, "HCTST_O1_C1")
	assert.Contains(t, result, "HCTST_O2_C1")
}

func TestExpandCbID_MexWithGlobMatch(t *testing.T) {
	cbid := []string{"HCT**"}
	pc := &providermodel.ProviderConfigImpl{}
	pc.Params = map[string]interface{}{
		"MEX": map[string]interface{}{
			"HCT**": "HCTST** HCTODT**",
		},
	}

	dp := []eqmodel.CbDataPoint{
		&eqmodel.CbDataPointImpl{ID: "HCTST_O1_C1", Value: 1.0},
		&eqmodel.CbDataPointImpl{ID: "HCTST_O2_C1", Value: 2.0},
		&eqmodel.CbDataPointImpl{ID: "HCTODT_O1_C1", Value: 3.0},
		&eqmodel.CbDataPointImpl{ID: "OTHER", Value: 4.0},
	}

	result, err := expandCbID(cbid, pc, dp)

	require.NoError(t, err)
	assert.Len(t, result, 3)
	assert.Contains(t, result, "HCTST_O1_C1")
	assert.Contains(t, result, "HCTST_O2_C1")
	assert.Contains(t, result, "HCTODT_O1_C1")
}

func TestExpandCbID_MexNoMatchKeepsOriginal(t *testing.T) {
	cbid := []string{"UNKNOWN"}
	pc := &providermodel.ProviderConfigImpl{}
	pc.Params = map[string]interface{}{
		"MEX": map[string]interface{}{
			"HCT**": "HCTST**",
		},
	}

	dp := []eqmodel.CbDataPoint{
		&eqmodel.CbDataPointImpl{ID: "HCTST_O1_C1", Value: 1.0},
	}

	result, err := expandCbID(cbid, pc, dp)

	require.NoError(t, err)
	assert.Equal(t, []string{"UNKNOWN"}, result)
}

func TestExpandCbID_MexInvalidMapType(t *testing.T) {
	cbid := []string{"HCT_C1"}
	pc := &providermodel.ProviderConfigImpl{}
	pc.Params = map[string]interface{}{
		"MEX": "invalid", // Not a map
	}

	result, err := expandCbID(cbid, pc, nil)

	require.Error(t, err)
	assert.Nil(t, result)
	assert.Contains(t, err.Error(), "MEX parameter is not a valid map")
}

func TestExpandCbID_MexInvalidValueType(t *testing.T) {
	cbid := []string{"HCT_C1"}
	pc := &providermodel.ProviderConfigImpl{}
	pc.Params = map[string]interface{}{
		"MEX": map[string]interface{}{
			"HCT_C1": 123, // Not a string
		},
	}

	result, err := expandCbID(cbid, pc, nil)

	require.Error(t, err)
	assert.Nil(t, result)
	assert.Contains(t, err.Error(), "MEX mapping value for key")
}
