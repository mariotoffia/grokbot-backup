package patterns

import (
	"runtime"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/provider/providercontext"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils/procutils"
)

// ParallelSourceSingleBatchTargetOptions is the options that are passed to the
// `ParallelSourceSingleBatchTargetExecute()` function.
type ParallelSourceSingleBatchTargetOptions[TInput any, TOutput any] struct {
	// ExecuteOptions that are passed to the `providercontext.ProviderContext.Execute()` function.
	//
	// TIP: If no target function is set it will install a default one that will verify that the target
	// is of the correct type.
	ExecuteOptions providercontext.OptExecute
	// ProviderContext is *MANDATORY*
	ProviderContext providercontext.ProviderContext
	// Config is the provider config that will be used as either default or the configuration to use.
	//
	// NOTE: The usage depends on the `providercontext.ProviderUserConfigUsage` setting either in the
	// `providercontext.ProviderContext` or in the `providercontext.OptExecute`.
	Config string
	// LocationID is an optional _LocationID_ that will be passed when loading user config. Thus it is
	// only applicable when user config loader are used.
	LocationID string
	// Input is the input that will be passed to the provider pipeline. It may be `nil`.
	Input map[string]any
	// MaxParallelization is the number of parallel executions that will be done. If not set it will be set
	// to `runtime.NumCPU()*32`.
	//
	// TIP: If no parallelism is wanted, use _1_.
	MaxParallelization int
	// Timeout is the main timeout for the processing, default is _120_ seconds.
	Timeout time.Duration
	// OnError specifies what to do when an error happens. Default is `ExecuteOnErrorStop`.
	OnError ExecuteOnError
	// BatchTarget is a function that gets called when a batch is done.
	//
	// NOTE: This is an optional function and if not set, the `providercontext.OptExecute.Target` functions are used.
	// If not set in the `providercontext.OptExecute.Target` functions, it will use the target set in the pipeline.
	//
	// If this function is set, it will use the caller go routine to do the batching. If the function is set on the
	// pipeline target, it will use the pipeline go routine to do the batching.
	BatchTarget BatchTargetFunc[TOutput]
	// Source is the source function that will be used instead of the `providercontext.OptExecute.Source` functions.
	//
	// NOTE: It is an optional function and if not set, the `providercontext.OptExecute.Source` functions will be used.
	// If none in the `providercontext.OptExecute.Source` functions are set, it will use the source set in the pipeline.
	Source SourceFunc[TInput]
}

// ParallelSourceBatchTargetExecute will do a parallel execution of a provider pipeline from source
// to the pipeline target. If batching is wanted, it will use the caller go routine to do the batching,
// hence only from source to the batch target function is done in parallel.
//
// TIP: This function is most useful when the source to target takes considerable amount of time and the target can
// be efficiently batched in a e.g. single request such as a post to a _SQS_ queue.
//
// `BatchTarget` is the function that will be invoked when each of the batch is done. It will do `Parallelization` amounts
// of parallel executions. If `len(events) > Parallelization` it will do multiple batches. Each time a batch is done, it
// invokes the `BatchTarget` function.
//
// The `BatchTarget` can be found in the _options_ parameter.
//
// NOTE: Since `BatchTarget` is called inside a separate go routine, next batch is processing. Thus, it may end up in multiple
// concurrent `BatchTarget` execution. It will, however, then wait until all `BatchTarget` calls are done before returning.
//
// If the _source_ is set, it will override the `providercontext.OptExecute` source functions and use it instead as the
// source function.
//
// CAUTION: When no `providercontext.ProviderContext` is supplied, this function will *panic*.
func ParallelSourceBatchTargetExecute[TInput any, TOutput any]( /* NOSONAR */
	ctx ifcore.CbContext,
	events []*TInput,
	options ParallelSourceSingleBatchTargetOptions[TInput, TOutput],
) procutils.ParallelizerResults[[]*TOutput] {
	// Handle defaults
	if options.ExecuteOptions.SimpleTarget == nil && options.ExecuteOptions.Target == nil {
		options.ExecuteOptions.SimpleTarget = func(target map[string]any) cberror.Error {
			// Verify that target do exist, and that it's of the correct type.
			return providerutils.VerifyTarget[TOutput](ctx, target)
		}
	}

	if options.ProviderContext == nil {
		panic("providercontext.ProviderContext is mandatory")
	}

	if options.Source != nil {
		// Clear the source functions
		options.ExecuteOptions.Source = nil
		options.ExecuteOptions.NoArgSource = nil
	}

	if options.MaxParallelization == 0 {
		options.MaxParallelization = runtime.NumCPU() * 32
	}

	if options.Timeout == 0 {
		options.Timeout = time.Duration(120 * time.Second)
	}

	if options.OnError == ExecuteOnErrorUnknown {
		options.OnError = ExecuteOnErrorStop
	}

	return procutils.ParallelizerCallback(
		ctx,
		events,
		options.MaxParallelization,
		options.Timeout,
		func(ctx ifcore.CbContext, idx int, item *TInput) ([]*TOutput, cberror.Error) {
			opt := options.ExecuteOptions

			if options.Source != nil {
				opt.NoArgSource = func() (map[string]any, cberror.Error) {
					return options.Source(ctx, item)
				}
			}

			// Execute the provider pipeline
			res, err := options.ProviderContext.Execute(
				ctx,
				options.LocationID,
				options.Config,
				item,
				options.Input,
				&opt,
			)

			switch options.OnError {
			case ExecuteOnErrorContinue:
				break
			case ExecuteOnErrorStop:
				if err != nil {
					return nil, err
				}

				// This case also includes the case below
				fallthrough
			case ExecuteOnErrorPipeExecutionErrorStop:
				if res.HasError() {
					return nil, res.GetCompositeError()
				}
			}

			var frames []*TOutput

			for i := range res {
				frame, err := providerutils.ExtractTargetError[TOutput](
					ctx,
					res[i].Result,
				)

				if err != nil {
					return nil, err
				}

				frames = append(frames, frame)
			}

			return frames, nil
		},
		func(start, end int, items []*procutils.ParallelizerResult[[]*TOutput]) []procutils.ParallelizerErrors {
			process := []*TOutput{}

			for i := range items {
				if items[i].Error == nil && len(items[i].Result) > 0 {
					for _, item := range items[i].Result {
						item := item
						process = append(process, item)
					}
				}
			}

			// No Callback set, just return or len i zero
			if options.BatchTarget == nil || len(process) == 0 {
				return nil
			}

			// Call target func with process
			errors := options.BatchTarget(ctx, process)

			if len(errors) == 0 {
				return nil
			}

			var (
				result  []procutils.ParallelizerErrors
				offset  int
				current int
			)

			// Remap errors so they have correct ParallelizerErrors.Index.
			for i := range items {
				if items[i].Error != nil {
					offset++
				}

				if errors[current].Index == (i - offset) {
					result = append(result, procutils.ParallelizerErrors{
						Index: i,
						Error: errors[current].Err,
					})

					current++

					if current == len(errors) {
						break
					}
				}
			}

			return result
		},
	)
}
