package providerpipe

import (
	"net/http"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
)

// UseSourceWithReport is the same as the `UseSource` function, but it will also
// produce a report using the `providerutils.DataPointReport` function.
//
// NOTE: `MapSectionIsWithoutPartition`, `HasPartitionIDSeparator` or `UseSplitPartitionID` may be
// needed to be set in order to properly report.
//
// This will place the `[]eqmodel.CbDataPoint` into the _src_ key and hence the pipe must have
// a `asmap(src,'ID')` in the pipe (see below example).
//
// .Example AsMap
// [source,json]
// ----
//
//	"set-provider": {
//		"source": "=asmap(src, 'ID')"
//	}
//
// ----
//
// It is possible to avoid this by using the `UseSourceMapWithReport` function.
//
// If the _MMO_ (`ifprovider.ParameterMappingMode`) is set to anything else than Explicit,
// it will delay the reporting *after* any source mapping has been done.
//
// When delayed, it wil return the `providerutils.ReportContext` in the `_report` key.
func (b *PipeBuilderImpl) UseSourceWithReport(source ReportableSourceFunction) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipe.source = func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		// Extract cbid and remote ids
		var rid []string
		cbid := pc.ExtractSensors(op)

		for _, sensor := range cbid {
			if n, ok := pc.GetMappedTo(sensor); ok {
				rid = append(rid, n)
			} else {
				// Check if the sensor exists as a VALUE in the map (inverted mapping)
				// Only check when using LeftAssign direction (inbound handlers)
				if b.pipe.mappingDirection == providermodel.MappingDirectionLeftAssign {
					if key, found := pc.GetMappedFrom(sensor); found {
						return nil, cberror.NewCbErrorfWithProps(
							b.ctx.Service(), 1, nil, map[string]any{
								"pn":   b.ctx.Provider(),
								"hint": "mapping_direction_inverted",
							},
							"sensor '%s' is not mapped: found '%s' -> '%s' in map but expected '%s' -> '<provider_id>'. "+
								"With MappingDirectionLeftAssign, map keys must be TEOS IDs. "+
								"Change map from { \"%s\": \"%s\" } to { \"%s\": \"%s\" }",
							sensor, key, sensor, sensor, key, sensor, sensor, key,
						)
					}
				}
				return nil, cberror.NewCbErrorfWithProps(
					b.ctx.Service(), 1, nil, map[string]any{
						"pn": b.ctx.Provider(),
					}, "the sensor %s is not mapped", sensor,
				)
			}
		}

		mmo := ifprovider.MappingMode(
			pc.GetParamAsStringWithDefault(
				string(ifprovider.ParameterMappingMode), string(ifprovider.MappingModeStrict),
			),
		)

		dp, body, err := source(ctx, pipeCtx, operation, op, pc, rid, cred)

		// Create the report context
		rc := &providerutils.ReportContext{
			Operation:               op,
			ProviderConfig:          pc,
			ProviderOperation:       locationmodel.ProviderOperation(b.pipe.operation),
			DataPoints:              dp,
			MapperWithoutPartition:  b.pipe.mapperWithoutPartition,
			SplitPartitionAndIDFunc: b.pipe.splitPartitionAndIDFunc,
			ToTeosID:                b.pipe.toTeosID,
			Err:                     err,
			Body:                    body,
			WantedSensors:           cbid,
		}

		res := map[string]any{
			"src": dp,
		}

		if mmo == ifprovider.MappingModeStrict {
			if err != providerutils.DataPointReport(b.ctx, rc) {
				return nil, err
			}
		} else {
			// Store the context to signal the pipe that the report is delayed.
			rep, ok := res["_report"].([]*providerutils.ReportContext)

			if !ok {
				rep = []*providerutils.ReportContext{rc}
				res["_report"] = rep
			} else {
				rep = append(rep, rc)
				res["_report"] = rep
			}
		}

		return res, nil
	}

	return b
}

// UseSourceMapWithReport is the same as `UseSourceWithReport` but the function will return a
// `map[string]eqmodel.CbDataPoint` instead and hence can be put into the _source_ key in the
// `pipe.ScopeCtx` and is more efficient.
//
// NOTE: This will place the `map[string]eqmodel.CbDataPoint` into the _source_ key.
//
// If the _MMO_ (`ifprovider.ParameterMappingMode`) is set to anything else than Explicit,
// it will delay the reporting *after* any source mapping has been done.
//
// When delayed, it wil return the `providerutils.ReportContext` in the `_report` key.
func (b *PipeBuilderImpl) UseSourceMapWithReport( /* NOSONAR */
	source ReportableSourceMapFunction,
) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}

	b.pipe.source = func(
		ctx ifcore.CbContext,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		pipeCtx map[string]any,
		cred any) (map[string]any, cberror.Error) {
		//
		if op == nil {
			return nil, cberror.NewCbErrorfWithProps(
				b.ctx.Service(), http.StatusBadRequest, nil, map[string]any{
					cberror.PropertyProvider: b.ctx.Provider(),
				}, "no operation configuration found for operation: %s, is it present in profile?", operation,
			)
		}

		// Extract cbid and remote ids
		var rid []string
		cbid := pc.ExtractSensors(op)

		for _, sensor := range cbid {
			if n, ok := pc.GetMappedTo(sensor); ok {
				rid = append(rid, n)
			} else {
				// Check if the sensor exists as a VALUE in the map (inverted mapping)
				// Only check when using LeftAssign direction (inbound handlers)
				if b.pipe.mappingDirection == providermodel.MappingDirectionLeftAssign {
					if key, found := pc.GetMappedFrom(sensor); found {
						return nil, cberror.NewCbErrorfWithProps(
							b.ctx.Service(), 1, nil, map[string]any{
								"pn":   b.ctx.Provider(),
								"hint": "mapping_direction_inverted",
							},
							"sensor '%s' is not mapped: found '%s' -> '%s' in map but expected '%s' -> '<provider_id>'. "+
								"With MappingDirectionLeftAssign, map keys must be TEOS IDs. "+
								"Change map from { \"%s\": \"%s\" } to { \"%s\": \"%s\" }",
							sensor, key, sensor, sensor, key, sensor, sensor, key,
						)
					}
				}
				return nil, cberror.NewCbErrorfWithProps(
					b.ctx.Service(), 1, nil, map[string]any{
						"pn": b.ctx.Provider(),
					}, "sensor %s is not mapped", sensor,
				)
			}
		}

		mmo := ifprovider.MappingMode(
			pc.GetParamAsStringWithDefault(
				string(ifprovider.ParameterMappingMode), string(ifprovider.MappingModeStrict),
			),
		)

		dp, src, body, err := source(ctx, pipeCtx, operation, op, pc, rid, cred)

		dps := make([]eqmodel.CbDataPoint, len(dp))
		i := 0

		for k := range dp {
			dps[i] = dp[k]
			i++
		}

		if len(cbid) > 0 {
			if ids, er := expandCbID(cbid, pc, dps); er != nil {
				err = cberror.FromError(b.ctx.Service(), 500, er)
			} else {
				cbid = ids
			}
		}

		// Create the report context
		rc := &providerutils.ReportContext{
			Operation:               op,
			ProviderConfig:          pc,
			ProviderOperation:       locationmodel.ProviderOperation(b.pipe.operation),
			WantedSensors:           cbid,
			DataPoints:              dps,
			MapperWithoutPartition:  b.pipe.mapperWithoutPartition,
			SplitPartitionAndIDFunc: b.pipe.splitPartitionAndIDFunc,
			ToTeosID:                b.pipe.toTeosID,
			Err:                     err,
			Body:                    body,
		}

		m := map[string]any{}

		if mmo == ifprovider.MappingModeStrict {
			if err != providerutils.DataPointReport(b.ctx, rc) {
				return nil, err
			}
		} else {
			// Store the context to signal the pipe that the report is delayed.
			rep, ok := m["_report"].([]*providerutils.ReportContext)

			if !ok {
				rep = []*providerutils.ReportContext{rc}
				m["_report"] = rep
			} else {
				rep = append(rep, rc)
				m["_report"] = rep
			}
		}

		// gval needs this - otherwise it will resort to reflection
		// and it will throw error if we navigate on non existent
		// elements. If we do like this, it will return nil instead.
		pdp := make(map[string]any, len(dp))
		for k := range dp {
			pdp[k] = dp[k]
		}

		m["source"] = pdp

		if src != nil {
			m["src"] = src
		}

		return m, nil
	}

	return b
}

// UseSource sets the source function that is invoked when the pipe has been executed.
func (b *PipeBuilderImpl) UseSource(source SourceFunction) *PipeBuilderImpl {
	// Check if in error state
	if b.err != nil {
		return b
	}

	if b.pipe.sourceWithSelection != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			400,
			nil,
			"source function already set (cannot set source with selection *and* source at the same time)",
		)

		return b
	}

	b.pipe.source = source

	return b
}

// UseSourceWithSelection sets the source function that is invoked when the pipe has been executed.
func (b *PipeBuilderImpl) UseSourceWithSelection(
	source SourceFunctionWithSelection,
) *PipeBuilderImpl {
	if b.err != nil {
		return b
	}

	if b.pipe.source != nil {
		b.err = cberror.NewCbErrorf(
			b.ctx.Service(),
			400,
			nil,
			"source function already set (cannot set source with selection *and* source at the same time)",
		)

		return b
	}

	b.pipe.sourceWithSelection = source

	return b
}

// ToSourceMapFromSrc will return a `ReportableSourceMapFunction` that used the id
// to create a `map[string]eqmodel.CbDataPoint` as key.
func ToSourceMapFromSrc(source ReportableSourceFunction) ReportableSourceMapFunction {
	return func(
		ctx ifcore.CbContext,
		pipeCtx map[string]any,
		operation string,
		op *providermodel.Operation,
		pc *providermodel.ProviderConfigImpl,
		rid []string,
		cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {

		dp, body, err := source(ctx, pipeCtx, operation, op, pc, rid, cred)

		if err != nil {
			return nil, nil, nil, err
		}

		m := map[string]eqmodel.CbDataPoint{}

		if len(dp) == 0 {
			return m, nil, body, nil
		}

		for k := range dp {
			m[dp[k].GetID()] = dp[k]
		}

		return m, nil, body, nil
	}
}
