package providerconfig

import (
	"fmt"
	"math"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// FilterResolverImpl will resolve filter expressions in a
// provider configuration.
//
// .Example Filter Expression
// [source,json]
// ----
//
//	{
//	  "MID": [
//				{ "IDT": { "start": 1, "end": "[ceil(CNTIDT, 10)]" } },
//				{ "IDT": { "select": "[:-v . map.IDT_C1_O[21-22]:]"} },
//				{ "HUM": { "end": 100, "select": "[:-v . map.HUM_**:]"} }
//		 ]
//	}
//
// ----
type FilterResolverImpl struct {
	ctx    ifcore.CbContext
	filter map[string][]*providermodel.FilterItemImpl
}

// NewFilterResolver creates a new instance of the filter resolver.
func NewFilterResolver(
	ctx ifcore.CbContext,
	filter map[string][]*providermodel.FilterItemImpl,
) (*FilterResolverImpl, cberror.Error) {
	resolver := &FilterResolverImpl{ctx: ctx, filter: filter}

	for k := range filter {
		for _, filter := range filter[k] {
			if filter.ID == "" {
				return nil, cberror.NewCbErrorf(
					resolver.ctx.Service(), 1, nil, "Filter ID is missing",
				)
			}
		}
	}

	return resolver, nil
}

func (resolver *FilterResolverImpl) ProcessFilter(
	ctx ifcore.CbContext,
	data map[string]any,
) (map[string]interface{}, cberror.Error) {

	result := map[string]any{}

	// MID is the only allowed filter to be processed.
	if filters, ok := resolver.filter[string(ifprovider.ParameterMappingIDs)]; ok {

		var mid string
		if s, ok := data[string(ifprovider.ParameterMappingIDs)]; ok {
			if ms, ok := s.(string); !ok {
				mid = fmt.Sprintf("%v", s)
			} else {
				mid = ms
			}
		}

		mod, err := resolver.processMIDFilter(ctx, mid, data, filters)

		if err != nil {
			return nil, err
		} else {
			result[string(ifprovider.ParameterMappingIDs)] = mod
		}
	}

	return result, nil
}

func (resolver *FilterResolverImpl) resolveSelect(
	ctx ifcore.CbContext,
	data map[string]any,
	filter ifprovider.ProcessFilterItem,
) (any, cberror.Error) {

	expr := filter.GetSelect()
	if expr == "" {
		expr = fmt.Sprintf("[:-v . map.%s_**:]", filter.GetID())
	}

	return evaluateSearchExpression(ctx, cbeval.UnwrapExpression(expr), data)
}

func (resolver *FilterResolverImpl) resolveStartEndCircuit(
	ctx ifcore.CbContext,
	data map[string]any,
	valueOrExpression any,
	defaultValue int,
) (int, cberror.Error) {

	if valueOrExpression == nil {
		return defaultValue, nil
	}

	switch val := valueOrExpression.(type) {
	case int:
		return val, nil
	case int32:
		return int(val), nil
	case int64:
		return int(val), nil
	case float64:
		return int(val), nil
	case string:
		sel, err := cbeval.GlobalEvalCache.GetEval(
			ctx, cbeval.UnwrapExpression(val), cbeval.EvalCacheLangCompositeRanges,
		)
		if err != nil {
			return -1, err
		}

		res, selError := sel(ctx, data)
		if selError != nil {
			return -1, cberror.NewCbErrorf(
				ctx.Service(), 1, selError,
				"Failed to evaluate start/end/circuit expression: %s", val,
			)
		}

		if res == nil {
			return -1, cberror.NewCbErrorf(
				ctx.Service(), 2, nil,
				"start/end/circuit expression returned nil: %s", val,
			)
		}

		if i, ok := res.(int64); ok {
			return int(i), nil
		}

		if i, ok := res.(int); ok {
			return i, nil
		}

		if i, ok := res.(int32); ok {
			return int(i), nil
		}

		if i, ok := res.(float64); ok {
			return int(i), nil
		}

		if i, ok := res.(float32); ok {
			return int(i), nil
		}

		return -1, cberror.NewCbErrorf(
			ctx.Service(), 3, nil,
			"start/end/circuit expression returned non-int: %v", res,
		)
	}

	return -1, cberror.NewCbErrorf(
		ctx.Service(), 4, nil,
		"start/end/circuit value is not a string or int: %v", valueOrExpression,
	)

}

func (resolver *FilterResolverImpl) processMIDFilter(
	ctx ifcore.CbContext,
	mid string,
	data map[string]any,
	filters []*providermodel.FilterItemImpl,
) (string, cberror.Error) {
	// Store all mapping IDs in the map to be included in MID
	includes := map[string][]string{}

	for _, filter := range filters {
		var ids []string
		var start, end, circuit int

		filterID := filter.ID
		result, err := resolver.resolveSelect(ctx, data, filter)

		if err != nil {
			return "", err
		}

		if id, ok := result.([]interface{}); ok {
			// Zero in selection -> skip filter
			if len(id) == 0 {
				continue
			}

			for _, i := range id {
				if s, ok := i.(string); ok {
					ids = append(ids, s)
				} else {
					return "", cberror.NewCbErrorf(
						ctx.Service(), 1, nil,
						"Filter expression returned invalid type: %s", filterID,
					)
				}
			}
		} else if id, ok := result.(string); ok {
			ids = append(ids, id)
		} else if id, ok := result.([]string); ok {
			ids = append(ids, id...)
		} else {
			return "", cberror.NewCbErrorf(
				ctx.Service(), 1, nil,
				"Filter expression returned invalid type: %s", filterID,
			)
		}

		// Special case where select is everything!
		if filter.Start == nil && filter.End == nil && filter.Circuit == nil {
			includes[filterID] = ids
			continue
		}

		if start, err = resolver.resolveStartEndCircuit(
			ctx, data, filter.Start, 1,
		); err != nil {
			return "", err
		}

		if end, err = resolver.resolveStartEndCircuit(
			ctx, data, filter.End, math.MaxInt64,
		); err != nil {
			return "", err
		}

		if circuit, err = resolver.resolveStartEndCircuit(
			ctx, data, filter.Circuit, 0,
		); err != nil {
			return "", err
		}

		for _, id := range ids {
			pos, ok, _, o, c, _, _, _ := eqmodel.SensorType(id).Parse()
			if c == -1 {
				c = 0
			}

			if !ok {
				return "", cberror.NewCbErrorf(
					ctx.Service(), 2, nil,
					"Invalid sensor type: %s - pos: %d", id, pos,
				)
			}

			if o >= start && o <= end && c == circuit {
				includes[filterID] = append(includes[filterID], id)
			}
		}
	}

	// Cleanse out the mapping IDs that are to be included in MID
	var remove []string
	for k := range includes {
		if len(includes[k]) > 0 {
			remove = append(remove, k)
		}
	}

	if len(mid) > 0 {
		var result []string
		mid_split := strings.Split(mid, " ")

		for _, id := range mid_split {
			var removeMe bool
			for _, shortID := range remove {
				if strings.HasPrefix(id, shortID) {

					if len(id) > len(shortID) {
						// Check if the next character is a underscore
						if id[len(shortID)] != '_' {
							continue
						}
					}

					removeMe = true
					break
				}
			}

			if !removeMe {
				// Keep it
				result = append(result, id)
			}
		}

		mid = strings.Join(result, " ")
	}

	// Add the include
	for _, v := range includes {
		if len(v) > 0 {
			mid = strings.Join(v, " ") + " " + mid
		}
	}

	return strings.Trim(mid, " "), nil
}
