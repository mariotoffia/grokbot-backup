package tests

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/config"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
	"github.com/Thiink-LLC/teos/go-core/provider/providerpipe"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// cSpell: disable

// TestSinglePipelineExecution tests a provider config that is a single execution and
// no process items. It is just configured with a single pipe.
func TestSinglePipelineExecutionNoProcessItems(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	// Create the pipeline
	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Token: []byte("token-from-remote-ep")}, 3600 /*1h*/, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/pipeline-executor-tests/",
			),
		)).
		// Create the pipe "sv": Import Sensor Values
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) ([]eqmodel.CbDataPoint, []byte, cberror.Error) {
						// Simulate call to remote endpoint for fetching sensor values
						return []eqmodel.CbDataPoint{
							&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZHI2WD0F", Value: 22.7},
							&eqmodel.CbDataPointImpl{ID: "1!N3ASTFSZH7ZS23P", Value: 18.5},
							&eqmodel.CbDataPointImpl{ID: "1!6WHH6DKHICVDSS", Value: 2.46},
							&eqmodel.CbDataPointImpl{ID: "1!N3ASTG10KWTFCMU", Value: -17.0},
						}, nil /*body*/, nil /*err*/
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		Build()

	// Create the pipeline executor
	pe := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "single-plant/generic"}`).
		Build()

	// Execute the pipeline
	result := pe.Execute()

	require.Equal(t, 1, len(result))
	require.NoError(t, result[0].Error)
	require.Contains(t, result[0].Result, "target")
	assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, result[0].Operation)

	target := result[0].Result["target"].(*dsmodel.DsBuilding)

	require.NotNil(t, target)
	assert.Equal(t, "Europe/Stockholm", target.TimeZone)
	assert.Equal(t, float64(-17), target.Sensors["ODT"])
	assert.Equal(t, float64(2.46), target.Sensors["OFFODT"])
	assert.NotContains(t, target.Sensors, "IDT_O1")
	assert.NotContains(t, target.Sensors, "IDT_O2")
}

func TestDiscovery(t *testing.T) {
	ctx := newCtx(t, zerolog.FatalLevel)

	pipeline := providerpipe.NewPipelineBuilder(ctx).
		WithBatchSize(10).
		WithParallelThreshold(1).
		WithTimeout(30 * time.Second).
		UseCredentialsFunction(
			func(
				context ifcore.CbContext,
				cred string,
				pipeCtx map[string]any,
				op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error) {
				return &securitymodel.TokenCredentialsImpl{
					Credentials: securitymodel.StandardCredentialsImpl{
						Endpoint: "api.climatixic.com",
					},
					Token: []byte("token-from-remote-ep")}, 3600 /*1h*/, nil
			}).
		UseVerifyConnectFunction(providerpipe.DefaultVerifyConnect).
		WithSessionStore(config.NewSessionStore(ctx)).
		WithConfigRepository(providerconfig.NewProviderConfigRepository(
			ctx,
			providerconfig.NewFsProviderConfigLoaderFromPath(
				"./testdata/pipeline-executor-tests/",
			),
		)).
		// Create the pipe "sv": Import Sensor Values
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				WithMarshalPrototype("dsv", dsmodel.DsBuilding{}).
				UseSourceMapWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
						// Simulate call to remote endpoint
						plant := pc.GetParamAsStringWithDefault(
							string(ifprovider.ParameterPlantID), "",
						)

						switch plant {
						case "plant-1":
							return map[string]eqmodel.CbDataPoint{
								"1!idt1": &eqmodel.CbDataPointImpl{ID: "1!idt1", Value: 12.1},
								"1!idt2": &eqmodel.CbDataPointImpl{ID: "1!idt2", Value: 18.2},
								"1!idt3": &eqmodel.CbDataPointImpl{ID: "1!idt3", Value: 12.3},
								"1!idt4": &eqmodel.CbDataPointImpl{ID: "1!idt4", Value: 15.4},
							}, nil /*src*/, nil /*body*/, nil /*err*/
						case "plant-2":
							return map[string]eqmodel.CbDataPoint{
								"remoteIdIDT_O1": &eqmodel.CbDataPointImpl{
									ID:    "remoteIdIDT_O1",
									Value: 22.1,
								},
								"1!idt2": &eqmodel.CbDataPointImpl{ID: "1!idt2", Value: 28.2},
								"1!idt3": &eqmodel.CbDataPointImpl{ID: "1!idt3", Value: 22.3},
								"1!idt4": &eqmodel.CbDataPointImpl{ID: "1!idt4", Value: 25.4},
								"1!idt5": &eqmodel.CbDataPointImpl{ID: "1!idt5", Value: 22.5},
								"1!idt6": &eqmodel.CbDataPointImpl{ID: "1!idt6", Value: 28.6},
								"1!idt7": &eqmodel.CbDataPointImpl{ID: "1!idt7", Value: 22.47},
								"1!idt8": &eqmodel.CbDataPointImpl{ID: "1!idt8", Value: 25.18},
							}, nil /*src*/, nil /*body*/, nil /*err*/
						}

						return nil, nil, nil, cberror.NewCbErrorfWithProps(
							ctx.Service(), 2, nil, map[string]any{"pn": ctx.Provider()},
							"'%s' is not a valid plant id for test", plant,
						)
					}).
				AsOperation(string(locationmodel.ProviderOperationSensorValueIn))
		}).
		// Create the pipe "dpdisc": Data Plane Discovery
		WithPipe(func(pb *providerpipe.PipeBuilderImpl) *providerpipe.PipeBuilderImpl {
			return pb.
				MapSectionIsWithoutPartition().
				HasPartitionIDSeparator(";").
				UseMappingDirection(providermodel.MappingDirectionLeftAssign).
				UseSourceMapWithReport(
					func(
						ctx ifcore.CbContext,
						pipeCtx map[string]any,
						operation string,
						eop *providermodel.Operation,
						pc *providermodel.ProviderConfigImpl,
						rid []string,
						cred any) (map[string]eqmodel.CbDataPoint, any, []byte, cberror.Error) {
						// Simulate call to remote endpoint for discovery
						plant := pc.GetParamAsStringWithDefault(
							string(ifprovider.ParameterPlantID), "",
						)

						switch plant {
						case "plant-1":
							return map[string]eqmodel.CbDataPoint{
								"1!plant-type-var-on-device": &eqmodel.CbDataPointImpl{
									ID: "1!plant-type-var-on-device", Value: "my-setting",
								},
								"1!plant-type-var-on-device-2": &eqmodel.CbDataPointImpl{
									ID: "1!plant-type-var-on-device-2", Value: "bravida-wds1100",
								},
								"1!var-on-device-cnt-sensors": &eqmodel.CbDataPointImpl{
									ID: "1!var-on-device-cnt-sensors", Value: int(4),
								},
							}, nil /*src*/, nil /*body*/, nil /*err*/
						case "plant-2":
							return map[string]eqmodel.CbDataPoint{
								"1!plant-type-var-on-device": &eqmodel.CbDataPointImpl{
									ID: "1!plant-type-var-on-device", Value: "bravida-idt",
								},
								"1!var-on-device-cnt-sensors": &eqmodel.CbDataPointImpl{
									ID: "1!var-on-device-cnt-sensors-2", Value: int(2),
								},
							}, nil /*src*/, nil /*body*/, nil /*err*/
						}

						return nil, nil, nil, cberror.NewCbErrorfWithProps(
							ctx.Service(), 2, nil, map[string]any{"pn": ctx.Provider()},
							"'%s' is not a valid plant id for test", plant,
						)
					}).
				AsOperation(string(locationmodel.ProviderOperationDataPointDiscovery))
		}).
		Build()

	// Create the pipeline executor
	executor := providerpipe.NewProviderPipelineExecutorBuilder(ctx).
		AsOperation(locationmodel.ProviderOperationSensorValueIn).
		UsePipeline(*pipeline).
		FromUserConfig(`{"profile": "multi-plant/discovery"}`).
		Build()

	require.NoError(t, executor.Error())

	results := executor.Execute()
	require.True(t, results.HasResults())
	require.False(t, results.HasError())
	require.Equal(t, 4, len(results))

	// First two *shall* be discovery (since it runs top down)
	assert.Equal(t, locationmodel.ProviderOperationDataPointDiscovery, results[0].Operation)
	assert.Equal(t, locationmodel.ProviderOperationDataPointDiscovery, results[1].Operation)
	// Next *shall* be each of the sub processors to actually import data
	assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, results[2].Operation)
	assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, results[3].Operation)

	// Check the first import (it must be plant-1 since PID_O1)
	ds := results[2].Result["target"].(*dsmodel.DsBuilding)
	assert.Equal(t, "Europe/Stockholm", ds.TimeZone)

	assert.Equal(
		t,
		4,
		len(ds.Sensors),
		"NOTE: If we get 1 here - then when calling ceil func we get back 1 but it do return 4... bug!!",
	)

	assert.Equal(t, float64(12.1), ds.Sensors["IDT_O1"])
	assert.Equal(t, float64(18.2), ds.Sensors["IDT_O2"])
	assert.Equal(t, float64(12.3), ds.Sensors["IDT_O3"])
	assert.Equal(t, float64(15.4), ds.Sensors["IDT_O4"])

	ds = results[3].Result["target"].(*dsmodel.DsBuilding)
	assert.Equal(t, "Europe/Stockholm", ds.TimeZone)
	assert.Equal(t, 2, len(ds.Sensors))
	assert.Equal(t, float64(22.1), ds.Sensors["IDT_O1"])
	assert.Equal(t, float64(25.18), ds.Sensors["IDT_O8"])
}
