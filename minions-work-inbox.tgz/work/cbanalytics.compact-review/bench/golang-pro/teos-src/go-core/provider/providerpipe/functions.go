package providerpipe

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerconfig"
)

// CbIDToRidMap contains the _TEOS_ ID to remote ID mapping.
type CbIDToRidMap map[string]string

// ToRemoteID extracts all the _RemoteID_ from the map and returns it as a list.
func (m CbIDToRidMap) ToRemoteID() []string {
	r := make([]string, len(m))
	i := 0

	for _, rid := range m {
		r[i] = rid
		i++
	}

	return r
}

// ToTeosID extracts all the _TEOS_ ID from the map and returns it as a list.
func (m CbIDToRidMap) ToTeosID() []string {
	r := make([]string, len(m))
	i := 0

	for cid := range m {
		r[i] = cid
		i++
	}

	return r
}

// SourceFunction is the function to populate the pipe with data to process.
//
// This is executed by the `ProviderPipeline` to get populated. If it returns any
// error, the pipe is not executed and will immediately return. This could be
// a call to external endpoint to get data to process.
//
// Outgoing providers may use this function to populate outgoing data to process in
// the pipeline and use the result to *manually* post that data to the remote endpoint.
//
// The _cred_ object is the credential object previously resolved by the provider in a `ObtainCredentialsFunction`
// and `SessionStore`.
//
// The _pc_ parameter is the current (merged) `ProviderConfig` that is being executed.
type SourceFunction func(
	ctx ifcore.CbContext,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	pipeCtx map[string]any,
	cred any) (map[string]any, cberror.Error)

// SourceFunctionWithSelection is the same as `SourceFunction` but also returns a list of `[]providermodel.Selection`(s).
//
// When such is registered in the provider, it will ignore any `SourceFunction` registration and do not
// process or select anything. This is completely done by this function.
type SourceFunctionWithSelection func(
	ctx ifcore.CbContext,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	pipeCtx map[string]any,
	cred any) (map[string]any, []providermodel.Selection, cberror.Error)

// TargetFunction is the function that gets executed when the pipeline has successfully
// executed and there's a target data generated. This target data along with an operation (_op_ parameter)
// is passed into the function.
//
// This is typically an outgoing function where data is pushed into the pipeline using the
// `SourceFunction` and data is emitted using the `TargetFunction`. Not all pipes do make
// use of the `TargetFunction`, instead use the returned target `map` from the `Execute` function.
//
// The _cred_ object is the credential object previously resolved by the provider in a `ObtainCredentialsFunction`
// and `SessionStore`.
//
// The _pc_ parameter is the current (merged) `ProviderConfig` that is being executed.
type TargetFunction func(
	ctx ifcore.CbContext,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	pipeCtx map[string]any,
	cred any, target map[string]any) cberror.Error

// ObtainCredentialsFunction is invoked when a referenced credentials in the `ProviderConfig.Params` using
// `config.ParameterCredentials` key (supplied as _cred_ parameter) and the `SessionStore` do not have such in store.
// For example, when expired the `SessionStore` will purge such object or if never acquired.
//
// This function should then retrieve such object and return this. The `ProviderPipeline` will then store this
// into the `SessionStore` using the key specified in the `ProviderConfig:params`. _See `config.ParameterCredentials` for
// how the _CRED_ string is formatted.
//
// The function is _REQUIRED_ to return a ttl, even if missing from the ttl string. In that case a sensible default should
// be returned. If _token-ttl_ is requested, the provider needs to either authenticate to determine the ttl time or set static
// defaults. The former is a good way to put the OAuth token into the `SessionStore`.
// The ttl is in seconds from now when the object should expire e.g. 3600 is one hour from now.
//
// NOTE: That `ProviderPipeline` expects the returned object as a pointer to the object not the literal object!
//
// .Example Obtain Credential Function
// [source,go]
// ----
// type ClimatixIC struct { // <1>
//
//		Endpoint    string `json:"ep" pms:"endpoint" env:"ENDPOINT"`
//	 Token 		string ´json:"token,omitempty"
//		Credentials struct {
//			User     string `json:"user" env:"CREDENTIALS_USER"`
//			Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
//			APIKey   string `json:"key" env:"CREDENTIALS_KEY"`
//		} `json:"credentials" pms:"credentials, keyid=default"`
//	}
//
// func obtainCredentials(
//
//			context ifcore.CbContext,
//			cred string,
//	   pipeCtx map[string]any,
//			eop *config.Operation) (interface{}, int64, cberror.Error) {
//
//			ptr, ttl := providerpipe.ParseCredString(cred) // <2>
//			var cfg ClimatixIC
//
//			s := config.New(context).UsePrefix(ptr).GetConfig(&cfg) // <3>
//
//		 if "" == s.Endpoint {
//		   s.Endpoint = "api.climatixic.com"
//		 }
//
//		 // Authenticate using credentials to obtain a token.
//		 token := client.Authenticate(cfg.Credentials)
//		 cfg.Token = token // <4>
//
//		 var err error
//		 ttl2 := 3600 /*1h*/
//		 if "token-ttl" == ttl {
//
//			  ttl2 := token.expires // <5>
//
//		 } else {
//
//			  if ttl2, err = strconv.ParseInt(ttl,10,8); err != nil { // <6>
//		     ttl2 = 3600
//		   }
//
//		 }
//
//			return &cfg, ttl2, s.Error() // <7>
//		}
//
// ----
// <1> Sample struct that contains the remote endpoint (for later connect validation, see _VerifyConnectFunction_).
// <2> Parse the credential string to strip out any possibly _ttl_ expression
// <3> Get the config from the ServiceConfig system (_see config.ServiceConfig for more information_)
// <4> This provider caches the token in the struct (that is going to be pushed to `SessionStore` by the pipeline) and thus can reuse the token.
// <5> Climatix OAuth token usually has two days of expire time, but this will set the expiration _ttl_ deemed by remote peer.
// <6> Parse the integer into the _ttl2_ variable and set a sensible default if problems with parsing.
// <7> return the configuration along with default _ttl_, if any errors it is also returned.
//
// For example, the above example wit a _CRED_ parameter of _/provider/climatix/nordvestor:token-ttl_ will search the _AWS Parameter Store_
// with the keys _/provider/climatix/nordvestor/credentials_ (encrypted _JSON_ string) and _/provider/climatix/nordvestor/endpoint_ for data.
//
// NOTE: That a provider may choose to have defaults for a endpoint so it may not be needed in the parameter store, hence api.climatixic.com
// could be the  default for the provider climatix. Thus, only the _credentials_ key is *MANDATORY*.
type ObtainCredentialsFunction func(
	context ifcore.CbContext,
	cred string,
	pipeCtx map[string]any,
	op *providermodel.Operation) (credentials any, ttl int64, err cberror.Error)

// VerifyConnectFunction will invoke this function before using credentials rendered from the in parameter instance _credentials_ or
// from the cred parameter.
//
// This is to verify that the credentials used are used onto the correct DNS or IP target. This is to deflect credential fishing where
// a configuration to use certain credentials towards a site where of user control and hence get the credentials.
//
// .Example Verify Connect
// [source,go]
// ----
// type ClimatixIC struct { // <1>
//
//		Endpoint    string `json:"ep" pms:"endpoint" env:"ENDPOINT"`
//		Credentials struct {
//			User     string `json:"user" env:"CREDENTIALS_USER"`
//			Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
//			APIKey   string `json:"key" env:"CREDENTIALS_KEY"`
//		} `json:"credentials" pms:"credentials, keyid=default"`
//	}
//
// func verifyConnect(cred string, credentials interface{}, eop *providerconfig.Operation) bool {
//
//		if nil == credentials { // <2>
//			return false
//		}
//
//		if c, ok := credentials.(*ClimatixIC); ok { // <3>
//
//			if u, err := url.Parse(eop.Operation); err == nil { // <4>
//				return u.Host == c.Endpoint // <5>
//			}
//		}
//
//		return false // <6>
//	}
//
// ----
// <1> Sample provider struct that provides credentials and which _Endpoint_ those are valid to
// <2> If no credentials is passed, the connection cannot take place since climatixic _REQUIRES_ credentials
// <3> Make sure to safe-cast to expected credentials instance type.
// <4> The _Operation_ parameter may be a https _URL_ or a plain _DNS_ / _IP_ form
// <5> Make sure that the DNS or IP matches the _ClimatixIC.Endpoint_ DNS or IP and return `true` if match.
// <6> This connection is not allowed to be connected.
type VerifyConnectFunction func(ctx ifcore.CbContext, cred string, credentials any, op *providermodel.Operation) bool

// OnPrepare is invoked when the pipe is about to be executed in the `ProviderPipeExecutorImpl`.
type OnPrepare func(
	ctx ifcore.CbContext,
	pipe *ProviderPipeImpl,
	config ifprovider.ConfigFull,
	input, pipeContext map[string]any) cberror.Error

// PrepareProfile is invoked just before `OnSource` and is used to discover the profile to use.
// It will be fed the current profile but it may be replaced by the function.
//
// NOTE: It is possible to do any type of modifications of current profile and the parameters here.
//
// Since it has access to verified and connected credentials, it is possible to call the remote endpoint from here.
//
// If returns a config it will be completely replaced, otherwise it assumes the current is edited inline.
type PrepareProfile func(
	ctx ifcore.CbContext,
	op *providermodel.Operation,
	config ifprovider.ConfigFull,
	pipeContext map[string]any,
	cred any,
	repository *providerconfig.ProviderConfRepository,
) (ifprovider.ConfigFull, cberror.Error)

// OnSource is invoked after any invocation of source function.
// If replace, return the new source map, otherwise return `nil`.
//
// NOTE: If no _source_ data, then the _source_ map can be `nil`.
//
// This is copied into the pipe context so it will be accessible from the pipe.
// This is used in the `ProviderPipeExecutorImpl`.
type OnSource func(
	ctx ifcore.CbContext,
	pipe *ProviderPipeImpl,
	config ifprovider.ConfigFull,
	source map[string]any) (newSource map[string]any, err cberror.Error)

// ExtractTargetFunc is invoked when the target data is to be taken out of a
// pipeline that has finished.
//
// It is given the variables the pipeline finished with, rather than the pipeline
// itself, because by this point the pipeline is over: its blocks have closed and
// their variables are gone. What is left is the outermost block's variables, and
// that is what this is handed.
//
// The default takes the value under the _target_ key. If that value is already a
// `map[string]any` it is returned as it stands, and otherwise it is returned
// inside a map under the key _target_. This is used in the
// `ProviderPipeExecutorImpl`.
type ExtractTargetFunc func(
	ctx ifcore.CbContext,
	vars map[string]any,
	targetKey string,
	config ifprovider.ConfigFull,
) (target map[string]any, err cberror.Error)

// OnTarget is invoked after any invocation of target function and just
// before returning the target to caller.
//
// If target is to be modified, just return _newTarget_, otherwise return `nil`.
// This is used in the `ProviderPipeExecutorImpl`.
type OnTarget func(
	ctx ifcore.CbContext,
	pipe *ProviderPipeImpl,
	config ifprovider.ConfigFull,
	target map[string]any) (newTarget map[string]any, err cberror.Error)

// ReportableSourceFunction is a function that can be used as a `SourceFunction` but allows for automatic reporting.
//
// NOTE: Returning the body of that produced the data points is optional.
//
// NOTE: The _rid_ (Remote ID) parameter is a list of remote sensors to be fetched.
type ReportableSourceFunction func(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	rid []string,
	cred any) (dp []eqmodel.CbDataPoint, body []byte, err cberror.Error)

// ReportableSourceMapFunction is a function that returns a map of data points instead of a list.
//
// This allows for skipping a first step in the pipeline to convert a list of data points into a map
// (_such is done in `ReportableSourceFunction`_).
//
// NOTE: The map _key_ is the _ID_ of the data point.
//
// When _src_ is set it will be placed in the _src_ key in the pipe context. This is optional and may
// be `nil`.
type ReportableSourceMapFunction func(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	rid []string,
	cred any) (dp map[string]eqmodel.CbDataPoint, src any, body []byte, err cberror.Error)

// ReportableTargetFunction is a function that can be used as a `TargetFunction` but allows for automatic reporting.
//
// NOTE: Returning the body of that was sent to remote peer for the _dp_ is optional.
//
// The _rid_ parameter corresponding to the _CbID_ in _cbid_ array.
type ReportableTargetFunction func(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	mapping CbIDToRidMap,
	cred any, target map[string]any) (dp []eqmodel.CbDataPoint, body []byte, err cberror.Error)

// AfterFunction is invoked on after a pipe has successfully invoked target.
//
// NOTE: This may be used to acknowledge a export data.
type AfterFunction func(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	target map[string]any) cberror.Error

// FinallyFunction is always invoked when pipe execution completes, regardless of success or failure.
//
// The pipeErr parameter contains the error from pipe execution (nil if successful).
// The target parameter may be nil if the pipe failed before producing a result.
//
// Return behavior:
//   - Return nil to clear/suppress any pipe error
//   - Return the same pipeErr to propagate unchanged
//   - Return a new/wrapped error to replace the original
//
// NOTE: This is useful for acknowledgment logic that must run regardless of outcome.
type FinallyFunction func(
	ctx ifcore.CbContext,
	pipeCtx map[string]any,
	operation string,
	op *providermodel.Operation,
	pc *providermodel.ProviderConfigImpl,
	target map[string]any,
	pipeErr cberror.Error,
) cberror.Error

// PipelineExecutorForOperationRequest is called when a `ProviderPipeExecutorImpl` is needed to execute a pipe.
//
// The _operation_ is the operation to be executed and _args_ is any arguments that may be used as _overlay_ in
// creation of the the pipe context.
//
// If the _operation_ is not found/supported the ´cberror.ErrProviderOperationNotFound` error is returned.
//
// If the _allowMutateGlobalParams_ is set to `true“
type PipelineExecutorForOperationRequest func(
	ctx ifcore.CbContext,
	pipeline *ProviderPipelineImpl,
	operation string,
	args map[string]any,
	pc ifprovider.ConfigFull,
	allowMutateGlobalParams bool,
) (executor *ProviderPipeExecutorImpl, err cberror.Error)
