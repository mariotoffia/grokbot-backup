package providerpipe

import (
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cbeval"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// expandCbID will check if "MEX" is present in params, if so it will check if the expanded values do
// exists in _dp_ and thus remove the MEX key from _cbid_ and add the expanded values.
//
// .Example
// [source,json]
// ----
//
//	{
//	  "prms": {
//			"MID": "HCT**",
//			"OPT": "**",
//			"MEX": {"HCT**": "HCTST** HCTODT**"} // <1>
//		}
//	}
//
// ----
// <1> Expand HCT to HCTST and HCTODT e.g. HCT_C1 -> HCTST_O1_C1, HCTST_O2_C1, HCTODT_O1_C1, HCTODT_O2_C1 etc...
//
// If no expanded values was found, the original cbid should be present in the returned cbid.
func expandCbID( /* NOSONAR */
	cbid []string,
	pc *providermodel.ProviderConfigImpl,
	dp []eqmodel.CbDataPoint,
) ([]string, error) {
	// Retrieve and assert the MEX parameter type.
	mexParam := pc.GetParamWithDefault("MEX", nil)
	if mexParam == nil {
		return cbid, nil
	}

	mexMap, ok := mexParam.(map[string]interface{})
	if !ok {
		return nil, fmt.Errorf("MEX parameter is not a valid map[string]interface{}")
	}

	expanded := make(map[string][]string)

	// Process each entry in the MEX map.
	for key, value := range mexMap {
		valStr, ok := value.(string)
		if !ok {
			return nil, fmt.Errorf("MEX mapping value for key %s is not a string", key)
		}

		// Use a set to collect unique IDs.
		uniqueIDs := make(map[string]struct{})

		// Split the value into individual patterns.
		for _, idPattern := range strings.Split(valStr, " ") {
			idPattern = strings.TrimSpace(idPattern)
			if idPattern == "" {
				continue
			}

			// If no wildcard is present, perform a substring match.
			if !strings.ContainsAny(idPattern, "*?") {
				for _, dpVal := range dp {
					if strings.Contains(dpVal.GetID(), idPattern) {
						uniqueIDs[dpVal.GetID()] = struct{}{}
					}
				}
			}

			// Always attempt glob expansion.
			glb, err := cbeval.GlobalGlobRegExpCache.Glob(idPattern, '_')
			if err != nil {
				return nil, fmt.Errorf("error expanding MEX id %s: %w", idPattern, err)
			}
			for _, dpVal := range dp {
				if glb.Match(dpVal.GetID()) {
					uniqueIDs[dpVal.GetID()] = struct{}{}
				}
			}
		}

		// If any unique IDs were collected, add them to the expanded map.
		if len(uniqueIDs) > 0 {
			for id := range uniqueIDs {
				expanded[key] = append(expanded[key], id)
			}
		}
	}

	// Build the final cbid slice.
	var result []string
	for _, id := range cbid {
		// First, try literal match.
		if expIDs, found := expanded[id]; found && len(expIDs) > 0 {
			result = append(result, expIDs...)
			continue
		}

		matched := false

		// Iterate over expanded keys to see if the cbid glob matches them.
		for key, expIDs := range expanded {
			// Check if the expanded key is a glob expression.
			if strings.ContainsAny(key, "*?") {
				keyGlob, err := cbeval.GlobalGlobRegExpCache.Glob(key, '_')
				if err != nil {
					return nil, fmt.Errorf(
						"error compiling glob for expanded key %s: %w",
						key,
						err,
					)
				}
				// Use glob matching both ways.
				if keyGlob.Match(id) {
					result = append(result, expIDs...)
					matched = true
				}
			}
		}

		if !matched {
			result = append(result, id)
		}
	}

	return result, nil
}
