package providerconfig

import (
	"bytes"
	"encoding/json"
	"fmt"
	"testing"
	"text/template"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbpipeline"
	"github.com/Thiink-LLC/teos/go-core/cbpipeline/builtin"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// runRenderedPipeline compiles pipeline JSON that was rendered from a provider
// configuration, seeds the pipeline variables from pipeCtx and runs it. It
// returns the value the pipeline left in the variable named "target", which is
// where provider pipelines put their result.
func runRenderedPipeline(
	ctx ifcore.CbContext,
	pipelineJSON []byte,
	pipeCtx map[string]interface{},
) (any, error) {
	reg, regErr := cbpipeline.NewRegistry(builtin.WithBuiltins())
	if regErr != nil {
		return nil, regErr
	}

	doc, readErr := cbpipeline.Read(ctx, pipelineJSON, cbpipeline.WithRegistry(reg))
	if readErr != nil {
		return nil, readErr
	}

	prog, compileErr := cbpipeline.Compile(ctx, doc, reg)
	if compileErr != nil {
		return nil, compileErr
	}

	result, runErr := prog.Run(ctx, cbpipeline.WithVars(pipeCtx))
	if runErr != nil {
		return nil, runErr
	}

	target, _ := result.Get("target")

	return target, nil
}

// cSpell: disable
func TestSetupAndRenderSimpleProviderTemplateWithProviderSpecifyGenerateTemplate(t *testing.T) {
	simpleTemplate := `{
		"set-provider" : {
			"source" : "=asmap(src.Sensors, 'ID')"
		},
		{{if has_mapping}}
			{{mapping}},
		{{end}}
		{{if has_filter}}
			{{filter}},
		{{end}}
		{{- if has_generate "get-sensor-template"}}
		"gen-ds": {{generate}}
		{{else}}
			"gen-ds": {
				"key": "target", "from": "=genref"
			},
			"marshal-ds": {
				"target": "=asmap(marshal(_types.dp, generate), 'Name')"
			}
		{{- end}}
		{{- if has_marshal "sv"}}
			"marshal-ds": {{marshal "asmap(marshal(_types.dp, generate), 'Name')"}}
		{{- end}}
	}`

	ctx := newCtx(t)
	pctx := map[string]interface{}{}
	p := genProviderConfig()
	pc := &p

	_ = ResolvePipeContextFromGlobals(ctx, &p, pctx, nil /*input*/, false /*allowMutate*/)
	tmpl, err := ResolveTemplate(
		&p,
		"test-template",
		"",
		"",
		providermodel.MappingDirectionLeftAssign,
		false, /*delayedGeneratorTemplate*/
		template.FuncMap{},
		pctx,
	).Parse(simpleTemplate)

	assert.Equal(t, nil, err)
	assert.Equal(t, "test-template", tmpl.Name())

	var writer bytes.Buffer
	err = tmpl.Execute(&writer, pc)
	assert.Equal(t, nil, err)

	var res map[string]interface{}
	err = json.Unmarshal(writer.Bytes(), &res)
	assert.Equal(t, nil, err)
	assert.Equal(
		t,
		"=asmap(src.Sensors, 'ID')",
		res["set-provider"].(map[string]interface{})["source"],
	)
	assert.Equal(
		t,
		"=source['Room temp.comf.']",
		res["set-mapping"].(map[string]interface{})["mapped.IDT"],
	)
	assert.Equal(
		t,
		"=V > -100 && V < 100",
		res["set-filter"].(map[string]interface{})["generate.IDT"].(map[string]interface{})["if"],
	)
	assert.Equal(
		t,
		"=mapped['IDT']",
		res["set-filter"].(map[string]interface{})["generate.IDT"].(map[string]interface{})["value"],
	)
	assert.Equal(t, "target", res["gen-ds"].(map[string]interface{})["key"])
	assert.Equal(t, "=genref", res["gen-ds"].(map[string]interface{})["from"])

	assert.Equal(
		t,
		"=asmap(marshal(_types.dp, generate), 'Name')",
		res["marshal-ds"].(map[string]interface{})["target"],
	)
}

func TestCompleteSimpleProvider(t *testing.T) {
	logging := false
	operation := "sv"

	// Sample ClimatixIC values
	type Datapoint struct {
		ID         string  `json:"-"`
		Value      float64 `json:"value"`
		ObjectName string  `json:"objectName"`
	}

	type DatapointList struct {
		Values map[string]Datapoint `json:"values"`
	}

	// thing shadow - should be in common somewhere
	type CbSensorValue struct {
		TS int64   `json:"ts,omitempty"`
		V  float64 `json:"v"`
	}

	type CbBuildingDeviceShadow struct {
		BuildingID string                   `json:"building"`
		Sensors    map[string]CbSensorValue `json:"sensors,omitempty"`
	}

	// Provider is expected to store secrets in param store or secrets manager
	type ClimatixICCredentials struct {
		User     string
		Password string
	}

	// Init provider templates (e.g. in binary or loaded from db / s3)
	ctProfile := `{
	"profile": "cttherm-1",
	"prms": {
		"REP": "climatixic.de/api",
		"PDA": "sv"
	},
	"operations" : {
		"sv" : {
			"oper": "['https://' + REP + '/DataPoints/Values/']",
			"auth": "[{\"apikey\": apikey, \"user\": cred.User, \"pass\": cred.Password}]",
			"prms": {
				"parentId": "['[{\"Plants\":\"[{\"Plants\":\"' + PID + '\"}]\"}]']"
			}
		}
	}
}
--gen=sv
{
	"building": BID,
	"sensors": {
		"IDT": {
			"ts": utcnow(32),
			"v": float64(generate["IDT"].Value)
		},
		"SHCT_C1": {
			"ts" : utcnow(32),
			"v": float64(generate["SHCT_C1"].Value)
		},
		"SHCT_C2": {
			"ts" : utcnow(32),
			"v": float64(generate["SHCT_C2"].Value)
		},
		"ODT": {
			"ts" : utcnow(32),
			"v": float64(generate["ODT"].Value)
		}
	}
}
--policydata=sv
{
    "range": {"IDT**": [-100, 100], "RHCS**": [20, 200]},
    "report": ["ODT", "IDT_O3_**"],
    "skip": ["IDT", "IDT_**"]
}
--pipe=sv
{
	"sensor-values": {
		"set-provider" : {
			"source" : "=asmap(src.Values, 'ID')"
		},
		{{if has_mapping}}
			{{mapping}},
		{{end}}
		{{if has_filter}}
			{{filter}},
		{{end}}
		{{- if has_generate "sv"}}
			"gen-ds": {{generate}}{{- if has_marshal "sv"}},{{end}}
		{{else}}
			"gen-ds": {
				"key": "target", "from": "=genref"
			},
			"marshal-ds": {
				"target": "=marshal(_ts.dsv, target)"
			}
		{{- end}}
		{{- if has_marshal "sv"}}
			"marshal-ds": {{marshal "marshal(_ts.dsv, target)"}}
		{{- end}}
	}
}`

	items, err := ReadConfig(newCtx(t), ctProfile)
	assert.Equal(t, nil, err)
	assert.Equal(t, 4, len(items))

	cfg, err := CreateConfig(items...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, cfg)

	ctx := newCtx(t)
	rep := NewProviderConfigRepository(ctx).Add(cfg)
	assert.NotNil(t, rep)

	// Simulate single sensor sync (e.g. every 15 minute for one building)
	config := `{
		"profile": "cttherm-1",
		"prms": {
			"apikey": "avc12-12291-1221",
			"REP": "climatixic.se/api",
			"BID": "Måssmyren 14",
			"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92"
		},
		"map": {
			"IDT": "1!6WHH75YIZH3STB",
			"SHCT_C1": "1!6WHH75YIXHSYVE",
			"SHCT_C2": "1!6WHH75YIRL4ZZI",
			"ODT": "1!6WHH75YIU4NUCO"
		}
	}`

	useritems, err := ReadConfig(newCtx(t), config)
	assert.Equal(t, nil, err)
	assert.Equal(t, 1, len(useritems))

	usercfg, err := CreateConfig(useritems...)
	assert.Equal(t, nil, err)
	assert.NotNil(t, usercfg)

	merged, _ := rep.Merge(newCtx(t), usercfg.Profile, usercfg)
	assert.NotNil(t, merged)

	assert.Equal(t, 1, len(merged.PolicyData), "shall have one policy data")

	// Load secrets from secrets manager
	pctx := map[string]interface{}{
		"cred": ClimatixICCredentials{
			User:     "nisse@nordvestor.se",
			Password: "PassW0rd!",
		},
		"_ts": map[string]interface{}{
			"dsv": CbBuildingDeviceShadow{},
		},
	}

	// Load generator template in context
	pctx[operation], _, err = CreateGeneratorTemplate(
		newCtx(t),
		merged,
		operation,
		operation,
		true, /*log*/
		pctx,
	)
	assert.Equal(t, nil, err)

	_ = ResolvePipeContextFromGlobals(
		ctx,
		merged,
		pctx,
		nil,   /*input*/
		false, /*allowMutate*/
	)

	require.Contains(t, pctx, "policydata")
	require.NotNil(t, pctx["policydata"])

	pd, ok := pctx["policydata"].(map[string]interface{})
	require.True(t, ok)

	require.NotNil(t, pctx["policydata"])
	// Check that policydata.sv do exists!
	assert.Equal(t, 128, len(pd["sv"].(string)))

	// Generate pipeline
	tmpl, terr := ResolveTemplate(
		merged,
		"sensor-values",
		operation,
		"",
		providermodel.MappingDirectionLeftAssign,
		false, /*delayedGeneratorTemplate*/
		template.FuncMap{},
		pctx,
	).
		Parse(merged.Pipe[operation])

	assert.Equal(t, nil, terr)
	assert.Equal(t, "sensor-values", tmpl.Name())

	// Load datapoints from remote provider (using operation "sv")
	op, err := ResolveOperation(ctx, merged, operation, pctx, nil /*input*/)
	assert.Equal(t, nil, err)

	assert.Equal(t, "https://climatixic.se/api/DataPoints/Values/", op.Operation)
	assert.Equal(
		t,
		`[{"Plants":"[{"Plants":"P7ac8f2a3-7069-484c-b745-dca3ce11bb92"}]"}]`,
		op.Params["parentId"],
	)

	dplist := DatapointList{Values: map[string]Datapoint{
		"1!6WHH75YIZH3STB": {ID: "1!6WHH75YIZH3STB", Value: 22.0, ObjectName: "Room temp.comf."},
		"1!6WHH75YIXHSYVE": {
			ID:         "1!6WHH75YIXHSYVE",
			Value:      89.0,
			ObjectName: "P1 Flow temp. Design",
		},
		"1!6WHH75YIRL4ZZI": {ID: "1!6WHH75YIRL4ZZI", Value: 76.0, ObjectName: "P2 Flow temp."},
		"1!6WHH75YIU4NUCO": {
			ID:         "1!6WHH75YIU4NUCO",
			Value:      -17.0,
			ObjectName: "P1 Outs.temp.design",
		},
	}}

	pctx["src"] = dplist

	var writer bytes.Buffer
	terr = tmpl.Execute(&writer, merged)
	assert.Equal(t, nil, terr)

	if logging {
		fmt.Println(writer.String())
	}

	trg, runErr := runRenderedPipeline(ctx, writer.Bytes(), pctx)
	require.NoError(t, runErr)
	require.NotNil(t, trg)

	tds, ok := trg.(*CbBuildingDeviceShadow)
	require.True(t, ok, "the pipeline must leave a building shadow in the variable \"target\"")

	if logging {
		fmt.Printf("%#v\n", tds)
	}

	// Update thing shadow!
}

func BenchmarkCompleteSimpleProvider(t *testing.B) {
	operation := "sv"

	// Sample ClimatixIC values
	type Datapoint struct {
		ID         string  `json:"-"`
		Value      float64 `json:"value"`
		ObjectName string  `json:"objectName"`
	}

	type DatapointList struct {
		Values map[string]Datapoint `json:"values"`
	}

	// thing shadow - should be in common somewhere
	type CbSensorValue struct {
		TS int64   `json:"ts,omitempty"`
		V  float64 `json:"v"`
	}

	type CbBuildingDeviceShadow struct {
		BuildingID string                   `json:"building"`
		Sensors    map[string]CbSensorValue `json:"sensors,omitempty"`
	}

	// Provider is expected to store secrets in param store or secrets manager
	type ClimatixICCredentials struct {
		User     string
		Password string
	}

	// Init provider templates (e.g. in binary or loaded from db / s3)
	ctProfile := `{
	"profile": "cttherm-1",
	"prms": {
		"REP": "climatixic.de/api"
	},
	"operations" : {
		"sv" : {
			"oper": "['https://' + REP + '/DataPoints/Values/']",
			"auth": "[{\"apikey\": apikey, \"user\": cred.User, \"pass\": cred.Password}]",
			"prms": {
				"parentId": "['[{\"Plants\":\"[{\"Plants\":\"' + PID + '\"}]\"}]']"
			}
		}
	}
}
--gen=sv
{
	"building": BID,
	"sensors": {
		"IDT": {
			"ts": utcnow(32),
			"v": float64(generate["IDT"].Value)
		},
		"SHCT_C1": {
			"ts" : utcnow(32),
			"v": float64(generate["SHCT_C1"].Value)
		},
		"SHCT_C2": {
			"ts" : utcnow(32),
			"v": float64(generate["SHCT_C2"].Value)
		},
		"ODT": {
			"ts" : utcnow(32),
			"v": float64(generate["ODT"].Value)
		}
	}
}
--policydata
{
    "range": {"IDT**": [-100, 100], "RHCS**": [20, 200]},
    "report": ["ODT", "IDT_O3_**"],
    "skip": ["IDT", "IDT_**"]
}
--pipe=sv
{
	"sensor-values": {
		"set-provider" : {
			"source" : "=asmap(src.Values, 'ID')"
		},
		{{if has_mapping}}
			{{mapping}},
		{{end}}
		{{if has_filter}}
			{{filter}},
		{{end}}
		{{- if has_generate "sv"}}
			"gen-ds": {{generate}}{{- if has_marshal "sv"}},{{end}}
		{{else}}
			"gen-ds": {
				"key": "target", "from": "=genref"
			},
			"marshal-ds": {
				"target": "=marshal(_ts.dsv, target)"
			}
		{{- end}}
		{{- if has_marshal "sv"}}
			"marshal-ds": {{marshal "marshal(_ts.dsv, target)"}}
		{{- end}}
	}
}`

	items, _ := ReadConfig(newCtx(t), ctProfile)
	cfg, _ := CreateConfig(items...)
	ctx := newCtx(t)
	rep := NewProviderConfigRepository(ctx).Add(cfg)

	// Since init is only done once per lambda
	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		// Simulate single sensor sync (e.g. every 15 minute for one building)
		config := `{
		"profile": "cttherm-1",
		"prms": {
			"apikey": "avc12-12291-1221",
			"REP": "climatixic.se/api",
			"BID": "Måssmyren 14",
			"PID": "P7ac8f2a3-7069-484c-b745-dca3ce11bb92"
		},
		"map": {
			"IDT": "1!6WHH75YIZH3STB",
			"SHCT_C1": "1!6WHH75YIXHSYVE",
			"SHCT_C2": "1!6WHH75YIRL4ZZI",
			"ODT": "1!6WHH75YIU4NUCO"
		}
	}`

		useritems, _ := ReadConfig(newCtx(t), config)
		usercfg, _ := CreateConfig(useritems...)
		merged, _ := rep.Merge(newCtx(t), usercfg.Profile, usercfg)
		// Load secrets from secrets manager
		pctx := map[string]interface{}{
			"cred": ClimatixICCredentials{
				User:     "nisse@nordvestor.se",
				Password: "PassW0rd!",
			},
			"_ts": map[string]interface{}{
				"dsv": CbBuildingDeviceShadow{},
			},
		}

		pctx[operation], _, _ = CreateGeneratorTemplate(
			newCtx(t),
			merged,
			operation,
			operation,
			true, /*log*/
			pctx,
		)
		_ = ResolvePipeContextFromGlobals(
			ctx,
			merged,
			pctx,
			nil,   /*input*/
			false, /*allowMutate*/
		)

		tmpl, _ := ResolveTemplate(
			merged,
			"sensor-values",
			operation,
			"",
			providermodel.MappingDirectionLeftAssign,
			false, /*delayedGeneratorTemplate*/
			template.FuncMap{},
			pctx,
		).
			Parse(merged.Pipe[operation])

		_, _ = ResolveOperation(ctx, merged, operation, pctx, nil /*input*/)

		dplist := DatapointList{Values: map[string]Datapoint{
			"1!6WHH75YIZH3STB": {
				ID:         "1!6WHH75YIZH3STB",
				Value:      22.0,
				ObjectName: "Room temp.comf.",
			},
			"1!6WHH75YIXHSYVE": {
				ID:         "1!6WHH75YIXHSYVE",
				Value:      89.0,
				ObjectName: "P1 Flow temp. Design",
			},
			"1!6WHH75YIRL4ZZI": {ID: "1!6WHH75YIRL4ZZI", Value: 76.0, ObjectName: "P2 Flow temp."},
			"1!6WHH75YIU4NUCO": {
				ID:         "1!6WHH75YIU4NUCO",
				Value:      -17.0,
				ObjectName: "P1 Outs.temp.design",
			},
		}}

		pctx["src"] = dplist

		var writer bytes.Buffer
		_ = tmpl.Execute(&writer, merged)

		if _, err := runRenderedPipeline(ctx, writer.Bytes(), pctx); err != nil {
			t.Fatal(err)
		}
	}
}

//cSpell: enable
