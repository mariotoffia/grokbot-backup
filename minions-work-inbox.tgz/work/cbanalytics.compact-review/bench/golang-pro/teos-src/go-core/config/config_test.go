package config

import (
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	"github.com/rs/zerolog"
	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"
)

// newCtx builds a production-tier context: the tier is part of the
// environment variable names these tests set.
func newCtx(tb testing.TB, opts ...ifcore.CbContextOption) (ifcore.CbContext, error) {
	tb.Helper()
	testenv.Use(tb, testenv.EnvDefaults)

	c, err := ctx.NewContextWithDefaultOptions("test-svc", "test", cbenv.Prod, opts...)
	if err == nil {
		tb.Cleanup(c.Close)
	}

	zerolog.SetGlobalLevel(zerolog.FatalLevel)
	return c, err
}

// cSpell:disable

// TestOverrideWithEnvShallWork is a test that will only use environment variables
// as backing property. It will try to use _JSON_, and _Secrets Manager_, and _Parameter Store_
// property - but will fail and fall back on environment.
func TestOverrideWithEnvShallWork(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration e2e TestOverrideWithEnvShallWork in short mode")
	}

	type Test struct {
		ClimatixIC  string `json:"endpoint" pms:"endpoint, remote-peer=climatixic" env:"ENDPOINT"`
		Credentials struct {
			APIKey   string `json:"apikey" env:"CREDENTIALS_API_KEY"`
			Username string `json:"user" env:"CREDENTIALS_USER"`
			Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
		} `                                                                      asm:"credentials, remote-peer=climatixic,type=credentials"`
	}

	ctx, err := newCtx(t)
	assert.Equal(t, nil, err)

	t.Setenv("CB_PROD_TEST_SVC_ENDPOINT", "https://api.climatixic.com/")
	t.Setenv("CB_PROD_TEST_SVC_CREDENTIALS_API_KEY", "krsdjki238ujks")
	t.Setenv("CB_PROD_TEST_SVC_CREDENTIALS_USER", "gördis")
	t.Setenv("CB_PROD_TEST_SVC_CREDENTIALS_PASSWORD", "passw0rd")

	var config Test
	err = New(ctx).GetConfig(&config).Error()

	// In environments without AWS Parameter Store / Secrets Manager
	// access, the loader is allowed to fall through to env vars
	// silently (err == nil). When the remote lookups are attempted
	// and fail, the loader surfaces a wrapped error containing the
	// "Parameter Store or Secrets Manager" sentinel - assert that
	// shape, but only when an error is reported.
	if err != nil {
		assert.True(
			t,
			strings.Contains(
				err.Error(),
				"Failed to get config from Parameter Store or Secrets Manager",
			),
		)
	}

	assert.Equal(t, "https://api.climatixic.com/", config.ClimatixIC)
	assert.Equal(t, "krsdjki238ujks", config.Credentials.APIKey)
	assert.Equal(t, "gördis", config.Credentials.Username)
	assert.Equal(t, "passw0rd", config.Credentials.Password)
}

// TestFromBackingJSONWithOneEnvOverrideShallWork will test to load _JSON_ data
// and have all data. However, the password property is overridden by an environment
// variable.
func TestFromBackingJSONWithOneEnvOverrideShallWork(t *testing.T) {
	if testing.Short() {
		t.Skip(
			"Skipping integration test TestFromBackingJSONWithOneEnvOverrideShallWork in short mode",
		)
	}

	type Test struct {
		ClimatixIC  string `json:"endpoint" env:"ENDPOINT"`
		Credentials struct {
			APIKey   string `json:"apikey" env:"CREDENTIALS_API_KEY"`
			Username string `json:"user" env:"CREDENTIALS_USER"`
			Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
		}
	}

	c, err := newCtx(t)
	assert.Equal(t, nil, err)

	setup := Test{ClimatixIC: "https://api.climatixic.com/"}
	setup.Credentials.APIKey = "krsdjki238ujks"
	setup.Credentials.Username = "gördis"
	setup.Credentials.Password = "passw0rd"

	file := New(c).renderJSONConfigName(reflect.TypeOf(setup))
	d, _ := json.Marshal(&setup)
	_ = writeFileOverwrite(file, d)

	defer func() { _ = os.Remove(file) }()

	t.Setenv("CB_PROD_TEST_SVC_CREDENTIALS_USER", "gösta")

	var config Test
	err = New(c).GetConfig(&config).Error()
	assert.Equal(t, nil, err)

	assert.Equal(t, "https://api.climatixic.com/", config.ClimatixIC)
	assert.Equal(t, "krsdjki238ujks", config.Credentials.APIKey)
	assert.Equal(t, "gösta", config.Credentials.Username)
	assert.Equal(t, "passw0rd", config.Credentials.Password)
}

// TestAllFromBackingJSONShallWork where all data is backed on a _JSON_ file.
func TestAllFromBackingJSONShallWork(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestAllFromBackingJSONShallWork in short mode")
	}

	type Test struct {
		ClimatixIC  string `json:"endpoint" env:"ENDPOINT"`
		Credentials struct {
			APIKey   string `json:"apikey" env:"CREDENTIALS_API_KEY"`
			Username string `json:"user" env:"CREDENTIALS_USER"`
			Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
		}
	}

	ctx, err := newCtx(t)
	assert.Equal(t, nil, err)

	setup := Test{ClimatixIC: "https://api.climatixic.com/"}
	setup.Credentials.APIKey = "krsdjki238ujks"
	setup.Credentials.Username = "gördis"
	setup.Credentials.Password = "passw0rd"

	file := New(ctx).renderJSONConfigName(reflect.TypeOf(setup))
	d, _ := json.Marshal(&setup)
	_ = writeFileOverwrite(file, d)

	defer func() { _ = os.Remove(file) }()

	var config Test
	err = New(ctx).GetConfig(&config).Error()
	assert.Equal(t, nil, err)

	assert.Equal(t, "https://api.climatixic.com/", config.ClimatixIC)
	assert.Equal(t, "krsdjki238ujks", config.Credentials.APIKey)
	assert.Equal(t, "gördis", config.Credentials.Username)
	assert.Equal(t, "passw0rd", config.Credentials.Password)
}

// TestCreateReportWithJSONBackingFile will instantiate a config and create
// a report on that config.
//
// It uses _JSON_ config file, _Secrets Manager_, _Parameter Store_ but no
// environment variables.
func TestCreateReportWithJSONBackingFile(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestCreateReportWithJSONBackingFile in short mode")
	}

	t.Skip("TODO:")

	type Test struct {
		ClimatixIC  string `pms:"endpoint, remote-peer=climatixic" env:"ENDPOINT"`
		Credentials struct {
			APIKey   string `json:"apikey" env:"CREDENTIALS_API_KEY"`
			Username string `json:"user" env:"CREDENTIALS_USER"`
			Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
		} `                                                      asm:"credentials, remote-peer=climatixic,type=credentials"`
	}

	ctx, err := newCtx(t)
	assert.Equal(t, nil, err)

	setup := Test{ClimatixIC: "https://api.climatixic.com/"}
	setup.Credentials.APIKey = "krsdjki238ujks"
	setup.Credentials.Username = "gördis"
	setup.Credentials.Password = "passw0rd"

	file := New(ctx).renderJSONConfigName(reflect.TypeOf(setup))
	d, _ := json.Marshal(&setup)
	_ = writeFileOverwrite(file, d)

	defer func() { _ = os.Remove(file) }()

	var config Test

	sc := New(ctx)
	report := sc.ReportConfig(&config)

	if sc.Error() != nil {
		assert.FailNowf(t, sc.Error().Error(), "")
	}

	fmt.Println(report)

	assert.Contains(t, report, `"fqname": "/prod/test-service/endpoint"`)
	assert.Contains(t, report, `"remote-peer": "climatixic"`)
	assert.Contains(t, report, `"fqname": "/prod/test-service/credentials"`)
	assert.Contains(t, report, `"type": "parameter-store"`)
	assert.Contains(t, report, `"type": "secrets-manager"`)
	assert.Contains(
		t,
		report,
		`"value": "{\"apikey\":\"krsdjki238ujks\",\"user\":\"gördis\",\"password\":\"passw0rd\"}"`,
	)
	assert.Contains(t, report, `"valuetype": "SecureString"`)
	assert.Contains(t, report, `"valuetype": "String"`)
}

// writeFileOverwrite makes sure that the _file- is deleted
// and *then* the _data_ is written onto the _file_ (path).
func writeFileOverwrite(file string, data []byte) error {
	_ = os.Remove(file)
	err := os.WriteFile(file, data, 0600) //nolint:gosec // G306 - test helper function
	if err != nil {
		return err
	}

	return nil
}

// cSpell:enable
