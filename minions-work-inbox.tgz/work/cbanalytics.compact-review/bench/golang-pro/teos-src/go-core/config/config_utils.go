package config

import (
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"strings"

	envConfig "github.com/mariotoffia/go-envconfig"
	"github.com/mariotoffia/ssm"
	"github.com/mariotoffia/ssm/support"
	"github.com/rs/zerolog"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/logger"
)

// renderJSONConfigName returns the name of the JSON file this configuration
// reads type t from. See [JSONFileName].
func (sc *ServiceConfig) renderJSONConfigName(t reflect.Type) string {
	return JSONFileName(sc.context.DeployEnv(), sc.context.Service(), sc.prefix, t.Name())
}

// JSONFileName returns the name of the file the JSON layer reads a
// configuration from, in lower case. Without a prefix it is
// env.service.type-name.config.json. A prefix local to the service gives
// env.service.prefix.type-name.config.json. A prefix that starts with "/" is
// global: the service name is left out, giving env.prefix.type-name.config.json.
// A "/" inside the prefix becomes "-", and so does a "/" in the service name
// when there is no prefix. Code that writes such a file, for example a
// deployment stack that bundles it with a Lambda function, calls this so its
// name matches the one the loader reads.
func JSONFileName(env cbenv.DeployEnv, service, prefix, typeName string) string {
	if prefix != "" {
		if strings.HasPrefix(prefix, "/") {
			// global
			prefix = prefix[1:]
			service = ""
		}

		prefix = strings.ReplaceAll(prefix, "/", "-")
	}

	if prefix == "" {
		fn := strings.ToLower(fmt.Sprintf("%s.%s.%s.config.json",
			env.String(),
			service,
			typeName))

		return strings.ReplaceAll(fn, "/", "-")
	}

	if service == "" {
		// global
		fn := strings.ToLower(fmt.Sprintf("%s.%s.%s.config.json",
			env.String(),
			prefix,
			typeName))

		return strings.ReplaceAll(fn, "/", "-")
	}

	// local
	return strings.ToLower(fmt.Sprintf("%s.%s.%s.%s.config.json",
		env.String(),
		service,
		prefix,
		typeName))
}

// renderEnvPrefix renders a formal configuration environment variable prefix.
func (sc *ServiceConfig) renderEnvPrefix() string {
	// envFormat formats the string into a environment
	// variable friendly format.
	envFormat := func(str string) string {
		str = strings.ReplaceAll(str, "-", "_")
		str = strings.ReplaceAll(str, ".", "_")
		str = strings.ReplaceAll(str, "/", "_")
		return str
	}

	service := envFormat(sc.context.Service())
	prefix := sc.prefix

	if prefix != "" {
		if strings.HasPrefix(prefix, "/") {
			// global
			prefix = prefix[1:]
			service = ""
		}

		prefix = envFormat(prefix)
	}

	if prefix == "" {
		return strings.ToUpper(fmt.Sprintf("CB_%s_%s_",
			sc.context.DeployEnv().String(),
			service))
	}

	if service == "" {
		// global
		return strings.ToUpper(fmt.Sprintf("CB_%s_%s_",
			sc.context.DeployEnv().String(),
			prefix))
	}

	// local
	return strings.ToUpper(fmt.Sprintf("CB_%s_%s_%s_",
		sc.context.DeployEnv().String(),
		service,
		prefix))
}

func (sc *ServiceConfig) fromJSON(config interface{}, t reflect.Type) cberror.Error {
	fn := sc.renderJSONConfigName(t)

	data, err := os.ReadFile(fn)
	if err != nil {
		return cberror.NewCbErrorf(
			sc.context.Service(), cberror.ErrorCfgUnableToLocateJsonCfgFile, err,
			"Could not locate file %s", fn,
		)
	}

	err = json.Unmarshal(data, config)
	if err != nil {
		return cberror.NewCbErrorf(
			sc.context.Service(),
			cberror.ErrorCfgUnableToUnmarshalJsonCfgFile,
			err,
			"Failed to unmarshal JSON %s to %s",
			fn,
			t.Name(),
		)
	}

	return nil
}

// get is the actual worker function for getting the configuration
//
// If _assert_ is set to true, it will not suppress errors of any form.
func (sc *ServiceConfig) get(config interface{}, assert bool) *ServiceConfig {
	if len(sc.layers) == 0 {
		sc.layers = LayerAllDefaultOrder
	}

	v := reflect.ValueOf(config)
	if v.Kind() != reflect.Pointer || v.IsNil() {
		sc.err = cberror.NewCbErrorf(sc.context.Service(), cberror.ErrorCfgInvalidPtr, nil,
			"Must pass struct by pointer and it must no be null - kind: %s", v.Kind().String())

		return sc
	}

	cfg := reflect.Indirect(v)
	t := cfg.Type()

	if t.Kind() != reflect.Struct {
		sc.err = cberror.NewCbErrorf(
			sc.context.Service(),
			cberror.ErrorCfgInvalidStruct,
			nil,
			"The config %s is not of struct kind (it is of kind: %s)",
			t.Name(),
			t.Kind().String(),
		)

		return sc
	}

	for _, layer := range sc.layers {
		switch layer {
		case LayerJSON:
			// Read from backing JSON file
			if errJSON := sc.fromJSON(config, t); errJSON != nil {
				level := zerolog.TraceLevel
				if errJSON.Code() != cberror.ErrorCfgUnableToLocateJsonCfgFile {
					level = zerolog.WarnLevel
				}

				if l, ok := logger.ClsLog(level, "get", logger.LDTUntyped, logger.LISUnclassified, sc.context); ok {
					l.Msgf(
						"Failed to get / unmarshal JSON backing config file: '%s' with error '%v'",
						sc.renderJSONConfigName(t), errJSON,
					)
				}

				if assert {
					sc.err = errJSON
					return sc
				}
			}
		case LayerSSM:
			// Apply parameter store and secrets manager
			s := ssm.NewSsmSerializer(sc.context.DeployEnv().String(), sc.context.Service())

			if sc.prefix != "" {
				s.UsePrefix(sc.prefix)
			}

			fields, errSSM := s.UnmarshalWithOpts(
				config,
				&support.FieldFilters{Filters: sc.filters},
				ssm.AllTags,
			)

			if errSSM != nil {
				if l, ok := logger.ClsLog(zerolog.WarnLevel, "config::get", logger.LDTUntyped, logger.LISUnclassified, sc.context); ok {
					l.Msgf(
						"Failed to get config from Parameter Store or Secrets Manager with error '%s'",
						errSSM.Error(),
					)
				}

				sc.err = cberror.NewCbErrorf(
					sc.context.Service(), cberror.ErrorCfgUnableToRetrieveCfg, errSSM,
					"Failed to get config from Parameter Store or Secrets Manager, error: %s",
					errSSM.Error(),
				)
			}

			if len(fields) > 0 {
				sc.err = cberror.NewCbErrorf(
					sc.context.Service(), cberror.ErrorCfgUnableToRetrieveCfg, nil,
					"Failed to get config from Parameter Store or Secrets Manager, fields: %v",
					fields,
				)

				for _, field := range fields {
					errStr := ""
					if field.Error != nil {
						errStr = field.Error.Error()
					}

					if l, ok := logger.ClsLog(zerolog.InfoLevel, "config::get", logger.LDTUntyped, logger.LISUnclassified, sc.context); ok {
						l.Msgf(
							"[SSM] Failed to get config field: %s remote: %s, error: %s",
							field.LocalName, field.RemoteName, errStr,
						)
					}
				}
			}

		case LayerEnv:
			// Populate from environment variables
			l := envConfig.PrefixLookuper(sc.renderEnvPrefix(), envConfig.OsLookuper())
			if err := envConfig.ProcessWith(
				sc.context, config, l, envConfig.WriteAll); err != nil {
				if l, ok := logger.ClsLog(zerolog.WarnLevel, "get", logger.LDTUntyped, logger.LISUnclassified, sc.context); ok {
					l.Msgf(
						"Failed to get config from environment variables, error: %s", err.Error(),
					)
				}

				sc.err = cberror.NewCbErrorf(
					sc.context.Service(), cberror.ErrorCfgUnableToRetrieveCfg, err,
					"Failed to get config from environment variables, error: %s", err.Error(),
				)
			}
		}
	}

	return sc
}
