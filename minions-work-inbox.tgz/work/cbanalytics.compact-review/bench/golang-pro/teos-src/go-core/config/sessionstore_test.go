package config

import (
	"fmt"
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"

	"github.com/stretchr/testify/assert"
)

func TestAddStructPersistEncryptShallWork(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestAddStructPersistEncryptShallWork in short mode")
	}

	type Test struct {
		Data string
		Age  int
	}

	ctx, _ := newCtx(t)
	store := NewSessionStore(ctx)

	defer store.Dispose()

	s := Test{
		Data: "hello world",
		Age:  17,
	}
	store.Put("testobject", &s, true /*persist*/, true /*encrypt*/)
	assert.Equal(t, nil, store.Error())

	i := store.Get("testobject").(*item)
	assert.True(t, &s == i.object)
	assert.True(t, fileutils.FileExists(i.renderFilePath()))

	data := i.loadFile()
	data = i.decrypt(data)

	str := i.unmarshal(data)
	assert.Equal(t, nil, i.Error())
	assert.Equal(t, &s, str)
}

func BenchmarkAddStructPersistEncrypt(b *testing.B) {
	type Test struct {
		Data string
		Age  int
	}

	ctx, _ := newCtx(b)
	store := NewSessionStore(ctx)

	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		s := Test{
			Data: "hello world",
			Age:  17,
		}

		store.Put(fmt.Sprintf("testobject-%d", i), &s, true /*persist*/, true /*encrypt*/)
	}

	b.Cleanup(func() {
		store.Dispose()
	})
}

func TestAddStringPersistEncryptShallWork(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestAddStringPersistEncryptShallWork in short mode")
	}

	ctx, _ := newCtx(t)
	store := NewSessionStore(ctx)

	defer store.Dispose()

	s := `{"some":"json", "data":42}`
	store.Put("testobject", s, true /*persist*/, true /*encrypt*/)
	assert.Equal(t, nil, store.Error())

	i := store.Get("testobject").(*item)
	assert.Equal(t, s, i.Object())
	assert.True(t, fileutils.FileExists(i.renderFilePath()))

	data := i.loadFile()
	data = i.decrypt(data)

	str := i.unmarshal(data)
	assert.Equal(t, s, str)
}

func TestAddPurgeAndGetObjectAgainShallReloadObject(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestAddPurgeAndGetObjectAgainShallReloadObject in short mode")
	}

	ctx, _ := newCtx(t)
	store := NewSessionStore(ctx)

	defer store.Dispose()

	s := `{"some":"json", "data":42}`
	store.Put("testobject", s, true /*persist*/, true /*encrypt*/)
	assert.Equal(t, nil, store.Error())

	i := store.Get("testobject")
	assert.Equal(t, s, i.Object())

	store.Purge(i)
	assert.Equal(t, nil, store.Error())
	assert.Equal(t, nil, store.objects[i.Name()].object)

	i = store.Get("testobject")
	assert.Equal(t, s, i.Object().(string))
}

func TestExpireShallDeleteTheObject(t *testing.T) {
	if testing.Short() {
		t.Skip("Skipping integration test TestExpireShallDeleteTheObject in short mode")
	}

	ctx, _ := newCtx(t)
	store := NewSessionStore(ctx)

	defer store.Dispose()

	s := `{"some":"json", "data":42}`
	store.PutExpire("testobject", s, time.Now().Unix()+3 /*3s*/, true /*persist*/, true /*encrypt*/)
	assert.Equal(t, nil, store.Error())

	fp := store.Get("testobject").(*item).renderFilePath()
	assert.True(t, fileutils.FileExists(fp))

	i := store.Get("testobject")
	assert.Equal(t, s, i.Object())

	time.Sleep(3 * time.Second)

	i = store.Get("testobject")
	assert.Equal(t, nil, i)
	assert.False(t, fileutils.FileExists(fp))

}
