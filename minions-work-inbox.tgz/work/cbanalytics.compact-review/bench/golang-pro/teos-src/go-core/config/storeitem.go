package config

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"

	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils/fileutils"
)

// SessionStoreItem is the items to be stored in the `SessionStore`
type SessionStoreItem interface {
	// Name is a unique name of the item. This is what the item is keyed with.
	Name() string
	// Object is the actual object that is in the session store, keyed with the `Name()`.
	//
	// Since the object may reside on persistence, this method call may incur a load time.
	Object() interface{}
	// Error return the latest error in the `SessionStoreItem`. If it is in error state the
	// `Object()` function returns _nil_. Use `ClearError()` to retry.
	Error() cberror.Error
	// ClearError clears any errors in this instance.
	ClearError() SessionStoreItem
}

type item struct {
	// store is the bound `SessionStore`.
	store *SessionStore
	// name if the item.
	name string
	// object that this item represents.
	object interface{}
	// size is the size of the object (marshalled data).
	size int
	// objectType describes the type in `object` field.
	objectType reflect.Type
	// key is the key that the item is encrypted / decrypted with on persistence (`file()`).
	//
	// Each `SessionStoreItem` do have a unique encryption key.
	key []byte
	// context is the _Lambda_ generic context (not request context!).
	context ifcore.CbContext
	// Last error occurred
	err cberror.Error
	// encrypted is set to true when the object should be encrypted onto persistence.
	encrypted bool
	// persistence is set to true when the object should be persisted. If false, it will
	// never be persisted.
	persistence bool
	// ttl is the unix 32 bit time (in seconds) when this object shall be obsoleted.
	ttl int64
}

// newItem creates a new item to be put into a store.
// If clone, provide with _key_ data since it *must* share the key.
//
// The ttl is specified as a unix 32 time (in seconds) when the object is obsolete
// and should be removed from memory and persistence. When an object
// has ceased to exist the `Object()` method will return nil and `Error`
// is flagged that cannot be cleared (_with code 999_).
func (s *SessionStore) newItem(
	object interface{},
	name string,
	persist, encrypt bool, ttl int64, key []byte) *item {
	i := &item{
		name:        name,
		object:      object,
		objectType:  reflect.TypeOf(object),
		key:         key,
		store:       s,
		persistence: persist,
		encrypted:   encrypt,
		ttl:         ttl,
	}

	if len(key) == 0 {
		i.key = i.generateKey()
	}

	data := i.marshal()
	if i.err != nil {
		return i
	}

	i.size = len(data)

	if persist {
		if encrypt {
			data = i.encrypt(data)
		}

		if i.err == nil {
			i.persistToFile(data)
		}
	}

	return i
}

// clone does a shallow clone of the `item`
func (i *item) clone() *item {
	return &item{
		name:        i.name,
		context:     i.context,
		encrypted:   i.encrypted,
		err:         i.err,
		key:         i.key,
		object:      i.object,
		objectType:  i.objectType,
		persistence: i.persistence,
		size:        i.size,
		store:       i.store,
		ttl:         i.ttl,
	}

}

// Name of the item.
func (i *item) Name() string {
	return i.name
}

// Error returns the last error that has occurred. If none `nil` is returned.
func (i *item) Error() cberror.Error {
	return i.err
}

// ClearError will clear any `Error()` state in this item.
func (i *item) ClearError() SessionStoreItem {
	if i.err != nil && i.err.Code() == 999 {
		return i
	}

	i.err = nil
	return i
}

// hasExpired checks if an item has expired and returns `true`
// in such case,  otherwise `false` is returned.
func (i *item) hasExpired() bool {
	return time.Now().Unix() >= i.ttl
}

// Object retrieves the underlying object (if any).
//
// If this `SessionStoreItem` is has expired it will set the error state to code _999_
// (Object timeout) and return `nil`.
func (i *item) Object() interface{} {
	if i.err != nil {
		return nil
	}

	if i.hasExpired() {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgSessionStoreTimeout, nil, "Object timeout",
		)

		return nil
	}

	return i.object
}

// generateKey will generate a 32 byte 256bit symmetric encryption key
// to use when encrypting the data.
//
// If the `SessionStoreItem` is already in error state when calling `generateKey`
// it will return `nil`. If it fails to generate a random key it will set
// the `SessionStoreItem` into a error state (_code 801_).
func (i *item) generateKey() []byte {
	if i.err != nil {
		return nil
	}

	key := make([]byte, 32)
	_, reader := rand.Read(key)

	if reader != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToCreateKey, reader,
			"Failed to create key for item: %s, err: %s",
			i.name, reader.Error(),
		)
	}

	return key
}

// encrypt will encrypt the data and return the encrypted payload.
//
// If `SessionStoreItem` is in error state when invoking this function
// it will return `nil`. If any, below, errors, the function will return `nil`.
//
// .Errors that encrypt may set
// |===
// |Error Code |Cause
//
// |802 |When `NewCipher` fails to create _AES_ Cipher
// |803 |When `NewGCM` fails
// |804 |When fail to encrypt the payload
//
// |===
func (i *item) encrypt(data []byte) []byte {
	if i.err != nil {
		return nil
	}

	blockCipher, err := aes.NewCipher(i.key)

	if err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToCreateCipher, err,
			"encrypt::NewCipher error: %s for key: %s", err.Error(), i.name,
		)

		return nil
	}

	gcm, err := cipher.NewGCM(blockCipher)

	if err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToCreateGCM, err,
			"encrypt::NewGCM error: %s for key: %s", err.Error(), i.name,
		)

		return nil
	}

	nonce := make([]byte, gcm.NonceSize())

	if _, err = rand.Read(nonce); err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToEncryptPayload, err,
			"encrypt::rand.Read(nonce) error: %s for key: %s", err.Error(), i.name,
		)

		return nil
	}

	cipherText := gcm.Seal(nonce, nonce, data, nil)
	return cipherText

}

// decrypt will decrypt the data and return the decrypted payload.
//
// If `SessionStoreItem` is in error state when invoking this function
// it will return `nil`. If any, below, errors, the function will return `nil`.
//
// .Errors that decrypt may set
// |===
// |Error Code |Cause
//
// |812 |When `NewCipher` fails to create _AES_ Cipher
// |813 |When `NewGCM` fails
// |814 |When fail to decrypt the payload
//
// |===
func (i *item) decrypt(data []byte) []byte {
	if i.err != nil {
		return nil
	}

	blockCipher, err := aes.NewCipher(i.key)

	if err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToCreateCipher, err,
			"decrypt::NewCipher error: %s for key: %s", err.Error(), i.name,
		)

		return nil
	}

	gcm, err := cipher.NewGCM(blockCipher)

	if err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToCreateGCM, err,
			"decrypt::NewGCM error: %s for key: %s", err.Error(), i.name,
		)

		return nil
	}

	nonce, cipherText := data[:gcm.NonceSize()], data[gcm.NonceSize():]
	plaintext, err := gcm.Open(nil, nonce, cipherText, nil)

	if err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToDecryptPayload, err,
			"decrypt::gcm.Open error: %s for key: %s", err.Error(), i.name,
		)

		return nil
	}

	return plaintext
}

// renderFilePath renders a filepath where the session store tmp directory.
func (i *item) renderFilePath() string {
	return filepath.Join(i.store.rootpath, fmt.Sprintf("%s.sstore", i.name))
}

// persistToFile will persist the _data_ onto the filesystem based on the `item.name`.
//
// If it fails, it will return an `cberror.Error`. Error codes are _821_ when it could not
// create the file and _822_ if problems with writing the file.
func (i *item) persistToFile(data []byte) {
	if i.err != nil {
		return
	}

	fp := i.renderFilePath()

	f, fileError := os.OpenFile(fp, os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0755)

	if nil != fileError {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToOpenFile, fileError,
			"Failed to open file: %s, error: %s", fp, fileError.Error(),
		)

		return
	}

	defer func() {
		if fileError := f.Close(); nil != fileError {
			var tmp error

			if i.err != nil {
				tmp = i.err
			} else {
				tmp = fileError
			}

			i.err = cberror.NewCbErrorf(
				i.store.context.Service(), cberror.ErrorCfgUnableToCloseFile, tmp,
				"Failed to close file: %s, error: %s", fp, fileError.Error(),
			)
		}
	}()

	if n, fileError := f.Write(data); nil != fileError {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToWriteToFile, fileError,
			"Failed to write to file: %s, bytes written: %d, error: %s", fp, n, fileError.Error(),
		)
	}

}

// deleteFile will delete the file from persistence (if it exists).
//
// If the file exist but could not be removed, an error is set
// with error code of _823_.
func (i *item) deleteFile() {
	if i.err != nil {
		return
	}

	fp := i.renderFilePath()

	if !fileutils.FileExists(fp) {
		return
	}

	if err := os.Remove(fp); err != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToDeleteFile, err,
			"Failed to delete to file: %s, error: %s", fp, err.Error(),
		)
	}
}

// loadFile will load a file from the filesystem based on the `item.name`.
//
// If it does not exist, it will return an empty `byte` array. If it fails
// to read the file, it will set an error with error code of _824_.
func (i *item) loadFile() []byte {
	if i.err != nil {
		return []byte{}
	}

	fp := i.renderFilePath()

	if !fileutils.FileExists(fp) {
		return []byte{}
	}

	filedata, fileerr := os.ReadFile(fp)

	if nil != fileerr {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToLoadFile, fileerr,
			"Could not load file %s, error: %s", fp, fileerr.Error(),
		)

		return []byte{}
	}

	return filedata
}

// marshal will marshal the contained `Object` into a byte array.
//
// If the `SessionStoreItem` is in error mode it will return an empty array.
// If the object is `nil` it will set the `SessionStoreItem` in error mode (code _831_).
// When marshal error it set the error mode code to _832_.
//
// NOTE: If the contained `Object()` is a string, it will write the string as is, without
// marshal using _JSON_ marshaller.
func (i *item) marshal() []byte {
	if i.err != nil {
		return []byte{}
	}

	if nil == i.object {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgMarshal, nil,
			"Failed to marshal object named: %s, since no object loaded", i.name,
		)

		return []byte{}
	}

	if str, ok := i.object.(string); ok {
		return []byte(str) // special case!
	}

	jsondata, jsonerr := json.Marshal(i.object)
	if jsonerr != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgMarshal, nil,
			"Failed to marshal object named: %s, error: %s", i.name, jsonerr.Error(),
		)
	}

	return jsondata
}

// stringType is just a reflect type cache to use when marshal / unmarshal.
var stringType = reflect.TypeOf("")

// unmarshal will unmarshal the _data_ parameter into a instance.
//
// If the `SessionStoreItem` is in error mode, `nil` is returned. If it
// fails to unmarshal it sets the error with error code of _833_.
//
// NOTE: If the contained type is a string, it will read the string as is, without
// unmarshal using _JSON_ marshaller.
func (i *item) unmarshal(data []byte) interface{} {
	if i.err != nil {
		return nil
	}

	if i.objectType == stringType {
		return string(data) // special case!
	}

	// Create a new instance of objectType
	v := reflect.New(i.objectType.Elem()).Interface()

	if jsonerr := json.Unmarshal(data, v); jsonerr != nil {
		i.err = cberror.NewCbErrorf(
			i.store.context.Service(), cberror.ErrorCfgUnableToUnmarshalJsonCfgFile, jsonerr,
			"Failed to unmarshal object named: %s, error: %s", i.name, jsonerr.Error(),
		)
	}

	return v
}
