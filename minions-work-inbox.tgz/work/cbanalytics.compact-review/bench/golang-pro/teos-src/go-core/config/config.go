package config

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"

	"github.com/mariotoffia/ssm"
	"github.com/mariotoffia/ssm/support"
)

// ServiceConfig is a config manager that handles configurations
// mostly aimed for services.
//
// The service config supports layering of configuration (
// _see overview for more information_).
type ServiceConfig struct {
	// prefix is set, if mult instance use a prefix while resolving the
	// configuration. Hence each `struct` may have multiple
	// sets of configuration.
	prefix string
	// layers are used to determine how and which config sources the
	// `struct` is resolved to. Default is `LayerAllDefaultOrder`.
	layers []Layer
	// context is the current thiink context.
	context ifcore.CbContext
	// filters is an optional set of filters to include / exclude filters.
	filters []support.FieldFilter
	// last error
	err cberror.Error
}

// Layer specifies a configuration layer
//
// It is possible to configure which layer should be part when resolving the data
// as well as the override order. The higher the ordinal, the more likely that
// data is resolved through that mechanism.
type Layer int

const (
	// LayerJSON specifies a backing file with json data
	// to populate the configuration.
	LayerJSON Layer = iota
	// LayerSSM is either parameter store or secrets manager.
	// It can also be a combination of both.
	LayerSSM
	// LayerEnv is environment variables that may populate the
	// configuration
	LayerEnv
)

// LayerAllDefaultOrder specifies all layers with the default order
// of applying.
//
// .Default order where it resolves the variable contents
// |===
// |Ordinal |Comment
//
// |1
// |Default json file <env>.<service name>.<interface name>.config.json
//
// |2
// |Parameter Store / Secrets Manager
//
// |3
// |Environment variables
//
// |===
//
// Hence environment variable will always win
var LayerAllDefaultOrder []Layer = []Layer{LayerJSON, LayerSSM, LayerEnv}

// New creates a new instance of the `ServiceConfig`.
func New(context ifcore.CbContext) *ServiceConfig {
	return &ServiceConfig{
		layers:  LayerAllDefaultOrder,
		context: context,
	}

}

// UseLayers will use specified layers when resolving one or more `struct`(s).
//
// Use this function if `LayerAllDefaultOrder` is not appropriate.
//
// NOTE: This function will overwrite all layers on each invocation. Also
// note that the ordering of layers is preserved.
//
// .Example Usage
// [source,go]
// ----
//
//	type MyConf struct {
//	  Endpoint string `json:"ep" env:"ENDPOINT", pms:"endpoint"` // <1>
//	  Timeout int `json:"timeout" env:"TIMEOUT" pms:"timeout"`
//	}
//
// var conf MyConf
// sc := New(ctx).
//
//	UseLayers(config.LayerJSON, config.LayerEnv). // <2>
//	Get(&conf)
//
// ----
// <1> The pms tags is ignored since no `config.LayerSSM` is configured
// <2> The order of resolving is _JSON_ and then _Environment_ variables.
func (sc *ServiceConfig) UseLayers(layers ...Layer) *ServiceConfig {
	sc.layers = layers
	return sc
}

// UsePrefix sets a prefix (default is "") when resolving config
//
// When a _prefix_ is set, it acts as a default prefix if no
// prefix is specified in the tag. Prefix operates under two modes
// _Local_ and _Global_. Prefixes may have multiple components and not
// just one name e.g. _my-prefix/sub-component_.
//
// .Local vs Global Mode
// [cols="1,1,4"]
// |===
// |Mode |Example |Description
//
// |Local
// |my-local-prefix/nested
// |This will render environment/service/my-local-prefix/nested/property. E.g. dev/tes-service/my-local-prefix/nested/password
//
// |Global
// |/my-global-prefix/nested
// |This will render environment/my-global-prefix/nested/property. E.g. dev/my-global-prefix/nested/password
//
// |===
//
// NOTE: When global prefix, the _service_ element is eliminated (in order to have singeltons).
//
// A prefix is translated differently depending on the `config.Layer`
//
// .Prefix Translation
// |===
// |Layer |Pattern Global |Pattern Local |Example
//
// |LayerJSON
// |deploy-env.prefix.struct-name.config.json
// |deploy-env.service-name.prefix.struct-name.config.json
// |JSON file name example: dev.test-service.my-prefix-next-gen.dbconfig.config.json
//
// |LayerSSM
// |environment/my-global-prefix/property-name
// |environment/service/my-local-prefix/property-name
// |dev/test-service/my-local-prefix/credentials
//
// |LayerEnv
// |CB_environment_my_global_prefix_property_env_tag_name (_ALL UPPERCASE_)
// |CB_environment_service_my_local_prefix_property_env_tag_name (_ALL UPPERCASE_)
// |CB_DEV_TEST_SERVICE_MY_LOCAL_PREFIX_CREDENTIALS_USER
//
// |===
//
// # The examples above are taken from this example struct
//
// .Example Struct
// [source,go]
// ----
// type DbConfig struct { // <1>
//
//	  Timeout int `json:"timeout" pms:"timeout" env:"TIMEOUT"` // <2>
//	  Credentials struct {
//
//			User string `json:"user" env:"CREDENTIALS_USER"`
//	     Password string `json:"password" env:"CREDENTIALS_PASSWORD"`
//	     APIKey string `json:"key" env:"CREDENTIALS_KEY"`
//
//	  } `json:"credentials" pms:"credentials, keyid=default"` // <3>
//	}
//
// ----
// <1> The _JSON_ config file will be named after this e.g. dev.test-service.my-prefix.*dbconfig*.config.json
// <2> This is a simple property with no parameter store encryption
// <3> This is a _JSON_ payload for _JSON_ config file, _AWS Pararameter Store / Secrets Manager_ but *not* for environment!
func (sc *ServiceConfig) UsePrefix(prefix string) *ServiceConfig {
	sc.prefix = prefix
	return sc
}

// UseFilters will add filters to use as inclusion / exclusion filter.
//
// If multiple include / exclude use the builder to create the filters.
//
// .Example Usage of Filter Builder
// [source,go]
// ----
// config.New(ctx).
//
//	UseFilters(
//	  support.NewFilters().
//	    Include("db.ConnectionString").
//	    Include("db.TimeStack").
//	    Filters...,
//	).
//	Get(&myConf)
//
// ----
func (sc *ServiceConfig) UseFilters(filters ...support.FieldFilter) *ServiceConfig {
	sc.filters = append(sc.filters, filters...)
	return sc
}

// ClearFilters will clear all filters and defaults to include *everything*.
func (sc *ServiceConfig) ClearFilters() *ServiceConfig {
	sc.filters = nil
	return sc
}

// Error returns the last error encountered.
//
// When the `ServiceConfig` is in error mode no get / report
// function will perform any work.
func (sc *ServiceConfig) Error() cberror.Error {
	return sc.err
}

// ClearError clears the last error.
func (sc *ServiceConfig) ClearError() *ServiceConfig {
	sc.err = nil
	return sc
}

// GetConfig fetches the configuration and is overridden
// in the specified configuration for field filters, and layers.
//
// WARNING: Make sure to check `Error()` so the `ServiceConfig` is clean from errors, otherwise nothing is fetched!
//
// .Example Usage
// [source,go]
// ----
// type MyConf struct { // <1>
//
//	  Endpoint string `json:"ep" env:"ENDPOINT", pms:"endpoint"`
//	  Timeout int `json:"timeout" env:"TIMEOUT" pms:"timeout"`
//	}
//
// var conf MyConf
// sc := New(ctx).Get(&conf) // <2>
//
//	if sc.Error() != nil {
//	  // handle error
//	}
//
// // sc is now populates from JSON, parameter store &
// // secrets manager and environment.
// ----
// <1> Define a configuration structure, you may have nested structs as well as _JSON_ serialized structs.
// <2> Get the configuration using the default layer config (_JSON -> SSM -> ENV_).
//
// Assuming the above `ifcore.CbContext.Service()` is set to _test-service_, deploy environment set to `Prod`,
// the environment variables are named
//
// * CB_PROD_TEST_SERVICE_ENDPOINT
// * CB_PROD_TEST_SERVICE_TIMEOUT
//
// # The secrets or parameters are named
//
// * /prod/test-service/endpoint
// * /prod/test-service/timeout
//
// _JSON_ file name is _prod.test-service.myconf.config.json and content is
//
// .JSON file Content
// [source,json]
// ----
//
//	{
//	  "ep": "the endpoint here",
//	  "timeout": 30
//	}
//
// ----
func (sc *ServiceConfig) GetConfig(config interface{}) *ServiceConfig {
	if sc.err != nil {
		return sc
	}

	sc.get(config, false /*assert*/)
	return sc
}

// GetConfigAsserted is same as `GetConfig` but will make sure to return error if
// config not found or not populated.
func (sc *ServiceConfig) GetConfigAsserted(config interface{}) *ServiceConfig {
	if sc.err != nil {
		return sc
	}

	sc.get(config, true /*assert*/)
	return sc
}

// ReportConfig produces a report in JSON format that may be used to generate CDK artifacts from.
// TODO: Currently only parameter store and secrets manager data is reported.
func (sc *ServiceConfig) ReportConfig(config interface{}) string {
	if sc.err != nil {
		return ""
	}

	if nil != sc.get(config, false /*assert*/).Error() {
		return ""
	}

	s := ssm.NewSsmSerializer(sc.context.DeployEnv().String(), sc.context.Service())
	_, data, err := s.ReportWithOpts(
		config,
		&support.FieldFilters{Filters: sc.filters},
		true, /*values*/
	)

	if err != nil {
		sc.err = cberror.NewCbErrorf(
			sc.context.Service(),
			cberror.ErrorCfgUnableToCreateCfgReport,
			err,
			"Failed to produce report - error '%v'",
			err,
		)
	}

	return data
}
