package config_test

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/config"
)

// TestJSONFileName checks the name the JSON layer reads a configuration from,
// for a service without a prefix, a service name that holds a slash, a prefix
// local to the service and a global prefix (one that starts with a slash).
func TestJSONFileName(t *testing.T) {
	tests := []struct {
		name     string
		service  string
		prefix   string
		typeName string
		want     string
	}{
		{"no prefix", "providerdispatcher", "", "FolderMapper", "devlocal.providerdispatcher.foldermapper.config.json"},
		{"slash in service", "actuationsvc/providerdispatcher", "", "FolderMapper", "devlocal.actuationsvc-providerdispatcher.foldermapper.config.json"},
		{"local prefix", "test-svc", "my/prefix", "DbConfig", "devlocal.test-svc.my-prefix.dbconfig.config.json"},
		{"global prefix", "test-svc", "/shared/db", "DbConfig", "devlocal.shared-db.dbconfig.config.json"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.want, config.JSONFileName(cbenv.DevLocal, tt.service, tt.prefix, tt.typeName))
		})
	}
}
