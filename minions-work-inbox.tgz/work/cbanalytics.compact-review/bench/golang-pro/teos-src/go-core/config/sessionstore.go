package config

import (
	"os"
	"sync"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// SessionStore is a local store that have temporal storage for configuration or anything that needs
// protecting but can be re-retrieved such as config from `ServiceConfig` or a lambda local
// OAuth token etc.
//
// `SessionStore` is a local, volatile, storage that have the ability to encrypt / decrypt
// data based on in-memory session keys. Therefore it cannot be shared by different processes.
// That is true even on *same* _Lambda_ (e.g. lambda-extension-function).
//
// NOTE: This is a thread safe store.
type SessionStore struct {
	// rootpath is the root to the filesystem store.
	rootpath string
	// err contains the last error.
	err cberror.Error
	// context contains a thiink context. Make sure it do not contain a lambda request context
	// since this is meant to be created before that. Instead use the global _Lambda_ context created
	// go `main` for the _Lambda_.
	context ifcore.CbContext

	// objects in this store. if the `item.object` is nil and `item.err == nil` the object has been purged
	// from memory and needs to be loaded before returning it.
	//
	// Only clones are returned and hence each retrieval have their own instance (*but shared pointers!*).
	objects map[string]*item
	// mtx is the mutex for the `objects` map.
	mtx sync.Mutex
}

// NewSessionStore create a new instance of the session store. One service _SHOULD_ only
// have one instance of this.
//
// Therefore this store is thread safe.
func NewSessionStore(context ifcore.CbContext) *SessionStore {
	tmp, err := os.MkdirTemp("", "session-store")

	store := &SessionStore{
		rootpath: tmp,
		context:  context,
		objects:  map[string]*item{},
	}

	if err != nil {
		store.err = cberror.NewCbErrorf(
			context.Service(),
			cberror.ErrorCfgUnableToCreateTmpDirectory,
			err,
			"Failed to create temp directory for session store, error: %s",
			err.Error(),
		)
	}

	return store
}

// Dispose will completely wipe the session store persistence.
func (s *SessionStore) Dispose() {
	_ = os.RemoveAll(s.rootpath)
}

// Error returns the last error.
func (s *SessionStore) Error() cberror.Error {
	return s.err
}

// ClearError will clear any error in the `SessionStore`.
func (s *SessionStore) ClearError() *SessionStore {
	s.err = nil
	return s
}

// Purge removes the _item_ object from in-memory and leave it on persistence
// if such exists.
//
// It does not remove the actual *item*, instead the `object` reference is cleared
// and hence only will be garbage collected.
func (s *SessionStore) Purge(item SessionStoreItem) *SessionStore {
	s.mtx.Lock()
	defer s.mtx.Unlock()

	if s.err != nil {
		return s
	}

	if itm, ok := s.objects[item.Name()]; ok {
		itm.object = nil
		s.objects[itm.name] = itm
	}

	return s
}

// Get retrieves `SessionStoreItem` from the store if found, otherwise `nil`
// is returned.
//
// The returned instance is a clone and hence receiver do have its own pointers
// to the object, even if it will be purged. But it points to the same object instance
// and hence modifications on the object level will be visible for multiple consumers.
//
// Make sure to check if any error in the `SessionStoreItem` by the `Error()` method before
// accessing `Object()` since it will return `nil` in such case.
//
// It may return nil even if the object do exist and no `Error()` is present. This is due to
// if the item has expired or an error while loading the data from persistence when the object
// was earlier `Purge`.
func (s *SessionStore) Get(name string) SessionStoreItem {
	s.mtx.Lock()
	defer s.mtx.Unlock()

	if s.err != nil {
		return nil
	}

	if itm, ok := s.objects[name]; ok {
		if itm.hasExpired() {
			s.delete(name)
			return nil
		}

		i := itm.clone()
		if nil == i.object && i.persistence {
			data := i.loadFile()

			if nil != i.Error() {
				return nil
			}

			if i.encrypted {
				data = i.decrypt(data)
			}

			i.object = i.unmarshal(data)
		}

		return i
	}

	return nil
}

// Put accepts a a _object_ with a unique _name_. If _persist_ is `true`, it will also
// be persited onto the, volatile, session store. Also if _encrypted_ is set to `true`
// the persisted data is stored using a unique key for the object itself.
//
// If object already exist with given _name_ this method will fail and set the `SessionStore` in error
// state. If the _object_ is a string, it will be persisted as normal string and thus do not submit the
// pointer to the string.
//
// This do not consider expiration time, use `PutExpire` to do that.
func (s *SessionStore) Put(name string, object interface{}, persist, encrypt bool) *SessionStore {
	return s.PutExpire(name, object, 9223372036854775807 /*max int64*/, persist, encrypt)

}

// PutExpire accepts a a _object_ with a unique _name_. If _persist_ is `true`, it will also
// be persited onto the, volatile, session store. Also if _encrypted_ is set to `true`
// the persisted data is stored using a unique key for the object itself.
//
// If object already exist with given _name_ this method will fail and set the `SessionStore` in error
// state (code _841_). If the _object_ is a string, it will be persisted as normal string and thus do not submit the
// pointer to the string.
//
// In contrast to `Put` this function accepts a _ttl_ in unix 32 time (seconds) when the object is purged upon
// get.
func (s *SessionStore) PutExpire(
	name string,
	object interface{},
	ttl int64,
	persist, encrypt bool,
) *SessionStore {
	s.mtx.Lock()
	defer s.mtx.Unlock()

	if s.err != nil {
		return s
	}

	if _, ok := s.objects[name]; ok {
		s.err = cberror.NewCbErrorf(
			s.context.Service(), cberror.ErrorCfgNameAlreadyRegistered, nil,
			"Failed put object named: %s since it already registered", name,
		)

		return s
	}

	s.objects[name] = s.newItem(object, name, persist, encrypt, ttl, nil)

	return s
}

// Delete will completely delete the object from the `SessionStore`, include delete
// the file from persistence.
func (s *SessionStore) Delete(name string) *SessionStore {
	s.mtx.Lock()
	defer s.mtx.Unlock()

	return s.delete(name)
}

// delete will completely delete the object from the `SessionStore`, include delete
// the file from persistence.
func (s *SessionStore) delete(name string) *SessionStore {
	if s.err != nil {
		return s
	}

	if itm, ok := s.objects[name]; ok {
		delete(s.objects, name)
		itm.deleteFile()
	}

	return s
}
