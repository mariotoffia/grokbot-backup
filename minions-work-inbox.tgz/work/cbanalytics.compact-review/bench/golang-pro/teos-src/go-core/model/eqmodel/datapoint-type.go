package eqmodel

// DataPointType is a generic datapoint in contrast of `SensorType`
// that is a `DataPointType` that _is_ a sensor.
type DataPointType string

const (
	// DataPointEnabledCircuits is represented as _ECR_ and
	// contains a bit vector.
	//
	// Bit zero is _Circuit 1_, bit two is _Circuit 2_ and so on.
	// It is a integer representation. Thus, if circuit 1 and 2 is
	// enabled it will have the value of 3.
	DataPointEnabledCircuits DataPointType = "ECR"
	// DataPointCommunicationTimer is represented as _COMT_ and is
	// a float specifying in hours when the underlying system shall
	// take over control.
	//
	// The protocol is, that _Thiink_ shall update this timer before
	// it has ran out. Thus, the link between thiink and the controlling
	// system may be down for a certain amount of time (written in _COMT_) and
	// if the timer has not yet reached zero and thiink updates the timer,
	// thiink will still be in control. If it reaches zero, the system will
	// take control until this timer is updated again.
	DataPointCommunicationTimer DataPointType = "COMT"
	// DataPointCommunicationTimerFromControllingAlgorithm is a _COMT_ that originates from
	// the controlling algorithm. This is a number in _minutes_ how long a controlling
	// signal is valid until it should be discarded.
	//
	// If present, overrides any default _COMT_ in profiles on eastbound providers.
	DataPointCommunicationTimerFromControllingAlgorithm DataPointType = "COMTALG"
	// DataPointReceivedEventTime Is stamped when the event was received by the system. This is a RFC3339
	// timestamp.
	DataPointReceivedEventTime DataPointType = "RET"
	// DataPointNoOperation is a datapoint that do not have any meaning.
	//
	// It may be used to e.g. state that a source based subscription (i.e. client
	// decides what to send) is still alive/subscribed (since when empty dp in
	// subscription messages means unsubscribe).
	DataPointNoOperation DataPointType = "NOP"
	// DataPointEffectSavingPerHourLocal is the energy expressed as saving of energy
	// in kW for one hour. This is a calculated value by the algorithm
	// controlling the system.
	//
	// This value can be used to show the local saving i.e. over a short period of time
	// (hence local). To aggregate a longer period of time use the `DataPointEffectSavingPerHourGlobal`
	// instead.
	//
	// This value is recalculated every hour and hence aggregated over short period of time
	// to give a total saving of energy in kWh for the aggregated (short) period of time.
	//
	// Unit: kW, Resolution: 0.1 kW
	DataPointEffectSavingPerHourLocal DataPointType = "ESHL"
	// DataPointEffectSavingPerHourGlobal is the energy expressed as saving of energy
	// in kW for one hour. This is a calculated value by the algorithm
	// controlling the system.
	//
	// This value can be used to show the global saving i.e. over a longer period of time
	// (hence global). To show the more "mountainous" (in hours) saving use the `DataPointEffectSavingPerHourLocal`
	// instead.
	//
	// This value is recalculated every hour and hence aggregated over time
	// to give a total saving of energy in kWh for the aggregated period of time.
	//
	// Unit: kW, Resolution: 0.1 kW
	DataPointEffectSavingPerHourGlobal DataPointType = "ESHG"
	// DataPointCurrentEnergyBuffer is the calculated energy buffer
	// in the system.
	//
	// Unit: kWh, Resolution: 0.1 kWh
	DataPointCurrentEnergyBuffer DataPointType = "CEB"
	// DataPointMaxEnergyBuffer is the maximum energy buffer in the system.
	//
	// Unit: kWh, Resolution: 0.1 kWh
	DataPointMaxEnergyBuffer DataPointType = "MEB"
	// DataPointNormalEnergyBuffer is the normal energy buffer in the system.
	// Where _normal_ is the usage over time and is calculated by the system.
	//
	// Unit: kWh, Resolution: 0.1 kWh
	DataPointNormalEnergyBuffer DataPointType = "NEB"
	// DataPointWeatherOutdoorTemp is the outdoor temperature in a weather forecast.
	//
	// Unit: °C, Resolution: 0.1 °C
	DataPointWeatherOutdoorTemp DataPointType = "WODT"
	// DataPointWeatherCloudiness is the cloudiness in the weather.
	//
	// Unit: %, Resolution: 1 %
	DataPointWeatherCloudiness DataPointType = "WCL"
	// DataPointWeatherHumidity is the humidity in the weather.
	//
	// Unit: %, Resolution: 1 %
	DataPointWeatherHumidity DataPointType = "WHU"
	// DataPointWeatherTemperature is the temperature in the weather.
	//
	// Unit: °C, Resolution: 0.1 °C
	DataPointWeatherTemperature DataPointType = "WTE"
	// DataPointWeatherWindSpeed is the wind speed in the weather.
	//
	// Unit: m/s, Resolution: 0.1 m/s
	DataPointWeatherWindSpeed DataPointType = "WWS"
	// DataPointWeatherWindDirection is the wind direction in the weather.
	//
	// Unit: °, Resolution: 1 °
	DataPointWeatherWindDirection DataPointType = "WWD"
	// DataPointWeatherPrecipitation is the precipitation in the weather.
	//
	// Unit: mm, Resolution: 0.1 mm
	DataPointWeatherPrecipitation DataPointType = "WPR"
	// DataPointWeatherPressure is the pressure in the weather.
	//
	// Unit: hPa, Resolution: 0.1 hPa
	DataPointWeatherPressure DataPointType = "WPRS"
	// DataPointWeatherSunrise is the sun is rising.
	//
	// Unit: RFC3339, Resolution: 1 s
	DataPointWeatherSunrise DataPointType = "WSR"
	// DataPointWeatherSunset is when the sun is setting.
	//
	// Unit: RFC3339, Resolution: 1 s
	DataPointWeatherSunset DataPointType = "WSS"
	// DataPointWeatherWindChill is how much the wind is chilling the temperature.
	//
	// Unit: °C, Resolution: 0.1 °C
	DataPointWeatherWindChill DataPointType = "WCH"
	// DataPointAverageIndoorTempControl is the average indoor temperature
	// that is used in current optimization calculations to control the
	// climate.
	DataPointAverageIndoorTempControl DataPointType = "AVGIDTC"
	// DataPointIndoorTempMinControl is the minimum indoor setting from a
	// controlling algorithm that is controlling the indoor temperature.
	DataPointIndoorTempMinControl DataPointType = "MINIDTC"

	// DataPointOperationalState is indicating how a remote system is doing
	// e.g. online, offline, error, etc.
	DataPointOperationalState DataPointType = "OPS"

	// DataPointOperationalInternalState is same as `DataPointOperationalState`
	// but is a internal state of the remote system and may be anything.
	DataPointOperationalInternalState DataPointType = "OPIS"
)
