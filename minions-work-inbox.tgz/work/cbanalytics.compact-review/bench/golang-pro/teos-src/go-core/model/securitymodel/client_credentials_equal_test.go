package securitymodel_test

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"

	"github.com/stretchr/testify/assert"
)

// ═══════════════════════════════════════════════
// ClientCredentialsMaterial Equal()
// ═══════════════════════════════════════════════

func TestClientCredentialsMaterial_Equal_Identical(t *testing.T) {
	a := securitymodel.ClientCredentialsMaterial{
		Auth:         "https://auth.teos.io",
		ClientId:     "cid",
		ClientSecret: "csec",
		Endpoint:     "https://api.teos.io",
		Id:           "id1",
		Key:          "apikey",
		ObjectType:   "client",
		Password:     "pass",
		User:         "user",
	}
	b := a
	assert.True(t, a.Equal(b))
}

func TestClientCredentialsMaterial_Equal_EachFieldDiffers(t *testing.T) {
	base := securitymodel.ClientCredentialsMaterial{
		Auth:         "auth",
		ClientId:     "cid",
		ClientSecret: "csec",
		Endpoint:     "ep",
		Id:           "id",
		Key:          "key",
		ObjectType:   "ot",
		Password:     "pw",
		User:         "usr",
	}

	fields := []struct {
		name  string
		other securitymodel.ClientCredentialsMaterial
	}{
		{"Auth", func() securitymodel.ClientCredentialsMaterial { c := base; c.Auth = "x"; return c }()},
		{"ClientId", func() securitymodel.ClientCredentialsMaterial { c := base; c.ClientId = "x"; return c }()},
		{"ClientSecret", func() securitymodel.ClientCredentialsMaterial { c := base; c.ClientSecret = "x"; return c }()},
		{"Endpoint", func() securitymodel.ClientCredentialsMaterial { c := base; c.Endpoint = "x"; return c }()},
		{"Id", func() securitymodel.ClientCredentialsMaterial { c := base; c.Id = "x"; return c }()},
		{"Key", func() securitymodel.ClientCredentialsMaterial { c := base; c.Key = "x"; return c }()},
		{"ObjectType", func() securitymodel.ClientCredentialsMaterial { c := base; c.ObjectType = "x"; return c }()},
		{"Password", func() securitymodel.ClientCredentialsMaterial { c := base; c.Password = "x"; return c }()},
		{"User", func() securitymodel.ClientCredentialsMaterial { c := base; c.User = "x"; return c }()},
	}

	for _, tt := range fields {
		t.Run(tt.name, func(t *testing.T) {
			assert.False(t, base.Equal(tt.other))
		})
	}
}

func TestClientCredentialsMaterial_Equal_ZeroValues(t *testing.T) {
	var a, b securitymodel.ClientCredentialsMaterial
	assert.True(t, a.Equal(b))
}
