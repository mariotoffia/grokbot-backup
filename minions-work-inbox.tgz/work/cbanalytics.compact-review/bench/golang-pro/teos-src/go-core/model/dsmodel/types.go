package dsmodel

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

// DsMetaTimeStamp is the _Unix Epoch Timestamp_ object for a variable in the
// thing shadow
type DsMetaTimeStamp struct {
	// Timestamp is standard 32 bit _Unix Epoch Timestamp_ and is administered
	// by the cloud provider, hence it is *read-only*.
	Timestamp coremodel.CbTime32 `json:"timestamp"`
}

// DsBase base type that specific thing shadow types
// may include.
type DsBase struct {
	// Version is the integer version and is updated by the cloud provider
	// automatically. Hence, it is *read-only*.
	Version int `json:"version"`
	// Timestamp is the _Unix Epoch Timestamp_ when the thing shadow was last updated.
	Timestamp coremodel.CbTime32 `json:"timestamp"`
	// ClientToken is an optional value to specify which client that was updating the
	// thing shadow.
	//
	// ClientToken can be any value, however, in thiink there are certain clients
	// that encodes / react to specific _ClientToken_Format.
	//
	// .Client Token Format
	// |===
	// |Id |Example Value |Description
	//
	// |provider
	// |climatixic
	// |This is the provider name in lower-case letters
	//
	// |uuid
	// |5c3a5d2f-80f3-4b2a-82a3-dae1ff31cb25
	// |A version 4 UUID unique for this particular thing shadow write
	//
	// |action
	// |cc-evt
	// a|A action requested to be executed by a listener of the thing shadow. For example, when _cc-evt_ is
	//   specified and the direction is outbound. It will make the provider dispatcher to look for configuration
	//   in the _cc-evt_ folder and feed it to the found providers.
	//
	// |direction
	// |inbound
	// |Specifies if the direction is _inbound_ or _outbound_ - denotes if value are reported (inbound) or desired (outbound)
	// |===
	//
	// TIP: It is rendered using the following form: _provider:uuid:direction_ and hence
	// it is possible to use e.g a _IoT Rule_ to select inbound only  data by `SELECT *,
	// topic() as topic FROM '$aws/things/+/shadow/name/building/update/accepted' WHERE
	// endswith(clientToken, 'inbound')`.
	ClientToken string `json:"clientToken,omitempty"`
	// Origin is the client token of the update this message was copied from.
	// It is empty for an update that is not a copy.
	//
	// The core router sets it on every mirror copy it sends to the eastbound
	// dispatcher. The dispatcher uses it to find the providers that already
	// received the original update, and does not send them the copy.
	Origin ClientToken `json:"origin,omitempty"`
	// Topic is when e.g. a selection in a IoT rule is *, topic() as topic.
	//
	// TIP: An example is `SELECT *,topic() as topic FROM '$aws/things/+/shadow/name/building/update/accepted'`.
	Topic string `json:"topic,omitempty"`
}

// ClientTokenAction is well known actions inside the _ClientToken_.
type ClientTokenAction string

const (
	// ClientTokenActionCCEvent is the action to execute a configuration change event.
	ClientTokenActionCCEvent ClientTokenAction = "cc-evt"
	// ClientTokenActionMirror is the action to mirror data written to device shadow back to same or other
	// provider with same or other credentials, plant or tenant.
	ClientTokenActionMirror ClientTokenAction = "mirror"
	// ClientTokenActionIngest is the action to ingest data written to device shadow into a data lake.
	ClientTokenActionIngest ClientTokenAction = "ingest"
)

// ClientTokenType specifies how the client token handling should be done or interpreted.
type ClientTokenType string

const (
	// ClientTokenTypeNone will not be created due to already exist in the payload
	// or it is not necessary.
	ClientTokenTypeNone ClientTokenType = "none"
	// ClientTokenTypeId uses a newly generated _UUID_.
	ClientTokenTypeId ClientTokenType = "id"
	// ClientTokenTypeProviderIdActionDirection uses _provider:id:action:direction_ format on the
	// client token. If the _action_ is empty or omitted, it will be set to a empty when
	// `Parse()` is called. Hence it also supports _provider:id:direction_ format as well.
	ClientTokenTypeProviderIdActionDirection ClientTokenType = "provider:id:action:direction"
)

type ClientToken string

// Parse will parse the _ct_ into it's components as `ClientTokenTypeProviderIdActionDirection`.
//
// A client token is interpreted as structural when it is on the following format
// _providerName:uid:action:direction_.
func (ct ClientToken) Parse() (
	pn locationmodel.ProviderType,
	id string,
	action string,
	dir string, err error) {
	s := string(ct)
	idx := 0
	start := 0
	state := 0

	assign := func() {
		switch state {
		case 0:
			pn = locationmodel.ProviderType(s[start:idx])
		case 1:
			id = s[start:idx]
		case 2:
			dir = s[start:idx]
		case 3:
			// action is optional but now we have it
			action = dir
			dir = s[start:idx]
		default:
			err = fmt.Errorf("invalid client token format: %s", s)
		}

		start = idx + 1
		state++
	}

	for idx = range s {
		if ct[idx] == ':' {
			// support more than one : as separator
			if idx == start {
				start++
				continue
			}

			assign()

			if err != nil {
				return
			}
		}
	}

	idx++
	assign()

	if state != 4 {
		err = fmt.Errorf(
			"expecting four components provider name:id:action:direction, got: %d",
			state,
		)
	}

	return
}
