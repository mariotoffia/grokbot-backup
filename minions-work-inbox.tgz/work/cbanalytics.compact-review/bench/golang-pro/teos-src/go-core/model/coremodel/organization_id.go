package coremodel

import (
	"errors"
	"fmt"
	"regexp"
	"strconv"
)

// organizationIDSegments is the organization ID format without anchors. OrganizationIDPattern and
// OwnerIDPattern are both built from it, so they cannot differ.
const organizationIDSegments = `[a-z0-9]+(\.[a-z0-9]+)*`

// OrganizationIDPattern is the format of an organization ID: one or more segments of lowercase
// letters and digits, separated by dots, top level first, such as "skebo" or
// "thiink.us.branchoffice".
const OrganizationIDPattern = `^` + organizationIDSegments + `$`

// OwnerIDPattern is the format of an owner ID: All, which covers every organization, or an
// organization ID. It has no length limit. ValidateOwnerID also checks OrganizationIDMaxLength.
const OwnerIDPattern = `^(all|` + organizationIDSegments + `)$`

// OrganizationIDMaxLength is the longest organization ID, in characters. It is the limit of the
// owner ID schema.
const OrganizationIDMaxLength = 128

// DefaultOrganizationID is the organization that holds the account's own data, such as the app
// store's registrations of platform services. It is the same in every account.
const DefaultOrganizationID = "default"

// ErrInvalidOrganizationID is wrapped by every error that ValidateOrganizationID and
// ValidateOwnerID return.
var ErrInvalidOrganizationID = errors.New("invalid organization ID")

// quotedValueLimit is the most characters of a refused value that an error message quotes.
const quotedValueLimit = 64

var organizationIDRegexp = regexp.MustCompile(OrganizationIDPattern)

// ValidateOrganizationID checks that id has the organization ID format. It refuses All, which
// covers every organization and is not one. The error quotes at most the first 64 characters of
// id.
func ValidateOrganizationID(id string) error {
	if id == All {
		return fmt.Errorf("%w: %q covers every organization and is not one",
			ErrInvalidOrganizationID, All)
	}

	if !organizationIDRegexp.MatchString(id) {
		return fmt.Errorf(
			"%w: %s must be lowercase letters and digits in segments separated by dots, "+
				"such as \"skebo\" or \"thiink.us\"",
			ErrInvalidOrganizationID, quoteValue(id))
	}

	// The format allows only ASCII, so the length in bytes is the length in characters.
	if len(id) > OrganizationIDMaxLength {
		return fmt.Errorf("%w: %s is %d characters long; the limit is %d",
			ErrInvalidOrganizationID, quoteValue(id), len(id), OrganizationIDMaxLength)
	}

	return nil
}

// ValidateOwnerID checks that id is an owner ID: an organization ID or All.
func ValidateOwnerID(id string) error {
	if id == All {
		return nil
	}

	return ValidateOrganizationID(id)
}

// quoteValue quotes value for an error message. A value longer than quotedValueLimit characters
// is cut to that many characters and marked as shortened, so a message never repeats a long input.
func quoteValue(value string) string {
	characters := 0

	for i := range value {
		if characters == quotedValueLimit {
			return fmt.Sprintf("%s (shortened to its first %d characters)",
				strconv.Quote(value[:i]), quotedValueLimit)
		}

		characters++
	}

	return strconv.Quote(value)
}
