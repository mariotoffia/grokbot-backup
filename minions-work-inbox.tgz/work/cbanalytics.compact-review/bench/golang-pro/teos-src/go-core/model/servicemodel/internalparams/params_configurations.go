package internalparams

import (
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel/parameters"
)

// configurationTypeParams holds the parameter definitions of the configuration types, keyed by
// parameter name.
var configurationTypeParams = map[string]parameters.ParameterDefinition{
	//
	// ConfigurationType
	//
	string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow): {
		Name:           string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeIndoorTemperatureLimitLow is the limit set by the system to control against. This is the lower limit.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationTypeIndoorTemperatureLimitHigh): {
		Name:           string(eqmodel.ConfigurationTypeIndoorTemperatureLimitHigh),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeIndoorTemperatureLimitHigh is the limit set by the system to control against. This is the upper limit.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationTypeIndoorTemperatureTarget): {
		Name:           string(eqmodel.ConfigurationTypeIndoorTemperatureTarget),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeIndoorTemperatureTarget is the target to control against.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationTypeOutdoorBalanceTemperature): {
		Name:           string(eqmodel.ConfigurationTypeOutdoorBalanceTemperature),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeOutdoorBalanceTemperature is the balance temperature to control against. This is usually in what temperature the system is balanced and is not heating or cooling (swedish \"pump stopp\").",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationTypeHeatingCurveOutDoorTempTrigger): {
		Name:           string(eqmodel.ConfigurationTypeHeatingCurveOutDoorTempTrigger),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeHeatingCurveOutDoorTempTrigger is a outdoor temperature trigger to trigger the paired heating curve. Heating curves have triggers O1 to On and its counterpart to control the supply temperature is O1 to On.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationTypeHeatingCurveSupplyTemp): {
		Name:           string(eqmodel.ConfigurationTypeHeatingCurveSupplyTemp),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeHeatingCurveSupplyTemp is the supply temperature for the paired heating curve. Heating curves have triggers O1 to On and its counterpart to control the supply temperature is O1 to On.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationTypeHeatingCurve): {
		Name:           string(eqmodel.ConfigurationTypeHeatingCurve),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationTypeHeatingCurve is the generic key for a heating curve. Under this a `servicemodel.HeatingCurveEntry` array expected.",
		Resolution:     "",
		Unit:           "",
		Type: parameters.ParameterType{
			Base: parameters.ParameterStructureTypeList,
			Params: []parameters.ParameterType{
				{
					Base: parameters.ParameterBaseTypeObject,
					Fields: []parameters.ParameterDefinition{
						{
							Name:           "trigger",
							Description:    "The trigger outdoor temperature to change the supply setpoint",
							Resolution:     "0.1",
							IdentifierType: parameters.ParameterIdentifierTypeExplicit,
							Unit:           parameters.ParameterUnitCelsius,
							Type: parameters.ParameterType{
								Base: parameters.ParameterBaseTypeNumber,
							},
							Use: []parameters.ParameterUsage{
								{
									Type: parameters.ParameterUsageConfig,
									Direction: []parameters.ParameterUsageDirection{
										parameters.ParameterUsageDirectionIn,
										parameters.ParameterUsageDirectionOut,
									},
								},
							},
						},
						{
							Name:           "supply",
							Description:    "The supply setpoint for the secondary circuit",
							Resolution:     "0.1",
							IdentifierType: parameters.ParameterIdentifierTypeExplicit,
							Unit:           parameters.ParameterUnitCelsius,
							Type: parameters.ParameterType{
								Base: parameters.ParameterBaseTypeNumber,
							},
							Use: []parameters.ParameterUsage{
								{
									Type: parameters.ParameterUsageConfig,
									Direction: []parameters.ParameterUsageDirection{
										parameters.ParameterUsageDirectionIn,
										parameters.ParameterUsageDirectionOut,
									},
								},
							},
						},
					},
				},
			},
		},
	},
	string(eqmodel.ConfigurationSecondaryCircuitMinFeedTemp): {
		Name:           string(eqmodel.ConfigurationSecondaryCircuitMinFeedTemp),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationSecondaryCircuitMinFeedTemp is the minimum feed temperature for the secondary circuit that can be controlled. It should never be lower than the minimum temperature that the heat source can provide.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationSecondaryCircuitMaxFeedTemp): {
		Name:           string(eqmodel.ConfigurationSecondaryCircuitMaxFeedTemp),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationSecondaryCircuitMaxFeedTemp is the maximum feed temperature for the secondary circuit that can be controlled. It should never be higher than the maximum temperature that the heat source can provide.",
		Resolution:     "0.1",
		Unit:           parameters.ParameterUnitCelsius,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	string(eqmodel.ConfigurationOptimizationControlPrinciple): {
		Name:           string(eqmodel.ConfigurationOptimizationControlPrinciple),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationOptimizationControlPrinciple is the controlling principle. Currently supported: OFFODT - Outdoor temperature Offset, ACTSPSSHCT - Actively controlled supply secondary heating circuit temperature, SPSSHCT - Supply secondary heating circuit temperature.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	string(eqmodel.ConfigurationOptimizationActivation): {
		Name:           string(eqmodel.ConfigurationOptimizationActivation),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationOptimizationActivation specifies in RFC3339 format when the service is expected to be activated.",
		Resolution:     "",
		Unit:           parameters.ParameterUnitRFC3339,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	string(eqmodel.ConfigurationEffectServiceLevel): {
		Name:           string(eqmodel.ConfigurationEffectServiceLevel),
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "ConfigurationEffectServiceLevel specifies effect to use or is installed on-site that the service shall relate to. Well known service types are in TeosEffectServiceLevels.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
}
