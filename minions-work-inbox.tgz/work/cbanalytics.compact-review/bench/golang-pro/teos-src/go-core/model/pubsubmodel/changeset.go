package pubsubmodel

import "github.com/google/uuid"

type SubscriptionDeletedIDImpl struct {
	SubscriberID  string      `json:"sid"`
	Subscriptions []uuid.UUID `json:"subs"`
}

// SubscriptionChangeSet represents a change set of added and
// deleted subscriptions.
//
// NOTE: An _Update_ is when a `SubscriberAndSubscriptionsImpl` is deleted
// and is added at the same time. The processing is _REQUIRED_ to process
// deleted first and *then* added.
type SubscriptionChangeSet struct {
	Deleted []*SubscriptionDeletedIDImpl
	Added   []*SubscriberAndSubscriptionsImpl
}
