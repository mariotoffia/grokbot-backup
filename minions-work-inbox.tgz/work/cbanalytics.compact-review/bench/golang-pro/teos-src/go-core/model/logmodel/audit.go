package logmodel

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
)

type AuditEventType string

const (
	PolicyRejection             AuditEventType = "policyrejection"
	PolicyObligationFulfillment AuditEventType = "policyobligation-fulfillment"
	PolicyAccept                AuditEventType = "policyaccept"
)

// AuditMaterialType is the type of audit material.
type AuditMaterialType string

const (
	// MaterialPolicy specifies a _cbpolicy_
	MaterialPolicy AuditMaterialType = "policy"
	// MaterialConfig is a generic config pointer
	MaterialConfig AuditMaterialType = "config"
)

// AuditMaterial is a identity in order to reference a certain item that
// may be later verified to be true.
//
// .Policy
// ====
// Lets assume that a `AuditMaterial` is pointing out a policy with name.
// It will then also include it's hash. If another material with the signature
// of the signed executable. It is possible to know that the execution did
// really use a specific policy and the flow of events may be audited.
// ====
type AuditMaterial struct {
	// Name of the material, e.g. policy name or configuration file
	Name string
	// Identity contains a _"hard-to-manufacture-alternative"_ identity of the
	// _Name_. For example a SHA512 hash of a policy.
	Identity string
	// Type is the type of material.
	//
	// This is a custom field with some well-known `AuditMaterialType` types.
	Type AuditMaterialType
}

// AuditEvent is a event that needs to be persistent and able for
// external actors to audit with certainty that this event has not
// been modified.
type AuditEvent struct {
	// Time recorded by the entity
	Time *coremodel.CbTime64 `json:"-"`
	Type AuditEventType      `json:"type"`
	// Claims is populated from the `ifcore.SecurityContext`
	Claims *securitymodel.OpenIDConnectToken `json:"sc,omitempty"`
	// Material is the proofs referenced by this events.
	//
	// This could be hashes to policies, configuration files,
	// executable signature etc.
	Material []AuditMaterial `json:"material,omitempty"`
	// Messsage is free form messsage
	Message string `json:"message,omitempty"`
	// Data is free form _JSON_ data coupeled with this audit entry.
	Data json.RawMessage `json:"data,omitempty"`
}
