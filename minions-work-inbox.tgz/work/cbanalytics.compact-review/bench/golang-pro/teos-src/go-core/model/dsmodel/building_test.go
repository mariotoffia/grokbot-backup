package dsmodel

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
)

// newCtx creates a 'unit-test' _ifcore.CbContext_ for one test.
func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	testenv.Use(tb, testenv.EnvDefaults)

	c, err := ctx.NewContextWithDefaultOptions("unit-test", "test", cbenv.DevLocal)
	require.NoError(tb, err)
	tb.Cleanup(c.Close)
	return c
}

// TestFullBuildingDs ensures that _NewDsFullBuildingWithTopic_ will deserialize a thing shadow _JSON_
// document properly.
func TestFullBuildingDs(t *testing.T) {
	topic := fmt.Sprintf(
		"$aws/things/%s/shadow/name/building/update/accepted",
		utils.EncodeThingCompatibleName("Måssmyren 18"),
	)

	data := []byte(fmt.Sprintf(`{
		"state": {
			"reported": {
				"sensors": {
					"IDT": 22,
					"ODT": -20,
					"SHCT_C1": 65,
					"SHCT_C2": 58
				},
				"tz": "+07:00"
			}
		},
		"metadata": {
			"reported": {
				"sensors": {
					"IDT": {
						"timestamp": 1599051846
					},
					"ODT": {
						"timestamp": 1599051846
					},
					"SHCT_C1": {
						"timestamp": 1599051846
					},
					"SHCT_C2": {
						"timestamp": 1599051846
					}
				},
				"tz": {
					"timestamp": 1599051955
				}
			}
		},
		"version": 4,
		"topic": "%s",
		"timestamp": 1599051955
	}`, topic))

	ds, err := NewDsFullBuildingWithTopic(newCtx(t), data)
	assert.Equal(t, nil, err)

	assert.Equal(t, "Måssmyren 18", ds.BuildingID)
	assert.Equal(t, "M_C3_A5ssmyren_2018", utils.EncodeThingCompatibleName("Måssmyren 18"))
	assert.Equal(t, "+07:00", ds.State.Reported.TimeZone)
	assert.Equal(t, float64(22), ds.State.Reported.Sensors["IDT"])
	assert.Equal(t, float64(-20), ds.State.Reported.Sensors["ODT"])
	assert.Equal(t, float64(65), ds.State.Reported.Sensors["SHCT_C1"])
	assert.Equal(t, float64(58), ds.State.Reported.Sensors["SHCT_C2"])
	assert.Equal(t, int64(1599051955), ds.Timestamp.Unix())
	assert.Equal(t, 4, ds.Version)
	assert.Equal(t, int64(1599051955), ds.Metadata.Reported.TimeZone.Timestamp.Unix())
	assert.Equal(t, int64(1599051846), ds.Metadata.Reported.Sensors["IDT"].Timestamp.Unix())
	assert.Equal(t, int64(1599051846), ds.Metadata.Reported.Sensors["ODT"].Timestamp.Unix())
	assert.Equal(t, int64(1599051846), ds.Metadata.Reported.Sensors["SHCT_C1"].Timestamp.Unix())
	assert.Equal(t, int64(1599051846), ds.Metadata.Reported.Sensors["SHCT_C2"].Timestamp.Unix())
}

func TestFullBuildingDsWithType(t *testing.T) {
	topic := fmt.Sprintf(
		"$aws/things/%s/shadow/name/building/update/accepted",
		utils.EncodeThingCompatibleName("Campus Alpha"),
	)

	data := []byte(fmt.Sprintf(`{
		"state": {
			"reported": {
				"type": "building",
				"sensors": {"IDT": 21},
				"tz": "Europe/Stockholm"
			}
		},
		"version": 1,
		"topic": "%s",
		"timestamp": 1700000000
	}`, topic))

	ds, err := NewDsFullBuildingWithTopic(newCtx(t), data)
	assert.Nil(t, err)
	assert.Equal(t, "building", ds.State.Reported.Type)
	assert.Equal(t, "Europe/Stockholm", ds.State.Reported.TimeZone)
}

func TestDsBuildingClonePreservesType(t *testing.T) {
	original := &DsBuilding{
		Type:     "building",
		TimeZone: "Europe/Stockholm",
		Sensors:  map[string]any{"IDT": float64(21)},
	}

	cloned := original.Clone()

	assert.Equal(t, "building", cloned.Type)
	assert.Equal(t, "Europe/Stockholm", cloned.TimeZone)
	assert.Equal(t, float64(21), cloned.Sensors["IDT"])

	// Verify independence: modifying clone doesn't affect original
	cloned.Type = "campus"
	assert.Equal(t, "building", original.Type)
}

func TestParseValidClientTokens(t *testing.T) {
	type Test struct {
		ClientToken  string
		ID           string
		ProviderType locationmodel.ProviderType
		Action       string
		Direction    locationmodel.ProviderOperation
		Error        bool
	}

	tests := []Test{
		{ //nolint:gosec // G101: test fixture, not real credentials
			ClientToken:  "climatixic:123-abc:cc-evt:inbound",
			ID:           "123-abc",
			Action:       "cc-evt",
			ProviderType: locationmodel.ProviderClimatixIC,
			Direction:    locationmodel.ProviderOperation("inbound"),
		},
		{ //nolint:gosec // G101: test fixture, not real credentials
			ClientToken:  "climatixic:123-abc:cc-evt:inbound",
			ID:           "123-abc",
			Action:       "cc-evt",
			ProviderType: locationmodel.ProviderClimatixIC,
			Direction:    locationmodel.ProviderOperation("inbound"),
		},
	}

	for _, tst := range tests {
		pn, id, action, dir, err := ClientToken(tst.ClientToken).Parse()

		if tst.Error {
			assert.True(t, nil != err)
		} else {
			assert.Equal(t, nil, err)
		}

		assert.Equal(t, tst.ProviderType, pn)
		assert.Equal(t, tst.ID, id)
		assert.Equal(t, tst.Action, action)
		assert.Equal(t, tst.Direction, locationmodel.ProviderOperation(dir))
	}

}

func TestParseInValidClientTokens(t *testing.T) {
	tests := []string{
		"123-abc:inbound",
	}

	for _, tst := range tests {
		_, _, _, _, err := ClientToken(tst).Parse()
		assert.True(t, nil != err)
	}

}

func BenchmarkParseValidClientToken(t *testing.B) {
	ct := ClientToken("climatixic:123-abc:cc-evt:inbound")

	for i := 0; i < t.N; i++ {
		_, _, _, _, _ = ct.Parse()
	}

}
