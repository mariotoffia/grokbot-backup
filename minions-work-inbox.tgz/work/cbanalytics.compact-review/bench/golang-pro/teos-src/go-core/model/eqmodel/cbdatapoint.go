package eqmodel

import (
	"fmt"
	"sort"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

// CbDataPoint is a datapoint / sensor data value that have the minimum required information to
// process it in the _TEOS_.
//
// A standard implementation do exist as `CbDataPointImpl`. Several helper functions are available
// to convert to an slice or map into a slice of `CbDataPoint`s.
type CbDataPoint interface {
	// GetID returns the ID of the data point.
	//
	// This is a *REQUIRED* property.
	//
	// The id may be a full id or a partial id that belongs to a partition.
	GetID() string
	// GetValue returns the value of the data point (if any).
	GetValue() any
	// GetPartition returns the partition the `GetID` is within (if any).
	//
	// Some data points do not belong to any partition at all.
	GetPartition() string
	// HasTimeStamp returns `true`` if the data point has a timestamp.
	HasTimeStamp() bool
	// GetTimeStamp returns the timestamp of the data point.
	//
	// If no timestamp it _SHALL_ return using `coremodel.NewZeroTime32()`.
	GetTimeStamp() coremodel.CbTime32
	// GetError may return an error that have occurred while importing / exporting this datapoint
	GetError() cberror.Error
}

// CbDataPointMap is a map of possible multiple `CbDataPoint`s where the key and `CbDataPoint.GetID()` are the same.
type CbMultiDataPointMap map[string][]CbDataPoint

// GroupDataPoints processes the map[string][]CbDataPoint and groups CbDataPoints into
// a slice of maps based on the provided _durRange_. Each map contains one CbDataPoint
// per key, and the slice is sorted with the oldest timestamp first.
//
// No duplicate CbDataPoints are included in the result instead each datapoint will be placed on a
// single map.
//
// .Example Usage
// [source,go]
// ----
//
//		fetchResult := map[string][]CbDataPoint{
//			"IDT_O1": { "ID": "IDT_O1", "TS": "2021-01-01T00:00:00Z" },
//			"IDT_O2": { "ID": "IDT_O2", "TS": "2021-01-01T00:00:01Z" },
//			"OFFODT": { "ID": "OFFODT", "TS": "2021-01-01T00:15:00Z" },
//	}
//
//	grouped := GroupDataPoints(fetchResult, 10 * time.Minute)
//
//	// grouped will be:
//	// [
//	//   { "IDT_O1": { "ID": "IDT_O1", "TS": "2021-01-01T00:00:00Z" }, "IDT_O2": { "ID": "IDT_O2", "TS": "2021-01-01T00:00:01Z" } },
//	//   { "OFFODT": { "ID": "OFFODT", "TS": "2021-01-01T00:15:00Z" } },
//	// ]
//
// ----
//
// If any errors such as a `CbDataPoint` without a timestamp are encountered, it will be returned. If not datapoints, it will return
// nil.
func (m CbMultiDataPointMap) GroupDataPoints(
	durRange time.Duration,
) ([]map[string]CbDataPoint, error) {
	// Define a helper struct to associate each CbDataPoint with its key.
	type dpk struct {
		Key   string
		Point CbDataPoint
	}

	// Step 0: size to minimize allocations
	size := 0

	for _, points := range m {
		size += len(points)
	}

	allPoints := make([]dpk, 0, size)

	// Step 1: extract all CbDataPoints with valid timestamps.
	for key, points := range m {
		for _, point := range points {
			if point.HasTimeStamp() {
				allPoints = append(allPoints, dpk{
					Key:   key,
					Point: point,
				})
			} else {
				return nil, fmt.Errorf("CbDataPoint with key %s has no timestamp", key)
			}
		}
	}

	if len(allPoints) == 0 {
		return nil, nil
	}

	// Step 2: sort timestamp (ascending)
	sort.Slice(allPoints, func(i, j int) bool {
		return allPoints[i].Point.GetTimeStamp().Before(allPoints[j].Point.GetTimeStamp())
	})

	// cluster each start time and its data map.
	type cluster struct {
		StartTime time.Time
		Data      map[string]CbDataPoint
	}

	var clusters []cluster

	// Step 3: iterate and assign points to appropriate clusters.
	for _, cp := range allPoints {
		assigned := false
		pointTime := cp.Point.GetTimeStamp()

		// Find cluster for point (or new cluster).
		for ci := 0; ci < len(clusters); ci++ {
			cluster := &clusters[ci]

			// within durRange of start time -> try-assign
			if time.Time(pointTime).Sub(cluster.StartTime) <= durRange {
				// Already exists -> skip (will be on next cluster).
				if _, exists := cluster.Data[cp.Key]; !exists {
					cluster.Data[cp.Key] = cp.Point
					assigned = true

					break
				}
			} else {
				// clusters are sorted by start time -> don't check further.
				break
			}
		}

		// wasn't assigned to any existing cluster -> new cluster.
		if !assigned {
			newCluster := cluster{
				StartTime: time.Time(pointTime),
				Data: map[string]CbDataPoint{
					cp.Key: cp.Point,
				},
			}

			clusters = append(clusters, newCluster)
		}
	}

	result := make([]map[string]CbDataPoint, len(clusters))

	for i, cluster := range clusters {
		result[i] = cluster.Data
	}

	return result, nil
}
