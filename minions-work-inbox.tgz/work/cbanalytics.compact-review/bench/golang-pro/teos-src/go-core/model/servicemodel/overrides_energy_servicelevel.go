package servicemodel

// ToServiceLevelFromKW translates a _kw_ (power) value to a service level.
func ToServiceLevelFromKW(kw int) TeosEffectServiceLevels {
	switch {
	case kw < 101:
		return TeosEffectServiceLevelSmall
	case kw < 251:
		return TeosEffectServiceLevelMedium
	case kw < 401:
		return TeosEffectServiceLevelLarge
	case kw > 400:
		return TeosEffectServiceLevelXLarge
	}

	return TeosEffectServiceLevelXLarge
}

func ToServiceLevelFromString(s string) TeosEffectServiceLevels {
	switch s {
	case "small":
		return TeosEffectServiceLevelSmall
	case "medium":
		return TeosEffectServiceLevelMedium
	case "large":
		return TeosEffectServiceLevelLarge
	case "xlarge":
		return TeosEffectServiceLevelXLarge
	}

	return TeosEffectServiceLevels(s)
}
