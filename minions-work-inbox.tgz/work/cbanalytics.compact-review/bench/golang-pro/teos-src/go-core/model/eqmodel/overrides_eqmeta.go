package eqmodel

import (
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"

	"github.com/Thiink-LLC/teos/go-core/utils/dbutils"
)

// MarshalDynamoDBAttributeValue overrides dynamodb marshalling
func (s *EqMeta) MarshalDynamoDBAttributeValue() (types.AttributeValue, error) {
	return dbutils.MarshalDynamoDBAttributeValue(s)
}

// UnmarshalDynamoDBAttributeValue overrides dynamodb unmarshalling
func (s *EqMeta) UnmarshalDynamoDBAttributeValue(v types.AttributeValue) error {
	if is, err := dbutils.UnmarshalDynamoDBAttributeValue[EqMeta](v); err != nil {
		return err
	} else {
		*s = *is
	}

	return nil
}
