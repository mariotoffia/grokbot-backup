package locationmodel

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/utils/idutils"
)

// PostProcess will make sure that all identifiers are correctly set after
// a query from the database. This will parse the identity and put data into
// the properties.
func (ps *ProviderSettings) PostProcess(ctx ifcore.CbContext) *ProviderSettings {
	if ps == nil {
		return nil
	}

	// Make sure BLD# is removed from the LocationID
	ps.LocationID = strings.TrimPrefix(ps.LocationID, "BLD#")

	str := strings.Split(ps.TransformationStepID, "#")

	// TS#{pn}#{po}
	if len(str) == 3 {
		ps.ProviderName = str[1]
		ps.ProviderGroup = ""
		ps.Operation = ProviderOperation(str[2])
	} else if len(str) == 4 {
		// TS#{pg}[-{res}]#{pn}#{po}
		// find last -
		idxLast := strings.LastIndex(str[1], "-")

		if idxLast == -1 {
			ps.ProviderGroup = str[1]
			ps.Resolution = ""
		} else {
			ps.ProviderGroup = str[1][:idxLast]
			ps.Resolution = str[1][idxLast+1:]

			if res, _ := ps.GetResolutionTypeAndDuration(); res == coremodel.ResolutionUnknown {
				ps.Resolution = ""
				ps.ProviderGroup = str[1]
			}
		}

		ps.ProviderName = str[2]

		ps.Operation = ProviderOperation(str[3])
	} else {
		log.Warn(ctx).
			WithMethod("PostProcess").
			Str("SK", ps.TransformationStepID).
			Str("PK", ps.LocationID).
			Msg("Expect 3 or 4 parts in the TransformationStepID")
	}

	return ps
}

// Prepare will prepare the instance for storage by render the attributes
// into the `LocationID` and `TransformationStepID` attributes including
// storage prefixes.
//
// NOTE: Since this is done inline, make sure to use `PostProcess` if you
// plan to keep using this instance.
func (ps *ProviderSettings) Prepare() *ProviderSettings {
	if ps == nil {
		return nil
	}
	ps.LocationID = "BLD#" + strings.TrimPrefix(ps.LocationID, "BLD#")

	if ps.ProviderGroup == "" {
		ps.TransformationStepID = fmt.Sprintf("TS#%s#%s", ps.ProviderName, ps.Operation)
	} else {
		if ps.Resolution == "" {
			ps.TransformationStepID = fmt.Sprintf(
				"TS#%s#%s#%s", ps.ProviderGroup, ps.ProviderName, ps.Operation,
			)

		} else {
			ps.TransformationStepID = fmt.Sprintf(
				"TS#%s-%s#%s#%s", ps.ProviderGroup, ps.Resolution, ps.ProviderName, ps.Operation,
			)
		}
	}

	return ps
}

// OwnedBy will check if the `LocationID` do end with ' ({owner})'. It will extract that and return the
// owner string.
func (ps *ProviderSettings) OwnedBy() string {
	if ps == nil {
		return ""
	}

	_, rsid := idutils.RSIDDecodeLocationID(strings.TrimPrefix(ps.LocationID, buildingPrefix))

	return rsid
}

// GetResolutionTypeAndDuration will parse the `ProviderSettings.Resolution` and return the
// resolution type and duration.
//
// If it fails it will return `timeutils.ResolutionUnknown` and `0`.
//
// CAUTION: In order for this function to work, this instance must have been
// `Prepare`d since the resolution is part of the `TransformationStepID`.
func (ps *ProviderSettings) GetResolutionTypeAndDuration() (coremodel.ResolutionType, int) {
	return coremodel.Resolution(ps.Resolution).ToResolutionAndDuration()
}

// GetProviderSettingsStepParam is a generic function that will check if _key_ do exist in the
// `ProviderSettings.Params` map and it is a `T`. If so, the value is returned, otherwise
// the _d_(default) value is returned.
//
// If _ts_ is `nil`, the _d_ value is returned.
func GetProviderSettingsStepParam[T any](ps *ProviderSettings, key string, d T) T {
	if nil == ps {
		return d
	}

	if nil == ps.Params {
		return d
	}

	if str, ok := ps.Params[key]; ok {
		if s, ok := str.(T); ok {
			return s
		}
	}

	return d
}

// GetParam checks and gets a param without casting it.
func (ps *ProviderSettings) GetParam(key string) (any, bool) {
	if nil == ps.Params {
		return nil, false
	}

	if value, ok := ps.Params[key]; ok {
		return value, true
	}

	return nil, false
}

// GetParamsString will check if _key_ do exist in the `ProviderSettings.Params` map
// and it is a `string`. If so, the value is returned, otherwise `false` is returned.
func (ps *ProviderSettings) GetParamsString(key string) (string, bool) {
	if nil == ps.Params {
		return "", false
	}

	if str, ok := ps.Params[key]; ok {
		if s, ok := str.(string); ok {
			return s, true
		}
	}

	return "", false
}

// GetStringOrDefault will check if _key_ do exist in the `ProviderSettings.Params` map
// and it is a `string`. If so, the value is returned, otherwise the _d_(default) value is returned.
func (ps *ProviderSettings) GetStringOrDefault(key, d string) string {
	if s, ok := ps.GetParamsString(key); ok {
		return s
	}

	return d
}

// GetParamsValueAsString will check if _key_ do exist in the `ProviderSettings.Params` map
// and if found, it will make sure that it is or make it a string and returns it.
//
// CAUTION: This may be a costly operation if the value is not a string since it will marshal
// the value into a string.
func (ps *ProviderSettings) GetParamsValueAsString(key string) (string, bool) {
	if nil == ps.Params {
		return "", false
	}

	if str, ok := ps.Params[key]; ok {
		if s, ok := str.(string); ok {
			return s, true
		}

		if s, err := json.Marshal(str); nil == err {
			return string(s), true
		}
	}

	return "", false
}

// GetLocationValueAsString will lookup the _key_ and try to convert it to a string .
func (ps *ProviderSettings) GetLocationValueAsString(key string) (string, bool) {
	if nil == ps.Location {
		return "", false
	}

	if str, ok := ps.Location[key]; ok {
		if s, ok := str.(string); ok {
			return s, true
		}

		if s, err := json.Marshal(str); nil == err {
			return string(s), true
		}
	}

	return "", false
}

// SetLocationValue will set the _value_ in the _key_ in the `ProviderSettings.Location` map.
//
// If the _key_ already exists, the value will be replaced and the old value is returned.
func (ps *ProviderSettings) SetLocationValue(key string, value any) (any, bool) {
	if nil == ps.Location {
		return nil, false
	}

	if val, ok := ps.Location[key]; ok {
		if val == value {
			return val, false
		}

		ps.Location[key] = value
		return val, true
	} else {
		ps.Location[key] = value
	}

	return nil, true
}

// IsLocated checks if `ProviderSettings.Location` contains `ProviderLocationType` (_type_)
// and matches the in parameter _location_.
func (ps *ProviderSettings) IsLocated(
	location ProviderLocation,
) (actual ProviderLocation, found bool) {
	actual = ProviderLocationUnknown

	if nil == ps.Location {
		return
	}

	if name, ok := ps.GetLocationValueAsString(string(ProviderLocationType)); ok {
		actual = ProviderLocation(name)
		found = actual == location
	}

	return
}

func (o *ProviderSettings) GetProviderLocation() ProviderLocation {
	if o == nil {
		return ProviderLocationUnknown
	}

	if pl, ok := o.GetLocationValueAsString(string(ProviderLocationType)); ok {
		return ProviderLocation(pl)
	}

	return ProviderLocationUnknown
}

// SetProviderLocation will set the `ProviderLocation` in the `Location` parameter
// named `ProviderLocationType` (_"type"_).
func (o *ProviderSettings) SetProviderLocation(pl ProviderLocation) {
	if o == nil {
		return
	}

	o.SetLocationValue(string(ProviderLocationType), pl)
}

// IsSubType check _subtype_ if present in the _ts_
func (ps *ProviderSettings) IsSubType(
	subtype ProviderSubType,
) (actual ProviderSubType, found bool) {
	actual = ProviderSubTypeUnknown

	if nil == ps.Location {
		return
	}

	if subType, ok := ps.GetLocationValueAsString(string(ProviderSubTypeName)); ok {
		actual = ProviderSubType(subType)
		found = actual == subtype
	}

	return
}
