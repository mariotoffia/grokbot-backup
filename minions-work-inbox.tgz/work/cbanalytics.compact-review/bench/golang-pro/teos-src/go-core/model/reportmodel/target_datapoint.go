package reportmodel

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cberror"
)

type CoreTargetDataPointReportSuccess string

const (
	// CoreTargetDataPointReportOk is when the complete operation was successful.
	CoreTargetDataPointReportOk CoreTargetDataPointReportSuccess = "ok"
	// CoreTargetDataPointReportFail is when the complete operation was unsuccessful.
	CoreTargetDataPointReportFail CoreTargetDataPointReportSuccess = "fail"
	// CoreTargetDataPointReportPartial is when some of the operations were successful but others were not.
	CoreTargetDataPointReportPartial CoreTargetDataPointReportSuccess = "partial"
)

type CoreTargetDataPointReport struct {
	// Operation may any of the `locationmodel.PipeOperation`
	Operation string `json:"oper,omitempty"`
	// Success determines the success of the operation.
	Success CoreTargetDataPointReportSuccess `json:"success"`
	// Body is an optional parameter where the body of the data is provided.
	Body *json.RawMessage `json:"body,omitempty"`
	// Info is an optional parameter where any additional information is provided.
	Info *CoreTargetDataPointReportInfo `json:"info,omitempty"`
	// Meta is an optional parameter where metadata can be stored
	Meta *json.RawMessage `json:"meta,omitempty"`
	// DataPoints is all the datapoints participating in the operation
	DataPoints *CoreTargetDataPointReportBody `json:"dp,omitempty"`
}

// CoreTargetDataPointReportBody is the body of a `CoreTargetDataPointReport`
type CoreTargetDataPointReportBody struct {
	// CountSuccess is the number of datapoints that were successfully processed.
	CountSuccess int `json:"cs,omitempty"`
	// CountFail is the number of datapoints that failed to process.
	CountFailed int `json:"cf,omitempty"`
	// Success is the datapoints that were successfully written.
	Success map[string]*CoreDataPointInfo `json:"success,omitempty"`
	// Fail is the datapoints that were not written.
	Failed map[string]*CoreDataPointInfo `json:"failed,omitempty"`
}

// CoreTargetDataPointReportTarget is the target of where the operation is applied.
type CoreTargetDataPointReportTarget string

const (
	// CoreTargetDataPointReportTargetDeviceShadow is when the target is a device shadow.
	CoreTargetDataPointReportTargetDeviceShadow CoreTargetDataPointReportTarget = "ds"
	// CoreTargetDataPointReportTargetEventBridge is the event bridge.
	CoreTargetDataPointReportTargetEventBridge CoreTargetDataPointReportTarget = "evb"
	// CoreTargetDataPointReportTargetSQS is when the target is an SQS queue.
	CoreTargetDataPointReportTargetSQS CoreTargetDataPointReportTarget = "sqs"
)

// CoreTargetDataPointReportInfo is the section that describes the operation
// and target in more detail.
type CoreTargetDataPointReportInfo struct {
	// Source is the source of the operation.
	//
	// This may be set if the system supports it, e.g. if _evb_ it would
	// be the event source identifier such as _se.thiink.provider.noda_.
	Source string `json:"s,omitempty"`
	// Target is the target of the operation.
	Target CoreTargetDataPointReportTarget `json:"t"`
	// SubTarget is additional info about the target.
	//
	// For example when event bridge, this is the event type.
	SubTarget string `json:"st,omitempty"`
	// TargetID is the target of the operation.
	//
	// When Target is `ds` this is the device shadow name or
	// is _SQS_ it will be the queue name or _ARN_ (if different account).
	TargetID string `json:"tid"`
	// AdditionalInfo is a set of extra info that is not standardized.
	AdditionalInfo map[string]interface{} `json:"a,omitempty"`
}

// RemoteDataPointInfo is a struct that contains information about a core
// datapoint. It is used to be a value, keyed with a thiink wellknown
// datapoint/sensor id.
//
// This is used in `CoreTargetDataPointReport`
type CoreDataPointInfo struct {
	// Value is corresponding the value
	Value interface{} `json:"v,omitempty"`
	// TimeStamp is the timestamp of the datapoint (this could be from a remote provider or current UTC date-time)
	TimeStamp string `json:"ts,omitempty"`
	// Error is an optional error that may describe why the datapoint could non be transported.
	//
	// NOTE: When exported this will translate to an array since it may be a `cberror.CbCompositeError` or
	//       wrapped into several errors. Those are flattened into a single array.
	Error cberror.Error `json:"err,omitempty"`
}
