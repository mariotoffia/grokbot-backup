package storagemodel

import "time"

// StoreBucket is a _bucket_ where `StoreObjects` may reside.
//
// TIP: _AWS S3 bucket_ is a `StoreBucket` or on Azure it would be a _Blob Store_.
type StoreBucket struct {
	// Name is the  name of the _bucket_
	Name string
	// Created is the _timestamp_ when the _bucket_ was _created_. If any.
	Created *time.Time
}

// StoreObject is a file or otherwise object in a `StoreBucket`.
//
// The term _object_ refers to any type of data that has a _Name_ that may
// be retrieved, updated, or deleted.
type StoreObject struct {
	// Hash is a value that will change if _object_ is changed (not metadata) if supported.
	Hash string
	// Name is the full name of the _object_, sometimes referred as object _key_.
	Name string
	// LastModified is the timestamp when the _object_ was last modified.
	LastModified *time.Time
	// OwnerID is the owner of the _object_.
	OwnerID string
	// OwnerName is the display friendly name of the _object_.
	OwnerName string
	// Size in bytes of the _object_
	Size int64
	// The cloud specific name or number for the _storage class_.
	//
	// Storage classes on AWS is taken from https://aws.amazon.com/s3/storage-classes/[here].
	//
	// .AWS Storage Classes
	// |===
	// |Name |Description
	//
	// |STANDARD
	// a|
	// * Low latency and high throughput performance
	// * Designed for durability of 99.999999999% of objects across multiple Availability Zones
	// * Resilient against events that impact an entire Availability Zone
	// * Designed for 99.99% availability over a given year
	// * Backed with the https://aws.amazon.com/s3/sla/[Amazon S3 Service Level Agreement] for availability
	// * Supports SSL for data in transit and encryption of data at rest
	// * S3 Lifecycle management for automatic migration of objects to other S3 Storage Classes
	//
	// |REDUCED_REDUNDANCY
	// |REDUCED_REDUNDANCY
	//
	// |STANDARD_IA
	// a|
	// 3 Standard offers high durability, availability, and performance object storage for frequently accessed data.
	// Because it delivers low latency and high throughput, S3 Standard is appropriate for a wide variety of use
	// cases, including cloud applications, dynamic websites, content distribution, mobile and gaming applications,
	// and big data analytics.
	//
	// * Same low latency and high throughput performance of S3 Standard
	// * Designed for durability of 99.999999999% of objects across multiple Availability Zones
	// * Resilient against events that impact an entire Availability Zone
	// * Data is resilient in the event of one entire Availability Zone destruction
	// * Designed for 99.9% availability over a given year
	// * Backed with the https://aws.amazon.com/s3/sla/[Amazon S3 Service Level Agreement] for availability
	// * Supports SSL for data in transit and encryption of data at rest
	// * S3 Lifecycle management for automatic migration of objects to other S3 Storage Classes
	//
	// |ONEZONE_IA
	// a|
	// S3 One Zone-IA is for data that is accessed less frequently, but requires rapid access when needed.
	//
	// * Same low latency and high throughput performance of S3 Standard
	// * Designed for durability of 99.999999999% of objects in a single Availability Zone†
	// * Designed for 99.5% availability over a given year
	// * Backed with the https://aws.amazon.com/s3/sla/[Amazon S3 Service Level Agreement] for availability
	// * Supports SSL for data in transit and encryption of data at rest
	// * S3 Lifecycle management for automatic migration of objects to other S3 Storage Classes
	//
	// |INTELLIGENT_TIERING
	// a|
	// The S3 Intelligent-Tiering storage class is designed to optimize costs by automatically moving data
	// to the most cost-effective access tier, without performance impact or operational overhead. It works
	// by storing objects in two access tiers: one tier that is optimized for frequent access and another
	// lower-cost tier that is optimized for infrequent access.
	//
	// * Same low latency and high throughput performance of S3 Standard
	// * Small monthly monitoring and auto-tiering fee
	// * Automatically moves objects between two access tiers based on changing access patterns
	// * Designed for durability of 99.999999999% of objects across multiple Availability Zones
	// * Resilient against events that impact an entire Availability Zone
	// * Designed for 99.9% availability over a given year
	// * Backed with the https://aws.amazon.com/s3/sla/[Amazon S3 Service Level Agreement] for availability
	// * Supports SSL for data in transit and encryption of data at rest
	// * S3 Lifecycle management for automatic migration of objects to other S3 Storage Classes
	//
	// |GLACIER
	// a|
	// S3 Glacier is a secure, durable, and low-cost storage class for data archiving. You can reliably store any
	// amount of data at costs that are competitive with or cheaper than on-premises solutions.
	//
	// * Designed for durability of 99.999999999% of objects across multiple Availability Zones
	// * Data is resilient in the event of one entire Availability Zone destruction
	// * Supports SSL for data in transit and encryption of data at rest
	// * Low-cost design is ideal for long-term archive
	// * Configurable retrieval times, from minutes to hours
	// * S3 PUT API for direct uploads to S3 Glacier, and S3 Lifecycle management for automatic migration of objects
	//
	// |DEEP_ARCHIVE
	// a|
	// S3 Glacier Deep Archive is Amazon S3’s lowest-cost storage class and supports long-term retention and
	// digital preservation for data that may be accessed once or twice in a year.
	//
	// * Designed for durability of 99.999999999% of objects across multiple Availability Zones
	// * Lowest cost storage class designed for long-term retention of data that will be retained for 7-10 years
	// * Ideal alternative to magnetic tape libraries
	// * Retrieval time within 12 hours
	// * S3 PUT API for direct uploads to S3 Glacier Deep Archive, and S3 Lifecycle management for automatic migration of objects
	//
	// |OUTPOSTS
	// a|
	// Amazon S3 on Outposts delivers object storage to your on-premises AWS Outposts environment.
	//
	// * S3 Object compatibility and bucket management through the S3 SDK
	// * Designed to durably and redundantly store data on your Outposts
	// * Encryption using SSE-S3 and SSE-C
	// * Authentication and authorization using IAM, and S3 Access Points
	// * Transfer data to AWS Regions using AWS DataSync
	// * S3 Lifecycle expiration actions
	// |===
	StorageClass string
	// The object version id
	Version string
}
