package eqdefs

import (
	"math"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// heatingSensorDefinitions holds the definitions of the heating circuit and
// heat meter sensor data points, keyed by TEOS identifier.
var heatingSensorDefinitions = map[string]DataPointDefinition{
	// SPHCT
	string(eqmodel.SensorSupplyHeatingPrimaryCircuitTemperature): {
		ID:          "TEOS/Primary Circuit/Supply Temperature",
		TeosID:      string(eqmodel.SensorSupplyHeatingPrimaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The primary circuit supply temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// RPHCT
	string(eqmodel.SensorReturnHeatingPrimaryCircuitTemperature): {
		ID:          "TEOS/Primary Circuit/Return Temperature",
		TeosID:      string(eqmodel.SensorReturnHeatingPrimaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The primary circuit return temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// SSHCT
	string(eqmodel.SensorSupplyHeatingSecondaryCircuitTemperature): {
		ID:          "TEOS/Secondary Circuit/Supply Temperature",
		TeosID:      string(eqmodel.SensorSupplyHeatingSecondaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The primary circuit supply temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// RSHCT
	string(eqmodel.SensorReturnHeatingSecondaryCircuitTemperature): {
		ID:          "TEOS/Secondary Circuit/Return Temperature",
		TeosID:      string(eqmodel.SensorReturnHeatingSecondaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The secondary circuit return temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// MPST
	string(eqmodel.SensorMeterPrimarySideTemperature): { // TODO:
		ID:          "TEOS/Heat Meter/Supply Temperature",
		TeosID:      string(eqmodel.SensorMeterPrimarySideTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The heat meter supply temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// MPRT
	string(eqmodel.SensorMeterPrimaryReturnTemperature): { // TODO:
		ID:          "TEOS/Heat Meter/Return Temperature",
		TeosID:      string(eqmodel.SensorMeterPrimaryReturnTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The heat meter return temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// AMFPS
	string(eqmodel.SensorAggregatedMassFlowPrimarySide): {
		ID:          "TEOS/Heat Meter/Aggregated Mass Flow Primary Side",
		TeosID:      string(eqmodel.SensorAggregatedMassFlowPrimarySide),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The heat meter mass flow on primary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "m3",
				Symbol: DataPointUnitSymbolMeterCube,
			},
		},
	},
	// AMF
	string(eqmodel.SensorAggregatedMassFlow): {
		ID:          "TEOS/Heat Meter/Aggregated Mass Flow",
		TeosID:      string(eqmodel.SensorAggregatedMassFlow),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The heat meter mass flow",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "m3",
				Symbol: DataPointUnitSymbolMeterCube,
			},
		},
	},
	// MFPS
	string(eqmodel.SensorMassFlowPrimarySide): {
		ID:          "TEOS/Heat Meter/Mass Flow Primary Side",
		TeosID:      string(eqmodel.SensorMassFlowPrimarySide),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The heat meter mass flow per hour on primary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "m3/h",
				Symbol: DataPointUnitSymbolMeterCubePerHour,
			},
		},
	},
	// AEUPS
	string(eqmodel.SensorAggregatedEnergyUsagePrimarySide): {
		ID:          "TEOS/Heat Meter/Aggregated Heat Demand Primary Side",
		TeosID:      string(eqmodel.SensorAggregatedEnergyUsagePrimarySide),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The aggregated heat demand on primary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "kWh",
				Symbol: DataPointUnitSymbolKiloWatthour,
			},
		},
	},
	// HDPS
	string(eqmodel.SensorHeatDemandPrimarySide): {
		ID:          "TEOS/Heat Meter/Heat Demand Primary Side",
		TeosID:      string(eqmodel.SensorHeatDemandPrimarySide),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The total heat demand on primary side (for all circuits)",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "kW",
				Symbol: DataPointUnitSymbolKiloWatt,
			},
		},
	},
}
