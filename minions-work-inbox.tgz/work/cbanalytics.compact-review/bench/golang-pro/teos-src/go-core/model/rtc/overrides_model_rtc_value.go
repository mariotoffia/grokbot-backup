package rtc

import (
	"bytes"
	"encoding/json"
	"fmt"

	"github.com/aws/aws-sdk-go-v2/aws"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// Int64AsRtcValue is a convenience function that returns int64 wrapped in RtcValue
//
// It will also set the Float32 counter part to the same value.
func Int64AsRtcValue(v *int64) RtcValue {
	return RtcValue{
		Float32: aws.Float32(float32(*v)),
		Int64:   v,
	}
}

// ArrayOfInt64AsRtcValue is a convenience function that returns []int64 []float32 wrapped in RtcValue
func ArrayOfInt64AsRtcValue(v *[]int64) RtcValue {
	rtc := RtcValue{ArrayOfInt64: v}

	if v != nil {
		arrayOfFloat32 := make([]float32, len(*v))
		for i, i64 := range *v {
			arrayOfFloat32[i] = float32(i64)
		}

		rtc.ArrayOfFloat32 = &arrayOfFloat32
	}

	return rtc
}

// ToDataPoint converts the value into a data point.
//
// Internally it uses the `eqmodel.CbDataPointImpl` to create the data point.
func (r *RtcValue) ToDataPoint(
	id, partition string,
	err cberror.Error,
	ts coremodel.CbTime32,
) eqmodel.CbDataPoint {
	//
	if r == nil {
		return nil
	}

	return &eqmodel.CbDataPointImpl{
		ID:        id,
		Partition: partition,
		Value:     r.ToAny(),
		TimeStamp: ts,
		Error:     err,
	}
}

// ToRTCValueFromDataPoint converts `eqmodel.CbDataPoint` to `*RtcValue`.
func ToRTCValueFromDataPoint(dp eqmodel.CbDataPoint) *RtcValue {
	if dp == nil {
		return nil
	}

	value := dp.GetValue()
	if value == nil {
		return &RtcValue{}
	}

	switch v := value.(type) {
	case bool:
		return &RtcValue{Bool: &v}
	case float32:
		return &RtcValue{Float32: &v}
	case float64:
		// If v is a integer -> set Int64 as well, otherwise just float32
		if v == float64(int64(v)) {
			i64 := int64(v)
			return &RtcValue{Int64: &i64, Float32: aws.Float32(float32(v))}
		}

		return &RtcValue{Float32: aws.Float32(float32(v))}
	case int:
		return &RtcValue{Int64: aws.Int64(int64(v))}
	case int32:
		return &RtcValue{Int64: aws.Int64(int64(v))}
	case int64:
		return &RtcValue{Int64: &v, Float32: aws.Float32(float32(v))}
	case string:
		return &RtcValue{String: &v}
	case []bool:
		return &RtcValue{ArrayOfBool: &v}
	case []float32:
		return &RtcValue{ArrayOfFloat32: &v}
	case []float64:
		arrayOfFloat32 := make([]float32, len(v))
		for i, f64 := range v {
			arrayOfFloat32[i] = float32(f64)
		}
		return &RtcValue{ArrayOfFloat32: &arrayOfFloat32}
	case []int:
		arrayOfInt64 := make([]int64, len(v))
		for i, i64 := range v {
			arrayOfInt64[i] = int64(i64)
		}
		return &RtcValue{ArrayOfInt64: &arrayOfInt64}
	case []int32:
		arrayOfInt64 := make([]int64, len(v))
		for i, i64 := range v {
			arrayOfInt64[i] = int64(i64)
		}
		return &RtcValue{ArrayOfInt64: &arrayOfInt64}
	case []int64:
		return &RtcValue{ArrayOfInt64: &v}
	case []string:
		return &RtcValue{ArrayOfString: &v}
	default:
		return &RtcValue{}
	}
}

// ToAny extracts the value from the RtcValue and returns it as an any.
func (r *RtcValue) ToAny() any {
	if r == nil {
		return nil
	}

	if r.String != nil {
		return *r.String
	} else if r.Float32 != nil {
		return *r.Float32
	} else if r.Bool != nil {
		return *r.Bool
	} else if r.ArrayOfBool != nil {
		return *r.ArrayOfBool
	} else if r.ArrayOfFloat32 != nil {
		return *r.ArrayOfFloat32
	}

	return nil

}

// UnmarshalJSON overrides the default behavior to allow for int64 and
// more clever unmarshal tactics.
func (dst *RtcValue) UnmarshalJSON(data []byte) error {
	if len(data) == 0 {
		return fmt.Errorf("empty data")
	}

	// find will search to next valid json character
	find := func(d []byte) byte {
		for _, char := range d {
			if char != ' ' && char != '\t' && char != '\n' && char != '\r' {
				return char
			}
		}

		return 0
	}

	firstChar := find(data)
	if firstChar == 0 {
		return fmt.Errorf("no valid data")
	}

	switch firstChar {
	case '"':
		var s string
		if err := json.Unmarshal(data, &s); err != nil {
			return err
		}
		dst.String = &s
	case 't', 'f':
		var b bool
		if err := json.Unmarshal(data, &b); err != nil {
			return err
		}
		dst.Bool = &b
	case '[':
		nextChar := find(data[1:])
		if nextChar == 0 {
			return fmt.Errorf("no valid data")
		}

		// String
		if nextChar == '"' {
			var arrayOfString []string
			if err := json.Unmarshal(data, &arrayOfString); err != nil {
				return err
			}
			dst.ArrayOfString = &arrayOfString
		} else if nextChar == 't' || nextChar == 'f' {
			var arrayOfBool []bool
			if err := json.Unmarshal(data, &arrayOfBool); err != nil {
				return err
			}
			dst.ArrayOfBool = &arrayOfBool
		} else if bytes.Contains(data, []byte(".")) {
			var arrayOfFloat64 []float64
			if err := json.Unmarshal(data, &arrayOfFloat64); err != nil {
				return err
			}
			arrayOfFloat32 := make([]float32, len(arrayOfFloat64))
			for i, f64 := range arrayOfFloat64 {
				arrayOfFloat32[i] = float32(f64)
			}
			dst.ArrayOfFloat32 = &arrayOfFloat32
		} else {
			var arrayOfInt64 []int64
			if err := json.Unmarshal(data, &arrayOfInt64); err != nil {
				return err
			}
			dst.ArrayOfInt64 = &arrayOfInt64
		}
	case '-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9':
		if bytes.Contains(data, []byte(".")) {
			var f float64
			if err := json.Unmarshal(data, &f); err != nil {
				return err
			}
			f32 := float32(f)
			dst.Float32 = &f32
		} else {
			var i int64
			if err := json.Unmarshal(data, &i); err != nil {
				return err
			}
			dst.Int64 = &i
		}
	default:
		return fmt.Errorf("unknown data type")
	}

	// Since we're assuming that int64/arr is when the data do not have a decimal point,
	// we need to set the float32/arr counter part to that as well.
	//
	// The client may then choose to use the float32/arr if they want to.
	if dst.Int64 != nil {
		dst.Float32 = aws.Float32(float32(*dst.Int64))
	}

	if dst.ArrayOfInt64 != nil {
		arrayOfFloat32 := make([]float32, len(*dst.ArrayOfInt64))
		for i, i64 := range *dst.ArrayOfInt64 {
			arrayOfFloat32[i] = float32(i64)
		}
		dst.ArrayOfFloat32 = &arrayOfFloat32
	}

	return nil
}
