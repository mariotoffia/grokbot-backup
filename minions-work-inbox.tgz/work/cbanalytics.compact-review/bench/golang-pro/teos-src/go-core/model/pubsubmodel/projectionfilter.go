package pubsubmodel

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cbprocess"
)

// ProjectPayloadFunc is a function that may transform any of the elements in the _payload_
// into a `json.RawMessage`. The returned `json.RawMessage` may as well be the same pointer
// in the _payload_.
//
// This is used when configuring a `ProjectionFilter`.
type ProjectPayloadFunc func(payload *ProjectedPayloadImpl) json.RawMessage

// ProjectProcessedFunc is a function that may transform any of the elements in the _payload_
// into a, structured, processed alike output. The returned `map[string]interface{}` may be the
// same as in the _payload_.
//
// This is used when configuring a `ProjectionFilter`.
type ProjectProcessedFunc func(payload *ProjectedPayloadImpl) map[string]interface{}

// ProjectionFilterImpl implements the `ifpubsub.ProjectionFilter` interface to allow
// for projection and filter of data or _payload_.
//
// The usage order of the parameters are as follows
// 1. `Transform` is evaluated first
// 2. `ProjectPayloadFunc` | `ProjectProcessedFunc` depending on `ProjectionFilterImpl.PayloadProject` setting
// 3. `Policy` is evaluated last
//
// If any is not set or `nil`, the step will be skipped. When policy the `input` will be the _payload_ and the
// `data.meta` is the meta part, if `ProjectionFilterImpl.IncludeMeta` is set to `true`. The functions can reach
// *any* data but have either _Data_ or _Processed_ as output.
type ProjectionFilterImpl struct {
	// PayloadProject determines if it is the `json.RawMessage`,_Data_, or `map[string]interface{}`
	// i.e. _Processed_ that will be the source & target in the projection and filtering.
	//
	// If set to `true`, the `json.RawMessage` is used
	PayloadProject bool `json:"payload,omitempty"`
	// IncludeMeta allows to include `PayloadImpl.Meta` to be included during projection / filter.
	//
	// This is only affecting if `Policy` is set. It will then be loaded as `data.meta.*`.
	IncludeMeta bool `json:"meta,omitempty"`
	// Policy is the path of the policy to use when calling `PolicyDecisionPoint.Process`.
	//
	// This may be a plain transform or with filter / rejection as well.
	Policy []string `json:"policy,omitempty"`
	// PolicyQuery is the query to run on the `Policy`.
	//
	// If omitted, the query is expected to be defined in the `PolicyDecisionPoint` query configuration for the `Policy`.
	PolicyQuery string `json:"query,omitempty"`
	// Transform contains a array of names to _JSON_ transform templates to be used
	// to _JSON_ payload or `map[string]interface{}' transform. This is looked up
	// in a `cbprocess.JsonTemplateRepository`.
	Transform []string `json:"transform,omitempty"`
	// Transformer specifies the type of the `cbprocess.JsonTransformer` to use. If
	// omitted and `Transform` is valid, _kazaam_ is used.
	Transformer cbprocess.JsonTemplateType `json:"transformer,omitempty"`
	// FnProjectPayload projects into a `json.RawMessage`.
	FnProjectPayload ProjectPayloadFunc `json:"-"`
	// FnProjectProcessed projects into a `map[string]interface{}`.
	FnProjectProcessed ProjectProcessedFunc `json:"-"`
}
