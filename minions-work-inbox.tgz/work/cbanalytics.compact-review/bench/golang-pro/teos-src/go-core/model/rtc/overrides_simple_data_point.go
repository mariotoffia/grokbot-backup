package rtc

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// ToDataPoint converts the value into a data point.
//
// Internally it uses the `eqmodel.CbDataPointImpl` to create the data point.
func (r *SimpleDataPoint) ToDataPoint(
	ctx ifcore.CbContext,
	id, partition string,
) eqmodel.CbDataPoint {
	//
	if r == nil {
		return nil
	}

	var err cberror.Error
	var ts coremodel.CbTime32

	if r.T.String != nil {
		var e error
		if ts, e = coremodel.FromRFC3339String(*r.T.String); e != nil {
			err = cberror.NewCbErrorfWithProps(ctx.Service(), 1, e, map[string]any{
				cberror.PropertyProvider: ctx.Provider(),
			}, "Failed to parse timestamp %s", *r.T.String)
		}
	} else {
		ts = *coremodel.NewTime32(*r.T.Int64)
	}

	return &eqmodel.CbDataPointImpl{
		ID:        id,
		Partition: partition,
		Value:     r.V.ToAny(),
		TimeStamp: ts,
		Error:     err,
	}
}
