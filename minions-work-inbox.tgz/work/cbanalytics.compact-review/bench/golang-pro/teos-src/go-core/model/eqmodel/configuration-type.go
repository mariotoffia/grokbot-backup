package eqmodel

type ConfigurationType string

const (
	// ConfigurationTypeIndoorTemperatureLimitLow is the limit set by the system
	// to control against. This is the lower limit.
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationTypeIndoorTemperatureLimitLow ConfigurationType = "ITL"
	// ConfigurationTypeIndoorTemperatureLimitHigh is the limit set by the system
	// to control against. This is the upper limit.
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationTypeIndoorTemperatureLimitHigh ConfigurationType = "ITH"
	// ConfigurationTypeIndoorTemperatureTarget is the target to control against.
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationTypeIndoorTemperatureTarget ConfigurationType = "ITT"
	// ConfigurationTypeOutdoorBalanceTemperature is the balance temperature
	// to control against. This is usually in what temperature the system
	// is balanced and is not heating or cooling (swedish "pump stopp").
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationTypeOutdoorBalanceTemperature ConfigurationType = "OBT"

	// ConfigurationTypeHeatingCurveOutDoorTempTrigger is a outdoor temperature trigger
	// to trigger the paired heating curve.
	//
	// Heating curves have triggers O1 to On and its counterpart to control the supply
	// temperature is O1 to On.'
	//
	// .Example Heating Curve with supply temp
	// [source, json]
	// ----
	// {
	//   "HCTODT_O1": -20,
	//   "HCTST_O1": 70,
	//   "HCTODT_O2": -10,
	//   "HCTST_O2": 70,
	//   "HCTODT_O3": -5,
	//   "HCTST_O3": 63,
	//   "HCTODT_O4": 0,
	//   "HCTST_O4": 55,
	//   "HCTODT_O5": 5,
	//   "HCTST_O5": 46,
	//   "HCTODT_O6": 10,
	//   "HCTST_O6": 40,
	//   "HCTODT_O7": 15,
	//   "HCTST_O7": 28,
	// }
	// ----
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationTypeHeatingCurveOutDoorTempTrigger ConfigurationType = "HCTODT"
	// ConfigurationTypeHeatingCurveNumValidCount is a parameter that may constrain the number
	// of valid entries in a heating curve. It always refers to the ordinal - 1 of both
	// heating curve triggers and supply temperatures.
	ConfigurationTypeHeatingCurveNumValidCount ConfigurationType = "HCTCNT"

	// ConfigurationTypeHeatingCurveSupplyTemp is the supply temperature for the
	// paired heating curve.
	//
	// Heating curves have triggers O1 to On and its counterpart to control the supply
	// temperature is O1 to On. (_See HCTODT for example heating curve table_).
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationTypeHeatingCurveSupplyTemp ConfigurationType = "HCTST"
	// ConfigurationTypeHeatingCurve is the generic key for a heating curve. Under this
	// a `servicemodel.HeatingCurveEntry` array expected.
	ConfigurationTypeHeatingCurve ConfigurationType = "HCT"
	// ConfigurationSecondaryCircuitMinFeedTemp is the minimum feed temperature for the
	// secondary circuit that can be controlled. It should never be lower
	// than the minimum temperature that the heat source can provide.
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationSecondaryCircuitMinFeedTemp ConfigurationType = "SCMFT"

	// ConfigurationSecondaryCircuitMaxFeedTemp is the maximum feed temperature for the
	// secondary circuit that can be controlled. It should never be higher
	// than the maximum temperature that the heat source can provide.
	//
	// Unit: °C, Resolution: 0.1 °C
	ConfigurationSecondaryCircuitMaxFeedTemp ConfigurationType = "SCMAT"
	// ConfigurationOptimizationControlPrinciple is the controlling principle
	//
	//
	// See `OptimizationsControlPrinciple` for possible values.
	//
	// Currently supported
	// * ACTODT 			- Absolute outdoor temperature (we set the acting temperature directly)
	// * OFFODT 			- Outdoor temperature Offset
	// * ACTSPSSHCT 		- Absolute supply secondary heating circuit temperature
	// * SPSSHCT 			- Supply secondary heating circuit temperature
	// * SPRHCT 			- Setpoint Control based on return temperature on secondary circuit
	ConfigurationOptimizationControlPrinciple ConfigurationType = "OCP"
	// ConfigurationOptimizationActivation specifies in RFC3339 format when the service
	// is expected to be activated.
	ConfigurationOptimizationActivation ConfigurationType = "ACTIVATION"
	// ConfigurationEffectServiceLevel specifies effect to use or is installed
	// on-site that the service shall relate to.
	//
	// Well known service types are in TeosEffectServiceLevels
	ConfigurationEffectServiceLevel ConfigurationType = "ESL"
	// ConfigurationCircuitType is used to specify the meaning of a _Cn_ in a sensor name. By default
	// it stands for _Circuit_ that has a heat exchanger. It is possible for it to be representing
	// a shunt group instead (without a exchanger) by specifying the parameter CTP_Cn=shunt.
	//
	// Possible values are:
	// * shunt
	// * exchanger
	ConfigurationCircuitType ConfigurationType = "CTP"
)
