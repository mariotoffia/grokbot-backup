package eqmodel

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/idutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

const buildingPrefix = "BLD#"
const equipmentPrefix = "EQ#"
const sensorPrefix = "S#"

// ShallowEqual will check if the _LocationID_, _EquipmentID_, _SensorID_ are equal.
func (s *InstalledSensor) ShallowEqual(other *InstalledSensor) bool {
	return s.LocationID == other.LocationID &&
		s.EquipmentID == other.EquipmentID &&
		s.SensorID == other.SensorID
}

// In will check if _ps_ exists in _other_. It will do a `ShallowEqual` check.
func (s *InstalledSensor) In(other []InstalledSensor) bool {
	for _, o := range other {
		o := o

		if s.ShallowEqual(&o) {
			return true
		}
	}

	return false
}

// MarshalMap creates a map[string]any from the `InstalledSensor`.
func (s *InstalledSensor) MarshalMap() (map[string]any, error) {
	return jsonutils.ToJSONMap(s)
}

// UnmarshalMap requires that the m points to a map[string]any of where
// it contains a single representation of `InstalledSensor`.
func (s *InstalledSensor) UnmarshalMap(m map[string]any) error {
	if s == nil {
		s = &InstalledSensor{}
	}

	return json.Unmarshal(jsonutils.ToJSON(m), s)
}

// Prepare will prepare the `InstalledEquipment` for database operation.
//
// It will return itself for fluent API.
func (s *InstalledSensor) Prepare() *InstalledSensor {
	if s == nil {
		return nil
	}

	s.EquipmentID = strings.TrimPrefix(s.EquipmentID, equipmentPrefix)
	s.SensorID = strings.TrimPrefix(s.SensorID, sensorPrefix)

	if !strings.HasPrefix(s.LocationID, buildingPrefix) {
		s.LocationID = buildingPrefix + s.LocationID
	}

	s.SK = fmt.Sprintf("EQ#%s#S#%s", s.EquipmentID, s.SensorID)

	return s
}

// PostProcess will make sure that all identifiers are correctly set after
// a query from the database.
func (s *InstalledSensor) PostProcess(ctx ifcore.CbContext) *InstalledSensor {
	if s == nil {
		return nil
	}

	s.SK = ""
	s.LocationID = strings.TrimPrefix(s.LocationID, buildingPrefix)

	return s
}

// OwnedBy will check if the `LocationID` do end with ' ({owner})'. It will extract that and return the
// owner string.
func (s *InstalledSensor) OwnedBy() string {
	if s == nil {
		return ""
	}

	_, rsid := idutils.RSIDDecodeLocationID(strings.TrimPrefix(s.LocationID, buildingPrefix))

	return rsid
}

// IsAttachedTo will check if the sensor is attached to any of the equipment
// in _eqID_.
func (s *InstalledSensor) IsAttachedTo(eqID ...string) bool {
	for _, id := range eqID {
		if s.EquipmentID == id {
			return true
		}
	}

	return false
}

// ResolveRemoteID will return the `RemoteID` of the sensor. If not set, it
// will check the params _RID_ for a value.
//
// If unresolved, an empty string is returned.
func (s *InstalledSensor) ResolveRemoteID() string {
	if s == nil {
		return ""
	}

	if s.RemoteID != "" {
		return s.RemoteID
	}

	if rid, ok := s.Params["RID"]; ok {
		if rid, ok := rid.(string); ok {
			return rid
		}

		return fmt.Sprintf("%v", rid)
	}

	return ""
}

// Circuit will check if `EqCircuit` exists in `Params` and return the value.
//
// If none is found -1 is returned.
func (s *InstalledSensor) Circuit() int {
	if s == nil {
		return -1
	}

	if _, ok := s.Params[string(EqCircuit)]; ok {
		return int(utils.ExtractInt64FromMap(string(EqCircuit), s.Params, -1))
	}

	return -1
}
