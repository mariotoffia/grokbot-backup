package storagemodel

import (
	"fmt"
	"time"
)

type DataType string

const (
	// DataTypeString is a string value
	DataTypeString DataType = "string"
	// DataTypeBinary is a binary value
	DataTypeBinary DataType = "binary"
	// DataTypeStringList is a list of strings
	DataTypeStringList DataType = "stringlist"
	// DataTypeNumber is an number value
	DataTypeNumber DataType = "number"
)

type SecureStorageObject struct {
	// ID is the unique identifier of the object. In _AWS_ this is the _ARN_.
	ID string `json:"id"`
	// Name is the name of the object.
	Name string `json:"name"`
	// Path is the path of the object (if hierarchical storage is supported).
	Path string `json:"path"`
	// PathSeparator is the path separator used by the storage provider.
	//
	// If omitted, the secure storage provider do not support hierarchical storage.
	// For _AWS_ this is '/'.
	PathSeparator string `json:"sep"`
	// LastModified is the date and time when the object was last modified.
	LastModified time.Time `json:"mod"`
	// IsEncrypted specifies if the object is encrypted when stored or not. The value
	// in `Value` is always decrypted.
	IsEncrypted bool `json:"enc"`
	// Version is a version of the object. This may be numeric or a arbitrary value.
	Version string `json:"ver"`
	// Value is the value stored in the object. The value is always decrypted (if encrypted at storage).
	Value any `json:"val"`
	// DataType is the type of the value stored in the object.
	DataType DataType `json:"type"`
}

// ValueAsString will make sure that the value is a string and return it. If
// `nil` an empty string is returned.
func (obj *SecureStorageObject) ValueAsString() string {
	if obj.Value == nil {
		return ""
	}

	switch obj.DataType {
	case DataTypeString:
		return obj.Value.(string)
	case DataTypeBinary:
		return string(obj.Value.([]byte))
	case DataTypeStringList:
		return obj.Value.(string)
	case DataTypeNumber:
		return fmt.Sprintf("%v", obj.Value)
	}

	return fmt.Sprintf("%v", obj.Value)
}
