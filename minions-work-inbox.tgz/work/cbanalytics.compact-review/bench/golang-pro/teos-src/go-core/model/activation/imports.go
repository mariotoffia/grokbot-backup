package activation

import (
	"github.com/Thiink-LLC/teos/go-core/model/meta"
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
)

type ResourceSecurityDocument securitymodel.ResourceSecurityDocument
type OpenIDConnectToken securitymodel.OpenIDConnectToken
type Customer meta.Customer
