package eqdefs

import (
	"strings"
)

type DataPointDefinition struct {
	// ID is the ID of the datapoint.
	//
	// ID contains the fully qualified name whereas
	// the _Name_ fields only contains the name of the datapoint.
	//
	// TIP: A slash is the path separator.
	//
	// The id is composed with the following parts:
	// 	- The path qualifier e.g. TEOS/Something/
	// 	- The object name e.g. Circuit
	// 	- The datapoint name e.g. Return Temperature
	//
	// The ID will then be: _TEOS/Something/Circuit/Return Temperature_
	ID string `json:"id"`
	// The Thiink Canonical Model Name
	//
	// NOTE: This comes from the `eqmodel.SensorType` and `eqmodel.DataPointType`
	// constants - and *nothing* else!
	TeosID string `json:"teosID"`
	// Sensor determines if the _TeosID_ is a `eqmodel.SensorType` or a `eqmodel.DataPointType`.
	Sensor bool `json:"sensor"`
	// The description of the datapoint in english.
	Description string `json:"description"`
	// Type is the type of the datapoint.
	Type DataPointDefinitionType `json:"type"`
	// Specifies whether the virtual data point is writable.
	Readonly bool `json:"readonly"`
	// Low defines the minimum value the data point is allowed to take.
	Low float64 `json:"low,omitempty"`
	// High defines the maximum value the data point is allowed to take.
	High float64 `json:"high,omitempty"`
	// Unit specifies the units.
	//
	// The _si_ system is mandatory!
	Unit map[DataPointUnitSystem]DataPointUnit `json:"unit"`
	// Conversion specifies the conversion between _Unit_ types.
	Conversion map[DataPointUnitSystem]DataPointConversion `json:"conversion,omitempty"`
}

// DataPointDefinitionType specifies what type of datapoint it is.
type DataPointDefinitionType string

const (
	DataPointDefinitionTypeString   DataPointDefinitionType = "string"
	DataPointDefinitionTypeNumber   DataPointDefinitionType = "number"
	DataPointDefinitionTypeInteger  DataPointDefinitionType = "integer"
	DataPointDefinitionTypeBoolean  DataPointDefinitionType = "boolean"
	DataPointDefinitionTypeEnum     DataPointDefinitionType = "enum"
	DataPointDefinitionTypeDateTime DataPointDefinitionType = "datetime"
	DataPointDefinitionTypeDate     DataPointDefinitionType = "date"
	DataPointDefinitionTypeTime     DataPointDefinitionType = "time"
	DataPointDefinitionTypeDuration DataPointDefinitionType = "duration"
	DataPointDefinitionTypeBinary   DataPointDefinitionType = "binary"
	DataPointDefinitionTypeArray    DataPointDefinitionType = "array"
	DataPointDefinitionTypeObject   DataPointDefinitionType = "object"
	DataPointDefinitionTypeBitmask  DataPointDefinitionType = "bitmask"
)

type DataPointUnit struct {
	// Name is the display friendly of the unit (e.g. "°C").
	Name string `json:"name"`
	// Symbol is the symbol of the unit (e.g. "C").
	Symbol DataPointUnitSymbol `json:"symbol"`
}

// DataPointUnitSystem specifies which system the unit belongs to
type DataPointUnitSystem string

const (
	// DataPointUnitSystemSI represents the _SI_ system
	DataPointUnitSystemSI DataPointUnitSystem = "si"
	// DataPointUnitSystemImperial represents the _imperial_ system
	DataPointUnitSystemImperial DataPointUnitSystem = "imperial"
)

// DataPointUnitSymbol is a symbol of a unit.
type DataPointUnitSymbol string

const (
	DataPointUnitSymbolCelsius          DataPointUnitSymbol = "C"
	DataPointUnitSymbolFahrenheit       DataPointUnitSymbol = "F"
	DataPointUnitSymbolKelvin           DataPointUnitSymbol = "K"
	DataPointUnitSymbolPercent          DataPointUnitSymbol = "%"
	DataPointUnitSymbolMeter            DataPointUnitSymbol = "m"
	DataPointUnitSymbolKiloWatthour     DataPointUnitSymbol = "kWh"
	DataPointUnitSymbolKiloWatt         DataPointUnitSymbol = "kW"
	DataPointUnitSymbolWatt             DataPointUnitSymbol = "W"
	DataPointUnitSymbolMeterCube        DataPointUnitSymbol = "m3"
	DataPointUnitSymbolMeterCubePerHour DataPointUnitSymbol = "m3/h"
	DataPointUnitSymbolMinutes          DataPointUnitSymbol = "min"
	DataPointUnitSymbolHours            DataPointUnitSymbol = "h"
	DataPointUnitSymbolNumber           DataPointUnitSymbol = "num"
	DataPointUnitSymbolBitField         DataPointUnitSymbol = "bits"
)

// DataPointConversion specifies how to convert between different systems.
type DataPointConversion struct {
	// Gain is the gain of the conversion.
	Gain float64 `json:"gain"`
	// Offset is the offset of the conversion.
	Offset float64 `json:"offset"`
}

// DataPointObjectNames represents well known object names.
type DataPointObjectNames string

const (
	DataPointObjectNameCircuit                  DataPointObjectNames = "Circuit"
	DataPointObjectNamePrimaryCircuit           DataPointObjectNames = "Primary Circuit"
	DataPointObjectNameSecondaryCircuit         DataPointObjectNames = "Secondary Circuit"
	DataPointObjectNameHotWaterCircuit          DataPointObjectNames = "Hot Water Circuit"
	DataPointObjectNamePrimaryHotWaterCircuit   DataPointObjectNames = "Primary Hot Water Circuit"
	DataPointObjectNameSecondaryHotWaterCircuit DataPointObjectNames = "Secondary Hot Water Circuit"
	DataPointObjectNameOutdoor                  DataPointObjectNames = "Outdoor"
	DataPointObjectNameIndoor                   DataPointObjectNames = "Indoor"
	DataPointObjectNameHeatMeter                DataPointObjectNames = "Heat Meter"
	DataPointObjectNameCircuitControl           DataPointObjectNames = "Circuit Control"
	DataPointObjectNameCommunication            DataPointObjectNames = "Communication"
)

// Path returns the path portion for the datapoint _ID_
func (dpd DataPointDefinition) Path() string {
	idx := strings.LastIndex(dpd.ID, "/")
	if idx == -1 {
		return ""
	}
	return dpd.ID[:idx]
}

// ObjectName is the last path element before `Name()`
// where the "object" grouping is defined.
func (dpd DataPointDefinition) ObjectName() string {
	end := strings.LastIndex(dpd.ID, "/")
	if end == -1 {
		return ""
	}
	start := strings.LastIndex(dpd.ID[:end], "/")
	if start == -1 {
		return ""
	}

	return dpd.ID[start+1 : end]
}

// Name returns the name portion for the datapoint _ID_.
func (dpd DataPointDefinition) Name() string {
	idx := strings.LastIndex(dpd.ID, "/")
	if idx == -1 {
		return dpd.ID
	}
	return dpd.ID[idx+1:]
}
