package securitymodel_test

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
)

// A machine client carries its remote system ID and organisation IDs as
// teos/c-rsid:{value} and teos/c-oid:{value} scopes. These are identifiers, so
// a value made of digits only stays the same text: the rsid "007" is not the
// number 7, and decoding it must neither panic nor drop it.

func TestUnmarshalMap_RSID_ScopeEncoded_DigitsStayText(t *testing.T) {
	var oidc securitymodel.OpenIDConnectToken
	require.NoError(t, json.Unmarshal([]byte(`{"scope": "teos/c-rsid:007 teos/sur-df"}`), &oidc))

	assert.Equal(t, "007", oidc.RemoteSystemID)
	assert.Equal(t, "teos/sur-df", oidc.Scope)
}

func TestUnmarshalMap_RSID_ScopeEncoded_WithoutValueIsIgnored(t *testing.T) {
	var oidc securitymodel.OpenIDConnectToken
	require.NoError(t, json.Unmarshal([]byte(`{"scope": "teos/c-rsid teos/sur-df"}`), &oidc))

	assert.Empty(t, oidc.RemoteSystemID)
}

func TestUnmarshalMap_OID_ScopeEncoded_DigitsStayText(t *testing.T) {
	var oidc securitymodel.OpenIDConnectToken
	require.NoError(t, json.Unmarshal([]byte(`{"scope": "teos/c-oid:42"}`), &oidc))

	assert.Equal(t, []string{"42"}, oidc.OID)
}

func TestUnmarshalMap_OID_ScopeEncoded_DigitListStaysText(t *testing.T) {
	var oidc securitymodel.OpenIDConnectToken
	require.NoError(t, json.Unmarshal([]byte(`{"scope": "teos/c-oid:42,0043"}`), &oidc))

	assert.Equal(t, []string{"42", "0043"}, oidc.OID)
}

// orderRuns is how often a test decodes the same token. Go visits map entries
// in a random order, so a result that depends on the order of the claims
// differs between runs.
const orderRuns = 200

func decodeToken(t *testing.T, claims map[string]any) securitymodel.OpenIDConnectToken {
	t.Helper()

	data, err := json.Marshal(claims)
	require.NoError(t, err)

	var oidc securitymodel.OpenIDConnectToken
	require.NoError(t, json.Unmarshal(data, &oidc))

	return oidc
}

// A user's token gets no claims from teos/c-* scopes: only a machine client's
// token carries its claims that way. The scopes are removed all the same.
func TestUnmarshalMap_UserTokenGetsNoClaimsFromScopes(t *testing.T) {
	claims := map[string]any{
		"sub":       "8c059ae6-dee7-4145-a6dc-d2820b4adf70",
		"client_id": "spa",
		"scope":     "teos/sca-config-read teos/c-rsid:all teos/c-oid:orgx teos/c-trust:10000",
	}

	for range orderRuns {
		oidc := decodeToken(t, claims)
		require.Empty(t, oidc.RemoteSystemID, "a user must not get a remote system from a scope")
		require.Empty(t, oidc.OID)
		require.NotContains(t, oidc.Claims, "trust")
		require.Equal(t, "teos/sca-config-read", oidc.Scope)
	}
}

// In a machine token (sub is the client ID) a non-empty direct claim wins
// over the same claim encoded as a scope, whatever the order of the claims.
func TestUnmarshalMap_MachineTokenDirectClaimsWin(t *testing.T) {
	claims := map[string]any{
		"sub":       "client-a",
		"client_id": "client-a",
		"rsid":      "direct-rsid",
		"oid":       "direct-org",
		"trust":     "500",
		"scope":     "teos/c-rsid:scope-rsid teos/c-oid:scope-org teos/c-trust:10000 teos/c-pn:extra",
	}

	for range orderRuns {
		oidc := decodeToken(t, claims)
		require.Equal(t, "direct-rsid", oidc.RemoteSystemID)
		require.Equal(t, []string{"direct-org"}, oidc.OID)
		require.Equal(t, "500", oidc.Claims["trust"])
		require.Equal(t, "extra", oidc.Claims["pn"], "a claim only the scopes carry is added")
		require.Empty(t, oidc.Scope)
	}
}

// In a machine token an empty direct claim is filled from the scope.
func TestUnmarshalMap_MachineTokenScopeFillsAnEmptyDirectClaim(t *testing.T) {
	claims := map[string]any{
		"sub":       "client-a",
		"client_id": "client-a",
		"rsid":      "",
		"trust":     "",
		"scope":     "teos/c-rsid:site-a teos/c-trust:10000",
	}

	for range orderRuns {
		oidc := decodeToken(t, claims)
		require.Equal(t, "site-a", oidc.RemoteSystemID)
		require.Equal(t, int64(10000), oidc.Claims["trust"])
	}
}
