package eqdefs

import (
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// climateSensorDefinitions holds the definitions of the control, savings,
// humidity, indoor and outdoor sensor data points, keyed by TEOS identifier.
var climateSensorDefinitions = map[string]DataPointDefinition{
	// AVGIDTC
	string(eqmodel.DataPointAverageIndoorTempControl): {
		ID:          "TEOS/Control/Indoor/Average Temperature Control",
		TeosID:      string(eqmodel.DataPointAverageIndoorTempControl),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "Average Indoor Temperature (seen by controlling algorithm)",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// ESHL
	string(eqmodel.DataPointEffectSavingPerHourLocal): {
		ID:          "TEOS/Savings/Energy Saving Per Hour (local)",
		TeosID:      string(eqmodel.DataPointEffectSavingPerHourLocal),
		Sensor:      false,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -99999,
		High:        99999,
		Description: "The Saved Energy Per Hour (use for short timespan)",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "kW",
				Symbol: DataPointUnitSymbolCelsius,
			},
		},
	},
	// ESHG
	string(eqmodel.DataPointEffectSavingPerHourGlobal): {
		ID:          "TEOS/Savings/Energy Saving Per Hour (global)",
		TeosID:      string(eqmodel.DataPointEffectSavingPerHourGlobal),
		Sensor:      false,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -99999,
		High:        99999,
		Description: "The Saved Energy Per Hour (use for long timespan)",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "kW",
				Symbol: DataPointUnitSymbolCelsius,
			},
		},
	},

	// HUM
	string(eqmodel.SensorHumidity): {
		ID:          "TEOS/Moist/Humidity",
		TeosID:      string(eqmodel.SensorHumidity),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        100,
		Description: "The relative humidity for current temperature",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "%",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°%",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
	},
	// IDT
	string(eqmodel.SensorIndoorTemp): {
		ID:          "TEOS/Indoor/Temperature",
		TeosID:      string(eqmodel.SensorIndoorTemp),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The temperature inside the building",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// MINIDT
	string(eqmodel.SensorMinIndoorTemp): {
		ID:          "TEOS/Indoor/Minimum Temperature",
		TeosID:      string(eqmodel.SensorMinIndoorTemp),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The minimum temperature inside the building",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// MAXIDT
	string(eqmodel.SensorMaxIndoorTemp): {
		ID:          "TEOS/Indoor/Maximum Temperature",
		TeosID:      string(eqmodel.SensorMaxIndoorTemp),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The maximum temperature inside the building",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// AVGIDT
	string(eqmodel.SensorAverageIndoorTemp): {
		ID:          "TEOS/Indoor/Average Temperature",
		TeosID:      string(eqmodel.SensorAverageIndoorTemp),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The average temperature indoor",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// ODT
	string(eqmodel.SensorOutdoorTemp): {
		ID:          "TEOS/Outdoor/Temperature",
		TeosID:      string(eqmodel.SensorOutdoorTemp),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The temperature outside",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// OFFODT
	string(eqmodel.SensorOffsetOutdoorTemperature): {
		ID:          "TEOS/Outdoor/Offset Temperature",
		TeosID:      string(eqmodel.SensorOffsetOutdoorTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The offset on outside temperature",
		Readonly:    false,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// ACTODT
	string(eqmodel.SensorActiveOutdoorTemperature): {
		ID:          "TEOS/Outdoor/Active Temperature",
		TeosID:      string(eqmodel.SensorActiveOutdoorTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         -300,
		High:        300,
		Description: "The outside temperature where the heater uses to calculate the heat demand on",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
}
