// Package teosid parses and renders canonical TEOS data-point identifiers.
package teosid

import "fmt"

// Parts contains the fields needed to render one TEOS identifier.
type Parts struct {
	QualifiedID string
	Ordinal     *int
	Circuit     *int
	Zone        *string
	Area        *string
	Tags        map[string]string
}

// Identity is a parsed TEOS identifier. Custom tag values retain their exact
// spelling; only reserved numeric dimensions are normalized in Canonical.
type Identity struct {
	Raw             string
	Canonical       string
	QualifiedID     string
	Category        string
	Subcategories   []string
	SubcategoryPath string
	ID              string
	Ordinal         *int
	Circuit         *int
	Zone            *string
	Area            *string
	Tags            map[string]string
}

// ParseError identifies a stable parse failure and its byte offset in the
// original identifier.
type ParseError struct {
	Code   string
	Offset int
}

func (e *ParseError) Error() string {
	return fmt.Sprintf("invalid TEOS identifier at byte %d: %s", e.Offset, e.Code)
}

func parseError(code string, offset int) error {
	return &ParseError{Code: code, Offset: offset}
}
