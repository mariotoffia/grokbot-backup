package pubsubmodel

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

// tag::dispatch-payload[]

// PayloadImpl is the default structure of the payload dispatched in the subscription and
// policy pipes. It implements the `ifcore.Payload` interface.
//
// The classification and transformation pipes may use other type of payload. But output of
// a transform pipe and at least input for the subscription pipe / function is this struct.
type PayloadImpl struct {
	// Type specifies the type of this instance, hence the contents of the `Payload` field may vary.
	Type ifcore.PayloadType
	// DetailedType is a more specific type.
	DetailedType ifcore.DetailedPayloadType
	// Meta contains all metadata surrounded by and extracted from the Payload.
	//
	// For example, if present the provider name and direction (_see `SubscriptionQualifier` for more info_).
	//
	// It also may contain e.g. _tz_ if a building device shadow etc. <1>
	Meta map[string]interface{} `json:"meta,omitempty"`
	// Data is the actual, original, payload to dispatch.
	//
	// This is the unprocessed payload received. This is mainly used to have slices (pointers) from
	// the `Parsed` and when projection: _$original_ is used for a subscription to just dispatch with complete integrity of
	// the original message. <2>
	Data json.RawMessage `json:"data,omitempty"`
	// Processed contains all datapoints that have been parsed out of the `Data` to be used
	// for selection and projection.
	//
	// Depending on the subscription type, the `Data` is used instead of this property to do projection on, however
	// it is always used to do selection when `Type` is `PayloadTypeDataPoint`.
	//
	// When the `Type` is `PayloadTypeConfig` the id of the configuration is set as "lid" in `Meta` and
	// this field contains nothing. Instead the original message in `Data` is the configuration.
	//
	// When it is `PayloadTypeDataPoint`, the datapoint is a flat name value map.
	//
	// NOTE: That _meta_ datapoint key values are put under the `Meta` such as _tz_, _oid_ etc.
	//
	// If all subscriptions projections are set to only _$original_, and no datapoint expressions. This field is
	// _OPTIONAL_ and hence acts as an optimization of `DispatchProviders` that do only dispatch complete original _JSON_
	// to subscribers, where the subscrition is purely `Meta` based. <3>
	//
	// The subscription filter datapoint will look under node _sensors_
	Processed map[string]interface{} `json:"proc,omitempty"`
}

func (p *PayloadImpl) GetType() ifcore.PayloadType {
	return p.Type
}

func (p *PayloadImpl) GetDetailedType() ifcore.DetailedPayloadType {
	return p.DetailedType
}

func (p *PayloadImpl) GetMeta() map[string]interface{} {
	return p.Meta
}

func (p *PayloadImpl) GetData() json.RawMessage {
	return p.Data
}

func (p *PayloadImpl) GetProcessed() map[string]interface{} {
	return p.Processed
}

// end::dispatch-payload[]
// tag::projected-payload[]

// ProjectedPayloadImpl is a projection of the payload. It implements the `ifcore.ProjectedPayload` interface.
type ProjectedPayloadImpl struct {
	// Original represents the original `PayloadImpl`.
	Original *PayloadImpl `json:"o"`
	// ProjectedData is the projected payload. If no projection, this fields
	// points to the `Original.Data` instance of the payload.
	// Hence, the complete, original, _JSON_ payload.
	ProjectedData json.RawMessage `json:"pd,omitempty"`
	// ProjectedProcessed is the projected version of the `PayloadImpl.Processed`.
	ProjectedProcessed map[string]interface{} `json:"proc,omitempty"`
	// PayloadProject determines if it is the `json.RawMessage`,_Data_, or `map[string]interface{}`
	// i.e. _Processed_ that has been the source & target in the projection and filtering.
	//
	// If set to `true`, the `json.RawMessage` was used.
	//
	// CAUTION: This is merely a hint since it will be the last `ProjectionFilterImpl` that determines
	// the value of this property.
	PayloadProject bool `json:"payload,omitempty"`
	// PayloadMeta is a _JSON_ representation of `PayloadImpl.Meta`. this is
	// generated if needed.
	//
	// NOTE: When it has been generated, there's no need to generate it more than once.
	PayloadMeta json.RawMessage `json:"-"`
	// IsProjected is a flag that is set to `true` when any projection or filtering has been done.
	// If it is set to `false` *only* _Original_ should be used!
	IsProjected bool `json:"-"`
}

func (p *ProjectedPayloadImpl) GetOriginal() ifcore.Payload {
	return p.Original
}
func (p *ProjectedPayloadImpl) GetProjectedData() json.RawMessage {
	return p.ProjectedData
}
func (p *ProjectedPayloadImpl) GetProjectedProcessed() map[string]interface{} {
	return p.ProjectedProcessed
}
func (p *ProjectedPayloadImpl) GetPayloadMeta() json.RawMessage {
	return p.PayloadMeta
}
func (p *ProjectedPayloadImpl) GetIsProjected() bool {
	return p.IsProjected
}

// end::projected-payload[]
