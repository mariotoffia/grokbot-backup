package storagemodel

// StorageObjectEvent represents a provider-agnostic notification that a
// storage object was created or modified. It abstracts S3 ObjectCreated,
// Azure BlobCreated, filesystem inotify events, etc.
type StorageObjectEvent struct {
	// Location is the container name (S3 bucket, Azure container, base dir).
	Location string
	// Key is the object identifier within the location (S3 key, blob path,
	// relative file path).
	Key string
	// Size is the object size in bytes (0 if unknown).
	Size int64
	// Source identifies the event origin (e.g. "aws:s3", "azure:blob",
	// "fs:inotify").
	Source string
}

// ObjectDescriptor describes a loaded storage object after download.
type ObjectDescriptor struct {
	// Location is where the object was loaded from.
	Location string
	// Key is the object key/path.
	Key string
	// Size is the raw size in bytes before decompression.
	Size int64
}
