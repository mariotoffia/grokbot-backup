package reportmodel

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestMarshalUnmarshalSimpleReport(t *testing.T) {
	report := ReportContainerImpl[ExportDataPointReport]{
		LocationID: "Junit 18",
		Provider:   "noda",
		Profile:    "test",
		ReportType: ReportTypeExportDataPointReport,
		Body: ExportDataPointReport{
			Count: 1,
			DataPoints: map[string]RemoteDataPointInfo{
				"MPRT": {
					Value:           45.2,
					RemoteID:        "outdoor_temp",
					RemotePartition: "2",
					RemoteTimeStamp: "2018-01-01T00:00:00Z",
				},
			},
			Body: map[string]interface{}{"hello": "world"},
		},
	}

	data, err := json.Marshal(&report)
	assert.Equal(t, nil, err)

	report2, err := UnmarshalReportContainer(data)
	assert.Equal(t, nil, err)
	assert.Equal(t, report.LocationID, report2.GetLocationID())
	assert.Equal(t, report.Provider, report2.GetProvider())
	assert.Equal(t, report.ReportType, report2.GetReportType())

	if rep, ok := report2.GetBody().(ExportDataPointReport); ok {
		assert.Equal(t, report.Body.DataPoints, rep.DataPoints)
		assert.Equal(t, report.Body.Body, rep.Body)
	} else {
		t.Errorf("Expected report to be of type ExportDataPointReport")
	}
}
