package reportmodel

import (
	"encoding/json"
	"fmt"
)

// Reportable represents a type that can be reported through `ReportContainer`.
type Reportable interface {
	ExportDataPointReport |
		ImportDataPointReport |
		MissingDataPointReport |
		DataPointThresholdReport |
		CoreTargetDataPointReport |
		ServiceExecutionReport
}

type ReportType string

const (
	// ExportDataPointReport represents a report of which datapoints were exported.
	ReportTypeExportDataPointReport ReportType = "ExportDataPointReport"
	// ImportDataPointReport represents a report of which datapoints were imported.
	ReportTypeImportDataPointReport ReportType = "ImportDataPointReport"
	// MissingDataPointReport represents a report of which datapoints were missing when importing / exporting.
	ReportTypeMissingDataPointReport ReportType = "MissingDataPointReport"
	// ReportTypeDataPointThresholdReport represents a report of which data-point thresholds where breached
	ReportTypeDataPointThresholdReport ReportType = "DataPointThresholdReport"
	// ReportTypeCoreTargetDataPointReport is when data-points are transferred into, out from or within the
	// _Thiink Energy OS_ Core services.
	//
	// This report contains both failed and succeeded datapoint transfers along with metadata (info) segment.
	ReportTypeCoreTargetDataPointReport ReportType = "CoreTargetDataPointReport"
	// ReportTypeServiceExecutionReport is a report of a service execution.
	ReportTypeServiceExecutionReport ReportType = "ServiceExecutionReport"
)

// ReportContainer is the interface for the `ReportContainerImpl`
type ReportContainer interface {
	// GetLocationID returns the location ID of the report.
	GetLocationID() string
	// GetProvider returns the provider of the report.
	//
	// NOTE: This may differ from the `ifcore.CbContext.Provider()`!
	GetProvider() string
	// GetProfile returns the profile of the report.
	GetProfile() string
	// GetReportType returns the type of the report.
	GetReportType() ReportType
	// GetError returns a _global_ error for the report.
	GetError() error
	// GetBody returns the body of the report.
	//
	// A ReportContainer is bound to return any of the `Reportable` types.
	GetBody() interface{}
}

// ReportContainer is container for different kinds of reports.
type ReportContainerImpl[T Reportable] struct {
	// LocationID is the location where this report refers to.
	LocationID string `json:"lid"`
	// Provider is the provider reporting this.
	Provider string `json:"pn"`
	// Profile is which profile was used as the origin of this report.
	Profile string `json:"profile,omitempty"`
	// ReportType describes the type of report `Body` is.
	ReportType ReportType `json:"m"`
	// Body is the actual report
	Body T `json:"body"`
	// Error is a global error if any.
	Error error `json:"err,omitempty"`
}

// GetLocationID implements the `ReportContainer` interface.
func (r *ReportContainerImpl[Reportable]) GetLocationID() string {
	return r.LocationID
}

// GetProvider implements the `ReportContainer` interface.
func (r *ReportContainerImpl[Reportable]) GetProvider() string {
	return r.Provider
}

// GetProfile implements the `ReportContainer` interface.
func (r *ReportContainerImpl[Reportable]) GetProfile() string {
	return r.Profile
}

// GetReportType implements the `ReportContainer` interface.
func (r *ReportContainerImpl[Reportable]) GetReportType() ReportType {
	return r.ReportType
}

// GetBody implements the `ReportContainer` interface.
func (r *ReportContainerImpl[Reportable]) GetBody() interface{} {
	return r.Body
}

// GetError implements the `ReportContainer` interface.
func (r *ReportContainerImpl[Reportable]) GetError() error {
	return r.Error
}

// UnmarshalReportContainer unmarshal a report container and makes sure
// that the correct `Body` type is instantiated.
func UnmarshalReportContainer(data []byte) (ReportContainer, error) {
	type Temp struct {
		LocationID string           `json:"lid"`
		Provider   string           `json:"pn"`
		Profile    string           `json:"profile,omitempty"`
		ReportType ReportType       `json:"m"`
		Body       *json.RawMessage `json:"body"`
	}

	var temp Temp
	err := json.Unmarshal(data, &temp)
	if err != nil {
		return nil, err
	}

	switch temp.ReportType {
	case ReportTypeExportDataPointReport:
		var report ExportDataPointReport
		err := json.Unmarshal(*temp.Body, &report)
		return &ReportContainerImpl[ExportDataPointReport]{
			LocationID: temp.LocationID,
			Provider:   temp.Provider,
			Profile:    temp.Profile,
			ReportType: temp.ReportType,
			Body:       report,
		}, err

	case ReportTypeImportDataPointReport:
		var report ImportDataPointReport
		err := json.Unmarshal(*temp.Body, &report)
		return &ReportContainerImpl[ImportDataPointReport]{
			LocationID: temp.LocationID,
			Provider:   temp.Provider,
			Profile:    temp.Profile,
			ReportType: temp.ReportType,
			Body:       report,
		}, err

	case ReportTypeMissingDataPointReport:
		var report MissingDataPointReport
		err := json.Unmarshal(*temp.Body, &report)
		return &ReportContainerImpl[MissingDataPointReport]{
			LocationID: temp.LocationID,
			Provider:   temp.Provider,
			Profile:    temp.Profile,
			ReportType: temp.ReportType,
			Body:       report,
		}, err

	case ReportTypeDataPointThresholdReport:
		var report DataPointThresholdReport
		err := json.Unmarshal(*temp.Body, &report)
		return &ReportContainerImpl[DataPointThresholdReport]{
			LocationID: temp.LocationID,
			Provider:   temp.Provider,
			Profile:    temp.Profile,
			ReportType: temp.ReportType,
			Body:       report,
		}, err

	case ReportTypeCoreTargetDataPointReport:
		var report CoreTargetDataPointReport
		err := json.Unmarshal(*temp.Body, &report)
		return &ReportContainerImpl[CoreTargetDataPointReport]{
			LocationID: temp.LocationID,
			Provider:   temp.Provider,
			Profile:    temp.Profile,
			ReportType: temp.ReportType,
			Body:       report,
		}, err

	case ReportTypeServiceExecutionReport:
		var report ServiceExecutionReport
		err := json.Unmarshal(*temp.Body, &report)
		return &ReportContainerImpl[ServiceExecutionReport]{
			LocationID: temp.LocationID,
			Provider:   temp.Provider,
			Profile:    temp.Profile,
			ReportType: temp.ReportType,
			Body:       report,
		}, err

	default:
		return nil, fmt.Errorf("unknown report type: %s", temp.ReportType)
	}
}
