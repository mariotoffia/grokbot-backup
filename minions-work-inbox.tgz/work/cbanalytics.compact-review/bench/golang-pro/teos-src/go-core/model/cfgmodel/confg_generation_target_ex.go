package cfgmodel

import (
	"maps"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/providermodel"
)

// ConfigGenerationTargetEx extends the `ConfigGenerationTarget` with
// the associated equipment and sensors.
type ConfigGenerationTargetEx struct {
	ConfigGenerationTarget
	// Equipment to be selected with the target
	Equipment *MergedEquipment
	// Sensors to be selected with the target
	Sensors *MergedSensors
	// Services to be selected with the target
	Services *MergedServices
	// Event that triggered the generation
	Event *ConfigMergedEvent
	// ProviderConfig is the found provider configuration for the target.
	//
	// NOTE: This may be `nil` if no provider configuration was found.
	ProviderConfig *providermodel.ProviderConfigImpl
	// Error is set when any error did occur for this target.
	Error cberror.Error
}

// Clone will do a shallow clone of the `ConfigGenerationTarget`.
func (c *ConfigGenerationTarget) Clone() *ConfigGenerationTarget {
	c2 := *c
	c2.Params = maps.Clone(c.Params)

	return &c2
}

type ConfigSection string

const (
	ConfigSectionMapping ConfigSection = "map"
	ConfigSectionParams  ConfigSection = "params"
	ConfigSectionTarget  ConfigSection = "target"
)

type ConfigAction string

const (
	// create specifies if it may create
	ConfigActionCreate ConfigAction = "create"
	// update specifies if it may update
	ConfigActionUpdate ConfigAction = "update"
	// delete specifies if it may delete
	ConfigActionDelete ConfigAction = "delete"
	// access is any action (create or update or delete)
	ConfigActionAccess ConfigAction = "access"
	ConfigActionUpsert ConfigAction = "upsert"
)

// Can
func (target *ConfigGenerationTarget) Can(action ConfigAction, section ConfigSection) bool {
	switch action {
	case ConfigActionUpsert:
		return target.CanCreate(section) || target.CanUpdate(section)
	case ConfigActionAccess:
		return target.CanCreate(section) || target.CanUpdate(section) || target.CanDelete(section)
	case ConfigActionCreate:
		return target.CanCreate(section)
	case ConfigActionUpdate:
		return target.CanUpdate(section)
	case ConfigActionDelete:
		return target.CanDelete(section)
	}

	return false
}

func (target *ConfigGenerationTarget) SectionMode(section ConfigSection) ConfigTargetModes {
	if target == nil || target.Mode == nil {
		return ConfigTargetModeCreateUpdateDelete
	}

	map_or_default := func(mode ConfigTargetModes) ConfigTargetModes {
		if mode == "" {
			return ConfigTargetModeCreateUpdateDelete
		}

		return mode
	}

	switch section {
	case ConfigSectionMapping:
		return map_or_default(target.Mode.Mapping)
	case ConfigSectionParams:
		return map_or_default(target.Mode.Prms)
	}

	return ConfigTargetModeCreateUpdateDelete
}

// CanCreate checks if it has rights to create a entry in a certain
// section.
func (target *ConfigGenerationTarget) CanCreate(section ConfigSection) bool {
	switch section {
	case ConfigSectionMapping:
		return target.HasMappingMode(
			ConfigTargetModeCreateOnly,
			ConfigTargetModeCreateUpdate,
			ConfigTargetModeCreateDelete,
		)
	case ConfigSectionParams:
		return target.HasParamsMode(
			ConfigTargetModeCreateOnly,
			ConfigTargetModeCreateUpdate,
			ConfigTargetModeCreateDelete,
		)
	}

	// ConfigTargetModeCreateDelete
	return true
}

// canUpdate checks if it has rights to update a entry in a certain
// section.
func (target *ConfigGenerationTarget) CanUpdate(section ConfigSection) bool {
	switch section {
	case ConfigSectionMapping:
		return target.HasMappingMode(
			ConfigTargetModeCreateUpdate,
			ConfigTargetModeCreateUpdateDelete,
			ConfigTargetModeUpdateDelete,
			ConfigTargetModeUpdateOnly,
		)
	case ConfigSectionParams:
		return target.HasParamsMode(
			ConfigTargetModeCreateUpdate,
			ConfigTargetModeCreateUpdateDelete,
			ConfigTargetModeUpdateDelete,
			ConfigTargetModeUpdateOnly,
		)
	}

	// ConfigTargetModeCreateDelete
	return true
}

// CanDelete checks if it has rights to delete a entry in a certain
// section.
func (target *ConfigGenerationTarget) CanDelete(section ConfigSection) bool {
	switch section {
	case ConfigSectionMapping:
		return target.HasMappingMode(
			ConfigTargetModeCreateDelete,
			ConfigTargetModeCreateUpdateDelete,
			ConfigTargetModeUpdateDelete,
		)
	case ConfigSectionParams:
		return target.HasParamsMode(
			ConfigTargetModeCreateDelete,
			ConfigTargetModeCreateUpdateDelete,
			ConfigTargetModeUpdateDelete,
		)
	}

	// ConfigTargetModeCreateDelete
	return true
}

// HasMappingMode checks if it has rights to access a mapping with following _modes_.
//
// If none is configured, it will return `true`.
func (target *ConfigGenerationTarget) HasMappingMode(modes ...ConfigTargetModes) bool {
	if target == nil || target.Mode == nil || target.Mode.Mapping == "" {
		return true
	}

	for _, mode := range modes {
		if target.Mode.Mapping == mode {
			return true
		}
	}

	return false
}

// HasParamsMode checks if it has rights to access a mapping with following _modes_.
func (target *ConfigGenerationTarget) HasParamsMode(modes ...ConfigTargetModes) bool {
	if target == nil || target.Mode == nil || target.Mode.Prms == "" {
		return true
	}

	for _, mode := range modes {
		if target.Mode.Prms == mode {
			return true
		}
	}

	return false
}
