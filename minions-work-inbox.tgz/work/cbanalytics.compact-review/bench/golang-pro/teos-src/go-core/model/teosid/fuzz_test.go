package teosid_test

import (
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/teosid"
)

func FuzzParseRenderRoundTrip(f *testing.F) {
	for _, seed := range []string{
		"IDT",
		"HP.ODT_O1",
		"HP.PRIMARY.ODT_C2_ZWEST_ALEVEL1_M03_Tdigital",
	} {
		f.Add(seed)
	}

	f.Fuzz(func(t *testing.T, raw string) {
		identity, err := teosid.Parse(raw)
		if err != nil {
			return
		}

		rendered, err := teosid.Render(teosid.Parts{
			QualifiedID: identity.QualifiedID,
			Ordinal:     identity.Ordinal,
			Circuit:     identity.Circuit,
			Zone:        identity.Zone,
			Area:        identity.Area,
			Tags:        identity.Tags,
		})
		require.NoError(t, err)
		require.Equal(t, identity.Canonical, rendered)

		reparsed, err := teosid.Parse(rendered)
		require.NoError(t, err)
		require.Equal(t, identity.Canonical, reparsed.Canonical)
	})
}
