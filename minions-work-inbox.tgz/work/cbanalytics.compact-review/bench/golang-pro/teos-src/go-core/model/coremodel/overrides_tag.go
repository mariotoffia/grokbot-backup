package coremodel

import "strings"

// IsValueMatch will check if _value_ matches the `Tag.Value` fields.
// It will first make sure that the _name_ matches the `Tag.Name` field.
// Then, if `Tag.TagValueSeparator` is set, it will split the value
// on that and check if any of the values match.
//
// TIP: This function is useful when e.g. loaded a tag from _AWS_ and
// want to check if it matches.
func (t Tag) IsMatch(name, value string) bool {
	if t.Name != name {
		return false
	}

	if t.Separator != "" {
		for _, v := range strings.Split(value, t.Separator) {
			if v == t.Value {
				return true
			}
		}

		return false
	}

	return t.Value == value
}
