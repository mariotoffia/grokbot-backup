package teosid

import (
	"sort"
	"strconv"
	"strings"
)

// Render validates parts and returns their canonical TEOS identifier.
func Render(parts Parts) (string, error) {
	if _, err := parseBase(parts.QualifiedID); err != nil {
		return "", err
	}
	if parts.Ordinal != nil && *parts.Ordinal < 0 {
		return "", parseError("invalid_number", 0)
	}
	if parts.Circuit != nil && *parts.Circuit < 0 {
		return "", parseError("invalid_number", 0)
	}
	if parts.Zone != nil && *parts.Zone == "" {
		return "", parseError("empty_value", 0)
	}
	if parts.Area != nil && *parts.Area == "" {
		return "", parseError("empty_value", 0)
	}

	var builder strings.Builder
	builder.WriteString(parts.QualifiedID)
	writeNumber := func(key byte, value *int) {
		if value == nil {
			return
		}
		builder.WriteByte('_')
		builder.WriteByte(key)
		builder.WriteString(strconv.Itoa(*value))
	}
	writeString := func(key byte, value *string) error {
		if value == nil {
			return nil
		}
		if strings.ContainsRune(*value, '_') {
			return parseError("invalid_value", 0)
		}
		builder.WriteByte('_')
		builder.WriteByte(key)
		builder.WriteString(*value)
		return nil
	}

	writeNumber('O', parts.Ordinal)
	writeNumber('C', parts.Circuit)
	if err := writeString('Z', parts.Zone); err != nil {
		return "", err
	}
	if err := writeString('A', parts.Area); err != nil {
		return "", err
	}

	keys := make([]string, 0, len(parts.Tags))
	for key, value := range parts.Tags {
		if len(key) != 1 || key[0] < 'A' || key[0] > 'Z' || dimensionOrder(key[0]) != 0 {
			return "", parseError("invalid_tag", 0)
		}
		if value == "" {
			return "", parseError("empty_value", 0)
		}
		if strings.ContainsRune(value, '_') {
			return "", parseError("invalid_value", 0)
		}
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		builder.WriteByte('_')
		builder.WriteString(key)
		builder.WriteString(parts.Tags[key])
	}
	return builder.String(), nil
}
