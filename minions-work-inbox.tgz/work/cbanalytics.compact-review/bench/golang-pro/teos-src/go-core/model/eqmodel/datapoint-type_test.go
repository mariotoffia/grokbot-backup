package eqmodel

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

type datapoint struct {
}

func (dp *datapoint) GetID() string {
	return "id"
}
func (dp *datapoint) GetValue() any {
	return 0
}
func (dp *datapoint) GetPartition() string {
	return "partition"
}
func (dp *datapoint) HasTimeStamp() bool {
	return false
}
func (dp *datapoint) GetTimeStamp() coremodel.CbTime32 {
	return *coremodel.NewZeroTime32()
}
func (dp *datapoint) GetError() cberror.Error {
	return nil
}

func TestCastSliceOfPtrStructToCbDataPointSlice(t *testing.T) {
	c := ToCbDataPointSlice([]*datapoint{{}, {}, {}})
	assert.Equal(t, 3, len(c))
}

func TestCastMapOfPtrStructToCbDataPointSlice(t *testing.T) {
	c := ToCbDataPointSliceFromMap(map[string]*datapoint{"1": {}, "2": {}, "3": {}})
	assert.Equal(t, 3, len(c))
	assert.Equal(t, "id", c[0].GetID())
	assert.Equal(t, "id", c[1].GetID())
	assert.Equal(t, "id", c[2].GetID())
}

func TestCastSliceOfPtrStructToCbDataPointSliceDynamic(t *testing.T) {
	c, err := ToCbDataPointSliceDynamic([]*datapoint{{}, {}, {}})
	assert.Equal(t, nil, err)
	assert.Equal(t, 3, len(c))
}

func TestCastSliceOfStructToCbDataPointSliceDynamic(t *testing.T) {
	c, err := ToCbDataPointSliceDynamic([]datapoint{{}, {}, {}})
	assert.Equal(t, nil, err)
	assert.Equal(t, 3, len(c))
}

func BenchmarkCastSliceOfPtrStructToCbDataPointSlice(t *testing.B) {
	dp := []*datapoint{{}, {}, {}}
	for i := 0; i < t.N; i++ {
		ToCbDataPointSlice(dp)
	}
}

func BenchmarkCbDataPointSliceToCbDataPointSliceDynamic(t *testing.B) {
	dp := []CbDataPoint{&CbDataPointImpl{}, &CbDataPointImpl{}, &CbDataPointImpl{}}
	for i := 0; i < t.N; i++ {
		_, _ = ToCbDataPointSliceDynamic(dp)
	}
}

func BenchmarkCbDataPointImplArrayToCbDataPointSliceDynamic(t *testing.B) {
	dp := []*CbDataPointImpl{{}, {}, {}}
	for i := 0; i < t.N; i++ {
		_, _ = ToCbDataPointSliceDynamic(dp)
	}
}

func BenchmarkCastSliceOfPtrStructToCbDataPointSliceDynamic(t *testing.B) {
	dp := []*datapoint{{}, {}, {}}
	for i := 0; i < t.N; i++ {
		_, _ = ToCbDataPointSliceDynamic(dp)
	}
}

func BenchmarkCastSliceOfStructToCbDataPointSliceDynamic(t *testing.B) {
	dp := []datapoint{{}, {}, {}}
	for i := 0; i < t.N; i++ {
		_, _ = ToCbDataPointSliceDynamic(dp)
	}
}
