package cfgmodel

import (
	"slices"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

const DummyEquipmentID = "DUMMY"

// EquipmentWithSensors is a return struct used in `GetEquipmentWithSensors` and
// should not be used anywhere else.
type EquipmentWithSensors struct {
	// Equipment (if non sensor bound equipment)
	//
	// NOTE: When `eqmodel.InstalledEquipment.TeosID` is `DummyEquipmentID`, it is a DummyEquipmentID equipment
	// and hence properties should not be used except for `eqmodel.InstalledEquipment.EquipmentID`,
	// `eqmodel.InstalledEquipment.LocationID`, and `eqmodel.InstalledEquipment.ProviderName`.
	//
	// The _DummyEquipmentID_ equipment is always a notchanged equipment.
	Equipment *MergedEquipment
	// Sensors bound to this equipment.
	Sensors *MergedSensors
}

// HasSensorChanges checks if there where any changes in the sensors
func (c *ConfigMergedEvent) HasSensorChanges() bool {
	return c.Sensors != nil && (len(c.Sensors.Added) > 0 || len(c.Sensors.Deleted) > 0 ||
		len(c.Sensors.Updated) > 0)
}

// HasEquipmentChanges checks if there where any changes in the equipment
func (c *ConfigMergedEvent) HasEquipmentChanges() bool {
	return c.Equipment != nil && (len(c.Equipment.Added) > 0 || len(c.Equipment.Deleted) > 0 ||
		len(c.Equipment.Updated) > 0)
}

// HasServiceChanges checks if there where any changes in the services
func (c *ConfigMergedEvent) HasServiceChanges() bool {
	return c.Services != nil && (len(c.Services.Added) > 0 || len(c.Services.Deleted) > 0 ||
		len(c.Services.Updated) > 0)
}

// DetachedSensorEquipmentIDs returns all sensors that have a equipment ID that is not
// present in the event. Hence, they are "detached" sensors.
func (c *ConfigMergedEvent) DetachedSensorEquipmentIDs() []string {
	if c.Sensors == nil {
		return nil
	}

	id := map[string]bool{}
	var eqLength int

	if c.Equipment != nil {
		eqLength = len(c.Equipment.Added) + len(c.Equipment.Updated) +
			len(c.Equipment.Deleted) + len(c.Equipment.Notchanged)
	}

	equipments := make([]string, eqLength)

	if c.Equipment != nil {
		for i := range c.Equipment.Added {
			equipments[i] = c.Equipment.Added[i].PlainEquipmentID()
		}

		for i := range c.Equipment.Deleted {
			equipments[i] = c.Equipment.Deleted[i].PlainEquipmentID()
		}

		for i := range c.Equipment.Updated {
			equipments[i] = c.Equipment.Updated[i].PlainEquipmentID()
		}

		for i := range c.Equipment.Notchanged {
			equipments[i] = c.Equipment.Notchanged[i].PlainEquipmentID()
		}
	}

	for i := range c.Sensors.Added {
		if !slices.Contains(equipments, c.Sensors.Added[i].EquipmentID) {
			id[c.Sensors.Added[i].EquipmentID] = true
		}
	}

	for i := range c.Sensors.Deleted {
		if !slices.Contains(equipments, c.Sensors.Deleted[i].EquipmentID) {
			id[c.Sensors.Deleted[i].EquipmentID] = true
		}
	}

	for i := range c.Sensors.Updated {
		if !slices.Contains(equipments, c.Sensors.Updated[i].EquipmentID) {
			id[c.Sensors.Updated[i].EquipmentID] = true
		}
	}

	for i := range c.Sensors.Notchanged {
		if !slices.Contains(equipments, c.Sensors.Notchanged[i].EquipmentID) {
			id[c.Sensors.Notchanged[i].EquipmentID] = true
		}
	}

	res := make([]string, len(id))
	i := 0

	for k := range id {
		res[i] = k
		i++
	}

	return res
}

// GetEquipmentWithSensors will return all equipments with sensors for the given
// equipment IDs. If omitted, it will take all equipments including creating a `DummyEquipmentID` equipment
// for sensors that are bound to a equipment but was not found in the event.
//
// NOTE: The _DUMMY_ equipment should not be used in any way or form.
//
// It is possible to detect if it is a `DummyEquipmentID` equipment by checking _TeosID_
// if it is _DummyEquipmentID_.
func (c *ConfigMergedEvent) GetEquipmentWithSensors(eqID ...string) []EquipmentWithSensors {
	var (
		eqs []EquipmentWithSensors
		id  []string
	)

	if len(eqID) == 0 {
		id = c.Equipment.AllEquipmentIDs()
	} else {
		id = eqID
	}

	for _, eq := range id {
		equipment := c.Equipment.Equipments(eq)
		sensor := c.Sensors.SensorsForEquipment(eq)

		eqs = append(eqs, EquipmentWithSensors{
			Equipment: equipment,
			Sensors:   sensor,
		})
	}

	if len(eqID) > 0 {
		return eqs
	}

	// Check if there are any sensor referencing a equipment ID that is not
	// present here. If so, create a _DummyEquipmentID_ equipment for it.
	detached := c.DetachedSensorEquipmentIDs()

	if len(detached) == 0 {
		return eqs
	}

	for _, eq := range detached {
		sensors := c.Sensors.SensorsForEquipment(eq)
		sensor := sensors.First()

		eqs = append(eqs, EquipmentWithSensors{
			Equipment: &MergedEquipment{
				Notchanged: []eqmodel.InstalledEquipment{
					{
						LocationID:   sensor.LocationID,
						OwnerID:      sensor.OwnerID,
						ProviderName: sensor.ProviderName,
						EquipmentID:  sensor.EquipmentID,
						TeosID:       DummyEquipmentID,
					}},
			},
			Sensors: sensors,
		})
	}

	return eqs
}
