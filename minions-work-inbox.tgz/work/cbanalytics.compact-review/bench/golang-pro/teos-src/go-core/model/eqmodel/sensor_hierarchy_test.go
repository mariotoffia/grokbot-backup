package eqmodel_test

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

func TestHierarchyPath(t *testing.T) {
	tests := []struct {
		SID  eqmodel.SensorType
		Path string
	}{
		{"IDT", ""},
		{"IDT_O1", ""},
		{"INDOOR.TEMP", "INDOOR"},
		{"INDOOR.TEMP_O1", "INDOOR"},
		{"A.B.C", "A.B"},
		{"A.B.C_O1_C2", "A.B"},
		{"INVERTER.L1", "INVERTER"},
	}

	for _, tc := range tests {
		assert.Equal(t, tc.Path, tc.SID.HierarchyPath(), "HierarchyPath for %s", tc.SID)
	}
}

func TestHierarchyLeaf(t *testing.T) {
	tests := []struct {
		SID  eqmodel.SensorType
		Leaf string
	}{
		{"IDT", "IDT"},
		{"IDT_O1", "IDT"},
		{"INDOOR.TEMP", "TEMP"},
		{"INDOOR.TEMP_O1", "TEMP"},
		{"A.B.C", "C"},
		{"A.B.C_O1_C2", "C"},
		{"INVERTER.L1", "L1"},
	}

	for _, tc := range tests {
		assert.Equal(t, tc.Leaf, tc.SID.HierarchyLeaf(), "HierarchyLeaf for %s", tc.SID)
	}
}

func TestHierarchyDepth(t *testing.T) {
	tests := []struct {
		SID   eqmodel.SensorType
		Depth int
	}{
		{"IDT", 1},
		{"IDT_O1", 1},
		{"INDOOR.TEMP", 2},
		{"INDOOR.TEMP_O1", 2},
		{"A.B.C", 3},
		{"A.B.C_O1_C2", 3},
	}

	for _, tc := range tests {
		assert.Equal(t, tc.Depth, tc.SID.HierarchyDepth(), "HierarchyDepth for %s", tc.SID)
	}
}

func TestAreaString(t *testing.T) {
	tests := []struct {
		SID  eqmodel.SensorType
		Area string
	}{
		{"IDT", ""},
		{"IDT_Awest", "west"},
		{"IDT_O1_C2_Awest", "west"},
		{"IDT_O1_C2_ZNorth_Awest", "west"},
		{"IDT_O1_C2_ZNorth_Awest_M3M", "west"},
		{"INDOOR.TEMP_Awest", "west"},
	}

	for _, tc := range tests {
		assert.Equal(t, tc.Area, tc.SID.AreaString(), "AreaString for %s", tc.SID)
	}
}

func TestZoneStringWithSubsequentTags(t *testing.T) {
	tests := []struct {
		SID  eqmodel.SensorType
		Zone string
	}{
		{"IDT_ZRoom1", "Room1"},
		{"IDT_ZRoom1_Awest", "Room1"},
		{"IDT_ZRoom1_M3M", "Room1"},
		{"IDT_O1_C2_ZNorth_Awest_M3M", "North"},
		{"INDOOR.TEMP_ZFloor2", "Floor2"},
	}

	for _, tc := range tests {
		assert.Equal(t, tc.Zone, tc.SID.ZoneString(), "ZoneString for %s", tc.SID)
	}
}

func BenchmarkHierarchicalSensorParsing(t *testing.B) {
	s := eqmodel.SensorType("INDOOR.TEMP_O1_C2_ZNorth")

	for i := 0; i < t.N; i++ {
		s.Validate()
	}
}

func BenchmarkFlatSensorParsing(t *testing.B) {
	s := eqmodel.SensorType("IDT_O1_C2")

	for i := 0; i < t.N; i++ {
		s.Validate()
	}
}
