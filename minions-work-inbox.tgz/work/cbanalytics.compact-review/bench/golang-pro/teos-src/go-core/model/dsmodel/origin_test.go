package dsmodel_test

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/dsmodel"
)

// TestOriginRoundTrips decodes a copied update the way the eastbound
// dispatcher decodes its queue messages, and encodes it again.
func TestOriginRoundTrips(t *testing.T) {
	copied := []byte(`{
		"state": {"desired": {"sensors": {"OFFODT": 1.47}}},
		"clientToken": "corerouter:abc:mirror:outbound",
		"origin": "climatecontrol:xyz:cc-evt:outbound",
		"topic": "$aws/things/building-1/shadow/name/building/update/accepted"
	}`)

	var evt dsmodel.DsFullBuilding
	require.NoError(t, json.Unmarshal(copied, &evt))

	assert.Equal(t, dsmodel.ClientToken("climatecontrol:xyz:cc-evt:outbound"), evt.Origin)
	assert.Equal(t, "corerouter:abc:mirror:outbound", evt.ClientToken)

	encoded, err := json.Marshal(&evt)
	require.NoError(t, err)

	var again dsmodel.DsFullBuilding
	require.NoError(t, json.Unmarshal(encoded, &again))
	assert.Equal(t, evt.Origin, again.Origin)
}

// TestOriginIsOmittedWhenEmpty checks that an update that is not a copy is
// encoded without an origin field.
func TestOriginIsOmittedWhenEmpty(t *testing.T) {
	evt := dsmodel.DsFullBuilding{
		DsBase: dsmodel.DsBase{ClientToken: "climatecontrol:xyz:cc-evt:outbound"},
	}

	encoded, err := json.Marshal(&evt)
	require.NoError(t, err)

	var fields map[string]any
	require.NoError(t, json.Unmarshal(encoded, &fields))
	assert.NotContains(t, fields, "origin")
	assert.Contains(t, fields, "clientToken")
}
