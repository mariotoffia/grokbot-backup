package coremodel

import (
	"crypto/sha256"
	"strconv"
	"unicode"

	"github.com/google/uuid"
)

// IdPrefix is a type that is used to specify a prefix for a generated UUID.
type IdPrefix int8

const (
	// IdPrefixAPI is a prefix for API related UUIDs.
	IdPrefixAPI IdPrefix = 1
	// IdPrefixRemotePartition is a remote (provider) partition identifier.
	IdPrefixRemotePartition IdPrefix = 2
	// IdPrefixRemoteResourceName is a remote (provider) resource name identifier.
	IdPrefixRemoteResourceName IdPrefix = 3
	// IdPrefixTeosID is a prefix for Teos IDs such as _IDT_, _ODT_ etc.
	IdPrefixTeosID IdPrefix = 4
)

// NameId is when you need to specify either a name or an ID (or both).
//
// This is when an API supports both named and ID based references.
//
// It may also distinguish if the `Id` is a _UUID_ or a numeric _ID_.
type NameId struct {
	// Name is the plain name of the resource.
	Name string `json:"name,omitempty"`
	// Id is the ID of the resource. This is completely handled by the API.
	//
	// A local UUID from Name exists as `ToUUID()` where it uses a hash of the name.
	Id string `json:"id,omitempty"`
}

// GetUUIDThenId tries to return the `Id` field if set, otherwise it will return the `Name` field.
// If neither is set, it will return an empty string.
func (n *NameId) GetIdThenName() string {
	if n.HasId() {
		return n.Id
	}

	return n.Name
}

// GetIdThenName tries to return the `Name` field if set, otherwise it will return the `Id` field.
// If neither is set, it will return an empty string.
func (n *NameId) GetNameThenId() string {
	if n.HasName() {
		return n.Name
	}

	return n.Id
}

// IsIdUUID checks if the `Id` field is set and is a valid _UUID_.
func (n *NameId) IsIdUUID() bool {
	if !n.HasId() {
		return false
	}

	_, err := uuid.Parse(n.Id)

	return err == nil
}

// IsIdNumeric checks if the `Id` field is set and is a numeric value.
//
// It allows - and + signs in the beginning and one fractional divider (.) in the middle.
func (n *NameId) IsIdNumeric() bool {
	if !n.HasId() {
		return false
	}

	// Unknown
	if len(n.Id) == 0 {
		return false
	}

	check := n.Id
	if n.Id[0] == '-' || n.Id[0] == '+' {
		check = n.Id[1:]
	}

	divider := 0

	for _, r := range check {
		if r == '.' {
			divider++

			// Only one divider allowed
			if divider > 1 {
				return false
			}

			continue
		}

		if !unicode.IsDigit(r) {
			return false
		}
	}

	return true
}

// IsIdDigitsOnly checks if the `Id` field is set and only contains digits.
func (n *NameId) IsIdDigitsOnly() bool {
	if !n.HasId() {
		return false
	}

	for _, r := range n.Id {
		if !unicode.IsDigit(r) {
			return false
		}
	}

	return true
}

// HasIdOrName returns `true` if either the `Id` or `Name` property is set.
func (n *NameId) HasIdOrName() bool {
	return n.HasId() || n.HasName()
}

// HasId returns `true` if the `Id` property is set.
func (n *NameId) HasId() bool {
	return n.Id != ""
}

// HasOnlyId returns `true` if the `Id` property is set and the `Name` property is not set.
func (n *NameId) HasOnlyId() bool {
	return n.Id != "" && n.Name == ""
}

// HasName returns `true` if the `Name` property is set.
func (n *NameId) HasName() bool {
	return n.Name != ""
}

// HasOnlyId returns `true` if the `Id` property is set and the `Name` property is not set.
func (n *NameId) HasOnlyName() bool {
	return n.Name != "" && n.Id == ""
}

// IdToInt tries to convert the `Id` property to an integer.
// If it fails, it will return `false`.
func (n *NameId) IdToInt() (int64, bool) {
	if !n.HasId() {
		return 0, false
	}

	if i, err := strconv.ParseInt(n.Id, 10, 64); err != nil {
		return 0, false
	} else {
		return i, true
	}
}

// String returns a string representation of the `NameId`.
func (n *NameId) String() string {
	switch {
	case n.Id != "" && n.Name != "":
		return n.Name + " (" + n.Id + ")"
	case n.Id != "":
		return n.Id
	case n.Name != "":
		return n.Name
	}

	return ""
}

// ToUUID creates a copy of the NameOrId but also sets the `Id` property to a generated
// _UUID_ from the `Name` property.
//
// An optional `prefix` parameter is used to replace the first 8 bits of the UUID with the given
// value. This is useful when you need to generate a UUID that is unique within a certain
// context.
// tag::ToUUID[]
func (n *NameId) ToUUID(prefix ...IdPrefix) *NameId {
	// Step 1: Generate SHA256 hash of the string
	hasher := sha256.New()
	hasher.Write([]byte(n.Name))
	hash := hasher.Sum(nil)

	// Step 2: Construct a UUID from the hash
	// UUIDs are 128-bit -> use the first 16 bytes of the hash
	u, _ := uuid.FromBytes(hash[:16])

	if len(prefix) == 1 {
		// Step 3: Replace the first 8 bits of the UUID with the seed
		// Convert the UUID to a byte slice
		uBytes := u[:]
		uBytes[0] = byte(prefix[0]) //nolint:gosec // G115: intentional int8→byte for UUID prefix encoding

		// Convert the modified byte slice back to a UUID
		u, _ = uuid.FromBytes(uBytes)
	}

	return &NameId{
		Name: n.Name,
		Id:   u.String(),
	}
}

// end::ToUUID[]

// IdPrefixType tries to detect the type of the ID prefix.
//
// This is a *not* deterministic function since it will only examine the first
// 8 bits of the UUID and just return the type from that.
func (n *NameId) IdPrefixType() IdPrefix {
	if len(n.Id) == 0 {
		return 0
	}

	// Convert the UUID to a byte slice
	u, _ := uuid.Parse(n.Id)
	uBytes := u[:]

	return IdPrefix(uBytes[0]) //nolint:gosec // G115: intentional byte→int8 for UUID prefix decoding
}
