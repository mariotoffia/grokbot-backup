package securitymodel

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestWithTimeWorksProperlyEvenWhenNotIncluded(t *testing.T) {
	var oidc OpenIDConnectToken

	err := json.Unmarshal(
		[]byte(`{"exp":1516239022, "iat":1516239022}`), &oidc,
	)

	require.Equal(t, nil, err)
	assert.Equal(t, "2018-01-18 01:30:22 +0000 UTC", oidc.Expires.UTC().String())
	assert.Equal(t, "2018-01-18 01:30:22 +0000 UTC", oidc.Issued.UTC().String())
	assert.Equal(t, true, oidc.NotBefore.IsZero())

}

func TestTimeSpecifiedAsStringShallWork(t *testing.T) {
	var oidc OpenIDConnectToken

	err := json.Unmarshal(
		[]byte(`{"exp":"1516239022", "iat":1516239022}`), &oidc,
	)

	require.Equal(t, nil, err)
	assert.Equal(t, "2018-01-18 01:30:22 +0000 UTC", oidc.Expires.UTC().String())
	assert.Equal(t, "2018-01-18 01:30:22 +0000 UTC", oidc.Issued.UTC().String())
	assert.Equal(t, true, oidc.NotBefore.IsZero())

}

func TestUnmarshalStringArrayAudienceShallWork(t *testing.T) {
	var oidc OpenIDConnectToken

	err := json.Unmarshal(
		[]byte(`{"aud":["a", "b"]}`), &oidc,
	)

	require.Equal(t, nil, err)
	assert.Equal(t, 2, len(oidc.Audience))
	assert.Equal(t, "a", oidc.Audience[0])
	assert.Equal(t, "b", oidc.Audience[1])

}

func TestUnmarshalStringAudienceShallWork(t *testing.T) {
	var oidc OpenIDConnectToken

	err := json.Unmarshal(
		[]byte(`{"aud":"a"}`), &oidc,
	)

	require.Equal(t, nil, err)
	assert.Equal(t, 1, len(oidc.Audience))
	assert.Equal(t, "a", oidc.Audience[0])

}

func TestMarshalAudienceIsStringArrayByDefault(t *testing.T) {
	oidc := OpenIDConnectToken{
		Audience: []string{"hej"},
	}

	data, err := json.Marshal(&oidc)
	require.Equal(t, nil, err)
	assert.Equal(t, `{"aud":["hej"]}`, string(data))
}

func TestMarshalAudienceIsStringWhenConfiguredRenderSingleAudienceIfSingle(t *testing.T) {
	oidc := OpenIDConnectToken{
		Config:   OpenIDConnectTokenConfig{RenderSingleAudienceIfSingle: true},
		Audience: []string{"hej"},
	}

	data, err := json.Marshal(&oidc)
	require.Equal(t, nil, err)
	assert.Equal(t, `{"aud":"hej"}`, string(data))
}

func TestOneScopeAndOneScopeClaimAsBoolDefault(t *testing.T) {
	token := []byte(`{"scope": "test-scope teos/c-admin"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.Equal(t, nil, err)

	assert.Equal(t, true, oidc.HasScope("test-scope"))

	admin, _ := oidc.ClaimAsBool("admin")
	assert.Equal(t, true, admin)
}

func TestTwoScopesAndOneScopeClaim(t *testing.T) {
	token := []byte(`{"scope": "test-scope scope::rw:2 teos/c-admin:false"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.Equal(t, nil, err)

	assert.Equal(t, true, oidc.HasScope("test-scope"))
	assert.Equal(t, true, oidc.HasScope("scope::rw:2"))

	admin, ok := oidc.ClaimAsBool("admin")
	assert.Equal(t, true, ok)
	assert.Equal(t, false, admin)
}

func TestBooleanScopeClaims(t *testing.T) {
	token := []byte(`{"scope": "teos/c-admin:false teos/c-admin1:true teos/c-admin2"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.Equal(t, nil, err)

	admin, ok := oidc.ClaimAsBool("admin")
	admin1, ok1 := oidc.ClaimAsBool("admin1")
	admin2, ok2 := oidc.ClaimAsBool("admin2")

	assert.Equal(t, true, ok)
	assert.Equal(t, true, ok1)
	assert.Equal(t, true, ok2)
	assert.Equal(t, false, admin)
	assert.Equal(t, true, admin1)
	assert.Equal(t, true, admin2)
}

func TestInt64ScopeClaims(t *testing.T) {
	token := []byte(`{"scope": "teos/c-admin:1234"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.Equal(t, nil, err)

	admin, ok := oidc.ClaimAsInt64("admin")
	assert.Equal(t, true, ok)
	assert.Equal(t, int64(1234), admin)
}

func TestScalarStringScopeClaims(t *testing.T) {
	token := []byte(`{"scope": "teos/c-admin:abba"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.Equal(t, nil, err)

	admin, ok := oidc.ClaimAsString("admin")
	assert.Equal(t, true, ok)
	assert.Equal(t, "abba", admin)
}

func TestStringWithCommaWillBeSliceScopeClaims(t *testing.T) {
	token := []byte(`{"scope": "teos/c-admin:abba,finntroll"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.Equal(t, nil, err)

	admin, ok := oidc.ClaimsAsStringSlice("admin")
	assert.Equal(t, true, ok)
	assert.Equal(t, 2, len(admin))
	assert.Contains(t, admin, "abba")
	assert.Contains(t, admin, "finntroll")
}

func TestUnmarshalMap_StructuredAct_ParsesIntoActor(t *testing.T) {
	token := []byte(`{"sub":"user-1","act":{"iss":"https://idp.example.com","sub":"admin-42","client_id":"spa-app"}}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.NotNil(t, oidc.Actor, "Actor must be populated from structured act claim")
	assert.Equal(t, "https://idp.example.com", oidc.Actor.Issuer)
	assert.Equal(t, "admin-42", oidc.Actor.Subject)
	assert.Equal(t, "spa-app", oidc.Actor.Claims["client_id"])
	// act must NOT appear in the generic Claims map
	_, found := oidc.Claims["act"]
	assert.False(t, found, "structured act must not leak into Claims map")
}

func TestUnmarshalMap_StringAct_StoresInClaims(t *testing.T) {
	token := []byte(`{"sub":"user-1","act":"admin"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	assert.Nil(t, oidc.Actor, "string act must NOT be parsed as RFC 8693 Actor")
	assert.Equal(t, "admin", oidc.Claims["act"], "string act must be stored in Claims map")
}

func TestMarshalUnmarshal_ActRoundTrip(t *testing.T) {
	original := OpenIDConnectToken{
		Subject: "user-1",
		Actor: &Actor{
			Issuer:  "https://idp.example.com",
			Subject: "delegate-99",
			Claims:  map[string]any{"client_id": "my-app"},
		},
		Claims: map[string]any{},
	}

	data, err := json.Marshal(&original)
	require.NoError(t, err)

	var restored OpenIDConnectToken
	err = json.Unmarshal(data, &restored)
	require.NoError(t, err)

	require.NotNil(t, restored.Actor)
	assert.Equal(t, original.Actor.Issuer, restored.Actor.Issuer)
	assert.Equal(t, original.Actor.Subject, restored.Actor.Subject)
	assert.Equal(t, original.Actor.Claims["client_id"], restored.Actor.Claims["client_id"])
}

func TestUnmarshalMap_OID_DirectStringClaim(t *testing.T) {
	token := []byte(`{"sub":"user-1","oid":"acme"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 1)
	assert.Equal(t, "acme", oidc.OID[0])
	assert.True(t, oidc.HasOID("acme"))
	assert.False(t, oidc.HasOID("other"))
	assert.Equal(t, "acme", oidc.PrimaryOID())
	// Must not leak into generic Claims
	_, found := oidc.Claims["oid"]
	assert.False(t, found, "oid must not appear in Claims map")
}

// API Gateway on AWS passes the oid list claim as one string. UnmarshalMap
// splits it the way it splits rsid.
func TestUnmarshalMap_OID_ListAsOneString(t *testing.T) {
	tests := []struct {
		name   string
		claims string
	}{
		{name: "comma-separated", claims: `{"sub":"user-1","oid":"acme,globex"}`},
		{name: "space-separated", claims: `{"sub":"user-1","oid":"acme globex"}`},
		{name: "in brackets", claims: `{"sub":"user-1","oid":"[acme globex]"}`},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var oidc OpenIDConnectToken
			require.NoError(t, json.Unmarshal([]byte(tt.claims), &oidc))

			assert.Equal(t, []string{"acme", "globex"}, oidc.OID)
		})
	}
}

// The rsid list claim reads the same from one bracketed string as from a list.
func TestUnmarshalMap_RSID_ListAsOneBracketedString(t *testing.T) {
	var oidc OpenIDConnectToken
	require.NoError(t, json.Unmarshal([]byte(`{"sub":"user-1","rsid":"[site-a site-b]"}`), &oidc))

	assert.Equal(t, "site-a,site-b", oidc.RemoteSystemID)
}

func TestUnmarshalMap_OID_DirectArrayClaim(t *testing.T) {
	token := []byte(`{"sub":"user-1","oid":["acme","globex"]}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 2)
	assert.Equal(t, "acme", oidc.OID[0])
	assert.Equal(t, "globex", oidc.OID[1])
	assert.True(t, oidc.HasOID("acme"))
	assert.True(t, oidc.HasOID("globex"))
	assert.Equal(t, "acme", oidc.PrimaryOID())
}

func TestUnmarshalMap_OID_ScopeEncoded_SingleValue(t *testing.T) {
	// M2M token: OID comes through scope-encoded teos/c-oid:<value>
	token := []byte(`{"scope": "teos/c-oid:thiink teos/building-read"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 1)
	assert.Equal(t, "thiink", oidc.OID[0])
	assert.True(t, oidc.HasOID("thiink"))
	assert.Equal(t, "thiink", oidc.PrimaryOID())
}

func TestUnmarshalMap_OID_ScopeEncoded_MultiValue(t *testing.T) {
	// M2M token: multiple OIDs scope-encoded as comma-separated
	token := []byte(`{"scope": "teos/c-oid:thiink,acme teos/building-read"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 2)
	assert.Contains(t, oidc.OID, "thiink")
	assert.Contains(t, oidc.OID, "acme")
}

func TestPrimaryOID_Empty_ReturnsEmptyString(t *testing.T) {
	oidc := OpenIDConnectToken{}
	assert.Equal(t, "", oidc.PrimaryOID())
	assert.False(t, oidc.HasOID("anything"))
}

func TestUnmarshalMap_OID_DirectClaimTakesPrecedenceOverScope(t *testing.T) {
	// When both a direct "oid" claim and scope-encoded teos/c-oid exist,
	// the direct claim must win regardless of map iteration order.
	token := []byte(`{"oid":"direct-org","scope":"teos/c-oid:scope-org teos/building-read"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 1)
	assert.Equal(t, "direct-org", oidc.OID[0],
		"direct claim must take precedence over scope-encoded OID")
}

func TestMarshalUnmarshal_OID_RoundTrip(t *testing.T) {
	original := OpenIDConnectToken{
		Subject: "user-1",
		OID:     []string{"acme", "globex"},
		Claims:  map[string]any{},
	}

	data, err := json.Marshal(&original)
	require.NoError(t, err)

	var restored OpenIDConnectToken
	err = json.Unmarshal(data, &restored)
	require.NoError(t, err)

	require.Len(t, restored.OID, 2)
	assert.Equal(t, "acme", restored.OID[0])
	assert.Equal(t, "globex", restored.OID[1])
}

// ---------------------------------------------------------------------------
// OID edge cases - scope-encoded parsing boundaries
// ---------------------------------------------------------------------------

// TestUnmarshalMap_OID_ScopeEncoded_TrailingColon validates that a scope entry
// "teos/c-oid:" (colon with no value) produces OID = [""] - an empty-string
// element. The parser does not reject this at parse time; validation is
// deferred to domain-layer callers (e.g. ValidateOID).
//
// teos/c-oid: → split("oid:") → kv=["oid",""] → OID=[""]
func TestUnmarshalMap_OID_ScopeEncoded_TrailingColon(t *testing.T) {
	token := []byte(`{"scope": "teos/c-oid: teos/building-read"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	// "teos/c-oid:" splits on ":" producing kv=["oid",""].
	// The empty string value is stored as-is.
	require.Len(t, oidc.OID, 1)
	assert.Equal(t, "", oidc.OID[0])
	assert.Equal(t, "teos/building-read", oidc.Scope)
}

// TestUnmarshalMap_OID_ScopeEncoded_SpecialChars validates that special
// characters (including '#') in scope-encoded OID values pass through without
// parse-time validation. The '#' character is only rejected by domain.ValidateOID.
//
// teos/c-oid:evil#inject → OID=["evil#inject"]
func TestUnmarshalMap_OID_ScopeEncoded_SpecialChars(t *testing.T) {
	token := []byte(`{"scope": "teos/c-oid:evil#inject teos/building-read"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 1)
	assert.Equal(t, "evil#inject", oidc.OID[0])
	assert.True(t, oidc.HasOID("evil#inject"))
	assert.Equal(t, "teos/building-read", oidc.Scope)
}

// TestUnmarshalMap_OID_ScopeEncoded_OnlyClaimScope validates that when the
// scope string contains ONLY a teos/c-oid entry, the resulting Scope field
// is empty and the OID is still extracted correctly.
func TestUnmarshalMap_OID_ScopeEncoded_OnlyClaimScope(t *testing.T) {
	token := []byte(`{"scope": "teos/c-oid:thiink"}`)

	var oidc OpenIDConnectToken
	err := json.Unmarshal(token, &oidc)
	require.NoError(t, err)

	require.Len(t, oidc.OID, 1)
	assert.Equal(t, "thiink", oidc.OID[0])
	assert.Equal(t, "", oidc.Scope, "scope must be empty after extracting claim")
}

// TestPrimaryOID_EmptySlice_BehavesSameAsNil validates that []string{} (empty
// slice) behaves identically to nil for PrimaryOID and HasOID - the len==0
// guard handles both.
func TestPrimaryOID_EmptySlice_BehavesSameAsNil(t *testing.T) {
	oidc := OpenIDConnectToken{OID: []string{}}

	assert.Equal(t, "", oidc.PrimaryOID())
	assert.False(t, oidc.HasOID("anything"))
}

func BenchmarkUnmarshalStringWithCommaWillBeSliceScopeClaims(t *testing.B) {
	token := []byte(`{"scope": "teos/c-admin:abba,finntroll"}`)

	for i := 0; i < t.N; i++ {
		var oidc OpenIDConnectToken
		err := json.Unmarshal(token, &oidc)
		if err != nil {
			t.Fail()
		}
	}
}

// The IAM sign-in function writes rsid into a user's access token as a list of
// site IDs. UnmarshalMap keeps it as one comma-separated string, the same form
// API Gateway passes, so a policy reads it the same way from both.
func TestUnmarshalRSIDStringAndList(t *testing.T) {
	tests := []struct {
		name   string
		claims string
		want   string
	}{
		{name: "one site", claims: `{"sub":"u","rsid":"site-a"}`, want: "site-a"},
		{name: "comma-separated string", claims: `{"sub":"u","rsid":" site-a , site-b "}`, want: "site-a,site-b"},
		{name: "list", claims: `{"sub":"u","rsid":["site-a","site-b"]}`, want: "site-a,site-b"},
		{name: "empty list", claims: `{"sub":"u","rsid":[]}`, want: ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var oidc OpenIDConnectToken
			require.NoError(t, json.Unmarshal([]byte(tt.claims), &oidc))
			assert.Equal(t, tt.want, oidc.RemoteSystemID)
		})
	}
}
