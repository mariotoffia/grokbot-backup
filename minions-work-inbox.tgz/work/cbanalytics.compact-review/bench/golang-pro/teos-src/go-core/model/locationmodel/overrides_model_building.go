package locationmodel

import (
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/utils/idutils"
)

const buildingPrefix = "BLD#"

// PostProcess will make sure that all identifiers are correctly set after
// a query from the database. This will parse the identity and put data into
// the properties.
func (ps *Building) PostProcess() *Building {
	if ps == nil {
		return nil
	}

	ps.Name = strings.TrimPrefix(ps.LocationID, buildingPrefix)

	return ps
}

// Prepare will prepare the instance for storage by render the attributes
// into the `LocationID` and `TransformationStepID` attributes including
// storage prefixes.
//
// NOTE: Since this is done inline, make sure to use `PostProcess` if you
// plan to keep using this instance.
func (ps *Building) Prepare() *Building {
	if ps == nil {
		return nil
	}

	ps.LocationID = buildingPrefix + strings.TrimPrefix(ps.Name, buildingPrefix)
	ps.SK = "BLD"

	return ps
}

// OwnedBy will check if the `LocationID` do end with ' ({owner})'. It will extract that and return the
// owner string.
func (o *Building) OwnedBy() string {
	if o == nil {
		return ""
	}

	_, rsid := idutils.RSIDDecodeLocationID(strings.TrimPrefix(o.LocationID, buildingPrefix))

	return rsid
}

// GetLocationAsString returns the location parameter as a string independent
// of the underlying type. If not found, it returns an empty string.
func (o *Building) GetLocationAsString(name string) string {
	if o == nil {
		var ret string
		return ret
	}

	if v, ok := o.Location[name]; ok {
		if vs, ok := v.(string); ok {
			return vs
		}

		return fmt.Sprintf("%v", v)
	}

	return ""
}

// SetLocation will ensure that the parameter in building Location
// is set.
//
// If the value is `nil`, it will be removed. If any changes, it
// will return `true`, if nothing was changed, it will return `false`.
func (o *Building) SetLocation(name string, value any) bool {
	if o == nil {
		return false
	}

	if value == nil {
		if o.Location == nil {
			return false
		}

		if _, ok := o.Location[name]; ok {
			delete(o.Location, name)

			if len(o.Location) == 0 {
				o.Location = nil
			}

			return true
		}

		return false
	}

	if o.Location != nil {
		if v, ok := o.Location[name]; ok && v == value {
			return false
		}
	} else {
		o.Location = map[string]any{}
	}

	o.Location[name] = value

	return true
}

// CompareSetLocation will compare the value in building Location section
// and if it differs or not found, it will be set (and return `true`).
//
// Otherwise, it will return `false`.
func (o *Building) CompareSetLocation(name string, value any) bool {
	if o == nil {
		return false
	}

	if nil == o.Location {
		o.Location = map[string]any{
			name: value,
		}

		return true
	}

	if v, ok := o.Location[name]; ok {
		if v == value {
			return false
		}
	}

	o.Location[name] = value

	return true
}

// GetParamsAsString returns the params parameter as a string independent
// of the underlying type. If not found, it returns an empty string.
func (o *Building) GetParamsAsString(name string) string {
	if o == nil {
		var ret string
		return ret
	}

	if v, ok := o.Params[name]; ok {
		if vs, ok := v.(string); ok {
			return vs
		}

		return fmt.Sprintf("%v", v)
	}

	return ""
}

// SetParams will ensure that the parameter in building Params
// is set.
//
// If the value is `nil`, it will be removed.
func (o *Building) SetParams(name string, value any) {
	if o == nil {
		return
	}

	if o.Params == nil {
		if value == nil {
			return
		}

		o.Params = map[string]any{}
	}

	if value == nil {
		delete(o.Params, name)
	} else {
		o.Params[name] = value
	}
}

// CompareSetParams will compare the value in building Params section
// and if it differs or not found, it will be set (and return `true`).
//
// Otherwise, it will return `false`.
func (o *Building) CompareSetParams(name string, value any) bool {
	if o == nil {
		return false
	}

	if nil == o.Params {
		o.Params = map[string]any{
			name: value,
		}

		return true
	}

	if v, ok := o.Params[name]; ok {
		if v == value {
			return false
		}
	}

	o.Params[name] = value

	return true
}
