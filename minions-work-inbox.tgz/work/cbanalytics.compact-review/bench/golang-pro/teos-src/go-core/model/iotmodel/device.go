package iotmodel

// Device is a platform independent abstraction of a _IoT device_.
//
// A device may have one or more named _Device Shadows_ attached to it. It
// also usually belongs to a _Device Group_ and possibly a _Billing Group_.
// Most device managers always search of metadata both from the Device_ itself
// and it's group belonging(s).
type Device struct {
	// A unique id of the device. This id is encoded as `_[a-z][A-Z]_`
	ID string `json:"id"`
	// URI is an optional _URI_ that is platform specific where the device resource is located
	URI string `json:"uri,omitempty"`
	// Name is a human readable name of the device
	Name string `json:"name,omitempty"`
	// Type is a id or common name of the type definition for this device
	Type string `json:"type,omitempty"`
	// Version is a version of the device e.g. when updated this may increment or otherwise change. It may be a
	// integer, hash, or UUID or otherwise.
	Version string `json:"version,omitempty"`

	// Billing is an optional identifier (if platform supports it) of how it is billed e.g. in a billing group.
	// This is then the name or id of that billing group.
	Billing string `json:"billing,omitempty"`

	// Extra properties on device that could not be mapped to this _device Struct_.
	Properties map[string]string `json:"properties,omitempty"`
	// Attributes attached to the device as _metadata_. Some device manager allows for _querying_ such _metadata_.
	Attributes map[string]string `json:"attributes,omitempty"`

	// Connected indicates whether the device is currently connected. Nil means
	// connectivity status is unknown (e.g. Fleet Indexing not enabled or the
	// device has never connected).
	Connected *bool `json:"connected,omitempty"`
	// ConnectedTimestamp is the epoch millisecond timestamp of the last
	// connect or disconnect event, as reported by IoT Fleet Indexing.
	ConnectedTimestamp int64 `json:"connectedTimestamp,omitempty"`
}
