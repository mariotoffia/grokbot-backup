package teosid

import (
	"strconv"
	"strings"
)

// Parse validates raw and returns its semantic fields and canonical spelling.
func Parse(raw string) (Identity, error) {
	if raw == "" {
		return Identity{}, parseError("empty", 0)
	}

	baseEnd := strings.IndexByte(raw, '_')
	if baseEnd < 0 {
		baseEnd = len(raw)
	}
	base := raw[:baseEnd]
	segments, err := parseBase(base)
	if err != nil {
		return Identity{}, err
	}

	identity := identityFromBase(raw, base, segments)
	if baseEnd < len(raw) {
		if err := parseSuffix(raw, baseEnd, &identity); err != nil {
			return Identity{}, err
		}
	}

	canonical, err := Render(Parts{
		QualifiedID: identity.QualifiedID,
		Ordinal:     identity.Ordinal,
		Circuit:     identity.Circuit,
		Zone:        identity.Zone,
		Area:        identity.Area,
		Tags:        identity.Tags,
	})
	if err != nil {
		return Identity{}, err
	}
	identity.Canonical = canonical
	return identity, nil
}

func parseBase(base string) ([]string, error) {
	if base == "" {
		return nil, parseError("invalid_base", 0)
	}
	segments := strings.Split(base, ".")
	offset := 0
	for _, segment := range segments {
		if !validBaseSegment(segment) {
			return nil, parseError("invalid_base", offset)
		}
		offset += len(segment) + 1
	}
	return segments, nil
}

func validBaseSegment(segment string) bool {
	if segment == "" || segment[0] < 'A' || segment[0] > 'Z' {
		return false
	}
	for i := 1; i < len(segment); i++ {
		if (segment[i] < 'A' || segment[i] > 'Z') && (segment[i] < '0' || segment[i] > '9') {
			return false
		}
	}
	return true
}

func identityFromBase(raw, base string, segments []string) Identity {
	identity := Identity{Raw: raw, QualifiedID: base, ID: segments[len(segments)-1]}
	if len(segments) == 1 {
		return identity
	}

	identity.Category = segments[0]
	if len(segments) > 2 {
		identity.Subcategories = append([]string(nil), segments[1:len(segments)-1]...)
		identity.SubcategoryPath = strings.Join(identity.Subcategories, ".")
	}
	return identity
}

func parseSuffix(raw string, baseEnd int, identity *Identity) error {
	position := baseEnd
	lastDimension := 0
	seenDimensions := map[byte]bool{}
	customStarted := false

	for position < len(raw) {
		if raw[position] != '_' {
			return parseError("invalid_suffix", position)
		}
		tokenStart := position + 1
		if tokenStart == len(raw) {
			return parseError("empty_suffix", tokenStart)
		}
		tokenEnd := strings.IndexByte(raw[tokenStart:], '_')
		if tokenEnd < 0 {
			tokenEnd = len(raw)
		} else {
			tokenEnd += tokenStart
		}
		token := raw[tokenStart:tokenEnd]
		if token == "" {
			return parseError("empty_suffix", tokenStart)
		}
		key := token[0]
		value := token[1:]
		if value == "" {
			return parseError("empty_value", tokenStart+1)
		}

		if order := dimensionOrder(key); order != 0 {
			if seenDimensions[key] {
				return parseError("duplicate_dimension", tokenStart)
			}
			if customStarted || order < lastDimension {
				return parseError("dimension_order", tokenStart)
			}
			if err := assignDimension(identity, key, value, tokenStart+1); err != nil {
				return err
			}
			seenDimensions[key] = true
			lastDimension = order
		} else {
			if key < 'A' || key > 'Z' {
				return parseError("invalid_tag", tokenStart)
			}
			customStarted = true
			if identity.Tags == nil {
				identity.Tags = make(map[string]string)
			}
			tag := string(key)
			if _, exists := identity.Tags[tag]; exists {
				return parseError("duplicate_tag", tokenStart)
			}
			identity.Tags[tag] = value
		}
		position = tokenEnd
	}
	return nil
}

func dimensionOrder(key byte) int {
	switch key {
	case 'O':
		return 1
	case 'C':
		return 2
	case 'Z':
		return 3
	case 'A':
		return 4
	default:
		return 0
	}
}

func assignDimension(identity *Identity, key byte, value string, offset int) error {
	switch key {
	case 'O', 'C':
		number, err := strconv.ParseUint(value, 10, 63)
		if err != nil || uint64(int(number)) != number {
			return parseError("invalid_number", offset)
		}
		parsed := int(number)
		if key == 'O' {
			identity.Ordinal = &parsed
		} else {
			identity.Circuit = &parsed
		}
	case 'Z':
		parsed := value
		identity.Zone = &parsed
	case 'A':
		parsed := value
		identity.Area = &parsed
	}
	return nil
}
