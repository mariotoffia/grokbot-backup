package reportmodel

// AwsServiceTypes is the well-known types of services.
type AwsServiceTypes string

const (
	AwsServiceTypeS3              AwsServiceTypes = "s3"
	AwsServiceTypeSQS             AwsServiceTypes = "sqs"
	AwsServiceTypeDynamoDB        AwsServiceTypes = "dynamodb"
	AwsServiceTypeKinesisStream   AwsServiceTypes = "kinesis-stream"
	AwsServiceTypeKinesisFirehose AwsServiceTypes = "kinesis-firehose"
	AwsServiceTypeLambda          AwsServiceTypes = "lambda"
	AwsServiceTypeIoTDeviceShadow AwsServiceTypes = "iot-ds"
	AwsServiceTypeApiGatewayV1    AwsServiceTypes = "api-rest-gateway"
	AwsServiceTypeApiGatewayV2    AwsServiceTypes = "api-http-gateway"
)

// ServiceStatus is the status for the `ServiceTypes`.
type ServiceStatus string

const (
	// ServiceStatusOnline seems to work ok.
	ServiceStatusOnline ServiceStatus = "online"
	// ServiceStatusSlow is when the service is slow to respond.
	ServiceStatusSlow ServiceStatus = "slow"
	// ServiceStatusIntermittent is when the service is intermittently slow to respond
	// e.g. need to re-connect several times before it works.
	ServiceStatusIntermittent ServiceStatus = "intermittent"
	// ServiceStatusDown is when the service is down.
	ServiceStatusDown ServiceStatus = "down"
	// ServiceStatusUnknown is when the service status is unknown.
	ServiceStatusUnknown ServiceStatus = "unknown"
)

// ServiceStatusImpl is the status for one un-/named service.
type ServiceStatusImpl struct {
	// ID is the ID of the service such as an _URI_, _ARN_ or _Name_.
	// When id is set to nothing, it is for the service as a whole.
	ID string `json:"id,omitempty"`
	// Type is the type of service.
	Type AwsServiceTypes `json:"type"`
	// Status is the status of the service.
	Status ServiceStatus `json:"status"`
}

// ServiceExecutionStatus is the status of the core or user service itself.
type ServiceExecutionStatus string

const (
	// ServiceExecutionStatusOnline is when the core or user service is working properly
	// and can maintain its work. This may be the status even if any of the dependencies
	// are down since it may still perform it's work (for now).
	ServiceExecutionStatusOnline ServiceExecutionStatus = "online"
	// ServiceExecutionStatusDegraded is when the core or user service cannot at all perform
	// any work. This may or may not be dependant on the status of the dependencies.
	//
	// NOTE: This status will not be set if e.g. any user-configuration is erroneous. But if
	// the service-configuration is bad, this may be set.
	ServiceExecutionStatusDown ServiceExecutionStatus = "down"
	// ServiceExecutionStatusDegraded is when the core or user service is working but
	// with degraded performance. This may or may not be dependant on the status of the
	// dependencies & service-configuration.
	ServiceExecutionStatusDegenerated ServiceExecutionStatus = "degenerated"
)

// ServiceLogItemType is the type of log item.
type ServiceLogItemType string

const (
	// ServiceLogItemTypeRecordProcessed marks a log entry where the service is doing
	// record processing and acts upon those. It may mark how many records were processed
	// and which records failed and succeeded.
	ServiceLogItemTypeRecordProcessed ServiceLogItemType = "processed-records"
)

// ServiceWorkLogItem is a single log item.
type ServiceWorkLogItem struct {
	// Type is the type of log item.
	Type ServiceLogItemType `json:"type"`
	// Count is the number of what the `Type` referrers to, e.g. number of records processed.
	Count int `json:"count,omitempty"`
	// Message is a free text semantics message
	Message string `json:"message,omitempty"`
}

// ServiceWorkLog is a set of log items.
//
// TIP: Do aggregate the log items in order to not get a overwhelming amount of log items.
// For example, if records processed, do use two log item to denote hom many bad and how many
// successful records were processed. Instead of one log item with the total number of records
// processed.
type ServiceWorkLog struct {
	Log []ServiceWorkLogItem `json:"log,omitempty"`
}

// ServiceExecutionReport is a generic report where the core & user
// services may report the execution status. Either periodically or
// per request-response basis.
//
// This is the foundation to monitor the health of the system and it's dependencies.
// For example, if a service is dependant on _AWS_ _S3_, _SQS_ and _DynamoDB_ and reports
// that all services except _DynamoDB_ could be used. The impact is that the service
// _DynamoDB_ is down and the service is not able to function properly for all dependant(s).
type ServiceExecutionReport struct {
	// Service is the name of the service reporting
	Service string `json:"svc"`
	// ServiceStatus is the status of the service(s) used by this service
	Dependencies []ServiceStatusImpl `json:"dependencies,omitempty"`
	// Status is the status of the service itself.
	Status ServiceExecutionStatus `json:"status"`
	// WorkLog is a log of what the service has done.
	WorkLog ServiceWorkLog `json:"worklog,omitempty"`
}
