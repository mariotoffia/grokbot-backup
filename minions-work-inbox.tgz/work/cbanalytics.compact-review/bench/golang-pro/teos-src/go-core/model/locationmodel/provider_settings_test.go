package locationmodel_test

import (
	"fmt"
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/locationmodel"
	"github.com/Thiink-LLC/teos/go-core/utils/testutils/testenv"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/cbenv"
	"github.com/Thiink-LLC/teos/go-core/ctx"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
)

func newCtx(tb testing.TB) ifcore.CbContext {
	tb.Helper()
	testenv.Use(tb, testenv.EnvDefaults)

	c, err := ctx.NewContext(
		"test-svc", "test", cbenv.DevLocal,
		true /*sort*/, ctx.OptAWSConfigLoadDefault(),
	)
	require.NoError(tb, err)
	tb.Cleanup(c.Close)

	return c
}

func TestNoResolutionWillNotRender(t *testing.T) {
	ps := &locationmodel.ProviderSettings{
		LocationID:           "BLD#Måssmyren 18",
		TransformationStepID: "TS#main#thiink#sv",
	}

	ps.PostProcess(newCtx(t))

	assert.Equal(t, "Måssmyren 18", ps.LocationID)
	assert.Equal(t, "thiink", ps.ProviderName)
	assert.Equal(t, "main", ps.ProviderGroup)
	assert.Equal(t, "", ps.Resolution)
	assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, ps.Operation)
}

func TestResolutions(t *testing.T) {
	resolutions := []string{
		"100ms", "1s", "5min", "1h", "1d", "2m",
	}

	for _, res := range resolutions {
		ps := &locationmodel.ProviderSettings{
			LocationID:           "BLD#Måssmyren 18",
			TransformationStepID: fmt.Sprintf("TS#main-%s#thiink#esv", res),
		}

		ps.PostProcess(newCtx(t))

		assert.Equal(t, "Måssmyren 18", ps.LocationID)
		assert.Equal(t, "thiink", ps.ProviderName)
		assert.Equal(t, "main", ps.ProviderGroup)
		assert.Equal(t, res, ps.Resolution)
		assert.Equal(t, locationmodel.ProviderOperationSensorValueOut, ps.Operation)
	}
}

func TestResolutionShallBeRenderedWhenSet(t *testing.T) {
	ps := &locationmodel.ProviderSettings{
		LocationID:           "BLD#Måssmyren 18",
		TransformationStepID: "TS#main-15min#thiink#sv",
	}

	ps.PostProcess(newCtx(t))

	assert.Equal(t, "Måssmyren 18", ps.LocationID)
	assert.Equal(t, "thiink", ps.ProviderName)
	assert.Equal(t, "main", ps.ProviderGroup)
	assert.Equal(t, "15min", ps.Resolution)
	assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, ps.Operation)

	ps.TransformationStepID = ""

	ps.Prepare()

	assert.Equal(t, "BLD#Måssmyren 18", ps.LocationID)
	assert.Equal(t, "TS#main-15min#thiink#sv", ps.TransformationStepID)
}

func TestResolutionShallNotBeRenderedWhenNotSet(t *testing.T) {
	ps := &locationmodel.ProviderSettings{
		LocationID:           "BLD#Måssmyren 18",
		TransformationStepID: "TS#main#thiink#sv",
	}

	ps.PostProcess(newCtx(t))

	assert.Equal(t, "Måssmyren 18", ps.LocationID)
	assert.Equal(t, "thiink", ps.ProviderName)
	assert.Equal(t, "main", ps.ProviderGroup)
	assert.Equal(t, "", ps.Resolution) // Since defaults to 15min
	assert.Equal(t, locationmodel.ProviderOperationSensorValueIn, ps.Operation)

	ps.TransformationStepID = ""
	ps.Resolution = ""

	ps.Prepare()

	assert.Equal(t, "BLD#Måssmyren 18", ps.LocationID)
	assert.Equal(t, "TS#main#thiink#sv", ps.TransformationStepID)
}
