package eqmodel_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// TestValidSensorNames tests all combinations of sensor names that shall validate to valid.
func TestValidSensorNames(t *testing.T) {
	id := []eqmodel.SensorType{
		eqmodel.SensorType("IDT"),
		eqmodel.SensorType("IDT_O1"),
		eqmodel.SensorType("IDT_C14"),
		eqmodel.SensorType("IDT_C14"),
		eqmodel.SensorType("IDT_O1_C2_ZLägenhet 19"),
		eqmodel.SensorType("IDT_C2_ZLägenhet 18"),
		eqmodel.SensorType("IDT_O1_ZLägenhet 18"),
		eqmodel.SensorType("IDT_ZLägenhet 18"),
		// Hierarchical naming
		eqmodel.SensorType("INDOOR.TEMP"),
		eqmodel.SensorType("INDOOR.TEMP_O1"),
		eqmodel.SensorType("INVERTER.L1_O2_C3"),
		eqmodel.SensorType("A.B.C_O1_C2_ZRoom"),
		eqmodel.SensorType("INDOOR.HUM_O14_C32"),
		eqmodel.SensorType("INVERTER.L1"),
		eqmodel.SensorType("A.B.C"),
		// Area tag
		eqmodel.SensorType("IDT_Awest"),
		eqmodel.SensorType("IDT_O1_C2_Awest"),
		eqmodel.SensorType("IDT_O1_C2_ZNorth_Awest"),
	}

	for _, s := range id {
		res, ok := s.Validate()
		assert.Equal(t, true, ok, "Should be ok but got error at: %d for: %s", res, s)
	}
}

// TestInvalidSensorNames tests all combinations of invalid sensor names.
func TestInvalidSensorNames(t *testing.T) {
	id := []eqmodel.SensorType{
		eqmodel.SensorType(""),
		eqmodel.SensorType("IDT_O"),          // Missing ordinal value
		eqmodel.SensorType("IDT_O1_C"),       // Missing circuit value
		eqmodel.SensorType("IDT_Z"),          // Missing zone value
		eqmodel.SensorType("IDT_"),           // Trailing underscore
		eqmodel.SensorType("IDT_C2_O1_"),     // C before O violates ordering
		eqmodel.SensorType("IDT_M"),          // Tag without value
		eqmodel.SensorType("IDT_m3M"),        // lowercase tag key
		eqmodel.SensorType("IDT_13M"),        // Numeric tag key start
		eqmodel.SensorType("IDT_O1_C2_M"),    // Tag without value after valid components
		eqmodel.SensorType("IDT_ZRoom1_m3M"), // lowercase tag key after zone
		eqmodel.SensorType("IDT__M3M"),       // Double underscore
		eqmodel.SensorType("IDT_O1__C2"),     // Double underscore between components
		// Lowercase base ID (uppercase enforcement)
		eqmodel.SensorType("idt"),
		eqmodel.SensorType("Indoor.TEMP"),
		eqmodel.SensorType("INDOOR.temp"),
		// Invalid hierarchy
		eqmodel.SensorType("IDT."),         // Trailing dot
		eqmodel.SensorType(".IDT"),         // Leading dot
		eqmodel.SensorType("INDOOR..TEMP"), // Double dot
		eqmodel.SensorType("1NVALID"),      // Starts with digit
		eqmodel.SensorType("INDOOR.1TEMP"), // Segment starts with digit
		// Invalid characters in base ID
		eqmodel.SensorType("COMT-C1"),
	}

	for _, s := range id {
		_, ok := s.Validate()
		assert.Equal(t, false, ok, "Should be error but got ok for: %s", s)
	}
}

func TestExtractSensorComponents(t *testing.T) {
	type Tests struct {
		SID  eqmodel.SensorType
		OK   bool
		Pos  int
		ID   string
		O    int
		C    int
		Z    string
		A    string
		Tags map[string]any
	}

	tests := []Tests{
		{
			SID: "IDT",
			OK:  true, O: -1, C: -1, Z: "", A: "", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_O1",
			OK:  true, O: 1, C: -1, Z: "", A: "", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_C2",
			OK:  true, O: -1, C: 2, Z: "", A: "", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_O03_C2",
			OK:  true, O: 3, C: 2, Z: "", A: "", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_O1_C2_ZLägenhet 18",
			OK:  true, O: 1, C: 2, Z: "Lägenhet 18", A: "", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_O1_C2_ZLägenhet 18_Awest",
			OK:  true, O: 1, C: 2, Z: "Lägenhet 18", A: "west", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_Awest",
			OK:  true, O: -1, C: -1, Z: "", A: "west", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_C2_Awest",
			OK:  true, O: -1, C: 2, Z: "", A: "west", ID: "IDT", Tags: nil,
		},
		{
			SID: "IDT_M3M",
			OK:  true, O: -1, C: -1, Z: "", A: "", ID: "IDT", Tags: map[string]any{"M": "3M"},
		},
		{
			SID: "IDT_O1_M3M",
			OK:  true, O: 1, C: -1, Z: "", A: "", ID: "IDT", Tags: map[string]any{"M": "3M"},
		},
		{
			SID: "IDT_C2_Tdigital",
			OK:  true, O: -1, C: 2, Z: "", A: "", ID: "IDT", Tags: map[string]any{"T": "digital"},
		},
		{
			SID: "IDT_O1_C2_M3M",
			OK:  true, O: 1, C: 2, Z: "", A: "", ID: "IDT", Tags: map[string]any{"M": "3M"},
		},
		{
			SID: "IDT_O1_C2_ZRoom1_M3M_Tdigital",
			OK:  true, O: 1, C: 2, Z: "Room1", A: "", ID: "IDT", Tags: map[string]any{"M": "3M", "T": "digital"},
		},
		{
			SID: "IDT_ZRoom1_M3M",
			OK:  true, O: -1, C: -1, Z: "Room1", A: "", ID: "IDT", Tags: map[string]any{"M": "3M"},
		},
		{
			SID: "IDT_M3M_Tdigital_Ssensor1",
			OK:  true, O: -1, C: -1, Z: "", A: "", ID: "IDT", Tags: map[string]any{"M": "3M", "T": "digital", "S": "sensor1"},
		},
		// Hierarchical naming
		{
			SID: "INDOOR.TEMP",
			OK:  true, O: -1, C: -1, Z: "", A: "", ID: "INDOOR.TEMP", Tags: nil,
		},
		{
			SID: "INDOOR.TEMP_O1",
			OK:  true, O: 1, C: -1, Z: "", A: "", ID: "INDOOR.TEMP", Tags: nil,
		},
		{
			SID: "INVERTER.L1_O2_C3",
			OK:  true, O: 2, C: 3, Z: "", A: "", ID: "INVERTER.L1", Tags: nil,
		},
		{
			SID: "A.B.C_O1_C2_ZRoom",
			OK:  true, O: 1, C: 2, Z: "Room", A: "", ID: "A.B.C", Tags: nil,
		},
		{
			SID: "INDOOR.HUM_O14_C32",
			OK:  true, O: 14, C: 32, Z: "", A: "", ID: "INDOOR.HUM", Tags: nil,
		},
		{
			SID: "INDOOR.TEMP_O1_C2_Awest",
			OK:  true, O: 1, C: 2, Z: "", A: "west", ID: "INDOOR.TEMP", Tags: nil,
		},
		{
			SID: "INDOOR.TEMP_O1_C2_ZNorth_Awest_M3M",
			OK:  true, O: 1, C: 2, Z: "North", A: "west", ID: "INDOOR.TEMP", Tags: map[string]any{"M": "3M"},
		},
		// Invalid hierarchical - pos is set to the string length since validation
		// fails at the base ID extracted at end-of-string (no underscore present).
		{
			SID: "indoor.TEMP",
			OK:  false, Pos: 11, O: -1, C: -1, ID: "indoor.TEMP",
		},
		{
			SID: "INDOOR.temp",
			OK:  false, Pos: 11, O: -1, C: -1, ID: "INDOOR.temp",
		},
		{
			SID: "INDOOR..TEMP",
			OK:  false, Pos: 12, O: -1, C: -1, ID: "INDOOR..TEMP",
		},
	}

	for _, test := range tests {
		pos, ok, id, o, c, z, a, tags := test.SID.Parse()

		assert.Equal(t, test.Pos, pos)
		assert.Equal(t, test.OK, ok)
		assert.Equal(t, test.ID, id)
		assert.Equal(t, test.O, o)
		assert.Equal(t, test.C, c)
		assert.Equal(t, test.Z, z)
		assert.Equal(t, test.A, a)
		assert.Equal(t, test.Tags, tags)
	}
}

func TestToSensorAllWithCertainCircuit(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2", "OFFSPSSHCT_C1", "OFFSPSSHCT_C2"},
		eqmodel.SensorType("*_C1"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("OFFSPSSHCT_C1"), sensors[1])
}

func TestWildcardIsOnlyAFilterExpression(t *testing.T) {
	_, ok := eqmodel.SensorType("*").Validate()
	assert.False(t, ok)
	_, ok = eqmodel.SensorType("*_C1").Validate()
	assert.False(t, ok)
}

func TestTagsWithStringBoolAndIntValues(t *testing.T) {
	s := eqmodel.SensorType("IDT_O1_C2_ZLägenhet 18_Amy area_S14_Ttrue")

	pos, ok, id, o, c, z, a, tags := s.Parse()

	require.Equal(t, 0, pos, "Should have zero errors")
	require.Equal(t, true, ok)
	require.Equal(t, "IDT", id)
	require.Equal(t, 1, o)
	require.Equal(t, 2, c)
	require.Equal(t, "Lägenhet 18", z)
	require.Equal(t, "my area", a)

	require.Equal(t, 2, len(tags))
	require.Equal(t, int64(14), tags["S"])
	require.Equal(t, true, tags["T"])
}

func BenchmarkSensorValidationPerformance(t *testing.B) {
	s := eqmodel.SensorType("IDT_O1_C2_ZLägenhet 18")

	for i := 0; i < t.N; i++ {
		s.Validate()
	}
}

func BenchmarkSensorWithCustomTagsValidationPerformance(t *testing.B) {
	s := eqmodel.SensorType("IDT_O1_C2_ZLägenhet 18_Amy area_S14_Ttrue")

	for i := 0; i < t.N; i++ {
		s.Validate()
	}
}

func BenchmarkToSensorAllWithCertainCircuit(t *testing.B) {
	s := []string{"COMT_C1", "COMT_C2", "OFFSPSSHCT_C1", "OFFSPSSHCT_C2"}

	for i := 0; i < t.N; i++ {
		eqmodel.ToSensorTypes(s, eqmodel.SensorType("*_C1"))
	}
}
