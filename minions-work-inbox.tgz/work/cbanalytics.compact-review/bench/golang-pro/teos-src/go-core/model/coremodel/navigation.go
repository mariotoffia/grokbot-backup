package coremodel

import (
	"errors"
	"strings"
)

// PathElement is a single element for a path in a reflective / map navigation
// (_see cbreflect_) for more information.
type PathElement struct {
	// Element is the name. If indexer, it has no _[]_ around
	// it, instead The IsIndexer is `true`.
	Element string
	// IsIndexer if the `Element` is a indexer path element.
	IsIndexer bool
}

// FullPath is a fully qualified path.
type FullPath []PathElement

// PathElementSet is a grouped set of `PathElement`. A set is typically formed
// after same indexer path. I.e. two different index for same array.
type PathElementSet struct {
	// FirstFqElement contains the first element fully qualified path.
	FirstFqElement FullPath
	// Root is the path all the way to the set.
	Root FullPath
	// IsIndexer is set to `true` if the `Root` points to a indexer set, e.g. a slice.
	IsIndexer bool
	// Elements is a pointer for each individual `PathElement` for this set.
	Elements []PathElement
}

// IsIndexerPath
func (fp FullPath) IsIndexerPath() bool {
	return fp[len(fp)-1].IsIndexer
}

// ToIndexerRootPath creates a path to the actual indexer and returns the
// actual indexer separately in _elem_.
func (fp FullPath) ToIndexerRootPath() (root FullPath, elem PathElement) {
	return fp[:len(fp)-1], fp[len(fp)-1]

}

// String returns a full representation of the path as a `string`.
func (fp FullPath) String() string {
	len := len(fp)
	var sb strings.Builder

	for i := 0; i < len-1; i++ {
		sb.WriteString(fp[i].Element)
		sb.WriteString("/")
	}

	sb.WriteString(fp[len-1].Element)
	return sb.String()

}

// GroupIndexers will group all indexers into _sets_ and rest of paths is returned in _rest_.
func GroupIndexers(paths []FullPath) (sets []*PathElementSet, rest []FullPath) {
	rest = []FullPath{}
	m := map[string]*PathElementSet{}

	for _, path := range paths {
		if path.IsIndexerPath() {
			fp, elem := path.ToIndexerRootPath()

			fps := fp.String()
			pes, ok := m[fps]

			if !ok {
				pes = &PathElementSet{
					Root:           fp,
					FirstFqElement: path,
					IsIndexer:      true,
				}

				m[fps] = pes
			}

			pes.Elements = append(pes.Elements, elem)
		} else {
			rest = append(rest, path)
		}
	}

	for key := range m {
		sets = append(sets, m[key])
	}

	return
}

// ToFullPath parses path into a `FullPath`. The segments of path are separated
// by ".". A segment in brackets, such as [2] or [ODT], is an indexer element:
// its Element is the text between the brackets, which may be empty. Any other
// segment is a plain element.
//
// It returns an error when a segment starts with "[" and does not end with
// "]". The error does not contain path, because a policy result can supply it.
func ToFullPath(path string) (FullPath, error) {
	p := []PathElement{}

	for _, element := range strings.Split(path, ".") {
		indexer, isIndexer := strings.CutPrefix(element, "[")
		if !isIndexer {
			p = append(p, PathElement{Element: element})
			continue
		}

		indexer, closed := strings.CutSuffix(indexer, "]")
		if !closed {
			return nil, errors.New("path has an indexer segment that does not end with ]")
		}

		p = append(p, PathElement{Element: indexer, IsIndexer: true})
	}

	return p, nil
}
