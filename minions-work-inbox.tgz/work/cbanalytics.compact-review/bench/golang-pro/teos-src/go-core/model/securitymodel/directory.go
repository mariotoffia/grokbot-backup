package securitymodel

import "time"

type UserDirectoryStatus string

const (
	UserDirectoryStatusEnabled  UserDirectoryStatus = "enabled"
	UserDirectoryStatusDisabled UserDirectoryStatus = "disabled"
)

// UserDirectory is a directory of users that can be used to authenticate.
type UserDirectory struct {
	// ID of the directory.
	ID string `json:"id"`
	// Name is a display friendly name of the directory.
	Name string `json:"name"`
	// Creates is when it was created.
	Created time.Time `json:"created"`
	// Status is the current status of the directory.
	Status UserDirectoryStatus `json:"status"`
}
