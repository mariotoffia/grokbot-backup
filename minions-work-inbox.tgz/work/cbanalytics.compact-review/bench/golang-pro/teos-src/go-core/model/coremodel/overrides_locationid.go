package coremodel

import (
	"net/url"
	"strings"
)

// MaxEncodedLocationIDLength is the longest thing name AWS IoT accepts, 128
// characters. It is the limit for an encoded location id, the form
// EncodeLocationID returns.
const MaxEncodedLocationIDLength = 128

// upperHex holds the uppercase hexadecimal digits EncodeLocationID writes.
const upperHex = "0123456789ABCDEF"

// DecodeLocationID turns a name made by EncodeLocationID back into the
// original location id.
//
// Every "_" in the name starts a three-character escape: it is read as "%"
// and the name is then path-unescaped. "_5F" gives back a literal "_".
func DecodeLocationID(name LocationID) LocationID {
	s, _ := url.PathUnescape(strings.ReplaceAll(string(name), "_", "%"))

	return LocationID(s)
}

// EncodeLocationID turns a location id into the name used for its AWS IoT
// thing and in its MQTT topics.
//
// Every byte other than A-Z, a-z, 0-9, '-' and ':' is written as '_' and
// the byte's two uppercase hexadecimal digits, so "Storgatan 1.5" becomes
// "Storgatan_201_2E5". The name therefore uses only characters AWS IoT
// accepts in a thing name, every '_' in it starts an escape, different ids
// give different names, and DecodeLocationID returns the original id.
func EncodeLocationID(name LocationID) LocationID {
	var b strings.Builder

	b.Grow(len(name))

	for i := 0; i < len(name); i++ {
		c := name[i]

		if keepInLocationID(c) {
			b.WriteByte(c)

			continue
		}

		b.WriteByte('_')
		b.WriteByte(upperHex[c>>4])
		b.WriteByte(upperHex[c&0x0F])
	}

	return LocationID(b.String())
}

// keepInLocationID reports whether EncodeLocationID writes byte c as it is.
func keepInLocationID(c byte) bool {
	return 'A' <= c && c <= 'Z' ||
		'a' <= c && c <= 'z' ||
		'0' <= c && c <= '9' ||
		c == '-' || c == ':'
}
