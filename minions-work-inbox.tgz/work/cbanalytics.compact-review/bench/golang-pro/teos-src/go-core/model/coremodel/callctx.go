package coremodel

import "strings"

type CallContext struct {
	PathParams    map[string]string
	QueryParams   map[string][]string
	HeaderParams  map[string][]string
	ContextParams map[string]string
	Operation     Operation
	Path          string
	Route         string
}

func (e *CallContext) GetPathParams() map[string]string {
	return e.PathParams
}

func (e *CallContext) GetQueryParams() map[string][]string {
	return e.QueryParams
}

func (e *CallContext) GetSingleQueryParam(name string) (string, bool) {
	if v, ok := e.QueryParams[name]; ok {
		if len(v) > 0 {
			return v[0], true
		}
	}

	return "", false
}

func (e *CallContext) GetHeaderParams() map[string][]string {
	return e.HeaderParams
}

func (e *CallContext) GetSingleHeaderParam(name string) (string, bool) {
	if v, ok := e.HeaderParams[name]; ok {
		if len(v) > 0 {
			return v[0], true
		}
	}

	return "", false

}

func (e *CallContext) GetOperation() Operation {
	return e.Operation
}

func (e *CallContext) GetPath() string {
	return e.Path
}

func (e *CallContext) GetRoute() string {
	return e.Route
}

func (e *CallContext) GetContextParams() map[string]string {
	return e.ContextParams
}

// CopyBothToMulti will copy the _single_ and _multi_ and return the resulting map.
func CopyBothToMulti(
	lc bool,
	single map[string]string,
	multi map[string][]string,
) map[string][]string {
	if len(single) == 0 && len(multi) == 0 {
		return nil
	}

	res := make(map[string][]string, len(multi)+len(single))

	for key, value := range single {
		if lc {
			key = strings.ToLower(key)
		}
		res[key] = []string{value}
	}

	for key, value := range multi {
		if lc {
			key = strings.ToLower(key)
		}

		if s, ok := res[key]; ok {
			res[key] = append(s, value...)
		} else {
			res[key] = value
		}
	}

	return res
}

// FilterContextParams will iterate the _data_ map and upsert keys in the _to_ map
// that are prefixed with `ctx_`. The prefix is removed from the key. The value
// is the value from the _data_ map.
//
// The return value is the _to_ map.
func FilterContextParams(to, data map[string]string) map[string]string {
	for key, value := range data {
		if len(key) > 4 && strings.ToLower(key[:4]) == "ctx_" {
			to[strings.ToUpper(key[4:])] = value
		}
	}

	return to
}
