package eqdefs

// DefinitionMap defines the well known datapoints in the system
var DefinitionMap map[string]DataPointDefinition = mergeDefinitions(
	climateSensorDefinitions,
	heatingSensorDefinitions,
	hotWaterSensorDefinitions,
	dataPointDefinitions,
)

// mergeDefinitions joins the definition sections into one map. An identifier
// defined in more than one section panics, so a duplicate fails as soon as the
// package loads.
func mergeDefinitions(sections ...map[string]DataPointDefinition) map[string]DataPointDefinition {
	merged := map[string]DataPointDefinition{}

	for _, section := range sections {
		for id, definition := range section {
			if _, exists := merged[id]; exists {
				panic("eqdefs: data point " + id + " is defined in more than one section")
			}

			merged[id] = definition
		}
	}

	return merged
}
