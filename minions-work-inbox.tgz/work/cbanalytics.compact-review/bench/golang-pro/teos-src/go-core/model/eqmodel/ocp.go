package eqmodel

type OptimizationsControlPrinciple string

var AllOptimizationControlPrinciples = []OptimizationsControlPrinciple{
	OcpOutdoorTemperature,
	OcpOutdoorTemperatureOffset,
	OcpSetpointSecondaryCircuitTemperature,
	OcpSetpointSecondaryCircuitTemperatureOffset,
}

const (
	// OcpOutdoorTemperatureOffset is a control principle
	// that is based on the outdoor temperature offset.
	OcpOutdoorTemperatureOffset OptimizationsControlPrinciple = "OFFODT"
	// OcpOutdoorTemperature is a control principle that optimizes on the outdoor temperature.
	OcpOutdoorTemperature OptimizationsControlPrinciple = "ODT"
	// OcpSetpointSecondaryCircuitTemperature is a control principle
	// that is based on the secondary heating circuit temperature setpoint.
	OcpSetpointSecondaryCircuitTemperature OptimizationsControlPrinciple = "SPSSHCT"
	// OcpActivelyControlledSetpointSecondaryCircuitTemperature is a control principle
	// that is based on the actively controlled secondary heating circuit temperature setpoint offset.
	OcpSetpointSecondaryCircuitTemperatureOffset OptimizationsControlPrinciple = "OFFSPSSHCT"
)

type OptimizationsControlPrinciples []OptimizationsControlPrinciple

var AllOptimizationsControlPrinciple = OptimizationsControlPrinciples{
	OcpOutdoorTemperatureOffset,
	OcpOutdoorTemperature,
	OcpSetpointSecondaryCircuitTemperature,
	OcpSetpointSecondaryCircuitTemperatureOffset,
}

var AllOptimizationsControlPrincipleSensors = []SensorType{
	SensorType(OcpOutdoorTemperatureOffset),
	SensorType(OcpOutdoorTemperature),
	SensorType(SensorSupplyActingHeatingSecondaryCircuitTemperature),
	SensorType(OcpSetpointSecondaryCircuitTemperatureOffset),
}

// PrimaryControlSignal returns the primary control signal for a certain optimization control principle.
func (o OptimizationsControlPrinciple) PrimaryControlSignal() SensorType {
	switch o {
	case OcpOutdoorTemperatureOffset:
		return SensorOffsetOutdoorTemperature
	case OcpOutdoorTemperature:
		return SensorActiveOutdoorTemperature
	case OcpSetpointSecondaryCircuitTemperature:
		return SensorSupplyActingHeatingSecondaryCircuitTemperature
	case OcpSetpointSecondaryCircuitTemperatureOffset:
		return SensorSupplySetPointHeatingSecondaryCircuitTemperatureOffset
	default:
		return ""
	}
}

// IsValid checks if the _o_ is a valid optimization control principle.
func (o OptimizationsControlPrinciple) IsValid() bool {
	return o == OcpOutdoorTemperatureOffset ||
		o == OcpOutdoorTemperature ||
		o == OcpSetpointSecondaryCircuitTemperature ||
		o == OcpSetpointSecondaryCircuitTemperatureOffset
}
