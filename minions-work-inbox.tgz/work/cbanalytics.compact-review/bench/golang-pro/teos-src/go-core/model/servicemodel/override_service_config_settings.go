package servicemodel

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel/core"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/collection"
	"github.com/Thiink-LLC/teos/go-core/utils/convutils"
	"github.com/Thiink-LLC/teos/go-core/utils/fexp"
	"github.com/Thiink-LLC/teos/go-core/utils/idutils"
)

// PostProcess will make sure that all identifiers are correctly set after
// a query from the database. This will parse the identity and put data into
// the properties.
func (ps *ServiceConfigurationSettings) PostProcess(
	ctx ifcore.CbContext,
) *ServiceConfigurationSettings {
	if ps == nil {
		return nil
	}

	// Make sure BLD# is removed from the LocationID
	ps.LocationID = strings.TrimPrefix(ps.LocationID, "BLD#")

	str := strings.Split(ps.SK, "#")

	if len(str) != 3 {
		log.Warn(ctx).
			WithMethod("PostProcess").
			Str("PK", ps.LocationID).
			Str("SK", ps.SK).
			Msg("Expect 3 parts in the SK: SVCC#{group}#{name}")

		return ps
	}

	ps.Group = str[1]
	ps.Name = str[2]
	ps.SK = ""

	return ps
}

// Prepare will prepare the instance for storage by render the attributes
// into the `LocationID` and `SK` attributes including storage prefixes.
//
// NOTE: Since this is done inline, make sure to use `PostProcess` if you
// plan to keep using this instance.
//
// NOTE: If no group is specified, it will default to `default`.
func (ps *ServiceConfigurationSettings) Prepare() *ServiceConfigurationSettings {
	if ps == nil {
		return nil
	}
	ps.LocationID = "BLD#" + strings.TrimPrefix(ps.LocationID, "BLD#")

	if ps.Group == "" {
		ps.Group = "default"
	}

	ps.SK = fmt.Sprintf("SVCC#%s#%s", ps.Group, ps.Name)

	return ps
}

// OwnedBy will check if the `LocationID` do end with ' ({owner})'. It will extract that and return the
// owner string.
func (ps *ServiceConfigurationSettings) OwnedBy() string {
	if ps == nil {
		return ""
	}

	_, rsid := idutils.RSIDDecodeLocationID(strings.TrimPrefix(ps.LocationID, "BLD#"))

	return rsid
}

// ShallowEqual will check if the name and group are equal.
func (ps *ServiceConfigurationSettings) ShallowEqual(other *ServiceConfigurationSettings) bool {
	return ps.Name == other.Name && ps.Group == other.Group
}

// In will check if _ps_ exists in _other_. It will do a comparison of
// the _Name_ and _Group_.
func (ps *ServiceConfigurationSettings) In(other []ServiceConfigurationSettings) bool {
	for _, o := range other {
		o := o

		if ps.ShallowEqual(&o) {
			return true
		}
	}

	return false
}

// IsConfigPresent will check if the configuration is present.
func (ps *ServiceConfigurationSettings) IsConfigPresent() bool {
	return ps != nil && ps.Config.AdditionalProperties != nil
}

// Validate will validate the instance and return an error if not valid.
func (ps *ServiceConfigurationSettings) Validate(ctx ifcore.CbContext) cberror.Error {
	if ps == nil {
		return cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusBadRequest,
			nil,
			"ServiceConfigurationSettings is nil",
		)
	}

	if ps.LocationID == "" {
		return cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusBadRequest,
			nil,
			"ServiceConfigurationSettings.LocationID is empty",
		)
	}

	if ps.Group == "" {
		return cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusBadRequest,
			nil,
			"ServiceConfigurationSettings.Group is empty",
		)
	}

	if ps.Name == "" {
		return cberror.NewCbErrorf(
			ctx.Service(),
			http.StatusBadRequest,
			nil,
			"ServiceConfigurationSettings.Name is empty",
		)
	}

	return nil
}

// GetOutdoorBalanceTemperature will return the balance temperature (OBT) if it is set.
func (ps *ServiceConfigurationSettings) GetOutdoorBalanceTemperature() (float64, bool) {
	if !ps.IsConfigPresent() {
		return -1, false
	}

	if v, ok := ps.Config.AdditionalProperties[string(eqmodel.ConfigurationTypeOutdoorBalanceTemperature)]; ok {
		return convutils.AnyToFloat64NoError(v)
	}

	return -1, false
}

// GetDisabledSensors checks the "disabled" key in the configuration and expects it to be a slice of strings.
func (ps *ServiceConfigurationSettings) GetDisabledSensors() ([]string, bool) {
	if !ps.IsConfigPresent() {
		return nil, false
	}

	if v, ok := ps.Config.AdditionalProperties["disabled"]; ok {
		var disabled []string
		if slc, ok := v.([]any); ok {
			for _, s := range slc {
				if str, ok := s.(string); ok {
					disabled = append(disabled, str)
				}
			}
		} else if str, ok := v.([]string); ok {
			disabled = str
		}

		return disabled, true
	}

	return nil, false
}

// GetIndoorTargetTemperature will return the target temperature (ITT) if it is set.
func (ps *ServiceConfigurationSettings) GetIndoorTargetTemperature() (float64, bool) {
	if !ps.IsConfigPresent() {
		return -1, false
	}

	if v, ok := ps.Config.AdditionalProperties[string(eqmodel.ConfigurationTypeIndoorTemperatureTarget)]; ok {
		return convutils.AnyToFloat64NoError(v)
	}

	return -1, false
}

// GetIndoorTemperatureLimitLow will return the low temperature (ITL) if it is set.
func (ps *ServiceConfigurationSettings) GetIndoorTemperatureLimitLow() (float64, bool) {
	if !ps.IsConfigPresent() {
		return -1, false
	}

	if v, ok := ps.Config.AdditionalProperties[string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow)]; ok {
		return convutils.AnyToFloat64NoError(v)
	}

	return -1, false
}

func (ps *ServiceConfigurationSettings) GetEffectServiceLevel() (TeosEffectServiceLevels, bool) {
	if !ps.IsConfigPresent() {
		return TeosEffectServiceLevelNotSet, false
	}

	if v, ok := ps.Config.AdditionalProperties[string(eqmodel.ConfigurationEffectServiceLevel)]; ok {
		if s, ok := convutils.AnyToString(v); ok {
			return TeosEffectServiceLevels(s), true
		}
	}

	return TeosEffectServiceLevelNotSet, false
}

// GetHeatCurve will check the configuration if _HCTODT_ and _HCTST_ is present
// and convert it to a slice of `HeatingCurveEntries`.
//
// If _HCT_ is encountered, it will prefer it and return it directly.
//
// If it is incomplete or any other validation error occurs, it wil return an error.
//
// If no config or no heating curve is present, it will return nil.
//
// .Example Heating Curve with supply temp
// [source, json]
// ----
//
//	{
//	  "HCTODT_O1": -20,
//	  "HCTST_O1": 70,
//	  "HCTODT_O2": -10,
//	  "HCTST_O2": 70,
//	  "HCTODT_O3": -5,
//	  "HCTST_O3": 63,
//	  "HCTODT_O4": 0,
//	  "HCTST_O4": 55,
//	  "HCTODT_O5": 5,
//	  "HCTST_O5": 46,
//	  "HCTODT_O6": 10,
//	  "HCTST_O6": 40,
//	  "HCTODT_O7": 15,
//	  "HCTST_O7": 28,
//	}
//
// ----
//
// TIP: Heating curves may be circuit bound and there may even be several heating curves. They are then named _"HCT_C{number}"_ instead
// of just _"HCT"_. The number is the circuit number and is greater than _zero_.
//
// If _circuit_ is set, it has to be greater than 0. If not provided or -1, it will fetch the "global" heating curve "HCT".
func (ps *ServiceConfigurationSettings) GetHeatCurve(circuit ...int) (HeatingCurveEntries, error) {
	if !ps.IsConfigPresent() {
		return nil, nil
	}

	circ := -1

	if len(circuit) > 0 {
		circ = circuit[0]
	}

	if circ == 0 || circ < -1 {
		return nil, fmt.Errorf("circuit must be greater than 0 and not less than -1")
	}

	var (
		h     any
		found bool
	)

	if circ > 0 {
		h, found = ps.Config.AdditionalProperties[fmt.Sprintf("HCT_C%d", circ)]
	} else {
		h, found = ps.Config.AdditionalProperties["HCT"]
	}

	// Check if _HCT_ is present
	if found {
		hctm, err := convutils.CastAnyToSlice[map[string]any](h)

		if err != nil {
			if hct, err := convutils.CastAnyToSlice[HeatingCurveEntry](h); err != nil {
				return nil, fmt.Errorf("the heating curve is not properly set: %w", err)
			} else {
				return hct, nil
			}
		}

		hct := make(HeatingCurveEntries, len(hctm))
		for i, v := range hctm {
			trigger, ok := v["trigger"]
			supply, ok2 := v["supply"]

			if !ok || !ok2 {
				return nil, fmt.Errorf("the heating curve is not properly set")
			}

			t, ok := convutils.AnyToFloat64NoError(trigger)
			if !ok {
				return nil, fmt.Errorf("the heating curve trigger is not a valid float64")
			}

			s, ok := convutils.AnyToFloat64NoError(supply)
			if !ok {
				return nil, fmt.Errorf("the heating curve supply is not a valid float64")
			}

			hct[i] = HeatingCurveEntry{
				OutdoorTriggerTemp: t,
				SupplyTemp:         s,
			}
		}

		return hct, nil
	}

	// Create heating curve
	tt := eqmodel.SensorType(
		eqmodel.ConfigurationTypeHeatingCurveOutDoorTempTrigger,
	).FromMapToArray(ps.Config.AdditionalProperties, true /*excludeNil*/)

	st := eqmodel.SensorType(
		eqmodel.ConfigurationTypeHeatingCurveSupplyTemp,
	).FromMapToArray(ps.Config.AdditionalProperties, true /*excludeNil*/)

	tt = fexp.Filter(tt, func(report *ingestionmodel.CbSensorReportItem) bool {
		return report.Circuit == circ
	})

	st = fexp.Filter(st, func(report *ingestionmodel.CbSensorReportItem) bool {
		return report.Circuit == circ
	})

	if len(tt) == 0 && len(st) == 0 {
		return nil, nil
	}

	if len(tt) != len(st) {
		return nil, fmt.Errorf("the heating curve must have equal length")
	}

	// When all entries are set to 2 then the heating curve is proper.
	vtt := make([]float64, len(tt))
	vst := make([]float64, len(st))
	validate := make([]int, len(tt))

	for i := range tt {
		ott := tt[i].Ordinal - 1 /* ordinal is 1 based */
		ost := st[i].Ordinal - 1

		if ott < 0 || ott >= len(vtt) {
			return nil, fmt.Errorf(
				"the heating curve ordinal - 1 (%d) for %s is out of range",
				ott, eqmodel.ConfigurationTypeHeatingCurveOutDoorTempTrigger)
		}

		if ost < 0 || ost >= len(vst) {
			return nil, fmt.Errorf("the heating curve ordinal - 1 (%d) for %s is out of range",
				ost, eqmodel.ConfigurationTypeHeatingCurveSupplyTemp,
			)
		}

		vtt[ott] = utils.ConvertToFloat64(tt[i].Value, 0)
		vst[ost] = utils.ConvertToFloat64(st[i].Value, 0)

		validate[ott]++
		validate[ost]++
	}

	for i := range validate {
		if validate[i] != 2 {
			return nil, fmt.Errorf(
				"the heating curve is not properly set, all entries must be aligned",
			)
		}
	}

	hct := make([]HeatingCurveEntry, len(vtt))

	for i := range vtt {
		hct[i] = HeatingCurveEntry{
			OutdoorTriggerTemp: vtt[i],
			SupplyTemp:         vst[i],
		}
	}

	return hct, nil
}

// GetHeatCurveCircuits will return all circuits id's that have a heating curve inside the configuration.
//
// It will use -1 if a global circuit i.e. no _C{num} specified.
//
// It detects both exploded and compact heating curves, i.e. "HCTODT_On": .., "HCTODT_On_Cn": .. and HCT, HCT_Cn.
//
// This function can be called and then the `GetHeatCurve` can be called with the circuit id's to get the heating curve.
//
// .Example Get all Heat Curves
// [source, go]
// ----
//
//	circuits := ps.GetHeatCurveCircuits()
//	for _, c := range circuits {
//		if hct, err := ps.GetHeatCurve(c); err == nil {
//			// Do something with the heating curve
//		}
//	}
//
// ----
//
// If no heating curve is present, it will return nil.
//
// There's a shortcut using the `GetAllHeatCurves` function.
func (ps *ServiceConfigurationSettings) GetHeatCurveCircuits() []int {
	if !ps.IsConfigPresent() {
		return nil
	}

	m := ps.Config.AdditionalProperties

	if len(m) == 0 {
		return nil
	}

	toCircuit := func(k string) (int, error) {
		for i := 0; i < len(k); i++ {
			if k[i] < '0' || k[i] > '9' {
				if n, err := strconv.ParseInt(k[:i], 10, 64); err == nil {
					return int(n), nil
				} else {
					return -1, err
				}
			}
		}

		if n, err := strconv.ParseInt(k, 10, 64); err == nil {
			return int(n), nil
		} else {
			return -1, err
		}
	}

	var circuits collection.Set[int]

	for k := range m {
		if strings.HasPrefix(k, "HCTODT_O") {
			if idx := strings.Index(k[7:], "_C"); idx > 0 {
				if c, err := toCircuit(k[idx+2:]); err == nil {
					circuits.Add(c)
				}
			} else {
				circuits.Add(-1)
			}
		} else {
			if strings.HasPrefix(k, "HCT_C") {
				if c, err := toCircuit(k[5:]); err == nil {
					circuits.Add(c)
				}
			} else if k == "HCT" {
				circuits.Add(-1)
			}
		}
	}

	return circuits.All()
}

// CircuitBoundHeatCurve is a heat curve and circuit. If any error
// it will also hold the error.
//
// TIP: `Circuit` of _-1_ is a global heating curve.
type CircuitBoundHeatCurve struct {
	HeatCurve HeatingCurveEntries
	Circuit   int
	Error     error
}

// GetAllHeatCurves will return all heating curves in the configuration.
func (ps *ServiceConfigurationSettings) GetAllHeatCurves() map[int]CircuitBoundHeatCurve {
	if !ps.IsConfigPresent() {
		return nil
	}

	circuits := ps.GetHeatCurveCircuits()

	if len(circuits) == 0 {
		return nil
	}

	entries := make(map[int]CircuitBoundHeatCurve, len(circuits))

	for _, c := range circuits {
		if hct, err := ps.GetHeatCurve(c); err == nil {
			entries[c] = CircuitBoundHeatCurve{HeatCurve: hct, Circuit: c}
		} else {
			entries[c] = CircuitBoundHeatCurve{Error: err, Circuit: c}
		}
	}

	return entries
}

// FromProfileToServiceConfigSettings will examine the params for a SVC entry and create a proper
// `ServiceConfigurationSettings` instance from it.
func FromProfileToServiceConfigSettings(
	params map[string]any,
) (*ServiceConfigurationSettings, error) {
	if p, err := core.FromProfileToServiceConfig(params); err != nil {
		return nil, err
	} else {
		return &ServiceConfigurationSettings{Config: *p}, nil
	}
}
