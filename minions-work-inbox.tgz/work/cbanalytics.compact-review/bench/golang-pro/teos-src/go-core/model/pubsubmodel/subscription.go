package pubsubmodel

import "github.com/google/uuid"

// tag::subscriptions-impl[]

// SubscriptionPayloadDirection specifies which direction the payload is heading.
//
// If no direction, just omit direction or use `QualifierDirectionAny` (which is a empty `string`).
type SubscriptionPayloadDirection string

const (
	// QualifierDirectionInbound specifies that the direction of the payload is inbound.
	QualifierDirectionInbound SubscriptionPayloadDirection = "inbound"
	// QualifierDirectionOutbound specifies that the direction of the payload is outbound.
	QualifierDirectionOutbound SubscriptionPayloadDirection = "outbound"
	// QualifierDirectionAny specifies that direction it both in and outbound.
	//
	// CAUTION: It is not possible to register a subscription with a provider name without
	// providing a valid direction (in/outbound). _QualifierDirectionAny_ is only used when
	// query and hence it will query both in and outbound.
	QualifierDirectionAny SubscriptionPayloadDirection = ""
)

type SubscriptionImpl struct {
	// ID is a globally _UNIQUE_ UUID v4 of the subscription.
	ID uuid.UUID `json:"id"`
	// Target is the target of which this payload is forwarded to. It is a standard name that the
	// `package cbtarget` do know how to interpret.
	//
	// If the provider do have this target name configured and it will translate that into a technology
	// and a _URI_. For example a target of _climatixic_ could be a translated to a _SQS URI_
	// that the `DispatchProvider` do have access to.
	Target string `json:"t"`
	// Qualifier is a qualification in order to apply the actual config or datapoint subscription.
	//
	// The _Qualifier_ may be set to `nil` after a subscription has been added since it is encoded into the subscription
	// tree directly. This would spare a few bytes of memory per subscription.
	Qualifier *SubscriptionQualifier `json:"q"`
	// DataPoints is an array of glob values to denote which datapoints to match.
	//
	// This matches is also a projection. Hence, it will only include the datapoints
	// that matches the expression. A special projection qualifier _$all_ is used to
	// include the _complete_ payload on a single match.
	//
	// If $original is specified, it will forward the original, not transformed payload instead of the transformed
	// one.
	//
	// .Example Match & Projection
	// [source,json]
	// ----
	// [ "IDT**", "ODT_O[0-5]?","RHCS_O*_C1", "RHCS_ZMyZone" ]
	// ----
	//
	// NOTE: If _$all_ is the only specifier, everything will be forwarded. If a glob expression *and* _$all_ is
	// specified, then it will match on the glob expression and then forward the complete payload.
	//
	// If no global, target, or subscription projection policy is present, the projection is done using the _glob_ expressions.
	//
	// It is also possible to specify a exclusion filter to remove data when the filter matches. Those filters begins with a minus sign.
	// .Example Exclusion Filter
	// [source,json]
	// ----
	// [ "IDT**", "$all", "-ODT_O[0-5]"] // <1>
	// ----
	// <1> When a IDT is found, capture the complete payload and then remove the _ODT_O[0-5]_ (if found).
	//
	// The last matcher is the not matcher. If it matches, the complete payload is not matched, even if all inclusion filters
	// are matched. The not matcher is denoted by a exclamation mark _!_.
	//
	// .Example Not Matcher
	// [source,json]
	// ----
	// [ "IDT**", "!ODT**" ] // <1>
	// ----
	// <1> Forward all payloads that do contain an IDT, but not an ODT. The payload will only contain IDT values.
	//
	// The add matcher is denoted by a plus sign _+_. This do not yield a match, instead will plainly add the datapoint(s)
	// when a match has been done.
	//
	// .Example Add Matcher
	// [source,json]
	// ----
	// [ "IDT**", "+ODT**" ] // <1>
	// ----
	// <1> When a single _IDT_ has been detected, it will take all _ODT_ found in the payload and forward them as well.
	//
	// When the datapoint starts with a colon _:_ it will be interpreted as a navigation path that is required to exist and
	// have a value / count in order for the payload to be forwarded. This is done *after* all other matching is done.
	//
	// .Example Navigation Path
	// [source,json]
	// ----
	// [ "IDT**", ":*.sensors"] // <1>
	// ----
	// <1> When a IDT is found, capture the _IDT_ sensors and forward it if a sublevel property sensors do exist and have a value
	// or count.
	DataPoints []string `json:"dp,omitempty"`
	// HintNavigation is a hint where to find the `DataPoints` in the payload. If omitted, it will try to find this automatically.
	HintNavigation string `json:"hn,omitempty"`
	// Subscriber is set by a `ifpubsub.SubscriptionManager` when subscription is added. This is then propagated to all
	// functions so it can be resolved - e.g. claims etc.
	Subscriber *SubscriberImpl `json:"-"`
}

// end::subscriptions-impl[]
// tag::location-qualifier[]

// SubscriptionQualifier is a qualifier where it filters in or out
// the subscription applied to the payload or to the context of the
// payload.
type SubscriptionQualifier struct {
	// OwnerID is the _ownerID_ that the subscription wishes to see data from.
	//
	// If the _OID_ is _all_ (coremodel.All) it wishes to see the data of every organization
	// in the account. An empty _OID_ is the same as _all_.
	//
	// NOTE: If the scopes / claims do not allow the subscriber to see _all_ data
	// it will only be seeing the data with the _ownerID_ that the subscriber has
	// _read_ access to.
	OwnerID string `json:"oid,omitempty"`
	// LocationID is the _ID_ of the location such as _BLD#Måssmyren 18_ or _BLD#*EQ#nibe-123-abc_
	// where the former is a explicit _Building_ instance and the latter is all _Installed Equipment_
	// within any _Building_ instance.
	//
	// _LocationID_ follows the standard glob pattern with the separator of _'#'_.
	LocationID string `json:"lid,omitempty"`
	// ProviderName specifies that the payload must originate from or is, at least part of, targeted to the
	// specified provider.
	//
	// CAUTION: All providers are specified in lowercase letters! Also if a _ProviderName_ is supplied it is
	// _REQUIRED_ to provide a `Direction` as well!
	//
	// If empty or omitted, any provider is accepted.
	ProviderName string `json:"pn,omitempty"`
	// Direction specifies which direction the payload is headed.
	//
	// If omitted or empty (`QualifierDirectionAny`), it will use any direction.
	//
	// CAUTION: If a _ProviderName_ is specified, you have to specify a direction as well. If any way, register
	// two subscriptions.
	Direction SubscriptionPayloadDirection `json:"dir,omitempty"`
}

// end::location-qualifier[]
