package securitymodel

type ProviderCredentials interface {
	// GetEndpoint is the DNS name to the remote endpoint where the credentials is allowed
	// to be posted to. This _Endpoint_ is _REQUIRED_ to be verified *before* invoking the remote endpoint
	GetEndpoint() string
	// Clone will clone the credentials.
	//
	// Each implementation must make sure to return the implementation clone.
	Clone() ProviderCredentials
}

// StandardCredentials is a set of simple credentials to either authenticate a request or
// to extract e.g. an OAuth token from a remote token endpoint.
type StandardCredentials interface {
	ProviderCredentials
	// GetUser is the username to login with
	GetUser() string
	// GetPassword is a plaintext password for the `User`
	GetPassword() string
	// GetAPIKey is a key or subscription key to get access to the APIs
	GetAPIKey() string
}

// TokenCredentials is extending the `StandardCredentials` with a token to use to authenticate the request.
type TokenCredentials interface {
	StandardCredentials
	// GetToken returns the token to use for authenticating the request
	GetToken() []byte
}

// StandardCredentialsImpl do include user, pass and a subscription key
type StandardCredentialsImpl struct {
	// User is the username to login with
	User string `json:"user"          env:"CREDENTIALS_PASSWORD"`
	// Password is a plaintext password for the `User`
	Password string `json:"password"      env:"CREDENTIALS_PASSWORD"`
	// ClientID to authenticate with
	ClientID string `json:"client_id"     env:"CREDENTIALS_CLIENT_ID"`
	// ClientSecret to authenticate with
	ClientSecret string `json:"client_secret" env:"CREDENTIALS_CLIENT_SECRET"`
	// APIKey is a key or subscription key to get access to the APIs
	APIKey string `json:"key"           env:"CREDENTIALS_API_KEY"`
	// Auth when the authentication endpoint is different from the `Endpoint`
	Auth string `json:"auth"          env:"CREDENTIALS_AUTH"`
	// Endpoint is the DNS name to the remote endpoint where the credentials is allowed
	// to be posted to. This _Endpoint_ is _REQUIRED_ to be verified *before* invoking the remote endpoint
	Endpoint string `json:"endpoint"      env:"CREDENTIALS_ENDPOINT"`
}

// FromClientCredentials creates a `StandardCredentialsImpl` from a `ClientCredentialsMaterial`.
//
// It will premium User and Password over ClientId and ClientSecret.
func FromClientCredentials(cc *ClientCredentialsMaterial) *StandardCredentialsImpl {
	sc := &StandardCredentialsImpl{}

	if cc == nil {
		return nil
	}

	if cc.ClientId != "" {
		sc.ClientID = cc.ClientId
	}

	if cc.ClientSecret != "" {
		sc.ClientSecret = cc.ClientSecret
	}

	if cc.User != "" {
		sc.User = cc.User
	}

	if cc.Password != "" {
		sc.Password = cc.Password
	}

	if cc.Key != "" {
		sc.APIKey = cc.Key
	}

	if cc.Auth != "" {
		sc.Auth = cc.Auth
	}

	sc.Endpoint = cc.Endpoint

	return sc
}

// Clone will clone the `StandardCredentialsImpl`
func (sc *StandardCredentialsImpl) Clone() ProviderCredentials {
	return &StandardCredentialsImpl{
		User:     sc.User,
		Password: sc.Password,
		APIKey:   sc.APIKey,
		Endpoint: sc.Endpoint,
	}
}

// GetUser is the username to login with
func (sc *StandardCredentialsImpl) GetUser() string {
	return sc.User
}

// GetPassword is a plaintext password for the `User`
func (sc *StandardCredentialsImpl) GetPassword() string {
	return sc.Password
}

// GetAPIKey is a key or subscription key to get access to the APIs
func (sc *StandardCredentialsImpl) GetAPIKey() string {
	return sc.APIKey
}

// GetEndpoint is the DNS name to the remote endpoint where the credentials is allowed
// to be posted to. This _Endpoint_ is _REQUIRED_ to be verified *before* invoking the remote endpoint
func (sc *StandardCredentialsImpl) GetEndpoint() string {
	return sc.Endpoint
}

// TokenCredentialsImpl contains configuration used in `SessionStore`
type TokenCredentialsImpl struct {
	// Credentials is the credentials to use when authenticate and call APIs on remote endpoint
	Credentials StandardCredentialsImpl `json:"credentials"     pms:"credentials, keyid=default"`
	// Token is a local cached OAuth token (or other token) gotten from an remote token server
	Token []byte `json:"token,omitempty"`
}

// Clone will clone the `TokenCredentialsImpl`
func (tc *TokenCredentialsImpl) Clone() ProviderCredentials {
	return &TokenCredentialsImpl{
		Credentials: StandardCredentialsImpl{
			User:     tc.Credentials.User,
			Password: tc.Credentials.Password,
			APIKey:   tc.Credentials.APIKey,
			Endpoint: tc.Credentials.Endpoint,
		},
		Token: tc.Token,
	}
}

// GetUser is the username to login with
func (tc *TokenCredentialsImpl) GetUser() string {
	return tc.Credentials.User
}

// GetPassword is a plaintext password for the `User`
func (tc *TokenCredentialsImpl) GetPassword() string {
	return tc.Credentials.Password
}

// GetAPIKey is a key or subscription key to get access to the APIs
func (tc *TokenCredentialsImpl) GetAPIKey() string {
	return tc.Credentials.APIKey
}

// GetEndpoint is the DNS name to the remote endpoint where the credentials is allowed
// to be posted to. This _Endpoint_ is _REQUIRED_ to be verified *before* invoking the remote endpoint
func (tc *TokenCredentialsImpl) GetEndpoint() string {
	return tc.Credentials.Endpoint
}

// GetToken returns the token to use for authenticating the request
func (tc *TokenCredentialsImpl) GetToken() []byte {
	return tc.Token
}
