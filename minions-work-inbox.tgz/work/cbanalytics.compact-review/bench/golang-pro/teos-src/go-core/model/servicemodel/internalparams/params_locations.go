package internalparams

import "github.com/Thiink-LLC/teos/go-core/model/servicemodel/parameters"

// locationTypeParams holds the parameter definitions of the location types, keyed by
// parameter name.
var locationTypeParams = map[string]parameters.ParameterDefinition{
	//
	// LocationTypes
	//
	"ALTITUDE": {
		Name:           "ALTITUDE",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "Altitude in a GPS position.",
		Resolution:     "",
		Unit:           parameters.ParameterDegree,
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	"CITY": {
		Name:           "CITY",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A city",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	"COUNTRY": {
		Name:           "COUNTRY",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A country.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	"POSTAL": {
		Name:           "POSTAL",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A postal.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	"STREET": {
		Name:           "STREET",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A street.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	"TZ": {
		Name:           "TZ",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A IANA TimeZone such as Europe/Stockholm.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeString},
	},
	"LAT": {
		Name:           "LAT",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A GPS latitude position.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	"LONG": {
		Name:           "LONG",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A GPS longitude position.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	"RLAT": {
		Name:           "RLAT",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A GPS regional latitude position.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
	"RLONG": {
		Name:           "RLONG",
		IdentifierType: parameters.ParameterIdentifierTypeBase,
		Description:    "A GPS regional longitude position.",
		Resolution:     "",
		Unit:           "",
		Type:           parameters.ParameterType{Base: parameters.ParameterBaseTypeNumber},
	},
}
