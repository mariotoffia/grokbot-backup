package securitymodel

func (cc *ClientCredentialsMaterial) SafeGetUser() string {
	if cc == nil {
		return ""
	}

	return cc.User
}

func (cc *ClientCredentialsMaterial) SafeGetPassword() string {
	if cc == nil {
		return ""
	}

	return cc.Password
}

func (cc *ClientCredentialsMaterial) SafeGetApiKey() string {
	if cc == nil {
		return ""
	}

	return cc.Key
}

func (cc *ClientCredentialsMaterial) Equals(other *ClientCredentialsMaterial) bool {
	if cc == nil && other == nil {
		return true
	}

	if cc != nil && other == nil {
		return false
	}

	if cc == nil && other != nil {
		return false
	}

	if cc.SafeGetUser() != other.SafeGetUser() {
		return false
	}

	if cc.SafeGetPassword() != other.SafeGetPassword() {
		return false
	}

	if cc.SafeGetApiKey() != other.SafeGetApiKey() {
		return false
	}

	if cc.ClientId != other.ClientId {
		return false
	}

	if cc.ClientSecret != other.ClientSecret {
		return false
	}

	return true
}
