package coremodel

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func Test64BitUnixTime(t *testing.T) {
	jt := NewTime64(1600679505000)
	nt, err := jt.WithTimeZone("W. Europe Standard Time")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-09-21 11:11:45 +0200 CEST", nt.String())

}

func Test64BitUnixTimeWithMilliSeconds(t *testing.T) {
	// Input is milliseconds: 1600679505003 = 1600679505 seconds + 3 milliseconds
	jt := NewTime64(1600679505003)
	nt, err := jt.WithTimeZone("W. Europe Standard Time")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-09-21 11:11:45.003 +0200 CEST", nt.String())
}

// TestUTCTime tests that a timestamp is correctly encoded in _UTC_ time format.
func TestUTCTime(t *testing.T) {
	jt := NewTime32(1601902283 /* Monday, October 5, 2020 12:51:23 PM UTC*/)
	nt, err := jt.WithTimeZone("UTC")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-10-05 12:51:23 +0000 UTC", nt.String())
}

func TestWesternEuropeStandardTime(t *testing.T) {
	jt := NewTime32(1601902283 /* Monday, October 5, 2020 12:51:23 PM UTC*/)
	nt, err := jt.WithTimeZone("W. Europe Standard Time")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-10-05 14:51:23 +0200 CEST", nt.String())
}

// TestUTCTimeRFC3339 tests that a timestamp is correctly encoded in _RFC3339_ time format.
func TestUTCTimeRFC3339(t *testing.T) {
	jt := NewTime32(1601902283 /* Monday, October 5, 2020 12:51:23 PM UTC*/)
	nt, err := jt.WithTimeZone("UTC")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-10-05T12:51:23Z", nt.Format(time.RFC3339))
}

// TestUTCTimeSwedishTimeZone test a Unix Epoch Timestamp and put a _Europe/Stockholm_ location
// and print out the contents of it using _model.Time.String()_ to ensure that the format is correct
func TestUTCTimeSwedishTimeZone(t *testing.T) {
	jt := NewTime32(1601902283 /* Monday, October 5, 2020 12:51:23 PM UTC*/)
	nt, err := jt.WithTimeZone("Europe/Stockholm")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-10-05 14:51:23 +0200 CEST", nt.String())
}

// TestUTCTimeSwedishTimeZoneRFC3339 test a Unix Epoch Timestamp and put a _Europe/Stockholm_ location
// and print out the contents of it using format _RFC3339_ to ensure that the format is correct.
func TestUTCTimeSwedishTimeZoneRFC3339(t *testing.T) {
	jt := NewTime32(1601902283 /* Monday, October 5, 2020 12:51:23 PM UTC*/)
	nt, err := jt.WithTimeZone("Europe/Stockholm")

	if err != nil {
		assert.FailNow(t, err.Error())
	}

	assert.Equal(t, "2020-10-05T14:51:23+02:00", nt.Format(time.RFC3339))
}
