package iotmodel

// MQTTCredentials is a struct containing credentials
// to connect a device / system to a _MQTT_ broker.
type MQTTCredentials struct {
	// ID is a vendor specific id that uniquely points out the credentials
	ID string `json:"id"`
	// CredentialsIdentifier is a identifier for this credentials
	CredentialsIdentifier string `json:"certid"`
	// Certificate is a PEM representation of a certificate.
	Certificate string `json:"pem,omitempty"`
	// Public key is a public key.
	PublicKey string `json:"pub,omitempty"`
	// PrivateKey is a private key.
	PrivateKey string `json:"priv,omitempty"`
}
