package dsmodel

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

// SensorModel contains sensors and sensorts maps that adheres to
// _Thiink_ `eqmodel.SensorType` definitions.
type SensorModel struct {
	// Sensors contains the sensor values.
	//
	// Thiink interprets the sensor format in a specific way in order to encode
	// _Circuit_, _Ordinal_ (within circuit or not), and _Zone_ name. All those are
	// optional but thiink reserves certain character combinations in sensor names (_See table below_).
	//
	// image::figures/providerconfig/sensor-format.svg[width="100%", opts=inline]
	//
	// .Examples of Sensor Ids
	// |===
	// |Name |Comments
	//
	// |IDT
	// |Plain sensor with no circuit, ordinal or zone
	//
	// |IDT_O1
	// |Sensor with no circuit, but do have a ordinal (possible more IDT sensors exists), and no zone
	//
	// |RHS_O1_C1
	// |Sensor that is attached to circuit 1 and may exist mor sensors of same kind since ordinal 1, but no zone
	//
	// |RHS_O1_C1_ZmyZone
	// |Same as above but sensor is attached to a zone named _myZone_
	// |===
	Sensors map[string]interface{} `json:"sensors,omitempty"`
	// SensorTimestamps contains Unix 32 bit epoch timestamps, on when a certain
	// `Sensor` with _ID_ was last updated.
	//
	// NOTE: This should never be written to the device shadow. Instead it is used to communicate
	// from a remote system about the last time a certain sensor was updated.
	SensorTimestamps map[string]coremodel.CbTime32 `json:"sensorts,omitempty"`
}

// SensorModelFromDeviceJSON will create a SensorModel from a JSON document where sensors are populated into
// the `Sensors` field and the metadata _timestamps_ for the _Sensors_ are put into `SensorTimeStamps` field.
//
// .Example using the following json data:
// [source,json]
// ----
//
//	{
//		 "state": {
//			"reported": {
//				"sensors": {
//					"IDT_C1_O14": 22.2,
//					"ODT": -26.9
//	  	    }
//	 	},
//	     "metadata": {
//		   		"sensors": {
//					"IDT_C1_O14": {
//						"timestamp": "1628763518",
//	             },
//					"ODT": {
//						"timestamp": "1628763518",
//					}
//				}
//		 	}
//		 }
//	}
//
// ----
func SensorModelFromDeviceJSON(c ifcore.CbContext, data []byte) (*SensorModel, cberror.Error) {
	// Use a local specific model to unmarshal sensor data and metadata timestamps.
	type LocalSensorModel struct {
		State struct {
			Reported struct {
				Sensors map[string]interface{} `json:"sensors,omitempty"`
			} `json:"reported"`
		} `json:"state"`
		Metadata struct {
			Reported DsBuildingMeta `json:"reported,omitempty"`
		} `json:"metadata,omitempty"`
	}

	var local LocalSensorModel
	if err := json.Unmarshal(data, &local); err != nil {
		return nil, cberror.NewCbErrorf(
			c.Service(), cberror.ErrorProviderUnableToCreateBuildingFromShadow, err,
			"Failed create dsBuilding JSON: '%s' error: %s",
			string(data), err.Error())
	}

	sensors := &SensorModel{
		Sensors:          local.State.Reported.Sensors,
		SensorTimestamps: map[string]coremodel.CbTime32{},
	}

	if nil != local.Metadata.Reported.Sensors {
		for k, v := range local.Metadata.Reported.Sensors {
			sensors.SensorTimestamps[k] = v.Timestamp
		}
	}

	return sensors, nil

}
