package coremodel_test

import (
	"regexp"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

type organizationIDCase struct {
	name string
	id   string
	ok   bool
}

// organizationIDCases are the values ValidateOrganizationID accepts (ok) and refuses.
func organizationIDCases() []organizationIDCase {
	long128 := strings.Repeat("a", 128)

	return []organizationIDCase{
		{"one segment", "skebo", true},
		{"digits", "1234", true},
		{"dotted", "thiink.us.branchoffice", true},
		{"default", coremodel.DefaultOrganizationID, true},
		{"128 characters", long128, true},
		{"129 characters", long128 + "a", false},
		{"empty", "", false},
		{"uppercase", "Skebo", false},
		{"hyphen", "umea-energi", false},
		{"comma", "a,b", false},
		{"equals", "ou=a", false},
		{"space", "a b", false},
		{"empty segment", "a..b", false},
		{"leading dot", ".a", false},
		{"trailing dot", "a.", false},
		{"non-ASCII", "umeå", false},
		{"all, which covers every organization", coremodel.All, false},
		{"key delimiter", "a#b", false},
	}
}

func TestValidateOrganizationID(t *testing.T) {
	for _, tc := range organizationIDCases() {
		t.Run(tc.name, func(t *testing.T) {
			err := coremodel.ValidateOrganizationID(tc.id)
			if tc.ok {
				require.NoError(t, err)
				return
			}

			require.ErrorIs(t, err, coremodel.ErrInvalidOrganizationID)
		})
	}
}

func TestValidateOrganizationIDRefusesAll(t *testing.T) {
	err := coremodel.ValidateOrganizationID(coremodel.All)

	require.ErrorIs(t, err, coremodel.ErrInvalidOrganizationID)
	require.ErrorContains(t, err, `"all" covers every organization`)
}

func TestValidateOwnerIDAcceptsAll(t *testing.T) {
	require.NoError(t, coremodel.ValidateOwnerID(coremodel.All))
	require.NoError(t, coremodel.ValidateOwnerID("thiink.us"))
	require.ErrorIs(t, coremodel.ValidateOwnerID("$system"), coremodel.ErrInvalidOrganizationID)
	require.ErrorIs(t, coremodel.ValidateOwnerID("Thiink"), coremodel.ErrInvalidOrganizationID)
}

// The owner ID pattern has no length limit, so the values here must all be at most
// OrganizationIDMaxLength characters long.
func TestOwnerIDPatternAcceptsWhatValidateOwnerIDAccepts(t *testing.T) {
	ownerIDPattern := regexp.MustCompile(coremodel.OwnerIDPattern)

	ids := []string{"$system", "xall", "allx", "all.us", "All", "$"}
	for _, tc := range organizationIDCases() {
		if len(tc.id) <= coremodel.OrganizationIDMaxLength {
			ids = append(ids, tc.id)
		}
	}

	for _, id := range ids {
		require.Equal(t, coremodel.ValidateOwnerID(id) == nil, ownerIDPattern.MatchString(id),
			"owner ID %q", id)
	}
}

func TestOrganizationIDErrorNamesTheValueAndTheFormat(t *testing.T) {
	err := coremodel.ValidateOrganizationID("umea-energi")

	require.ErrorContains(t, err, `"umea-energi"`)
	require.ErrorContains(t, err, "lowercase letters")
}

func TestOrganizationIDLengthErrorStatesTheLengthAndTheLimit(t *testing.T) {
	err := coremodel.ValidateOrganizationID(strings.Repeat("a", 129))

	require.ErrorIs(t, err, coremodel.ErrInvalidOrganizationID)
	require.ErrorContains(t, err, "is 129 characters long; the limit is 128")
}

// Every case here must be longer than 64 characters, or it cannot tell whether the value was
// shortened.
func TestOrganizationIDErrorShortensALongValue(t *testing.T) {
	tests := []struct {
		name  string
		id    string
		first string
	}{
		{"too long", strings.Repeat("a", 129), strings.Repeat("a", 64)},
		{"wrong format", strings.Repeat("A", 10000), strings.Repeat("A", 64)},
		{"non-ASCII", strings.Repeat("å", 100), strings.Repeat("å", 64)},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := coremodel.ValidateOrganizationID(tc.id)

			require.ErrorIs(t, err, coremodel.ErrInvalidOrganizationID)
			require.ErrorContains(t, err, `"`+tc.first+`" (shortened to its first 64 characters)`)
			require.Less(t, len(err.Error()), 400)
		})
	}
}
