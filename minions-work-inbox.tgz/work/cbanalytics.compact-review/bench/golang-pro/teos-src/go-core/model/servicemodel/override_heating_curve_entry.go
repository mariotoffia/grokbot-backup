package servicemodel

import (
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/model/servicemodel/core"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// Represents a slice of heating curve entries.
type HeatingCurveEntries []HeatingCurveEntry

// String returns the representation of the heating curve entries on format
// "[HeatingCurveEntry, HeatingCurveEntry, ...]".
//
// For example: [[-30,75],[-15,60],[-5,50],[0,45],[5,40],[15,30]]
func (hce HeatingCurveEntries) String() string {
	if hce == nil {
		return ""
	}

	result := "["
	for i, v := range hce {
		if i > 0 {
			result += ","
		}

		result += v.String()
	}

	return result + "]"
}

// String returns the representation of the heating curve entry on format
// "[OutdoorTriggerTemp, SupplyTemp]" rounded to 2 decimals.
func (hce *HeatingCurveEntry) String() string {
	if hce == nil {
		return ""
	}

	return fmt.Sprintf(
		"[%.1f,%.1f]",
		hce.OutdoorTriggerTemp,
		utils.ConvertToFloat64(hce.SupplyTemp, 2),
	)
}

type HeatingServiceConfig struct {
	// OBT is the outdoor break temperature when the heating system is turned on
	OBT float64
	// ITT is the indoor target temperature that the algorithm strives to achieve
	ITT float64
	// ITL is the indoor low threshold temperature where the algorithm will stop interacting
	ITL float64
	// OCP is the control principle to use when controlling the heating system (e.g. offset outdoor temperature or direct on setpoint)
	OCP string
	// ESL is the max effect level the system may use
	ESL TeosEffectServiceLevels
	// HCT is the heating curve entries
	HCT HeatingCurveEntries
}

func CreateServiceConfigForDistrictHeatingBuildingService(
	cfg HeatingServiceConfig,
) *core.ServiceConfig {
	return &core.ServiceConfig{
		Realizes: &core.ServiceRealization{
			Type:       []core.ServiceType{core.ServiceTypeHeating},
			Technology: []core.ServiceTechnologyType{core.DistrictHeating},
			Location:   []core.ServiceLocationTarget{core.ServiceLocationTargetBuilding},
		},
		AdditionalProperties: map[string]any{
			"OBT": cfg.OBT,
			"ITT": cfg.ITT,
			"ITL": cfg.ITL,
			"ESL": cfg.ESL,
			"HCT": cfg.HCT,
			"OCP": cfg.OCP,
		}}
}
