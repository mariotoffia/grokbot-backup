package securitymodel

import (
	"slices"
	"strings"
	"unicode"
)

// CallerType distinguishes between machine-to-machine app tokens (client_credentials),
// user tokens (authorization_code) and requests without a token.
type CallerType string

const (
	// CallerTypeApp indicates a client_credentials token (no user subject).
	CallerTypeApp CallerType = "app"
	// CallerTypeUser indicates an authorization_code token (a user subject).
	CallerTypeUser CallerType = "user"
	// CallerTypeNone indicates a request without a token: the token has no
	// subject and no client_id claim.
	CallerTypeNone CallerType = "none"
)

// OAuth 2.0 grant type identifiers returned by GrantType().
const (
	GrantTypeAuthorizationCode = "authorization_code"
	GrantTypeClientCredentials = "client_credentials"
	GrantTypeTokenExchange     = "urn:ietf:params:oauth:grant-type:token-exchange" //nolint:gosec // G101: RFC 8693 grant type URI, not a credential
	GrantTypeNone              = "none"
)

// CallerType returns whether this token represents a user, an app (machine) or
// no caller at all.
func (t *OpenIDConnectToken) CallerType() CallerType {
	if t.Subject == "" && t.ClientID() == "" {
		return CallerTypeNone
	}
	if t.IsAppToken() {
		return CallerTypeApp
	}
	return CallerTypeUser
}

// GrantType returns the OAuth 2.0 grant type that produced this token.
//
// Detection logic:
//   - No caller (see CallerType returning CallerTypeNone) → none
//   - Actor present (RFC 8693 structured act) → token exchange
//   - An app token (see IsAppToken) → client_credentials (M2M token)
//   - Otherwise → authorization_code (user token)
func (t *OpenIDConnectToken) GrantType() string {
	if t.CallerType() == CallerTypeNone {
		return GrantTypeNone
	}
	if t.Actor != nil {
		return GrantTypeTokenExchange
	}
	if t.IsAppToken() {
		return GrantTypeClientCredentials
	}
	return GrantTypeAuthorizationCode
}

// IsExchangeToken returns true if this token was produced by an RFC 8693 token
// exchange (delegation). This is detected by the presence of a structured Actor claim.
func (t *OpenIDConnectToken) IsExchangeToken() bool {
	return t.Actor != nil
}

// IsUserToken returns true if this is a user-issued token (authorization_code flow).
func (t *OpenIDConnectToken) IsUserToken() bool {
	return !t.IsAppToken()
}

// IsAppToken returns true if this is a machine-to-machine token (client_credentials
// flow): it has no subject, or its subject is the app client ID. Cognito sets sub
// to the app client ID in a client_credentials access token (RFC 9068 section
// 2.2); a user's token has the user's own ID as sub.
func (t *OpenIDConnectToken) IsAppToken() bool {
	return t.Subject == "" || t.Subject == t.ClientID()
}

// CognitoGroups extracts the cognito:groups claim from the token, in either
// shape ClaimList reads. Cognito automatically includes this reserved claim for
// users in groups. Returns nil for app tokens or users not in any group.
func (t *OpenIDConnectToken) CognitoGroups() []string {
	return ClaimList(t.Claims["cognito:groups"])
}

// ClaimList reads a claim that lists names, such as cognito:groups, rsid or
// oid. A decoded JWT and the local emulator hold such a claim as a list of
// strings. API Gateway on AWS passes it as one string, which ClaimList splits on
// spaces and commas, after dropping a leading "[" and a trailing "]" of the
// whole string: such a string may be "a,b", "a b" or "[a b]". No group name,
// owner ID or remote system ID holds a bracket. List items are trimmed of
// surrounding spaces, and empty and non-string items are dropped. It returns
// nil when no name is left.
func ClaimList(claim any) []string {
	var items []string

	switch v := claim.(type) {
	case string:
		v = strings.TrimSuffix(strings.TrimPrefix(strings.TrimSpace(v), "["), "]")
		items = strings.FieldsFunc(v, func(r rune) bool { return r == ',' || unicode.IsSpace(r) })
	case []string:
		items = v
	case []any:
		for _, item := range v {
			if s, ok := item.(string); ok {
				items = append(items, s)
			}
		}
	}

	var out []string

	for _, s := range items {
		if s = strings.TrimSpace(s); s != "" {
			out = append(out, s)
		}
	}

	return out
}

// HasCognitoGroup returns true if the token's cognito:groups claim contains the
// specified group name.
func (t *OpenIDConnectToken) HasCognitoGroup(group string) bool {
	return slices.Contains(t.CognitoGroups(), group)
}

// ClientID extracts the client_id claim from the token.
// Both user and app tokens include this claim identifying the Cognito app client.
func (t *OpenIDConnectToken) ClientID() string {
	if t.Claims == nil {
		return ""
	}
	if v, ok := t.Claims["client_id"].(string); ok {
		return v
	}
	return ""
}

// TokenUse extracts the token_use claim ("access" or "id").
func (t *OpenIDConnectToken) TokenUse() string {
	if t.Claims == nil {
		return ""
	}
	if v, ok := t.Claims["token_use"].(string); ok {
		return v
	}
	return ""
}

// EnrichSecurityContext adds caller-type fields to a PDP security context map
// so OPA policies can use input.sc.caller_type, input.sc.groups, input.sc.act, etc.
// It overwrites the keys it writes and leaves every other entry of sc alone.
//
// The lists scopes, groups and oid are always written, empty when the token has
// none. A missing list makes a Rego rule such as `not g in input.sc.groups` let a
// caller with no groups through, so the lists are always present.
func EnrichSecurityContext(sc map[string]any, token *OpenIDConnectToken) {
	if sc == nil || token == nil {
		return
	}

	sc["caller_type"] = string(token.CallerType())
	sc["grant_type"] = token.GrantType()
	sc["sub"] = token.Subject
	sc["client_id"] = token.ClientID()
	sc["scopes"] = strings.Fields(token.Scope)

	groups := token.CognitoGroups()
	if groups == nil {
		groups = []string{}
	}
	sc["groups"] = groups

	oid := token.OID
	if oid == nil {
		oid = []string{}
	}
	sc["oid"] = oid

	if token.Actor != nil {
		sc["is_exchange"] = true
		sc["act"] = token.Actor.MarshalMap()
	}
}
