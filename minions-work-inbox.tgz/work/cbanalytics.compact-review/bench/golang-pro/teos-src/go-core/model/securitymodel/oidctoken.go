package securitymodel

import (
	"encoding/json"
	"strings"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/utils/textutils"
)

type OpenIDConnectTokenConfig struct {
	// RenderSingleAudienceIfSingle specifies that it will render a string instead
	// of a string array when a single audience is encountered.
	//
	// Default is to render it as a string array.
	RenderSingleAudienceIfSingle bool
	// RenderActorInString will make sure that the actor is rendered in a string instead of
	// a _JSON_ object. If only _sub_ is present, it will just be the value of _sub_ inside the
	// string (instead of _JSON_ object).
	RenderActorInShortString bool
}

type OIDCMaterialType int

const (
	OIDCMaterialTypeUnknown        OIDCMaterialType = 0
	OIDCMaterialTypeNotPresent     OIDCMaterialType = 1
	OIDCMaterialTypeJWT            OIDCMaterialType = 2
	OIDCMaterialTypeEncryptedToken OIDCMaterialType = 3
)

// tag::oidc-token[]

// OpenIDConnectToken is a set of claims defined for the https://tools.ietf.org/html/rfc7519#RFC7519
//
// It has a custom un-/marshaller attached to it in order to handle extra claims properly.
type OpenIDConnectToken struct {
	// Material is the raw material of the token (e.g. the JWT)
	Material []byte `json:"-"`
	// MaterialType is the type of the material (e.g. JWT)
	MaterialType OIDCMaterialType `json:"-"`
	// Config is a optional configuration how to process this token
	Config OpenIDConnectTokenConfig `json:"-"`
	// Audience is the base address of the license / system resource  e.g. https://nordvestor.api.crossbreeed.se
	//
	// Defined as "aud" in https://tools.ietf.org/html/rfc7519
	Audience []string `json:"aud,omitempty"`
	// Issuer specifies the principal that issued the license e.g. "https://nordvestor.api.crossbreeed.se/cognito"
	//
	// Defined as "iss" in https://tools.ietf.org/html/rfc7519
	Issuer string `json:"iss,omitempty"`
	// Subject is the principal that is the subject of the API access e.g. "8c059ae6-dee7-4145-a6dc-d2820b4adf70" or
	// "nisse@hult.se".
	//
	// Defined as "sub" in https://tools.ietf.org/html/rfc7519.
	Subject string `json:"sub,omitempty"`
	// Expires is the number of seconds when the license expires based on unix 32 bit epoch time (
	// from 1970-01-01T00:00:00Z) see RFC 3339 for more details. For example 1609231906 is 2020-12-29T08:51:46Z.
	//
	// Defined as "exp" in https://tools.ietf.org/html/rfc7519.
	Expires coremodel.CbTime32 `json:"exp,omitempty"`
	// Issued at is a unix 32 bit epoch time when the license was issued.
	//
	// Defined as "iat" in https://tools.ietf.org/html/rfc7519.
	Issued coremodel.CbTime32 `json:"iat,omitempty"`
	// NotBefore at is a unix 32 bit epoch time when the license is activated (this may be in future!).
	//
	// Defined as "nbf" in https://tools.ietf.org/html/rfc7519.
	NotBefore coremodel.CbTime32 `json:"nbf,omitempty"`
	// JTI is a unique identifier for the JWT that prevents replay protection
	//
	// Defined as "jti" in https://tools.ietf.org/html/rfc7519#section-4.1.7.
	JTI string `json:"jti,omitempty"`
	// Scope is a space separated string of the scope that this _JWT_ grants.
	//
	// Defines as "scope" in https://www.rfc-editor.org/rfc/rfc8693.html#name-scope-scopes-claim
	Scope string `json:"scope,omitempty"`
	// Actor is the "act" in the https://datatracker.ietf.org/doc/html/rfc8693#name-act-actor-claim[OAuth 2.0 Token Exchange]
	// specification.
	Actor *Actor `json:"-"`
	// OID is the Organisation ID claim. It holds one or more organisation identifiers
	// that the caller is associated with. For user tokens the claim is injected by
	// the Pre-Token-Gen V2_0 trigger; for M2M tokens it is scope-encoded as
	// teos/c-oid:<value> (comma-separated for multiple).
	OID []string `json:"oid,omitempty"`
	// This is the Remote System ID claim. It is the unique identifier of the remote system. This needs to match one of the
	// configured  remote system ID in the deployed product. A token that names several remote systems holds them as
	// one comma-separated string, such as "site-a,site-b", whether the claim came as a list or as a string.
	RemoteSystemID string `json:"rsid,omitempty"`
	// Claims is a set of extra claims that is not standardized.
	//
	// Note that these are populated from the root that do not match the well known claims.
	Claims map[string]any `json:"-"`
}

// HasExpired checks if the token has expired. The guardZone is a time.Duration that is used to
// guard against clock skew or if communication is slow.
func (oidc *OpenIDConnectToken) HasExpired(guardZone time.Duration) bool {
	return oidc.Expires.Before(coremodel.NewTime32Now().CbTime32UTC().Add(guardZone))
}

// IsAfterNotBefore checks if the token is valid to use. It makes sure that
// the token is not used before it is valid.
//
// If `NotBefore` is not set, it will return `true`.
//
// Use this and `HasExpired` to check if the token is valid.
func (oidc *OpenIDConnectToken) IsAfterNotBefore() bool {
	if oidc.NotBefore.IsZero() {
		return true
	}

	return oidc.NotBefore.Before(coremodel.NewTime32Now().CbTime32UTC())
}

// HasScope verifies that a certain scope is present in the token.
func (oidc *OpenIDConnectToken) HasScope(scope string) bool {
	if !strings.Contains(oidc.Scope, scope) {
		return false
	}

	for _, s := range strings.Split(oidc.Scope, " ") {
		if s == scope {
			return true
		}
	}

	return false
}

// HasOID returns true if the given organisation ID is present in the token's OID list.
func (oidc *OpenIDConnectToken) HasOID(oid string) bool {
	for _, o := range oidc.OID {
		if o == oid {
			return true
		}
	}
	return false
}

// PrimaryOID returns the first organisation ID or an empty string when none is set.
func (oidc *OpenIDConnectToken) PrimaryOID() string {
	if len(oidc.OID) == 0 {
		return ""
	}
	return oidc.OID[0]
}

// ClaimAsBool will return the value of the claim as a bool.
//
// If the claim is not present or not a bool it will return false and false.
func (oidc *OpenIDConnectToken) ClaimAsBool(key string) (bool, bool) {
	if value, ok := oidc.Claims[key]; ok {
		if value, ok := value.(bool); ok {
			return value, true
		}

		return false, false
	}

	return false, false
}

// ClaimAsString will return the value of the claim as a string.
//
// If the claim is not present or not a string it will return "" and false.
func (oidc *OpenIDConnectToken) ClaimAsString(key string) (string, bool) {
	if value, ok := oidc.Claims[key]; ok {
		if value, ok := value.(string); ok {
			return value, true
		}

		return "", false
	}

	return "", false
}

// ClaimsAsStringSlice will return the value of the claim as a string slice.
func (oidc *OpenIDConnectToken) ClaimsAsStringSlice(key string) ([]string, bool) {
	if value, ok := oidc.Claims[key]; ok {
		if value, ok := value.([]string); ok {
			return value, true
		}

		return nil, false
	}

	return nil, false
}

// ClaimAsInt64 will return the value of the claim as a int64.
//
// If the claim is not present or not a int64 it will return 0 and false.
func (oidc *OpenIDConnectToken) ClaimAsInt64(key string) (int64, bool) {
	if value, ok := oidc.Claims[key]; ok {
		if value, ok := value.(int64); ok {
			return value, true
		}

		return 0, false
	}

	return 0, false
}

// end::oidc-token[]

// MarshalJSON will marshal the `OpenIDConnectToken` so the standard claims is
// taken from the Fields and the `Claims` map is merged on root level.
//
// Hence, marshal supports both extra root level claims and nested claims.
//
// CAUTION: This receiver is not accepting a pointer to `OpenIDConnectToken` as
// to allow for embedding of this struct in other structs.
func (oidc OpenIDConnectToken) MarshalJSON() ([]byte, error) {
	m := map[string]interface{}{}

	for key, value := range oidc.Claims {
		m[key] = value
	}

	if len(oidc.Audience) > 0 {
		if oidc.Config.RenderSingleAudienceIfSingle &&
			len(oidc.Audience) == 1 {
			m["aud"] = oidc.Audience[0]
		} else {
			m["aud"] = oidc.Audience
		}
	}
	if len(oidc.Issuer) > 0 {
		m["iss"] = oidc.Issuer
	}
	if len(oidc.Subject) > 0 {
		m["sub"] = oidc.Subject
	}
	if !oidc.Expires.IsZero() {
		m["exp"] = oidc.Expires
	}
	if !oidc.Issued.IsZero() {
		m["iat"] = oidc.Issued
	}
	if !oidc.NotBefore.IsZero() {
		m["nbf"] = oidc.NotBefore
	}
	if len(oidc.JTI) > 0 {
		m["jti"] = oidc.JTI
	}
	if len(oidc.Scope) > 0 {
		m["scope"] = oidc.Scope
	}

	if len(oidc.OID) > 0 {
		m["oid"] = oidc.OID
	}

	if oidc.RemoteSystemID != "" {
		m["rsid"] = oidc.RemoteSystemID
	}

	if oidc.Actor != nil {
		if oidc.Config.RenderActorInShortString {
			m["act"] = oidc.Actor.String()
		} else {
			m["act"] = oidc.Actor.MarshalMap()
		}
	}

	return json.Marshal(&m)
}

// UnmarshalJSON will unmarshal the `OpenIDConnectToken` so the standard claims is
// written to the Fields and the `Claims` map is receiving additional claims from the root level.
//
// Hence, unmarshal supports both extra root level claims and nested claims.
func (oidc *OpenIDConnectToken) UnmarshalJSON(token []byte) error {
	var m map[string]any
	if err := json.Unmarshal(token, &m); err != nil {
		return err
	}

	return oidc.UnmarshalMap(m, token, OIDCMaterialTypeJWT)
}

// UnmarshalMap unmarshals the `OpenIDConnectToken` the same way as `UnmarshalJSON`,
// but from a `map[string]any` instead of `[]byte`.
//
// The teos/c-{claim}:{value} claim scopes are always removed from Scope. They
// are decoded into claims only for a machine token (see IsAppToken), after
// every direct claim is read: a non-empty direct claim wins over the same
// claim encoded as a scope, whatever the order of the claims. A user's claim
// scopes are dropped unread, so a scope cannot give a user a remote system or
// any other claim.
func (oidc *OpenIDConnectToken) UnmarshalMap(
	token map[string]any,
	material []byte,
	materialType OIDCMaterialType,
) error {
	oidc.Material = material
	oidc.MaterialType = OIDCMaterialTypeJWT
	oidc.Claims = map[string]any{}

	var scopeClaims map[string]any

	for key, value := range token {
		switch key {
		case "aud":
			oidc.Audience = valueToStringArray(value)
		case "iss":
			oidc.Issuer = value.(string)
		case "sub":
			oidc.Subject = value.(string)
		case "exp":
			oidc.Expires = *coremodel.NewTime32ByInterface(value)
		case "iat":
			oidc.Issued = *coremodel.NewTime32ByInterface(value)
		case "nbf":
			oidc.NotBefore = *coremodel.NewTime32ByInterface(value)
		case "jti":
			oidc.JTI = value.(string)
		case "scope":
			oidc.Scope, scopeClaims = claimsFromScope(value.(string))
		case "oid":
			oidc.OID = ClaimList(value)
		case "rsid":
			oidc.RemoteSystemID = strings.Join(ClaimList(value), ",")
		case "act":
			switch v := value.(type) {
			case map[string]any:
				actor := &Actor{}
				if err := actor.UnmarshalMap(v); err == nil {
					oidc.Actor = actor
				}
			case string:
				// A string act (from packs/custom attributes) is stored as a plain
				// claim. Do NOT interpret it as an RFC 8693 actor.
				oidc.Claims["act"] = v
			}
		default:
			oidc.Claims[key] = value
		}
	}

	if oidc.IsAppToken() {
		oidc.addScopeClaims(scopeClaims)
	}

	return nil
}

// addScopeClaims fills the fields and claims that the direct claims left empty
// from claims, the claims decoded from the teos/c-* scopes.
func (oidc *OpenIDConnectToken) addScopeClaims(claims map[string]any) {
	for k, v := range claims {
		switch k {
		case "oid":
			if len(oidc.OID) == 0 {
				oidc.OID = valueToStringArray(v)
			}
		case "rsid":
			if s, ok := v.(string); ok && oidc.RemoteSystemID == "" {
				oidc.RemoteSystemID = s
			}
		default:
			if cur, set := oidc.Claims[k]; !set || cur == "" {
				oidc.Claims[k] = v
			}
		}
	}
}

// claimsFromScope extracts any 'teos/c-' encoded claims from the scope string.
//
// Returns the scope string with claim-scopes removed, and a map of extracted claims.
//
//   - M2M tokens (client_credentials): Claims are scope-encoded as teos/c-{name}:{value}
//     because Cognito V2_0 triggers do NOT fire for M2M flows. This is the only
//     mechanism for M2M claim injection.
//   - User tokens (auth code): Claims are injected directly by Pre-Token-Gen V2_0
//     into ClaimsToAddOrOverride. UnmarshalMap ignores a user token's claim scopes.
func claimsFromScope(scope string) (string, map[string]any) {

	if scope == "" || !strings.Contains(scope, "teos/c-") {
		return scope, nil
	}

	split := strings.Split(scope, " ")
	scope = ""

	var m map[string]any

	for _, s := range split {
		if !strings.HasPrefix(s, "teos/c-") {
			if scope != "" {
				scope += " " + s
			} else {
				scope = s
			}

			continue
		}

		kv := strings.Split(s[7:], ":")

		if m == nil {
			m = map[string]any{}
		}

		if len(kv) == 1 {
			m[kv[0]] = true
			continue
		}

		switch {
		case kv[0] == "rsid":
			// Identifiers keep their text: the rsid "007" is not the number 7.
			m[kv[0]] = kv[1]
		case kv[0] == "oid":
			m[kv[0]] = strings.Split(kv[1], ",")
		case kv[1] == "true":
			m[kv[0]] = true
		case kv[1] == "false":
			m[kv[0]] = false
		default:
			if i, ok := textutils.ConvertFromStringToIntegerIfDigitOnly(kv[1]); ok {
				m[kv[0]] = i
			} else if strings.Contains(kv[1], ",") {
				m[kv[0]] = strings.Split(kv[1], ",")
			} else {
				m[kv[0]] = kv[1]
			}
		}
	}

	return scope, m
}

func valueToStringArray(value interface{}) []string {
	switch v := value.(type) {
	case string:
		return []string{v}
	case []interface{}:
		s := make([]string, 0, len(v))
		for _, val := range v {
			value, ok := val.(string)
			if !ok {
				return []string{}
			}
			s = append(s, value)
		}
		return s
	case []string:
		return v
	}

	return []string{}
}
