package coremodel

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// TeosDuration is a `time.Duration` but may be marshalled to JSON as a string
type TeosDuration time.Duration

// TeosDurationParse will return the _d_ from the string. If it fails
// it will return _0_.
//
// CAUTION: If a duration string of zero, use `time.Duration` parse function instead.
func TeosDurationParse(d string) TeosDuration {
	duration, err := time.ParseDuration(d)
	if err != nil {
		return 0
	}

	return TeosDuration(duration)
}

// MarshalJSON converts the duration to a JSON string
func (d TeosDuration) MarshalJSON() ([]byte, error) {

	return []byte(`"` + d.String() + `"`), nil
}

// UnmarshalJSON parses the duration from a JSON string
func (d *TeosDuration) UnmarshalJSON(b []byte) error {
	if len(b) == 0 {
		return fmt.Errorf("empty duration, expecting a string")
	}

	// Remove the quotes from the JSON string
	durationString := string(b[1 : len(b)-1])
	duration, err := time.ParseDuration(durationString)

	if err != nil {
		return err
	}

	*d = TeosDuration(duration)
	return nil
}

// ToDuration converts to a `time.Duration`
func (d *TeosDuration) ToDuration() time.Duration {
	if d == nil {
		return 0
	}

	return time.Duration(*d)
}

// String is the string representation of the duration (it will cutoff any trailing 0s)
func (d TeosDuration) String() string {
	dur := time.Duration(d).String()

	if strings.HasSuffix(dur, "m0s") {
		dur = strings.TrimSuffix(dur, "0s")
	}

	return dur
}

// iso8601Re is a regular expression that matches an ISO8601 duration string.
var iso8601Re = regexp.MustCompile(`^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$`)

// TeosDurationFromISO8601 parses a ISO8601 duration string and returns a time.Duration.
func TeosDurationFromISO8601(pt string) (TeosDuration, error) {
	// Find the matches using the regular expression
	matches := iso8601Re.FindStringSubmatch(pt)
	if len(matches) == 0 {
		return 0, fmt.Errorf("invalid PT duration format")
	}

	// Initialize the total duration
	var totalDuration time.Duration

	// Parse the hours, minutes, and seconds if they are present
	if matches[1] != "" {
		hours, err := strconv.Atoi(matches[1])
		if err != nil {
			return 0, fmt.Errorf("invalid hours value: %w", err)
		}
		totalDuration += time.Duration(hours) * time.Hour
	}

	if matches[2] != "" {
		minutes, err := strconv.Atoi(matches[2])
		if err != nil {
			return 0, fmt.Errorf("invalid minutes value: %w", err)
		}
		totalDuration += time.Duration(minutes) * time.Minute
	}

	if matches[3] != "" {
		seconds, err := strconv.Atoi(matches[3])
		if err != nil {
			return 0, fmt.Errorf("invalid seconds value: %w", err)
		}
		totalDuration += time.Duration(seconds) * time.Second
	}

	return TeosDuration(totalDuration), nil
}
