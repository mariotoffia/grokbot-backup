package rtc_test

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/rtc"
)

type TestMap map[string]rtc.RtcValue

func TestUnmarshalFloat32(t *testing.T) {
	data := []byte(`{"float32": 1.12}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, float32(1.12), *v["float32"].Float32)
}

func TestUnmarshalString(t *testing.T) {
	data := []byte(`{"string": "test"}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, "test", *v["string"].String)
}

func TestUnmarshalBool(t *testing.T) {
	data := []byte(`{"bool": true}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, true, *v["bool"].Bool)
}

func TestUnmarshalInt64(t *testing.T) {
	data := []byte(`{"int64": 123}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, int64(123), *v["int64"].Int64)
}

func TestUnmarshalArrayOfFloat32(t *testing.T) {
	data := []byte(`{"arrayOfFloat32": [1.12, 2.34]}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, float32(1.12), (*v["arrayOfFloat32"].ArrayOfFloat32)[0])
	assert.Equal(t, float32(2.34), (*v["arrayOfFloat32"].ArrayOfFloat32)[1])
}

func TestUnmarshalArrayOfString(t *testing.T) {
	data := []byte(`{"arrayOfString": ["test1", "test2"]}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, "test1", (*v["arrayOfString"].ArrayOfString)[0])
	assert.Equal(t, "test2", (*v["arrayOfString"].ArrayOfString)[1])
}

func TestUnmarshalArrayOfBool(t *testing.T) {
	data := []byte(`{"arrayOfBool": [true, false]}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, true, (*v["arrayOfBool"].ArrayOfBool)[0])
	assert.Equal(t, false, (*v["arrayOfBool"].ArrayOfBool)[1])
}

func TestUnmarshalArrayOfInt64(t *testing.T) {
	data := []byte(`{"arrayOfInt64": [123, 456]}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, int64(123), (*v["arrayOfInt64"].ArrayOfInt64)[0])
	assert.Equal(t, int64(456), (*v["arrayOfInt64"].ArrayOfInt64)[1])
}

func TestUnmarshalInt64andFloat32(t *testing.T) {
	data := []byte(`{"int64": 123, "float32": 1.12}`)

	var v TestMap

	err := json.Unmarshal(data, &v)

	require.NoError(t, err)

	assert.Equal(t, int64(123), *v["int64"].Int64)
	assert.Equal(t, float32(1.12), *v["float32"].Float32)
}
