package coremodel

import (
	"fmt"
	"strings"
)

// Capabilities is a set of `Capability` instances.
type Capabilities struct {
	// Caps contains all capabilities.
	Caps []Capability `json:"capabilities,omitempty"`
}

// GetByName searches for a capability whose `Capability.Name` case-sensitive matches.
//
// If not found, `false` is returned.
func (c *Capabilities) GetByName(name string) (Capability, bool) {
	if len(c.Caps) == 0 {
		return Capability{}, false
	}

	for i := range c.Caps {
		if c.Caps[i].Name == name {
			return c.Caps[i], true
		}
	}

	return Capability{}, false
}

// Has checks if a capability with the name exists.
func (c *Capabilities) Has(name string) bool {
	_, ok := c.GetByName(name)
	return ok
}

// StringByName will look for the capability by _name_ and return the value.
//
// If not found it will return _d_. If it is found it will do a `Capability.String()`
// and return that.
func (c *Capabilities) StringByName(name string, d string) string {
	if v, ok := c.GetByName(name); ok {
		return v.String()
	}

	return d
}

// IntegerByName will look for the capability by _name_ and return the value.
//
// If found, it will do a `Capability.Integer()` otherwise _d_ is returned. If
// is not found `0` is returned.
func (c *Capabilities) IntegerByName(name string, d int64) int64 {
	if v, ok := c.GetByName(name); ok {
		return v.Integer()
	}

	return d
}

// BooleanByName will look for the capability by _name_ and return the value.
//
// If found, it will do a `Capability.Boolean()` otherwise _d_ is returned.
// If it is not found, `false` is returned.
func (c *Capabilities) BooleanByName(name string, d bool) bool {
	if v, ok := c.GetByName(name); ok {
		return v.Boolean()
	}

	return d
}

// Capability represents a single named capability such as queue.fifo or
// message.maxsize. The value is optional since e.g. queue.fifo is a boolean
// and thus the value could be omitted.
//
// .Value Types
//
// * bool
// * string
// * int8, int16, int32, int64, int
type Capability struct {
	Name  string      `json:"name"`
	Value interface{} `json:"value,omitempty"`
}

// String gets or converts the _Value_ part of the capability as a string.
//
// If no value, an _true_ string is returned (since no value is considered as
// a has capability statement).
func (c Capability) String() string {
	if c.Value == nil {
		return "true"
	}

	if v, ok := c.Value.(string); ok {
		return v
	}

	return fmt.Sprintf("%v", c.Value)
}

// Boolean gets or converts _Value_ to a boolean. If the value is missing it will return true.
//
// If the value is not a boolean but the value is a integer it will return true if value
// above zero. If the value is a string and contains true it returns `true` (`false` otherwise).
func (c Capability) Boolean() bool {
	if c.Value == nil {
		return true
	}

	if v, ok := c.Value.(bool); ok {
		return v
	}

	if v, ok := c.Value.(string); ok {
		return strings.ToLower(v) == "true"
	}

	return c.Integer() > 0
}

// Integer gets or converts the _Value_ to a `int64`.
//
// If the _Value_ is `nil`, it will return zero. If the value is non numeric
// such as list or struct that cannot be converted to a integer, zero is returned.
// If boolean it will return 1 on `true` and zero on `false`.
func (c Capability) Integer() int64 {
	if c.Value == nil {
		return 0
	}

	switch v := c.Value.(type) {
	case bool:
		if v {
			return 1
		}
		return 0
	case int8:
		return int64(v)
	case int16:
		return int64(v)
	case int32:
		return int64(v)
	case int64:
		return v
	case int:
		return int64(v)
	}

	return 0
}
