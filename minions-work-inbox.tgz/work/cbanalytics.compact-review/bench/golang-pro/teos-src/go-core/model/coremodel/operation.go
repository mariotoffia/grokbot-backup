package coremodel

// Operation is the type of operation that is being performed.
type Operation string

const (
	// OperationGet is expressing a get operation
	OperationGet Operation = "GET"
	// OperationPut is expressing a put operation
	//
	// A _PUT_ operation patches / merges existing data
	OperationPut Operation = "PUT"
	// OperationPost is expressing a post operation
	//
	// A _POST_ operation is creating / truncating and
	// overwrite the contents.
	OperationPost Operation = "POST"
	// OperationDelete is expressing a delete operation
	OperationDelete Operation = "DELETE"
	// OperationProcess used when PDP is requested to process
	// and in such circumstance, no other operation is possible.
	OperationProcess Operation = "PROCESS"
)

// OperationPathMap contains a map of operations and under that map a path to `T` map.
//
// This type do have receiver methods that can be used to manipulate the map. Do not
// manipulate the map directly.
type OperationPathMap[T any] map[Operation]map[string]T

// Get returns a `T` based on the in parameter _operation_ and _path_.
//
// If the operation or path is not found, `nil` is returned.
func (m OperationPathMap[T]) Get(operation Operation, path string) (value T, ok bool) {
	var paths map[string]T

	paths, ok = m[operation]

	if ok {
		value, ok = paths[path]
	}

	return
}

// Set sets a `T` based on the in parameter _operation_ and _path_.
//
// If the _operation_ is yet not present in the map, it is created.
//
// NOTE: It will overwrite any existing value.
func (m OperationPathMap[T]) Set(operation Operation, path string, t T) {
	paths, ok := m[operation]

	if !ok {
		paths = map[string]T{}
		m[operation] = paths
	}

	paths[path] = t
}

// Delete deletes a `T` based on the in parameter _operation_ and _path_.
func (m OperationPathMap[T]) Delete(operation Operation, path string) {
	paths, ok := m[operation]

	if ok {
		delete(paths, path)
	}
}

// Has returns `true` if the _operation_ and _path_ is present in the map.
func (m OperationPathMap[T]) Has(operation Operation, path string) bool {
	_, ok := m.Get(operation, path)

	return ok
}

// GetPaths returns a map of paths and `T` based on the in parameter _operation_.
func (m OperationPathMap[T]) GetPaths(operation Operation) (paths map[string]T, ok bool) {
	paths, ok = m[operation]

	return
}

// GetOperations returns a slice of all operations.
func (m OperationPathMap[T]) GetOperations() (operations []Operation) {
	operations = make([]Operation, len(m))

	i := 0

	for operation := range m {
		operations[i] = operation
		i++
	}

	return
}

// Iterate will iterate all operations and paths and call the in parameter _cb_ for each.
//
// CAUTION: Do not modify the map in the _cb_ function.
func (m OperationPathMap[T]) Iterate(cb func(operation Operation, path string, t T)) {
	for operation, paths := range m {
		for path, t := range paths {
			cb(operation, path, t)
		}
	}
}
