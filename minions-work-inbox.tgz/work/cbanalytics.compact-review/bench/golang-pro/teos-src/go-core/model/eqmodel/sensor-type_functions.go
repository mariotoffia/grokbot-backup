package eqmodel

import (
	"strconv"
	"strings"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/ingestionmodel"
	"github.com/Thiink-LLC/teos/go-core/model/teosid"
)

// ToCbSensorReportItem creates a new `ingestionmodel.CbSensorReportItem` with
// properties populated from the _s_. It will use current time as timestamp.
//
// Rest of the properties are not touched and may need to be populated.
//
// If it fails, it will return an empty item. Use `SensorType.Validate` to detect the
// problem.
func (s SensorType) ToCbSensorReportItem() ingestionmodel.CbSensorReportItem {
	if _, ok, id, o, c, z, a, tags := s.Parse(); ok {
		return ingestionmodel.CbSensorReportItem{
			Sensor:  id,
			Circuit: c,
			Ordinal: o,
			Zone:    z,
			Area:    a,
			Tags:    tags,
		}
	}

	return ingestionmodel.CbSensorReportItem{}
}

// ToCbSensorReportItemWithValue converts all _s_ into `ingestionmodel.CbSensorReportItem` using
// the `SensorType.ToCbSensorReportItems`.
func ToCbSensorReportItems(s ...SensorType) []ingestionmodel.CbSensorReportItem {
	res := make([]ingestionmodel.CbSensorReportItem, 0, len(s))

	for _, sensor := range s {
		res = append(res, sensor.ToCbSensorReportItem())
	}

	return res
}

type SensorTypeWithValueOptions struct {
	Provider   string
	LocationID string
}

// ToCbSensorReportItemWithValue converts a _s_ into a `ingestionmodel.CbSensorReportItem` and adds a value and
// timestamp to it.
func (s SensorType) ToCbSensorReportItemWithValue(
	v any,
	ts time.Time,
	opts ...SensorTypeWithValueOptions,
) ingestionmodel.CbSensorReportItem {
	if _, ok, id, o, c, z, a, tags := s.Parse(); ok {
		res := ingestionmodel.CbSensorReportItem{
			Sensor:    id,
			Circuit:   c,
			Ordinal:   o,
			Zone:      z,
			Area:      a,
			Value:     v,
			TimeStamp: ts,
			Tags:      tags,
		}

		if len(opts) > 0 {
			res.Provider = opts[0].Provider
			res.LocationID = opts[0].LocationID
		}

		return res
	}

	return ingestionmodel.CbSensorReportItem{}
}

// IsPrimaryControlSignal will return true if the _s_ is a (primary) control signal for a `OptimizationPrinciple`.
// When this is sent remote, eastbound, system/_PLC_, it should be accompanied by _COMT_ (`DataPointCommunicationTimer`)
// matching the circuit (or if global just _COMT_).
//
// TIP: Depending on the _OCP_ it may not be a control signal when importing from eastbound e.g
// `SensorSupplyActingHeatingSecondaryCircuitTemperature` may not be a control signal when _OCP_
// is `OcpSetpointSecondaryCircuitTemperatureOffset` but still is imported to see if the remote
// system is following the offset of the setpoint.
func (s SensorType) IsPrimaryControlSignal() bool {
	return s == SensorOffsetOutdoorTemperature ||
		s == SensorActiveOutdoorTemperature ||
		s == SensorSupplyActingHeatingSecondaryCircuitTemperature ||
		s == SensorSupplySetPointHeatingSecondaryCircuitTemperatureOffset
}

// ToSensorTypes will create `SensorType` from the _teosIDs_ that matches the _filter_.
// If no filter, all will be returned.
//
// When a filter do not have any circuits or ordinal, it will return all _teosIDs_ matching
// the ID only and hence include all circuits and ordinals. If a filter has a circuit or ordinal
// it will only return those that match the filter.
//
// If a _filter_ have the '*' as _id_ it will return all _teosIDs_. This is useful when a certain
// circuit or ordinal for all `SensorType` is wanted.
// ToSensorTypes will create `SensorType` from the _teosIDs_ that matches the _filter_.
// If no filter, all will be returned.
//
// When a filter do not have any circuits or ordinal, it will return all _teosIDs_ matching
// the ID only and hence include all circuits and ordinals. If a filter has a circuit or ordinal
// it will only return those that match the filter.
//
// If a _filter_ have the '*' as _id_ it will return all _teosIDs_. This is useful when a certain
// circuit or ordinal for all `SensorType` is wanted.
func ToSensorTypes(teosIDs []string, filter ...SensorType) []SensorType {
	res := make([]SensorType, 0, len(teosIDs))

	// No filter - return all
	if len(filter) == 0 {
		for _, cid := range teosIDs {
			res = append(res, SensorType(cid))
		}
		return res
	}

	// Prepare filters
	type filterType struct {
		circuit int // -1 means all
		ordinal int // -1 means all
	}

	m := make(map[string]filterType, len(filter))

	for _, f := range filter {
		if ok, id, o, c := parseSensorFilter(f); ok {
			m[id] = filterType{
				circuit: c,
				ordinal: o,
			}
		}
	}

	for _, cid := range teosIDs {
		if len(filter) == 0 {
			res = append(res, SensorType(cid))
			continue
		}

		_, ok, id, o, c, _, _, _ := SensorType(cid).Parse()
		if !ok {
			continue
		}

		var f filterType

		if f, ok = m[id]; !ok {
			if f, ok = m["*"]; !ok {
				continue
			}
		}

		if f.circuit == -1 && f.ordinal == -1 {
			res = append(res, SensorType(cid))
		} else if (f.circuit == -1 || f.circuit == c) && (f.ordinal == -1 || f.ordinal == o) {
			res = append(res, SensorType(cid))
		}
	}

	return res
}

func parseSensorFilter(filter SensorType) (ok bool, id string, ordinal int, circuit int) {
	if filter == "*" || strings.HasPrefix(string(filter), "*_") {
		candidate := SensorType("WILDCARD" + strings.TrimPrefix(string(filter), "*"))
		_, ok, _, ordinal, circuit, _, _, _ = candidate.Parse()
		return ok, "*", ordinal, circuit
	}

	_, ok, id, ordinal, circuit, _, _, _ = filter.Parse()
	return
}

// FromMapToArray will create a `ingestionmodel.CbSensorReportItem` for all entries that
// matches the exact `SensorType` or prefixed with `SensorType` + "_".
//
// If none are found, it will return an empty array.
//
// If `excludeNil` is `true`, it will exclude all entries that are `nil`.
//
// NOTE: It only uses the key to determine the sensor, not the value.
func (s SensorType) FromMapToArray(
	m map[string]any,
	excludeNil bool,
) []*ingestionmodel.CbSensorReportItem {
	res := []*ingestionmodel.CbSensorReportItem{}

	if m == nil {
		return nil
	}

	var (
		sn  = string(s)
		snp = sn + "_"
	)

	for k, v := range m {
		if v == nil && excludeNil {
			continue
		}

		if k == sn || strings.HasPrefix(k, snp) {
			itm := SensorType(k).ToCbSensorReportItem()
			itm.Value = v

			res = append(res, &itm)
		}
	}

	return res
}

// Validate will validate that the `SensorType` is on proper form.
//
// _See `SensorType.Extract` for more information_.
func (s SensorType) Validate() (pos int, ok bool) {
	pos, ok, _, _, _, _, _, _ = s.Parse()
	return
}

func (s SensorType) String() string {
	return string(s)
}

// RawID returns the base identity without any Ordinal, Circuit, Zone, Area, or tags.
// For hierarchical identities this returns the full hierarchy (e.g. "INDOOR.TEMP").
// Use HierarchyPath and HierarchyLeaf to split the hierarchy.
func (s SensorType) RawID() string {
	sensor := string(s)

	if idx := strings.Index(sensor, "_"); idx != -1 {
		return sensor[:idx]
	}

	return sensor
}

// HierarchyPath returns the parent hierarchy path, or "" if flat.
//
//	"INDOOR.TEMP_O1" -> "INDOOR"
//	"A.B.C_O1"       -> "A.B"
//	"IDT_O1"         -> ""
func (s SensorType) HierarchyPath() string {
	raw := s.RawID()

	if idx := strings.LastIndex(raw, "."); idx != -1 {
		return raw[:idx]
	}

	return ""
}

// HierarchyLeaf returns the leaf identifier (last segment after last dot).
//
//	"INDOOR.TEMP_O1" -> "TEMP"
//	"IDT_O1"         -> "IDT"
func (s SensorType) HierarchyLeaf() string {
	raw := s.RawID()

	if idx := strings.LastIndex(raw, "."); idx != -1 {
		return raw[idx+1:]
	}

	return raw
}

// HierarchyDepth returns the number of segments in the hierarchy.
//
//	"INDOOR.TEMP" -> 2
//	"IDT"         -> 1
//	"A.B.C"       -> 3
func (s SensorType) HierarchyDepth() int {
	raw := s.RawID()
	depth := 1

	for i := 0; i < len(raw); i++ {
		if raw[i] == '.' {
			depth++
		}
	}

	return depth
}

// Parse will validate and extract that the `SensorType` is on proper form.
//
// If it fails it will return `false` and denote where the error did occur.
//
// A sensor identity uses the format [CATEGORY[.SUBCATEGORY]*.]ID[_On][_Cn][_Zstr][_Astr][_<key><value>]*
// where each segment in the base identity must match [A-Z][A-Z0-9]*. Tags O, C, Z, A
// must appear in that relative order when present. Custom tags (single uppercase letter
// key other than O, C, Z, A) follow after all well-known tags.
func (s SensorType) Parse() (pos int, ok bool, id string, o int, c int, z string, a string, tags map[string]any) {
	o = -1
	c = -1
	parsed, err := teosid.Parse(string(s))
	if err != nil {
		return len(s), false, s.RawID(), o, c, "", "", nil
	}

	id = parsed.QualifiedID
	if parsed.Ordinal != nil {
		o = *parsed.Ordinal
	}
	if parsed.Circuit != nil {
		c = *parsed.Circuit
	}
	if parsed.Zone != nil {
		z = *parsed.Zone
	}
	if parsed.Area != nil {
		a = *parsed.Area
	}
	if len(parsed.Tags) > 0 {
		tags = make(map[string]any, len(parsed.Tags))
		for key, value := range parsed.Tags {
			tags[key] = legacyTagValue(value)
		}
	}
	return 0, true, id, o, c, z, a, tags
}

func legacyTagValue(tagValue string) any {
	if tagValue == "true" || tagValue == "false" {
		return tagValue == "true"
	}
	for i := 0; i < len(tagValue); i++ {
		if tagValue[i] < '0' || tagValue[i] > '9' {
			return tagValue
		}
	}

	if v, err := strconv.ParseInt(tagValue, 10, 64); err == nil {
		return v
	}

	return tagValue
}

// PostFix renders all postfixes that have a valid value, ie. _On_Cn_Zstr_Astr.
func (s SensorType) PostFix() string {
	_, _, _, o, c, z, a, _ := s.Parse()

	var res strings.Builder

	if o != -1 {
		res.WriteString("_O")
		res.WriteString(strconv.Itoa(o))
	}

	if c != -1 {
		res.WriteString("_C")
		res.WriteString(strconv.Itoa(c))
	}

	if z != "" {
		res.WriteString("_Z")
		res.WriteString(z)
	}

	if a != "" {
		res.WriteString("_A")
		res.WriteString(a)
	}

	return res.String()
}

// OrdoString will just grab the ordinal as string and return it.
//
// If not existent, it will return an empty string
func (s SensorType) OrdoString() string {
	str := string(s)

	idx := strings.Index(str, "_O")

	if idx == -1 {
		return ""
	}

	// From idx + 2 to where no digit is found
	for i := idx + 2; i < len(str); i++ {
		if str[i] < '0' || str[i] > '9' {
			return str[idx+2 : i]
		}
	}

	return str[idx+2:]
}

// CircuitString will just grab the circuit as string and return it.
//
// If not existent, it will return an empty string
func (s SensorType) CircuitString() string {
	str := string(s)

	idx := strings.Index(str, "_C")

	if idx == -1 {
		return ""
	}

	// From idx + 2 to where no digit is found
	for i := idx + 2; i < len(str); i++ {
		if str[i] < '0' || str[i] > '9' {
			return str[idx+2 : i]
		}
	}

	return str[idx+2:]
}

// ZoneString will just grab the zone as string and return it.
//
// If not existent, it will return an empty string.
func (s SensorType) ZoneString() string {
	str := string(s)

	idx := strings.Index(str, "_Z")
	if idx == -1 {
		return ""
	}

	start := idx + 2
	if start >= len(str) {
		return ""
	}

	if end := strings.Index(str[start:], "_"); end != -1 {
		return str[start : start+end]
	}

	return str[start:]
}

// AreaString will just grab the area as string and return it.
//
// If not existent, it will return an empty string.
func (s SensorType) AreaString() string {
	str := string(s)

	idx := strings.Index(str, "_A")
	if idx == -1 {
		return ""
	}

	start := idx + 2
	if start >= len(str) {
		return ""
	}

	if end := strings.Index(str[start:], "_"); end != -1 {
		return str[start : start+end]
	}

	return str[start:]
}
