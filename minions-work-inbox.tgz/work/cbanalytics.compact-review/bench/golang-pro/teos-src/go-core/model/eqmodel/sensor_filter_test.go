package eqmodel_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

func TestToSensorTypesGlobalReturnsAllWithID(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2", "OFFSPSSHCT_C1", "OFFSPSSHCT_C2"},
		eqmodel.SensorType("COMT"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[1])
}

// Test when no filter is provided. In this case, all sensor IDs should be returned in the input order.
func TestToSensorTypesNoFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes([]string{"COMT_C1", "COMT_C2", "INVALID", "OFFSPSSHCT_C1"})
	require.Equal(t, 4, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[1])
	assert.Equal(t, eqmodel.SensorType("INVALID"), sensors[2])
	assert.Equal(t, eqmodel.SensorType("OFFSPSSHCT_C1"), sensors[3])
}

// Test a filter that specifies a circuit (e.g. COMT_C2 means circuit=2, ordinal unspecified).
// Expect sensors with circuit 2 to be returned in the order they appear.
func TestToSensorTypesSpecificCircuitFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2", "COMT_C3", "COMT_O1_C1", "COMT_O1_C2"},
		eqmodel.SensorType("COMT_C2"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C2"), sensors[1])
}

// Test a filter that specifies an ordinal only (assuming the parser accepts a syntax with an empty circuit,
// e.g. "COMT__O1" means ordinal 1, any circuit).
func TestToSensorTypesSpecificOrdinalFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_O1_C1", "COMT_O2_C1", "COMT_O1_C2", "COMT_O2_C2"},
		eqmodel.SensorType("COMT_O1"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C2"), sensors[1])
}

// Test a filter that specifies both circuit and ordinal exactly.
func TestToSensorTypesExactCircuitAndOrdinalFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1_O1", "COMT_O2_C1", "COMT_O1_C2", "COMT_O2_C2"},
		eqmodel.SensorType("COMT_O2_C1"),
	)

	require.Equal(t, 1, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_O2_C1"), sensors[0])
}

// Test a filter that does not match any sensor.
func TestToSensorTypesFilterNotMatchingAnySensor(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "OFFSPSSHCT_C1"},
		eqmodel.SensorType("XYZ"),
	)
	require.Empty(t, sensors)
}

// Test multiple filters for different sensor IDs.
// For "COMT" (global) all COMT sensors are returned and for "OFFSPSSHCT_C1"
// only those with circuit 1.
func TestToSensorTypesMultipleFiltersDifferentIDs(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2", "OFFSPSSHCT_C1", "OFFSPSSHCT_C2"},
		eqmodel.SensorType("COMT"), eqmodel.SensorType("OFFSPSSHCT_C1"),
	)
	// Order: input order is preserved.
	require.Equal(t, 3, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[1])
	assert.Equal(t, eqmodel.SensorType("OFFSPSSHCT_C1"), sensors[2])
}

// Test with sensor IDs that are invalid. Only valid ones should be returned when a filter is provided.
func TestToSensorTypesInvalidSensorIDs(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"INVALID", "BAD_FORMAT", "COMT_C1"},
		eqmodel.SensorType("COMT"),
	)
	// Only "COMT_C1" is valid and should match.
	require.Equal(t, 1, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
}

// Test mixed valid and invalid sensor IDs.
func TestToSensorTypesMixedValidAndInvalid(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "INVALID", "OFFSPSSHCT_C2", "UNKNOWN"},
		eqmodel.SensorType("OFFSPSSHCT"),
	)
	// Only valid and matching sensor: "OFFSPSSHCT_C2"
	require.Equal(t, 1, len(sensors))
	assert.Equal(t, eqmodel.SensorType("OFFSPSSHCT_C2"), sensors[0])
}

// Test multiple filters for the same sensor ID where a global filter overwrites a specific filter.
// In the map of filters, the later value wins.
func TestToSensorTypesMultipleFiltersSameIDGlobalWins(t *testing.T) {
	// Global filter provided second overwrites the specific one.
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2", "COMT_C3"},
		eqmodel.SensorType("COMT_C1"), eqmodel.SensorType("COMT"),
	)
	// Order preserved: all COMT sensors as per input order.
	require.Equal(t, 3, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[1])
	assert.Equal(t, eqmodel.SensorType("COMT_C3"), sensors[2])
}

// Test multiple filters for the same sensor ID where a specific filter is provided last.
func TestToSensorTypesMultipleFiltersSameIDSpecificWins(t *testing.T) {
	// Specific filter provided second should limit the result.
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2", "COMT_C3"},
		eqmodel.SensorType("COMT"), eqmodel.SensorType("COMT_C2"),
	)
	// Order: Only COMT_C2 (found in the middle) should match.
	require.Equal(t, 1, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[0])
}

// Test with an empty input slice.
func TestToSensorTypesEmptyInput(t *testing.T) {
	sensors := eqmodel.ToSensorTypes([]string{}, eqmodel.SensorType("COMT"))
	require.Empty(t, sensors)
}

// Test a filter with circuit only (e.g. COMT_C1 means circuit=1, ordinal unspecified).
func TestToSensorTypesCircuitOnlyFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_O1_C1", "COMT_O2_C1", "COMT_O1_C2", "COMT_O2_C2"},
		eqmodel.SensorType("COMT_C1"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_O2_C1"), sensors[1])
}

// Test for case sensitivity. Assuming matching is case-sensitive.
func TestToSensorTypesCaseSensitivity(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "comt_C2"},
		eqmodel.SensorType("COMT"),
	)
	// Only "COMT_C1" should match if the parser is case-sensitive.
	require.Equal(t, 1, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
}

// Test sensor IDs with a bad format. Only well-formed ones should match the filter.
func TestToSensorTypesBadFormatSensors(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT-C1", "COMT_C1", "COMT_O1_C1"},
		eqmodel.SensorType("COMT"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C1"), sensors[1])
}

// Test when multiple matching sensors occur (including duplicates).
func TestToSensorTypesMultipleMatchesForFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_O1_C1", "COMT_O2_C1", "COMT_O1_C1"},
		eqmodel.SensorType("COMT_O1_C1"),
	)

	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_O1_C1"), sensors[1])
}

// Test overlapping sensor IDs where filters for "COMT" and "COM" are provided.
// The output order should match the input order.
func TestToSensorTypesOverlappingSensorIDs(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COM_C1", "COMT_C2", "COM_C2"},
		eqmodel.SensorType("COMT"), eqmodel.SensorType("COM"),
	)
	// Expected order (same as input):
	// Index 0: "COMT_C1" (matches filter "COMT")
	// Index 1: "COM_C1"  (matches filter "COM")
	// Index 2: "COMT_C2" (matches filter "COMT")
	// Index 3: "COM_C2"  (matches filter "COM")
	require.Equal(t, 4, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COM_C1"), sensors[1])
	assert.Equal(t, eqmodel.SensorType("COMT_C2"), sensors[2])
	assert.Equal(t, eqmodel.SensorType("COM_C2"), sensors[3])
}

// Test with a malformed filter (one that fails parsing). In this case no sensor should match.
func TestToSensorTypesMalformedFilterProvided(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2"},
		eqmodel.SensorType("BADFILTER"),
	)
	// BADFILTER fails parsing so no filter is added; thus, no sensor is matched.
	require.Empty(t, sensors)
}

// Test a filter that does not match any sensors among the list.
func TestToSensorTypesAllSensorsNonMatchingFilter(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C2"},
		eqmodel.SensorType("OFFSPSSHCT"),
	)
	require.Empty(t, sensors)
}

// Test duplicate sensor IDs in the input slice.
func TestToSensorTypesDuplicateSensorIDs(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "COMT_C1", "OFFSPSSHCT_C1"},
		eqmodel.SensorType("COMT"),
	)
	// Expect both duplicates of "COMT_C1" to be returned in order.
	require.Equal(t, 2, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[1])
}

// Test multiple filters where one of them does not match any sensor.
func TestToSensorTypesMultipleFiltersOneNonMatching(t *testing.T) {
	sensors := eqmodel.ToSensorTypes(
		[]string{"COMT_C1", "OFFSPSSHCT_C1"},
		eqmodel.SensorType("COMT"), eqmodel.SensorType("XYZ"),
	)
	// Only the COMT filter will match, yielding "COMT_C1".
	require.Equal(t, 1, len(sensors))
	assert.Equal(t, eqmodel.SensorType("COMT_C1"), sensors[0])
}
