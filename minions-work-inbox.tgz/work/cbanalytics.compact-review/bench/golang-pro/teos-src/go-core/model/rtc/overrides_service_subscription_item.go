package rtc

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// ToPipeSource converts the subscription item to a pipe source that may be returned directly from
// a `providerpipe.SourceFunction`. No errors will be returned from this function.
//
// It will copy all elements in the `Dp` map to the source map and set the _FRT_
// and _BID_ (from `Lid`) globals. If _PID_ and _TID_ is set, those will also be set as globals.
//
// The _FRT_ is set by the `RtChannelMessageType` (`SIMPLE_SUBSCRIPTION_FRAME`). It will set
// _Mode_ to the `Mode`.
func (item *RtcServiceSubscriptionItem) ToPipeSource(
	now coremodel.CbTime32,
) (map[string]any, cberror.Error) {
	dp, source, globals := providerutils.StandardPipeSource(true)

	if item.Dp != nil {
		for k, v := range *item.Dp {
			source[k] = &eqmodel.CbDataPointImpl{ID: k, Value: v, TimeStamp: now}
		}
	}

	globals["FRT"] = string(SIMPLE_SUBSCRIPTION_FRAME)
	globals["Mode"] = item.Mode
	globals[string(ifprovider.ParameterLocationID)] = item.Lid
	utils.MapSetStringValueIf(string(ifprovider.ParameterTarget), &item.Target, globals)
	utils.MapSetStringValueIf(string(ifprovider.ParameterPlantID), item.Pid, globals)
	utils.MapSetStringValueIf(string(ifprovider.ParameterTenantID), item.Tid, globals)
	return dp, nil
}
