package cfgmodel

import "github.com/Thiink-LLC/teos/go-core/model/eqmodel"

// First will return the first available sensor in the merged sensors.
//
// If none, `nil` is returned.
func (ms *MergedSensors) First() *eqmodel.InstalledSensor {
	if len(ms.Added) > 0 {
		return &ms.Added[0]
	}

	if len(ms.Updated) > 0 {
		return &ms.Updated[0]
	}

	if len(ms.Deleted) > 0 {
		return &ms.Deleted[0]
	}

	if len(ms.Notchanged) > 0 {
		return &ms.Notchanged[0]
	}

	return nil
}

// SensorsForEquipment returns all sensors for the given equipment ID (added, updated and deleted)
//
// If no _eqID_ is given, it will return all sensors (same as `c.Sensors`).
func (ms *MergedSensors) SensorsForEquipment(eqID ...string) *MergedSensors {
	if ms == nil {
		return &MergedSensors{}
	}

	if len(eqID) == 0 {
		return ms
	}

	var sensors MergedSensors

	for i, s := range ms.Added {
		if s.EquipmentID == eqID[0] {
			sensors.Added = append(sensors.Added, ms.Added[i])
		}
	}

	for i, s := range ms.Updated {
		if s.EquipmentID == eqID[0] {
			sensors.Updated = append(sensors.Updated, ms.Updated[i])
		}
	}

	for i, s := range ms.Deleted {
		if s.EquipmentID == eqID[0] {
			sensors.Deleted = append(sensors.Deleted, ms.Deleted[i])
		}
	}

	for i, s := range ms.Notchanged {
		if s.EquipmentID == eqID[0] {
			sensors.Notchanged = append(sensors.Notchanged, ms.Notchanged[i])
		}
	}

	return &sensors
}
