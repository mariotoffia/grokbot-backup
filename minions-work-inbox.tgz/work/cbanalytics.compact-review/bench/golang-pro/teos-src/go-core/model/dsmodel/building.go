package dsmodel

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/utils"

	"github.com/Thiink-LLC/teos/go-core/cberror"
)

// DsBuilding is a thing shadow object where it contains the sensors / values in that building.
//
// This is a explicit named thing shadow named building under the thing named after name or cadastral
// for the building.
type DsBuilding struct {
	// Type indicates the kind of location this thing represents (e.g. "building").
	// This field enables distinguishing location types when the thing type is the
	// generic "location" rather than a specific type like "building".
	Type string `json:"type,omitempty"`
	// TimeZone expressed as https://www.iana.org/time-zones[IANA timezone].
	//
	// As a backup option but do not have daylight savings
	// is to specify _+-HH:MM_ directly. It will be converted to
	// a _UTC_ timestamp with the offset applied.
	//
	// IMPORTANT: If omitted, it will be treated as a pure _UTC_ timestamp with no offset!
	TimeZone string `json:"tz,omitempty"`
	// ReportType is an override of `ifprovider.ParameterReportType` and will affect how a provider
	// will report back the device shadow data (see `providerutils.ReportDsBuildingType` for more info)
	ReportType string `json:"rpt,omitempty"`
	// Sensors contains the sensor values.
	//
	// Thiink interprets the sensor format in a specific way in order to encode
	// _Circuit_, _Ordinal_ (within circuit or not), and _Zone_ name. All those are
	// optional but thiink reserves certain character combinations in sensor names (_See table below_).
	//
	// image::figures/providerconfig/sensor-format.svg[width="100%", opts=inline]
	//
	// .Examples of Sensor Ids
	// |===
	// |Name |Comments
	//
	// |IDT
	// |Plain sensor with no circuit, ordinal or zone
	//
	// |IDT_O1
	// |Sensor with no circuit, but do have a ordinal (possible more IDT sensors exists), and no zone
	//
	// |RHS_O1_C1
	// |Sensor that is attached to circuit 1 and may exist mor sensors of same kind since ordinal 1, but no zone
	//
	// |RHS_O1_C1_ZmyZone
	// |Same as above but sensor is attached to a zone named _myZone_
	// |===
	Sensors map[string]any `json:"sensors,omitempty"`
	// SensorTimestamps contains Unix 32 bit epoch timestamps, on when a certain
	// `Sensor` with _ID_ was last updated.
	//
	// NOTE: This may be used when a timestamp check is done on a sensor value
	// and the algorithm needs to have the device timestamp instead of when the
	// value was collected by _TEOS_.
	SensorTimestamps map[string]coremodel.CbTime32 `json:"sensorts,omitempty"`
}

// Clone creates a new `DsBuilding` and copies the data to the new instance before
// returning it.
func (ds *DsBuilding) Clone() *DsBuilding {
	d := &DsBuilding{
		Type:     ds.Type,
		TimeZone: ds.TimeZone,
	}

	if len(ds.Sensors) > 0 {
		d.Sensors = map[string]any{}

		for k, v := range ds.Sensors {
			d.Sensors[k] = v
		}
	}

	if len(ds.SensorTimestamps) > 0 {
		d.SensorTimestamps = map[string]coremodel.CbTime32{}

		for k, v := range ds.SensorTimestamps {
			d.SensorTimestamps[k] = v
		}
	}

	return d
}

// DsBuildingMeta is a metadata representation for DsBuilding
//
// Use this to determine when the individual properties where updated.
type DsBuildingMeta struct {
	// Type (see _DsBuilding.Type_ for info about contents) _Unix Epoch Timestamp_.
	Type DsMetaTimeStamp `json:"type,omitempty"`
	// TimeZone (see _DsBuilding.TimeZone_ for info about contents) _Unix Epoch Timestamp_.
	TimeZone DsMetaTimeStamp `json:"tz,omitempty"`
	// Sensors (see _DsBuilding.Sensors_ for more information about contents)
	// _Unix Epoch Timestamp_ for each individual Sensor.
	Sensors map[string]DsMetaTimeStamp `json:"sensors,omitempty"`
	// SensorTimestamps (see _DsBuilding.SensorTimestamps for more information about contents)
	// _Unix Epoch Timestamp_ for each individual SensorTimestamps.
	SensorTimestamps map[string]DsMetaTimeStamp `json:"sensorts,omitempty"`
}

// DsFullBuildingState represents the state of the thing shadow.
//
// NOTE: Depending on the selection of the thing shadow different
// fields are populated. Make sure to check each access!
type DsFullBuildingState struct {
	// Reported is where all properties that are reported from the
	// thing is residing.
	//
	// If _Desired_ and _Reported_ is different, the _Delta_ contains
	// the differences.
	Reported *DsBuilding `json:"reported,omitempty"`
	// Desired is where all properties that are desired from services
	// are located.
	Desired *DsBuilding `json:"desired,omitempty"`
	// Delta contains all properties that are different between _Reported_
	// and _Desired_.
	Delta *DsBuilding `json:"delta,omitempty"`
}

// DsFullBuildingMetadata contains _Unix Epoch Timestamp_ on each attribute in both _Reported_
// and _Desired State_.
//
// NOTE: Depending on the selection of the thing shadow this property may not even
// exist. Please check access before investigating the fields.
type DsFullBuildingMetadata struct {
	// Reported contains the metadata about the _Reported State_.
	Reported *DsBuildingMeta `json:"reported,omitempty"`
	// Desired contains the metadata about the _Desired State_.
	Desired *DsBuildingMeta `json:"desired,omitempty"`
}

// DsFullBuilding is a full thing shadow with metadata for DsBuilding
type DsFullBuilding struct {
	// DsBase is base thing shadow info, hence _DsFullBuilding_ derives from _DsBase_.
	DsBase

	// BuildingID is the name or cadastral of the building.
	//
	// Use the function _SetBuildingID()_ to set this property since
	// it will extract the _DsBase.Topic_ property and try to decode
	// the name from that. This means that the _Topic_ property
	// must contain the _MQTT_ topic in order to extract the thing name.
	BuildingID string `json:"-"`

	// State represents the state of the thing shadow.
	//
	// NOTE: Depending on the selection of the thing shadow different
	// fields are populated. Make sure to check each access!
	State *DsFullBuildingState `json:"state,omitempty"`
	// Metadata contains _Unix Epoch Timestamp_ on each attribute in both _Reported_
	// and _Desired State_.
	//
	// NOTE: Depending on the selection of the thing shadow this property may not even
	// exist. Please check access before investigating the fields.
	Metadata *DsFullBuildingMetadata `json:"metadata,omitempty"`
}

// NewDsFullBuilding creates a new instance of _DsFullBuilding_
// from a thing shadow payload and do not populate _BuildingID_.
func NewDsFullBuilding(c ifcore.CbContext, payload []byte) (*DsFullBuilding, cberror.Error) {
	var dsb DsFullBuilding

	if err := json.Unmarshal(payload, &dsb); err != nil {
		return nil, cberror.NewCbErrorf(
			c.Service(), cberror.ErrorModelUnmarshalBuilding, err,
			"Failed to unmarshal into DsFullBuilding, payload: '%s', error: %s",
			string(payload), err.Error())
	}

	return &dsb, nil
}

// NewDsFullBuildingWithTopic creates a new instance of _DsFullBuilding_
// from a thing shadow payload and populates BuildingID.
//
// If it encounters a _DsBase.Topic_ it will extract the _BuildingID_
// using _SetBuildingID()_.
// NOTE: This is only valid when the payload do have the topic property set, e.g use an _IoT Rule_.
// For example `SELECT *, topic() as topic ...`
func NewDsFullBuildingWithTopic(
	c ifcore.CbContext,
	payload []byte,
) (*DsFullBuilding, cberror.Error) {
	dsb, err := NewDsFullBuilding(c, payload)
	if err != nil {
		return nil, err
	}

	err = dsb.SetBuildingID(c)
	return dsb, err
}

// DecodeTopicToBuildingID will take a MQTT topic name and try to extract a building id from it.
//
// If it fails, it will return an `error`.
func DecodeTopicToBuildingID(topic string) (string, error) {
	if topic != "" {
		comp := strings.Split(topic, "/")

		if len(comp) > 2 {
			return utils.DecodeThingName(comp[2]), nil
		}
	}

	return "", fmt.Errorf(
		"no topic / not enough parameters on topic = '%s' found, "+
			"you need to subscribe e.g. SELECT *, topic() as topic ... in order to be populated",
		topic,
	)
}

// SetBuildingID extracts the _DsBase.Topic_ and Decodes the value
// and set the thing name portion into the _DsBuilding.BuildingID_.
//
// If it fails it will not set the _BuildingID_ and return an `cberror.Error`.
func (dsb *DsFullBuilding) SetBuildingID(c ifcore.CbContext) cberror.Error {
	if bid, err := DecodeTopicToBuildingID(dsb.Topic); err != nil {
		return cberror.NewCbErrorf(
			c.Service(),
			cberror.ErrorModelUnableToSetBuildingId,
			nil,
			"%s",
			err.Error(),
		)
	} else {
		dsb.BuildingID = bid
	}

	return nil

}
