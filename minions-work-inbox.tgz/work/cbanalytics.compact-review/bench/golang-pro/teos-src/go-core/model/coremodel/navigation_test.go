package coremodel_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

func TestToFullPath(t *testing.T) {
	tests := []struct {
		name string
		path string
		want coremodel.FullPath
	}{
		{
			name: "plain segments",
			path: "sensors.ODT",
			want: coremodel.FullPath{{Element: "sensors"}, {Element: "ODT"}},
		},
		{
			name: "an indexer",
			path: "list.[2].value",
			want: coremodel.FullPath{
				{Element: "list"},
				{Element: "2", IsIndexer: true},
				{Element: "value"},
			},
		},
		{
			name: "an empty indexer",
			path: "list.[]",
			want: coremodel.FullPath{{Element: "list"}, {Element: "", IsIndexer: true}},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := coremodel.ToFullPath(tt.path)

			require.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestToFullPath_IndexerWithNoClosingBracketIsAnError(t *testing.T) {
	for _, path := range []string{"[", "[abc", "list.[abc.value"} {
		t.Run(path, func(t *testing.T) {
			var (
				got coremodel.FullPath
				err error
			)

			require.NotPanics(t, func() { got, err = coremodel.ToFullPath(path) })

			require.Error(t, err)
			assert.Nil(t, got)
			assert.NotContains(t, err.Error(), path, "the error leaves out the path")
		})
	}
}
