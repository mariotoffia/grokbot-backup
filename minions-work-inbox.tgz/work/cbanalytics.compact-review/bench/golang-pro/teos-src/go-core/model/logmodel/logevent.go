package logmodel

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

type LogEvent struct {
	// Time is the time of the log event. It is a Unix 64 bit timestamp in milliseconds.
	Time coremodel.CbTime64
	// Message to log.
	Message string
	// LogStream is an optional name of the log stream.
	LogStream string
	// LogGroup is the optional name of the log group.
	//
	// For _AWS_ this is account ID: log group name e.g. _033549287452:/aws/lambda/buildingx-cfin_.
	LogGroup string
	// Metadata is any metadata associated with the log event. This may be `nil` or empty.
	Metadata map[string]any
}

// LogEventWithError is a log event with an error. It is used to return the log event and the error
// that occurred while processing the log event.
//
// This typically used in a async processing scenario such from a channel.

type LogEventWithError struct {
	LogEvent
	Error cberror.Error
}

type PutLogEventResult struct {
	// The expired log events.
	ExpiredLogEventEndIndex int
	// The log events that are too new.
	TooNewLogEventStartIndex int
	// The log events that are too old.
	TooOldLogEventEndIndex int
}

// IsJSON checks if the message is a _JSON_ object or array.
//
// CAUTION: It will not *validate the _JSON_, just check if it is enclosed in `{}` or `[]`.
func (le *LogEvent) IsJSON() bool {
	if le == nil {
		return false
	}
	s := le.Message
	n := len(s)
	i, j := 0, n-1
	exit := false

	// Trim leading whitespace
	for i < n && !exit {
		switch s[i] {
		case ' ', '\t', '\n', '\r':
			i++
		default:
			exit = true
		}
	}

	if i >= n {
		return false
	}

	// Must start with '{' or '['
	first := s[i]

	if first != '{' && first != '[' {
		return false
	}

	// Trim trailing whitespace
	exit = false

	for j > i && !exit {
		switch s[j] {
		case ' ', '\t', '\n', '\r':
			j--
		default:
			exit = true
		}
	}

	// Must end with the matching '}' or ']'
	last := s[j]

	if (first == '{' && last == '}') || (first == '[' && last == ']') {
		return true
	}

	return false
}
