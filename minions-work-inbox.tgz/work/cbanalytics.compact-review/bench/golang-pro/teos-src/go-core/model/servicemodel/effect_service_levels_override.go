package servicemodel

import "strings"

// FromShortHand is the prefix of the esl - e.g. large -> "Large (251-400 kW)"
func FromShortHand(esl string) TeosEffectServiceLevels {
	esl = strings.TrimSpace(strings.ToLower(esl))

	for _, en := range AllTeosEffectServiceLevelsTypes {
		current := strings.ToLower(string(en))

		idx := strings.Index(current, " (")
		if idx > 0 {
			current = current[:idx]
		}

		if esl == current {
			return en
		}
	}

	return TeosEffectServiceLevelNotSet
}
