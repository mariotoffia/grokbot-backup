package coremodel_test

import (
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"

	"github.com/stretchr/testify/assert"
)

func TestToResolutionAndDuration(t *testing.T) {
	type testCase struct {
		resolution coremodel.Resolution
		expected   coremodel.ResolutionType
		duration   int
	}

	testCases := []testCase{
		{
			resolution: coremodel.Resolution(""),
			expected:   coremodel.ResolutionUnknown,
			duration:   0,
		},
		{
			resolution: coremodel.Resolution("1ms"),
			expected:   coremodel.ResolutionMilliseconds,
			duration:   1,
		},
		{
			resolution: coremodel.Resolution("1s"),
			expected:   coremodel.ResolutionSeconds,
			duration:   1,
		},
		{
			resolution: coremodel.Resolution("1min"),
			expected:   coremodel.ResolutionMinutes,
			duration:   1,
		},
		{
			resolution: coremodel.Resolution("1h"),
			expected:   coremodel.ResolutionHours,
			duration:   1,
		},
		{
			resolution: coremodel.Resolution("1d"),
			expected:   coremodel.ResolutionDays,
			duration:   1,
		},
		{
			resolution: coremodel.Resolution("1m"),
			expected:   coremodel.ResolutionMonths,
			duration:   1,
		},
		{
			resolution: coremodel.Resolution("1"),
			expected:   coremodel.ResolutionUnknown,
			duration:   0,
		},
		{
			resolution: coremodel.Resolution("1ms1"),
			expected:   coremodel.ResolutionUnknown,
			duration:   0,
		},
	}

	for _, tc := range testCases {
		t.Run(string(tc.resolution), func(t *testing.T) {
			res, dur := tc.resolution.ToResolutionAndDuration()

			assert.Equal(t, tc.expected, res)
			assert.Equal(t, tc.duration, dur)
		})
	}
}

func TestToDuration(t *testing.T) {
	type testCase struct {
		resolution coremodel.Resolution
		expected   time.Duration
	}

	testCases := []testCase{
		{
			resolution: coremodel.Resolution(""),
			expected:   0,
		},
		{
			resolution: coremodel.Resolution("1ms"),
			expected:   time.Duration(1) * time.Millisecond,
		},
		{
			resolution: coremodel.Resolution("1s"),
			expected:   time.Duration(1) * time.Second,
		},
		{
			resolution: coremodel.Resolution("1min"),
			expected:   time.Duration(1) * time.Minute,
		},
		{
			resolution: coremodel.Resolution("1h"),
			expected:   time.Duration(1) * time.Hour,
		},
		{
			resolution: coremodel.Resolution("1d"),
			expected:   time.Duration(1) * 24 * time.Hour,
		},
		{
			resolution: coremodel.Resolution("1m"),
			expected:   time.Duration(1) * 30 * 24 * time.Hour,
		},
		{
			resolution: coremodel.Resolution("1"),
			expected:   0,
		},
		{
			resolution: coremodel.Resolution("1ms1"),
			expected:   0,
		},
	}

	for _, tc := range testCases {
		t.Run(string(tc.resolution), func(t *testing.T) {
			dur, _ := tc.resolution.ToDuration()

			assert.Equal(t, tc.expected, dur)
		})
	}
}

func TestSlots(t *testing.T) {
	type testCase struct {
		resolution coremodel.Resolution
		expected   []int
	}

	testCases := []testCase{
		{
			resolution: coremodel.Resolution(""),
			expected:   []int{},
		},
		{
			resolution: coremodel.Resolution("1ms"),
			expected:   []int{0},
		},
		{
			resolution: coremodel.Resolution("2s"),
			expected:   []int{0, 1},
		},
		{
			resolution: coremodel.Resolution("15min"),
			expected:   []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14},
		},
		{
			resolution: coremodel.Resolution("4h"),
			expected:   []int{0, 1, 2, 3},
		},
		{
			resolution: coremodel.Resolution("7d"),
			expected:   []int{0, 1, 2, 3, 4, 5, 6},
		},
		{
			resolution: coremodel.Resolution("1m"),
			expected:   []int{0},
		},
		{
			resolution: coremodel.Resolution("1"),
			expected:   []int{},
		},
		{
			resolution: coremodel.Resolution("1ms1"),
			expected:   []int{},
		},
	}

	for _, tc := range testCases {
		t.Run(string(tc.resolution), func(t *testing.T) {
			slots := tc.resolution.Slots()

			assert.Equal(t, tc.expected, slots)
		})
	}
}
