package internalparams

import (
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel/parameters"
)

// Get will return a clone of the parameter definition for the given name.
//
// This function is safe for concurrent use.
//
// When use is set, it will return a clone of the parameter definition with
// the use set to the given value.
func Get(name string, use ...parameters.ParameterUsage) (parameters.ParameterDefinition, bool) {
	if p, ok := params[name]; !ok {
		return p, false
	} else {
		return parameters.ParameterDefinition{
			Name:           p.Name,
			IdentifierType: p.IdentifierType,
			Description:    p.Description,
			Resolution:     p.Resolution,
			Unit:           p.Unit,
			Type:           p.Type,
			Use:            use,
		}, true
	}
}

// List will return all parameter names that may be returned from `Get`.
func List() []string {
	list := make([]string, 0, len(params))

	for k := range params {
		list = append(list, k)
	}

	return list
}

// params holds every parameter definition that `Get` and `List` serve, keyed by
// parameter name.
var params = mergeParams(sensorTypeParams, dataPointTypeParams, configurationTypeParams, locationTypeParams)

// mergeParams joins the parameter sections into one map. A name defined in more
// than one section panics, so a duplicate fails as soon as the package loads.
func mergeParams(sections ...map[string]parameters.ParameterDefinition) map[string]parameters.ParameterDefinition {
	merged := map[string]parameters.ParameterDefinition{}

	for _, section := range sections {
		for name, p := range section {
			if _, exists := merged[name]; exists {
				panic("internalparams: parameter " + name + " is defined in more than one section")
			}

			merged[name] = p
		}
	}

	return merged
}
