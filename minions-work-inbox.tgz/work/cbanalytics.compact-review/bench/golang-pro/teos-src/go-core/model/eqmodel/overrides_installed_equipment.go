package eqmodel

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/utils"
	"github.com/Thiink-LLC/teos/go-core/utils/idutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// ShallowEqual will check if the _LocationID_ and _EquipmentID_ are equal.
func (eq *InstalledEquipment) ShallowEqual(other *InstalledEquipment) bool {
	return eq.LocationID == other.LocationID && eq.EquipmentID == other.EquipmentID
}

// In will check if _ps_ exists in _other_. It will do a `ShallowEqual` check.
func (eq *InstalledEquipment) In(other []InstalledEquipment) bool {
	for _, o := range other {
		o := o

		if eq.ShallowEqual(&o) {
			return true
		}
	}

	return false
}

// MarshalMap creates a map[string]any from the installed equipment.
func (eq *InstalledEquipment) MarshalMap() (map[string]any, error) {
	return jsonutils.ToJSONMap(eq)
}

// UnmarshalMap requires that the m points to a map[string]any of where
// it contains a single representation of `InstalledEquipment`.
func (eq *InstalledEquipment) UnmarshalMap(m map[string]any) error {
	if eq == nil {
		eq = &InstalledEquipment{}
	}

	return json.Unmarshal(jsonutils.ToJSON(m), eq)
}

// Prepare will prepare the `InstalledEquipment` for database operation.
//
// It will return itself for fluent API.
func (eq *InstalledEquipment) Prepare() *InstalledEquipment {
	if eq == nil {
		return nil
	}

	if !strings.HasPrefix(eq.LocationID, buildingPrefix) {
		eq.LocationID = buildingPrefix + eq.LocationID
	}

	if !strings.HasPrefix(eq.EquipmentID, equipmentPrefix) {
		eq.EquipmentID = equipmentPrefix + eq.EquipmentID
	}

	return eq
}

// PostProcess will make sure that all identifiers are correctly set after
// a query from the database.
func (eq *InstalledEquipment) PostProcess(ctx ifcore.CbContext) *InstalledEquipment {
	if eq == nil {
		return nil
	}

	eq.LocationID = strings.TrimPrefix(eq.LocationID, buildingPrefix)
	eq.EquipmentID = strings.TrimPrefix(eq.EquipmentID, equipmentPrefix)

	return eq
}

// OwnedBy will check if the `LocationID` do end with ' ({owner})'. It will extract that and return the
// owner string.
func (eq *InstalledEquipment) OwnedBy() string {
	if eq == nil {
		return ""
	}

	_, rsid := idutils.RSIDDecodeLocationID(strings.TrimPrefix(eq.LocationID, buildingPrefix))

	return rsid
}

// PlainEquipmentID this will strip off any database prefix of the _EquipmentID_.
func (eq *InstalledEquipment) PlainEquipmentID() string {
	return strings.TrimPrefix(eq.EquipmentID, equipmentPrefix)
}

// GetSensorStartOrdinal tries to extract the start ordinal from the
// `InstalledEquipment.Params` using the `EqOrdinalStart` key.
//
// If missing, it will return -1.
func (eq *InstalledEquipment) GetSensorStartOrdinal() int {
	if eq == nil {
		return -1
	}

	if eq.Params == nil {
		return -1
	}

	return int(utils.ExtractInt64FromMap(string(EqOrdinalStart), eq.Params, -1))
}

// Prm will return a value from the `Params`. If a _d_efault is set, it will never
// return an error. Otherwise, if the param is not found, it will return error.
func (eq *InstalledEquipment) Prm(name string, d ...any) (any, error) {
	if len(d) > 0 {
		if eq == nil || len(eq.Params) == 0 {
			return d[0], nil
		}

		if v, ok := eq.Params[name]; ok {
			return v, nil
		} else {
			return d, nil
		}
	}

	if eq == nil || len(eq.Params) == 0 {
		return nil, fmt.Errorf("cannot find param: %s", name)
	}

	if v, ok := eq.Params[name]; ok {
		return v, nil
	}

	return nil, fmt.Errorf("cannot find param: %s", name)
}

// IsEquipment will check if the _eqID_ is equal to the _EquipmentID_. If
// _eqID_ is not provided, it will return false.
func (eq *InstalledEquipment) IsEquipment(eqID ...string) bool {
	id := strings.TrimPrefix(eq.EquipmentID, equipmentPrefix)

	for _, e := range eqID {
		if id == e {
			return true
		}
	}

	return false
}
