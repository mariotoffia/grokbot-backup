package eqdefs

import (
	"math"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// dataPointDefinitions holds the definitions of the circuit control,
// communication and configuration data points, keyed by TEOS identifier.
var dataPointDefinitions = map[string]DataPointDefinition{
	/** DataPoints **/
	// ECR
	string(eqmodel.DataPointEnabledCircuits): {
		ID:          "TEOS/Circuit Control/Enable Circuits",
		TeosID:      string(eqmodel.DataPointEnabledCircuits),
		Sensor:      true,
		Type:        DataPointDefinitionTypeBitmask,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The bitmask of the enabled circuits for TEOS control",
		Readonly:    false,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "bits",
				Symbol: DataPointUnitSymbolBitField,
			},
		},
	},
	// COMT
	string(eqmodel.DataPointCommunicationTimer): {
		ID:          "TEOS/Communication/Communication Timeout",
		TeosID:      string(eqmodel.DataPointCommunicationTimer),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         1,
		High:        360,
		Description: "The number of minutes before the local controller will take over",
		Readonly:    false,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "h",
				Symbol: DataPointUnitSymbolHours,
			},
		},
	},
	//
	// Configuration Variables.
	//

	// ITL
	string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow): {
		ID:          "TEOS/Thresholds/Indoor/Low Temperature Limit",
		TeosID:      string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow),
		Sensor:      false,
		Type:        DataPointDefinitionTypeNumber,
		Low:         1,
		High:        100,
		Description: "Lower boundary for average indoor target temperature where algorithm operations stops",
		Readonly:    false,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// ITT
	string(eqmodel.ConfigurationTypeIndoorTemperatureTarget): {
		ID:          "TEOS/Thresholds/Indoor/Target Temperature",
		TeosID:      string(eqmodel.ConfigurationTypeIndoorTemperatureTarget),
		Sensor:      false,
		Type:        DataPointDefinitionTypeNumber,
		Low:         1,
		High:        100,
		Description: "The buildings desired average indoor target temperature",
		Readonly:    false,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// OBT
	string(eqmodel.ConfigurationTypeOutdoorBalanceTemperature): {
		ID:          "TEOS/Thresholds/Outdoor/Balance Temperature",
		TeosID:      string(eqmodel.ConfigurationTypeOutdoorBalanceTemperature),
		Sensor:      false,
		Type:        DataPointDefinitionTypeNumber,
		Low:         1,
		High:        100,
		Description: "Outdoor temperature limit when heating systems stops due to warm weather",
		Readonly:    false,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
}
