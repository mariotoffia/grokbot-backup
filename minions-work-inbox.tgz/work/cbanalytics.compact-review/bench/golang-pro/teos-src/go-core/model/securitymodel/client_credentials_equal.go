package securitymodel

// Equal returns true when all fields of both ClientCredentialsMaterial
// values are identical. This avoids reflect.DeepEqual for config diffing.
func (c ClientCredentialsMaterial) Equal(other ClientCredentialsMaterial) bool {
	return c.Auth == other.Auth &&
		c.ClientId == other.ClientId &&
		c.ClientSecret == other.ClientSecret &&
		c.Endpoint == other.Endpoint &&
		c.Id == other.Id &&
		c.Key == other.Key &&
		c.ObjectType == other.ObjectType &&
		c.Password == other.Password &&
		c.User == other.User
}
