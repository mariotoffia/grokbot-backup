package logmodel_test

import (
	"testing"

	"github.com/Thiink-LLC/teos/go-core/model/logmodel"
)

func TestIsJSON(t *testing.T) {
	tests := []struct {
		name string
		le   *logmodel.LogEvent
		want bool
	}{
		{"nil receiver", nil, false},
		{"empty string", &logmodel.LogEvent{Message: ""}, false},
		{"whitespace only", &logmodel.LogEvent{Message: "   \n\t"}, false},
		{"valid object", &logmodel.LogEvent{Message: `{"foo":"bar"}`}, true},
		{"valid object with whitespace", &logmodel.LogEvent{Message: "  { \"a\": [] }  \n"}, true},
		{"valid array", &logmodel.LogEvent{Message: `[1,2,3]`}, true},
		{"valid array with whitespace", &logmodel.LogEvent{Message: "\t[true,false]\r\n"}, true},
		{"mismatched brackets 1", &logmodel.LogEvent{Message: "{not json]"}, false},
		{"mismatched brackets 2", &logmodel.LogEvent{Message: "[oops}"}, false},
		{"non-JSON braces", &logmodel.LogEvent{Message: "hello {world}"}, false},
		{"JSON plus extra text", &logmodel.LogEvent{Message: "{\"foo\": \"bar\"} ok"}, false},
		{"empty object", &logmodel.LogEvent{Message: "{ }"}, true},
		{"empty array", &logmodel.LogEvent{Message: "[]"}, true},
		{"open array", &logmodel.LogEvent{Message: "["}, false},
		{"open object", &logmodel.LogEvent{Message: "{"}, false},
		{"no open array", &logmodel.LogEvent{Message: "]"}, false},
		{"no open object", &logmodel.LogEvent{Message: "}"}, false},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := tt.le.IsJSON()
			if got != tt.want {
				t.Errorf("IsJSON() = %v; want %v for test: %s", got, tt.want, tt.name)
			}
		})
	}
}

func BenchmarkIsJSON(b *testing.B) {
	tests := []struct {
		name string
		le   *logmodel.LogEvent
	}{
		{"NilReceiver", nil},
		{"EmptyString", &logmodel.LogEvent{Message: ""}},
		{"WhitespaceOnly", &logmodel.LogEvent{Message: "   \n\t"}},
		{"ValidObject", &logmodel.LogEvent{Message: `{"foo":"bar"}`}},
		{"ValidObjectWithWhitespace", &logmodel.LogEvent{Message: "  { \"a\": [] }  \n"}},
		{"ValidArray", &logmodel.LogEvent{Message: `[1,2,3]`}},
		{"ValidArrayWithWhitespace", &logmodel.LogEvent{Message: "\t[true,false]\r\n"}},
		{"MismatchedBrackets1", &logmodel.LogEvent{Message: "{not json]"}},
		{"MismatchedBrackets2", &logmodel.LogEvent{Message: "[oops}"}},
		{"NonJSONBraces", &logmodel.LogEvent{Message: "hello {world}"}},
		{"JSONPlusExtraText", &logmodel.LogEvent{Message: "{\"foo\": \"bar\"} ok"}},
		{"EmptyObject", &logmodel.LogEvent{Message: "{ }"}},
		{"EmptyArray", &logmodel.LogEvent{Message: "[]"}},
	}
	for _, tt := range tests {
		b.Run(tt.name, func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				tt.le.IsJSON()
			}
		})
	}
}
