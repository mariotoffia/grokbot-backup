package reportmodel

import (
	"encoding/json"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// RemoteDataPointInfo is a struct that contains information about a remote
// datapoint. It is used to be a value, keyed with a thiink wellknown
// datapoint/sensor id.
//
// This is used in `ExportDataPointReport` and `ImportDataPointReport`.
type RemoteDataPointInfo struct {
	// RemoteID is the identifier of the remote datapoint. It can be anything.
	//
	// TIP: Sometimes the `RemoteID` *and* the `RemotePartition` combined is the
	//      unique remote id.
	//
	RemoteID string `json:"rid"`
	// Value is the value to be written or read from the remote datapoint.
	Value interface{} `json:"v,omitempty"`
	// Optional determines if the _DataPoint_ is mandatory or optional.
	Optional bool `json:"opt,omitempty"`
	// RemotePartition is a partition of the remote datapoint (if any).
	RemotePartition string `json:"rp,omitempty"`
	// RemoteTimeStamp is the timestamp of the remote datapoint (or to be written).
	RemoteTimeStamp string `json:"ts,omitempty"`
	// Error is an optional error that may describe why the datapoint could non be exported / imported.
	//
	// NOTE: When exported this will translate to an array since it may be a `cberror.CbCompositeError` or
	//       wrapped into several errors. Those are flattened into a single array.
	Error cberror.Error `json:"err,omitempty"`
}

// NewFromCbDataPoint creates a new `RemoteDataPointInfo` from a `CbDataPoint`.
func NewFromCbDataPoint(dp eqmodel.CbDataPoint, optional bool) RemoteDataPointInfo {
	info := RemoteDataPointInfo{
		RemoteID:        dp.GetID(),
		Value:           dp.GetValue(),
		RemotePartition: dp.GetPartition(),
		Error:           dp.GetError(),
		Optional:        optional,
	}

	if dp.HasTimeStamp() {
		info.RemoteTimeStamp = dp.GetTimeStamp().RFC3339()
	}

	return info
}

// ExportDataPointReport is emitted when a set of datapoints/sensors
// are successfully exported.
//
// NOTE: It may report on a subset of of all sensors, hence some may be part of
//
//	`MissingDataPointReport` instead.
//
// When logging this report. On root level the _lid_ (LocationId), if known,
// is *REQUIRED* to be included (if multiple, use a string array). The same
// goes for _pn_ (ProviderName).
//
// .Example Log Entry of a ExportDataPointReport
// [source,json]
// ----
//
//	{
//		"s": "noda/outbound",
//		"level": "info",
//		"lid": "Junit 18",
//		"body": {
//		  "dp": {
//			"MPRT": {
//			  "v": 45.2,
//			  "rn": "meter_primreturntemp",
//			  "rid": 2,
//			  "ts": "2020-06-08T12:45:12%2B02:00"
//			},
//			"MPST": {
//			  "v": 75.1,
//			  "rn": "meter_primsupplytemp",
//			  "rid": 2,
//			  "ts": "2020-06-08T12:45:12%2B02:00"
//			}
//		  },
//		  "body": {"some": "optional body info"},
//		},
//		"message": "Successfully exported data to Noda",
//		"m": "ExportDataPointReport",
//		"pn": "noda"
//	}
//
// ----
type ExportDataPointReport struct {
	// Count is the number of _DataPoints_ in the hash.
	Count int `json:"c"`
	// Sensors are keyed with the datapoint/sensor id.
	DataPoints map[string]RemoteDataPointInfo `json:"dp"`
	// Body is an optional parameter where the body of the data is provided.
	Body interface{} `json:"body,omitempty"`
}

// ImportDataPointReport is emitted when a set of datapoints/sensors
// are successfully imported.
//
// NOTE: It may report on a subset of of all sensors, hence some may be part of
//
//	`MissingDataPointReport` instead.
//
// When logging this report. On root level the _lid_ (LocationId), if known,
// is *REQUIRED* to be included (if multiple, use a string array). The same
// goes for _pn_ (ProviderName).
//
// .Example Log Entry of a ImportDataPointReport:
// [source,json]
// ----
//
//	{
//		"s": "noda/inbound",
//		"level": "info",
//		"lid": "BuildingA",
//		"dp": {
//			"OFFODT": {
//		  		"v": "2.074",
//		  		"rid": 2,
//		  		"rn": "outdoortemp_offset",
//		  		"ts": "2020-10-27T12:13:30+01:00"
//			}
//		},
//		"message": "Imported Sensor data",
//		"m": "ImportDataPointReport",
//		"pn": "noda"
//	}
//
// ----
type ImportDataPointReport struct {
	// Count is the number of _DataPoints_ in the hash.
	Count int `json:"c"`
	// Sensors are keyed with the datapoint/sensor id.
	DataPoints map[string]RemoteDataPointInfo `json:"dp"`
	// Body is an optional parameter where the body of the data is provided.
	Body *json.RawMessage `json:"body,omitempty"`
}

// MissingDataPointReport is reported by providers when one or more datapoint
// is missing from the requested one. When outbound, this represents a datapoint
// that could not be written.
//
// NOTE: It may be quite reasonable that some datapoints are missing!
//
// When logging this report. On root level the _lid_ (LocationId), if known,
// is *REQUIRED* to be included (if multiple, use a string array). The same
// goes for _pn_ (ProviderName).
//
// .Example Log Entry of a Missing Datapoint
// [source,json]
// ----
//
//	{
//		"s": "noda/inbound",
//		"level": "info",
//		"lid": "BuildingB",
//		"body": {
//			"missing": {
//				"OFFODT": { "rid": "3", "rn": "outdoortemp_offset" }
//			},
//			"wanted": {
//				"OFFODT": { "rid": "3", "rn": "outdoortemp_offset" }
//			}
//		},
//		"message": "Missing data-point for climate control",
//		"m": "MissingDataPointReport",
//		"pn": "noda"
//	}
//
// ----
type MissingDataPointReport struct {
	// AllAreMissing is `true` when all the mandatory *and* optional datapoints are missing.
	AllAreMissing bool `json:"am"`

	// MandatoryMissingCount is the number of wanted/mandatory  _DataPoints_ that are missing.
	MandatoryMissingCount int `json:"mc"`
	// MandatoryWantedCount is the number of mandatory _DataPoints_ that are wanted.
	MandatoryWantedCount int `json:"wc"`

	// OptionalMissingCount is the number of optional  _DataPoints_ that are missing.
	OptionalMissingCount int `json:"omc"`
	// OptionalWantedCount is the number of optional _DataPoints_ that are wanted.
	OptionalWantedCount int `json:"owc"`

	// Body is an optional parameter where the body of the data is provided.
	Body *json.RawMessage `json:"body,omitempty"`
	// Wanted is all of the datapoints wanted when the request was made.
	Wanted map[string]RemoteDataPointInfo `json:"wanted"`
	// Missing is all of the datapoints that were not recieved (or was failed for some reason).
	Missing map[string]RemoteDataPointInfo `json:"missing"`
	// Operation may any of the `locationmodel.PipeOperation`
	Operation string `json:"oper"`
}
