package eqmodel

import (
	"fmt"
	"strings"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/utils/cbreflect"
)

// CbDataPointImpl is a default implementation that provider may use to map the datapoints to.
//
// Since the _JSON_ tags and types are fixed in this structure. It may not fit the needs when integrating
// towards a remote provider. Sometimes it is possible to do rewrites using a custom Unmarshaler.
//
// .Simple JSON Rewrite
// [source,go]
// ----
//
//	type myDataPoint struct {
//		eqmodel.CbDataPointImpl
//	}
//
// func (dp *myDataPoint) UnmarshalJSON(data []byte) error {
//
//	 type myPayload struct {
//			ID string `json:"device_id"`
//			Value float64 `json:"device_value"`
//	}
//
//		var payload myPayload
//		if err := json.Unmarshal(data, &payload); err != nil {
//			return err
//		}
//
//		*dp = myDataPoint{
//			CbDataPointImpl: eqmodel.CbDataPointImpl{
//				ID: payload.ID,
//				Value: payload.Value,
//			}
//		}
//
//		return nil
//	}
//
// ----
type CbDataPointImpl struct {
	// ID is the ID of the data point.
	// By default json tag is set to _n_ but may be overridden.
	ID string `json:"n,omitempty"`
	// Value is the value of the data point.
	// By default json tag is set to _v_ but may be overridden.
	Value any `json:"v,omitempty"`
	// Partition is the partition the partition for the datapoint (if any).
	// By default json tag is set to _p_ but may be overridden.
	Partition string `json:"p,omitempty"`
	// TimeStamp is the timestamp of the data point.
	// By default json tag is set to _ts_ but may be overridden.
	TimeStamp coremodel.CbTime32 `json:"ts,omitempty"`
	// Error is the error that occurred while importing / exporting the data point.
	Error cberror.Error `json:"-"`
	// CustomData is a map of custom data that may be used to store additional information.
	CustomData map[string]any `json:"custom,omitempty"`
}

// BaseID will return the base ID without any circuits, zones or ordinal (if present).
func (dp CbDataPointImpl) BaseID() string {
	if strings.Contains(dp.ID, "_") {
		return strings.Split(dp.ID, "_")[0]
	}

	return dp.ID
}

// GetID returns the ID of the data point.
func (dp CbDataPointImpl) GetID() string {
	return dp.ID
}

// GetValue returns the value of the data point (if any).
func (dp CbDataPointImpl) GetValue() any {
	return dp.Value
}

// GetPartition returns the partition the `GetID` is within (if any).
func (dp CbDataPointImpl) GetPartition() string {
	return dp.Partition
}

// HasTimeStamp returns `true“ if the data point has a timestamp.
func (dp CbDataPointImpl) HasTimeStamp() bool {
	return !dp.TimeStamp.IsZero()
}

// GetTimeStamp returns the timestamp of the data point.
func (dp CbDataPointImpl) GetTimeStamp() coremodel.CbTime32 {
	return dp.TimeStamp
}

// GetError may return an error that have occurred while importing / exporting this datapoint
func (dp CbDataPointImpl) GetError() cberror.Error {
	return dp.Error
}

// GetCustomData returns the custom data of the data point.
func (dp CbDataPointImpl) GetCustomData() map[string]any {
	return dp.CustomData
}

// FindDataPoint searches the array of _dp_ if it contains a `CbDataPoint.GetID()` matching the _id_.
//
// If _dp_ is `nil` or empty, it returns `nil`. If it fails to find a matching data point, it returns `nil`.
func FindDataPoint(dp []CbDataPoint, id string) (CbDataPoint, bool) {
	if len(dp) == 0 {
		return nil, false
	}

	for _, dp := range dp {
		if dp.GetID() == id {
			return dp, true
		}
	}
	return nil, false
}

// FindDataPointImpl is exactly the same as `FindDataPoint` but for the `CbDataPointImpl` type.
func FindDataPointImpl(dp []CbDataPointImpl, id string) (*CbDataPointImpl, bool) {
	if len(dp) == 0 {
		return nil, false
	}

	for _, dp := range dp {
		if dp.GetID() == id {
			return &dp, true
		}
	}
	return nil, false
}

// FindAndRemoveDataPointImpl does the same as `FindDataPointImpl` but also removes the found data point
// from the slice (if found).
func FindAndRemoveDataPointImpl(
	dp []CbDataPointImpl,
	id string,
) (*CbDataPointImpl, []CbDataPointImpl, bool) {
	if len(dp) == 0 {
		return nil, dp, false
	}

	for i, d := range dp {
		if d.GetID() == id {
			return &d, append(dp[:i], dp[i+1:]...), true
		}
	}
	return nil, dp, false
}

// FromImplToDataPoint converts the _dp_ to a slice of `CbDataPoint`s.
func FromImplToDataPoint(dp []CbDataPointImpl) []CbDataPoint {
	if len(dp) == 0 {
		return nil
	}

	var arr []CbDataPoint
	for _, d := range dp {
		arr = append(arr, &d)
	}
	return arr
}

// ToCbDataPointSlice converts a slice of structs that implement the
// `CbDataPoint` interface to a slice of `CbDataPoint`s.
//
// TIP: If your slice is not a pointer array or of other form use the more
// versatile `ToCbDataPointSliceDynamic` instead. Caution, it may be slow!
func ToCbDataPointSlice[T CbDataPoint](s []T) []CbDataPoint {
	r := make([]CbDataPoint, len(s))

	for i := range s {
		r[i] = s[i]
	}

	return r
}

func ToCbDataPointMap[T CbDataPoint](m map[string]T) map[string]CbDataPoint {
	r := make(map[string]CbDataPoint, len(m))

	for k, v := range m {
		r[k] = v
	}

	return r
}

func ToCbDataPointMapArray[T CbDataPoint](m map[string][]T) map[string][]CbDataPoint {
	r := make(map[string][]CbDataPoint, len(m))

	for k, v := range m {
		r[k] = ToCbDataPointSlice(v)
	}

	return r
}

func ToCbDataPointArrayMap[T CbDataPoint](m map[string][]T) map[string][]CbDataPoint {
	r := make(map[string][]CbDataPoint, len(m))

	for k, v := range m {
		r[k] = make([]CbDataPoint, 0, len(v))

		for i := range v {
			r[k] = append(r[k], v[i])
		}
	}

	return r
}

// ToCbDataPointSliceFromMap converts a map of structs that implement the
// `CbDataPoint` interface to a slice of `CbDataPoint`s.
func ToCbDataPointSliceFromMap[T CbDataPoint](m map[string]T) []CbDataPoint {
	r := make([]CbDataPoint, len(m))

	i := 0
	for _, v := range m {
		r[i] = v
		i++
	}

	return r
}

// ToCbDataPointSliceDynamic converts a slice of structs that supposedly implement the
// `CbDataPoint` interface to a slice of `CbDataPoint`s.
//
// This function do reflection and hence is a bit slow. It supports both pointer
// struct and non pointer struct arrays.
//
// CAUTION: If the slice is a pointer array that each element implements `CbDataPoint`
// you is _REQUIRED_ to use `ToCbDataPointSlice` instead!
func ToCbDataPointSliceDynamic(dp any) ([]CbDataPoint, error) {
	if dp == nil {
		return nil, fmt.Errorf("data point is nil")
	}

	if dpSlice, ok := dp.([]CbDataPoint); ok {
		return dpSlice, nil
	}

	if dp, ok := dp.(CbDataPoint); ok {
		return []CbDataPoint{dp}, nil
	}

	if dpc, ok := dp.([]CbDataPointImpl); ok {
		var arr []CbDataPoint

		for _, dp := range dpc {
			arr = append(arr, &dp)
		}

		return arr, nil
	}

	if dpc, ok := dp.([]*CbDataPointImpl); ok {
		var arr []CbDataPoint

		for _, dp := range dpc {
			arr = append(arr, dp)
		}

		return arr, nil
	}

	iter, err := cbreflect.NewArraySliceIterator(dp)
	if err != nil {
		return nil, err
	}

	var kv *cbreflect.KeyValue
	var arr []CbDataPoint
	for kv = iter.Next(); kv != nil; kv = iter.Next() {
		var value any
		if cbreflect.IsPointer(kv.Value.Interface()) {
			value = kv.Value.Interface()
		} else {
			value = kv.Value.Addr().Interface()
		}

		if dp, ok := value.(CbDataPoint); ok {
			arr = append(arr, dp)
		} else {
			return nil, fmt.Errorf("value is not a CbDataPoint: %T", kv.Value)
		}
	}

	return arr, nil
}

// ConvertToDataPointMap will try to convert the _m_ into a `map[string][]CbDataPoint`. It supports
// both `map[string][]type implements CbDataPoint` and `map[string]type that implements CbDataPoint`.
//
// If fails to convert it return an error.
//
// NOTE: it will *NOT* add any arrays with length zero. If any `nil` value is found it will return an error.
//
// This function uses reflection if the type is not a `map[string][]CbDataPoint` or `map[string]CbDataPoint`.
func ConvertToDataPointArrayMap(m map[string]any) (map[string][]CbDataPoint, error) {
	if len(m) == 0 {
		return nil, nil
	}

	var arrMap = make(map[string][]CbDataPoint, len(m))
	for k, v := range m {
		if v == nil {
			return nil, fmt.Errorf("value for: %s is nil", k)
		}

		if dp, ok := v.([]CbDataPoint); ok {
			arrMap[k] = dp
			continue
		}

		if dp, ok := v.(CbDataPoint); ok {
			arrMap[k] = []CbDataPoint{dp}
			continue
		}

		// check if array type -> iterate and convert
		iter, err := cbreflect.NewArraySliceIterator(v)

		if err != nil {
			return nil, err
		}

		var (
			kv  *cbreflect.KeyValue
			arr []CbDataPoint
		)

		for kv = iter.Next(); kv != nil; kv = iter.Next() {
			var value any
			if cbreflect.IsPointer(kv.Value.Interface()) {
				value = kv.Value.Interface()
			} else {
				value = kv.Value.Addr().Interface()
			}

			if dp, ok := value.(CbDataPoint); ok {
				arr = append(arr, dp)
			} else {
				return nil, fmt.Errorf("value is not a CbDataPoint: %T", kv.Value)
			}
		}

		arrMap[k] = arr

		return nil, fmt.Errorf("value is not a CbDataPoint: %T", v)
	}

	return arrMap, nil
}

// SizeDataPointErrors will count the number of errors in the given data points.
func SizeDataPointErrors(cbDpl []CbDataPoint) int {
	if len(cbDpl) == 0 {
		return 0
	}

	var count int
	for _, dp := range cbDpl {
		if dp.GetError() != nil {
			count++
		}
	}
	return count
}
