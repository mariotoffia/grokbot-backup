package pubsubmodel

// ClassifierType is the type of classifier.
type ClassifierType string

const (
	// ClassifierTypeDsBuilding will check if the event or event body is a `DsBuilding`.
	ClassifierTypeDsBuilding ClassifierType = "ds-building"
)

// Exists will check if the _c_ exists in the _s_ slice.
func (c ClassifierType) Exists(s []ClassifierType) bool {
	for _, v := range s {
		if v == c {
			return true
		}
	}
	return false
}
