package coremodel

import (
	"bytes"
	"strconv"
	"time"
)

// CbTime64 defines a _64bit Unix Timestamp_ encoded as epoch milliseconds and may
// be used in _JSON_ marshal and un-marshalling.
//
// It is also able to create _time.Time_ with a specific timezone from
// this _UTC_ timestamp that have https://www.iana.org/time-zones[IANA compatible zone names].
// In order to create such _time.Time_ use the extension function
// @WithTimeZone.
type CbTime64 time.Time

// IsZero returns true if the time value is zero
func (t CbTime64) IsZero() bool {
	return time.Time(t).IsZero()
}

// MarshalJSON is used to convert the _Unix Epoch Timestamp_ in milliseconds to _JSON_
func (t CbTime64) MarshalJSON() ([]byte, error) {
	return []byte(strconv.FormatInt(
		time.Time(t).UnixNano()/int64(time.Millisecond), 10),
	), nil

}

// UnmarshalJSON is used to convert the _Unix Epoch Timestamp_ from _JSON_
func (t *CbTime64) UnmarshalJSON(s []byte) (err error) {
	if bytes.ContainsAny(s, "Z+-:") {
		// -number is not a time.Time
		if s[0] != '-' {
			var t2 time.Time

			if err := t2.UnmarshalJSON(s); err != nil {
				return err
			}

			*(*time.Time)(t) = t2

			return
		}
	}

	q, err := strconv.ParseInt(string(s), 10, 64)

	if err != nil {
		return err
	}

	*(*time.Time)(t) = NewTime64(q).UTC()

	return nil
}

// NewOptionalTime64 returns a new instance of time.
//
// If the _t_ is `nil`, the resulting instance will return
// `true` on `CbTime64.IsZero`.
func NewOptionalTime64(t *int64) *CbTime64 {
	if t == nil {
		return NewTime64(0)
	}

	return NewTime64(*t)

}

// NewTime64 creates a new time based on the _Unix Epoch Timestamp_
// measured in milliseconds.
func NewTime64(milliseconds int64) *CbTime64 {
	var s, n int64
	if milliseconds == 0 {
		s = 0
		n = 0
	} else {
		s = milliseconds / 1000
		n = (milliseconds % 1000) * int64(time.Millisecond)
	}

	t := &CbTime64{}
	*(*time.Time)(t) = time.Unix(s, n)

	return t
}

// Creates a new `CbTime64` from current date and time
func NewTime64Now() *CbTime64 {
	return NewTime64(time.Now().UnixNano() / int64(time.Millisecond))

}

// Unix returns _CbTime64_ as a _Unix Epoch Time_, the number of milliseconds elapsed
// since January 1, 1970 UTC. The result does not depend on the location associated with t.
func (t CbTime64) Unix() int64 {
	return time.Time(t).UnixNano() / int64(time.Millisecond)
}

// UTC returns the _CbTime64_ as a _time.Time instance in _UTC_
func (t CbTime64) UTC() time.Time {
	return time.Time(t).UTC()
}

// CbTime64UTC creates a new _CbTime64_ with the time as _UTC_.
func (t CbTime32) CbTime64UTC() CbTime64 {
	return CbTime64(t.UTC())
}

// WithTimeZone creates a new time.Time with the specific timeZone e.g. _Europe/Stockholm_ or _UTC_.
// Note that _UTC_ do not have daylight saving whereas _Europe/Stockholm_ has one hour shift twice a year.
//
// .Example usage
// [source,go]
// ----
// t, err := NewTime(1601902283).WithTimeZone("Europe/Stockholm") // Local time (offset +02:00)
// ----
func (t CbTime64) WithTimeZone(timeZone string) (time.Time, error) {
	return In(t.UTC(), timeZone)
}
