package logmodel

import (
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

type LogGroup struct {
	// The _ID_ or _URI_ to the log group.
	//
	// For example, in _AWS_ this is the _ARN_ to the log group.
	ID string
	// The creation time of the log group, expressed as the number of milliseconds
	// after Jan 1, 1970 00:00:00 UTC.
	CreationTime coremodel.CbTime64
	// KeyID is the id of the key that this loggroup uses to encrypt the logs.
	//
	// For example, _AWS KMS_ key _ID_ or _ARN_.
	KeyID string
	// Name is the name of the log group.
	Name string
	// Retention is the time until the logevents gets discarded from the group.
	Retention time.Duration
	// Size is the number of bytes stored inside the log group.
	Size int64
}
