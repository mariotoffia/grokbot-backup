package securitymodel

import "encoding/json"

// Actor is the "act" in the https://datatracker.ietf.org/doc/html/rfc8693#name-act-actor-claim[OAuth 2.0 Token Exchange]
// specification.
type Actor struct {
	// Issuer specifies the principal that issued the license e.g. "https://nordvestor.api.crossbreeed.se/cognito"
	//
	// Defined as "iss" in https://tools.ietf.org/html/rfc7519
	Issuer string `json:"iss,omitempty"`
	// Subject is the principal that is the subject of the API access e.g. "8c059ae6-dee7-4145-a6dc-d2820b4adf70" or
	// "nisse@hult.se".
	//
	// Defined as "sub" in https://tools.ietf.org/html/rfc7519.
	Subject string `json:"sub,omitempty"`
	// Claims is a set of extra claims that is not standardized.
	//
	// Note that these are populated from the root that do not match the well known claims.
	Claims map[string]any `json:"-"`
}

// MarshalJSON to handle custom `Claims` field.
func (act *Actor) MarshalJSON() ([]byte, error) {
	return json.Marshal(act.MarshalMap())
}

// MarshalString will marshal `Actor` into a string.
// If the only value is `Subject` then only that value will be returned.
func (act *Actor) String() string {
	if len(act.Claims) == 0 && len(act.Issuer) == 0 && len(act.Subject) > 0 {
		return act.Subject
	}

	m, err := json.Marshal(act.MarshalMap())
	if err != nil {
		return err.Error()
	}

	return string(m)
}

// MarshalMap will marshal `Actor` into a map.
func (act *Actor) MarshalMap() map[string]any {
	m := map[string]any{}

	for key, value := range act.Claims {
		m[key] = value
	}

	if len(act.Issuer) > 0 {
		m["iss"] = act.Issuer
	}
	if len(act.Subject) > 0 {
		m["sub"] = act.Subject
	}

	return m
}

// UnmarshalJSON to handle custom `Claims` field.
func (act *Actor) UnmarshalJSON(token []byte) error {
	var m map[string]any
	if err := json.Unmarshal(token, &m); err != nil {
		return err
	}

	return act.UnmarshalMap(m)
}

// UnmarshalMap to handle custom `Claims` field.
func (act *Actor) UnmarshalMap(token map[string]any) error {
	act.Claims = map[string]any{}

	for key, value := range token {
		switch key {
		case "iss":
			act.Issuer = value.(string)
		case "sub":
			act.Subject = value.(string)
		default:
			act.Claims[key] = value
		}
	}

	return nil
}
