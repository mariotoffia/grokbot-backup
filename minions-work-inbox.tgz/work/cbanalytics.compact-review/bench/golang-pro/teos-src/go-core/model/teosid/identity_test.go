package teosid_test

import (
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/teosid"
)

func intPtr(value int) *int          { return &value }
func stringPtr(value string) *string { return &value }

func TestParseIdentity(t *testing.T) {
	tests := []struct {
		name string
		raw  string
		want teosid.Identity
	}{
		{
			name: "flat",
			raw:  "IDT",
			want: teosid.Identity{Raw: "IDT", Canonical: "IDT", QualifiedID: "IDT", ID: "IDT"},
		},
		{
			name: "category",
			raw:  "HP.ODT",
			want: teosid.Identity{Raw: "HP.ODT", Canonical: "HP.ODT", QualifiedID: "HP.ODT", Category: "HP", ID: "ODT"},
		},
		{
			name: "category and subcategories",
			raw:  "HP.PRIMARY.LOOP.ODT",
			want: teosid.Identity{Raw: "HP.PRIMARY.LOOP.ODT", Canonical: "HP.PRIMARY.LOOP.ODT", QualifiedID: "HP.PRIMARY.LOOP.ODT", Category: "HP", Subcategories: []string{"PRIMARY", "LOOP"}, SubcategoryPath: "PRIMARY.LOOP", ID: "ODT"},
		},
		{
			name: "all reserved dimensions and custom tags",
			raw:  "HP.PRIMARY.ODT_O02_C3_ZWEST_ALEVEL1_Tdigital_M03",
			want: teosid.Identity{Raw: "HP.PRIMARY.ODT_O02_C3_ZWEST_ALEVEL1_Tdigital_M03", Canonical: "HP.PRIMARY.ODT_O2_C3_ZWEST_ALEVEL1_M03_Tdigital", QualifiedID: "HP.PRIMARY.ODT", Category: "HP", Subcategories: []string{"PRIMARY"}, SubcategoryPath: "PRIMARY", ID: "ODT", Ordinal: intPtr(2), Circuit: intPtr(3), Zone: stringPtr("WEST"), Area: stringPtr("LEVEL1"), Tags: map[string]string{"M": "03", "T": "digital"}},
		},
		{
			name: "dimensions may be omitted",
			raw:  "IDT_C01_Afloor 2",
			want: teosid.Identity{Raw: "IDT_C01_Afloor 2", Canonical: "IDT_C1_Afloor 2", QualifiedID: "IDT", ID: "IDT", Circuit: intPtr(1), Area: stringPtr("floor 2")},
		},
		{
			name: "custom spelling is identity",
			raw:  "IDT_M03",
			want: teosid.Identity{Raw: "IDT_M03", Canonical: "IDT_M03", QualifiedID: "IDT", ID: "IDT", Tags: map[string]string{"M": "03"}},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := teosid.Parse(tt.raw)
			require.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestParseRejectsMalformedIdentity(t *testing.T) {
	tests := []struct {
		raw  string
		code string
	}{
		{"", "empty"},
		{"*", "invalid_base"},
		{"idt", "invalid_base"},
		{"1DT", "invalid_base"},
		{"HP..ODT", "invalid_base"},
		{"IDT_", "empty_suffix"},
		{"IDT_O", "empty_value"},
		{"IDT_Z", "empty_value"},
		{"IDT_O1_O2", "duplicate_dimension"},
		{"IDT_C1_O2", "dimension_order"},
		{"IDT_ZWEST_C1", "dimension_order"},
		{"IDT_M1_O2", "dimension_order"},
		{"IDT_M", "empty_value"},
		{"IDT_M1_M2", "duplicate_tag"},
		{"IDT_m1", "invalid_tag"},
		{"IDT_11", "invalid_tag"},
	}

	for _, tt := range tests {
		t.Run(tt.raw, func(t *testing.T) {
			_, err := teosid.Parse(tt.raw)
			require.Error(t, err)
			var parseErr *teosid.ParseError
			require.True(t, errors.As(err, &parseErr))
			assert.Equal(t, tt.code, parseErr.Code)
			assert.GreaterOrEqual(t, parseErr.Offset, 0)
			assert.LessOrEqual(t, parseErr.Offset, len(tt.raw))
		})
	}
}

func TestRenderCanonicalIdentity(t *testing.T) {
	got, err := teosid.Render(teosid.Parts{
		QualifiedID: "HP.PRIMARY.ODT",
		Ordinal:     intPtr(2),
		Circuit:     intPtr(3),
		Zone:        stringPtr("WEST"),
		Area:        stringPtr("LEVEL1"),
		Tags:        map[string]string{"T": "digital", "M": "03"},
	})
	require.NoError(t, err)
	assert.Equal(t, "HP.PRIMARY.ODT_O2_C3_ZWEST_ALEVEL1_M03_Tdigital", got)

	_, err = teosid.Render(teosid.Parts{QualifiedID: "IDT", Tags: map[string]string{"O": "2"}})
	require.Error(t, err)
}

func TestCustomTagSpellingRemainsDistinct(t *testing.T) {
	withZero, err := teosid.Parse("IDT_M03")
	require.NoError(t, err)
	withoutZero, err := teosid.Parse("IDT_M3")
	require.NoError(t, err)
	assert.NotEqual(t, withZero.Canonical, withoutZero.Canonical)
}
