package internalparams_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/servicemodel/internalparams"
)

// TestEverySectionIsServed checks that Get and List serve a parameter from each
// of the sections the parameter table is built from.
func TestEverySectionIsServed(t *testing.T) {
	names := []string{
		string(eqmodel.SensorIndoorTemp),
		string(eqmodel.DataPointEnabledCircuits),
		string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow),
		"ALTITUDE",
	}

	listed := internalparams.List()

	for _, name := range names {
		p, ok := internalparams.Get(name)
		require.True(t, ok, name)
		assert.Equal(t, name, p.Name)
		assert.Contains(t, listed, name)
	}
}
