package eqmodel

// EqParams is specifying well known constants for the equipment or sensor parameters such
// as the `EqState`.
type EqParams string

// EqStateTypes represents the different installation states of the equipment.
type EqStateTypes string

const (
	// EqStateInstalled is when the equipment is installed but not online.
	EqStateInstalled EqStateTypes = "installed"
	// EqStateOnline is when the equipment is installed and online.
	EqStateOnline EqStateTypes = "online"
	// EqStateOffline is when the equipment is installed but offline.
	EqStateOffline EqStateTypes = "offline"
	// EqStateNotInstalled is when the equipment is uninstalled. This is a "generic" state
	// where the equipment is not installed but no further information is available.
	EqStateNotInstalled EqStateTypes = "not-installed"
	// EqStateInTransit is when the equipment is in transit.
	EqStateInTransit EqStateTypes = "in-transit"
	// EqStateOrdered is when the equipment is ordered but not yet shipped (or unknown transit state).
	EqStateOrdered EqStateTypes = "ordered"
	// EqStateBroken is when the equipment is broken.
	EqStateBroken EqStateTypes = "broken"
)

const (
	// EqState specifies the overall state of the equipment.
	EqState EqParams = "STATE"
	// EqLastUpdated is a parameter that is set to the timestamp of the last update of the equipment/sensor
	// configuration.
	//
	// NOTE: This is used to determine if the newly imported instance shall be used or not. I.e. if it
	// is newer than the existing instance in the repository.
	//
	// A provider *shall* provide with this timestamp if it is available.
	//
	// This is when the timestamp is for the whole equipment/sensor instead of the individual. Then it
	// will reside in params.ts as a map[string]int64 or float64 where the key is the ID of which the timestamp reflect
	// the last update in unix 64 bit, millisecond, resolution.
	EqLastUpdated EqParams = "LASTUPD"
	// EqOperationalValues represents a `map[string]any` of operational values for the equipment.
	//
	// For Example a indoor sensor, would have a _IDT_ and a float value for the temperature.
	EqOperationalValues EqParams = "OPVAL"
	// This stipulates how the ordinal is calculated for sensors attached to the equipment. If
	// this is set, then it will start with the ordinal specified in the parameter and upward.
	//
	// NOTE: This this does not affect sensors that are already assigned a valid _TEOS ID_ with
	// the `EqTeosID`.
	EqOrdinalStart EqParams = "ORDSTART"
	// EqCircuit specifies if the sensor is attached to a circuit.
	EqCircuit EqParams = "CIRCUIT"
)
