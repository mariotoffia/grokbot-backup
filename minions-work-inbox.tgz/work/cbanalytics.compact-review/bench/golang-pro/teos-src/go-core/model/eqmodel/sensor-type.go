package eqmodel

// SensorType is specifying the sensor type.
//
// The `SensorType` is a specialization of `DataPointType` and
// shall be regarded as datapoints. However, sensors are reflecting
// a real sensor.
//
// A sensor identity uses the format:
//
//	[CATEGORY[.SUBCATEGORY]*.]ID[_On][_Cn][_Zstr][_Astr][_<tag><value>]*
//
// The base identity (everything before the first '_') supports dot-separated
// hierarchical naming. Each segment must match [A-Z][A-Z0-9]* (uppercase ASCII
// letters and digits, starting with a letter). Tags O, C, Z, A must appear in
// that relative order when present, but any may be omitted. Custom tags (single
// uppercase letter key other than O, C, Z, A) follow after all well-known tags.
//
// |===
// |Symbol |Example         |Description
//
// |ID |IDT, INDOOR.TEMP |Base identity, optionally hierarchical with '.' separator.
// |O  |O3               |_Ordinal_ of the sensor if it is part of multiple sensors with same _ID_.
// |C  |C1               |The _Circuit_ where the sensor is attached.
// |Z  |ZMyZone          |The grouping or zone where this sensor belongs to.
// |A  |Amy-area         |The _Area_ where the sensor is located.
//
// |===
//
// NOTE: If single sensor, of specific type, and no circuits, zone, or area, the sensor is named just _ID_.
//
// .Sensor Names
// ====
// 1. ODT
// 2. IDT_O14_C1
// 3. IDT_O2_ZLgh14
// 4. INDOOR.TEMP_O1
// 5. INVERTER.L1_O2_C3
// 6. IDT_Awest
// ====
//
// TIP: Use `SensorType.Validate` to verify that it has correct form.
//
// By default _Cn_ stands for _Circuit_ that has a heat exchanger. It is possible for it to be representing
// a shunt group instead (without a exchanger) by specifying the parameter CTP_Cn=shunt|exchanger.
type SensorType string

const (
	// SensorIndoorTemp measures indoor temperature.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorIndoorTemp SensorType = "IDT"

	// SensorHumidity represents a relative humidity (expressed as a percent) also measures
	// water vapor, but RELATIVE to the temperature of the air. In other words, it is a
	// measure of the actual amount of water vapor in the air compared to the total amount
	// of vapor that can exist in the air at its current temperature.
	//
	// Unit: %, Resolution: 1 %
	SensorHumidity SensorType = "HUM"

	// SensorOutdoorTemp measures the outdoor temperature.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorOutdoorTemp SensorType = "ODT"

	// SensorAverageIndoorTemp is a average of all of the indoor temperature sensors.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorAverageIndoorTemp SensorType = "AVGIDT"
	// SensorMedianIndoorTemp is the median of all of the indoor temperature sensors.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorMedianIndoorTemp SensorType = "MEDIDT"
	// SensorMinIndoorTemp is the single lowest temperature in the building.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorMinIndoorTemp SensorType = "MINIDT"

	// SensorMaxIndoorTemp is the single lowest temperature in the building.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorMaxIndoorTemp SensorType = "MAXIDT"

	// SensorOffsetOutdoorTemperature is a "virtual" sensor
	// that represents the offset value that the heating
	// system shall regulate towards (ODT + OFFODT = regulated towards)
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorOffsetOutdoorTemperature SensorType = "OFFODT"

	// SensorActiveOutdoorTemperature is the temperature that the
	// heater is currently regulating towards - often this is
	// ODT + OFFODT
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorActiveOutdoorTemperature SensorType = "ACTODT"

	// SensorSupplyHeatingPrimaryCircuitTemperature is measuring temperature
	// in a heating circuit that is classified as primary temperature measurement.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplyHeatingPrimaryCircuitTemperature SensorType = "SPHCT"

	// SensorReturnHeatingPrimaryCircuitTemperature is measuring temperature
	// in a heating circuit that is classified as primary temperature measurement.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorReturnHeatingPrimaryCircuitTemperature SensorType = "RPHCT"

	// SensorSupplyHeatingSecondaryCircuitTemperature is measuring temperature
	// in a heating circuit that is classified as secondary temperature measurement.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplyHeatingSecondaryCircuitTemperature SensorType = "SSHCT"

	// SensorSupplySetPointHeatingSecondaryCircuitTemperature is the set-point for the secondary
	// heating circuit supply temperature. This is the calculated setpoint by the DUC and is
	// used when the algorithm is not controlling the system.
	//
	// This is in contrast to _SSHCT_ where this is the value it strives to and the _SSHCT_ is
	// the actual value and the _SSHCT_ is the measured temperature.
	//
	// NOTE: When controlling with offset (_see OFFSPSSHCT_) this is usually read by _TEOS_ in order
	// to validate that the system is targeting the correct temperature set by the offset. It is also
	// used to validate when a non offset control _ACTSPSSHCT_ is used instead of an offset to verify
	// that the system is actually responding to it.
	//
	// The system will also track so the _SSHCT_ is driving towards this value.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplySetPointHeatingSecondaryCircuitTemperature SensorType = "SPSSHCT"

	// SensorSupplySetPointHeatingSecondaryCircuitTemperatureOffset is the offset for the secondary
	// heating circuit supply temperature. This is used when controlling the secondary circuit
	// temperature.
	//
	// TIP: In some system, it is possible to validate that this offset is provisioned by reading
	// the _SPSSHCT_ value since it will reflect this offset.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplySetPointHeatingSecondaryCircuitTemperatureOffset SensorType = "OFFSPSSHCT"

	// SensorSupplyActingHeatingSecondaryCircuitTemperature is a control from TEOS to alter the
	// _SPSSHCT_. This the _DUC_ must be able to use this value instead of the _SPSSHCT_.
	//
	// When the _COMT_ has expired, the _DUC_ will revert back to the _SPSSHCT_, otherwise it will
	// use this value.
	//
	// The offset that the algorithm is modifying the heating can calculated as _SPSSHCT_ - _ACTSPSSHCT_.
	// Hence, the saving is the diff.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplyActingHeatingSecondaryCircuitTemperature SensorType = "ACTSPSSHCT"
	// SensorPrimaryCircuitReturnTemperatureActingSetPoint is the acting set-point for the primary heating circuit
	// return temperature.
	//
	// This is set by an algorithm to adjust the setpoint that is used to control the supply temperature on
	// the return side. This is to guarantee that that the system will never have heating water that is colder
	// than the setpoint.
	//
	// The _DUC_ will use this value instead of the _SPRHCT_ when the _COMT_ has not expired.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorPrimaryCircuitReturnTemperatureActingSetPoint SensorType = "ACTSPRHCT"
	// SensorPrimaryCircuitReturnTemperatureSetPoint is a setpoint to control the primary heating circuit
	// return temperature.
	//
	// This is the value that the _DUC_ will use to control the supply temperature on the return side. This
	// is to guarantee that that the system will never have heating water that is colder than the setpoint.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorPrimaryCircuitReturnTemperatureSetPoint SensorType = "SPRHCT"

	// SensorReturnHeatingSecondaryCircuitTemperature is measuring temperature
	// in a heating circuit that is classified as secondary temperature measurement.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorReturnHeatingSecondaryCircuitTemperature SensorType = "RSHCT"

	// SensorMeterPrimarySideTemperature is a value from _heat meter_ (normally owned by
	// district heating provider).
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorMeterPrimarySideTemperature SensorType = "MPST"

	// SensorMeterPrimaryReturnTemperature is a value from _heat meter_ (normally owned by
	// district heating provider)
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorMeterPrimaryReturnTemperature SensorType = "MPRT"

	// SensorAggregatedMassFlowPrimarySide is a value from _heat meter_ (normally owned by
	// district heating provider).
	//
	// This is the cumulative / aggregated volume on the meter itself.
	//
	// Unit: stem:[m^3], Resolution 0.1 stem:[m^3]
	SensorAggregatedMassFlowPrimarySide SensorType = "AMFPS"

	// SensorAggregatedMassFlow is the generic aggregated mass-flow sensor
	//
	// This is the cumulative / aggregated volume in a unspecified place,
	// but it may be on the meter itself (_see AMFPS_).
	//
	// Unit: stem:[m^3], Resolution: 0.1 stem:[m^3]
	SensorAggregatedMassFlow SensorType = "AMF"

	// SensorMassFlowPrimarySide is a value from _heat meter_ (normally owned by
	// district heating provider)
	//
	// This sensor measures the flow per hour.
	//
	// Unit: stem:[m^3/h], Resolution: 0.001 stem:[m^3/h]
	SensorMassFlowPrimarySide SensorType = "MFPS"

	// SensorAggregatedEnergyUsagePrimarySide is a value from _heat meter_ (normally owned by
	// district heating provider)
	//
	// This is cumulative / aggregated measured energy on the _heat meter_ itself.
	//
	// Unit: kWh, Resolution: 0.1 kWh
	SensorAggregatedEnergyUsagePrimarySide SensorType = "AEUPS"

	// SensorHeatDemandPrimarySide is a value from _heat meter_ (normally owned by
	// district heating provider)
	//
	// Total effect demanded by the all the circuits, measured by the _heat meter_ itself.
	// This is the cumulative / aggregated effect for all circuits.
	//
	// Unit: kW, Resolution: 0.1 kW
	SensorHeatDemandPrimarySide SensorType = "HDPS"

	// SensorSupplyHotWaterPrimaryCircuitTemperature is measuring temperature
	// in a hot water circuit that is classified as primary temperature measurement.
	//
	// This is independent on which circuit number is belongs to so e.g.
	// _SPHWCT_ may translate to _SHWCT_C13_.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplyHotWaterPrimaryCircuitTemperature SensorType = "SPHWCT"

	// SensorReturnHotWaterPrimaryCircuitTemperature is measuring temperature
	// in a hot water circuit that is classified as primary temperature measurement.
	//
	// This is independent on which circuit number is belongs to so e.g.
	// _RPHWCT_ may translate to _RHWCT_C4_.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorReturnHotWaterPrimaryCircuitTemperature SensorType = "RPHWCT"

	// SensorSupplyHotWaterSecondaryCircuitTemperature is measuring temperature
	// in a hot water circuit that is classified as secondary temperature measurement.
	//
	// This is independent on which circuit number is belongs to so e.g.
	// _SSHWCT_ may translate to _SHWCT_C1_.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplyHotWaterSecondaryCircuitTemperature SensorType = "SSHWCT"
	// SensorReturnHotWaterSecondaryCircuitTemperature is measuring temperature
	// in a hot water circuit that is classified as secondary temperature measurement.
	//
	// This is independent on which circuit number is belongs to so e.g.
	// _RSHWCT_ may translate to _RHWCT_C18_.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorReturnHotWaterSecondaryCircuitTemperature SensorType = "RSHWCT"

	// SensorSupplyHotWaterCircuitTemperature is measuring temperature
	// in a hot water circuit (can be one of many circuits)
	// Might be several: each per radiator / ventilation /water circuit
	//
	// One of this is primary and one may be secondary. Those are named
	// _SPHWCT_ (primary) and _SSHWCT_ (secondary). But may also be represented
	// as this name but then it will have an ordinal.
	//
	// For example SHWCT_O15_C1 states that this is return hot water circuit 1 temperature
	// and is numbered as 15. It may also be a _SPHWCT_ or _SSHWCT_ as well.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorSupplyHotWaterCircuitTemperature SensorType = "SHWCT"

	// SensorReturnHotWaterCircuitTemperature is measuring departure
	// in a hot water circuit (can be one of many circuits)
	// Might be several: each per radiator / ventilation /water circuit.
	//
	// One of this is primary and one may be secondary. Those are named
	// _RPHWCT_ (primary) and _RSHWCT_ (secondary). But may also be represented
	// as this name but then it will have an ordinal.
	//
	// For example RHWCT_O3_C2 states that this is return hot water circuit 2 temperature
	// and is numbered as 2. It may also be a _RPHWCT_ or _RSHWCT_ as well.
	//
	// Unit: °C, Resolution: 0.1 °C
	SensorReturnHotWaterCircuitTemperature SensorType = "RHWCT"

	// SensorRawAnalogInput is a raw value from the analog input.
	//
	// It may be any type of float value and do not have any unit.
	SensorRawAnalogInput SensorType = "RAI"

	// SensorRawAnalogOutput is a raw value that may be writable to an
	// analog output port.
	//
	// It may be any type of float value and do not have any unit.
	//
	// NOTE: The port may have restrictions of which value that may be written.
	SensorRawAnalogOutput SensorType = "RAO"

	// SensorRawDigitalInput is a raw value from the digital input.
	//
	// The digital value may have any meaning but is always a single boolean.
	SensorRawDigitalInput SensorType = "RDI"

	// SensorRawDigitalOutput is a raw value that may be writable as a boolean.
	//
	// NOTE: It may or may not be writeable, it is determined by the port itself.
	SensorRawDigitalOutput SensorType = "RDO"
	// SensorSecondaryCircuitPumpControlState is the control state of a pump in a
	// secondary circuit.

	// The state may be any of the following:
	// |===
	// |Symbol |Description
	//
	// |off
	// |The pump is manually forced off (either physical or via software).
	//
	// |on
	// |The pump is manually forced on (either physical or via software).
	//
	// |auto
	// |The pump is in automatic control mode.
	//
	// |===
	SensorSecondaryCircuitPumpControlState SensorType = "SCPCS"
	// SensorSecondaryCircuitPumpState is the state of a pump in a
	// secondary circuit.
	//
	// The state may be any of the following:
	// |===
	// |Symbol |Description
	//
	// |`false` - off
	// |The pump is off.
	//
	// |`true` - on
	// |The pump is on.
	//
	// |===
	SensorSecondaryCircuitPumpState SensorType = "SCPS"
	// SensorSecondaryCircuitValveControlState is the control state of a valve in a
	// secondary circuit.
	// The state may be any of the following:
	// |===
	// |Symbol |Description
	//
	// |off
	// |The valve is manually forced off (either physical or via software).
	//
	// |on
	// |The valve is manually forced on (either physical or via software).
	//
	// |auto
	// |The valve is in automatic control mode.
	//
	// |===
	SensorSecondaryCircuitValveControlState SensorType = "SCVCS"
	// SensorSecondaryCircuitValveState is the state of a valve in a
	// secondary circuit.
	//
	// The state may be any of the following:
	// |===
	// |Symbol |Description
	//
	// |`false` - off
	// |The valve is off.
	//
	// |`true` - on
	// |The valve is on.
	//
	// |===
	SensorSecondaryCircuitValveState SensorType = "SCVS"
	// SensorSecondaryCircuitPumpOutput is a discrete value between 0% - 100% where some
	// pumps may have fixed steps but still are represented as a percentage.
	//
	// Unit: 0% - 100%, Resolution: 1%
	SensorSecondaryCircuitPumpOutput SensorType = "SCPO"
	// SensorPrimaryCircuitValveOutput is a discrete value between 0% - 100% where some
	// valves may have fixed steps but still are represented as a percentage.
	//
	// Unit: 0% - 100%, Resolution: 0.1%
	SensorPrimaryCircuitValveOutput SensorType = "PCVO"
	// SensorSecondaryCircuitValveOutput is a discrete value between 0% - 100% where some
	// valves may have fixed steps but still are represented as a percentage.
	//
	// Unit: 0% - 100%, Resolution: 0.1%
	SensorSecondaryCircuitValveOutput SensorType = "SCVO"
	// SensorHotWaterCircuitValveOutput is a discrete value between 0% - 100% where some
	// valves may have fixed steps but still are represented as a percentage.
	//
	// Unit: 0% - 100%, Resolution: 0.1%
	SensorHotWaterCircuitValveOutput SensorType = "HWVO"
	// SensorValveOutput is the generic valve output where it needs a circuit
	// identifier to be specified to know which circuit it is.
	//
	// Unit: 0% - 100%, Resolution: 0.1%
	SensorValveOutput SensorType = "VO"
)
