package eqdefs

import (
	"math"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// hotWaterSensorDefinitions holds the definitions of the hot water circuit
// sensor data points, keyed by TEOS identifier.
var hotWaterSensorDefinitions = map[string]DataPointDefinition{
	// SPHWCT
	string(eqmodel.SensorSupplyHotWaterPrimaryCircuitTemperature): {
		ID:          "TEOS/Primary Hot Water Circuit/Supply Temperature",
		TeosID:      string(eqmodel.SensorSupplyHotWaterPrimaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The temperature of the hot water circuit on primary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// RPHWCT
	string(eqmodel.SensorReturnHotWaterPrimaryCircuitTemperature): {
		ID:          "TEOS/Primary Hot Water Circuit/Return Temperature",
		TeosID:      string(eqmodel.SensorReturnHotWaterPrimaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The return temperature of the hot water circuit on primary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// SSHWCT
	string(eqmodel.SensorSupplyHotWaterSecondaryCircuitTemperature): {
		ID:          "TEOS/Secondary Hot Water Circuit/Supply Temperature",
		TeosID:      string(eqmodel.SensorSupplyHotWaterSecondaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The temperature of the hot water circuit on secondary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// RSHWCT
	string(eqmodel.SensorReturnHotWaterSecondaryCircuitTemperature): {
		ID:          "TEOS/Secondary Hot Water Circuit/Return Temperature",
		TeosID:      string(eqmodel.SensorReturnHotWaterSecondaryCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The return temperature of the hot water circuit on secondary side",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// SHWCT
	string(eqmodel.SensorSupplyHotWaterCircuitTemperature): {
		ID:          "TEOS/Hot Water Circuit/Supply Temperature",
		TeosID:      string(eqmodel.SensorSupplyHotWaterCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The supply temperature of a hot water circuit",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
	// RHWCT
	string(eqmodel.SensorReturnHotWaterCircuitTemperature): {
		ID:          "TEOS/Hot Water Circuit/Return Temperature",
		TeosID:      string(eqmodel.SensorReturnHotWaterCircuitTemperature),
		Sensor:      true,
		Type:        DataPointDefinitionTypeNumber,
		Low:         0,
		High:        math.MaxFloat32,
		Description: "The return temperature of a hot water circuit",
		Readonly:    true,
		Unit: map[DataPointUnitSystem]DataPointUnit{
			DataPointUnitSystemSI: {
				Name:   "°C",
				Symbol: DataPointUnitSymbolCelsius,
			},
			DataPointUnitSystemImperial: {
				Name:   "°F",
				Symbol: DataPointUnitSymbolFahrenheit,
			},
		},
		Conversion: map[DataPointUnitSystem]DataPointConversion{
			DataPointUnitSystemImperial: {
				Gain:   1.8,
				Offset: 32,
			},
		},
	},
}
