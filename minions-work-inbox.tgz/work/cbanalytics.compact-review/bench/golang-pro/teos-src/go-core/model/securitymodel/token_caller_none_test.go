package securitymodel_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
)

func TestCallerType_NoSubjectNoClientID_IsNone(t *testing.T) {
	cases := map[string]securitymodel.OpenIDConnectToken{
		"empty token":         {},
		"claims without both": {Claims: map[string]any{"token_use": "access"}},
		"empty client_id":     {Claims: map[string]any{"client_id": ""}},
	}

	for name, token := range cases {
		t.Run(name, func(t *testing.T) {
			assert.Equal(t, securitymodel.CallerTypeNone, token.CallerType())
			assert.Equal(t, securitymodel.GrantTypeNone, token.GrantType())

			sc := map[string]any{}
			securitymodel.EnrichSecurityContext(sc, &token)

			assert.Equal(t, "none", sc["caller_type"])
			assert.Equal(t, "none", sc["grant_type"])
		})
	}
}

func TestGrantType_NoneWinsOverActor(t *testing.T) {
	token := securitymodel.OpenIDConnectToken{
		Actor: &securitymodel.Actor{Subject: "actor-1"},
	}

	assert.Equal(t, securitymodel.CallerTypeNone, token.CallerType())
	assert.Equal(t, securitymodel.GrantTypeNone, token.GrantType())
}

func TestEnrichSecurityContext_ListsArePresentAndEmpty(t *testing.T) {
	cases := map[string]securitymodel.OpenIDConnectToken{
		"empty token": {},
		"user token": {
			Subject: "user-1",
			Claims:  map[string]any{"client_id": "spa"},
		},
		"app token": {
			Claims: map[string]any{"client_id": "m2m"},
		},
		"blank scope and empty oid": {
			Subject: "user-1",
			Scope:   "  ",
			OID:     []string{},
			Claims:  map[string]any{"client_id": "spa", "cognito:groups": []any{}},
		},
	}

	for name, token := range cases {
		t.Run(name, func(t *testing.T) {
			sc := map[string]any{}
			securitymodel.EnrichSecurityContext(sc, &token)

			for _, key := range []string{"scopes", "groups", "oid"} {
				v, ok := sc[key]
				require.True(t, ok, "%s must be present", key)

				list, ok := v.([]string)
				require.True(t, ok, "%s must be a []string, got %T", key, v)
				assert.NotNil(t, list, "%s must not be nil", key)
				assert.Empty(t, list, "%s must be empty", key)
			}
		})
	}
}
