package coremodel

// All is the claim value that covers every value of its claim: every organization in an oid
// claim, every remote system in an rsid claim, every provider in a pn claim and every service in
// a service claim. It is reserved, so no organization is named all.
const All = "all"
