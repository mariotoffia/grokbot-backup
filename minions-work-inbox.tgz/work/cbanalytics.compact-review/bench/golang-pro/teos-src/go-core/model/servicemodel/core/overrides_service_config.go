package core

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"

	"github.com/Thiink-LLC/teos/go-core/utils/convutils"
	"github.com/Thiink-LLC/teos/go-core/utils/dbutils"
	"github.com/Thiink-LLC/teos/go-core/utils/jsonutils"
)

// GetCast will try to get the value and cast it to _T_.
func GetCast[T any](sc *ServiceConfig, name string) (value T, found bool) {
	if sc == nil {
		return
	}

	if sc.AdditionalProperties != nil {
		if v, f := sc.AdditionalProperties[name]; !f {
			return
		} else if v != nil {
			value, found = v.(T)
		}
	}

	return
}

func GetSlice[Elem any](sc *ServiceConfig, name string) ([]Elem, error) {
	if sc == nil {
		return nil, nil
	}

	if sc.AdditionalProperties != nil {
		if v, f := sc.AdditionalProperties[name]; !f {
			return nil, nil
		} else if v != nil {
			return convutils.CastAnyToSlice[Elem](v)
		}
	}

	return nil, nil
}

// GetUpdated will safely return the updated timestamp of the service config.
func (sc *ServiceConfig) GetUpdated() time.Time {
	if sc == nil || sc.TS == nil {
		return time.Time{}
	}

	return *sc.TS
}

// IsWithinUpdateWindow checks if the service config is within the update window.
func (sc *ServiceConfig) IsWithinUpdateWindow(dur time.Duration) bool {
	if sc == nil || sc.TS == nil {
		return false
	}

	return time.Now().UTC().Sub(*sc.TS) < dur
}

// GetCastFloat64 will return the value of the key as a float64 if it exists.
//
// If not in float64 format, it will try to convert it to float64.
func (sc *ServiceConfig) GetCastFloat64(key string) (float64, bool) {
	if sc == nil {
		return 0, false
	}

	if v, ok := sc.AdditionalProperties[key]; ok {
		return convutils.AnyToFloat64NoError(v)
	}

	return 0, false
}

// MarshalMapNoError will marshal the service config to a map[string]any without error.
//
// If an error occurs, it will return `nil`.
func (sc *ServiceConfig) MarshalMapNoError() map[string]any {
	if sc == nil {
		return nil
	}

	if data, err := json.Marshal(sc); err != nil {
		return nil
	} else {
		var m map[string]any

		if err := json.Unmarshal(data, &m); err != nil {
			return nil
		}

		return m
	}
}

func ServiceConfigFromMap(m map[string]any) (*ServiceConfig, error) {
	var service *ServiceConfig

	if len(m) == 0 {
		return nil, nil
	}

	if err := json.Unmarshal(jsonutils.ToJSON(m), &service); err != nil {
		return nil, err
	}

	return service, nil
}

// FromProfileToServiceConfig converts a global params from a profile into a service config (if found).
// If not found, it returns `nil`.
func FromProfileToServiceConfig(prms map[string]any) (*ServiceConfig, error) {
	if _, ok := prms["SVC"]; !ok {
		return nil, nil
	}

	svc, ok := prms["SVC"].(map[string]any)

	if !ok {
		return nil, nil
	}

	return ServiceConfigFromMap(svc)
}

// MarshalDynamoDBAttributeValue will marshal the `ServiceConfig` using the standard marshal into a
// map. This is due to that it has most of the config in the `AdditionalProperties` map.
func (t *ServiceConfig) MarshalDynamoDBAttributeValue() (types.AttributeValue, error) {
	return dbutils.MarshalDynamoDBAttributeValue(t)
}

// UnmarshalDynamoDBAttributeValue will unmarshal the _DynamoDB_ `types.AttributeValue` into a `ServiceConfig` via
// a map[string]any to handle the _AdditionalProperties_.
//
// We _REQUIRE_ the `types.AttributeValue` to be a `map[string]any` and thus the `AttributeValueMemberM` is set.
func (t *ServiceConfig) UnmarshalDynamoDBAttributeValue(v types.AttributeValue) error {
	if m, ok := v.(*types.AttributeValueMemberM); ok {
		var mp map[string]any

		if err := attributevalue.UnmarshalMap(m.Value, &mp); err != nil {
			return err
		}

		if data, err := json.Marshal(mp); err != nil {
			return err
		} else {
			*t = ServiceConfig{}

			return json.Unmarshal(data, t)
		}
	}

	return fmt.Errorf("failed to unmarshal service")
}
