package eqmodel_test

import (
	"fmt"
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func toTime(s string) coremodel.CbTime32 {
	t, _ := time.Parse(time.RFC3339, s)
	return coremodel.CbTime32(t)
}

func toArr(arr ...eqmodel.CbDataPointImpl) []eqmodel.CbDataPoint {
	x := make([]eqmodel.CbDataPoint, len(arr))

	for i, v := range arr {
		x[i] = &v
	}

	return x
}

func TestAllWithinDurationWillProduceSingleItem(t *testing.T) {
	m := eqmodel.CbMultiDataPointMap{
		"ODT": toArr(
			eqmodel.CbDataPointImpl{ID: "ODT", TimeStamp: toTime("2021-01-01T00:00:00Z")},
		),
		"IDT_O1": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
		),
	}

	grouped, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
	require.NoError(t, err)

	require.Len(t, grouped, 1)
	assert.Len(t, grouped[0], 2)
	assert.Contains(t, grouped[0], "ODT")
	assert.Contains(t, grouped[0], "IDT_O1")
}

func TestNothingWillProduceNil(t *testing.T) {
	m := eqmodel.CbMultiDataPointMap{}

	grouped, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
	require.NoError(t, err)
	assert.Nil(t, grouped)
}

func TestAllWithinDurationButMultipleValuesWillProduceMultipleItems(t *testing.T) {
	m := eqmodel.CbMultiDataPointMap{
		"ODT": toArr(
			eqmodel.CbDataPointImpl{ID: "ODT", TimeStamp: toTime("2021-01-01T00:00:00Z")},
		),
		"IDT_O1": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
	}

	grouped, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
	require.NoError(t, err)

	require.Len(t, grouped, 2)
	assert.Len(t, grouped[0], 2)
	assert.Contains(t, grouped[0], "ODT")
	assert.Contains(t, grouped[0], "IDT_O1")
	assert.Equal(
		t,
		"2021-01-01T00:10:00Z",
		grouped[0]["IDT_O1"].GetTimeStamp().UTC().Format(time.RFC3339),
	)

	assert.Len(t, grouped[1], 1)
	assert.Contains(t, grouped[1], "IDT_O1")
	assert.Equal(
		t,
		"2021-01-01T00:14:00Z",
		grouped[1]["IDT_O1"].GetTimeStamp().UTC().Format(time.RFC3339),
	)
}

func TestNoTimeStampGivesError(t *testing.T) {
	m := eqmodel.CbMultiDataPointMap{
		"ODT": toArr(
			eqmodel.CbDataPointImpl{ID: "ODT"},
		),
		"IDT_O1": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
		),
	}

	grouped, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
	require.Error(t, err)
	fmt.Println(err.Error())
	assert.Equal(t, "CbDataPoint with key ODT has no timestamp", err.Error())
	assert.Nil(t, grouped)
}

func TestDuplicatesAreInDifferentFrames(t *testing.T) {
	m := eqmodel.CbMultiDataPointMap{
		"ODT": toArr(
			eqmodel.CbDataPointImpl{ID: "ODT", TimeStamp: toTime("2021-01-01T00:00:00Z")},
		),
		"IDT_O1": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
		),
	}

	grouped, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
	require.NoError(t, err)

	require.Len(t, grouped, 2)
	assert.Len(t, grouped[0], 2)
	assert.Contains(t, grouped[0], "ODT")
	assert.Contains(t, grouped[0], "IDT_O1")

	assert.Len(t, grouped[1], 1)
	assert.Contains(t, grouped[1], "IDT_O1")
}

func TestManyItemsInTwoFramesShallSucceed(t *testing.T) {
	m := eqmodel.CbMultiDataPointMap{
		"ODT": toArr(
			eqmodel.CbDataPointImpl{ID: "ODT", TimeStamp: toTime("2021-01-01T00:00:00Z")},
		),
		"IDT_O1": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O2": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O2", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O2", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O3": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O3", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O3", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O4": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O4", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O4", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O5": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O5", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O5", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O6": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O6", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O6", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O7": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O7", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O7", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O8": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O8", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O8", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O9": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O9", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O9", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
	}

	grouped, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
	require.NoError(t, err)

	require.Len(t, grouped, 2)
	assert.Len(t, grouped[0], 10)
	assert.Contains(t, grouped[0], "ODT")
	assert.Contains(t, grouped[0], "IDT_O1")
	assert.Contains(t, grouped[0], "IDT_O2")
	assert.Contains(t, grouped[0], "IDT_O3")
	assert.Contains(t, grouped[0], "IDT_O4")
	assert.Contains(t, grouped[0], "IDT_O5")
	assert.Contains(t, grouped[0], "IDT_O6")
	assert.Contains(t, grouped[0], "IDT_O7")
	assert.Contains(t, grouped[0], "IDT_O8")

	assert.Len(t, grouped[1], 9)
	assert.NotContains(t, grouped[1], "ODT")
	assert.Contains(t, grouped[1], "IDT_O1")
	assert.Contains(t, grouped[1], "IDT_O2")
	assert.Contains(t, grouped[1], "IDT_O3")
	assert.Contains(t, grouped[1], "IDT_O4")
	assert.Contains(t, grouped[1], "IDT_O5")
	assert.Contains(t, grouped[1], "IDT_O6")
	assert.Contains(t, grouped[1], "IDT_O7")
	assert.Contains(t, grouped[1], "IDT_O9")
}

func BenchmarkMultipleFramesAndManyItems(t *testing.B) {
	m := eqmodel.CbMultiDataPointMap{
		"ODT": toArr(
			eqmodel.CbDataPointImpl{ID: "ODT", TimeStamp: toTime("2021-01-01T00:00:00Z")},
		),
		"IDT_O1": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O1", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O2": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O2", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O2", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O3": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O3", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O3", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O4": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O4", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O4", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O5": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O5", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O5", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O6": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O6", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O6", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O7": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O7", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O7", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O8": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O8", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O8", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
		"IDT_O9": toArr(
			eqmodel.CbDataPointImpl{ID: "IDT_O9", TimeStamp: toTime("2021-01-01T00:14:00Z")},
			eqmodel.CbDataPointImpl{ID: "IDT_O9", TimeStamp: toTime("2021-01-01T00:10:00Z")},
		),
	}

	t.ResetTimer()

	for i := 0; i < t.N; i++ {
		_, err := m.GroupDataPoints(15 * time.Minute /*durRange*/)
		require.NoError(t, err)
	}
}
