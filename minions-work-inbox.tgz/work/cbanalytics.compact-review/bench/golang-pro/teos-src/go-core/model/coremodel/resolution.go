package coremodel

import (
	"fmt"
	"regexp"
	"strconv"
	"time"
)

// ResolutionType specifies what the resolution is.
type ResolutionType string

const (
	// ResolutionUnknown is the unknown/illegal resolution.
	ResolutionUnknown ResolutionType = ""
	// ResolutionMilliseconds is the resolution in milliseconds.
	ResolutionMilliseconds ResolutionType = "ms"
	// ResolutionSeconds is the resolution in seconds.
	ResolutionSeconds ResolutionType = "s"
	// ResolutionMinutes is the resolution in minutes.
	ResolutionMinutes ResolutionType = "min"
	// ResolutionHours is the resolution in hours.
	ResolutionHours ResolutionType = "h"
	// ResolutionDays is the resolution in days.
	ResolutionDays ResolutionType = "d"
	// ResolutionMonths is the resolution in months.
	ResolutionMonths ResolutionType = "m"
)

// Resolution is a type that have utility functions attached to it.
//
// .Example Usage
// [source,go]
// ----
// dur := Resolution("15min").ToDuration()
// ----
type Resolution string

// ResolutionPattern is the regular expression used to parse the resolution.
var ResolutionPattern = regexp.MustCompile(
	`^(?:(\d{1,3})ms|(\d{1,20})s|(\d{1,5})min|(\d{1,2})h|(\d{1,2})d|(\d{1,2})m)$`,
)

// ToResolution translates a resolution type and number to a resolution.
// If the resolution type is unknown or _num <= 0_, an empty string is returned.
//
// .Example Usage
// [source,go]
// ----
// res := ToResolution(ResolutionMinutes, 15) // <1>
// ----
// <1> Will return `15min`
func ToResolution(resType ResolutionType, num int) Resolution {
	if resType == ResolutionUnknown || num <= 0 {
		return ""
	}

	return Resolution(fmt.Sprintf("%d%s", num, resType))
}

// ToResolutionAndDuration will parse the _res_ and return the resolution type
// and duration.
//
// If it fails, `ResolutionUnknown` and `0` is returned.
func (res Resolution) ToResolutionAndDuration() (ResolutionType, int) {
	if res == "" {
		return ResolutionUnknown, 0
	}

	matches := ResolutionPattern.FindStringSubmatch(string(res))

	if matches == nil {
		return ResolutionUnknown, 0
	}

	var duration int

	// Parse milliseconds
	if ms := matches[1]; ms != "" {
		value, _ := strconv.Atoi(ms)
		duration = value
		return ResolutionMilliseconds, duration
	}

	// Parse seconds
	if s := matches[2]; s != "" {
		value, _ := strconv.Atoi(s)
		duration = value
		return ResolutionSeconds, duration
	}

	// Parse minutes
	if min := matches[3]; min != "" {
		value, _ := strconv.Atoi(min)
		duration = value
		return ResolutionMinutes, duration
	}

	// Parse hours
	if h := matches[4]; h != "" {
		value, _ := strconv.Atoi(h)
		duration = value
		return ResolutionHours, duration
	}

	// Parse days
	if d := matches[5]; d != "" {
		value, _ := strconv.Atoi(d)
		duration = value
		return ResolutionDays, duration
	}

	// Parse months (assuming 30 days per month)
	if m := matches[6]; m != "" {
		value, _ := strconv.Atoi(m)
		duration = value
		return ResolutionMonths, duration
	}

	return ResolutionUnknown, 0
}

// ToDuration will parse the `ProviderSettings.Resolution` and return the
// duration.
//
// If it fails to parse the resolution, `false` is returned.
func (res Resolution) ToDuration() (time.Duration, bool) {
	resolution, duration := res.ToResolutionAndDuration()

	switch resolution {
	case ResolutionMilliseconds:
		return time.Duration(duration) * time.Millisecond, true
	case ResolutionSeconds:
		return time.Duration(duration) * time.Second, true
	case ResolutionMinutes:
		return time.Duration(duration) * time.Minute, true
	case ResolutionHours:
		return time.Duration(duration) * time.Hour, true
	case ResolutionDays:
		return time.Duration(duration) * 24 * time.Hour, true
	case ResolutionMonths:
		return time.Duration(duration) * 30 * 24 * time.Hour, true
	default:
		return 0, false
	}
}

// Slots will create a range slots from the resolution. Depending on the resolution value
// and type, the returned range will be different.
//
// For example a resolution of 5min will return a array of 12 integers, 0-11, and
// a resolution of 1h will return a single integer, 0 (2h will return two integers 0,1).
//
// If unknown resolution, an empty array is returned.
func (res Resolution) Slots() []int {
	from, to := res.Range()

	if from == -1 || to == -1 {
		return []int{}
	}

	if from == to {
		return []int{from}
	}

	slots := make([]int, to-from+1)

	for i := range slots {
		slots[i] = from + i
	}

	return slots
}

// Range will return the range of the resolution.
//
// For example a resolution of 5min will return 0, 11, and
// a resolution of 1h will return 0 and 2h 0, 1.
//
// If the resolution is unknown, -1, -1 is returned.
func (res Resolution) Range() (int, int) {
	resolution, duration := res.ToResolutionAndDuration()

	switch resolution {
	case ResolutionMilliseconds:
		return 0, duration - 1
	case ResolutionSeconds:
		return 0, duration - 1
	case ResolutionMinutes:
		return 0, duration - 1
	case ResolutionHours:
		return 0, duration - 1
	case ResolutionDays:
		return 0, duration - 1
	case ResolutionMonths:
		return 0, duration - 1
	default:
		return -1, -1
	}
}
