package rtc

import (
	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/provider/providerutils"
	"github.com/Thiink-LLC/teos/go-core/utils"
)

// ToPipeSource converts the actuation item to a pipe source that may be returned directly from
// a `providerpipe.SourceFunction`. No errors will be returned from this function.
//
// It will copy all elements in the `Dp` map to the source map and set the _FRT_
// and _BID_ (from `Lid`) globals. If _PID_ and _TID_ is set, those will also be set as globals.
//
// The _FRT_ is set by the `RtChannelMessageType` (`SIMPLE_ACTUATION_FRAME`).
func (o *SimpleCollectionFrame) ToPipeSource(
	ctx ifcore.CbContext,
) (map[string]any, cberror.Error) {
	dp, source, globals := providerutils.StandardPipeSource(true)

	for k, v := range o.Dp {
		source[k] = v.ToDataPoint(ctx, k, "")
	}

	source[string(eqmodel.DataPointReceivedEventTime)] = ToRFC3339Time(o.T)

	globals[string(ifprovider.ParameterFrameType)] = string(SIMPLE_ACTUATION_FRAME)
	globals[string(ifprovider.ParameterLocationID)] = o.Lid
	globals[string(ifprovider.ParameterTimeZone)] = o.Tz

	utils.MapSetStringValueIf(string(ifprovider.ParameterPlantID), o.Pid, globals)
	utils.MapSetStringValueIf(string(ifprovider.ParameterTenantID), o.Tid, globals)
	return dp, nil

}
