package logmodel

import (
	"time"
)

type LogStreamOrderBy string

// Enum values for OrderBy
const (
	OrderByLogStreamName LogStreamOrderBy = "LogStreamName"
	OrderByLastEventTime LogStreamOrderBy = "LastEventTime"
)

type LogStream struct {
	// The _ID_ or _URI_ to log stream.
	//
	// For example, in _AWS_ this is the _ARN_.
	ID string
	// The creation time of the stream
	CreationTime time.Time
	// The time of the first event
	FirstEventTimestamp time.Time
	// The time of the most recent log event in the log stream in this log-stream. The
	// lastEventTime value updates on an eventual consistency basis. It
	// typically updates in less than an hour from ingestion, but in rare situations
	// might take longer.
	LastEventTimestamp time.Time
	// The ingestion time. This may be later than the `LastEventTimestamp` if the
	// log event was ingested later than the time of the last event.
	LastIngestionTime time.Time
	// Name is the name of the log stream.
	Name string
	// Token is a holder of a _ID_. Some log services supports a notion of e.g. sequence
	// token that needs to be present when logging data.
	Token string
}
