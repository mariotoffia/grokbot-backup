package pubsubmodel

import (
	"github.com/Thiink-LLC/teos/go-core/model/securitymodel"
)

// tag::subscriber[]

// SubscriberImpl encapsulates a single subscriber.
//
// On a single subscriber, *multiple* `SubscriptionImpl` may be applied. Hence a single
// subscriber may have multiple subscriptions (even different targets such as REST
// and WebSocket etc.).
//
// NOTE: The _SubscriberID_ is the `OpenIDConnectToken.Subject` property!
type SubscriberImpl struct {
	securitymodel.OpenIDConnectToken
}

// end::subscriber[]

// SubscriberAndSubscriptionsImpl is a container for a single subscriber with
// one or more subscriptions.
type SubscriberAndSubscriptionsImpl struct {
	Subscriber    SubscriberImpl      `json:"subscriber"`
	Subscriptions []*SubscriptionImpl `json:"subscriptions"`
}
