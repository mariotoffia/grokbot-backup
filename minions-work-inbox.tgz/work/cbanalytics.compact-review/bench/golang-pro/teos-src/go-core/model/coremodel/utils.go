package coremodel

import "strings"

// ToTagMap converts a set of _tags_ to a map.
func ToTagMap(tags []Tag) map[string]string {
	if len(tags) == 0 {
		return nil
	}

	m := make(map[string]string, len(tags))

	for _, t := range tags {
		m[t.Name] = t.Value
	}

	return m
}

// ToTags will convert _tags_ on <name>[:<value>] format. If other
// separator is wanted, specify it in the _sep_ parameter
func ToTags(tags []string, sep ...string) []Tag {
	if len(tags) == 0 {
		return nil
	}

	separator := ":"

	if len(sep) > 0 {
		separator = sep[0]
	}

	list := make([]Tag, 0, len(tags))

	for _, t := range tags {
		s := strings.SplitN(t, separator, 2)

		if len(s) == 1 {
			list = append(list, Tag{
				Name:      s[0],
				Value:     "",
				Separator: separator,
			})
		} else {
			list = append(list, Tag{
				Name:      s[0],
				Value:     s[1],
				Separator: separator,
			})
		}

	}

	return list
}

// ToTagResourceOperation will diff _old_ and _new_ maps and return the patch operations
// needed to make them equal. The _tagResource_ map will contain the operations to add or
// replace tags, while the _untagResource_ slice will contain the operations to remove tags.
func ToTagResourceOperation(
	old, new map[string]string,
) (tagResource map[string]string, untagResource []string) {
	tagResource = make(map[string]string)
	untagResource = make([]string, 0)

	for k, v := range new {
		if old[k] != v {
			tagResource[k] = v
		}
	}

	for k := range old {
		if _, ok := new[k]; !ok {
			untagResource = append(untagResource, k)
		}
	}

	return tagResource, untagResource
}
