package cfgmodel

import "github.com/Thiink-LLC/teos/go-core/model/eqmodel"

// FirstParam will return the first available equipment in the merged sensors
// and try to extract the parameter. If not found an _d_ is returned.
func (me *MergedEquipment) FirstParam(name string, d any) any {
	if me == nil {
		return d
	}

	if eq := me.First(); eq != nil {
		if v, ok := eq.Params[name]; ok {
			return v
		}
	}

	return d
}

// First will return the first available sensor in the merged sensors.
//
// If none, `nil` is returned.
func (me *MergedEquipment) First() *eqmodel.InstalledEquipment {
	if me == nil {
		return nil
	}

	if len(me.Added) > 0 {
		return &me.Added[0]
	}

	if len(me.Updated) > 0 {
		return &me.Updated[0]
	}

	if len(me.Deleted) > 0 {
		return &me.Deleted[0]
	}

	if len(me.Notchanged) > 0 {
		return &me.Notchanged[0]
	}

	return nil
}

// AllEquipmentIDs returns all equipment IDs in the event (added, updated, notchanged and deleted)
func (me *MergedEquipment) AllEquipmentIDs() []string {
	if me == nil {
		return nil
	}

	var eqIDs []string

	for _, eq := range me.Added {
		eqIDs = append(eqIDs, eq.EquipmentID)
	}

	for _, eq := range me.Updated {
		eqIDs = append(eqIDs, eq.EquipmentID)
	}

	for _, eq := range me.Deleted {
		eqIDs = append(eqIDs, eq.EquipmentID)
	}

	for _, eq := range me.Notchanged {
		eqIDs = append(eqIDs, eq.EquipmentID)
	}

	return eqIDs
}

// AllEquipments returns all equipments in the event (added, updated, notchanged and deleted)
//
// If no _eqID_ is given, it will return all equipments (same as c.Equipment).
func (me *MergedEquipment) Equipments(eqID ...string) *MergedEquipment {
	size := len(me.Added) + len(me.Updated) + len(me.Deleted)

	if size == 0 {
		return &MergedEquipment{}
	}

	if len(eqID) == 0 {
		return me
	}

	eqs := MergedEquipment{}

	for i, eq := range me.Updated {
		if eq.EquipmentID == eqID[0] {
			eqs.Updated = append(eqs.Updated, me.Updated[i])
		}
	}

	for i, eq := range me.Added {
		if eq.EquipmentID == eqID[0] {
			eqs.Added = append(eqs.Added, me.Added[i])
		}
	}

	for i, eq := range me.Deleted {
		if eq.EquipmentID == eqID[0] {
			eqs.Deleted = append(eqs.Deleted, me.Deleted[i])
		}
	}

	for i, eq := range me.Notchanged {
		if eq.EquipmentID == eqID[0] {
			eqs.Notchanged = append(eqs.Notchanged, me.Notchanged[i])
		}
	}

	return &eqs
}
