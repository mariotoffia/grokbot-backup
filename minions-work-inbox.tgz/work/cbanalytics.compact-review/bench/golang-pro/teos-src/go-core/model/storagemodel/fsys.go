package storagemodel

import "io/fs"

// FSysAndFolder is a container of a `fs.FS` and a folder
// to e.g. start iterating.
type FSysAndFolder struct {
	FSys   fs.FS
	Folder string
}
