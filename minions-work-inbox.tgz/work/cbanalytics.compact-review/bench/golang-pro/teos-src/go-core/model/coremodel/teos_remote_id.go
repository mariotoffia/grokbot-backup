package coremodel

// TeosAndRemoteID is a struct that contains a Thiink Energy OS ID and
// the remote partition and/or remote id of the resource.
type TeosAndRemoteID struct {
	// TeosID is the Teos ID of the resource.
	TeosID string `json:"teos_id"`
	// RemoteID is the remote ID of the resource.
	RemoteID string `json:"remote_id,omitempty"`
	// RemotePartition is the remote partition of the resource.
	RemotePartition string `json:"remote_partition,omitempty"`
}
