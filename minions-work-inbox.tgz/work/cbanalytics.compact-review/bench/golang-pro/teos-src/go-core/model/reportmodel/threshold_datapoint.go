package reportmodel

// DataPointReportReason is the reason why  a `SensorReport` was emitted.
type DataPointReportReason string

const (
	// DataPointReportReasonTime is when a sensor did not update within a certain threshold.
	DataPointReportReasonTime DataPointReportReason = "time"
	// DataPointReportReasonValue is when a sensor did not change a value within a certain threshold.
	DataPointReportReasonValue DataPointReportReason = "value"
	// DataPointReportReasonNotNewer is set when a original device timestamp is stored in _TEOS_
	// and compared with device current. If it is not newer, then it will be dropped and this will
	// be the reason.
	DataPointReportReasonNotNewer DataPointReportReason = "not-newer"
)

// DataPointThresholdReport that it has not been updated within the `Limit` threshold
// and remote sensor should be investigated.
//
// This is reported in the log system or as part of an event (never an alarm!).
//
// It is always having the category or message of _SensorReport_ so it is easy
// to capture in the log.
//
// When logging this report. On root level the _lid_ (LocationId), if known,
// is *REQUIRED* to be included (if multiple, use a string array). The same
// goes for _pn_ (ProviderName).
//
// NOTE: When reported the ID of the sensor is the key and the value is the `SensorThresholdReport`
type DataPointThresholdReport struct {
	// TotalCount is the number of sensors that where used to check the threshold.
	TotalCount int `json:"tot"`
	// AllDropped is set to true if all sensors that where handled are present in Dropped
	//
	// TIP: Can be an indicator of connectivity or other severe issues.
	AllDropped bool `json:"ad"`
	// CountDropped is a counter of the number of sensors that are present in Dropped.
	//
	// TIP: This can be used if in e.g. JSON format to query the log
	CountDropped int `json:"cd"`
	// AllReported is set to true if all sensors that where handled are present in Reported
	//
	// TIP: Can be an indicator of connectivity or other severe issues.
	AllReported bool `json:"ar"`
	// CountReported is a counter of the number of sensors that are present in Reported.
	CountReported int `json:"cr"`
	// Dropped is the list of sensors that have not been updated within the `Limit` threshold.
	Dropped map[string]*DataPointThresholdItem `json:"dropped"`
	// Reported is the list of sensors that have been updated within the `Limit` threshold.
	Reported map[string]*DataPointThresholdItem `json:"reported"`
}

// DataPointAction specifies what action was taken on a datapoint.
type DataPointAction string

const (
	// DataPointActionReport is when a datapoint was reported only.
	DataPointActionReport DataPointAction = "report"
	// DataPointActionDrop is when a datapoint was dropped.
	DataPointActionDrop DataPointAction = "drop"
)

// DataPointThresholdItem is a single item in a `DataPointThresholdReport`
type DataPointThresholdItem struct {
	// Timestamp is the unix 32 timestamp it was last updated.
	Timestamp int64 `json:"ts"`
	// DateTime is the display friendly version of the timestamp.
	DateTime string `json:"dt,omitempty"`
	// Diff is the difference in unix 32 epoch time in seconds.
	//
	// This is calculated `now - remote.Timestamp` and hence is the time the remote
	// was last updated.
	Diff int64 `json:"diff"`
	// Limit is the threshold set in seconds when this report should be emitted.
	Limit int64 `json:"limit"`
	// Reason is the reason why this report was emitted.
	Reason DataPointReportReason `json:"reason,omitempty"`
	// Action describe the action taken when this was discovered.
	Action DataPointAction `json:"action,omitempty"`
}
