package securitymodel

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// --- Token fixtures ---

// userTokenJSON simulates a Cognito authorization_code access token.
//
//nolint:gosec // G101 false positive - test fixture, not real credentials.
const userTokenJSON = `{
	"sub": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
	"iss": "https://cognito-idp.eu-west-1.amazonaws.com/eu-west-1_ABC123",
	"client_id": "teos-dashboard-spa",
	"token_use": "access",
	"scope": "openid email teos/building-read teos/sda-read",
	"cognito:groups": ["teos-admin", "teos-operator"],
	"exp": 1700000000,
	"iat": 1699999000
}`

// appTokenJSON simulates a Cognito client_credentials access token (no sub, no groups).
//
//nolint:gosec // G101 false positive - test fixture, not real credentials.
const appTokenJSON = `{
	"iss": "https://cognito-idp.eu-west-1.amazonaws.com/eu-west-1_ABC123",
	"client_id": "tklocal-m2m-client",
	"token_use": "access",
	"scope": "teos/c-oid:thiink teos/c-pn:tklocal teos/building-read",
	"exp": 1700000000,
	"iat": 1699999000
}`

// exchangeTokenJSON simulates an RFC 8693 token exchange token (delegation).
// It has both a subject and a structured act claim identifying the actor.
//
//nolint:gosec // G101 false positive - test fixture, not real credentials.
const exchangeTokenJSON = `{
	"sub": "subject-user-001",
	"iss": "https://cognito-idp.eu-west-1.amazonaws.com/eu-west-1_ABC123",
	"client_id": "exchange-client",
	"token_use": "access",
	"scope": "openid teos/building-read",
	"act": {"iss": "https://idp.example.com", "sub": "actor-admin-42", "client_id": "spa-app"},
	"exp": 1700000000,
	"iat": 1699999000
}`

func unmarshalToken(t *testing.T, raw string) OpenIDConnectToken {
	t.Helper()
	var token OpenIDConnectToken
	err := json.Unmarshal([]byte(raw), &token)
	require.NoError(t, err)
	return token
}

// --- CallerType tests ---

func TestCallerType_UserToken(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.Equal(t, CallerTypeUser, token.CallerType())
	assert.True(t, token.IsUserToken())
	assert.False(t, token.IsAppToken())
}

func TestCallerType_AppToken(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	assert.Equal(t, CallerTypeApp, token.CallerType())
	assert.True(t, token.IsAppToken())
	assert.False(t, token.IsUserToken())
}

// Cognito's client_credentials access tokens set sub to the app client ID
// (RFC 9068 section 2.2), so a subject equal to client_id is a machine client.
func TestCallerType_CognitoClientCredentialsToken(t *testing.T) {
	token := OpenIDConnectToken{
		Subject: "4l2bjm3q8rrch0r1ou3uhfrqsa",
		Claims:  map[string]any{"client_id": "4l2bjm3q8rrch0r1ou3uhfrqsa", "token_use": "access"},
	}

	assert.Equal(t, CallerTypeApp, token.CallerType())
	assert.True(t, token.IsAppToken())
	assert.False(t, token.IsUserToken())
	assert.Equal(t, GrantTypeClientCredentials, token.GrantType())

	sc := map[string]any{}
	EnrichSecurityContext(sc, &token)
	assert.Equal(t, "app", sc["caller_type"])
}

// --- CognitoGroups tests ---

func TestCognitoGroups_UserToken(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	groups := token.CognitoGroups()
	require.NotNil(t, groups)
	assert.Equal(t, []string{"teos-admin", "teos-operator"}, groups)
}

func TestCognitoGroups_AppToken_ReturnsNil(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	assert.Nil(t, token.CognitoGroups())
}

func TestCognitoGroups_NoClaims_ReturnsNil(t *testing.T) {
	token := OpenIDConnectToken{}
	assert.Nil(t, token.CognitoGroups())
}

func TestCognitoGroups_EmptyGroupsList(t *testing.T) {
	token := OpenIDConnectToken{
		Claims: map[string]any{"cognito:groups": []any{}},
	}
	assert.Nil(t, token.CognitoGroups())
}

func TestCognitoGroups_StringSliceType(t *testing.T) {
	token := OpenIDConnectToken{
		Claims: map[string]any{"cognito:groups": []string{"admin", "viewer"}},
	}
	assert.Equal(t, []string{"admin", "viewer"}, token.CognitoGroups())
}

// API Gateway on AWS passes cognito:groups as one string, and a decoded JWT or
// the local emulator holds it as a list. CognitoGroups reads both.
func TestCognitoGroups_StringAndList(t *testing.T) {
	want := []string{"teos-admin", "tklocal-admin"}

	tests := []struct {
		name  string
		claim any
		want  []string
	}{
		{name: "comma-separated string", claim: "teos-admin,tklocal-admin", want: want},
		{name: "space-separated string", claim: "teos-admin tklocal-admin", want: want},
		{name: "spaces around commas", claim: " teos-admin , tklocal-admin ", want: want},
		{name: "one group", claim: "tklocal-admin", want: []string{"tklocal-admin"}},
		{name: "empty string", claim: "", want: nil},
		{name: "list", claim: []any{"teos-admin", "tklocal-admin"}, want: want},
		{name: "list items trimmed, empty and non-string items dropped", claim: []any{" teos-admin ", "", 7, "tklocal-admin"}, want: want},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			token := OpenIDConnectToken{Claims: map[string]any{"cognito:groups": tt.claim}}
			assert.Equal(t, tt.want, token.CognitoGroups())
		})
	}
}

// API Gateway on AWS may pass a list claim as one string in brackets, such as
// "[a b]". ClaimList drops the brackets around the whole value.
func TestClaimList_Brackets(t *testing.T) {
	tests := []struct {
		name  string
		claim any
		want  []string
	}{
		{name: "space-separated in brackets", claim: "[a b]", want: []string{"a", "b"}},
		{name: "comma-separated in brackets", claim: "[a,b]", want: []string{"a", "b"}},
		{name: "one item in brackets", claim: "[a]", want: []string{"a"}},
		{name: "brackets with spaces inside", claim: "[ a , b ]", want: []string{"a", "b"}},
		{name: "empty brackets", claim: "[]", want: nil},
		{name: "all in brackets", claim: "[all]", want: []string{"all"}},
		{name: "dotted organization ID in brackets", claim: "[thiink.us]", want: []string{"thiink.us"}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.Equal(t, tt.want, ClaimList(tt.claim))
		})
	}
}

// --- HasCognitoGroup tests ---

func TestHasCognitoGroup_Found(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.True(t, token.HasCognitoGroup("teos-admin"))
	assert.True(t, token.HasCognitoGroup("teos-operator"))
}

func TestHasCognitoGroup_NotFound(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.False(t, token.HasCognitoGroup("teos-super-admin"))
}

func TestHasCognitoGroup_AppToken(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	assert.False(t, token.HasCognitoGroup("teos-admin"))
}

// --- ClientID tests ---

func TestClientID_UserToken(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.Equal(t, "teos-dashboard-spa", token.ClientID())
}

func TestClientID_AppToken(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	assert.Equal(t, "tklocal-m2m-client", token.ClientID())
}

func TestClientID_NoClaims(t *testing.T) {
	token := OpenIDConnectToken{}
	assert.Equal(t, "", token.ClientID())
}

// --- TokenUse tests ---

func TestTokenUse_AccessToken(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.Equal(t, "access", token.TokenUse())
}

func TestTokenUse_NoClaims(t *testing.T) {
	token := OpenIDConnectToken{}
	assert.Equal(t, "", token.TokenUse())
}

// --- EnrichSecurityContext tests ---

func TestEnrichSecurityContext_UserToken(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	sc := map[string]any{"oidc": token}

	EnrichSecurityContext(sc, &token)

	assert.Equal(t, "user", sc["caller_type"])
	assert.Equal(t, "a1b2c3d4-e5f6-7890-abcd-ef1234567890", sc["sub"])
	assert.Equal(t, "teos-dashboard-spa", sc["client_id"])
	assert.Equal(t, []string{"teos-admin", "teos-operator"}, sc["groups"])
	assert.Equal(t, []string{"openid", "email", "teos/building-read", "teos/sda-read"}, sc["scopes"])
}

func TestEnrichSecurityContext_AppToken(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	sc := map[string]any{"oidc": token}

	EnrichSecurityContext(sc, &token)

	assert.Equal(t, "app", sc["caller_type"])
	assert.Equal(t, "", sc["sub"])
	assert.Equal(t, "tklocal-m2m-client", sc["client_id"])
	// App tokens have no cognito:groups - "groups" is an empty list.
	assert.Equal(t, []string{}, sc["groups"])
	// Scopes should be present (m2m tokens have scopes, minus the teos/c- claims).
	scopes, ok := sc["scopes"].([]string)
	assert.True(t, ok)
	assert.NotEmpty(t, scopes)
}

func TestEnrichSecurityContext_NilInputs(t *testing.T) {
	// Should not panic.
	EnrichSecurityContext(nil, &OpenIDConnectToken{})
	EnrichSecurityContext(map[string]any{}, nil)
}

func TestEnrichSecurityContext_PreservesExistingEntries(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	sc := map[string]any{
		"oidc":   token,
		"custom": "value",
	}

	EnrichSecurityContext(sc, &token)

	assert.Equal(t, "value", sc["custom"])
	assert.Equal(t, "user", sc["caller_type"])
}

// --- GrantType tests ---

func TestGrantType_UserToken(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.Equal(t, GrantTypeAuthorizationCode, token.GrantType())
}

func TestGrantType_AppToken(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	assert.Equal(t, GrantTypeClientCredentials, token.GrantType())
}

func TestGrantType_ExchangeToken(t *testing.T) {
	token := unmarshalToken(t, exchangeTokenJSON)
	assert.Equal(t, GrantTypeTokenExchange, token.GrantType())
}

// --- IsExchangeToken tests ---

func TestIsExchangeToken_WithAct_ReturnsTrue(t *testing.T) {
	token := unmarshalToken(t, exchangeTokenJSON)
	assert.True(t, token.IsExchangeToken())
	require.NotNil(t, token.Actor)
	assert.Equal(t, "actor-admin-42", token.Actor.Subject)
}

func TestIsExchangeToken_WithoutAct_ReturnsFalse(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	assert.False(t, token.IsExchangeToken())
}

func TestIsExchangeToken_AppToken_ReturnsFalse(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	assert.False(t, token.IsExchangeToken())
}

// --- EnrichSecurityContext with act data tests ---

func TestEnrichSecurityContext_ExchangeToken_IncludesActData(t *testing.T) {
	token := unmarshalToken(t, exchangeTokenJSON)
	sc := map[string]any{"oidc": token}

	EnrichSecurityContext(sc, &token)

	// Caller type and grant type
	assert.Equal(t, "user", sc["caller_type"])
	assert.Equal(t, GrantTypeTokenExchange, sc["grant_type"])

	// Exchange flag
	isExchange, ok := sc["is_exchange"].(bool)
	assert.True(t, ok)
	assert.True(t, isExchange)

	// Actor data
	act, ok := sc["act"].(map[string]any)
	require.True(t, ok, "act must be a map in security context")
	assert.Equal(t, "actor-admin-42", act["sub"])
	assert.Equal(t, "https://idp.example.com", act["iss"])
	assert.Equal(t, "spa-app", act["client_id"])
}

func TestEnrichSecurityContext_UserToken_NoActData(t *testing.T) {
	token := unmarshalToken(t, userTokenJSON)
	sc := map[string]any{"oidc": token}

	EnrichSecurityContext(sc, &token)

	assert.Equal(t, GrantTypeAuthorizationCode, sc["grant_type"])
	_, hasAct := sc["act"]
	assert.False(t, hasAct, "user tokens must not have act in security context")
	_, hasExchange := sc["is_exchange"]
	assert.False(t, hasExchange, "user tokens must not have is_exchange flag")
}

func TestEnrichSecurityContext_AppToken_NoActData(t *testing.T) {
	token := unmarshalToken(t, appTokenJSON)
	sc := map[string]any{"oidc": token}

	EnrichSecurityContext(sc, &token)

	assert.Equal(t, GrantTypeClientCredentials, sc["grant_type"])
	_, hasAct := sc["act"]
	assert.False(t, hasAct, "app tokens must not have act in security context")
}

// --- OID in EnrichSecurityContext tests ---

func TestEnrichSecurityContext_AppToken_IncludesOID(t *testing.T) {
	// appTokenJSON has teos/c-oid:thiink in scope
	token := unmarshalToken(t, appTokenJSON)
	sc := map[string]any{}

	EnrichSecurityContext(sc, &token)

	oid, ok := sc["oid"].([]string)
	require.True(t, ok, "oid must be present in security context for M2M token with scope-encoded OID")
	assert.Equal(t, []string{"thiink"}, oid)
}

func TestEnrichSecurityContext_DirectOID_IncludesOID(t *testing.T) {
	// Simulate a user token with direct OID claim
	token := OpenIDConnectToken{
		Subject: "user-1",
		OID:     []string{"acme", "globex"},
		Claims:  map[string]any{"client_id": "my-spa"},
	}
	sc := map[string]any{}

	EnrichSecurityContext(sc, &token)

	oid, ok := sc["oid"].([]string)
	require.True(t, ok)
	assert.Equal(t, []string{"acme", "globex"}, oid)
}

func TestEnrichSecurityContext_MultiOID_ThreeOrMore(t *testing.T) {
	// Verify 3+ OIDs are all propagated - no truncation or off-by-one.
	token := OpenIDConnectToken{
		Subject: "user-1",
		OID:     []string{"acme", "globex", "initech"},
		Claims:  map[string]any{"client_id": "my-spa"},
	}
	sc := map[string]any{}

	EnrichSecurityContext(sc, &token)

	oid, ok := sc["oid"].([]string)
	require.True(t, ok)
	assert.Equal(t, []string{"acme", "globex", "initech"}, oid)
}
