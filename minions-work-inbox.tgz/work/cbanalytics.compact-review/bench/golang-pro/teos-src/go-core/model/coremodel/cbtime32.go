package coremodel

import (
	"bytes"
	"fmt"
	"maps"
	"slices"
	"strconv"
	"strings"
	"time"
	"unicode"
)

// CbTime32 defines a _Unix Timestamp_ encoded as epoch seconds in JSON
//
// It is also able to create _time.Time_ with a specific timezone from
// this _UTC_ timestamp that have https://www.iana.org/time-zones[IANA compatible zone names].
// In order to create such _time.Time_ use the extension function @WithTimeZone.
type CbTime32 time.Time

// MarshalJSON is used to convert the _Unix Epoch Timestamp_ to _JSON_
func (t CbTime32) MarshalJSON() ([]byte, error) {
	return []byte(strconv.FormatInt(time.Time(t).Unix(), 10)), nil
}

// UnmarshalJSON is used to convert the _Unix Epoch Timestamp_ from _JSON_
func (t *CbTime32) UnmarshalJSON(s []byte) (err error) {
	if bytes.ContainsAny(s, "Z+-:") {
		// -number is not a time.Time
		if s[0] != '-' {
			var t2 time.Time

			if err := t2.UnmarshalJSON(s); err != nil {
				return err
			}

			*(*time.Time)(t) = t2

			return
		}
	}

	r := string(s)
	q, err := strconv.ParseInt(r, 10, 64)
	if err != nil {
		return err
	}

	*(*time.Time)(t) = time.Unix(q, 0)
	return nil
}

// NewZeroTime32 creates a new _CbTime32_ with the time set to _zero_
func NewZeroTime32() *CbTime32 {
	return &CbTime32{}
}

// NewTime32 creates a new time based on the _Unix Epoch Timestamp_.
func NewTime32(unix int64) *CbTime32 {
	t := &CbTime32{}
	*(*time.Time)(t) = time.Unix(unix, 0)
	return t
}

// NewTime32FromTime creates a new _CbTime32_ from a _time.Time_.
func NewTime32FromTime(t time.Time) *CbTime32 {
	return (*CbTime32)(&t)
}

// NewTime32ByInterface creates a new CbTime32 by probing the type
// of the value.
func NewTime32ByInterface(unix any) *CbTime32 {
	t := &CbTime32{}

	switch v := unix.(type) {
	case float64:
		*(*time.Time)(t) = time.Unix(int64(v), 0)
	case int64:
		*(*time.Time)(t) = time.Unix(v, 0)
	case string:
		if q, err := strconv.ParseInt(v, 10, 64); err == nil {
			*(*time.Time)(t) = time.Unix(q, 0)
		}
	}

	return t
}

func (c CbTime32) IsGreaterThan(other CbTime32) bool {
	return time.Time(c).After(time.Time(other))
}

func (t CbTime32) Equal(other CbTime32) bool {
	return time.Time(t).Equal(time.Time(other))
}

func (t CbTime32) Before(other CbTime32) bool {
	return time.Time(t).Before(time.Time(other))
}

func (t CbTime32) BeforeTime(other time.Time) bool {
	return time.Time(t).Before(other)
}

func (t CbTime32) After(other CbTime32) bool {
	return time.Time(t).After(time.Time(other))
}

func (t CbTime32) Add(d time.Duration) CbTime32 {
	return CbTime32(time.Time(t).Add(time.Duration(d)))
}

// Diff will return the difference from _t_ to _other_ as a _time.Duration_.
// If the _other_ is greater than _t_ it will be a positive value, otherwise
// it will be negative.
func (t CbTime32) Diff(other CbTime32) time.Duration {
	return time.Time(t).Sub(time.Time(other))
}

// IsZero returns true if the time value is zero
func (t CbTime32) IsZero() bool {
	return time.Time(t).IsZero()
}

// Creates a new `CbTime32` from current local date and time
func NewTime32Now() *CbTime32 {
	return NewTime32(time.Now().Unix())
}

// Creates a new `CbTime32` from current _UTC_ date and time
func NewTimeUTC32Now() *CbTime32 {
	return NewTime32(time.Now().UTC().Unix())
}

func (t CbTime32) RFC3339() string {
	return time.Time(t).Format(time.RFC3339)
}
func (t CbTime32) Format(layout string) string {
	return time.Time(t).Format(layout)
}

// Unix returns _CbTime32_ as a _Unix Epoch Time_, the number of seconds elapsed
// since January 1, 1970 UTC. The result does not depend on the location associated with t.
func (t CbTime32) Unix() int64 {
	return time.Time(t).Unix()
}

// UTC returns the _CbTime32_ as a _time.Time instance in _UTC_
func (t CbTime32) UTC() time.Time {
	return time.Time(t).UTC()
}

// CbTime32UTC creates a new _CbTime32_ with the time as _UTC_.
func (t CbTime32) CbTime32UTC() CbTime32 {
	return CbTime32(t.UTC())
}

// WithTimeZone creates a new time.Time with the specific timeZone e.g. _Europe/Stockholm_ or _UTC_.
// Note that _UTC_ do not have daylight saving whereas _Europe/Stockholm_ has one hour shift twice a year.
//
// .Example usage
// [source,go]
// ----
// t, err := NewTime(1601902283).WithTimeZone("Europe/Stockholm") // Local time (offset +02:00)
// ----
func (t CbTime32) WithTimeZone(timeZone string) (time.Time, error) {
	return In(t.UTC(), timeZone)
}

// WithTimeZoneAsCbTime uses the `WithTimeZone` function to create a new `CbTime32` with the specific timeZone.
func (t CbTime32) WithTimeZoneAsCbTime(timeZone string) (CbTime32, error) {
	nt, err := t.WithTimeZone(timeZone)
	return CbTime32(nt), err
}

// ToMilliSeconds returns the time _t_ in milliseconds.
func ToMilliSeconds(t time.Time) int64 {
	return t.UnixNano() / (int64(time.Millisecond) / int64(time.Nanosecond))
}

// In creates a new time that is adjusted to the in parameter _timezone_.
//
// The _timezone_ may be a _IANA_ compatible timezone, +/-HH:MM that gets
// translated to hours and minutes from _UTC_ and abbreviated timezone such
// as _W. Europe Standard Time_ (in this case gets translated to "Europe/Berlin_).
//
// NOTE: That the +/-HH:MM will not have any daylight savings since it is converted to a _UTC_ time.
func In(t time.Time, timezone string) (time.Time, error) {
	if unicode.IsDigit(rune(timezone[0])) || timezone[0] == '+' ||
		timezone[0] == '-' || timezone[0] == 'Z' {
		offset, _, err := tzToSeconds(timezone)
		if err != nil {
			return t, err
		}

		loc := time.FixedZone("UTC", offset)
		return t.In(loc), nil
	}

	loc, err := time.LoadLocation(timezone)
	if err == nil {
		return t.In(loc), nil
	}

	if abbreviated, ok := ToIANA(timezone); ok {
		loc, err := time.LoadLocation(abbreviated)
		if err == nil {
			return t.In(loc), nil
		}

		return t, err
	}

	return t, err

}

// FromRFC3339String parses a `time.RFC3339` string and returns a `CbTime32`
// representation of it.
func FromRFC3339String(ts string) (CbTime32, error) {
	t, err := time.Parse(time.RFC3339, ts)
	if err != nil {
		return CbTime32{}, err
	}

	return CbTime32(t), nil
}

// ToCbTimeStamp will try to parse the _ts_ string and return a timestamp
//
// If it deemed a `time.RFC3339` string it will try to parse it as such. If
// not it will use the _tz_ to load the location and use the _notRFC3339Format_
// to parse the string. If it is an empty string, it will try to parse with timezone
// but in a `time.RFC3339` without the timezone in the _ts_.
//
// When _onFailure_ is set and the function fails to parse, it will be returned. If `nil`
// it will use `coremodel.NewTime32(time.Now().Unix())`.
func TryParseTimeStamp32(tz, ts, notRFC3339Format string, onFailure *CbTime32) (CbTime32, error) {
	if onFailure == nil {
		onFailure = NewTime32(time.Now().Unix())
	}

	len := len(ts)
	check := ts[len-6 : len-5]
	if strings.HasSuffix(ts, "Z") || check == "+" || check == "-" {
		t, err := time.Parse(time.RFC3339, ts)
		if err != nil {
			return *onFailure, err
		} else {
			return CbTime32(t), nil
		}
	}

	if loc, err := time.LoadLocation(tz); err != nil {
		return *onFailure, err
	} else {
		if notRFC3339Format == "" {
			notRFC3339Format = time.RFC3339
		}

		t, err := time.ParseInLocation(notRFC3339Format, ts, loc)

		if err != nil {
			return *onFailure, err
		}

		if t, err = In(t, "UTC"); err != nil {
			return *onFailure, err
		} else {
			return CbTime32(t), nil
		}
	}
}

// tzToSeconds translates the in param timeZone on format _+/_HH:MM or just Z
// into seconds.
//
// If any error on timeZone format it will return an error.
func tzToSeconds(timeZone string) (tzSeconds int, tzFormatted string, err error) {
	if len(timeZone) > 4 {
		if timeZone[0] >= '0' && timeZone[0] <= '9' {
			tzFormatted = "+" + timeZone
		} else {
			tzFormatted = timeZone
		}

		if len(timeZone) != 6 {
			err = fmt.Errorf("TimeZone must be on format +/HH:MM or Z = '%s'", timeZone)
			return
		}

		tzh := tzFormatted[1:3]
		tzm := tzFormatted[4:6]
		var offsetHour int64
		var offsetMinute int64

		offsetHour, err = strconv.ParseInt(tzh, 10, 64)
		if err != nil {
			return
		}

		offsetMinute, err = strconv.ParseInt(tzm, 10, 64)
		if err != nil {
			return
		}

		tzSeconds = int(offsetHour*60*60 + (offsetMinute * 60))
		return
	}

	if timeZone == "" || strings.ToUpper(timeZone) == "Z" {
		timeZone = "Z"
		tzFormatted = "Z"
		tzSeconds = 0
	} else {
		err = fmt.Errorf("TimeZone must be on format +/HH:MM or Z = '%s'", timeZone)
	}

	return
}

// AbbreviatedTimeZone is a windows (only) timezone
type AbbreviatedTimeZone map[string]string

// ToIANA translates a windows timezone to an IANA timezone.
func ToIANA(windows string) (iana string, ok bool) {
	iana, ok = abbreviationToIANA[windows]
	return
}

// IsIANATimeZone checks if the timezone is a valid IANA timezone.
func IsIANATimeZone(iana string) bool {
	if iana == "" {
		return false
	}

	z, ok := time.LoadLocation(iana)

	return ok != nil && z != nil
}

// ToWindows takes a iana timezone and returns the windows timezone.
func ToWindows(iana string) (windows string, ok bool) {
	for k, v := range abbreviationToIANA {
		if v == iana {
			windows = k
			ok = true
			break
		}
	}

	return
}

// GetWindowsTimeZones returns a map of windows timezones and their IANA counterpart.
func GetWindowsTimeZones() AbbreviatedTimeZone {
	return abbreviationToIANA
}

// TimeZones returns all IANA timezones supported by _TEOS_.
func TimeZones(sorted bool) []string {
	values := slices.Collect(maps.Values(abbreviationToIANA))

	if sorted {
		slices.Sort(values)
	}

	return values
}

// abbreviationToIANA is a translation table where it translates an _abbreviation_ to a _IANA_ compatible _timezone_.
var abbreviationToIANA = AbbreviatedTimeZone{
	"Egypt Standard Time":             "Africa/Cairo",
	"Morocco Standard Time":           "Africa/Casablanca",
	"South Africa Standard Time":      "Africa/Johannesburg",
	"Sudan Standard Time":             "Africa/Khartoum",
	"W. Central Africa Standard Time": "Africa/Lagos",
	"E. Africa Standard Time":         "Africa/Nairobi",
	"Sao Tome Standard Time":          "Africa/Sao_Tome",
	"Libya Standard Time":             "Africa/Tripoli",
	"Namibia Standard Time":           "Africa/Windhoek",
	"Aleutian Standard Time":          "America/Adak",
	"Alaskan Standard Time":           "America/Anchorage",
	"Tocantins Standard Time":         "America/Araguaina",
	"Paraguay Standard Time":          "America/Asuncion",
	"Bahia Standard Time":             "America/Bahia",
	"SA Pacific Standard Time":        "America/Bogota",
	"Argentina Standard Time":         "America/Buenos_Aires",
	"Eastern Standard Time (Mexico)":  "America/Cancun",
	"Venezuela Standard Time":         "America/Caracas",
	"SA Eastern Standard Time":        "America/Cayenne",
	"Central Standard Time":           "America/Chicago",
	"Mountain Standard Time (Mexico)": "America/Chihuahua",
	"Central Brazilian Standard Time": "America/Cuiaba",
	"Mountain Standard Time":          "America/Denver",
	"Greenland Standard Time":         "America/Godthab",
	"Turks And Caicos Standard Time":  "America/Grand_Turk",
	"Central America Standard Time":   "America/Guatemala",
	"Atlantic Standard Time":          "America/Halifax",
	"Cuba Standard Time":              "America/Havana",
	"US Eastern Standard Time":        "America/Indianapolis",
	"SA Western Standard Time":        "America/La_Paz",
	"Pacific Standard Time":           "America/Los_Angeles",
	"Central Standard Time (Mexico)":  "America/Mexico_City",
	"Saint Pierre Standard Time":      "America/Miquelon",
	"Montevideo Standard Time":        "America/Montevideo",
	"Eastern Standard Time":           "America/New_York",
	"US Mountain Standard Time":       "America/Phoenix",
	"Haiti Standard Time":             "America/Port-au-Prince",
	"Magallanes Standard Time":        "America/Punta_Arenas",
	"Canada Central Standard Time":    "America/Regina",
	"Pacific SA Standard Time":        "America/Santiago",
	"E. South America Standard Time":  "America/Sao_Paulo",
	"Newfoundland Standard Time":      "America/St_Johns",
	"Pacific Standard Time (Mexico)":  "America/Tijuana",
	"Central Asia Standard Time":      "Asia/Almaty",
	"Jordan Standard Time":            "Asia/Amman",
	"Arabic Standard Time":            "Asia/Baghdad",
	"Azerbaijan Standard Time":        "Asia/Baku",
	"SE Asia Standard Time":           "Asia/Bangkok",
	"Altai Standard Time":             "Asia/Barnaul",
	"Middle East Standard Time":       "Asia/Beirut",
	"India Standard Time":             "Asia/Calcutta",
	"Transbaikal Standard Time":       "Asia/Chita",
	"Sri Lanka Standard Time":         "Asia/Colombo",
	"Syria Standard Time":             "Asia/Damascus",
	"Bangladesh Standard Time":        "Asia/Dhaka",
	"Arabian Standard Time":           "Asia/Dubai",
	"West Bank Standard Time":         "Asia/Hebron",
	"W. Mongolia Standard Time":       "Asia/Hovd",
	"North Asia East Standard Time":   "Asia/Irkutsk",
	"Israel Standard Time":            "Asia/Jerusalem",
	"Afghanistan Standard Time":       "Asia/Kabul",
	"Russia Time Zone 11":             "Asia/Kamchatka",
	"Pakistan Standard Time":          "Asia/Karachi",
	"Nepal Standard Time":             "Asia/Katmandu",
	"North Asia Standard Time":        "Asia/Krasnoyarsk",
	"Magadan Standard Time":           "Asia/Magadan",
	"N. Central Asia Standard Time":   "Asia/Novosibirsk",
	"Omsk Standard Time":              "Asia/Omsk",
	"North Korea Standard Time":       "Asia/Pyongyang",
	"Qyzylorda Standard Time":         "Asia/Qyzylorda",
	"Myanmar Standard Time":           "Asia/Rangoon",
	"Arab Standard Time":              "Asia/Riyadh",
	"Sakhalin Standard Time":          "Asia/Sakhalin",
	"Korea Standard Time":             "Asia/Seoul",
	"China Standard Time":             "Asia/Shanghai",
	"Singapore Standard Time":         "Asia/Singapore",
	"Russia Time Zone 10":             "Asia/Srednekolymsk",
	"Taipei Standard Time":            "Asia/Taipei",
	"West Asia Standard Time":         "Asia/Tashkent",
	"Georgian Standard Time":          "Asia/Tbilisi",
	"Iran Standard Time":              "Asia/Tehran",
	"Tokyo Standard Time":             "Asia/Tokyo",
	"Tomsk Standard Time":             "Asia/Tomsk",
	"Ulaanbaatar Standard Time":       "Asia/Ulaanbaatar",
	"Vladivostok Standard Time":       "Asia/Vladivostok",
	"Yakutsk Standard Time":           "Asia/Yakutsk",
	"Ekaterinburg Standard Time":      "Asia/Yekaterinburg",
	"Caucasus Standard Time":          "Asia/Yerevan",
	"Azores Standard Time":            "Atlantic/Azores",
	"Cape Verde Standard Time":        "Atlantic/Cape_Verde",
	"Greenwich Standard Time":         "Atlantic/Reykjavik",
	"Cen. Australia Standard Time":    "Australia/Adelaide",
	"E. Australia Standard Time":      "Australia/Brisbane",
	"AUS Central Standard Time":       "Australia/Darwin",
	"Aus Central W. Standard Time":    "Australia/Eucla",
	"Tasmania Standard Time":          "Australia/Hobart",
	"Lord Howe Standard Time":         "Australia/Lord_Howe",
	"W. Australia Standard Time":      "Australia/Perth",
	"AUS Eastern Standard Time":       "Australia/Sydney",
	"UTC":                             "Etc/GMT",
	"UTC-11":                          "Etc/GMT+11",
	"Dateline Standard Time":          "Etc/GMT+12",
	"UTC-02":                          "Etc/GMT+2",
	"UTC-08":                          "Etc/GMT+8",
	"UTC-09":                          "Etc/GMT+9",
	"UTC+12":                          "Etc/GMT-12",
	"UTC+13":                          "Etc/GMT-13",
	"Astrakhan Standard Time":         "Europe/Astrakhan",
	"W. Europe Standard Time":         "Europe/Berlin",
	"Sweden Standard Time":            "Europe/Stockholm",
	"GTB Standard Time":               "Europe/Bucharest",
	"Central Europe Standard Time":    "Europe/Budapest",
	"E. Europe Standard Time":         "Europe/Chisinau",
	"Turkey Standard Time":            "Europe/Istanbul",
	"Kaliningrad Standard Time":       "Europe/Kaliningrad",
	"FLE Standard Time":               "Europe/Kiev",
	"GMT Standard Time":               "Europe/London",
	"Belarus Standard Time":           "Europe/Minsk",
	"Russian Standard Time":           "Europe/Moscow",
	"Romance Standard Time":           "Europe/Paris",
	"Russia Time Zone 3":              "Europe/Samara",
	"Saratov Standard Time":           "Europe/Saratov",
	"Volgograd Standard Time":         "Europe/Volgograd",
	"Central European Standard Time":  "Europe/Warsaw",
	"Mauritius Standard Time":         "Indian/Mauritius",
	"Samoa Standard Time":             "Pacific/Apia",
	"New Zealand Standard Time":       "Pacific/Auckland",
	"Bougainville Standard Time":      "Pacific/Bougainville",
	"Chatham Islands Standard Time":   "Pacific/Chatham",
	"Easter Island Standard Time":     "Pacific/Easter",
	"Fiji Standard Time":              "Pacific/Fiji",
	"Central Pacific Standard Time":   "Pacific/Guadalcanal",
	"Hawaiian Standard Time":          "Pacific/Honolulu",
	"Line Islands Standard Time":      "Pacific/Kiritimati",
	"Marquesas Standard Time":         "Pacific/Marquesas",
	"Norfolk Standard Time":           "Pacific/Norfolk",
	"West Pacific Standard Time":      "Pacific/Port_Moresby",
	"Tonga Standard Time":             "Pacific/Tongatapu",
}
