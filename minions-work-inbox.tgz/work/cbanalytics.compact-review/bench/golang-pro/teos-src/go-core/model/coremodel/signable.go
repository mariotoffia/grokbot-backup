package coremodel

type SignableObject struct {
	// This is a incrementing version of the building object. Each time any of the fields has been updated this will be incremented.
	Version int64 `json:"ver"`
	// This is a signature, either a human or software actor. This is to aid in auditing and when config changes are made.
	//
	// NOTE: When a provider do a configuration change and it also listens for those, it would create a cyclic behavior. Hence,
	// it is possible to sort out the ones done by itself (by inspecting this property).
	Sign string `json:"sig"`
}
