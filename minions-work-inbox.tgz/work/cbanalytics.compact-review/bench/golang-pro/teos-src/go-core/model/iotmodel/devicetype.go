package iotmodel

import "time"

// DeviceType is a type definition that one or more `Device` may assume.
// It is a way of grouping devices and also may add searchable attributes.
type DeviceType struct {
	// A unique id of the device type definition. This id is encoded as `_[a-z][A-Z]_`
	ID string
	// URI is an optional _URI_ that is platform specific where the device resource is located
	URI string
	// Name is a human readable name of the device type definition
	Name string
	// Description is a free text description about this definition.
	Description string
	// Created specifies, if supported, the date and time UTC when this definition was created.
	Created time.Time
	// Deprecated decides if any more `Device` may be associated with this definition or not.
	Deprecated bool
	//  DeprecationDate specifies, if supported, the date and time UTC when this definition was deprecated.
	DeprecationDate time.Time
	// SearchableAttributes specifies, if supported, a number of attribute names that the device registry will index
	// on the actual Device to be searchable.
	SearchableAttributes []string
}
