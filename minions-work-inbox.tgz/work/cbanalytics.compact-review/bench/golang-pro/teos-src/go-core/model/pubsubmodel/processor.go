package pubsubmodel

import "encoding/json"

// ProcessorType is the type of processor.
type ProcessorType string

const (
	// ProcessorTypeDsBuilding will process a `DsBuilding` data payload into processed and meta
	// for the payload.
	ProcessorTypeDsBuilding ProcessorType = "ds-building"
)

// Exists will check if the _p_ exists in the _s_ slice.
func (p ProcessorType) Exists(s []ProcessorType) bool {
	for _, v := range s {
		if v == p {
			return true
		}
	}
	return false
}

// TranslateFunc is a function to do translation from a payload to
// a `pubsubmodel.PayloadImpl.Meta` and if supported, into
// `pubsubmodel.PayloadImpl.Processed` format.
type TranslateFunc func(
	payload json.RawMessage,
) (meta map[string]interface{}, processed map[string]interface{}, err error)

// ProcessorImpl is a quick way of implementing the `ifpubsub.Processor` interface.
type ProcessorImpl struct {
	// TF is the actual function to do the translation.
	TF TranslateFunc
}

func (p *ProcessorImpl) Translate(
	payload json.RawMessage,
) (meta map[string]interface{}, processed map[string]interface{}, err error) {
	return p.TF(payload)
}
