package events

import (
	"github.com/Thiink-LLC/teos/go-core/model/activation"
	"github.com/Thiink-LLC/teos/go-core/model/events"
)

type Event events.Event
type EventType events.EventType

type ActivationUserConfigItem activation.ActivationUserConfigItem
type ActivationMetaConfig activation.ActivationMetaConfig
type ConstraintsNotMet activation.ConstraintsNotMet
type ActivationLifecycle activation.ActivationLifecycle
