package rtc

import (
	"encoding/json"
	"fmt"

	"github.com/Thiink-LLC/teos/go-core/cberror"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifcore"
	"github.com/Thiink-LLC/teos/go-core/interfaces/ifprovider"
	"github.com/Thiink-LLC/teos/go-core/logger/log"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
)

// RtcFrameTypes is a type that represents the available frame types.
type RtcFrameTypes interface {
	*SimpleActuationFrame | *SimpleCollectionFrame | *SimpleSubscriptionFrame
}

// UnmarshalJSON is overridden since the generator is really in bad
// shape. It's not possible to unmarshal into a struct with a mapping
// discriminator and a oneOf field.
func (dst *RtChannelMessage) UnmarshalJSON(data []byte) error {
	// MessageType used to determine the message type.
	type MessageType struct {
		MessageType RtChannelMessageType `json:"frame"`
	}

	var msgType MessageType
	if err := json.Unmarshal(data, &msgType); err != nil {
		return err
	}

	switch msgType.MessageType {
	case SIMPLE_COLLECTION_FRAME:
		dst.SimpleCollectionFrame = &SimpleCollectionFrame{}
		return json.Unmarshal(data, dst.SimpleCollectionFrame)
	case SIMPLE_ACTUATION_FRAME:
		dst.SimpleActuationFrame = &SimpleActuationFrame{}
		return json.Unmarshal(data, dst.SimpleActuationFrame)
	case SIMPLE_SUBSCRIPTION_FRAME:
		dst.SimpleSubscriptionFrame = &SimpleSubscriptionFrame{}
		return json.Unmarshal(data, dst.SimpleSubscriptionFrame)
	}

	return fmt.Errorf("unknown message type: %s", msgType.MessageType)
}

// GetPipelineInputParametersFromRtcMessage will create input parameters for a pipeline execution to overlay when
// e.g. resolving global params for the profile.
func (dst *RtChannelMessage) GetPipelineInputParametersFromRtcMessage() map[string]any {
	params := map[string]any{}

	if dst == nil {
		return params
	}

	if dst.SimpleCollectionFrame != nil {
		if dst.SimpleCollectionFrame.Tz != "" {
			params[string(ifprovider.ParameterTimeZone)] = dst.SimpleCollectionFrame.Tz
		}

		if ret := ToRFC3339Time(dst.SimpleCollectionFrame.T); ret != "" {
			params[string(eqmodel.DataPointReceivedEventTime)] = ret
		}

		if dst.SimpleCollectionFrame.Pid != nil && *dst.SimpleCollectionFrame.Pid != "" {
			params[string(ifprovider.ParameterPlantID)] = *dst.SimpleCollectionFrame.Pid
		}

		if dst.SimpleCollectionFrame.Tid != nil && *dst.SimpleCollectionFrame.Tid != "" {
			params[string(ifprovider.ParameterTenantID)] = *dst.SimpleCollectionFrame.Tid
		}

		if dst.SimpleCollectionFrame.Lid != "" {
			params[string(ifprovider.ParameterLocationID)] = dst.SimpleCollectionFrame.Lid
		}

		return params
	}

	if dst.SimpleActuationFrame != nil {
		if dst.SimpleActuationFrame.Pid != nil && *dst.SimpleActuationFrame.Pid != "" {
			params[string(ifprovider.ParameterPlantID)] = *dst.SimpleActuationFrame.Pid
		}

		if dst.SimpleActuationFrame.Tid != nil && *dst.SimpleActuationFrame.Tid != "" {
			params[string(ifprovider.ParameterTenantID)] = *dst.SimpleActuationFrame.Tid
		}

		if dst.SimpleActuationFrame.Lid != "" {
			params[string(ifprovider.ParameterLocationID)] = dst.SimpleActuationFrame.Lid
		}

		return params
	}

	if dst.SimpleSubscriptionFrame != nil {
		if dst.SimpleSubscriptionFrame.Pid != nil && *dst.SimpleSubscriptionFrame.Pid != "" {
			params[string(ifprovider.ParameterPlantID)] = *dst.SimpleSubscriptionFrame.Pid
		}

		if dst.SimpleSubscriptionFrame.Tid != nil && *dst.SimpleSubscriptionFrame.Tid != "" {
			params[string(ifprovider.ParameterTenantID)] = *dst.SimpleSubscriptionFrame.Tid
		}

		if dst.SimpleSubscriptionFrame.Lid != "" {
			params[string(ifprovider.ParameterLocationID)] = dst.SimpleSubscriptionFrame.Lid
		}

		return params
	}

	return params
}

// GetFrame will get the frame from the message, if it exists. Otherwise it will return `nil`.
//
// If it did not get a hit, it will warn log the miss if _logIfMiss_ is `true`.
func GetFrame[T RtcFrameTypes](ctx ifcore.CbContext, msg *RtChannelMessage, logIfMiss bool) T {
	if msg == nil {
		return nil
	}

	var t T

	switch any(t).(type) {
	case *SimpleCollectionFrame:
		if msg.SimpleCollectionFrame != nil {
			return any(msg.SimpleCollectionFrame).(T)
		}
	case *SimpleActuationFrame:
		if msg.SimpleActuationFrame != nil {
			return any(msg.SimpleActuationFrame).(T)
		}
	case *SimpleSubscriptionFrame:
		if msg.SimpleSubscriptionFrame != nil {
			return any(msg.SimpleSubscriptionFrame).(T)
		}
	}

	if !logIfMiss {
		return nil
	}

	if msg.SimpleCollectionFrame != nil {
		log.Warn(ctx).
			WithBody(msg.SimpleCollectionFrame).
			Msgf("Expecting %T but got SimpleCollectionFrame", t)
	}

	if msg.SimpleActuationFrame != nil {
		log.Warn(ctx).
			WithBody(msg.SimpleActuationFrame).
			Msgf("Expecting %T but got SimpleActuationFrame", t)
	}

	if msg.SimpleSubscriptionFrame != nil {
		log.Warn(ctx).
			WithBody(msg.SimpleSubscriptionFrame).
			Msgf("Expecting %T but got SimpleSubscriptionFrame", t)
	}

	return nil
}

// ExtractRtcMessageFrame searches for the first frame in the message and returns it.
// If it can extract the _locationID_ from the frame it will also return it.
//
// If a frame is not found it will return an error.
func (dst *RtChannelMessage) ExtractRtcMessageFrame(
	ctx ifcore.CbContext,
) (frame any, locationID string, err cberror.Error) {
	if dst == nil {
		return
	}

	if dst.SimpleCollectionFrame != nil {
		frame = dst.SimpleCollectionFrame
		locationID = dst.SimpleCollectionFrame.Lid
	} else if dst.SimpleActuationFrame != nil {
		frame = dst.SimpleActuationFrame
		locationID = dst.SimpleActuationFrame.Lid
	} else if dst.SimpleSubscriptionFrame != nil {
		frame = dst.SimpleSubscriptionFrame
		locationID = dst.SimpleSubscriptionFrame.Lid
	} else {
		err = cberror.NewCbErrorfWithProps(
			ctx.Service(),
			cberror.ErrorProviderRTCFrameMissingInMessage,
			nil,
			map[string]any{cberror.PropertyProvider: ctx.Provider()},
			"Expecting one frame in the `RtcChannelMessage` but none found",
		)
	}

	return
}
