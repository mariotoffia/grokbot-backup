package eqdefs_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/Thiink-LLC/teos/go-core/model/eqmodel"
	"github.com/Thiink-LLC/teos/go-core/model/eqmodel/eqdefs"
)

// TestDefinitionMapHoldsEverySection checks that DefinitionMap holds a data
// point from each of the sections it is built from.
func TestDefinitionMapHoldsEverySection(t *testing.T) {
	ids := []string{
		string(eqmodel.DataPointAverageIndoorTempControl),
		string(eqmodel.SensorSupplyHeatingPrimaryCircuitTemperature),
		string(eqmodel.SensorSupplyHotWaterPrimaryCircuitTemperature),
		string(eqmodel.DataPointEnabledCircuits),
		string(eqmodel.ConfigurationTypeIndoorTemperatureLimitLow),
	}

	for _, id := range ids {
		definition, ok := eqdefs.DefinitionMap[id]
		require.True(t, ok, id)
		assert.Equal(t, id, definition.TeosID)
	}
}
