package coremodel_test

import (
	"regexp"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"

	"github.com/Thiink-LLC/teos/go-core/model/coremodel"
)

// TestEncodeLocationIDGivesDifferentIDsDifferentNames checks that two ids,
// one of which reads like the escaped form of the other, encode to two
// different names.
func TestEncodeLocationIDGivesDifferentIDsDifferentNames(t *testing.T) {
	tests := []struct {
		a, b string
	}{
		{"A B", "A_20B"},
		{"xå", "x_C3_A5"},
	}

	for _, tt := range tests {
		t.Run(tt.a+" vs "+tt.b, func(t *testing.T) {
			assert.NotEqual(t,
				coremodel.EncodeLocationID(tt.a),
				coremodel.EncodeLocationID(tt.b),
			)
		})
	}
}

// thingNameCharacters matches a string made only of the characters AWS IoT
// accepts in a thing name.
var thingNameCharacters = regexp.MustCompile(`^[A-Za-z0-9:_-]*$`)

// FuzzDecodeLocationIDReturnsTheEncodedID checks that an encoded name uses
// only the characters AWS IoT accepts in a thing name, and that decoding it
// gives back the original id, including ids that contain "_" or "%".
func FuzzDecodeLocationIDReturnsTheEncodedID(f *testing.F) {
	for _, id := range []string{
		"A B",
		"A_20B",
		"A_B",
		"_",
		"__5F",
		"Måssmyren 18",
		"site_1",
		"tklocal-site_1",
		"100%",
		"a/b;c",
		"Kosmonautów 30",
		"Storgatan 1.5",
		"a~b",
		"a+b",
		"user@example",
		"urn:a-b",
	} {
		f.Add(id)
	}

	f.Fuzz(func(t *testing.T, id string) {
		encoded := coremodel.EncodeLocationID(id)

		assert.Regexp(t, thingNameCharacters, encoded)
		assert.Equal(t, id, coremodel.DecodeLocationID(encoded))
	})
}

// TestEncodeLocationIDEscapesCharactersAThingNameRefuses checks the exact
// encoded names of ids with characters AWS IoT refuses in a thing name, and
// that ':' and '-' are kept as they are.
func TestEncodeLocationIDEscapesCharactersAThingNameRefuses(t *testing.T) {
	tests := []struct {
		id, want string
	}{
		{"Storgatan 1.5", "Storgatan_201_2E5"},
		{"a~b", "a_7Eb"},
		{"a$b", "a_24b"},
		{"a&b", "a_26b"},
		{"a+b", "a_2Bb"},
		{"a=b", "a_3Db"},
		{"a@b", "a_40b"},
		{"urn:a-b", "urn:a-b"},
	}

	for _, tt := range tests {
		t.Run(tt.id, func(t *testing.T) {
			assert.Equal(t, tt.want, coremodel.EncodeLocationID(tt.id))
		})
	}
}

// TestEncodeLocationIDEscapesUnderscore checks that a literal "_" is written
// as "_5F".
func TestEncodeLocationIDEscapesUnderscore(t *testing.T) {
	tests := []struct {
		id, want string
	}{
		{"A_20B", "A_5F20B"},
		{"site_1", "site_5F1"},
		{"_", "_5F"},
	}

	for _, tt := range tests {
		t.Run(tt.id, func(t *testing.T) {
			assert.Equal(t, tt.want, coremodel.EncodeLocationID(tt.id))
		})
	}
}

// TestEncodeLocationIDKeepsNamesOfIDsWithoutUnderscore checks the exact
// encoded names of ids that contain no "_".
func TestEncodeLocationIDKeepsNamesOfIDsWithoutUnderscore(t *testing.T) {
	tests := []struct {
		id, want string
	}{
		{"Måssmyren 18", "M_C3_A5ssmyren_2018"},
		{"Kosmonautów 30", "Kosmonaut_C3_B3w_2030"},
		{"svctest-abc", "svctest-abc"},
		{"A B", "A_20B"},
	}

	for _, tt := range tests {
		t.Run(tt.id, func(t *testing.T) {
			assert.Equal(t, tt.want, coremodel.EncodeLocationID(tt.id))
		})
	}
}

// complexLocationID is an id of about 100 characters with spaces, "_" and
// non-ASCII letters.
var complexLocationID = strings.Repeat("Måssmyren_18 Kosmonautów ", 4)

func BenchmarkEncodeLocationID(b *testing.B) {
	for _, bc := range []struct{ name, id string }{
		{"simple", "site1"},
		{"complex", complexLocationID},
	} {
		b.Run(bc.name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				_ = coremodel.EncodeLocationID(bc.id)
			}
		})
	}
}

func BenchmarkDecodeLocationID(b *testing.B) {
	for _, bc := range []struct{ name, id string }{
		{"simple", "site1"},
		{"complex", complexLocationID},
	} {
		encoded := coremodel.EncodeLocationID(bc.id)
		b.Run(bc.name, func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				_ = coremodel.DecodeLocationID(encoded)
			}
		})
	}
}
