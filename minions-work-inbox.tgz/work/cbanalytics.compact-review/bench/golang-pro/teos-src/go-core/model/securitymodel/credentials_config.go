package securitymodel

// CredentialConfig contains the configuration for a endpoint authentication.
//
// This is typically used to specify what type of credential is expected and what properties are
// required to perform an operation. The actual credential can be obtained anywhere.
type CredentialConfig struct {
	// CredentialsPointer contains a pointer to where to get the credentials from.
	//
	// Example 'provider/climatixic/nordvestor' or '[CRD]' where the latter is the
	//         _CRD_ variable from the context. This gets rendered each time a call is made.
	//
	// When a credential instance is fetched and it resolves to a call to a remote endpoint to extract
	// the *real* credentials / token, those will be cached until remote credentials / token expires.
	CredentialsPointer string `json:"crd,omitempty"`
	// AuthenticationFlow is the call chain or flow to use when authenticating. It can be a custom auth and thus
	// the value of this will be used to lookup in a `EndpointImpl.Chains`. It may also be one of the `WellknownAuthenticationFlow`.
	//
	// If such is the case it will try to do default handling of that flow. If not, it will try to lookup the `EndpointImpl.Chains`
	// for such name.
	AuthenticationFlow string `json:"flow,omitempty"`
	// Type specifies what type of credentials to expect.
	//
	// This is validated by the executor and if mismatch or requirement is not
	// met it will immediately return error. If omitted, the default is `CredentialsTypeToken`.
	Type CredentialsType `json:"type,omitempty"`
	// Required is an array of expected credentials to be provided in the
	// `securitymodel` credentials (specified by the _Crd_ field).
	Required []CredentialItemType `json:"required,omitempty"`
}

// HasCustomFlow will check if the `CredentialConfig.AuthenticationFlow` is not any of the `WellknownAuthenticationFlow`
// constants.
func (cc *CredentialConfig) HasCustomFlow() bool {
	return cc.AuthenticationFlow != string(WellknownAuthenticationFlowNone) &&
		cc.AuthenticationFlow != string(WellknownAuthenticationFlowBasicAuth) &&
		cc.AuthenticationFlow != string(WellknownAuthenticationFlowClientCredentials) &&
		cc.AuthenticationFlow != string(WellknownAuthenticationFlowCodeFlow) &&
		cc.AuthenticationFlow != string(WellknownAuthenticationFlowImplicitFlow) &&
		cc.AuthenticationFlow != string(WellknownAuthenticationFlowCodeProofKeyCodeExchange)
}

// HasBasicAuth checks if the `CredentialConfig.AuthenticationFlow` is `WellknownAuthenticationFlowBasicAuth`
func (cc *CredentialConfig) HasBasicAuth() bool {
	return cc.AuthenticationFlow == string(WellknownAuthenticationFlowBasicAuth)
}

// HasNoAuth checks if the `CredentialConfig.AuthenticationFlow` is `WellknownAuthenticationFlowNone`
func (cc *CredentialConfig) HasNoAuth() bool {
	return cc.AuthenticationFlow == string(WellknownAuthenticationFlowNone)
}

// WellknownAuthenticationFlow is well known authentication flows to use with `CredentialConfig.AuthenticationFlow`.
type WellknownAuthenticationFlow string

const (
	// WellknownAuthenticationFlowNone is no authentication flow
	WellknownAuthenticationFlowNone WellknownAuthenticationFlow = ""
	// WellknownAuthenticationFlowBasicAuth is the basic auth flow.
	WellknownAuthenticationFlowBasicAuth WellknownAuthenticationFlow = "basic"
	// WellknownAuthenticationFlowClientCredentials basic auth deluxe
	WellknownAuthenticationFlowClientCredentials WellknownAuthenticationFlow = "client"
	// WellknownAuthenticationFlowImplicitFlow is the OAuth implicit flow
	WellknownAuthenticationFlowImplicitFlow WellknownAuthenticationFlow = "implicit"
	// WellknownAuthenticationFlowCodeFlow is the OAuth2 code flow
	WellknownAuthenticationFlowCodeFlow WellknownAuthenticationFlow = "code"
	// WellknownAuthenticationFlowCodeProofKeyCodeExchange is the OAuth2 code flow with proof key for code exchange
	//
	// Defined in https://datatracker.ietf.org/doc/html/rfc7636[RFC7636].
	WellknownAuthenticationFlowCodeProofKeyCodeExchange WellknownAuthenticationFlow = "code+pkce"
)

// CredentialsType specifies what credential types to expect from the _CRD_ pointer.
type CredentialsType string

const (
	// CredentialsTypeStandard specifies that the `securitymodel.StandardCredentialsImpl` are expected
	// and do not obtain any token from the remote endpoint to store in a `securitymodel.TokenCredentialsImpl`
	CredentialsTypeStandard CredentialsType = "standard"
	// CredentialsTypeToken specifies that the `securitymodel.TokenCredentialsImpl` are expected
	//
	// It may be that the actual token is retrieved from the endpoint and stored in the `securitymodel.TokenCredentialsImpl`
	// or it has a pre-shared long lived token in it.
	CredentialsTypeToken CredentialsType = "token"
)

// CredentialItemType specifies a type of credential item such as username, password, API key etc.
type CredentialItemType string

const (
	// CredentialItemTypeUsername is a username
	CredentialItemTypeUsername = "user"
	// CredentialItemTypePassword is a password
	CredentialItemTypePassword = "pass"
	// CredentialItemTypeAPIKey is a API key
	CredentialItemTypeAPIKey = "apikey"
	// CredentialItemTypeToken is a token of any kind, usually a access token. Often the token is retrieved
	// at runtime but may be static or long lived and thus manually / automatic configured.
	CredentialItemTypeToken = "token"
)

// HasCredentialItemType checks if _t_ is within the slice _c_.
func HasCredentialItemType(c []CredentialItemType, t CredentialItemType) bool {
	for _, v := range c {
		if v == t {
			return true
		}
	}
	return false
}
