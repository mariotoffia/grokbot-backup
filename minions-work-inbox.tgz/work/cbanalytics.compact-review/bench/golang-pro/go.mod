module golangpro

go 1.25.0

require github.com/Thiink-LLC/teos/go-core v0.0.0

require github.com/Masterminds/semver/v3 v3.5.0 // indirect

replace github.com/Thiink-LLC/teos/go-core => ./teos-src/go-core
