# golang-pro benchmarks: cbanalytics compact storage (teos c71c73ba)

Supports `../../lenses/golang-pro.md`. Go used: go1.27.3 linux/amd64 (Intel Xeon, 8 threads).

| File | What |
|---|---|
| shape.go | Reference-location partition state from design §8.5 (700 sensors, 50 monitors), design format A (CBOR, absolute ms) |
| packed.go | Variant B (same CBOR, anchor-relative times) and C (packed uvarint columns) encoder/decoder |
| bench_test.go | Round-trip + size test, Encode/Decode/Compress/BatchJSON/IdentityLookup benchmarks |
| sizes.txt, bench.txt, benchstat.txt | Results quoted in the lens (count=6, benchtime=200ms) |
| go.mod, go.sum | Module `golangpro`; `replace` → `./teos-src/go-core` |
| setup.sh | Recreates `teos-src/` from `git -C /workspace/repos/teos archive c71c73ba go-core` (override repo with `TEOS_REPO`) |

`teos-src/` is generated; recreate it rather than editing it.

## Rerun
```bash
cd /workspace/minions/work/cbanalytics.compact-review/bench/golang-pro
./setup.sh
go vet ./...
go test -run TestRoundTripAndSizes -v . | tee sizes.txt
go test -run '^$' -bench . -benchmem -count=6 -benchtime=200ms . | tee bench.txt
go run golang.org/x/perf/cmd/benchstat@latest bench.txt | tee benchstat.txt
```
