// Package golangpro benchmarks the partition-state encoding proposed in
// COMPACT_STORAGE_DESIGN.md (section 8) against simpler/smaller alternatives.
// Shapes follow section 8.5 (reference location: 700 sensors, 50 monitors).
package golangpro

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"math/rand/v2"
)

// ---- Design format (section 8.1/8.2/8.3): CBOR maps, columns as arrays,
// times as int64 ms since epoch (9 bytes each), decimals via the strict profile.

type Header struct {
	Format       int      `json:"f"`
	Major        int      `json:"m"`
	Partition    string   `json:"p"`
	Applied      string   `json:"a"`
	Batches      [][]byte `json:"b"` // 16-byte SHA-256 prefixes (section 9.1)
	Completeness int64    `json:"c"`
	LastEval     int64    `json:"e"`
	Due          int64    `json:"d"`
	Epoch        int64    `json:"ep"`
	Counter      int64    `json:"rc"`
	Revision     int64    `json:"r"`
	ConfigRev    int64    `json:"cr"`
}

type Sensors struct {
	Names   []string `json:"n"`
	Source  []uint16 `json:"s"`
	Sources []string `json:"ss"`
}

type Shared struct {
	Last    []int64       `json:"l"`
	Prev    []int64       `json:"p"`
	Since   []int64       `json:"vs"`
	Value   []json.Number `json:"v"`
	Quality []uint16      `json:"q"`
	Recent  [][]int64     `json:"rt"` // other recent event times (section 9.1)
}

type Admit struct {
	Sensor []uint16 `json:"s"`
	First  []int64  `json:"t"`
}

type AlarmCols struct {
	Sensor []uint16 `json:"s"`
	Phase  []uint16 `json:"ph"`
	Since  []int64  `json:"t"`
}

type WindowCols struct {
	Sensor []uint16      `json:"s"`
	Pane   []int64       `json:"ps"`
	Total  []json.Number `json:"tot"`
}

type Monitor struct {
	ID      string                `json:"id"`
	Version string                `json:"v"`
	Admit   map[string]Admit      `json:"ad,omitempty"`
	Alarms  map[string]AlarmCols  `json:"al,omitempty"`
	Windows map[string]WindowCols `json:"w,omitempty"`
}

type DesignState struct {
	Header   Header    `json:"h"`
	Sensors  Sensors   `json:"s"`
	Shared   Shared    `json:"sh"`
	Monitors []Monitor `json:"ms"`
}

// Params lets the benchmark vary the duplicate-retention list length
// (section 8.5: ~4 for hourly windows, 96 daily, 672 weekly).
type Params struct {
	Sensors     int
	RecentPer   int // recent event times per sensor that has a list
	RecentShare float64
	Jitter      bool // independent per-reading ms jitter (section 16 test 1, second run)
}

const fetch = int64(15 * 60 * 1000)

// Build returns a deterministic reference-location state.
func Build(p Params) *DesignState {
	r := rand.New(rand.NewPCG(1, 2))
	now := int64(1761400800000) // 2025-10-25T14:00Z, ms
	s := &DesignState{}
	h := &s.Header
	h.Format, h.Major = 1, 1
	h.Partition = "urn:teos:location:east:sv:LID-4711"
	h.Applied = "000000000000012345-0007"
	for i := range 96 {
		sum := sha256.Sum256(fmt.Appendf(nil, "log-line-%d", i))
		h.Batches = append(h.Batches, sum[:16])
	}
	h.Completeness, h.LastEval, h.Due = now, now, now+fetch
	h.Epoch, h.Counter, h.Revision, h.ConfigRev = 3, 98765, 2880, 7

	zones := []string{"ZWEST", "ZEAST", "ZNORTH", "ZSOUTH"}
	kinds := []string{"IDT", "IDH", "ICO2", "IDP", "OTE"}
	s.Sensors.Sources = []string{"urn:teos:provider:east:regin:sv:LID-4711"}
	for i := range p.Sensors {
		name := fmt.Sprintf("%s_O%d_C%d_%s_M%02d", kinds[i%len(kinds)], i/100+1, (i/10)%10, zones[i%4], i%100)
		s.Sensors.Names = append(s.Sensors.Names, name)
		s.Sensors.Source = append(s.Sensors.Source, 0)
		last := now - int64(r.IntN(3))*1000
		s.Shared.Last = append(s.Shared.Last, last)
		s.Shared.Prev = append(s.Shared.Prev, last-fetch)
		s.Shared.Since = append(s.Shared.Since, last-fetch*int64(r.IntN(8)))
		s.Shared.Value = append(s.Shared.Value, json.Number(fmt.Sprintf("%d.%d", 18+r.IntN(10), 1+r.IntN(9))))
		s.Shared.Quality = append(s.Shared.Quality, 0)
		var rec []int64
		if float64(i) < p.RecentShare*float64(p.Sensors) {
			for k := 2; k < p.RecentPer+2; k++ {
				t := last - int64(k)*fetch
				if p.Jitter {
					t -= int64(r.IntN(60000))
				}
				rec = append(rec, t)
			}
		}
		s.Shared.Recent = append(s.Shared.Recent, rec)
	}
	// 50 monitors: 35 alarm monitors, 10 window monitors, 5 others;
	// ~5,000 admission pairs over 75 signals; ~100 sensors per monitor.
	for m := range 50 {
		mon := Monitor{ID: fmt.Sprintf("monitor-%02d", m), Version: "1.4.2",
			Admit: map[string]Admit{}, Alarms: map[string]AlarmCols{}, Windows: map[string]WindowCols{}}
		base := (m * 13) % p.Sensors
		var ad Admit
		for k := range 100 {
			ad.Sensor = append(ad.Sensor, uint16((base+k)%p.Sensors))
			ad.First = append(ad.First, now-int64(r.IntN(30*96))*fetch)
		}
		mon.Admit["sig"] = ad
		switch {
		case m < 35:
			var al AlarmCols
			for k := range 5 { // 5 % of 100 instances raised
				al.Sensor = append(al.Sensor, uint16((base+k*17)%p.Sensors))
				al.Phase = append(al.Phase, 1)
				al.Since = append(al.Since, now-int64(r.IntN(96))*fetch)
			}
			mon.Alarms["hot"] = al
		case m < 45:
			var w WindowCols
			for k := range 100 {
				w.Sensor = append(w.Sensor, uint16((base+k)%p.Sensors))
				w.Pane = append(w.Pane, now-now%(3600000))
				w.Total = append(w.Total, json.Number(fmt.Sprintf("%d.%d", 60+r.IntN(40), 1+r.IntN(9))))
			}
			mon.Windows["hourly"] = w
		default:
			var w WindowCols // episodes: reference + time
			for k := range 100 {
				w.Sensor = append(w.Sensor, uint16((base+k)%p.Sensors))
				w.Pane = append(w.Pane, now-int64(r.IntN(96))*fetch)
				w.Total = append(w.Total, json.Number("1"))
			}
			mon.Windows["episode"] = w
		}
		s.Monitors = append(s.Monitors, mon)
	}
	return s
}
