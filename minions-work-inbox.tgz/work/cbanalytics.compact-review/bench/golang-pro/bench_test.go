package golangpro

import (
	"bytes"
	"compress/flate"
	"encoding/json"
	"fmt"
	"io"
	"reflect"
	"sync"
	"testing"
	"time"

	"github.com/Thiink-LLC/teos/go-core/cbanalytics/model"
)

var shapes = []struct {
	name string
	p    Params
}{
	{"hourly4", Params{700, 4, 0.5, false}}, // section 8.5 baseline
	{"daily96", Params{700, 96, 1, false}},  // section 8.5 daily window
	{"weekly672", Params{700, 672, 1, false}},
	{"weekly672jitter", Params{700, 672, 1, true}},
}

func cborA(s *DesignState) []byte {
	b, err := model.CBORMarshal(s)
	if err != nil {
		panic(err)
	}
	return b
}

func deflate(b []byte, lvl int) []byte {
	var out bytes.Buffer
	fw, _ := flate.NewWriter(&out, lvl)
	fw.Write(b)
	fw.Close()
	return out.Bytes()
}

func TestRoundTripAndSizes(t *testing.T) {
	for _, sh := range shapes {
		s := Build(sh.p)
		a := cborA(s)
		var back DesignState
		if err := model.CBORUnmarshal(a, &back); err != nil {
			t.Fatalf("A decode: %v", err)
		}
		if !bytes.Equal(cborA(&back), a) || !reflect.DeepEqual(back.Shared, s.Shared) {
			t.Errorf("%s: A round trip differs", sh.name)
		}
		b := cborA(Relative(s))
		c := EncodePacked(s, nil)
		cb, err := DecodePacked(c)
		if err != nil || !reflect.DeepEqual(cb, s) {
			t.Fatalf("%s: C round trip differs: %v", sh.name, err)
		}
		recs := 0
		for _, r := range s.Shared.Recent {
			recs += len(r)
		}
		t.Logf("%s recentTimes=%d", sh.name, recs)
		for _, v := range []struct {
			n string
			b []byte
		}{{"A_designCBOR", a}, {"B_cborRelative", b}, {"C_packed", c}} {
			t.Logf("%-10s %-15s raw=%8d B  perSensor=%6.1f  deflate6=%8d  deflate1=%8d",
				sh.name, v.n, len(v.b), float64(len(v.b))/700, len(deflate(v.b, 6)), len(deflate(v.b, 1)))
		}
	}
	// Per-value cost in the existing profile.
	one := func(v any) int { b, _ := model.CBORMarshal(v); return len(b) }
	t.Logf("int64 ms now=%dB  delta 15min=%dB  json.Number 21.5=%dB  time.Time(ms precision)=%dB  time.Time(whole s)=%dB",
		one(int64(1761400800123)), one(int64(900000)), one(json.Number("21.5")),
		one(time.UnixMilli(1761400800123).UTC()), one(time.Unix(1761400800, 0).UTC()))
	type bs struct {
		B  []byte   `json:"b"`
		BL [][]byte `json:"bl"`
	}
	id := make([]byte, 16)
	t.Logf("16B id as field=%dB, as element of [][]byte=%dB (base64 text)",
		one(bs{B: id})-one(bs{}), one(bs{BL: [][]byte{id}})-one(bs{}))
}

func BenchmarkEncode(b *testing.B) {
	for _, sh := range shapes {
		s := Build(sh.p)
		rel := Relative(s)
		b.Run(sh.name+"/A_designCBOR", func(b *testing.B) {
			b.ReportAllocs()
			var n int
			for b.Loop() {
				n = len(cborA(s))
			}
			b.ReportMetric(float64(n), "bytes/state")
		})
		b.Run(sh.name+"/B_cborRelative", func(b *testing.B) {
			b.ReportAllocs()
			var n int
			for b.Loop() {
				n = len(cborA(rel))
			}
			b.ReportMetric(float64(n), "bytes/state")
		})
		b.Run(sh.name+"/C_packed", func(b *testing.B) {
			b.ReportAllocs()
			buf := make([]byte, 0, 1<<16)
			var n int
			for b.Loop() {
				buf = EncodePacked(s, buf)
				n = len(buf)
			}
			b.ReportMetric(float64(n), "bytes/state")
		})
	}
}

func BenchmarkDecode(b *testing.B) {
	for _, sh := range shapes {
		s := Build(sh.p)
		a, br, c := cborA(s), cborA(Relative(s)), EncodePacked(s, nil)
		b.Run(sh.name+"/A_designCBOR", func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				var d DesignState
				if err := model.CBORUnmarshal(a, &d); err != nil {
					b.Fatal(err)
				}
			}
		})
		b.Run(sh.name+"/B_cborRelative", func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				var d DesignState
				if err := model.CBORUnmarshal(br, &d); err != nil {
					b.Fatal(err)
				}
			}
		})
		b.Run(sh.name+"/C_packed", func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				if _, err := DecodePacked(c); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}

var fwPool = sync.Pool{New: func() any { w, _ := flate.NewWriter(io.Discard, flate.BestSpeed); return w }}

func BenchmarkCompress(b *testing.B) {
	s := Build(shapes[0].p)
	for _, in := range []struct {
		n string
		b []byte
	}{{"A", cborA(s)}, {"C", EncodePacked(s, nil)}} {
		for _, lvl := range []int{1, 6} {
			b.Run(fmt.Sprintf("%s/fresh/level%d", in.n, lvl), func(b *testing.B) {
				b.ReportAllocs()
				b.SetBytes(int64(len(in.b)))
				for b.Loop() {
					deflate(in.b, lvl)
				}
			})
		}
		b.Run(in.n+"/pooledReset/level1", func(b *testing.B) {
			b.ReportAllocs()
			b.SetBytes(int64(len(in.b)))
			var out bytes.Buffer
			for b.Loop() {
				out.Reset()
				fw := fwPool.Get().(*flate.Writer)
				fw.Reset(&out)
				fw.Write(in.b)
				fw.Close()
				fwPool.Put(fw)
			}
		})
		z := deflate(in.b, 6)
		b.Run(in.n+"/inflate/fresh", func(b *testing.B) {
			b.ReportAllocs()
			for b.Loop() {
				io.ReadAll(flate.NewReader(bytes.NewReader(z)))
			}
		})
		b.Run(in.n+"/inflate/reused", func(b *testing.B) {
			b.ReportAllocs()
			fr := flate.NewReader(nil)
			var out bytes.Buffer
			br := bytes.NewReader(z)
			for b.Loop() {
				br.Reset(z)
				fr.(flate.Resetter).Reset(br, nil)
				out.Reset()
				out.ReadFrom(fr)
			}
		})
	}
}

// Batch: one fetch of 700 readings in the adapter's JSON (design section 7,
// event service section 3.1 ~66 B/reading) decoded with UseNumber.
type jr struct {
	S string      `json:"s"`
	T int64       `json:"t"`
	V json.Number `json:"v"`
}
type jb struct {
	ID string `json:"id"`
	O  int64  `json:"o"`
	Sr string `json:"src"`
	R  []jr   `json:"r"`
}

func batch() []byte {
	s := Build(shapes[0].p)
	bt := jb{ID: "log-0000000123", O: s.Header.Completeness, Sr: s.Sensors.Sources[0]}
	for i, n := range s.Sensors.Names {
		bt.R = append(bt.R, jr{n, s.Shared.Last[i], s.Shared.Value[i]})
	}
	out, _ := json.Marshal(bt)
	return out
}

func BenchmarkBatchJSONDecode(b *testing.B) {
	raw := batch()
	b.ReportAllocs()
	b.ReportMetric(float64(len(raw))/700, "bytes/reading")
	for b.Loop() {
		d := json.NewDecoder(bytes.NewReader(raw))
		d.UseNumber()
		var v jb
		if err := d.Decode(&v); err != nil {
			b.Fatal(err)
		}
	}
	b.ReportMetric(float64(len(raw)), "bytes/batch")
}

// Identity lookup (section 6.4 "a few tens of ns"): struct key vs joined string.
type sid struct{ name, src, grp string }

func BenchmarkIdentityLookup(b *testing.B) {
	s := Build(shapes[0].p)
	m := map[sid]uint16{}
	for i, n := range s.Sensors.Names {
		m[sid{n, s.Sensors.Sources[0], ""}] = uint16(i)
	}
	b.ReportAllocs()
	var hit int
	i := 0
	for b.Loop() {
		n := s.Sensors.Names[i%700]
		if _, ok := m[sid{n, s.Sensors.Sources[0], ""}]; ok {
			hit++
		}
		i++
	}
}
