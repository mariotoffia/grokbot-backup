# Code review: PR #1282 (draft), head b7cc2757, base main a606d9df

Reviewer: code-reviewer. Read-only: temporary worktree /tmp/w1282, now removed. Floci evidence only; no AWS touched.

## Verdict: APPROVED conditional on CI

Unit Tests, Build, Static Analysis and Architecture show `skipping` because the PR is a draft. They must run green once it is marked ready.

## Scope check

**(a) objectExpirationDays bound:** correct and coherent.
- Schema (`manifest/provision-schema.json:21-27`): `integer`, minimum 1, maximum 2147483647.
- `LoadFromYAML` → `runSchemaValidation` rejects violations loudly. Every operator path goes through it.
- Stack fallback (`deployment/stack.go:266-273`): uses the value only when it is a whole number from 1 to MaxInt32, otherwise 90.
- The fallback is defence in depth. It is reachable only when a `product.Definition` is built without the validating loader, for example in tests. So bad operator input is rejected loudly, not silently replaced with 90.

| Boundary | Schema | Stack |
|---|---|---|
| missing | accepted (default) | 90 |
| 0 | rejected (minimum) | 90 |
| 1 | accepted | 1 |
| max (2147483647) | accepted | max |
| max+1 | rejected | 90 |
| negative | rejected | 90 |
| fraction | rejected (`integer`) | 90 |
| 1e20 | rejected | 90 |

**(b) Unwrap test (`ingestioncore/serialization_test.go:134-137`):** pins that the direct cause is `*json.UnmarshalTypeError` and not the `dsmodel` error that holds the whole record. The author's mutation logs show it is red without the fix (`gates/red-unwrap-mutation*.log`).

**(c) Makefile lint (`Makefile:11-18`):** now also runs `golangci-lint run --build-tags=e2e ./$(MODULE)/deployment/service-test/...`. The red probe log shows the lint caught 1 `unused` issue before the fix. L-1 from #1275 is resolved.

**(d) Docs:**
- `ARCHITECTURE.md`: settings text, the 2803 constant name and the Logging text now match the code. I checked `errorcodes/codes.go:7` and `serialization.go` ToDsBuilding: the cause is unwrapped and both previews are capped at 200 bytes.
- Removing the Open points is accurate: the `ExtractSensorComponents` comment now lists 2800/2801, the schema allows settings, and `make lint` exists.
- `LINT.md` "Make targets" matches the Makefile.

## Gates (re-run by me in /tmp/w1282)

| Gate | Result |
|---|---|
| gofmt -l (touched .go) | clean |
| go vet (ingestionsvc, deployment, service-test with `-tags=e2e`) | clean |
| go test ingestionsvc/... and deployment module | ok |
| `TestLoadFromYAML_IngestionObjectExpirationDays` | PASS |
| `make lint` (3 golangci-lint runs) | 0 issues |
| `make lint-arch` (go-arch-lint) | OK, no warnings |

Author gate logs in `gates/`:
- Floci ingestion-service harness PASS (rc=0, 178s, undeploy run).
- markdownlint: 0 issues.
- Red logs for schema, stack, unwrap and lint.
- cspell was not run (npx package missing); see I-3.
- Only Go and Markdown files are touched.

## Findings

1. **L-1: the stack fallback is silent.** `go-services/ingestionsvc/deployment/stack.go:266-273`
   - An out-of-range value that bypassed the schema becomes 90 with no trace.
   - Fix: log a synth-time warning (or `fmt.Fprintf(os.Stderr, …)`) naming the rejected value, so a bypassed validation is visible.
   - Not blocking: no operator path bypasses the schema.
2. **L-2: the schema reject table has no tests for 0 or a fraction.** `deployment/lib/infrastructure/config/yaml_loader_ingestion_settings_test.go:36-41`
   - The stack table covers both, but the schema side (the loud path) only tests -1, a quoted value, max+1 and 1e20.
   - Fix: add `{"rejects zero", "0"}` and `{"rejects a fraction", "1.5"}` to pin `minimum: 1` and `type: integer`.
3. **I-1:** the tests exercise TEOS behaviour: the loader/schema, the stack helper, ToDsBuilding and the Makefile lint. Floci is used only as the harness backend, and no test asserts Floci behaviour.
4. **I-2:** no box-specific adaptations in the diff: no /workspace, /home/box, /tmp or Floci paths. No W-/T- IDs or plan IDs in the PR title, commit subjects/bodies or added comments.
5. **I-3:** cspell was not run by the author. Run it in CI or locally on `ARCHITECTURE.md`/`LINT.md` before ready.

## CI (`gh pr checks 1282 -R Thiink-LLC/teos`)

- Pass: CodeQL, Analyze (actions), Analyze (javascript-typescript).
- Skipping (draft): Unit Tests, Architecture, Build, Static Analysis.

## Final — 9240c016

**Verdict: APPROVED.** This verdict does not depend on Build: Build is not required, and nothing it covers is left untested.

Head checked with `gh pr view` (headRefOid 9240c0161d15) and `gh pr checks`. Passing: Architecture, Static Analysis, Unit Tests, CodeQL, Analyze (actions) and Analyze (javascript-typescript). Skipped: Build (it needs the `build` label) and Bugbot.

Delta b7cc2757..9240c016 has two commits. Neither subject contains a W-/T- ID.
- 3db4c316 "Warn when objectExpirationDays falls back to the default"
- 9240c016 "Describe the warn log preview as a size bound"

Gates were run in /tmp/w1282:
- gofmt: clean.
- go vet: ingestionsvc/deployment and deployment/lib/infrastructure/config.
- go test: ingestionsvc/... ok, ingestionsvc/deployment ok (13/13 TestObjectExpirationDaysFrom subtests), config IngestionObjectExpiration 11/11 ok.
- `make lint`: 3 runs with 0 issues, including e2e. `lint-arch`: OK.
- go build: ingestionsvc/deployment and deployment/lib.

Findings:
1. L-1 resolved. `objectExpirationDaysFrom(cfg, warn io.Writer)` (stack.go:273-298) handles each input as follows:
   - It returns silently when the config is nil or the key is absent, and when the value is valid.
   - Only a value that is present and invalid writes `WARNING: services.ingestion.settings.objectExpirationDays <%#v> (<%T>) … using the default of 90 days`.
   - The value is cut to 200 bytes. It is a provisioning number, so no secret is involved.
   - The call site passes os.Stderr. That matches the synth-time stderr convention in the other deployment mains (for example collectorsvc/deployment/main.go:25). The stack has no logger.
   - Red check: I sent the warning to io.Discard locally, in the temp tree only. 8 FAIL lines appeared (7 warn rows plus the parent test), then I restored the file. The new rows fail without the fix.
2. L-2 withdrawn. Zero and 1.5 were already tested as separate t.Run cases further down the file, so my earlier finding was wrong. The delta moves them into the table, with no loss of coverage.
3. I. A YAML `objectExpirationDays: null` would warn `<nil> (<nil>)` and fall back. The schema rejects null first, so this is harmless. No change needed.
4. I. The ARCHITECTURE.md wording now correctly says the 200-byte preview bounds the size of a warning but does not keep payload out of it.
5. I. I did not see the TR-1 row in the code delta. It is presumably in the test-review doc, outside the PR diff.
6. I. cspell was not run: the box has Node 20.19.2 and cspell@10.4.0 needs ≥22.18. The Dev Lead's clean result stands unverified by me.

Build:
- build.yml runs `make build` (meta, web bundles, deployment/lib).
- On a PR it runs only with the `build` label. It always runs on a push to main.
- It does no docker build or cdk synth of this stack. The changed Go is compiled by Unit Tests and by my local go build.
- Branch protection has no required status checks: contexts and checks are both []. The rulesets only cover Copilot review.
- I found no CONVENTIONS.md rule that requires the label.
- Recommendation: no label or re-run is needed. Build will run on the merge push to main.
