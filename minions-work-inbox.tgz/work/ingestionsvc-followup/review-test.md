== Verdict ==
APPROVED

== Findings ==
1. [Low] [testable] go-services/ingestionsvc/deployment/stack_expiration_test.go:23-33 — no stack-level case where the value has a non-float64 type (string "30", or int 30 from a hand-built map). Today the type assertion makes these fall back to 90, but no test pins that. Fix: add {"string falls back", Settings{"objectExpirationDays": "30"}, 90}.
2. [Info] [testable] gates/red-unwrap.log — this log is GREEN ("ok"), not red. That matches the PR's claim: the test was written after the code and was already green on main. The genuine red evidence is red-unwrap-mutation*.log, and I reproduced it (M10, M11). No fix needed.
3. [Info] [non-testable] go-services/ingestionsvc/deployment/service-test/ingestion_test.go:42 — TestIngestionServiceFlow checks TEOS's pipeline outcome (shadow -> rule -> S3 -> storeloader, :173-176). It does not check the bucket lifecycle Days, which is fine: the unit tests own that. I did not re-run it; I relied on gates/integration-ingestion-service-b7cc2757.log (ok, rc=0, Floci, eu-west-1).
4. [Info] [testable] deployment/lib/infrastructure/config/yaml_loader_ingestion_settings_test.go:53-85 — the zero and fraction rejections are separate t.Run blocks inherited from #1275, not rows in the new reject table at :36-41. This is a style inconsistency only. Fix (optional): fold them into the table.

== Rationale ==
Checked a git archive of b7cc2757 under /tmp. The diff touches stack.go (range + Trunc guard), provision-schema.json (maximum), and three test files. Issue #1281's acceptance criteria are all covered: schema max + tests, stack fallback, errors.Unwrap check, and the e2e lint target (gates/make-lint rc=0).

Red logs: red-stack.log fails zero, negative, fraction, past-max and far-past-max on expected 90 vs actual (correct reason). red-schema.log fails "rejects one/far past the maximum" with "error expected but got nil" (correct). red-unwrap-mutation{,2}.log fail with "got *cberror.CbError" (correct). red-lint-service-test.log shows errorlint rejecting a type assertion on an error, which is why the test uses assert.IsType (a genuine L-1 probe). red-unwrap.log is green (see finding 2).

Runs (AWS_PROFILE=devlocal, eu-west-1; nothing touched AWS):
- go test -count=5 -race ingestionsvc/deployment -run TestObjectExpirationDaysFrom: ok
- go test -count=5 -race ingestionsvc/ingestioncore: ok
- go test -count=5 -race deployment/lib/infrastructure/config: ok
- golangci-lint run ./go-services/ingestionsvc/... and ./deployment/lib/infrastructure/config/...: 0 issues
- There is no t.Parallel, time, rand or map-order dependence in the touched tests. Tables are slices, and each test writes its own temp YAML via writeTempYAML. No unit test needs Floci (the YAML fixture's baseDomain "localhost.floci.io" is only a string value).

Mutant table (all killed):
| # | Mutation | Killed by |
|---|---|---|
| M1 | stack: drop the whole range/Trunc guard | zero/negative/fraction/past-max/far-past-max falls back |
| M2 | stack: drop v==Trunc(v) | fraction falls back |
| M3 | stack: drop v<=MaxInt32 | past-max, far-past-max |
| M4 | stack: v>=0 | zero falls back |
| M5 | stack: v<MaxInt32 | maximum used |
| M6 | schema: delete "maximum" | rejects one/far past the maximum |
| M7 | schema: maximum 2147483646 | accepts the maximum |
| M8 | schema: minimum 0 | rejects zero |
| M9 | schema: type number | rejects a fraction |
| M10 | serialization: wrap the whole dsmodel err | IsType Unwrap (got *cberror.CbError) |
| M11 | serialization: extra fmt.Errorf %w layer | IsType Unwrap (got *fmt.wrapError) |

Boundary matrix (S = stack_expiration_test.go, Y = yaml_loader_ingestion_settings_test.go):
| value | stack | YAML/schema |
|---|---|---|
| missing | S:25 (also nil cfg :23, no settings :24) | Y:21 |
| 0 | S:29 | Y:65 |
| 1 | S:27 | Y:20 |
| 2147483647 | S:28 | Y:22 |
| 2147483648 | S:32 | Y:39 |
| negative | S:30 (-5) | Y:37 (-1) |
| float 1.5 | S:31 | Y:75 |
| string | MISSING (finding 1) | Y:38 ("30") |
| huge 1e20 | S:33 | Y:40 (99999999999999999999) |
