Closes #1281

Follow-up batch held back when #1275 merged.

- **Schema and stack:** `services.ingestion.settings.objectExpirationDays` gets `"maximum": 2147483647` (the range of the S3 lifecycle Days type, not a business limit). `objectExpirationDaysFrom` falls back to the 90-day default for any value that is not a whole number from 1 to MaxInt32, so `int(1e20)` can no longer become a negative lifecycle duration. Tests cover the max, one past it, `99999999999999999999`, 0, negative, fraction and `1e20`.
- **Decode cause:** `TestToDsBuildingDecodeFailureWrapsJSONCause` also checks that `errors.Unwrap(err)` is the `*json.UnmarshalTypeError` itself (kills the "wrap the whole dsmodel error" mutant).
- **Docs:** ARCHITECTURE.md drops the Open points fixed in #1275 (2803 text, ExtractSensorComponents comment, settings schema, lint target), rewrites the Logging bullet to "inner error and payload preview each capped at 200 bytes", documents the expiration range and fixes the 2803 constant name (`ErrorNilValueNotAllowed`). LINT.md replaces the stale "no lint target" Known gap with a Make targets section.
- **Lint:** `make lint` also runs `golangci-lint --build-tags=e2e` on `deployment/service-test` (own module). A probe unused func there is caught by the new target and missed by the old targets.

Interpretation: the reviewer offered "schema maximum or clamp/reject in the stack"; this does both (schema rejects, stack falls back defensively). Unit tests only; no Floci-only tests, no real AWS.

Status: /workspace/minions/work/ingestionsvc-followup/STATUS.md

Gates at b7cc2757 (local): `make lint` 0 issues (all three modules) + lint-arch OK; go vet green (service, deployment, service-test -tags e2e, deployment config); unit tests green (-race); ingestion-service harness against local Floci (`mariotoffia/floci:latest`) PASS. markdownlint clean. Spell check: see the note below.

**Spell check:** cspell@10.4.0 (repo config) on all 7 changed files: no findings on changed lines; the only unknown words are existing import aliases in `deployment/stack.go` and the `ingestioncore` package name.

<!-- CURSOR_SUMMARY -->
---

> [!NOTE]
> **Low Risk**
> Changes are provision validation, defensive CDK synth defaults, lint coverage, and tests/docs; no runtime transform or auth paths.
> 
> **Overview**
> Tightens **`services.ingestion.settings.objectExpirationDays`** end-to-end: the provision schema now caps the value at **2147483647** (S3 lifecycle `Days` / `MaxInt32`), YAML loader tests accept that max and reject 0, fractions, and values past the bound, and **`objectExpirationDaysFrom`** only applies whole numbers in **1…MaxInt32**—anything else falls back to **90 days** with a **stderr** warning whose rejected value preview is capped at **200 bytes** (so huge floats cannot produce invalid lifecycle rules).
> 
> **`make lint`** for ingestionsvc also runs **`golangci-lint --build-tags=e2e`** on **`deployment/service-test`**. Docs (**ARCHITECTURE.md**, **LINT.md**) drop resolved open points, document the expiration range and logging bounds, and fix the **2803** constant name in prose. **`TestToDsBuildingDecodeFailureWrapsJSONCause`** now asserts the direct unwrap is **`*json.UnmarshalTypeError`** (not a wrapper around the full-record dsmodel error).
> 
> <sup>Reviewed by [Cursor Bugbot](https://cursor.com/bugbot) for commit 9240c0161d152ab0caa7e6e02d84e55da56cd367. Bugbot is set up for automated code reviews on this repo. Configure [here](https://www.cursor.com/dashboard/bugbot).</sup>
<!-- /CURSOR_SUMMARY -->
