#!/bin/sh
cd /workspace/repos/teos/.worktrees/clean-caches-guard || exit 1
G=/workspace/minions/work/clean-caches-guard/gates/load; rm -f $G/*
hp=""; for i in $(seq "$(nproc)"); do yes >/dev/null & hp="$hp $!"; done
for r in 1 2 3 4; do
  pids=""
  for j in 1 2 3 4; do sh=dash; [ $((j%2)) = 0 ] && sh=bash
    ( s=$(date +%s); timeout 200 $sh scripts/clean-caches-guard/clean-caches-guard_test.sh > $G/r$r-$j-$sh.log 2>&1; echo "$sh rc=$? $(( $(date +%s)-s ))" > $G/r$r-$j-$sh.res ) & pids="$pids $!"
  done
  wait $pids
done
kill $hp
