bash rc=0 69
