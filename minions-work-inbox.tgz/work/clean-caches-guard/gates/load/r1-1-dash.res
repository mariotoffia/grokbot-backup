dash rc=0 69
