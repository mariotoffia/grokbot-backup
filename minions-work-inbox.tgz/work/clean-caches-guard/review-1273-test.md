# Test review: PR #1273 @4730262e (scripts/clean-caches-guard)

== Verdict == CHANGES_REQUESTED

== Findings ==
[High] [testable] scripts/clean-caches-guard/clean-caches-guard.sh:23-27 — Fails open: if CLEAN_GUARD_PS_FILE is missing or unreadable, or `ps` fails, `list` is empty and the guard exits 0, so the clean goes ahead (checked: CLEAN_GUARD_PS_FILE=/nonexistent prints a cat error and exits 0). No test covers this. Fix: exit with a distinct non-zero code (e.g. 2) when cat/ps fails, and add a test case "missing fixture -> non-zero".
[Medium] [testable] scripts/clean-caches-guard/clean-caches-guard_test.sh:94-96 — The real-ps check is almost vacuous. The guard's own command line ("sh .../clean-caches-guard.sh") never matches PATTERN, so `absent "clean-caches-guard.sh"` passes even when self/ancestor exclusion is broken. It is deterministic and safe on any host (read-only ps, `|| true`), but it proves little. Fix: also assert the exit status is 0 or 1 (never 2 or a crash). Or run the guard as `sh -c 'exec sh "$SCRIPT"' go test` (argv contains the pattern) so self-exclusion is actually exercised against real ps.
[Medium] [testable] scripts/clean-caches-guard/clean-caches-guard_test.sh:40-62 — Fixtures don't cover macOS shapes: wide PIDs (5-6 digits) with different padding, paths containing spaces ("/Applications/Visual Studio Code.app/..."), tab separators, or a line with only PID PPID and no args (NF<3). Fix: add a macOS-style fixture with these cases.
[Medium] [testable] scripts/clean-caches-guard/clean-caches-guard.sh:21 — PATTERN is an unanchored substring match, so `cdk`/`floci`/`go run` match unrelated args. Checked: "vim /home/u/cdk-notes.md" blocks the clean. No negative test pins the false-positive behaviour. Fix: tighten the pattern (word boundaries / command basename) and add negative fixtures (cdk-notes.md, "grep golangci", an editor with "go test" in its args).
[Low] [testable] scripts/clean-caches-guard/clean-caches-guard_test.sh:25 — `run` passes extra vars, but FORCE from the caller's env leaks into the non-FORCE cases: `env` inherits it. With FORCE=1 exported (e.g. `make test FORCE=1`), "match: exits non-zero" fails. Fix: use `env -u FORCE` in run (and `-u CLEAN_GUARD_*` at line 95 is already done).
[Low] [non-testable] scripts/clean-caches-guard/clean-caches-guard_test.sh:11 — `set -u` only, not `set -euo pipefail`. The script is POSIX sh (pipefail is not portable there), and per-case status capture needs no -e. Acceptable; the trap on EXIT cleans $WORK correctly. Naming, PASS/FAIL lines, the final "FAIL clean-caches-guard: N failed" plus exit 1 (picked up by the Makefile `^FAIL\s` grep) are good.
[Info] [non-testable] .github/workflows/build.yml:8,86 — Wired into `make test` (Makefile:297-298, the unit-test target), which CI runs via `make test SHELL=/bin/bash`. No path filter on build.yml, but on PRs the unit-test job is label-gated (`unit-test` label per the header comment) and always runs on push to main. Both files are mode 100755.

== Rationale ==
The tests call the real guard script (sh "$SCRIPT"), not a reimplementation. All fixture cases are deterministic, with no timing or sleeps. The guard only reads ps and never signals or kills anything (no kill/pkill anywhere), so the real-ps case is safe. Coverage of match, no-match, FORCE=1/0 and ancestor self-exclusion is good. Blocking: the guard fails open when the process source can't be read, with no test, which undermines the safety purpose. The real-ps case doesn't really test self-exclusion. macOS-shaped fixtures and false-positive negatives are missing.

Local run (fixture copy via git archive into /tmp/ccg, repo untouched): 19 PASS, "ok   clean-caches-guard", exit 0.

== Delta 1 (4730262e..4bf68929) ==

== Verdict == APPROVED

== Findings ==
Previous findings, checked again:
- [High] fail-open (guard.sh:23-27): FIXED. guard.sh:31-44 now exits 2 for an unreadable or missing fixture, a ps failure, an empty list, or an awk failure. Manual probe: CLEAN_GUARD_PS_FILE=/nonexistent -> exit 2, "nothing deleted". Tests cover a missing fixture, an empty fixture, a fake failing ps on PATH, and FORCE=1 not overriding a failed read (all exit 2). Mutation: removing `|| unreadable "ps failed"` is still caught, because the empty-list check also exits 2 (defence in depth).
- [Medium] vacuous self-exclusion: FIXED. The new `self` fixture gives the guard and every ancestor/child commands that match, plus one unrelated run (700) that must be listed. Mutations on the /tmp copy: removing the skip (`pid in skip || ppid==self`) -> 5 FAIL; removing the ancestor walk's `skip[p]=1` -> 3 FAIL (parent, grandparent, top ancestor); removing the `ppid==self` child skip -> 1 FAIL (child). The real-ps case now also asserts exit 0|1. It still doesn't exercise self-exclusion against real ps, but that's acceptable now that the fixture case is mutation-proven.
- [Medium] macOS shapes: FIXED. The fixture covers wide padded PIDs, tab separators, spaces in paths, a PID/PPID-only line, and /opt/homebrew.
- [Medium] substring false positives: FIXED. Matching is now by program basename/subcommand. The `noise` fixture (vim floci.go, cdk-notes, grep golangci, code --goto "go test", go version, docker ps, ...) exits 0. Manual probe: `vim /home/u/cdk-notes.md` -> exit 0.
- [Low] FORCE env leak: FIXED. `env -u FORCE` is in run() and the real-ps call.

New findings:
[Low] [testable] scripts/clean-caches-guard/clean-caches-guard.sh:51-58 — False negatives: the guard misses some real runs and lets the clean go ahead. Probed: `npx aws-cdk@2 deploy` (version suffix), `node -r ts-node/register node_modules/.bin/cdk synth` (the value of a flag is treated as the script), `/Users/m/My Tools/go test` (split on spaces, base = "My"), `go -C sub test` — none blocked. Only `pnpm exec cdk deploy` blocked. Fix: strip `@version` before comparing, skip the values of known flags (-r/--require), allow `go` flags before the subcommand; add these as positive fixtures. Not blocking: these are uncommon invocations, and the guard is a convenience check.
[Info] [non-testable] clean-caches-guard_test.sh real-ps case — on the box it returned exit 1 (other agents' runs were active). The case accepts 0|1, so it stays host-independent.

== Rationale ==
Every earlier finding is fixed and backed by tests. Mutation testing shows the self-exclusion and fail-closed checks catch regressions. The guard is still read-only (no kill/signal), and no new determinism or env-leak problems came in. The remaining gaps are minor false negatives in launcher parsing.
Local run (git archive 4bf68929 -> /tmp/ccg2, repo untouched): 36 PASS, "ok   clean-caches-guard", exit 0.

== Delta 2 (4bf68929..c0636181) ==

== Verdict == CHANGES_REQUESTED

== Findings ==
Previous Low (false negatives), checked again: FIXED. Probes: `npx aws-cdk@2 deploy`, `node -r ts-node/register node_modules/.bin/cdk synth`, `/Users/m/My Tools/go test ./...`, `go -C sub test ./...` all exit 1. Extra positives also block: `npx -p aws-cdk@2 cdk deploy`, `npm exec -- cdk deploy`, `yarn cdk deploy`.
Earlier regressions checked: `vim /home/u/cdk-notes.md`, `go version`, `go env GOPATH`, `node server.js`, `npm run build` all exit 0.

[Medium] [testable] scripts/clean-caches-guard/clean-caches-guard.sh:83-88 (prog_end) — New false positives from the path-with-spaces heuristic. Any absolute program followed by a capitalised relative path argument is merged into one "program" path. Probed (each exits 1 and blocks the clean): `/bin/cat Docs/cdk`, `/usr/bin/vim Projects/teos/cdk`, `/usr/bin/less Notes/go test`, `/usr/bin/tail Logs/floci.log`. The near-miss fixtures only use lower-case or ./ args (`/bin/sh src/cdk`, `/usr/bin/vim ./cdk`), so this goes untested. The failure is fail-safe (it blocks and FORCE=1 overrides), but it brings back the false-positive class that Delta 1 fixed. Fix: only merge words when a[1] is under a user/app root where spaces occur (e.g. /Users/, /Applications/, /Volumes/, /home/), not when a[1] is in a */bin/ or */sbin/ directory. Or merge only when the merged base is a known tool AND a[1] itself is not a */bin/<name> executable. Add the four probes above as near-miss fixtures.
[Low] [non-testable] scripts/clean-caches-guard/clean-caches-guard.sh:11-14 — Lower-case folders with spaces (`/Users/x/my tools/go test`) still go undetected (exit 0). This is documented ("macOS folder names usually are") and acceptable. Optionally pin it as a known-limitation fixture.
[Low] [hard-to-test] scripts/clean-caches-guard/clean-caches-guard.sh:56-62 — The takes_value lists are hand-maintained: `node --inspect-port 9229 cdk` → exit 0 (missed). Fine as a best-effort; keep it documented.
[Info] [non-testable] Ran only with mawk 1.3.4 (box awk). macOS uses BSD one-true-awk, which was not available here. The awk is plain POSIX (sub, split, functions with local params), so no portability issue is visible.

Mutations on the /tmp copy (each caught):
- remove the @version strip → 3 FAIL
- remove the `go -C` skip → 1 FAIL
- remove the prog_end merge loop → 3 FAIL
- disable the node -e/--eval/-p exit → 1 FAIL
- drop `-r` from takes_value → 1 FAIL

== Rationale ==
The requested false negatives are fixed. The new rules are each covered by tests that fail when the rule is removed, and the suite passes under both dash and bash. However, the prog_end heuristic creates a new, easy-to-hit false-positive class (capitalised relative paths after any absolute program, common on macOS: Documents/, Projects/, Logs/), and no fixture covers it. Narrowing it and adding the four negatives is a small change.

Test run (git archive c0636181 → /tmp/ccg3, repo untouched): dash 54 PASS / 0 FAIL, exit 0; bash 54 PASS / 0 FAIL, exit 0 ("ok   clean-caches-guard").

== Delta 3 (c0636181..43bc9456) ==

== Verdict == APPROVED

== Findings ==
Delta 2 Medium (prog_end false positives): FIXED. All 4 probes (`/bin/cat Docs/cdk`, `/usr/bin/vim Projects/teos/cdk`, `/usr/bin/less Notes/go test`, `/usr/bin/tail Logs/floci.log`) exit 0 and are now fixtures, plus `/home/u/bin/vim Notes/go test`.
Positives still block (exit 1): `/Users/m/My Tools/go test`, `npx aws-cdk@2 deploy`, `node -r ts-node/register …/cdk synth`, `go -C sub test`, `/home/u/My Docs/cdk deploy`, `/home/u/.local/bin/cdk deploy`, `/Volumes/Ext Disk/Tools/cdk deploy`, `/usr/local/bin/cdk deploy`, `/home/u/go/bin/golangci-lint run`.
Regressions checked (exit 0): `vim /home/u/cdk-notes.md`, `go version`, `go env GOPATH`, `node server.js`, `npm run build`, `/Users/m/bin/less Notes/cdk`, `/Users/m/.local/bin/vim Docs/cdk`, `/opt/homebrew/bin/vim Docs/cdk`, `/Applications/Visual Studio Code.app/... Electron Docs/cdk`.

[Low] [testable] scripts/clean-caches-guard/clean-caches-guard.sh (prog_end root check `^/(Users|Applications|Volumes|home)/`) — Mutation: widening the root check to any absolute path SURVIVES. Every near-miss fixture is in a bin folder, so the bin/sbin check alone rejects them. Fix: add a near-miss under a non-user, non-bin root, e.g. `/opt/tools/vim Docs/cdk` or `/usr/libexec/vim Docs/cdk` → want 0.
[Low] [non-testable] clean-caches-guard.sh:83-84 — Documented known limit: `/Users/m/Apps/vim Docs/cdk` exits 1 (blocks; FORCE=1 overrides). Acceptable on the safe side.

Mutations on the /tmp copy:
- remove the bin/sbin exclusion → 1 FAIL (home bin fixture)
- drop Users from the root list → 3 FAIL
- widen the root to any absolute path → survives (see Low)

== Rationale ==
The regression is fixed with targeted fixtures, nothing earlier regressed, and the remaining gaps are low-severity test hardening.
Test run (git archive 43bc9456 → /tmp/ccg4, repo untouched): dash 59/59 PASS exit 0; bash 59/59 PASS exit 0.
