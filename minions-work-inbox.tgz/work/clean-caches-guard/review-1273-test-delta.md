# PR 1273 test review — delta 43bc9456..bb2502ac

== Verdict ==
APPROVED

== Findings ==
[Low] [testable] scripts/clean-caches-guard/clean-caches-guard.sh:156-157 — the container awk pipeline has no `|| unreadable`. Every other step fails closed (ps, PS file, the main awk at :144, docker ps), but if this awk errors, $floci is empty and running Floci containers are silently ignored, so the guard fails open. Seen in mutation: a broken awk program made the "running Floci container" test return 0. Fix: `floci=$(... | awk '...') || unreadable "awk failed"`. A fault-injection test (an awk stub that exits 1) would cover it.
[Low] [hard-to-test] clean-caches-guard.sh:149 — any `docker info` failure is treated as "Docker not running, so no containers". That includes a permission-denied socket or a broken context (and in those cases docker ps would fail too), so they fail open rather than closed. A wedged daemon can also make `docker info` hang, since there is no timeout. Fix (optional): treat only "Cannot connect to the Docker daemon"/"Is the docker daemon running" as down and call unreadable for any other error, or add a short timeout.
[Low] [testable] clean-caches-guard.sh java rule / prog_end launcher join — two known false positives, both on the safe side:
  - `java -jar /opt/app/app.jar floci`: any argument whose basename starts with floci blocks.
  - `node /Users/x/My Tools/app.js Notes/cdk` blocks, because the spaced-path join swallows a following capitalised relative argument. This is the same documented limit as the earlier `/Users/m/Apps/vim Docs/cdk` case.
  Both only over-block. Fix: optional; document them.
[Info] Earlier optional Low not addressed: there is still no negative fixture outside bin directories such as `/opt/tools/vim Docs/cdk`. Manual probes return 0 for `/opt/tools/vim Docs/cdk`, `/usr/libexec/vim Docs/cdk` and `/bin/cat Docs/cdk`, but widening the root check would still not be caught by a test.

== Rationale ==
Test run: I ran the tests on a git archive of bb2502ac in /tmp/ccg5, with `docker` on PATH shadowed by a tripwire stub that only logs calls. Results: dash 71/71 and bash 71/71, both exit 0. The tripwire logged no calls, so the suite never touches real Docker.

Real-ps test: it passes CLEAN_GUARD_DOCKER_FILE pointing at an empty fixture, so the docker branch is skipped and the result does not depend on the host. The two docker-stub tests prepend a PATH stub, and every `run`/`one` call injects the empty docker fixture.

-ww: the ps stub writes its argv to a file and the test greps it for `-ww`. Removing -ww from the script is killed ("ps gets -ww").

Docker semantics:
- `docker ps` failing while the daemon is up gives exit 2 (fail closed). This is correct.
- Docker down counts as no containers (exit 0). This is correct: no container can be running.
- The one weakness is that "down" is inferred from any `docker info` failure (Low above).
- An unreadable docker fixture gives exit 2.
- A container with no lifecycle label (NF=2) blocks, and one labelled retained does not.

Mutation results (all killed; tripwire stayed clean):
- Swallowing the docker ps failure: killed by "docker ps failing exits 2".
- Dropping the retained filter (`$3 != "retained"` → 1): killed by "retained does not block".
- `NF >= 2` → `NF >= 3`: killed by the running-container tests.
- Dropping the `docker info` gate: killed by "docker not running means no containers".
- Launcher without the prog_end join: killed by both spaced-path positives.
- Disabling the java rule: killed by "lists 710 java".
- Dropping -ww: killed.

The negative launcher fixture (`node /usr/lib/app.js Notes/cdk`) passes.

All the new behaviour is covered and verified to fail when broken. The remaining items are Low and optional, so this is APPROVED.

== Re-review (bb2502ac..0d90310c) ==

== Verdict ==
APPROVED

== Findings ==
[Low] [testable] scripts/clean-caches-guard/clean-caches-guard.sh:164 — no test covers the `*"connect: no such file"*` match. Deleting it passes all 75 tests. That match is the only one that recognises the newer Docker CLI wording ("failed to connect to the docker API at unix:///…/.docker/run/docker.sock; … dial unix …: connect: no such file or directory"), which is what you see on macOS when Docker Desktop is quit. If it regressed, the guard would fail safe (exit 2) but would block every clean whenever Docker Desktop is off. Fix: add a docker-stub fixture with that message that expects 0.
[Info] clean-caches-guard.sh:163 — removing the `*"Is the docker daemon running"*` match also survives. This is equivalent: the classic message contains both phrases. No action needed.
[Info] Error wording I probed with a fake docker:
  - Docker Desktop on macOS, classic wording (~/.docker/run/docker.sock): 0.
  - Newer "failed to connect to the docker API … connect: no such file": 0.
  - Colima "Cannot connect…": 0.
  - Stale socket ("connect: connection refused"): 2.
  - Windows npipe ("open //./pipe/docker_engine: The system cannot find the file specified"): 2.
  The last two fail safe and are acceptable. Matching is case-sensitive and English-only, so new wording falls into the exit-2 branch.
[Info] Still no timeout on `docker info` or `docker ps` (grep finds no timeout), so a wedged daemon can hang the guard. Noted only, as asked.
[Info] Low 3 was declined as safe-side, as agreed. The 9dcd97fe header documents the retained-container java process limit.

== Rationale ==
Test run: I ran the tests on a git archive of 0d90310c in /tmp/ccg6, with a logging fake docker first on PATH. Results: dash 75/75 and bash 75/75, both exit 0. The fake docker logged no calls during the suite or any mutation run.

Mutation results:
- Old awk-break mutant (dropping `|| unreadable "awk failed"`): now killed by "container awk failure exits 2". The awk stub fails only for the container-list program and passes everything else to the real awk.
- Making the catch-all count as "no containers": killed by the permission-denied and bad-context tests.
- Widening the daemon match to `*"Docker daemon"*` or `*"docker"*`: killed by "docker permission denied exits 2". The permission-denied message contains "Docker daemon", so this is a good discriminating fixture.
- Widening `connect: no such file` to `connect: `: killed by the permission-denied test.
- Widening the folder check to any absolute path: killed by the new `/opt/tools/vim Docs/cdk` fixture, and also by `node /usr/lib/app.js Notes/cdk`.

Lows 1, 2 and 4 are fixed and have tests. Only the untested new-CLI match remains, and it fails safe, so this is APPROVED.

== Delta (0d90310c..b42acd7d) ==

== Verdict ==
CHANGES_REQUESTED

== Findings ==
[High] [testable] scripts/clean-caches-guard/clean-caches-guard.sh docker_run (the watchdog subshell and `kill "$wpid"; wait "$wpid"`) — race on the quick path.
  When docker finishes, the guard sends TERM to the watchdog. Under CPU load or parallel runs, the watchdog sometimes never acts on it: it stays in `wait "$s"` until its sleep ends.
  What I reproduced: four guards (from the load run and parallel round 2) were stuck for about 400s. Each was a guard → watchdog subshell → `sleep 7391` chain. I killed only those sleeps, which belonged to my /tmp runs. Each watchdog then went on to write $tmp.timeout, and the guard exited 2 ("quick docker listing a container exits 1 (status 2, want 1)").
  That means the TERM was lost, not handled late. The likely cause is the window between dash's trap check and the blocking wait, or TERM arriving before the trap is installed (dash 0.5.12).
  Production impact with the default 10s: a docker call that succeeded can still stall the guard for 10s and then wrongly exit 2. Worse, kill_tree "$dpid" then runs on a PID that has already been reaped. If that PID has been reused, the watchdog kills an unrelated process and its children.
  Fix: don't rely on signalling the watchdog. Options:
  - Have the watchdog poll `kill -0 "$dpid"` once a second and exit when docker is gone, up to the timeout.
  - Or kill the sleep directly from the parent (record its PID in a file) and re-check `kill -0 "$dpid"` before kill_tree.
  Either way, never kill_tree after docker has exited.
[Medium] [testable] clean-caches-guard_test.sh no_proc() — the leftover check looks host-wide: `ps -A -o args=` plus a fixed marker ("sleep 6173/6174/7391"). It doesn't filter by its own PIDs, process group, or $WORK. Any other suite on the same host (other agents, parallel CI, a previous run that hung) causes false failures. Observed: all 4 suites in parallel round 1 failed "no watchdog sleeper left" because of each other's sleepers. Fix: put a per-run marker in the stub (for example `sleep 6173 #$$`, or exec a uniquely named copy in $WORK) and match on that, or check only descendants of the guard's PID.
[Medium] [testable] clean-caches-guard_test.sh — the suite has no outer timeout. Mutant "remove kill_tree" doesn't fail; it hangs on the 6173s stub. My 120s cap is what ended it, so the `took < 10` assertion is never reached. The race above also hung real runs for 400s+. In CI this could block the job for up to about 2h instead of failing. Fix:
  - Run each watchdog case in the background with a test-side deadline (poll for up to ~15s, then fail and clean up).
  - Use stub sleeps of about 30s, not 6173s, so a leftover expires quickly.
[Low] [testable] clean-caches-guard_test.sh — no cleanup of hung stubs if a test fails. The trap only removes $WORK, so a leaked `sleep 6173` lives about 1.7h and poisons later runs through the host-wide no_proc check. Fix: on EXIT, kill only processes whose args carry the per-run marker.
[Low] [hard-to-test] Parallel round 1 had one unexplained failure: "docker not running means no containers (status 2, want 0)", with a stub that cannot hang. This fits a stray kill_tree or TERM from another run's watchdog reaching a reused PID (the guard maps TERM to exit 2), but I couldn't confirm it.
[Info] Timing margins are generous: hung cases use a 1s timeout and assert `took < 10`, and `sleep 1` comes before no_proc. Under load, the elapsed-time assertion never failed.
[Info] Portability: POSIX sh only. It uses ps -A -o pid=,ppid=, kill, sleep N, background jobs and wait, with no GNU timeout and no setsid, so it is fine on macOS. The race above is shell-level and could also affect macOS /bin/sh (bash 3.2 in sh mode); I didn't verify that.
[Info] The 'connect: no such file' fixture was added. Deleting the match is killed by "missing docker socket means no containers".

== Rationale ==
Test runs, all on a git archive of b42acd7d in /tmp/ccg7, with a logging fake docker first on PATH (no calls logged; no real docker used):
- Serial: dash 10/10 and bash 10/10 at 90/90, about 4.6s per run (91.4s total for 20 runs).
- CPU load (16 busy loops on 8 cores, each capped with `timeout 150`) while a parallel batch ran:
  - dash: 3/5 runs passed. Run 1 hung for 430s (false exit 2 after I killed its sleeper); run 2 failed no_proc.
  - bash: 5/5 passed.
  - Passing runs took 4.52–4.64s.
- Parallel, 4 suites per round × 2 rounds: 0/8 passed.
  - Round 1: no_proc cross-talk; 6.2–16.4s.
  - Round 2: 3 of the 4 suites hung about 411s, then a false exit 2.
- Overall duration: min 4.52s, max 430s.

Mutation results:
- Removing kill_tree: the suite hangs rather than failing (Medium above).
- Breaking validation to `""|0`: killed (-1, abc).
- Breaking validation to `""` only: killed (0, -1, abc).
- Deleting the connect-no-such-file match: killed.
- Dropping `kill "$wpid"`: killed.

Cleanup: afterwards there were no leftover sleep 6173/6174/7391 processes. The only processes I killed were four sleeps whose parent chain led to my own /tmp/ccg7 suites.

The watchdog design is sound in intent and portable. However, the quick path has a reproducible signal race that wrongly fails the guard, and possibly kills a reused PID. The leftover-process checks are host-global, so the suite is flaky whenever it shares a host. Both need fixing before approval.

== Re-review (b42acd7d..c988dbab) ==

== Verdict ==
APPROVED

== Findings ==
[Low] [testable] scripts/clean-caches-guard/clean-caches-guard_test.sh within() — the per-case deadline only bounds hangs in the docker stub. On timeout it fails the case, kills the run-marked `hang` stubs, then calls `wait "$jp"` with no limit. If the hang is in the guard or watchdog itself, the case still blocks until the guard's own timeout (up to 300s for the "timeout 300 is accepted" case).
  Seen in mutation: with the polling exit removed, the cases correctly fail "finished within 15s", but the suite ran into my 300s outer cap.
  Fix: after the deadline, kill the job's process tree (or run it in its own process group with perl setpgrp, as the Ctrl-C test already does) before waiting.
[Info] clean-caches-guard.sh docker_run / kill_tree — the PID-reuse risk I raised last time is closed:
  - The guard waits on the watchdog ($wpid) before reaping docker ($dpid), so $dpid stays an unreaped child (at worst a zombie) the whole time the watchdog can act on it. Its PID can't be reused between the `ps -o ppid=` check and kill_tree.
  - The `.done`/`.stop` markers and `kill -0 $guard_pid` let the watchdog exit without relying on signals.
  - The only remaining window is theoretical: kill_tree takes a snapshot of child PIDs and kills them one level at a time. A grandchild of docker that exits and is reaped in between could have its PID reused. That's negligible for docker CLI helpers.
[Info] Leftover checks now only look at this run: hung stubs exec $WORK/dock/hang (a symlink to sleep), and marked() / no_proc match that per-run path. The deaf-sleep check matches $WORK/deaf/sleep the same way. Other agents' sleeps can no longer cause false failures (parallel runs below: 8/8).
[Info] Trade-off of polling once a second: each quick docker call can take up to 1s longer, about 2s per guard run. The suite now takes about 30.6s instead of 4.6s.
[Info] The trap cleanup can't be tested from inside the suite, but it works. With the guard's kill_tree removed and the suite stopped by `timeout --foreground 10` (TERM to the suite only):
  - Original cleanup: no leftover stub.
  - Cleanup loop removed: a `$WORK/dock/hang 30` stub was left behind (it expired on its own after 30s).
  Under plain `timeout`, which signals the whole group, the guard's on_signal also cleans up.

== Rationale ==
All runs used a git archive of c988dbab in /tmp/ccg8, with a logging fake docker first on PATH (no calls logged; no real docker), each suite capped with `timeout 300`:

| Condition | dash | bash | Duration |
|---|---|---|---|
| Serial ×10 per shell | 10/10 (101/101) | 10/10 | 30.55–30.68s |
| 16 busy loops on 8 cores (`timeout 420`/`360`), serial ×5 per shell | 5/5 | 5/5 | 32.0–33.0s |
| 4 suites in parallel × 2 rounds per shell, overlapping the load | 8/8 | 8/8 | 32.1–32.5s |

- Overall: 46/46 runs passed; min 30.55s, max 33.00s; no timeouts, no hangs.
- The first load loop stopped after 4 dash runs when my shell session ended (not a hang). I re-ran the 5th dash run and the 5 bash runs under fresh load.
- No leftover hang stubs at any point.

This matches their gates/load evidence: 16 .res files, all rc=0 (8 dash, 8 bash), with logs ending "ok clean-caches-guard". Last round's failures (cross-talk, about 410s hangs, false exit 2) did not reproduce.

Mutation results (one change each unless noted):
- Removing the polling exit: killed ("finished within 15s", "returns quickly", "not stalled by the sleep"), but the suite was slow to finish (Low above).
- Removing the watchdog's kill_tree: killed in 70s (the hung-docker cases fail their deadline; Ctrl-C test fails).
- Removing kill_tree and the per-case deadline together: the hung-docker cases pass, because the 30s stub ends and the guard still exits 2. Only the Ctrl-C test catches it. So the deadline is what turns a missing kill into a failure.
- Removing the test's kill loops (trap and deadline) together with kill_tree: same failures, no leaks within the run. The trap matters only when the suite is stopped from outside (shown in Info above).
- Removing kill_tree from on_signal: killed ("Ctrl-C finished within 15s", "exits promptly").

The watchdog race is fixed, the PID-reuse window is closed, the leftover checks are per-run, and the load scenario that failed before now passes 46/46. The one remaining item is a Low about how well the deadline bounds hangs inside the guard, so this is APPROVED.

== Delta (c988dbab..3f51e7cf) + tmp-file question ==

== Verdict ==
APPROVED

== Findings ==
(A) Stray /tmp/clean-caches-guard.j9GEGZ* files — a test artifact from my own run, not a leak in the guard
[Info] The four files were j9GEGZ, .err and .out (created 16:21:09.868 CEST) and .timeout (16:21:10.880 CEST), all 0 bytes and owned by box. My file /tmp/ccg8/tt.out was last written at 16:21:09.860 CEST, 8ms before they appeared. That run was my trap-kill-removed mutation from the c988dbab re-review: the guard's kill_tree was removed, the suite's cleanup kill loop was removed, and the suite was stopped with `timeout --foreground 10`. The suite died during "a hung docker is stopped by the watchdog" (1s timeout). The orphaned guard went on waiting for its 30s stub, and the watchdog wrote .timeout 1s later. My Shell call then ended about 16:21:22 CEST, before the stub finished, and the box tore down the session's processes. The guard was killed without running its EXIT trap, so its files stayed.
[Info] I reproduced it exactly: same mutation with a private TMPDIR gave the same 4-file pattern (.timeout 1.0s after the others). This time I kept the session alive for 35s, the guard finished normally and removed all four. So the leak only happens when the guard is SIGKILLed. That confirms the files were mine, and I removed exactly those 4.
[Info] Temp-file handling at c988dbab and 3f51e7cf is the same: the delta does not touch mktemp or the traps.
  - One `mktemp ${TMPDIR:-/tmp}/clean-caches-guard.XXXXXX`, before any docker call.
  - An EXIT trap removes $tmp, .out, .err, .timeout, .done and .stop.
  - INT/TERM/HUP run on_signal, which writes .stop, kills docker, waits for both jobs, then exits, so the EXIT trap still runs.
  - The docker wrapper and the watchdog only create $tmp.* names, all on the EXIT list. Neither can outlive the guard on a normal or signal path: the watchdog exits once the guard is gone (`kill -0`).
[Info] Path-by-path reproduction (3f51e7cf, private TMPDIR, guard in its own process group; counts are guard temp files during → after):

| Path | Exit | Files during | Files after |
|---|---|---|---|
| Normal (quick docker) | 1 | 0 | 0 |
| Watchdog timeout (1s) | 2 | 3 | 0 |
| SIGINT | 130 | 3 | 0 |
| SIGTERM | 143 | 3 | 0 |
| SIGHUP | 129 | 3 | 0 |
| SIGKILL | 137 | 3 | 3 (.out, .err, base) |

  The SIGKILL leak is expected and can't be avoided. SIGKILL also orphans the docker child, here a 30s stub, which I killed (my own run). There is no leak on any normal or signal path.
[Low] [non-testable] clean-caches-guard.sh — optional hardening: because SIGKILL leaks are possible, the guard could remove stale `clean-caches-guard.*` files older than, say, a day at startup. Left to the author.

(B) Delta c988dbab..3f51e7cf
[Low] [testable] clean-caches-guard_test.sh "quick docker phase takes under 1s" — this check assumes `sleep 0.1` works.
  - Where sleep only takes whole seconds (the guard then falls back to tick=1), the fast path takes at least 1s per docker call. The check would fail every time, not intermittently. Mutant tick=1 gave 2176ms.
  - It also needs perl (now_ms); macOS and the Linux CI images have it.
  - Fix: skip or relax the check when `sleep 0.1` fails, mirroring the guard's own check.
[Low] [testable] Same case — the fast-path measurement calls guard_docker 20 directly, not through within(). A regression there costs up to 40s (2×20s; 40.6s observed under mutation) instead of failing within 15s. The run is still bounded, so this is minor.
[Info] Timing margin for <1s: measured 322–344ms serial and 371–424ms under 16 busy loops on 8 cores with 4 suites in parallel. That's about 2.4× headroom at the worst point I saw, with no failures. A slower or oversubscribed CI runner would have to be about 2.5× worse than my load test before it flakes.
[Info] The long-value timeout tests (99999999999999999999 and 0300 → exit 2) pass, and the `????*` length cap stops arithmetic overflow before `-gt 300`.

== Rationale ==
Test runs, all on a git archive of 3f51e7cf in /tmp/ccg9, with a logging fake docker first on PATH (no calls logged; no real docker), each suite capped at `timeout 300`:

| Condition | dash | bash | Duration |
|---|---|---|---|
| Serial ×5 per shell | 5/5 (104/104) | 5/5 | 25.07–25.29s |
| 16 busy loops (`timeout 120`) + 4 suites in parallel, per shell | 4/4 | 4/4 | 26.93–27.23s |

Overall: 18/18 passed; min 25.07s, max 27.23s. That matches the claimed 104 checks and the 8/8 load result.

Mutation results:
- Watchdog kill removed, with and without within()'s tree_kill: both fail in about 65s. The per-run stub kill frees the case either way, so stub hangs alone can't tell whether tree_kill is there.
- Hang inside the guard (polling exit removed):
  - With tree_kill: the suite fails in 171s ("finished within 15s", "timeout 300 is accepted", status 124).
  - With tree_kill removed: the suite hits my 300s cap (rc 124).
  So within() does kill the tree first and limits hangs inside the guard. That fixes my previous Low.
- Fast path forced to tick=1: killed ("quick docker phase takes under 1s (2176ms)").

Cleanup: no processes or guard temp files remain from my runs. The deaf-sleep stray that appeared under mutation was killed by the test itself.

(A) is a test artifact from my own run, now removed; the guard leaks only on SIGKILL. (B) is verified and stable under load, with only Low notes. APPROVED.

== Delta (3f51e7cf..42e70ad3) ==
== Verdict ==
CHANGES_REQUESTED

== Findings ==
[Medium] [testable] scripts/clean-caches-guard/clean-caches-guard_test.sh:470-494 — the group-TERM test does not reliably catch removing `trap : INT TERM HUP` (guard.sh:199). Without the trap, the docker subshell dies on the group TERM and the TERM-deaf stub is reparented to the subreaper and keeps running. Whether the test notices depends on a race: if on_signal's kill_tree runs ps before the subshell dies, it still finds and kills the stub. The mutant survived 4/4 runs under the dash suite and was caught 3/3 under the bash suite. I reproduced the orphan by hand (ppid 54, still running after the guard exited 143). Fix: make the test detect a dead subshell regardless of timing. Either have the stub record its parent pid and assert it is still the guard's subshell when TERM arrives, or delay the guard's kill_tree for the test (e.g. a stub that sleeps before re-exec), then assert no marked process survives 1–2s after the guard exits.
[Low] [testable] clean-caches-guard_test.sh:490 — when the group-TERM case fails quickly, the stub it leaked is not cleaned up. Stubs are only killed in the took>=15 branch, so a TERM-deaf stub (which also ignores the `kill` at :458/:490) lingers for 30s after the suite ends. Fix: use `kill -KILL` on $(marked) after the no_proc assertions, whatever the outcome.
[Low] [non-testable] guard.sh node flag list — --max-old-space-size is listed even though node rejects the separated form. This is documented as erring on the safe side, which is fine.

== Rationale ==
Copy made with git archive (/tmp/ccg10), using a tripwire fake docker (never called) and a private TMPDIR for each run.
Serial: dash 5/5 and bash 5/5 gave 121/121 with 0 files left (32.12–32.30s). Load (4 parallel suites under 16 busy loops, timeout 300): dash 4/4 (34.49–34.64s) and bash 4/4 (34.35–34.41s), all 121/121. Overall min/max: 32.12/34.64s.
Mutants, each caught well before the outer cap:
- no SIGKILL escalation: 6 FAIL, 73s, bounded by the test's own 15s guards.
- private-dir cleanup replaced with rm -f: 3 FAIL, 32s.
- sed failure ignored: 1 FAIL, 32s.
- cat/docker-output failure ignored: 1 FAIL, 32s.
- go -C handling dropped: 2 FAIL, 32s.
- only the -C= form dropped: 1 FAIL, 32s.
- --inspect-port dropped: 1 FAIL, 32s.
- no TERM/HUP trap: NOT reliably caught (see the Medium finding).
Private dir: checked by hand. The HUP (129), TERM (143), INT (130) and timeout (2) paths leave nothing; only SIGKILL (137) leaves the clean-caches-guard.XXXXXX dir, as expected. My runs left no processes and nothing under /tmp outside /tmp/ccg10. The /tmp/tmp.* dirs present date from 15:04–15:24, before this review, and are not mine, so I left them alone.

== Delta (42e70ad3..85113103) ==
== Verdict ==
APPROVED

== Findings ==
[Low] [testable] scripts/clean-caches-guard/clean-caches-guard_test.sh — the PR claims 128/128, but every run on this box reports 127 PASS / 0 FAIL ("ok"). One check is probably conditional or was miscounted. Fix: correct the count in the description, or print a total so a skipped check shows up.
[Low] [hard-to-test] clean-caches-guard.sh signal_tree — a process that exits between `kill -STOP` and the ps walk is skipped (`|| continue`), which is correct. A child forked by an already-stopped parent cannot appear, so the walk is sound; no action needed.

== Rationale ==
Copy made with git archive (/tmp/ccg11), using a tripwire fake docker (never called) and a private TMPDIR for each run.
(1) No-trap mutant: caught 16/16 runs (dash 5/5, bash 5/5, and 3/3 per shell under 16 busy loops). Each failed with "docker wrapper survives TERM (stub parent now '54')" plus the no-stub check, in 40–42s. The race from the last round is gone.
(2) Serial: dash 5/5 (38.39–38.44s) and bash 5/5 (38.44–38.56s). Load (4 parallel suites under 16 busy loops, timeout 300): dash 4/4 (40.84–40.97s) and bash 4/4 (40.65–40.82s). Every run was 127/127 with 0 temp files left. Overall min/max: 38.39/40.97s.
(3) Straight to KILL (signal_tree TERM replaced with kill_tree): caught by "docker was sent TERM first", 1 FAIL, 40s. signal_tree signalling only the top PID (child walk removed): 8 FAIL, 40s. Both were caught well under the 300s outer cap.
(4) After every failing mutant run, no stub (/dock/hang) under /tmp/ccg11 was still alive once the suite exited. Afterwards, no processes from my runs remained, there was no /tmp/clean-caches-guard.* dir, and nothing new in /tmp other than my /tmp/ccg11 and system sand-* files.

== Delta (85113103..76e951f6) ==
== Verdict ==
APPROVED

== Findings ==
[Low] [hard-to-test] scripts/clean-caches-guard/clean-caches-guard.sh:265-267 — after the grace period, on_signal sends SIGKILL to every pid recorded at TERM time. A process that exited on TERM may already have been reaped by the subreaper, and its pid could be reused within the ≤1s grace, so an unrelated process could be killed. The comment acknowledges this. Fix (optional): re-check each pid's ppid, or its start time from `ps -o lstart=`, against the TERM-time snapshot before KILLing.
[Info] — the watchdog timeout path (guard.sh:235) still goes straight to kill_tree (KILL), so it does not have the grandchild gap; only on_signal needed the new loop.

== Rationale ==
Copy made with git archive (/tmp/ccg12), using a tripwire fake docker (never called) and a private TMPDIR for each run.
(1) Mutants, 3x per shell each, all caught 6/6 in 41.5–41.7s (outer cap 300):
- A, post-grace KILL loop skipped: 1 FAIL, "no TERM-deaf docker child left after Ctrl-C".
- B, only the direct children of the docker subshell KILLed: same FAIL.
- C, spaced --env-file handling dropped (i++): 1 FAIL, "node with a spaced flag value".
(2) Serial: dash 5/5 (41.39–41.50s) and bash 5/5 (41.53–43.27s). Load (4 parallel suites under 16 busy loops): dash 4/4 (45.95–46.10s) and bash 4/4 (44.15–44.33s). Overall min/max: 41.39/46.10s. Every run counted exactly 130 PASS / 0 FAIL, matching the claimed 130, so the earlier count mismatch is resolved.
(3) After every run, including all 18 failing mutant runs, there were 0 stubs under /tmp/ccg12 still alive and 0 files in any private TMPDIR. There was no /tmp/clean-caches-guard.*, and no processes from my runs remained. Nothing needed killing.

== Delta (85113103..953aebce) ==
(Supersedes "== Delta (85113103..76e951f6) ==" above; this is the single verdict for 85113103..953aebce.)
== Verdict ==
APPROVED

== Findings ==
[Low] [hard-to-test] scripts/clean-caches-guard/clean-caches-guard.sh start_id/same_start — `ps -o lstart` has one-second resolution, and the etime fallback accepts ±1s. A pid reaped and then reused by an unrelated process within the same second (possible inside the ≤1s grace on a busy host) would still match and get SIGKILL. That is far less likely than before, but not zero. Fix (optional): on Linux, compare /proc/<pid>/stat field 22 (starttime in clock ticks) when it is available, and fall back to lstart elsewhere.
[Info] [testable] the reaped-PID tests check "pid gone at KILL time" through CLEAN_GUARD_KILL_TRACE, not actual pid reuse. That is enough to catch dropping the lstart compare deterministically (6/6). True reuse cannot be tested portably.
[Low] [non-testable] the per-launcher node value-flag list is still hand-maintained (carried over from earlier rounds; no action needed).

== Rationale ==
Copy made with git archive of 953aebce (/tmp/ccg13), using a tripwire fake docker (never called) and a private TMPDIR for each run.
Check count: every run reported exactly 136 PASS / 0 FAIL, matching the claim.
Mutants, 3x per shell each (outer cap 300). All caught 6/6, deterministically, in 44.7–45.0s:
- lstart compare dropped (L* → true): 2 FAIL, "no SIGKILL to a reaped pid" and "no SIGKILL to an exited docker tree", with GONE entries in the trace.
- join reading dropped (only launched_tool(...,0)): 1 FAIL, "node with a spaced flag value".
- single-word reading dropped (only launched_tool(...,1)): 2 FAIL, "node with a flag value and a relative script" and "node with a require hook and a relative script".
- grandchild kill_orphan dropped: 1 FAIL, "no TERM-deaf docker child left after Ctrl-C".
- spaced --env-file join dropped (i+1 always): 1 FAIL, "node with a spaced flag value".
Load: serial dash 5/5 (44.76–44.83s) and bash 5/5 (44.84–44.96s). 4 parallel suites under 16 busy loops: dash 4/4 (47.48–47.49s) and bash 4/4 (47.69–47.76s). All 136/136. Overall min/max: 44.76/47.76s.
Leftovers: after every run, including all 30 failing mutant runs, there were 0 live stubs under /tmp/ccg13 and 0 files in any private TMPDIR. There was no /tmp/clean-caches-guard.*, and no processes from my runs remained. Nothing needed killing.
