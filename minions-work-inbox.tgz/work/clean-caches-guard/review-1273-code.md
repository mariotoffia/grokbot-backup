# Code review: PR #1273, active-run guard in `make clean-caches`

- **PR:** https://github.com/Thiink-LLC/teos/pull/1273 (draft, closes #1272)
- **Head:** `4730262e6993dbd4c0aa017f879d024ad8b233f3`, verified; the head has not moved.
- **Commit:** `4730262e build: active-run guard in clean-caches`
- **Verdict: CHANGES_REQUESTED**, because requirement (g) fails.

## Gate table

| Gate | Result |
|---|---|
| (a) Portable to Linux and macOS | PASS. No pgrep is used. It runs `ps -A -o pid= -o ppid= -o args=` (POSIX, works on BSD and GNU) with POSIX sh and awk. The test's `env -u` is supported by GNU and BSD env. No GNU-only flags. |
| (b) Same pattern as CONVENTIONS.md:99 | PASS (literal match). `go (build\|test\|run)\|golangci\|floci\|cdk\|jsii` is the same in both. |
| (c) Lists runs, exits 1, guard runs before any rm | PASS. Makefile:241 is its own recipe line, with no `-` prefix and no `\|\| true`. Exit 1 stops make before the `$(MAKE)` sub-make on Makefile:242. The sub-targets are no longer prerequisites, so they cannot run before the guard, even with -j. |
| (d) Never kills | PASS. It only reads the process list. |
| (e) FORCE=1 override printed | PASS. stderr shows "WARNING: FORCE=1 set: …" plus the list, and the refusal message names FORCE=1. Only an exact `1` overrides. |
| (f) Self-exclusion | PASS. The awk walk skips the guard, all its ancestors (the recipe shell and make) and its direct children. ps output is captured before awk starts, so awk never appears. No pgrep/grep is in the list. Verified on the real ps. |
| (g) No false matches | **FAIL.** See H-1. |
| shellcheck -x / sh -n | PASS (both scripts) |
| Script self-test (`clean-caches-guard_test.sh`) | PASS, all cases |
| make lint / fmt | N/A. Those gates are Go/Rego/TS only, and this PR touches only the Makefile and sh. `make -n clean-caches FORCE=1` gives the expected order. |
| Prefixes (title and commit) | PASS. No W-/T- prefixes. |
| Plan IDs | PASS. None found. |
| Issue #1272 | Assignee mariotoffia; labels devops, build; Priority Medium; Size Hours; Roadmap unset. Board status is **Progress, not Incoming** (L-2). |
| CI (`gh pr checks 1273`, 12:44 CEST) | Green. CodeQL and both Analyze jobs pass. Unit Tests, Build, Architecture and Static Analysis were skipped. |

## Findings

### High

- **H-1, scripts/clean-caches-guard/clean-caches-guard.sh:21 and :44.** The pattern is an unanchored substring match over the whole command line, so unrelated processes block the clean. I tested this live with dummy `sleep` processes started via `exec -a`; all four were listed as active and the guard exited 1:
  - `vim floci.go`
  - `less /home/x/cdk-notes`
  - `cargo test --all` (matches `go test` inside "car**go test**")
  - `go test ./...` (a correct match)

  Proposed fix: match on the executable instead of the substring. Take argv[0]'s basename (and, for `node`/`docker`, the script or image argument) and test it against `go` plus build|test|run, `golangci-lint`, `cdk`, `floci*` and `jsii*`. At minimum, use word boundaries such as `(^|[ /])go (build|test|run)( |$)`. Requirement (b) asks for the literal CONVENTIONS.md pattern, and that pattern (`pgrep -af`) has the same false positives, so update CONVENTIONS.md:99 together with this script. Add fixtures for `vim floci.go`, `/home/x/cdk-notes` and `cargo test` to the `absent` cases. The current test only has `vim notes.txt` (test.sh:45), which cannot catch this.

### Low

- **L-1, Makefile:297-298.** The new self-test runs inside `make test`, but CI's Unit Tests job was skipped on this PR, so CI never ran it. Confirm the job triggers on changes to `scripts/**` and `Makefile`.
- **L-2, issue #1272.** Board status is Progress; the expected value is Incoming.

### Info

- `make -i clean-caches` ignores the guard's failure. That is acceptable, and FORCE=1 is the documented override.
- During the live test, a real `go test -count=1 -run IngestionObjectExpiration` run belonging to another minion was listed correctly. It was not touched.

## Delta 1: 4730262e..4bf68929 (head verified 4bf68929)

**Verdict: CHANGES_REQUESTED.** The only blocker is CI: **Unit Tests was still pending** after about 5 minutes of rechecks (last check 13:05 CEST). The code itself is ready to approve once CI is green.

Commit: `4bf68929 build: fail closed and match program names in clean-caches guard`. It has no W-/T- prefix, and there are no plan IDs. The commit changes only the two scripts; the Makefile is unchanged, and the unit-test label at Makefile:297 was already there.

### Gate table

| Gate | Result |
|---|---|
| H-1 negatives (live dummies via `exec -a`) | PASS. None of these were listed: `vim floci.go`, `less /home/x/cdk-notes`, `cargo test --all`, `vim /opt/golangci/notes`, `/home/x/golangci-stuff/run.sh`. |
| H-1 positives (live) | PASS. All of these were listed: `go test ./...`, `go build`, `golangci-lint run`, `cdk deploy`, `node …/aws-cdk/bin/cdk synth`, `floci-harness`, `jsii`, `docker run floci/floci`, `/usr/local/go/bin/go test`, `pnpm exec cdk synth`. |
| Wrappers | `/usr/local/go/bin/go test` matches (basename). `env X=1 go test` does **not** match as a command line, but `env` execs `go`, so a real run shows up as `go test` (Info). `npm run cdk` does not match, but its child `node …/cdk` does (Info). |
| Fail closed | PASS. `ps` failing (a fake `ps` exiting 1) gives exit 2 and "nothing deleted", **also with FORCE=1** (guard.sh:31-42 run before the FORCE check at :89). An empty list, an unreadable fixture or an awk failure (:83) also give 2. With a readable ps and active runs, FORCE=1 gives exit 0 plus the warning (verified live). Make stops on exit 2 because the guard has its own recipe line (Makefile:241) with no `-` prefix. |
| Self-exclusion | PASS. The ancestor chain and the guard's children are skipped, and the fixture covers matching ancestors. |
| macOS | PASS (static review plus fixtures). `ps -A -o pid= -o ppid= -o args=` is valid on BSD. The awk uses POSIX features only (user functions with locals, `split` with a regex, `sub`), so BWK awk works. `base()` is a `sub(/.*\//)` on a copy. The fixtures cover tabs, wide PIDs and empty args. |
| CONVENTIONS.md:99 | **Not updated and not tracked.** It still has the old substring `pgrep -af` pattern (L-3). |
| shellcheck -x / sh -n | PASS |
| Script tests | PASS (`ok clean-caches-guard`) |
| golangci-lint (pending on the developer's side) | Not relevant. The change is Makefile plus POSIX sh only, with no Go files. |
| CI (`gh pr checks 1273`, 13:05 CEST) | **Unit Tests pending**, which blocks. CodeQL and both Analyze jobs pass; Build, Architecture and Static Analysis were skipped. |

### Findings

- **H-1: resolved.**
- **L-1 (from the initial review): resolved.** The Unit Tests job now triggers on this PR, but it is still pending.
- **L-2 (open):** issue #1272's board status is Progress, not Incoming.
- **L-3 (new), /workspace/minions/CONVENTIONS.md:99:** this line still uses the substring pattern that H-1 fixed, so the manual pre-check still false-matches (`vim floci.go`). Update it to say "run `make clean-caches-guard`", or record it as a follow-up.
- **Info, guard.sh:80:** args are split on whitespace, so a program path that contains a space misses. For example, `/Users/x/My Tools/cdk deploy` is not listed. This is rare and accepted.
- **Info, guard.sh:63-64:** short-lived `docker ps --filter name=floci` or `docker logs floci-…` commands block the clean. That errs on the safe side.
- **Process note:** a live `golangci-lint run …` and a `go test -count=1 -short ./ingestionsvc/...` run belonging to other minions were listed correctly and were not touched. My dummies had exited on their own (`sleep 60`) before cleanup; I killed nothing else.

## Delta 2: 4bf68929..43bc9456 (first pass at c0636181, extended)

**Verdict: CHANGES_REQUESTED, blocked on CI only.** Head verified as c063618199f0 (one commit: "build: detect versioned, flagged and spaced-path runs in clean-caches guard"). No W-/T- prefixes and no plan IDs.

### CI

The **Unit Tests** check was still pending after about 5 minutes of rechecking (10×30s). CodeQL and Analyze (actions, js-ts) pass. Architecture, Build and Static Analysis were skipped.

### Local gates

- `sh -n` passes.
- `shellcheck -s sh -x` is clean on both scripts.
- dash and bash give identical output on a 44-line probe fixture.
- The box's awk is mawk 1.3.4, not gawk, so no gawk extensions are relied on. The script uses only POSIX `sub`, `split` and the `in` operator.
- busybox and checkbashisms aren't available.
- Test script: 54 PASS, ok.

### Probes

The fixture went through CLEAN_GUARD_PS_FILE. No real processes were touched and clean-caches was not run.

**Matched (correct):**
- `go -C x test`, `go test -race`, `go run`, `go -mod=mod build`, `go test -run TestX -count 1`
- `/opt/My Tools/go/bin/go test`
- `golangci-lint run`, `golangci-lint-v2`
- `npx cdk deploy`, `npx --yes aws-cdk@2 synth`, `npx cdk@2.150.0 diff`, `npx -p aws-cdk cdk synth`
- `node --max-old-space-size=4096 node_modules/aws-cdk/bin/cdk synth`
- `pnpm dlx cdk`, `yarn cdk`, `bun x cdk`, `npm exec -- cdk`
- `docker compose -f docker-compose.floci.yml up`
- `jsii-pacmak`

**Not matched (correct or acceptable):**
- `node -e x cdk`: correct, it must not match.
- `go vet`: consistent with CONVENTIONS.md:99, whose pattern is `go (build|test|run)`.
- `node -r ts-node/register bin/app.ts` (the cdk app child): its `cdk synth` parent is matched.
- `gotestsum`: its `go test` child is matched.
- `cdk.cmd`: Windows only, so N/A.

**Earlier negatives, no regressions:** `vim floci.go`, `less /home/x/cdk-notes`, `cargo test --all`, golangci paths, `grep golangci`, `gopls`, `go version`, `docker ps`, `/bin/sh src/cdk` and `/usr/bin/less Notes/cdk-notes.md` are all still unmatched.

**Known safe-direction false positive:** `/usr/bin/vim Src/cdk` matches, as described.

### New Lows (not blocking; no unsafe regression, all were already missed at 4bf68929)

- **L-4:** `bunx cdk` isn't matched because `bunx` is not in the launcher list. Add it next to `bun`.
- **L-5:** `docker compose up` run from the floci directory with no floci argument isn't matched, and neither is the standalone `docker-compose` binary (`docker-compose -p floci up`). Running floci containers show on the host as their own processes, for example `java -jar /opt/floci/floci.jar`, and the guard can't see them. Suggestions:
  - add `docker-compose` to the docker/podman branch;
  - consider adding a `docker ps --filter name=floci` probe, with ps fallback semantics.
- **L-6:** a spaced program path is only recognised when the next segment starts with an upper-case letter. `/opt/my tools/go/bin/go test` is missed. The comment documents this heuristic; it's acceptable for macOS.
- **Info:** `node --stack-size 4096 x/cdk`, a V8 flag given with a separate value, is read as a script named `4096` and missed. The `=` form is the common one.

### Carried items

- **L-2:** still open. Issue #1272's board Status is "Progress", not Incoming.
- **L-3:** still open. CONVENTIONS.md:99 still uses the old `pgrep -af` substring pattern.

To approve: Unit Tests must go green at c0636181. L-4 is a one-word fix worth folding in.

### Extension: c0636181..43bc9456

**Verdict: CHANGES_REQUESTED, blocked on CI only.** The head moved to 43bc94569c14 with one new commit, "build: limit spaced-path joining in clean-caches guard". No W-/T- prefixes and no plan IDs. If Unit Tests goes green and nothing else changes, this becomes APPROVED.

**What the commit does:** `prog_end` now joins following words into the program path only when the first word starts with `/Users/`, `/Applications/`, `/Volumes/` or `/home/` and doesn't end in a `bin/` or `sbin/` folder (checked with the regex `/\/s?bin\/[^\/]*$/`). The comment and the Known limitation in the PR body describe this.

**CI:** the Unit Tests check was still pending after about 5 minutes (10×30s). CodeQL and Analyze pass. Architecture, Build and Static Analysis were skipped. Unit Tests has now been pending on c0636181 and on 43bc9456. Worth checking whether the job is queued, waiting on a label, or stuck.

**Gates:**
- `sh -n` passes and `shellcheck -s sh -x` is clean.
- The tests give 59 PASS and 0 FAIL under both dash and bash.
- The 5 new negative fixtures are: `/bin/cat Docs/cdk`, `/usr/bin/vim Projects/teos/cdk`, `/usr/bin/less Notes/go test`, `/usr/bin/tail Logs/floci.log` and `/home/u/bin/vim Notes/go test`.

**Portability, by inspection of the awk program:**
- No gawk-only functions (gensub, strftime, systime, asort), no `length(arr)`, no IGNORECASE, no `\< \> \y` word boundaries.
- No `{n}` regex intervals; the new regexes use only alternation, `?`, `*` and bracket expressions.
- No match(), RSTART or substr.
- The one regex `split` is `split(args, a, /[ \t]+/)`, which POSIX defines and BSD awk, mawk and busybox all support.
- The `?` in `s?bin` is a POSIX ERE feature and works in BSD awk and mawk.
- The box runs mawk 1.3.4.

**Probes** (fixture file):
- **Caught:** `/Users/x/My Tools/cdk deploy`, `/home/x/My Tools/go/bin/go test`, `/Applications/Dev Tools/golangci-lint run`, `/Volumes/Ext Disk/Go/bin/go build`, `/usr/local/go/bin/go test`, `/home/x/go/bin/go run`, `npx cdk@2 synth`.
- **Known false positive, documented in the PR body:** `/Users/x/Tools/vim Notes/cdk`.
- **Correctly not matched:** `/usr/bin/vim Src/cdk`, the earlier false positive, which this commit fixes; `/home/x/bin/vim Notes/cdk`; `node -e x cdk`; `vim floci.go`; `/bin/sh src/cdk`.
- **New miss compared with c0636181:** `/opt/My Tools/go/bin/go test` is no longer caught. It's covered by the Known limitation ("A program at a spaced path that does not fit this shape is not detected"). It's acceptable: a spaced path under /opt is unusual on Linux and macOS, it never matched before c0636181, and FORCE semantics are unchanged.

**Dev-lead decisions, recorded:**
- L-4 (bunx), L-5 (docker-compose and floci container processes) and L-6 (lower-case spaced path) were declined as pre-existing and non-blocking. Accepted. Note that the /opt case above widens L-6 slightly; it is documented.
- L-3 (CONVENTIONS.md:99): per Mario, it will be updated after merge. Tracked.
- L-2 (issue #1272 status is Progress, not Incoming): still as before.

## Final

APPROVED at 43bc9456. CI is green: Unit Tests passed (run 40089310814), CodeQL and both Analyze jobs passed, and Architecture, Build and Static Analysis were skipped. Open, non-blocking: L-2 (#1272 board status) and L-3 (CONVENTIONS, after merge).
