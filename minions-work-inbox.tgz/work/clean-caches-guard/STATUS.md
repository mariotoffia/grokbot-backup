# build: active-run guard in clean-caches
Phase: review (draft PR) · Owner: core-services-dev · Last update (Europe/Stockholm): see log
Next step: internal reviews on PR #1273
Blockers: none

## Log
- 2026-10-24 12:22 build.clean-caches-guard start: go relayed by Solo 12:21; creating issue.
- 2026-10-24 12:22 build.clean-caches-guard milestone: issue #1272 created (Task, Medium, Hours, board Incoming, Sprint unset).
- 2026-10-24 12:24 build.clean-caches-guard milestone: red->green guard test; draft PR #1273 at 4730262e; running gates.
- 2026-10-24 12:42 build.clean-caches-guard milestone: gates guard-test PASS, shellcheck PASS, vet PASS, lint-arch PASS (11 maps), golangci-lint 0 issues; web pnpm lint env-blocked (corepack cache /usr/local/share/corepack not writable).
- 2026-10-24 12:42 build.clean-caches-guard done: PR #1273 draft at 4730262e; clean-caches run via new guard (idle), df / 20%, inodes 41%.
- 2026-10-24 12:43 test-reviewer start: review PR 1273 tests @4730262e
- 2026-10-24 12:44 test-reviewer done: PR 1273 tests @4730262e — CHANGES_REQUESTED
- 2026-10-24 12:44 code-reviewer done: #1273 review CHANGES_REQUESTED at 4730262e (false matches on floci/cdk/go substrings)
- 2026-10-24 12:46 build.clean-caches-guard milestone: review fixes (fail closed, program-name matching, macOS/self/negative fixtures, env -u FORCE) red->green, pushed 4bf68929; unit-test label added; running gates.
- 2026-10-24 12:57 build.clean-caches-guard milestone: gates guard-test PASS (36), shellcheck PASS, vet PASS, lint-arch PASS; make lint golangci typecheck failed once (Go build cache wiped mid-run by another job), rerun interrupted; no cache cleaning run.
- 2026-10-24 12:58 test-reviewer start: delta 1 review PR 1273 tests 4730262e..4bf68929
- 2026-10-24 12:59 test-reviewer done: delta 1 PR 1273 tests @4bf68929 — APPROVED
- 2026-10-24 13:06 code-reviewer done: #1273 delta-1 review CHANGES_REQUESTED at 4bf68929 (H-1 fixed; Unit Tests CI pending)
- 2026-10-24 13:06 build.clean-caches-guard milestone: make lint @4bf68929: golangci-lint PASS (0 issues), lint-arch PASS; pnpm web lint FAIL env-only (corepack OK with COREPACK_HOME, but web node_modules not installed -> eslint not found). No commits, no cache cleaning.
- 2026-10-24 13:08 build.clean-caches-guard milestone: detection misses (npx @version, node flags, go flags, spaced paths) red->green, 54 checks dash+bash; pushed c0636181; running gates.
- 2026-10-24 13:12 build.clean-caches-guard milestone: gates @c0636181: guard test PASS (dash+bash), shellcheck PASS, vet PASS, lint-arch PASS, golangci-lint PASS (0 issues); pnpm web FAIL known (no node_modules). Draft kept; no cache cleaning.
- 2026-10-24 13:14 test-reviewer start: delta 2 review PR 1273 tests 4bf68929..c0636181
- 2026-10-24 13:15 test-reviewer done: delta 2 PR 1273 tests @c0636181 — CHANGES_REQUESTED
- 2026-10-24 13:17 build.clean-caches-guard milestone: spaced-path join limited to user/volume dirs, 5 negatives red->green, 59 checks dash+bash; pushed 43bc9456; PR body limitation note appended; running gates.
- 2026-10-24 13:19 build.clean-caches-guard milestone: gates @43bc9456: guard test PASS (59, dash+bash), shellcheck PASS, vet PASS, lint-arch PASS, golangci-lint PASS (0 issues; first try hit 'parallel golangci-lint is running', retried after it ended); pnpm web FAIL known (no node_modules). awk reviewed manually for POSIX (no bwk/busybox on box). Draft kept; no cache cleaning.
- 2026-10-24 13:19 code-reviewer done: PR #1273 Delta 2 @c0636181 CHANGES_REQUESTED (Unit Tests CI pending ~5min; code OK, 54 tests pass, sh/dash/mawk/shellcheck clean; new Lows L-4 bunx, L-5 docker-compose/floci containers, L-6 lowercase spaced path; L-2/L-3 still open) -> review-1273-code.md
- 2026-10-24 13:20 test-reviewer start: delta 3 review PR 1273 tests c0636181..43bc9456
- 2026-10-24 13:21 test-reviewer done: delta 3 PR 1273 tests @43bc9456 — APPROVED
- 2026-10-24 13:28 code-reviewer done: PR #1273 Delta 2 extended to 43bc9456: CHANGES_REQUESTED (CI only: Unit Tests pending ~5min); spaced-path restriction OK, 59/59 dash+bash, shellcheck clean, awk portable; /opt spaced path now missed but documented; L-4..L-6 declined, L-3 after merge -> review-1273-code.md
2026-10-24 14:07 CEST code-reviewer: #1273 APPROVED at 43bc9456 (CI green)
- 2026-10-24 14:08 build.clean-caches-guard milestone: PR #1273 marked ready, Copilot review requested (round 1).
- 2026-10-24 14:20 build.clean-caches-guard milestone: Copilot round 1: 2 comments (ps -ww, detached Floci containers) fixed TDD, 68 checks; pushed c893e22e; replied on both threads.
- 2026-10-24 14:35 build.clean-caches-guard milestone: Copilot round 2: smoke check docker fixture + launcher spaced script path fixed TDD, 71 checks; pushed bb2502ac; re-requested Copilot.
- 2026-10-24 14:52 build.clean-caches-guard milestone: Copilot round 3 on bb2502ac: no open inline comments; 1 summary-only 'previously missed' note (retained Floci container java process on Linux host ps blocks clean; safe side) left open, 3-round cap reached; reported to dev-lead.
- 2026-10-24 14:53 test-reviewer start: delta review PR 1273 tests 43bc9456..bb2502ac
- 2026-10-24 14:53 build.clean-caches-guard milestone: round-3 note accepted as fail-safe; documented in guard header (9dcd97fe), guard test 71 PASS dash+bash, shellcheck clean; pushed; PR comment posted; Copilot not re-requested.
- 2026-10-24 14:54 test-reviewer done: delta review PR 1273 tests 43bc9456..bb2502ac — APPROVED
- 2026-10-24 14:55 build.clean-caches-guard milestone: test-delta fixes (container awk fails closed, docker down only when daemon unreachable, /opt/tools/vim negative) TDD, 75 PASS dash+bash, shellcheck clean; committed 0d90310c locally, NOT pushed (awaiting code-review delta batch).
- 2026-10-24 14:57 test-reviewer start: re-review PR 1273 tests bb2502ac..0d90310c
- 2026-10-24 14:57 test-reviewer done: re-review PR 1273 tests bb2502ac..0d90310c — APPROVED
- 2026-10-24 15:03 code-reviewer done: PR #1273 delta 43bc9456..0d90310c CHANGES_REQUESTED (M-1 docker info/ps has no timeout nor documented limit; Unit Tests pending ~5min); label filter/retained/fail-closed (perm denied=2, daemon-down=0, Docker 29 + legacy wording, locale-safe) OK, 75/75 dash+bash, shellcheck clean -> review-1273-code-delta.md
- 2026-10-24 15:10 build.clean-caches-guard milestone: code-delta M-1 docker watchdog (CLEAN_GUARD_DOCKER_TIMEOUT, default 10s, invalid -> exit 2) + 'connect: no such file or directory' fixture, TDD; 90 PASS dash+bash x3, no stray processes, shellcheck clean; pushed 0d90310c + b42acd7d.
- 2026-10-24 15:11 test-reviewer start: delta review PR 1273 tests 0d90310c..b42acd7d (flakiness focus)
- 2026-10-24 15:21 code-reviewer done: PR #1273 Delta 2 @b42acd7d CHANGES_REQUESTED (M-2 Ctrl-C orphans docker+watchdog; watchdog later kill_tree's a possibly reused pid + stray .timeout file; Unit Tests pending ~5min); M-1 timeout works (3.02s@3s rc2, fast 13ms), 90/90 dash+bash, shellcheck clean, invalid values exit 2 except huge (L-2) -> review-1273-code-delta.md
- 2026-10-24 15:26 test-reviewer done: delta review PR 1273 tests 0d90310c..b42acd7d — CHANGES_REQUESTED
- 2026-10-24 15:26 build.clean-caches-guard milestone: code-delta 2 M-2 (signal trap stops+waits watchdog/docker, watchdog checks guard alive/.done/ppid, 130/143/129) + L-2 (timeout cap 300) + silenced Terminated, TDD; 98 PASS dash+bash x3, no strays/temp files, shellcheck clean; pushed 0675023d.
2026-10-24 15:46 polling watchdog (no TERM reliance, .stop marker, wait wpid then dpid), run-scoped no-strays, per-case deadlines, 30s stubs, test cleanup trap; deaf-sleep red confirmed (red-10); dash/bash green 101 PASS; load 4 parallel + yes x8: dash 8/8, bash 8/8, 32s each; shellcheck -s sh clean; committed+pushed c988dbab
- 2026-10-24 15:47 test-reviewer start: re-review PR 1273 tests b42acd7d..c988dbab (load repro)
- 2026-10-24 16:08 code-reviewer #1273 Delta 3 @c988dbab: approvable pending CI (Unit Tests pending); M-2 fixed; L-3 ~1s/docker-call fast-path latency, L-2 overflow values bypass cap (msg-build.clean-caches-guard-code-reviewer-008 re dev-lead-527)
- 2026-10-24 16:21 test-reviewer done: re-review PR 1273 tests b42acd7d..c988dbab — APPROVED
2026-10-24 16:26 L-3 0.1s watchdog tick w/ sleep-1 fallback (manual fallback check: 2s timeout honoured), L-2 ????* reject (+99999999999999999999, 0300 tests), within() tree-kill; red-11 confirmed (2025ms, overlong accepted); unloaded dash/bash 25s 104 PASS quick 326-328ms; load 4 parallel + yes x8: dash 8/8 bash 8/8 26-27s, quick 358-387ms; shellcheck clean; pushed 3f51e7cf; not marked ready
- 2026-10-24 16:27 test-reviewer start: delta review PR 1273 c988dbab..3f51e7cf + stray tmp-file question
- 2026-10-24 16:36 code-reviewer #1273 Delta 4 @3f51e7cf: approvable pending CI (Unit Tests pending); L-3 and L-2 fixed, safety holds; info: ~4% tick drift, 0.1s probe always (msg-build.clean-caches-guard-code-reviewer-009 re dev-lead-532)
- 2026-10-24 16:49 test-reviewer done: delta review PR 1273 c988dbab..3f51e7cf + tmp-file question — APPROVED (stray j9GEGZ files were my SIGKILLed mutant run; removed)
- 2026-10-24 17:35 cto watchdog: head 48e6c44f (17:27), 0 unresolved Copilot threads, Unit Tests running; test+code delta re-check of aa14f31e..48e6c44f pending.
2026-10-24 17:38 Copilot loop (3-round cap): r1 private mktemp -d dir, SIGKILL timed-out docker, spaced go -C (aa14f31e); r2 unreadable docker output exit 2, group TERM/HUP wrapper trap, node --max-old-space-size (36fb5361); r3 sed failure exit 2, go -C=dir (48e6c44f). Final Copilot review @48e6c44f: no open threads; 1 previously-missed item (node --inspect-port value) left unfixed (cap). Gates: dash/bash 117 PASS ~32s, load 8/8+8/8 (33s, after r2), shellcheck clean. Unit Tests CI pending/in progress. Not merged.
2026-10-24 17:41 round 4: node value-flag list (--inspect-port, --debug-port, --redirect-warnings, --report-dir, --openssl-config, ... checked with node v22 --help and separated-form runs); fixtures inspect-port, inspect-brk, -r+--env-file, report/warnings; red-15 confirmed; dash/bash 121 PASS 32s; shellcheck clean; pushed 42e70ad3; Copilot not re-requested
- 2026-10-24 17:42 test-reviewer start: delta review PR 1273 3f51e7cf..42e70ad3
- 2026-10-24 17:51 code-reviewer #1273 Delta 5 @42e70ad3: approvable pending CI (Unit Tests pending); 121/121 dash+bash; kill safety holds; L-4 kill_tree top-down SIGKILL reuse window, L-5 SIGKILL on Ctrl-C, I-3 node flags incomplete (msg-build.clean-caches-guard-code-reviewer-010 re dev-lead-537)
- 2026-10-24 18:01 test-reviewer done: delta review PR 1273 3f51e7cf..42e70ad3 — CHANGES_REQUESTED
2026-10-24 18:11 Round 5 pushed 85113103: L-4 signal_tree (STOP top-down, signal children-first, CONT), L-5 TERM+1s grace then KILL on interrupt, I-3 --test-reporter/--test-reporter-destination/--localstorage-file; deterministic group-TERM test (stub records wrapper ppid), KILL cleanup, graceful-TERM test. Red: gates/guard-test-red-16-{dash,bash}.log (3 FAIL). No-trap mutant under dash FAILs 2/2: gates/guard-test-mutant-notrap-dash-{1,2}.log. Green dash+bash 128 checks, shellcheck clean, load dash 8/8 bash 8/8 (40-41s). No Copilot request, no cache clean, no merge.
- 2026-10-24 18:12 test-reviewer start: delta review PR 1273 42e70ad3..85113103
- 2026-10-24 18:24 code-reviewer #1273 Delta 6 @85113103: approvable pending CI (Unit Tests pending); 127/127 dash+bash (claim 128 off by one); L-4/L-5/I-3 fixed; L-6 SIGKILL mid-walk leaves wrapper stopped (msg-build.clean-caches-guard-code-reviewer-011 re dev-lead-541)
- 2026-10-24 18:33 test-reviewer done: delta review PR 1273 42e70ad3..85113103 — APPROVED
2026-10-24 19:02 Pushed 8fc56d3b (Known limit comment) and 76e951f6 (Copilot R1: kill TERM-deaf children after the grace on interrupt; join spaced node flag values). Check count is 127 at 8fc56d3b (the earlier 128 was a grep miscount) and 130 at 76e951f6; PR body updated. Gates: dash/bash 130/130, shellcheck clean, load 8/8+8/8; red logs gates/guard-test-red-17-dash.log. Copilot R2 at 76e951f6: no open issues. No merge, no cache clean.
- 2026-10-24 19:06 cto watchdog: head 76e951f6, Copilot R2 clean, 0 unresolved threads, Unit Tests running; test+code delta re-check of 85113103..76e951f6 pending.
- 2026-10-24 19:16 test-reviewer start: delta review PR 1273 85113103..76e951f6
- 2026-10-24 19:27 code-reviewer: Delta 7 PR 1273 @76e951f6 CHANGES REQUESTED — H-1 KILL of stale termed pids on Ctrl-C (guard.sh:258-266, repro'd), M-1 node value join fail-open (guard.sh:102, repro'd); 130/130 dash+bash; CI Unit Tests pending
2026-10-24 19:37 Round 6 pushed 953aebce: H-1 start-time identity check (lstart, etime ±1s fallback) before orphan SIGKILL plus an unconditional kill_tree re-walk; M-1 node flag values read joined and single-word; I-5 comment. Red gates/guard-test-red-18-{dash,bash}.log (4 FAIL each). Green dash/bash 136/136, shellcheck clean, load 8/8 each, no leftovers or stopped processes. PR body updated to 136. No Copilot request, no merge, no cache clean.
- 2026-10-24 19:38 test-reviewer done: delta review PR 1273 85113103..76e951f6 — APPROVED
- 2026-10-24 19:38 test-reviewer start: delta review PR 1273 85113103..953aebce (supersedes ..76e951f6)
- 2026-10-24 19:47 code-reviewer: Delta 8 PR 1273 @953aebce APPROVABLE PENDING CI — H-1/M-1/I-5 resolved (repro: 0 KILLs to reaped pids, TERM+INT dash+bash; orphan KILLed); L-7 1s identity granularity (guard.sh:214-234), L-8 malformed E match (232); 136/136 dash+bash; CI Unit Tests pending
- 2026-10-24 20:18 test-reviewer done: delta review PR 1273 85113103..953aebce — APPROVED (supersedes ..76e951f6)
2026-10-24 21:28 round 7 done: head 76d8c818; 158/158 dash+bash, shellcheck clean, load 8/8 both; Copilot 3 rounds (cap reached), last finding fixed and replied, no re-request; PR body 158
2026-10-24 21:29 Europe/Stockholm test-reviewer: start delta 953aebce..76d8c818 (msg 554)
- 2026-10-24 21:40 code-reviewer: Delta 9 PR 1273 @76d8c818 CHANGES REQUESTED — M-2 bare return in same_start under bash trap (guard.sh:263) leaves TERM-deaf orphan; 1-line fix verified; L-9 empty-pp hardening (316-323); rule audit clean; 158/158 dash+bash (guard always under sh); CI Unit Tests pending
2026-10-24 21:54 round 8 done: head 0d55cd67; M-2 explicit returns, suite runs guard under shell under test (+3 bash orphan cases, red-23), L-9 kill -0 checks, I-9 Known limit; 161/161 dash+bash, shellcheck clean, load 8/8 both; Copilot not re-requested; PR body 161
- 015 re 558: PR 1273 Delta 10 @0d55cd67 APPROVED (conditional on Unit Tests); 161/161 dash+bash; CI Unit Tests pending
