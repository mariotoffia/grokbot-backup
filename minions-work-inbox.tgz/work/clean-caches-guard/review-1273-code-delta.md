# PR #1273 code review, delta 43bc9456..0d90310c

**Verdict: CHANGES_REQUESTED** for one Medium (M-1, docker hang). CI is also pending.

**Head:** 0d90310c654021f58e4d67f8a09ee3a55dfd4331, verified. I waited for it to move from bb2502ac.

**Commits:**
- c893e22e: wide ps and Floci container check
- bb2502ac: spaced script paths for launchers
- 9dcd97fe: documents the retained Floci limit
- 0d90310c: fails closed on docker and container-list errors

The title is "build: active-run guard in clean-caches". No W-/T- prefixes in the title or commits, and no plan IDs.

## CI

The Unit Tests check was still pending after about 5 minutes of rechecking (10×30s). CodeQL and Analyze (actions, js-ts) pass. Architecture, Build, Static Analysis, Bugbot and Security Reviewer were skipped.

## Gates

- `sh -n` passes and `shellcheck -s sh -x` is clean.
- The test script gives 75 PASS and 0 FAIL under both dash and bash.

## Docker detection

- **Label filter.** `--filter label=teos.floci.local=1` matches `labelKey`/`labelValue` in go-core/utils/testutils/flocilocal/consts.go, an exact key=value match. `docker ps` without `-a` lists only running containers, which is correct.
- **Retained containers.** A container is skipped only when `teos.environment.lifecycle` is exactly `retained`, matching `RetainedLifecycleLabel`/`RetainedLifecycleValue` in consts.go. Retained environments are meant to outlive their creator, so they're not a run in progress. A missing lifecycle label, or `temporary`, counts as active, which is the safe direction.
  - Fixture check: `abc temporary` and `ghi` with no label were flagged; `def retained` was skipped.
- **Accepted residual:** a retained container's java process that shows in host ps blocks the clean. This is now in the header's Known limit.
- **Docker CLI missing:** treated as no containers. Correct.

### Daemon unreachable

At 0d90310c, a `docker info` failure counts as "no containers" only when its stderr contains one of three strings; anything else exits 2. Probed with stub docker binaries on PATH:

| docker info stderr | rc |
|---|---|
| Older and tcp wording: "Cannot connect to the Docker daemon at …. Is the docker daemon running?" (the same text on Linux and on macOS Docker Desktop, where only the socket path differs, e.g. ~/.docker/run/docker.sock) | 0 |
| Docker 29.9.2 wording, checked live on the box against a missing socket: "failed to connect to the docker API at unix://…; … daemon is running: dial unix …: connect: no such file or directory" (matched by `connect: no such file`) | 0 |
| permission denied, both old and new wording | **2** |
| connection refused (stale socket, daemon dead) | 2 (fails closed; safe but noisy, Info) |
| info ok, ps fails | 2 |

On the real box, the socket is permission-denied, and the guard exits 2. This was the live unsafe case at c893e22e and bb2502ac, where any `docker info` failure counted as a pass. It is fixed at 0d90310c.

**Locale.** Docker CLI and Go syscall error texts aren't localised. With `LC_ALL=de_DE.UTF-8` the message was identical. Not locale-fragile.

**Info.** A remote or tcp context that is unreachable also counts as "none". Only local caches are cleaned, so this is acceptable.

### M-1: no timeout on docker

`docker info` and `docker ps` run with no time limit. A wedged daemon, or Docker Desktop still starting, blocks `make clean-caches` forever. A stub docker that sleeps was still blocking after 8 seconds and had to be killed by my outer `timeout`. This is the safe direction, since nothing is deleted, but it's a silent hang, and it isn't documented in the header or the PR body.

Fix: either add a portable watchdog or document the limit.
- **Watchdog sketch.** `timeout` isn't on stock macOS, so use a background job plus kill:
  ```
  docker info >"$tmp" 2>&1 & p=$!
  ( sleep 10; kill "$p" ) 2>/dev/null & w=$!
  wait "$p"; rc=$?
  kill "$w"
  ```
  Then treat the timeout as exit 2.
- **Minimum.** Add a Known limit line ("a hung Docker daemon blocks the guard; Ctrl-C or FORCE=1 does not help…").

## ps -ww

`-ww` (unlimited width) is supported by procps on Linux and by BSD/macOS ps. busybox ps doesn't implement `-A`/`-ww` in most builds, so ps exits non-zero there and the guard exits 2, which fails closed. Info only; busybox isn't a supported developer host.

## Spaced-path launcher script (bb2502ac)

This isn't a separate script file. It's a change to awk `prog_end(a, n, s)` so the same spaced-path join applies to the script word a launcher runs, as in `node "/Users/x/My Tools/cdk"`, with the same /Users, /Applications, /Volumes, /home and not-bin/sbin restriction. It's safe and portable: POSIX awk only, and no new regex features.

It doesn't reopen or change the /opt miss: `/opt/My Tools/go/bin/go test` and `node /opt/My Tools/cdk` are still not matched. That remains covered by the Known limitation in the PR body.

New java branch: `java` with any argument whose base name starts with `floci` matches. That covers `-jar /opt/floci/floci.jar` and `-cp /app/floci-1.2.jar`. `java -jar app.jar --name floci` also matches, a safe-direction false positive (Info).

## Fixture probes at 0d90310c

**Matched:**
- `go -C x test`, `go run`
- `/home/x/My Tools/go/bin/go test`, `/Users/x/My Tools/cdk`
- `golangci-lint-v2`
- `npx --yes aws-cdk@2`, `npx -p aws-cdk cdk`
- `node --max-old-space-size=4096 …/cdk`
- `node /Users/x/My Tools/cdk`, `node /home/u/Dev Stuff/node_modules/aws-cdk/bin/cdk`
- `pnpm dlx cdk`, `yarn cdk`
- `jsii-pacmak`
- `docker compose -f docker-compose.floci.yml`
- the java floci jars
- the containers abc and ghi

**Not matched (correct):** `node -e x cdk`, `vim floci.go`, `/usr/bin/vim Src/cdk`, `/bin/sh src/cdk`, `node /home/u/bin/app Notes/cdk`, `cargo test --all`, `go vet`, `java -Dlog=/var/floci/x.log -jar app.jar`.

**Not matched (documented):** the /opt spaced paths.

No real processes or containers were touched. I ran only `docker version` and `docker info` against a nonexistent socket and tcp:1. clean-caches was not run.

## To approve

1. M-1: add a timeout or a documented Known limit for a docker hang.
2. Unit Tests green.

## Delta 2: 0d90310c..b42acd7d

**Verdict: CHANGES_REQUESTED** for M-2, the watchdog killing a pid after Ctrl-C. Unit Tests is also pending.

**Head:** b42acd7d1c1c6c749ddadceae5988b6bbece88ed, verified. One commit, "build: docker watchdog in clean-caches guard". No W-/T- prefixes and no plan IDs.

**CI:** the Unit Tests check was still pending after about 5 minutes (10×30s). CodeQL and Analyze pass. Everything else was skipped.

**Gates:**
- `sh -n` passes and `shellcheck -s sh -x` is clean.
- The tests give 90 PASS and 0 FAIL under both dash and bash.
- No `wait -n`, `[[`, `local`, pipefail, pkill/killall, or negative-pid (process-group) kill. POSIX only, portable to macOS by inspection.

All runs below used stub docker binaries on PATH, with TMPDIR set to a scratch directory.

### What works

- **M-1 fixed.**
  - A hung stub returns with rc 2 after 3.02 s at a 3 s timeout, under both dash and bash. The message is "clean-caches: docker did not respond within Ns; nothing deleted."
  - The hung docker, the sleeper and the temp files are all gone afterwards.
  - The fast path takes 13–16 ms, so the sleeper adds no fixed wait.
  - "Daemon down" still gives 0.
  - A retained container gives 0.
- **What is killed.**
  - `kill_tree` sends a plain-pid `kill` to `$dpid` and, recursively, to the children it finds through a `ps` ppid snapshot.
  - The main shell sends `kill "$wpid"` to the watchdog subshell, whose TERM trap kills only its own `$s` sleep.
  - No PGID or pattern kills.
- **Normal and timeout paths leave nothing behind.** Checked with ps: no leftover sleepers and no zombies from the guard's process trees. The zombies and the `sleep 10` that ps showed belonged to unrelated processes, including another agent's test run under /tmp/ccg7, and were left alone.
- **Traps.** The EXIT trap removes `$tmp*`, and INT/TERM/HUP run `exit 2`, which triggers EXIT in both dash and bash.
  - The guard runs as its own process, so there's no caller trap to restore or chain.
  - The watchdog subshell sets its own TERM trap and, after firing, ignores TERM (`trap '' TERM`). This is fine in POSIX sh.
- **Invalid values.** Empty, `0`, `-1`, `abc`, `1.5` and `05` all exit 2.

### M-2: Ctrl-C orphans docker and the watchdog, which later kills a pid that may have been reused

Reproduced with a SIGINT to the guard's own process group, which is what Ctrl-C sends, against a 2 s "slow" stub with a 6 s timeout:

1. The guard exits 2 immediately and removes its temp files.
2. In a non-interactive sh, background jobs ignore SIGINT, so the docker child and the watchdog keep running. They're reparented to the subreaper (ppid 54).
3. Docker finishes at about 2 s and is reaped by init, so its pid becomes free.
4. At 6 s the watchdog fires anyway and runs `kill_tree "$dpid"`. That sends a kill to a pid that now belongs to no one and could have been reused by an unrelated process, and also to that process's children. This breaks the "never kill anything" requirement.
5. It also recreates a stray `$TMPDIR/clean-caches-guard.XXXXXX.timeout` file. The file was observed under dash and bash, for both the hang and the slow stub.

With a hung stub, the hung docker survives the Ctrl-C until the watchdog kills it at the timeout.

**Fix:** in the INT/TERM/HUP trap, kill `$wpid` and then `$dpid` while they're still unreaped children of the guard, so their pids can't have been reused yet, and wait for them. Also, or instead, have the watchdog check `kill -0 "$PPID"`, or check that the parent is still the guard, before `kill_tree`, and skip `: >"$tmp.timeout"` once the guard is gone. Add a test that sends SIGINT to the group.

### Low

- **L-1, a small race on the normal path.** If docker exits just as the sleeper fires, the main `wait` reaps `$dpid` while the watchdog, now ignoring TERM, still runs `kill_tree` on it. The window is microseconds and the pid has only just been freed. The M-2 fix, a parent and pid check in the watchdog, covers it.
- **L-2, huge values.** `99999999999999999999` is accepted, exit 0 on the fast path. GNU sleep takes it. BSD/macOS sleep may reject it and return at once, so the watchdog fires immediately and exits 2. That's the safe direction, but it doesn't match the documented validation. Suggest capping the value, e.g. at 3600 or by digit count.
- **Info.** Under dash, the timeout path also prints the shell's "Terminated" job notice on stderr, which is cosmetic.

### To approve

1. Fix M-2 and add a group-SIGINT test.
2. Unit Tests green.

## Delta 3 — b42acd7d..c988dbab (head c988dbab48519f5e581570401cf2def7527e648d)

**Verdict: code approvable pending CI.** M-2 is fixed. Two Lows remain, neither blocking. CI: Unit Tests is still pending after about 5 min of rechecks; CodeQL and Analyze pass; the other checks are skipping.

- **Head and commits:** head verified. The delta is 2 commits, 0675023d ("clean up docker jobs on interrupt") and c988dbab ("polling watchdog"). It changes only the guard script and its test. There are no W-/T- prefixes and no plan IDs.
- **Static checks and tests:** `sh -n` and `shellcheck -s sh` (script and test) are clean. The tests pass: dash 101/101 and bash 101/101, about 31s each. The tests only kill processes they marked under $WORK.
- **Load gates:** all 16 rN-M result files say rc=0 (8 dash and 8 bash). I read them; rerunning the suite above covers them.

### Stub repro (python setsid harness, docker stub on PATH only)
I used a private TMPDIR and checked the session for leftover processes right after exit and again stub+2s later.

| Case | dash | bash | Leftovers / .timeout / temp files |
|---|---|---|---|
| INT to group (2s stub, 6s timeout) | 130 in 1.02s | 130 in 1.02s | none |
| INT to guard pid only (4s stub) | 130 | 130 | none |
| TERM to guard pid only | 143 | 143 | none |
| HUP to guard pid only | 129 | 129 | none |
| TERM with a hung stub (sleep 500), 30s timeout | 143 in 3.0s | 143 in 3.0s | none; the stub's sleep was killed |
| timeout path (3s stub, 2s timeout) | 2 in 2.04s | 2 in 2.10s | none |
| hung stub (sleep 500), 3s timeout | 2 in 3.04s | 2 in 3.09s | none |
| normal path | 0 | 0 | none |

The docker child and the watchdog are stopped even when only the guard pid gets the signal. Nothing ran or killed after the guard exited.

### The "still the guard's child" recheck
- The check is `ps -o ppid= -p $dpid` compared with `$guard_pid` (= `$$`, which is also correct inside subshells). It is POSIX and works on macOS.
- The guard blocks in `wait $wpid` before it reaps docker, so `$dpid` stays an unreaped child, or a zombie, until the watchdog exits. Its pid cannot be reused between the check and `kill_tree`.
- If the guard is SIGKILLed, docker is reparented, so the ppid no longer matches and `kill -0` fails: no kill. Good.
- A residual window remains for grandchildren that `kill_tree` lists. The docker process could be reaped by its subshell between the ps and the kill. This window is microseconds and existed before; info only.

### L-3 (new, Low): the polling watchdog adds about 1s per docker call on the fast path
- A fast stub now takes **2.01s** (dash) and **2.07s** (bash), against 13ms at b42acd7d. The guard waits for the watchdog, which only notices `.done` at its next 1s tick, and this happens for `docker info` and again for `docker ps`.
- This is safe but visible on every `make clean-caches`.
- Possible fixes:
  - Make the guard wait on `$dpid`'s `.done` marker first and let the watchdog exit early. A short `sleep` fraction is not POSIX, though Linux and macOS accept it.
  - Run one watchdog across both calls.

### L-2 (partly fixed): overflowing timeout values slip past the cap
- 0, 301, -5, abc, an empty value, " 5" and 007 all exit 2; 1 and 300 are accepted. 1000000000000 is rejected.
- 99999999999999999999 and 9223372036854775808 are not rejected. They make `[ -gt 300 ]` error ("Illegal number" in dash, "integer expression expected" in bash), and the error counts as false, so the value passes the cap.
- The watchdog's `[ -lt ]` then also errors, so its loop is skipped and it kills docker at once. The result is a spurious "did not respond" exit 2, or rc 0 if docker is already done, plus stderr noise.
- This fails on the safe side, but the 1-300 claim isn't fully met.
- Fix: reject long values before any numeric test, for example add `????*)` to the case statement.

Temp worktree /tmp/w1273 and stubs /tmp/stub1273 removed.

## Delta 4 — c988dbab..3f51e7cf (head 3f51e7cf27055b0fba8364c05ab1ddb54041edb9)

**Verdict: code approvable pending CI.** L-3 and L-2 are fixed, and every Delta 3 safety property still holds. CI: Unit Tests is still pending after about 5 min of rechecks; CodeQL and Analyze pass; the other checks are skipping.

- **Head and commit:** head verified. The delta is 1 commit ("build: faster watchdog tick and stricter timeout in clean-caches guard") and changes only the guard script (+12/-4) and its test (+11/-1). There are no W-/T- prefixes and no plan IDs.
- **Static checks and tests:** `sh -n` and `shellcheck -s sh` are clean. The tests pass: dash 104/104 in 25s and bash 104/104 in 26s, with QUICK_MS=326 QUICK_MS=326 . The new `tree_kill` in the test only kills the test's own `within` job tree. The new `now_ms` uses perl, which macOS also ships.
- **Ppid recheck:** unchanged; it still runs before `kill_tree`.
- **Tick math:** `ticks = timeout*10` at 0.1s, so 300 gives 3000 ticks, and `timeout` ticks at 1s. There is no overflow: the timeout is at most 3 digits and at most 300.
- **Fractional-sleep detection:** the guard probes once with `sleep 0.1`, which costs 0.1s. That is portable:
  - macOS and GNU sleep accept 0.1;
  - busybox does without FANCY_SLEEP, and that build fails the probe, so the guard falls back;
  - dash has no builtin sleep.

### Stub repro (python setsid harness)
Docker was a stub on PATH only. "int" mode added a PATH `sleep` stub that rejects non-integer values. Each case was checked for leftover processes in the session at exit and 3s later, and for .timeout and temp files.

| Case | 0.1s mode (dash / bash) | 1s fallback (dash / bash) | Leftovers / files |
|---|---|---|---|
| fast path | 0.32s / 0.32s | 2.01s / 2.02s | none |
| timeout path (3s stub, 2s timeout) | 2 in 2.20s / 2.17s | 2 in 2.04s / 2.04s | none |
| hung stub (sleep 500), 3s / 5s timeout | 2 in 3.17s, 5.21s / 3.18s, 5.21s | 2 in 3.04s, 5.05s / 3.04s, 5.05s | none |
| INT to group (2s stub, 6s timeout) | 130 / 130 | 130 / 130 | none |
| INT / TERM / HUP to guard pid only | 130 / 143 / 129 | 130 / 143 / 129 | none |
| INT to guard pid with hung stub | 130 in 2.5s | 130 in 3.0s | none; the stub's sleep was killed |

No kill happened after exit. The fallback works, and in that mode the fast path is back to about 2s, which is expected.

**Cap:** 99999999999999999999, 1000, 0300 and 301 exit 2 with only the one-line message and no "Illegal number" or "integer expression" noise. 1 and 300 are accepted.

### Info (non-blocking)
- **I-1:** in 0.1s mode the timeout drifts about 4% late (5s → 5.21s), so 300s lands near 312s. This comes from the fork and test overhead on each tick. It fails on the safe side; acceptable.
- **I-2:** the `sleep 0.1` probe costs 0.1s on every run, even when no docker call happens (no docker, or CLEAN_GUARD_DOCKER_FILE set). It could be moved inside the docker branch. Minor.

Temp worktree /tmp/w1273 and stubs /tmp/stub1273 removed.

## Delta 5 — 3f51e7cf..42e70ad3 (head 42e70ad34aed7b4e17f82da45b6d5ff99fa860f2)

**Verdict: code approvable pending CI.** There are no H or M findings and no new fail-open path; FORCE=1 is unchanged. CI: Unit Tests is still pending after about 5 min of rechecks; CodeQL and Analyze pass; the other checks are skipping.

- **Head and commits:** head verified. The delta is 4 commits: aa14f31e, 36fb5361, 48e6c44f and 42e70ad3. It changes only the guard script (+38/-12) and its test (+84). There are no W-/T- prefixes and no plan IDs (the only "plan" match was the word "planted").
- **Static checks and tests:** `sh -n` and `shellcheck -s sh` are clean. The tests pass **121/121** under dash (32s) and **121/121** under bash (32s), which confirms the dev's count. Kills in the test only target its own `within` job tree, its own `$WORK` stub markers, and its own setsid guard group.

### Kill safety
- **Timeout SIGKILL path (guard.sh:208-218):** still gated by `.done`/`.stop`, `kill -0 $guard_pid`, and `ps -o ppid= -p $dpid` == `$guard_pid` (:216) before `kill_tree "$dpid"` (:218). The guard reaps docker only after `wait $wpid`, so `$dpid` is an unreaped child and cannot be reused. OK.
- **Interrupt path (guard.sh:232-238):** `kill_tree "$dpid"` without the ppid compare is safe by construction: the guard itself is the parent and has not reaped it.
- **Scope:** `kill_tree` (guard.sh:176-180) reaches only `$dpid`, its wrapper subshell, and that subshell's descendants. Nothing else is signalled.
- **Wrapper `trap : INT TERM HUP` (guard.sh:196-199):** it catches the signals rather than ignoring them, so docker still gets default handling. Stub repro with a TERM/INT/HUP-deaf docker stub (sleep 500), python setsid harness, dash and bash:
  - timeout 2s exits 2 in about 2.17s;
  - INT, TERM and HUP sent to the group and to the guard pid alone exit 130, 143 and 129 in about 1.03s;
  - in every case there were no session survivors, the private temp dir was gone, and no kill happened after exit;
  - the fast path takes 0.32s.

### Fail-closed changes
- `mktemp -d` private dir with `trap 'rm -rf "$tmpd"' EXIT` (guard.sh:262-264): good; `$tmpd` is always the mktemp result.
- `cat $tmp.out || unreadable` (:278) and `sed || unreadable` (:292): good.
- An unreadable `$tmp.err` on the info path leaves `info_err` empty, which falls to `*) unreadable`, so it fails closed.
- **go -C (awk :123-132):** a spaced or `-C=` directory now makes any later build/test/run word count. That is broader, on the safe side.
- **Node value flags (awk :75-84):** I checked every listed flag on the box's node v20.19.2 with `node <flag> ZZVAL -e …`. Each one consumes the next word as its value (by echo or a value-validation error), so no listed boolean flag can hide the script word and fail open.

### Findings
- **L-4 (Low, guard.sh:176-180):** `kill_tree` lists children and then kills the parent first. After the wrapper is SIGKILLed, the docker grandchild is reparented to init. If docker exits and is reaped between its own `ps` listing and its `kill -KILL`, that pid could in theory be reused. The window is a ps call (about 10ms) and existed before, but the signal is now SIGKILL. Optional hardening: `kill -STOP` the whole tree top-down first, then `kill -KILL`; or kill bottom-up while the parent is still alive.
- **L-5 (Low, guard.sh:233-235):** Ctrl-C/TERM/HUP now also SIGKILL docker (the shared `kill_tree`), not just the timeout path. That is harmless for the docker CLI client, but a TERM-then-KILL in on_signal would be gentler. Optional.
- **I-3 (info, awk :75-84):** the node flag list is still not exhaustive (for example `--test-reporter`, `--test-reporter-destination` and `--localstorage-file` are missing), so `node --test-reporter spec …/cdk` would be missed. This miss existed before (not new fail-open); a follow-up could add them.

Temp worktree /tmp/w1273 and stubs /tmp/stub1273 removed.

## Delta 6 — 42e70ad3..85113103 (head 8511310306d083525edd0b394df4bac29e75080b)

**Verdict: code approvable pending CI.** L-4, L-5 and I-3 are fixed. There are no H or M findings, no new fail-open path, and FORCE=1 is untouched (the only FORCE hits in the diff are the test's `env -u FORCE`). CI: Unit Tests is still pending after about 5 min of rechecks; CodeQL and Analyze pass; the other checks are skipping.

- **Head and commit:** head verified. The delta is 1 commit (85113103). It changes only the guard script (+28/-7) and its test (+51/-4). There are no W-/T- prefixes and no plan IDs.
- **Static checks:** `sh -n` and `shellcheck -s sh` are clean.
- **Tests:** dash **127/127** in 38s and bash **127/127** in 39s, with 0 FAIL and rc 0. **The dev's claim of 128/128 is off by one.** The load-gate logs (r4-*, 18:10) also show 127 PASS lines. Their .res files say `rc=0 40`, so the "8/8 load gate" means 8 runs at rc 0. The new test kills only its own setsid guard group and its `$WORK` stubs.

### signal_tree review (guard.sh:177-194)
- **PID reuse:** the walk does STOP before it lists children, so a stopped parent cannot reap its children. A listed child that exits stays a zombie, so its pid cannot be reused before the STOP, the signal or the CONT. The root `$dpid` is the guard's unreaped child. On the timeout path the ppid recheck (guard.sh:230) still runs before `kill_tree`. The walk only reaches descendants of `$dpid`. OK.
- **Already-exited members:** `kill -STOP || continue` skips them. A zombie member is still STOPped (that succeeds), but it has no children to list.
- **Grandchildren of an already-exited member:** they are reparented to init, so the walk cannot reach them. This is the same as before and only affects the docker CLI's own children.
- **Portability:** STOP, CONT, `kill -SIG` and `ps -A -o pid= -o ppid=` are POSIX and work on macOS.
- **Ordering:** KILL is delivered while a process is stopped. TERM stays pending until CONT, and then the process acts on it. Both are correct.
- **on_signal (guard.sh:246-258):** sends TERM, then polls `.done` for up to grace ticks (10×0.1s, or 1×1s in fallback), then KILL. The wrapper's `trap :` keeps it alive through TERM, so it waits for docker and writes `.done`. OK.

### Repro (stub docker that ignores TERM/INT/HUP and hangs in sleep 500)
I used a slow `ps` PATH stub (+1.5s per walk listing) to widen the STOP/CONT window. The guard ran under a separate process group whose parent was in the same session, like `make` under an interactive shell, so the kernel's orphaned-pgrp SIGCONT could not mask a missed CONT. Each case was checked 12s later for leftover and `T` (stopped) processes. Dash and bash gave the same results.

| Case | rc | Leftovers | Stopped |
|---|---|---|---|
| timeout 2s | 2 | none | 0 |
| TERM to guard pid | 143 | none | 0 |
| INT to guard pid, slow walk | 130 | none | 0 |
| timeout, slow walk | 2 | none | 0 |
| **SIGKILL guard + watchdog mid-walk (timeout path)** | 137 | wrapper, docker stub, sleep | **1 (wrapper)** |
| **TERM, then SIGKILL guard mid-walk** | 137 | wrapper, docker stub, sleep | **1 (wrapper)** |

Every normal exit path (timeout, INT, TERM, HUP, docker already done) leaves nothing stopped. After my runs, a box-wide `ps` showed no T-state processes. My own dummy stub processes were CONTed and KILLed by session id.

### Findings
- **L-6 (Low, guard.sh:180-193): a SIGKILL during the walk leaves the docker wrapper stopped.** If the guard (or watchdog) is SIGKILLed between STOP and CONT, the wrapper stays in state T. Docker itself keeps running, as it would have before this change.
  - It recovers only when the process group becomes orphaned (the parent `make` exits): the kernel then sends HUP+CONT.
  - This is not fixable in-process. SIGKILL can't be trapped, and the guard's cleanup already can't run on SIGKILL.
  - It needs a SIGKILL timed inside the walk, which takes milliseconds in practice. Documenting it is enough; optionally, CONT each node right after signalling it.
- **I-4 (info):** the claim of 128/128 tests is really 127/127. Ask the dev to correct the number; nothing is missing.
- I-3 is fixed: `--test-reporter`, `--test-reporter-destination` and `--localstorage-file` were added.

Temp worktree /tmp/w1273 and stubs /tmp/stub1273 removed.

## Delta 7 — 85113103..76e951f6 (Copilot R1 fixes), head 76e951f6

**Verdict: CHANGES REQUESTED** (H-1, M-1). CI: Unit Tests pending after a 5-min recheck, CodeQL/Analyze pass, the rest skipping. Tests: 130/130 PASS on dash and bash. `sh -n` and `shellcheck -s sh` are clean on the guard and its test. No W-/T- prefixes or plan IDs.

### H-1 (High): Ctrl-C SIGKILLs pids that are already reaped and may have been reused (guard.sh:255-267)
`termed=$tree` (258) holds the pid list across the CONT and the ~1s grace. The loop at 265-266 then sends `kill -KILL` to every pid except `$dpid`. It does this **without checking `.done`, and without checking that the pid still belongs to the tree**. The common Ctrl-C path is: docker exits on TERM, the wrapper subshell reaps it, and its children are reaped by init. That frees those pids during the grace, so a recycled pid gets SIGKILL. This breaks Mario's never-kill-anything-unrelated rule. The comment's claim that a reuse is "very unlikely" doesn't make it safe.
Repro (stub, instrumented copy, dash and bash): docker stub plus a `sleep 500` child, then TERM the guard. The log shows `KILL <sleepchild> GONE` and `KILL <docker> GONE`: both KILLs go to pids that no longer exist, on every interrupt. (I couldn't force an actual reuse because there is no ns_last_pid access, but the KILL to a freed pid is proven.)
**Fix** (verified on an uncommitted copy: 130/130 on dash and bash, shellcheck clean, the TERM-deaf orphan test still passes, the repro sends zero KILLs to dead pids, no T-state processes left, no leftovers):
```sh
# signal_tree: after the STOP walk, while everything is still stopped
  snap=""
  for p in $tree; do snap="$snap$p|$(ps -o lstart= -p "$p" 2>/dev/null)
"; done
  for p in $tree; do kill "-$1" "$p" 2>/dev/null; done
  for p in $tree; do kill -CONT "$p" 2>/dev/null; done
# on_signal
    signal_tree TERM "$dpid"
    termed=$snap
    ...grace loop unchanged...
    kill_tree "$dpid"   # always: re-walk under STOP from the unreaped wrapper, so only current, pid-held descendants get KILL
    printf '%s\n' "$termed" | while IFS='|' read -r p st; do
      if [ -n "$p" ] && [ "$p" != "$dpid" ] && [ -n "$st" ] &&
        [ "$(ps -o lstart= -p "$p" 2>/dev/null)" = "$st" ]; then
        kill -KILL "$p" 2>/dev/null   # orphaned TERM-deaf child, same start time as at TERM
      fi
    done
```
The re-walk covers everything that is still in the tree. The start-time check covers TERM-deaf orphans that have been reparented to init. A pid that was reaped or reused has a different or empty lstart, so it is skipped. The only remaining risk is the microsecond gap between ps and kill, which is inherent without pidfd. `lstart` works on procps and BSD/macOS; if strict POSIX is required, `etime` with a ±1s tolerance is the fallback. Snapshotting while the tree is stopped is what makes each identity valid at TERM time.

### M-1 (Medium, fail-open regression): the node flag-value join swallows a relative script path (guard.sh:102)
`i = prog_end(a, n, i + 1)` joins every following word that matches `^[A-Z][^/]*/`. If the value sits under /Users|/home|/Volumes|/Applications and the script is relative with a capitalised first folder, the script is absorbed into the value. The active run is then missed and the clean goes ahead.
Repro (CLEAN_GUARD_PS_FILE fixture):
- `node --env-file /Users/x/.env Tools/cdk/bin/cdk deploy`: 85113103 blocks (rc1), 76e951f6 **passes (rc0)**.
- `node -r /home/x/hooks/reg.js Projects/infra/node_modules/aws-cdk/bin/cdk synth`: same regression.
- The new spaced case `--env-file /Users/x/My Project/.env /opt/...cdk` is correctly blocked now.
**Fix:** read the command both ways and block if either reading finds a tool. In `first()` keep the joined index, and also compute the unjoined index (`i++`). In the node/npx branch: `return tool(pkg(a[prog_end(a,n,i_join)]))` || `tool(pkg(a[prog_end(a,n,i_plain)]))`. Add the two repro lines above as blocking cases.

### I-5: the comment at guard.sh:253-256 should describe the identity check, not the claim that "a reused pid is very unlikely".
STOP/CONT: no T-state processes were left in any run (orig or fixed).

## Delta 8 — 76e951f6..953aebce (fixes for H-1, M-1, I-5), head 953aebce

**Verdict: APPROVABLE PENDING CI.** H-1, M-1 and I-5 are resolved. Two Low and three Info findings remain, none blocking. CI: Unit Tests still pending after a 5-min recheck, CodeQL/Analyze pass, the rest skipping. Tests: **136/136** PASS on both dash and bash, which matches the claim. `sh -n` and `shellcheck -s sh` are clean on the guard and its test. No W-/T- prefixes or plan IDs.

**H-1 resolved** (guard.sh:201-247, 300-324). The snapshot is taken under STOP in `signal_tree`. `kill_tree "$dpid"` (315) now always re-walks from the unreaped wrapper. Orphans go through `kill_orphan`, which checks identity.
- My instrumented repro logged every candidate *before* the filter. It used a stub docker with a sleep child and covered TERM and INT on dash and bash (8 runs). In the plain case both candidates were `GONE` and **no KILL was sent**. In the TERM-deaf case the orphan was `alive` and got `KILLSENT`, while docker's pid was GONE and skipped.
- Every run exited 130 or 143 with no leftovers and nothing in T state.
- Unit checks of `kill_orphan` against a live process: a wrong lstart, an empty snapshot, or an E-vs-L mismatch all leave it alive. A matching snapshot kills it.

**M-1 resolved** (guard.sh:96-104, 124-133, 155). Both regression commands block (rc 1) and the spaced-path case still blocks. The dual reading combines the two readings with OR, so it can't fail open compared with either one alone. FORCE=1 is intact (rc 0 with the warning).

**Hook (CLEAN_GUARD_KILL_TRACE, 209-211, 243-245)**
- It only appends a "KILL pid alive|GONE" line.
- It doesn't change control flow or exit codes. `kill -KILL` runs whether or not the redirect fails.
- I tested an unset, empty, space, `-` and an unwritable-dir value: each was safe and the KILL still happened. The unwritable path printed one stderr line.
- Its contents are fixed and it appends only, to a path the caller already controls through the environment, so there's no new write risk.
- It's documented as "tests only" inline, but it's missing from the env list in the header (lines 20-40); see I-6.

### L-7 (Low): 1s identity granularity (guard.sh:214-234)
`lstart` has 1s resolution, and the etime fallback allows ±1s, so the window is effectively about 2s. A pid reused by a process that starts in the same second (lstart) or within ±1s (etime) would match. That needs a pid wrap within about a second of TERM, and in etime mode it can only happen where ps lacks lstart (not on Linux procps or macOS). Suggestion: add `comm=` (or `args=`) to the identity, e.g. `echo "L $st|$(ps -o comm= -p "$1")"`, so a reuse also has to match the command name.
### L-8 (Low, defensive): `same_start` matches malformed E values (guard.sh:232)
`same_start "Ex" "Ey"` returns 0: the arithmetic treats `Ex`/`Ey` as unset variables, gets 0, and reports a match. This can't happen today because `start_id` always prints `E %d`. Still, guard it with `case ${1#E } in ''|*[!0-9-]*) return 1;; esac` for both arguments.
### I-6: `CLEAN_GUARD_KILL_TRACE` is missing from the header's env list (20-40), and its comment (208-210) sits above `start_id` instead of `kill_orphan`.
### I-7: the trace is written after the identity filter. The "no GONE" tests do catch a broken filter, but they don't cover the `kill_tree` re-walk path.
### I-8 (pre-existing, not a regression): `npx --prefix /Users/x/My Dir exec Tools/cdk/bin/cdk deploy` is not blocked (rc 0 at 85113103, 76e951f6 and 953aebce). A spaced final component with no slash is inherently ambiguous once ps drops the quotes. Worth a documented known limit or a follow-up.
POSIX/portability: no bashisms (shellcheck -s sh clean). `ps -o lstart=` works on procps and BSD/macOS, `ps -o etime=` is POSIX, and `date +%s` works on GNU, BSD and busybox.

## Delta 9 — 953aebce..76d8c818 (round 7 + Copilot R1-R3), head 76d8c818 — FINAL gate

**Verdict: CHANGES REQUESTED — one Medium (M-2), a one-line fix.** Nothing here breaks the never-kill-unrelated rule: every kill path is either pid-held or identity-checked. But on Linux with bash as `sh`, M-2 lets a TERM-deaf orphan survive Ctrl-C. CI: Unit Tests still pending after a 5-min recheck, CodeQL/Analyze pass, the rest skipping. Tests: **158/158** PASS on dash and on bash, which matches the claim. `sh -n` and `shellcheck -s sh` are clean. No W-/T- prefixes or plan IDs.

### M-2 (Medium): under bash, the bare `return` in `same_start` returns the trap's status, so orphans are never KILLed (guard.sh:263)
`if [ "$k1" = P ]; then [ "$v1" = "$v2" ]; return; fi`. `same_start` runs from `on_signal`, which is a trap. In a trap handler, bash makes a bare `return` use the status from *before* the trap (here the interrupted `wait`, e.g. 130 or 138). `bash --posix` does the same; I confirmed `trap-f-rc=138`.
- Repro: stub docker with a TERM-deaf child, guard run under bash. The trace shows `snap=[P|12257310|sleep] now=[P|12257310|sleep]` but no KILL, and `sleep 501` is left running after both TERM and INT. dash is unaffected.
- This hits Linux hosts where `/bin/sh` is bash (Fedora/RHEL/Arch), and any `bash guard.sh`. macOS uses the L branch, which doesn't end in a bare return, so it isn't affected.
- It's fail-safe for the rule, since it kills less, but it regresses H-1's orphan cleanup.
- **Fix:** `if [ "$k1" = P ]; then [ "$v1" = "$v2" ] && return 0; return 1; fi`. Verified on a copy: the orphan is KILLed on bash and dash, TERM and INT, and with ps -A failing; shellcheck is clean.
- **Test gap:** both suite runs launch the guard as `$launch sh "$SCRIPT"`, so it always runs under dash and the bash run never covers the guard. Run the guard under the shell being tested (e.g. `${GUARD_SH:-sh}`) and add a bash pass.

### Kill-path audit (rule check)
- **(a) pgrep fallback** (guard.sh:217-223): `children` is called from `signal_tree` after `kill -STOP "$p"`, so the walk is still under STOP. pgrep -P exists on macOS (10.8+) and procps. Repro with a stub ps that fails only for `-A`: the orphan and the tree were handled correctly. If pgrep is missing as well, no children are listed and only the unreaped wrapper gets KILL; hung docker and its children are left (I-9). That's fail-closed: exit 2, nothing deleted, nothing unrelated touched.
- **(b) ppid-lookup failure** (guard.sh:316-323): `dpid=$!` comes from a top-level `( … ) &` in `docker_run` (called at 403-404, not inside `$( )`), so it is the guard's direct child. It stays unreaped until the watchdog exits, so `kill_tree "$dpid"` hits a held pid, and the walk below it runs under STOP. Repro with a stub ps whose `-o ppid= -p` fails: hung docker and its child were KILLed, exit 2, nothing left, nothing else touched.
- **L-9 (Low):** an empty `pp` also means "dpid is gone". That only happens if the guard died and init reaped dpid in the few ms after the `kill -0 $guard_pid` check. Previously, ppid=1 would have made the watchdog exit. Hardening: add `kill -0 "$dpid" 2>/dev/null || exit 0` before the kill (a zombie still passes), and re-check `kill -0 "$guard_pid"`.
- **(c) /proc starttime** (guard.sh:231-235): `sub(/.*\)/, "")` is greedy, so it cuts after the last `)`, and `$20` is field 22. Verified with comm `a) b (c) 9 9`, which gave `P|12262323|…` and matched field 22. Detection uses `[ -r /proc/PID/stat ]`. A kind mismatch between snapshot and recheck never matches, which is the safe side. Malformed or empty numeric values are rejected (L-8 is fixed).
- **(d) repeat signal** (guard.sh:340): `trap '' INT TERM HUP` is the first line of `on_signal`. A double INT 0.2s apart ran cleanup once: rc 130, nothing stopped, nothing left. The EXIT trap still removes the tmp dir.
- **(e)** Fail-closed and FORCE=1 are unchanged. Nothing was left in T state in any run (16 runs on dash and bash). L-7 is fixed (/proc ticks plus comm; lstart plus comm on macOS). I-6, I-7 and I-8 are addressed.
### I-9: if both ps -A and pgrep fail, the hung docker child survives the timeout (fail-closed). Optionally mention it under Known limits.

## Delta 10 — 76d8c818..0d55cd67 — APPROVED (conditional on Unit Tests)

Head SHA verified: 0d55cd6710c9f682e41ba2f31eb5614276b555dd.
- M-2 fixed. same_start now ends the L, P and E branches with `&& return 0; return 1`. No bare `return` is left in any trap path; grep finds only a comment. No other bash-vs-dash trap differences were found.
- GUARD_SH wiring is correct. It defaults to bash when BASH_VERSION is set, else sh, and every launch goes through `"$GUARD_SH" "$SCRIPT"`.
- Red then green confirmed. The new suite against the 76d8c818 guard gives dash 161/0 and bash 156 pass, 5 fail. Those 5 are the orphan and TERM-deaf cases, as the dev claimed. At 0d55cd67: dash 161/161 and bash 161/161.
- Instrumented repro, on dash and bash. A deaf orphan under TERM, INT, INT with ps -A failing, and a double INT: the orphan is alive, gets KILLSENT, and is gone. No KILL goes to a GONE pid. rc is 143 or 130. Nothing is left over and nothing is stopped. With plain docker, the candidates are all GONE and no KILL is sent.
- L-9 and the guard-alive recheck: no fail-open. A hung docker with ppid failing, or with ps -A failing, gives rc 2 with no leftovers on both shells. `kill -0 dpid` can only fail after the guard reaps dpid, so the watchdog exiting 0 cannot turn into a guard exit 0.
- The FORCE=1 path is unchanged (lines 438-446). The script is POSIX: sh -n and shellcheck -s sh are clean. There are no W-/T- prefixes or plan IDs in the commits or the diff.
- Findings: none new. I-9 is documented as a known limit.
- CI: Unit Tests is pending. CodeQL and both Analyze checks pass; the rest are skipping.
