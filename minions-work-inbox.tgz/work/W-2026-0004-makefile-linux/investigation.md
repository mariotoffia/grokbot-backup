# W-2026-0004 — teos Makefile Linux/macOS compatibility audit (P-2026-0004-01)

Owner: release-config-mgr · Planning only: no repo files changed.
Repo: /workspace/repos/teos (HEAD a3543337, `git status` clean).
Method: read 171 tracked Makefiles/.mk files (108 build Makefiles, 63 `_design` doc Makefiles; one shared include `docs_meta.mk`); parsed all 754 targets and checked each recipe for portability patterns; read the /workspace/lintarch logs and w0-env.md; ran read-only checks (`make -n install|generate|lint-arch`, `make help`, `command -v`, `go env`, `npm prefix -g`).
Status labels: **verified** = seen in logs or a read-only run; **inferred** = from reading only. COND = works only when an external service or an earlier step is in place (kroki on :8000, `make dep` done, PATH set).

## Summary
- Targets audited: **754** (in 171 files)
- Linux failing: **227** (17 verified, 210 inferred). Another 160 are COND (kroki/asciidoctor docs targets).
- macOS failing: **0 hard failures found**. 346 are COND (same `~/go/bin`/cdk PATH assumption, kroki, act/restic installs).
- Box facts (verified): non-login PATH has no `~/go/bin` and no `~/.local/bin` (npm -g prefix=`~/.local`, so `cdk` and `pnpm` installed there are invisible); `go env GOBIN`=/home/box/go/bin; `COREPACK_HOME=/usr/local/share/corepack` (root-owned); shell user `box` is not in the `docker` group in this session (socket 660 root:docker); `zip`, `lsof`, `act`, `makensis`, `asciidoctor`, `restic`, `brew` missing; `zsh` now installed.

## Root causes (grouped)
| # | Cause | Where | Linux | macOS |
|---|---|---|---|---|
| R1 | Bare `~/go/bin` tools (go-arch-lint, golangci-lint, oapi-codegen, scc, cb*) | root lint/lint-arch/lint-go/stats, 9 per-service `lint-arch`, generate-code in 6 Makefiles | FAIL 127 (verified) | COND (Go pkg installer puts only /usr/local/go/bin on PATH) |
| R2 | `install`: `sudo apt-get update` with no retry; `wget`+`sudo dpkg -i` pandoc; `curl latest` opa + `sudo install /usr/local/bin`; npm -g needs a writable prefix | root Makefile:80-86 | FAIL HTTP 500 (verified) | OK (brew branch) |
| R3 | corepack cache in root-owned `/usr/local/share/corepack` | every pnpm/npx target (web, documentation/asciidoc, cmd/tklocal webui) | FAIL (verified) | OK (brew node; user-owned prefix) |
| R4 | `docker run` openapi-generator needs socket access; `generate-code: clean-generated` deletes tracked `model_*.go`/`client.go` BEFORE docker runs, so a failure leaves 45 tracked files deleted | go-services/model, go-core/model | FAIL + destructive (verified) | OK, but the same destructive behaviour on any failure (inferred) |
| R5 | `export SHELL=/bin/zsh` | root, go-services, deployment/lib | needs zsh (verified, first run failed) | OK |
| R6 | `sed -i ''` hardcoded | documentation/ai/Makefile:86 (ppt target) | FAIL (inferred) | OK |
| R7 | Ad-hoc `ifeq darwin` sed macro, duplicated | go-core/model, go-services/model `find_and_replace` | OK (inferred) | OK; but scattered OS logic, and `@cd ./scapi` is a no-op |
| R8 | brew-only installs | devops/gh-backup install, realestatecore/_design, act hint | FAIL (inferred) | OK |
| R9 | Missing Debian tools: lsof (tklocal serve-stop), zip (devops-clean-table), makensis (tklocal installer), cdk on PATH (120 deployment targets) | listed | FAIL (inferred) | OK/COND |
| R10 | Recursive loops end in `; true` / `|| true` so sub-make failures are swallowed (34 targets: meta/go-core/go-services/web generate-api|code, clean, dep scanners) | aggregators | hides failures (inferred) | same |
| R11 | Hardcoded `/tmp/...` pid/log files, `~/teos` data dir, `GOCACHE=/tmp/ceos-gocache` | cmd/tklocal, nodabuilding/cmd/noda | OK (inferred), but not multi-user safe | macOS `$TMPDIR` ignored |
| R12 | `GOOS= $(shell uname -s ...)` duplicated in 6 Makefiles; `setenv` is a phony target that only carries conditionals | root, go-core, go-services, deployment/lib, meta, realestatecore | OK | OK (cleanup item) |
No GNU-only `readlink -f`, `date -d/-v`, `stat -c/-f`, `grep -P`, `xargs -r` found in Makefiles (scripts/hooks note about grep -P already avoided). `find -mindepth`, `xargs -0`, `grep -E \s`, `sed -E -i.bak` are portable to both.

## (a) Per-target matrix — key targets
| Makefile | Target | Linux | macOS | Root cause |
|---|---|---|---|---|
| Makefile | install | FAIL (verified) | OK (inferred) | R2, R5; npm -g prefix |
| Makefile | dep | FAIL (verified) | OK (inferred) | R3; chains install |
| Makefile | generate / generate-code | FAIL (verified) | OK (inferred) | R4, R1 (oapi-codegen), R3 (web) |
| Makefile | generate-api | OK (inferred) | OK (inferred) | R10 swallows errors |
| Makefile | generate-provision | OK (inferred) | OK (inferred) | - |
| Makefile | lint-arch | FAIL (verified) | COND (inferred) | R1 |
| Makefile | lint / lint-go / lint-fix | FAIL (verified/inferred) | COND (inferred) | R1 |
| Makefile | build | PASS only with env workaround (verified) | OK (inferred) | R1/R3 env |
| Makefile | test, vet, cover, benchmark, test-integration*, test-e2e*, test-service* | OK (inferred) | OK (inferred) | integration/e2e need docker group on Linux |
| Makefile | stats | FAIL (inferred) | COND | R1 (scc) |
| Makefile | act-lint / act-test | FAIL (inferred) | COND | act missing; brew hint; docker group |
| Makefile | fmt-ts / fmt-check-ts / web-* | FAIL (inferred) | OK | R3 |
| Makefile | docs, docs-generate, docs-antora | COND (inferred) | COND | kroki :8000, asciidoctor after dep |
| Makefile | clean*, install-hooks, help, release*, dependabot-* | OK (help verified) | OK (inferred) | R10 in clean |
| go-services/model/Makefile | generate-code | FAIL + destructive (verified) | OK, destructive on failure | R4, R7 |
| go-core/model/Makefile | generate-code | FAIL (inferred) | OK | R4, R7 |
| web/Makefile | install / generate-code / build / lint | FAIL (verified for generate-code) | OK | R3 |
| */Makefile (9 services) | lint-arch | FAIL (verified) | COND | R1 |
| */deployment/Makefile | deploy/synth/diff (cdk) | FAIL (inferred) | COND | cdk in ~/.local/bin not on PATH |
| documentation/ai/Makefile | ppt target (sed -i '') | FAIL (inferred) | OK | R6 |
| cmd/tklocal/Makefile | serve-stop (lsof), windows installer (makensis) | FAIL (inferred) | OK | R9 |
| devops/gh-backup/Makefile | install & restic targets | FAIL (inferred) | OK/COND | R8 |
| devops/handlers/devops-clean-table/Makefile | zip / deploy | FAIL (inferred) | OK | zip missing |
| */_design/Makefile (63) + docs_meta.mk | docs-generate / docs | COND (inferred) | COND | kroki, asciidoctor |

Full per-target matrix (all 754 rows) is in the Appendix.

## (b) Proposed task list
| ID | Scope | Owner | Effort | Acceptance criteria | Depends |
|---|---|---|---|---|---|
| T1 | Add `make/os.mk` detect layer + `make/os/{linux,darwin}.mk`; include once from root and the 6 Makefiles that duplicate GOOS/GOARCH; remove `setenv` conditionals | release-config-mgr | M | `make -n` output unchanged on macOS; no `ifeq ($(GOOS)` / `uname` outside make/os*; `make help` OK on both | - |
| T2 | Tool resolution: `GOBIN ?= $(shell go env GOBIN)` falling back to `$(go env GOPATH)/bin`; `export PATH := $(GOBIN):$(NPM_BIN):$(PATH)` in os.mk; same for npm global bin | release-config-mgr | S | On a clean non-login Debian shell `make lint-arch` and the cdk targets no longer exit 127; macOS unchanged | T1 |
| T3 | Linux `install`: apt with `-o Acquire::Retries=5`, retry loop around `update`, optional `APT_MIRROR`; `SUDO ?= $(if root,,sudo)` + preflight check; pin opa version + checksum; pandoc deb with retry; `npm -g` into user prefix | release-config-mgr | M | `make install` succeeds on the box through a simulated mirror 500 (retry seen in log); runs as root without sudo; macOS brew path unchanged | T1 |
| T4 | Corepack: `export COREPACK_HOME ?= $(XDG_CACHE_HOME or ~/.cache)/node/corepack` in os.mk (only override when the default dir is not writable) | release-config-mgr | S | `make dep` passes on the box with no manual env; `pnpm --version` works from web/ | T1 |
| T5 (superseded by T5 extended below) | Atomic, non-destructive codegen in go-services/model and go-core/model: generate into a temp dir, docker preflight (`docker info`, clear message about docker group/`sg docker`), swap in only on success, no `clean-generated` prerequisite; one portable `sed -i.bak`/`perl -pi` helper instead of the darwin macro; fix the `@cd ./scapi` no-op | release-config-mgr | M | Forced docker failure leaves `git status` clean; a successful run produces a byte-identical tree; works on macOS | T1 |
| T6 | Make recursive aggregators propagate failures (drop `; true` / `|| true` in generate-api/code, dep, build scanners) | release-config-mgr | S | A failing sub-make makes the parent exit non-zero; review lists every changed loop | - |
| T7 | Replace hardcoded GNU/BSD calls: documentation/ai `sed -i ''` → portable helper; lsof → `$(PORT_PIDS)` from os layer (lsof/fuser/ss); tklocal `/tmp` pid/log → `$(TMPDIR)`; document zip/makensis/act/restic per OS in os/*.mk install lists | release-config-mgr | S | ppt and serve-stop targets pass on Debian and macOS; no `sed -i ''` left | T1 |
| T8 | SHELL: replace `export SHELL=/bin/zsh` with `SHELL := bash` + `.SHELLFLAGS := -eu -o pipefail -c` after checking the regexps the comment refers to; or keep zsh and add it to the Linux install list | release-config-mgr | M | Full workflow (install→dep→generate→build→test→lint) green on Debian without zsh, or zsh installed by `make install`; macOS green | T1, T5 |
| T9 | Preflight `make doctor` target: checks tools, PATH, docker access, COREPACK_HOME, kroki; prints OS-specific fixes | release-config-mgr | S | `make doctor` lists every missing item seen in this audit on the box; exits 0 on a ready macOS | T1-T4 |
| T10 | Docs: update README/DEVELOPMENT/AGENTS with Linux (Debian) setup, docker group, env vars, macOS notes | technical-writer | S | Docs match the new Makefile behaviour; reviewed by release-config-mgr | T1-T9 |
| T11 | CI parity: run install→dep→generate→build on ubuntu and macos runners, plus a "generate fails cleanly" check | platform-lead | M | Both jobs green; failure test asserts a clean `git status` | T5, T8 |
| T12 | Review the Makefile/os-layer change set for regressions and security (sudo, curl downloads, checksum pins) | code-reviewer (+ security-auditor for T3) | S | Approved review; no unpinned downloads run as root | T1-T9 |
| T5 (extended) | Atomic, non-destructive codegen for ALL generate-code targets: go-services/model, go-core/model AND go-services/providers/eastbound/sur (and any other `rm`-before-`docker run` target found by grep); generate into `$(RUN_TMP)/gen`, docker preflight, swap on success only (covers gitignored outputs), drop `clean-generated` from `generate`; pin `openapi-generator-cli:latest` and `goimports@latest` | release-config-mgr | M | Forced docker failure leaves both tracked and gitignored generated files untouched (checksum before/after); success gives an identical tree; no `:latest`/`@latest` in generate recipes | T1, T13 |
| T13 | Per-run/per-worktree isolation in Makefiles: `RUN_ID`, `RUN_TMP` (mktemp -d, exported TMPDIR, trap cleanup of own dir only) in tools.mk for test*, generate*, lint targets; per-checkout `flock` on generate/clean-generated | release-config-mgr | M | Two `make generate` in the same checkout serialize; in different worktrees they run concurrently without touching each other's files; no target writes fixed `/tmp/...` names | T1 |
| T14 | Harness cert isolation (localenv/svctest/cbtest): CA file in a per-environment private dir, owner record (pid+start time), removal only by recorded path or when owner is dead; `Remove`/`cbtest local stop` refuse to delete files of a live owner unless `--force`; children get the cert via inherited path but never own it | golang-pro | M | New test: two concurrent environments plus a stop of one leave the other's CA readable; a child attached via TEOS_TEST_ENVIRONMENT can't delete the creator's file; existing localenv/svctest tests green | T13 |
| T15 | clean-temp hardening: exclude `teos-*-ca-*.pem` and `teos-run-*` dirs whose owner is alive (or narrow `teos-*` to `teos-lambda-*`); test in clean-temp_test.sh | release-config-mgr | S | clean-temp run during a >60 min integration run keeps its CA file; self-test covers it | T14 |
| T16 | Parallel-run regression: corerouter test-service + test-integration (+ make generate in another worktree) run concurrently in CI/box job and must all pass | qa-lead (test design by test-designer) | M | Concurrent job green 3 runs in a row; job fails if any CA/generated file disappears mid-run | T5, T13, T14 |
| T17 | Workspace rule: batch/audit runners use their own clone or worktree and honour minion worktree locks; document in CONVENTIONS.md / runner scripts (e.g. /workspace/lintarch/run.sh) | release-config-mgr | S | Runner refuses to run in a locked worktree; convention text merged and acknowledged by dev-lead | - |

## Recommended os-layer design
```
make/
  os.mk          # included first by every top-level Makefile: include $(dir $(lastword $(MAKEFILE_LIST)))../make/os.mk
  os/darwin.mk   # PKG_INSTALL := brew install; SED_I := sed -i ''; PORT_PIDS = lsof -ti :$(1)
  os/linux.mk    # PKG_INSTALL := $(SUDO) apt-get -o Acquire::Retries=5 install -y; SED_I := sed -i; PORT_PIDS = ...
  tools.mk       # GOBIN, NPM_BIN, PATH export, COREPACK_HOME default, docker preflight, tool vars (GO_ARCH_LINT := $(GOBIN)/go-arch-lint)
```
- `os.mk`: one place that sets `HOST_OS`/`HOST_ARCH` (normalising x86_64→amd64, aarch64→arm64), `GOOS ?=`/`GOARCH ?=`, then `include os/$(HOST_OS).mk` and `tools.mk`. No `ifeq` on OS anywhere else.
- Recipes only use variables (`$(PKG_INSTALL)`, `$(SED_I)`, `$(GO_ARCH_LINT)`); OS packages are listed as data (`OS_PACKAGES := ...`) in each os/*.mk, so `install` is one recipe.
- Prefer the portable form where one exists (for example `sed -i.bak … && rm *.bak`, `perl -pi -e`) so the os layer stays small.
- No sudo unless needed: `SUDO := $(if $(filter 0,$(shell id -u)),,sudo)`; user-writable defaults (XDG cache, npm user prefix) so nothing writes to /usr/local after install.
- Codegen always writes to a temp dir and swaps in only on success.
- `make doctor` reads the same variables, so detection and diagnostics can't drift apart.

## Shared mutable state (addendum)

### 1. sur model files deleted at 12:53 in the T-27.21 worktree
**Root cause:** a `make install → dep → generate → lint-arch` batch (the runs logged in /workspace/lintarch) ran `make generate` directly inside golang-pro's worktree `work/git-worktree/W-2026-0001-t27-21-shadow-metadata-timestamps`. `go-services/providers/eastbound/sur/Makefile` `generate-code` runs `rm -rf model/surmodel/model_*.go` first and only then `docker run` openapi-generator. Docker failed with "permission denied" (Error 126), so the 17 files were not rebuilt. They are gitignored (`model/surmodel/.gitignore: model_*.go`), so the runner's `git checkout -- .` could not bring them back.
The paths were not shared: every path is relative or `$(CURDIR)`-based, and the docker mounts are `${CURDIR}:/model`. That rules out the "resolved to a shared location" hypothesis. The shared state was the worktree itself, used by two agents with no lock.

Evidence:
- Verified: `/workspace/lintarch/t2721-gen.log` runs in `/workspace/repos/teos/work/git-worktree/W-2026-0001-t27-21-…/go-services/providers/eastbound/sur`. Its lines 262-268 show `generate-code` failing on docker.sock with Error 126.
- Verified timing: install 12:52:02, dep 12:52:39, gen ended 12:53:24, lintarch 12:53:28 (file mtimes, Europe/Stockholm). This matches the 12:53 deletion golang-pro reported (W-2026-0001 STATUS.md 13:12 line).
- Verified: the same runner (`/workspace/lintarch/run.sh`, mtime 12:53:44) then emptied surmodel in t27-10, t27-12 and t27-25 (dir mtimes 12:54:36-38) and later in t27-20 and t27-16-2 (13:03-13:04). Those worktrees still have 0 model files now. t27-21 was regenerated by golang-pro at 13:02:44. Tracked damage was restored by `git checkout`, but ignored generated files were not.
- Verified: in this worktree, root `clean`/`clean-generated` loops exclude `./work/*` with depth ≤ 3. So a run in the main checkout cannot reach the nested worktrees under `work/git-worktree/`. I found no cross-worktree path leak.
- Inferred: I couldn't see who started the batch, because the logs carry no PID or user. I didn't need reflog: no commits were involved, only gitignored files.
- Extra risks seen: the sur Makefile uses `openapitools/openapi-generator-cli:latest` and `goimports@latest`, which are unpinned and non-reproducible. Its `generate` target runs `clean-generated` before it runs `generate-code`.

### 2. Harness CA certificate deleted during parallel corerouter + test-integration runs
**How certificates work:** `cbtest local exec` (root `test-integration`) creates environment `teos-<pid>-<rand>`. It writes the emulator CA to the shared system temp dir as `os.CreateTemp("", "teos-<envID>-ca-*.pem")` (`go-core/utils/testutils/localenv/certificates.go`). It exports `AWS_CA_BUNDLE`, `NODE_EXTRA_CA_CERTS` and `TEOS_TEST_ENVIRONMENT` to every child process.
The names are unique, but ownership is decided by a name glob in a global directory. Two paths delete by pattern instead of by recorded owner:
- `localenv.Remove(id)` / `cbtest local stop` (`lifecycle.go` `certificateFiles` = Glob `$TMPDIR/teos-<id>-ca-*.pem`).
- `make clean-temp` (`scripts/clean-temp/clean-temp.sh` pattern `teos-*`, age > 60 min). This also matches every live CA file of a long run, and the cbtest exec process only names the env ID on its command line, not the file name.
Nothing scopes temp state per run or worktree, and child processes inherit `TEOS_TEST_ENVIRONMENT`, so anything that stops or removes "the selected environment" deletes the creator's file.

- Verified: the first `test-integration` run (env `teos-2381914-223123`, file `/tmp/teos-teos-2381914-223123-ca-480989026.pem`) lost that file. The first read failure was at 12:24:37 in the gobridge module (`/workspace/t2721/test-integration.log` line 65562). Every later module failed with "no such file".
- Verified: the parallel corerouter service-test (ended 12:17:05) started its own environment `teos-2647781-726010`. It did not attach to the cbtest one. The code it runs (`svctest.stop` → `Environment.Close` → `releaseCertificate`, plus `forgetCABundle`, which only unsets variables) removes only its own recorded file. The svctest/localenv/cbtest code in the worktree is identical to main.
- Inferred: golang-pro's attribution to "corerouter teardown" is the timeline explanation, but the code doesn't confirm it. The actual deleter is unverified. Candidates, in order: (a) a process calling `localenv.Remove`/`cbtest local stop` for the inherited `TEOS_TEST_ENVIRONMENT`, from a shell or test that inherited it; (b) `clean-temp.sh` matching `teos-*` on a file over 60 min old (the run started about 11:3x); (c) a test in the suite attaching to the selected env. `scripts/clean-temp/clean-temp_test.sh` run by `make test` is isolated (it points TMPDIR at its own dir), so it is excluded.
- The root cause class is verified by reading: shared `/tmp` namespace, glob-based ownership, and environment-variable inheritance, with no per-run directory, owner record or lock.

### Fix direction
- Run-scoped state: `RUN_ID ?= $(shell date +%s)-$$$$` (or the worktree name). `RUN_TMP := $(TMPDIR)/teos-run-$(RUN_ID)` is created with `mktemp -d` and exported as `TMPDIR` for test and generate targets, then removed only by the target that created it (trap).
- Certificates: written into the run's private dir (`os.MkdirTemp` per environment). Deletion goes only through the recorded path plus an owner file (pid + start time). Glob deletion is skipped while the owner is alive. `clean-temp` skips CA files and run dirs whose owner is alive.
- Codegen: a per-checkout lock (`flock $(git rev-parse --git-dir)/teos-generate.lock`). Generate into `$(RUN_TMP)/gen` and swap in only on success, including gitignored outputs. No `clean-generated` prerequisite. Docker preflight before anything is touched.
- Process: batch audits run in their own clone or worktree, never inside another minion's locked worktree.

## Blockers / notes
- None blocking planning. Statuses are mostly inferred; only the four known failures plus help/build were verified, because install/dep/generate must not be run in this packet.
- The box session lacks the docker group (use `sg docker`) and has COREPACK_HOME pointing at a root-owned dir. Env notes in w0-env.md still apply until T2/T4 land.
- Appendix is generated by pattern scan; COND/OK rows for deployment and docs targets need confirmation in T11.

## Appendix — full per-target matrix (754 targets)
| Makefile | Target | Linux | macOS | Root cause / notes |
|---|---|---|---|---|
| Makefile | setenv | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | help | PASS (verified) | OK (inferred) | make help ran rc=0 |
| Makefile | all | FAIL (inferred) | OK (inferred) | chains dep+generate |
| Makefile | install | FAIL (verified) | OK (inferred; brew branch) | apt mirror HTTP 500 w/o retry; sudo dpkg/apt/install to /usr/local; first run needed zsh (SHELL=/bin/zsh) |
| Makefile | generate | FAIL (verified) | OK (inferred) | docker.sock permission denied + oapi-codegen not on PATH; model generate-code deletes tracked files before docker runs |
| Makefile | generate-api | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | generate-code | FAIL (verified) | OK (inferred) | same as generate (docker group, ~/go/bin PATH, corepack in web) |
| Makefile | generate-provision | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | build | PASS (verified, with env workaround) | OK (inferred) | passed only with PATH+=~/go/bin, COREPACK_HOME, docker group (w0-env) |
| Makefile | clean | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-generated | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-deps | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-cache | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | distclean | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-modcache | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-temp | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-gocache | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-docker | FAIL (inferred) | OK (inferred) | docker socket needs docker group; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | clean-caches | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | vet | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | vet-rego | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-integration | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-integration-cloud | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | cbtest-bin | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | check-no-floci-goflags | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | run-integration-tests | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-integration-no-cache | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | no-cache | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | -no-cache | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-e2e | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-e2e-cloud | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | run-e2e-tests | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-service | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | test-service-cloud | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | cover | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| Makefile | lint | FAIL (verified) | OK (inferred) | depends on lint-arch/lint-go; bare golangci-lint/go-arch-lint need GOBIN on PATH |
| Makefile | lint-go | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | act-lint | FAIL (inferred) | COND (inferred) | docker socket needs docker group; brew-only; act not installed; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | act-test | FAIL (inferred) | COND (inferred) | docker socket needs docker group; brew-only; act not installed; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint exit 127: ~/go/bin not on PATH |
| Makefile | lint-examples | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | lint-fitness | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | lint-fix | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | format | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt-go | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt-rego | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt-ts | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt-check | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt-check-go | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | fmt-check-ts | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | benchmark | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | dep | FAIL (verified) | OK (inferred) | corepack cache /usr/local/share/corepack not writable (COREPACK_HOME); also pulls in install |
| Makefile | go-work-sum | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-resync | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-resync-steps | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | upgrade | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | check-upgrade | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | tidy | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-sync | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-upgrade-check | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-upgrade | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-upgrade-patch | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | go-upgrade-tidy | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | check-replace | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | check-replace-strict | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | check-replace-fix | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | stats | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | docs-generate | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | docs | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | docs-antora | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | generate-compliance-report | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | web-install | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | web-build | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | web-test | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME; SHELL=/bin/zsh (zsh must be installed) |
| Makefile | web-lint | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | web-generate | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | serve-all | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | serve-tklocal | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | serve-teos | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | install-hooks | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | dependabot-list | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | dependabot-merge | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | dependabot-rebase | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | release | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| Makefile | release-dry-run | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| cmd/Makefile | tklocal | OK (inferred) | OK (inferred) | - |
| cmd/Makefile | install | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| cmd/Makefile | build | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| cmd/Makefile | upgrade | OK (inferred) | OK (inferred) | - |
| cmd/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | dep | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | pnpm-install | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| cmd/tklocal/Makefile | generate-api | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | generate-code | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | docs | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | build | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | serve | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | install | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | installer | FAIL (inferred) | OK (inferred) | makensis not installed |
| cmd/tklocal/Makefile | bundle | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | lint | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| cmd/tklocal/Makefile | react-build | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| cmd/tklocal/Makefile | serve-mock | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| cmd/tklocal/Makefile | serve-dev | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| cmd/tklocal/Makefile | stop | FAIL (inferred) | OK (inferred) | lsof not installed; masks sub-make failures (|| true / ; true) |
| cmd/tklocal/Makefile | release | OK (inferred) | OK (inferred) | - |
| cmd/tklocal/Makefile | clean-generated | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| cmd/tklocal/Makefile | clean | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| cmd/tklocal/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| cmd/tklocal/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| cmd/tklocal/webui/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| cmd/tklocal/webui/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| deployment/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| deployment/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| deployment/lib/Makefile | setenv | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | build | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | clean-generated | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | clean | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | benchmark | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | dep | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | upgrade | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | tidy | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/Makefile | stats | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| deployment/lib/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| deployment/lib/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| deployment/stacks/groundzero/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| deployment/stacks/groundzero/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| devops/gh-backup/Makefile | build | FAIL (inferred) | OK (inferred) | docker socket needs docker group |
| devops/gh-backup/Makefile | login | FAIL (inferred) | OK (inferred) | docker socket needs docker group |
| devops/gh-backup/Makefile | push | FAIL (inferred) | OK (inferred) | docker socket needs docker group |
| devops/gh-backup/Makefile | build-cdk | OK (inferred) | OK (inferred) | - |
| devops/gh-backup/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| devops/gh-backup/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| devops/gh-backup/Makefile | undeploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| devops/gh-backup/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| devops/gh-backup/Makefile | dep | FAIL (inferred) | COND (inferred) | brew-only; restic via brew |
| devops/gh-backup/Makefile | clean | FAIL (inferred) | OK (inferred) | docker socket needs docker group; masks sub-make failures (|| true / ; true) |
| devops/gh-backup/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| devops/handlers/devops-clean-table/Makefile | all | OK (inferred) | OK (inferred) | - |
| devops/handlers/devops-clean-table/Makefile | build | OK (inferred) | OK (inferred) | - |
| devops/handlers/devops-clean-table/Makefile | zip | FAIL (inferred) | OK (inferred) | zip not installed |
| devops/handlers/devops-clean-table/Makefile | deploy | OK (inferred) | OK (inferred) | - |
| devops/handlers/devops-clean-table/Makefile | clean | OK (inferred) | OK (inferred) | - |
| docs_meta.mk | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/Makefile | clean | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| documentation/ai/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/ai/Makefile | docs-contracts-validate | OK (inferred) | OK (inferred) | - |
| documentation/ai/Makefile | docs-render-check | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/ai/Makefile | docs-validate | OK (inferred) | OK (inferred) | - |
| documentation/ai/Makefile | ppt | FAIL (inferred) | COND (inferred) | sed -i '' is BSD-only; asciidoctor from node_modules (after make dep); masks sub-make failures (|| true / ; true) |
| documentation/ai/Makefile | docs-all | OK (inferred) | OK (inferred) | - |
| documentation/ai/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/architecture/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/architecture/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/asciidoc/Makefile | dep | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| documentation/asciidoc/Makefile | clean | OK (inferred) | OK (inferred) | - |
| documentation/business/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/business/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/devops/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/devops/providers/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/devops/updowngrade/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/flow/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/design/flow/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/goservices/webformservice/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/design/schneider/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/ggc/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/overview/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/overview/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/products/siemens/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/products/siemens/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/projects/cesab/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/projects/cesab/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/projects/estimates/Makefile | calculate | OK (inferred) | OK (inferred) | - |
| documentation/projects/estimates/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/projects/estimates/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/projects/ume-energi/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/projects/ume-energi/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/providers/eastbound/schneider/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/providers/eastbound/schneider/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/roadmap/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/roadmap/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/servicedesk/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/servicedesk/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/services/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/services/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/sla/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/sla/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| documentation/token/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| documentation/token/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/Makefile | setenv | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | build | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-core/Makefile | clean | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-core/Makefile | generate | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-core/Makefile | benchmark | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | report | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | reportverbose | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | reportsonar | FAIL (inferred) | OK (inferred) | docker socket needs docker group |
| go-core/Makefile | dep | FAIL (inferred) | OK (inferred) | brew-only; masks sub-make failures (|| true / ; true) |
| go-core/Makefile | generate-api | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-core/Makefile | generate-code | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-core/Makefile | upgrade | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | updatesub | OK (inferred) | OK (inferred) | - |
| go-core/Makefile | stats | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-core/Makefile | licenses | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-core/_design/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-core/_design/Makefile | docs | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; needs kroki on localhost:8000; asciidoctor from node_modules (after make dep) |
| go-core/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/cbanalytics/Makefile | help | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | test-integration | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | vet-rego | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-core/cbanalytics/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-core/cbanalytics/Makefile | fmt | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | fmt-check | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | build-module | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | check | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | check-full | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/Makefile | scenarios | OK (inferred) | OK (inferred) | - |
| go-core/cbanalytics/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/cbanalytics/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/cblang/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/cbpipeline/Makefile | help | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | generate | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | docs-schema | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | test-race | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | bench | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | cover | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-core/cbpipeline/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | docs | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/_design/Makefile | docs-schema | OK (inferred) | OK (inferred) | - |
| go-core/cbpipeline/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/cbpipeline/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/cbpolicy/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/cbpolicy/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/cmdb/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/config/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/interfaces/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/managers/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/model/Makefile | clean | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-core/model/Makefile | generate-code | FAIL (inferred) | COND (inferred; same PATH assumption) | same docker + clean-first pattern as go-services/model |
| go-core/model/Makefile | generate | OK (inferred) | OK (inferred) | - |
| go-core/provider/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/provider/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/provider/providerconfig/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/provider/providerpipe/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/provider/providerpipe/_design/Makefile | docs-developer | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/provider/providerpipe/_design/Makefile | docs-architect | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/provider/providerpipe/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/pubsub/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/pubsub/_design/pubsubsdk/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/schedules/calendar/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/schedules/calendar/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/tkdisp/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-core/tkdisp/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-core/tkdisp/cbprovider/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/Makefile | setenv | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | all | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | build | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | clean-generated | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | clean | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | benchmark | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | dep | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | generate-api | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | generate-code | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true); SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | upgrade | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | tidy | OK (inferred) | OK (inferred) | SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | stats | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| go-services/Makefile | generate-compliance-report | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; SHELL=/bin/zsh (zsh must be installed) |
| go-services/_design/Makefile | docs | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH; needs kroki on localhost:8000; asciidoctor from node_modules (after make dep) |
| go-services/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/actuationsvc/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/actuationsvc/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/actuationsvc/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/actuationsvc/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/actuationsvc/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/actuationsvc/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/actuationsvc/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/actuationsvc/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/actuationsvc/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/actuationsvc/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/actuationsvc/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/actuationsvc/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/appstore/Makefile | build | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/appstore/Makefile | clean-generated | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | generate-api | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | generate-code | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/Makefile | bundle | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | lint-api | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | validate-openapi | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | docs | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/appstore/Makefile | synth-ci | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/appstore/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/appstore/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | test-integration | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | fmt | OK (inferred) | OK (inferred) | - |
| go-services/appstore/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/appstore/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/appstore/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/appstore/cmd/cbdeploy/Makefile | install | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/cmd/cbdeploy/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/appstore/cmd/cbdeploy/Makefile | test-integration | OK (inferred) | OK (inferred) | - |
| go-services/appstore/cmd/cbdeploy/Makefile | build | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/cmd/cbdeploy/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/appstore/cmd/cbdeploy/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/cmd/cbdeploy/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/appstore/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/appstore/deployment/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/appstore/deployment/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/appstore/deployment/Makefile | test-short | OK (inferred) | OK (inferred) | - |
| go-services/appstore/deployment/Makefile | fmt | OK (inferred) | OK (inferred) | - |
| go-services/appstore/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/buildingsvc/Makefile | generate-code | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/Makefile | generate-api | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/Makefile | bundle | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/buildingsvc/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/buildingsvc/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/buildingsvc/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/buildingsvc/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/buildingsvc/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/buildingsvc/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/buildingsvc/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/buildingsvc/export/Makefile | generate-code | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/export/Makefile | generate | OK (inferred) | OK (inferred) | - |
| go-services/buildingsvc/export/client/apiclient/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/collectorsvc/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/collectorsvc/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/collectorsvc/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/collectorsvc/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/collectorsvc/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/collectorsvc/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/collectorsvc/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/collectorsvc/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/collectorsvc/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/collectorsvc/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/collectorsvc/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/collectorsvc/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/core/brokers/gobridge/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/Makefile | test-integration | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/Makefile | test-service | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/brokers/gobridge/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/core/brokers/gobridge/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/Makefile | fmt | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/brokers/gobridge/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/brokers/gobridge/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/brokers/gobridge/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/brokers/gobridge/deployment/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/Makefile | test-integration | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/brokers/gobridge/deployment/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/service-test/Makefile | test-service | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/service-test/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/core/brokers/gobridge/deployment/service-test/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/management/alarm-service/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/management/alarm-service/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/core/management/alarm-service/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/Makefile | generate-api | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/Makefile | generate-code | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/management/alarm-service/Makefile | bundle | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/Makefile | docs | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/core/management/alarm-service/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/core/management/alarm-service/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/core/management/alarm-service/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/alarm-service/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/alarm-service/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/alarm-service/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/iam/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/management/iam/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/core/management/iam/Makefile | clean-generated | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/management/iam/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/Makefile | generate-api | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/Makefile | generate-code | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/core/management/iam/Makefile | bundle | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/Makefile | lint-api | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/Makefile | docs | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/core/management/iam/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/core/management/iam/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/core/management/iam/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/iam/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/iam/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/core/management/iam/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/corerouter/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/corerouter/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/corerouter/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/corerouter/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/corerouter/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/corerouter/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/corerouter/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/corerouter/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/corerouter/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/corerouter/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/corerouter/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/corerouter/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/devicesvc/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/devicesvc/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/devicesvc/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/devicesvc/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/devicesvc/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/devicesvc/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/devicesvc/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/devicesvc/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/devicesvc/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/devicesvc/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/devicesvc/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/devicesvc/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/eventsvc/Makefile | help | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/Makefile | test-integration | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/eventsvc/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/eventsvc/Makefile | check-model | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/eventsvc/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/eventsvc/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/eventsvc/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/eventsvc/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/eventsvc/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/eventsvc/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/deployment/service-test/Makefile | test-service | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/deployment/service-test/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/eventsvc/deployment/service-test/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/eventsvc/evidencemonitor/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/eventsvc/evidencemonitor/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/ingestionsvc/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/ingestionsvc/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/ingestionsvc/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/ingestionsvc/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/ingestionsvc/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/ingestionsvc/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/ingestionsvc/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/ingestionsvc/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/ingestionsvc/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/ingestionsvc/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/ingestionsvc/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/ingestionsvc/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/management/custom/cb-account-creation/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/management/custom/cb-account-creation/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/management/custom/cb-account-creation/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/management/custom/cb-account-creation/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/management/custom/cb-account-creation/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/management/custom/cb-account-creation/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/management/custom/cb-account-creation/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/management/custom/cb-account-creation/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/model/Makefile | generate-code | FAIL (verified) | OK (inferred) | docker.sock denied; clean-generated runs first and leaves 45 tracked *api files deleted |
| go-services/model/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| go-services/model/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/buildingx/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/buildingx/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/providers/eastbound/buildingx/Makefile | generate-code | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/buildingx/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/buildingx/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/buildingx/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/buildingx/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/buildingx/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/buildingx/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/buildingx/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/buildingx/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/buildingx/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/climatixic/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/climatixic/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/climatixic/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/climatixic/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/climatixic/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/climatixic/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/climatixic/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/climatixic/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/climatixic/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/climatixic/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/danfosslh/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/danfosslh/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/danfosslh/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/danfosslh/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/ecoguard/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/ecoguard/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/ecoguard/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/ecoguard/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/Makefile | lint | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/providers/eastbound/mqtt/Makefile | vet | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/mqtt/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/mqtt/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/mqtt/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/mqtt/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/mqtt/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/mqtt/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/mqtt/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/mqtt/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/realestatecore/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/realestatecore/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/realestatecore/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/realestatecore/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/regin/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/regin/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/regin/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/regin/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/regin/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/regin/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/regin/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/regin/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/regin/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/regin/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sensative/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sensative/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sensative/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sensative/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sensative/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sensative/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sensative/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sensative/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/Makefile | generate | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/Makefile | generate-code | FAIL (inferred) | COND (inferred; same PATH assumption) | docker socket needs docker group; bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/providers/eastbound/sur/Makefile | clean-generated | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-services/providers/eastbound/sur/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/Makefile | lint | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/providers/eastbound/sur/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/sur/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/sur/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sur/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sur/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sur/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/sur/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/sur/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/sur/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/tklocal/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/tklocal/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/tklocal/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/tklocal/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/tklocal/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/tklocal/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/tklocal/deployment/Makefile | deploy-ci | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/tklocal/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/tklocal/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/tklocal/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/wideco/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/wideco/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/eastbound/wideco/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/eastbound/wideco/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/wideco/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/eastbound/wideco/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/wideco/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/wideco/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/wideco/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/eastbound/wideco/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/azure/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/azure/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/northbound/azure/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/northbound/azure/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/azure/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/azure/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/azure/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/azure/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/azure/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/azure/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/Makefile | ${DIST_OUTPUT} | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/Makefile | _dist/_output/sda-http-api.yaml | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/northbound/sda/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/northbound/sda/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/deployment/Makefile | synth | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/deployment/Makefile | deploy | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/deployment/Makefile | destroy | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/deployment/Makefile | verify | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sda/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/Makefile | ${DIST_OUTPUT} | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/Makefile | _dist/_output/siemens-http-api.yaml | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/northbound/siemens/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/northbound/siemens/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/siemens/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/siemens/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/siemens/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/siemens/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/siemens/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/Makefile | ${DIST_OUTPUT} | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/Makefile | _dist/_output/sma-http-api.yaml | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/northbound/sma/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/northbound/sma/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/northbound/sma/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/sma/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/sma/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/sma/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/northbound/sma/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/algeno/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/algeno/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/westbound/algeno/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/westbound/algeno/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/algeno/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/algeno/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/algeno/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/algeno/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/algeno/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/algeno/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/providers/westbound/nodabuilding/Makefile | generate-code | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/westbound/nodabuilding/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/providers/westbound/nodabuilding/cmd/noda/Makefile | dep | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| go-services/providers/westbound/nodabuilding/cmd/noda/Makefile | web-build | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| go-services/providers/westbound/nodabuilding/cmd/noda/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/cmd/noda/Makefile | serve | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | build | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | destroy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | verify | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/providers/westbound/nodabuilding/deployment/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/providers/westbound/nodabuilding/deployment/service-test/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/providers/westbound/nodabuilding/deployment/service-test/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/realestatecore/Makefile | setenv | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | all | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | setup | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | dep | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/realestatecore/Makefile | download-rec-specs | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | test | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | test-ci | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | benchmark | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | lint | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/realestatecore/Makefile | lint-arch | FAIL (verified) | COND (inferred; same PATH assumption) | go-arch-lint not on PATH (127) |
| go-services/realestatecore/Makefile | lint-fix | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/realestatecore/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| go-services/realestatecore/Makefile | generate-check | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | deploy | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/realestatecore/Makefile | synth | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/realestatecore/Makefile | diff | FAIL (inferred) | COND (inferred; same PATH assumption) | cdk in ~/.local/bin (npm -g prefix) not on PATH |
| go-services/realestatecore/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | upgrade | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | ci | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/Makefile | help | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/_design/Makefile | all | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/_design/Makefile | html | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/realestatecore/_design/Makefile | pdf | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/realestatecore/_design/Makefile | diagrams | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| go-services/realestatecore/_design/Makefile | clean | OK (inferred) | OK (inferred) | - |
| go-services/realestatecore/_design/Makefile | install-deps | FAIL (inferred) | COND (inferred) | corepack needs writable COREPACK_HOME; brew-only; asciidoctor from node_modules (after make dep) |
| go-services/realestatecore/migration/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/realestatecore/migration/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/tklocal/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/tklocal/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| go-services/tklocal/ruleengine/_design/Makefile | docs | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| go-services/tklocal/ruleengine/_design/Makefile | docs-generate | COND (inferred) | COND (inferred) | needs kroki on localhost:8000 |
| meta/Makefile | setenv | OK (inferred) | OK (inferred) | - |
| meta/Makefile | docs-ims-system | COND (inferred) | COND (inferred) | asciidoctor from node_modules (after make dep) |
| meta/Makefile | generate | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| meta/Makefile | stats | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| meta/Makefile | dep | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| meta/Makefile | generate-api | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| meta/Makefile | generate-code | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| meta/Makefile | build | OK (inferred) | OK (inferred) | - |
| meta/Makefile | clean | OK (inferred) | OK (inferred) | - |
| meta/Makefile | check-upgrade | OK (inferred) | OK (inferred) | - |
| meta/Makefile | upgrade | OK (inferred) | OK (inferred) | - |
| meta/Makefile | tidy | OK (inferred) | OK (inferred) | - |
| meta/spec/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| meta/spec/Makefile | clean | OK (inferred) | OK (inferred) | - |
| meta/spec/Makefile | generate | OK (inferred) | OK (inferred) | - |
| meta/spec/Makefile | generate-api | OK (inferred) | OK (inferred) | - |
| meta/spec/Makefile | FORCE | OK (inferred) | OK (inferred) | - |
| meta/spec/Makefile | $(APIS) | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| meta/spec/Makefile | _output/api/sur/http-api.yaml | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| meta/spec/Makefile | docs | OK (inferred) | OK (inferred) | - |
| meta/spec/model/eqmodel/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| meta/spec/model/providermodel/Makefile | generate | FAIL (inferred) | COND (inferred; same PATH assumption) | bare ~/go/bin tool, needs GOBIN on PATH |
| web/Makefile | install | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | build | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | dev-teos | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | dev-tklocal | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | lint | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | typecheck | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | clean-generated | OK (inferred) | OK (inferred) | - |
| web/Makefile | clean | OK (inferred) | OK (inferred) | - |
| web/Makefile | fmt | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/Makefile | generate-api | OK (inferred) | OK (inferred) | masks sub-make failures (|| true / ; true) |
| web/Makefile | generate-code | FAIL (verified) | OK (inferred) | corepack cache dir not writable |
| web/teos/Makefile | generate-code | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/teos/Makefile | serve-dev | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/teos/Makefile | build | FAIL (inferred) | OK (inferred) | corepack needs writable COREPACK_HOME |
| web/teos/Makefile | verify-monaco-lazy | OK (inferred) | OK (inferred) | - |