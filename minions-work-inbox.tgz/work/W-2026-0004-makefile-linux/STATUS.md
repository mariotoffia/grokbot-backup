# W-2026-0004 Makefile Linux support

Scope: every teos Makefile target works on Linux (Debian) and macOS. OS-specific logic is isolated, not scattered conditionals. PLANNING ONLY: no implementation until Mario says go.
Owner of investigation: platform-lead. Input: /workspace/lintarch/ logs, clean-arch-reviewer msg-006.

- 2026-10-22 13:10 dev-lead: opened; investigation sent to platform-lead.
- 2026-10-22 13:11 (Europe/Stockholm) platform-lead start: msg-W-2026-0004-dev-lead-001 accepted (planning only); investigation routed to release-config-mgr as P-2026-0004-01.
- 2026-10-22 13:11 release-config-mgr start: P-2026-0004-01 planning audit of all teos Makefile targets for Linux/macOS.
- 2026-10-22 13:14 release-config-mgr done: investigation.md written (754 targets, 227 Linux failing, 0 macOS hard failures, tasks T1-T12).
- 2026-10-22 13:15 (Europe/Stockholm) platform-lead milestone: P-01 matrix + T1–T12 done; addendum (shared mutable state: generate deletes, harness cert) sent to release-config-mgr.
- 2026-10-22 13:15 release-config-mgr milestone: addendum start, investigating shared mutable state (sur model deletion, harness certs).
- 2026-10-22 13:18 release-config-mgr done: addendum 'Shared mutable state' added (sur deletion root-caused to lintarch batch generate in T-27.21 worktree; cert deletion = shared /tmp glob ownership); tasks T5 extended, T13-T17 added.
- 2026-10-22 13:20 (Europe/Stockholm) platform-lead done: P-01 + addendum delivered to dev-lead (msg-004). Risk: 5 worktrees lack sur models; do not rerun /workspace/lintarch/run.sh. Next: Mario's go for T1–T17.
- 2026-10-22 13:42 (Europe/Stockholm) cto: approval request for T1–T17 posted to Mario in #teos-grokbot (ts 1792669212.952129) and buzz teos-grok. Phase awaiting-approval; no implementation until Mario's go.
